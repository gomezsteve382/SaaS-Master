import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { makeId } from "./id.js";

export interface KnowledgeChunk {
  id: string;
  documentId: string;
  index: number;
  text: string;
  tokenEstimate: number;
  keywords: string[];
  createdAt: string;
}

export interface KnowledgeDocument {
  id: string;
  title: string;
  sourceType: "file" | "text" | "url_note";
  source: string;
  tags: string[];
  checksum: string;
  chunkCount: number;
  createdAt: string;
  updatedAt: string;
  metadata: Record<string, unknown>;
}

export interface KnowledgeSearchResult {
  document: KnowledgeDocument;
  chunk: KnowledgeChunk;
  score: number;
  highlights: string[];
}

interface KnowledgeDatabaseShape {
  version: 1;
  updatedAt: string;
  documents: KnowledgeDocument[];
  chunks: KnowledgeChunk[];
}

const emptyKnowledgeDatabase = (): KnowledgeDatabaseShape => ({
  version: 1,
  updatedAt: new Date().toISOString(),
  documents: [],
  chunks: []
});

function normalizeText(value: string): string {
  return value.replace(/\r\n/g, "\n").replace(/[\t ]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

function checksum(value: string): string {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = ((hash << 5) - hash + value.charCodeAt(index)) | 0;
  }
  return Math.abs(hash).toString(16).padStart(8, "0");
}

function tokenize(value: string): string[] {
  const stop = new Set(["the", "and", "for", "with", "that", "this", "from", "are", "you", "your", "into", "will", "have", "has", "not", "but", "was", "were", "can", "all", "our", "out", "use", "using", "how", "what", "when", "where", "why"]);
  return [...new Set(value.toLowerCase().match(/[a-z0-9_#.-]{3,}/g) ?? [])].filter((word) => !stop.has(word));
}

function chunkText(text: string, maxChars = 1400): string[] {
  const paragraphs = text.split(/\n\s*\n/g).map((part) => part.trim()).filter(Boolean);
  const chunks: string[] = [];
  let current = "";
  for (const paragraph of paragraphs.length ? paragraphs : [text]) {
    if ((current + "\n\n" + paragraph).trim().length > maxChars && current.trim()) {
      chunks.push(current.trim());
      current = paragraph;
    } else {
      current = (current ? `${current}\n\n${paragraph}` : paragraph).trim();
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks.flatMap((chunk) => {
    if (chunk.length <= maxChars * 1.5) return [chunk];
    const split: string[] = [];
    for (let cursor = 0; cursor < chunk.length; cursor += maxChars) split.push(chunk.slice(cursor, cursor + maxChars));
    return split;
  });
}

export class KnowledgeBaseStore {
  readonly path: string;

  constructor(private readonly cwd: string, path = ".goatmez/knowledge.json") {
    this.path = resolve(cwd, process.env.GOATMEZ_KB_PATH || path);
  }

  read(): KnowledgeDatabaseShape {
    try {
      const parsed = JSON.parse(readFileSync(this.path, "utf8")) as Partial<KnowledgeDatabaseShape>;
      return {
        version: 1,
        updatedAt: typeof parsed.updatedAt === "string" ? parsed.updatedAt : new Date().toISOString(),
        documents: Array.isArray(parsed.documents) ? parsed.documents as KnowledgeDocument[] : [],
        chunks: Array.isArray(parsed.chunks) ? parsed.chunks as KnowledgeChunk[] : []
      };
    } catch (error: any) {
      if (error?.code === "ENOENT") return emptyKnowledgeDatabase();
      throw error;
    }
  }

  write(next: KnowledgeDatabaseShape): void {
    mkdirSync(dirname(this.path), { recursive: true });
    writeFileSync(this.path, JSON.stringify({ ...next, updatedAt: new Date().toISOString() }, null, 2));
  }

  listDocuments(): KnowledgeDocument[] {
    return [...this.read().documents].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  getDocument(id: string): { document: KnowledgeDocument; chunks: KnowledgeChunk[] } | undefined {
    const db = this.read();
    const document = db.documents.find((item) => item.id === id);
    if (!document) return undefined;
    return { document, chunks: db.chunks.filter((chunk) => chunk.documentId === id).sort((a, b) => a.index - b.index) };
  }

  ingestText(input: { title: string; text: string; source?: string; sourceType?: KnowledgeDocument["sourceType"]; tags?: string[]; metadata?: Record<string, unknown> }): { document: KnowledgeDocument; chunks: KnowledgeChunk[]; replacedExisting: boolean } {
    const text = normalizeText(input.text);
    if (!text) throw new Error("Knowledge text is empty.");
    const now = new Date().toISOString();
    const digest = checksum(`${input.title}\n${text}`);
    const pieces = chunkText(text);
    const documentId = makeId("kbdoc");
    const document: KnowledgeDocument = {
      id: documentId,
      title: input.title.trim() || "Untitled knowledge document",
      sourceType: input.sourceType || "text",
      source: input.source || input.title,
      tags: [...new Set((input.tags || []).map((tag) => tag.trim()).filter(Boolean))],
      checksum: digest,
      chunkCount: pieces.length,
      createdAt: now,
      updatedAt: now,
      metadata: input.metadata || {}
    };
    const chunks = pieces.map((piece, index): KnowledgeChunk => ({
      id: makeId("kbchunk"),
      documentId,
      index,
      text: piece,
      tokenEstimate: Math.ceil(piece.length / 4),
      keywords: tokenize(piece).slice(0, 40),
      createdAt: now
    }));

    let replacedExisting = false;
    const db = this.read();
    const existing = db.documents.find((item) => item.checksum === digest || (item.source === document.source && item.title === document.title));
    if (existing) {
      replacedExisting = true;
      document.id = existing.id;
      document.createdAt = existing.createdAt;
      document.updatedAt = now;
      for (const chunk of chunks) chunk.documentId = existing.id;
      db.documents = [document, ...db.documents.filter((item) => item.id !== existing.id)];
      db.chunks = [...chunks, ...db.chunks.filter((chunk) => chunk.documentId !== existing.id)];
    } else {
      db.documents = [document, ...db.documents];
      db.chunks = [...chunks, ...db.chunks];
    }
    this.write(db);
    return { document, chunks, replacedExisting };
  }

  search(query: string, options: { limit?: number; tags?: string[] } = {}): KnowledgeSearchResult[] {
    const cleanQuery = query.trim();
    if (!cleanQuery) return [];
    const queryTokens = tokenize(cleanQuery);
    const tagFilter = new Set((options.tags || []).map((tag) => tag.toLowerCase()));
    const db = this.read();
    const docsById = new Map(db.documents.map((document) => [document.id, document]));
    const results: KnowledgeSearchResult[] = [];

    for (const chunk of db.chunks) {
      const document = docsById.get(chunk.documentId);
      if (!document) continue;
      if (tagFilter.size && !document.tags.some((tag) => tagFilter.has(tag.toLowerCase()))) continue;
      const haystack = `${document.title}\n${document.tags.join(" ")}\n${chunk.text}`.toLowerCase();
      let score = 0;
      for (const token of queryTokens) {
        if (haystack.includes(token)) score += 4;
        if (chunk.keywords.includes(token)) score += 3;
      }
      if (haystack.includes(cleanQuery.toLowerCase())) score += 10;
      if (score <= 0) continue;
      const highlights = queryTokens.slice(0, 6).filter((token) => haystack.includes(token));
      results.push({ document, chunk, score, highlights });
    }

    return results.sort((a, b) => b.score - a.score).slice(0, Math.max(1, options.limit || 10));
  }

  deleteDocument(id: string): boolean {
    const db = this.read();
    const before = db.documents.length;
    db.documents = db.documents.filter((document) => document.id !== id);
    db.chunks = db.chunks.filter((chunk) => chunk.documentId !== id);
    const deleted = db.documents.length !== before;
    if (deleted) this.write(db);
    return deleted;
  }
}
