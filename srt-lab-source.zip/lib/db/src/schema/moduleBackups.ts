import { pgTable, text, integer, jsonb, timestamp, index } from "drizzle-orm/pg-core";

export const moduleBackupsTable = pgTable(
  "module_backups",
  {
    id: text("id").primaryKey(),
    module: text("module").notNull(),
    vin: text("vin").notNull(),
    didCount: integer("did_count").notNull().default(0),
    tx: integer("tx"),
    rx: integer("rx"),
    timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
    payload: jsonb("payload").notNull(),
    checksum: text("checksum"),
    snapshotKind: text("snapshot_kind"),
    preWriteKey: text("pre_write_key"),
    jobId: text("job_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    moduleIdx: index("module_backups_module_idx").on(t.module),
    timestampIdx: index("module_backups_timestamp_idx").on(t.timestamp),
    jobIdIdx: index("module_backups_job_id_idx").on(t.jobId),
  }),
);

export type ModuleBackup = typeof moduleBackupsTable.$inferSelect;
