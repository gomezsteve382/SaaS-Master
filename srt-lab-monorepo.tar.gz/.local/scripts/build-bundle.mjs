import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = '/home/runner/workspace';
const OUT_TXT = path.join(ROOT, 'srt-lab-monorepo-bundle.txt');

const EXCLUDE_DIRS = new Set([
  'node_modules', '.git', '.cache', 'dist', 'build', '.next', '.turbo',
  '.vite', '.pnpm-store', '__pycache__', '.pytest_cache',
  'coverage', '.nyc_output', '.parcel-cache',
]);
const EXCLUDE_PATH_PREFIXES = [
  '.local/state', '.local/.commit_message', '.local/secondary_skills',
  '.local/skills', '.local/scripts', '.local/share', '.local/cache',
  '.local/tmp', 'attached_assets',
];
const TEXT_EXTS = new Set([
  '.js','.jsx','.ts','.tsx','.mjs','.cjs','.json','.md','.txt','.html','.css',
  '.scss','.sass','.less','.yml','.yaml','.toml','.gitignore',
  '.gitattributes','.replitignore','.sql','.sh','.bash',
  '.zsh','.py','.rb','.go','.rs','.java','.c','.cpp','.h','.hpp','.svg',
  '.xml','.ini','.cfg','.conf','.editorconfig','.prettierrc','.eslintrc',
  '.npmrc','.nvmrc','.dockerignore','.replit','.tsconfig','.map','.example',
]);
const BINARY_EXTS = new Set([
  '.png','.jpg','.jpeg','.gif','.webp','.ico','.bmp','.tiff','.pdf',
  '.zip','.tar','.gz','.bz2','.xz','.7z','.rar','.exe','.dll','.so',
  '.dylib','.bin','.dat','.db','.sqlite','.sqlite3','.woff','.woff2',
  '.ttf','.otf','.eot','.mp3','.mp4','.avi','.mov','.wav','.flac',
  '.ogg','.webm','.class','.jar','.pyc',
]);
const SKIP_FILES = new Set([
  'pnpm-lock.yaml', 'package-lock.json', 'yarn.lock',
  'srt-lab-monorepo-bundle.txt', 'srt-lab-monorepo.tar.gz',
  'srt-lab-all-code.txt',
]);

function isBinary(buf) {
  const n = Math.min(buf.length, 8000);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

const files = [];
function walk(dir) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return; }
  for (const e of entries) {
    const full = path.join(dir, e.name);
    const rel = path.relative(ROOT, full);
    if (e.isSymbolicLink()) continue;
    if (e.isDirectory()) {
      if (EXCLUDE_DIRS.has(e.name)) continue;
      if (EXCLUDE_PATH_PREFIXES.some(p => rel === p || rel.startsWith(p + '/'))) continue;
      walk(full);
    } else if (e.isFile()) {
      if (SKIP_FILES.has(e.name)) continue;
      if (e.name.startsWith('.env') && e.name !== '.env.example') continue;
      if (EXCLUDE_PATH_PREFIXES.some(p => rel === p || rel.startsWith(p + '/'))) continue;
      files.push(rel);
    }
  }
}
walk(ROOT);
files.sort();

let totalText = 0, totalBin = 0, totalSkipped = 0, written = 0;
const out = fs.createWriteStream(OUT_TXT);
out.write('===== SRT-LAB MONOREPO BUNDLE =====\n');
out.write(`Generated: ${new Date().toISOString()}\n`);
out.write(`Files: ${files.length}\n`);
out.write('Excluded: node_modules, .git, dist, build, .cache, .local/state, .local/skills, .env*, lockfiles, binaries (inlined as <<binary>> placeholder).\n');
out.write('=========================================\n\n');

for (const rel of files) {
  const full = path.join(ROOT, rel);
  let st;
  try { st = fs.statSync(full); } catch { continue; }
  if (st.size > 5 * 1024 * 1024) {
    out.write(`===== ${rel} =====\n<<skipped: ${st.size} bytes (>5MB)>>\n\n`);
    totalSkipped++;
    continue;
  }
  const ext = path.extname(rel).toLowerCase();
  out.write(`===== ${rel} =====\n`);
  let buf;
  try { buf = fs.readFileSync(full); } catch (e) { out.write(`<<unreadable: ${e.message}>>\n\n`); continue; }
  let binary = BINARY_EXTS.has(ext);
  if (!binary && !TEXT_EXTS.has(ext)) binary = isBinary(buf);
  if (binary) {
    const sha = crypto.createHash('sha256').update(buf).digest('hex').slice(0, 16);
    out.write(`<<binary file, ${st.size} bytes, sha256:${sha}…>>\n\n`);
    totalBin++;
  } else {
    out.write(buf.toString('utf8'));
    if (!buf.length || buf[buf.length - 1] !== 0x0a) out.write('\n');
    out.write('\n');
    totalText++;
    written += buf.length;
  }
}
out.end();
await new Promise(r => out.on('finish', r));
const finalSt = fs.statSync(OUT_TXT);
console.log(`text=${totalText} binary=${totalBin} skipped=${totalSkipped} body=${written} bundle=${finalSt.size}`);
