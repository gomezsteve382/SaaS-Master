# ImmoVIN Tab — RFH ST95640 + BCM MPC5606B

## What & Why
Add a new **IMMOVIN** tab to SRT Lab with two independent sections for binary-level VIN inspection and editing of two FCA module types: the ST95640 8KB EEPROM (used in RFH MC9S12X) and the BCM MPC5606B_05B (64KB D-Flash). Each section follows the same two-phase workflow: INSPECT first (read-only analysis), then re-upload the same file and APPLY edits (write + download).

## Done looks like
- A new **IMMOVIN** nav tab appears in the SRT Lab header.
- **RFH / ST95640 section (top half):**
  - User uploads an 8KB `.bin` dump; INSPECT reports size, chip OK, ID1/PN/ID2 identification strings, current VIN, and a table showing VIN1 and VIN2 with their offsets, stored checksum, calculated checksum, and OK/FAIL badge.
  - User re-uploads the same file, enters a new 17-char VIN (live format validation), hits APPLY → the tool writes the new VIN to both slots, recalculates the single-byte checksum at 0x0274 and 0x0287 (byte sum of the 17 VIN bytes, masked to 0xFF), and downloads the patched 8KB file.
- **BCM MPC5606B_05B section (bottom half):**
  - User uploads a 65536-byte `.bin`; INSPECT reports MCU type, size, main VIN (highest-scoring copy), a table of up to 4 VIN copies (offsets 0x5320, 0x5340, 0x5360, 0x5380) each with local CRC16 status (OK/FAIL), and the SEC16 value if found (32 hex chars, validated with CRC16 poly 0x1021 seed 0xFFFF at the 2-byte CRC slot after the 16-byte key).
  - User re-uploads the same file, optionally enters a new VIN (17 chars) and/or new SEC16 (32 hex digits), hits APPLY → the tool writes only the non-empty fields, recalculates all relevant checksums, and downloads the patched 65536-byte file.
  - If a field is left blank it is not modified.

## Out of scope
- Live OBD/UDS writing for these module types.
- Any module types other than ST95640 (8KB) and BCM MPC5606B_05B (65536 bytes).
- Auto-detection or mixing of files between the two sections.

## Tasks
1. **ImmoVIN tab shell** — Add `IMMOVIN` to the TABS array in App.jsx and wire up a new `ImmoVINTab` component rendered when that tab is active.

2. **ST95640 INSPECT logic** — Parse the 8KB buffer: extract ID1 (offset area), PN, ID2 identification strings; extract VIN1 at 0x0275 (17 bytes) and VIN2 at 0x0288 (17 bytes); read stored checksum bytes at 0x0274 and 0x0287; calculate expected checksum as `(sum of 17 VIN bytes) & 0xFF`; compare stored vs calculated and expose OK/FAIL state.

3. **ST95640 APPLY + download** — On second file upload + new VIN entry: write the 17-byte VIN into both 0x0275 and 0x0288; write recalculated checksum bytes to 0x0274 and 0x0287; trigger browser download of the patched buffer.

4. **BCM MPC5606B_05B INSPECT logic** — Parse the 65536-byte buffer: detect MCU by size; extract VIN copies from 0x5320, 0x5340, 0x5360, 0x5380 (17 bytes each), compute local CRC16 (poly 0x1021, seed 0xFFFF) over the 17-byte VIN and compare with the 2-byte CRC stored immediately after; score copies to find the main VIN; read 16-byte SEC16 from 0x0838, validate its CRC16 at 0x0848.

5. **BCM APPLY + download** — On second file upload + optional VIN/SEC16 entry: write new VIN to all 4 slots and update their CRC16s; write new SEC16 (hex-decoded) to 0x0838 and update CRC16 at 0x0848; skip any field left blank; trigger browser download.

6. **ImmoVINTab UI** — Build the React component with two clearly labeled card sections matching the described layout: file chooser → Analyze button → results table → second file chooser → input fields → APPLY button. Show per-slot OK/FAIL badges, live VIN length counter (17/17), and hex validation for SEC16.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/crc.js`
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx`
- `artifacts/srt-lab/src/tabs/DumpsTab.jsx`
