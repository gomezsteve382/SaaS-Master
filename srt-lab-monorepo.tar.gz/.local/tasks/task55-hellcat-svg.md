---
title: Replace generic car SVG in PAIRED banner with a proper Hellcat Charger
---
# Hellcat Charger SVG in PAIRED Banner

## What & Why

The current PairedBanner has a blocky trapezoid on wheels that doesn't look like
anything in particular. User explicitly asked for a Hellcat Charger instead.

Replace the SVG body inside the animated `<div>` in `PairedBanner()` with a
recognisable 5th-gen Dodge Charger Hellcat side-profile silhouette.

## Done looks like

- The SVG reads as a Charger Hellcat from the side: long fastback roofline, wide
  muscular body, squared-off front fascia with split grille opening, rectangular
  headlight stack, Supercharged hood bulge, wide rear haunches, dual exhaust tips,
  and a subtle decklid/spoiler.
- Wheels: two large circles with a 5-spoke pattern (path or spokes via lines).
- Color palette stays consistent: dark body (#1a1a1a / #111), green (#00C853) glow
  strokes and accents, amber headlights (#FFB300), red taillights (#FF1744).
- Exhaust smoke circles stay at the rear (left edge of the SVG when car faces right).
- SVG viewBox should be wider than the original (e.g. 200×70) to give the Charger
  the long-body proportions it deserves.
- All other animation/banner logic is unchanged — only the `<svg>...</svg>` block
  inside `PairedBanner` is replaced.

## Key Charger Hellcat profile landmarks (left=rear, right=front, car faces right)

Roofline: flat fast-back from ~x=55 (B-pillar) rising slightly at A-pillar (~x=125),
dropping sharply at C-pillar to deck (~x=40). Front: near-vertical with slight rake.
Hood: long and flat with a raised power dome centered ~x=130–160.
Front fascia: Charger's distinctive dual-opening split grille, tall lower intake.
Headlights: stacked rectangular DRL strip + main lamp block at far right.
Rear: tall, upright trunk with subtle decklid spoiler, round taillamp cluster.
Wheels: centred approx. x=50 (rear) and x=155 (front), y=60, r=13.
Spoke detail: 5 lines from center to rim at 72° increments.

## Relevant files

`artifacts/srt-lab/src/tabs/TwinTab.jsx`
Lines ~514–528: the `<svg>` block inside PairedBanner's animated Charger div.

No other files touched.
