# RFH → PCM Pairing Tab

## What & Why
Add a dedicated "RFH → PCM" tab that implements the full herokee-style pairing workflow:
load an RFH (24C32 EEPROM) and a PCM (GPEC2/GPEC3/GPEC2A) dump, perform deep validation
on both, show a structured compatibility report, and — if valid — apply the RFH-derived SEC6
(and optionally VIN) into the PCM dump for download.

## Done looks like
- Two file drop zones: "RFH 24C32 (.bin)" and "PCM GPEC (.bin/.eprom)"
- After both files are loaded, an INSPECT section shows:
  - **RFH panel**: generation (gen1/gen2), VIN (value + status), Part Number, Serial,
    SEC16 Slot 1 & 2 (hex + BCM-style hex + XOR CS + PIN per slot),
    SEC6 derived (first 6 bytes of valid SEC16, or error), and all check badges
    (SEC16 match, CS match, PIN match)
  - **PCM panel**: VIN current, VIN original, PN, Serial, IMMO state (raw pattern + label),
    SEC6 raw (offset 0x03C8, 6 bytes), write-check (need vs buf)
  - **Compatibility status card**: overall verdict (LOCKED / COMPATIBLE / WARNING), reason text,
    issues list, info list, and a comparison table (VIN equal before, SEC6 equal before,
    SEC6 RFH→PCM, SEC6 PCM current)
- APPLY button is enabled only when backend logic confirms pairing is valid; it writes
  the derived SEC6 into the PCM at offset 0x03C8 and writes the RFH VIN to all 3 PCM VIN
  slots (0x0000, 0x01F0, 0x0224) if the RFH VIN is valid
- DOWNLOAD button exports the patched PCM as `<original>_RFH-PCM_<VIN>.bin`
- Warnings shown for unexpected file sizes (e.g. 8192 bytes instead of 4096 for Gen2)

## Out of scope
- Writing back to hardware (OBD/bench) — file-only workflow
- BCM pairing (separate SecurityTab feature)
- IMMO fix on a damaged PCM (noted in UI but not applied here)
- Modifying ImmoVINTab or SecurityTab

## Tasks

1. **RFH 24C32 parser** — Implement `parseRFH24C32(buf)` that returns: detected generation
   (gen1/gen2 via scoring), VIN at offset 0x92 (17 bytes ASCII) + CRC16 at 0xA3, Part Number
   at 0x0808 (10 bytes ASCII), Serial at 0x0812 (10 bytes ASCII), SEC16 Slot 1 at 0xAE
   (16 bytes + XOR CS at 0xBE), SEC16 Slot 2 at 0xC0 (16 bytes + XOR CS at 0xD0),
   BCM-style SEC16 (byte-reversed Slot 1), PIN extracted from SEC16 (bytes 14-15 as decimal),
   SEC6 derived (first 6 bytes of valid SEC16, else error if SEC16 is all-FF/all-00),
   and all validation flags. Warn if size is 8192 instead of 4096 (double-dump).
   **CRC note (Gen 2, hardware version 19 and up):** VIN checksum uses the `rfhGen2VinCs`
   algorithm (XOR all 17 raw bytes then XOR with `0x87`), reusing `crc.js:rfhGen2VinCs`.
   Gen 1 and pre-v19 Gen 2 units use `crc8rf` / CRC16 instead. The parser must apply the
   correct algorithm based on the detected generation and, within Gen 2, version 19+ boundary.

2. **PCM GPEC parser** — Implement `parsePCMGPEC(buf)` that returns: VIN current at 0x0000,
   VIN original at 0x01F0, Part Number at 0x0012 (10 bytes), Serial at 0x001C (14 bytes),
   IMMO state (4-byte pattern at 0x0011 — all-FF = IMMO_DAMAGED, 0x80 = ENABLED,
   0x00 = DISABLED, else UNKNOWN), SEC6 raw at 0x03C8 (6 bytes), and write-check
   (need = 0x03CE, buf = file length).

3. **Compatibility engine** — After both files are parsed, compute: VIN-equal-before
   (RFH VIN === PCM current VIN), SEC6-equal-before (derived SEC6 === PCM SEC6), overall
   verdict (COMPATIBLE if RFH SEC16 valid + VIN present; LOCKED with reasons otherwise),
   issues list, and info notes. Expose `canApply` boolean.

4. **RFH → PCM Tab UI** — Build `RFHPCMTab.jsx` with:
   - Two `FileDropZone` inputs (RFH and PCM)
   - RFH detail card (gen badge, VIN row, PN, Serial, SEC16 slots table, SEC6 derived)
   - PCM detail card (VIN current/original, PN, Serial, IMMO badge, SEC6, write-check)
   - Compatibility status card (verdict badge, reason, issues, info, comparison table)
   - APPLY button (disabled when `!canApply`); on click, patch PCM in-memory
   - DOWNLOAD button; exports patched PCM as binary

5. **Register the tab** — Add "RFH → PCM" to the tab list in `App.jsx` alongside the
   existing tabs. No other tabs are modified.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/fileUtils.js`
- `artifacts/srt-lab/src/lib/crc.js`
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
