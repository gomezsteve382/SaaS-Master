---
title: Four-Attempt Per-Module Scan Strategy
---
---
title: Four-Attempt Per-Module Scan Strategy
---
# Four-Attempt Per-Module Scan Strategy

## What & Why
Replace the Phase 1 / Phase 2 broadcast scan (Task #19) with a more robust
four-attempt per-module approach. The new strategy tries progressively different
addressing methods for each known module, handles WK2 bench offset variants,
and keeps ATCRA filtered per-module to prevent cross-talk during functional
broadcast attempts.

## Reference Implementation
`attached_assets/App_1776050563521.jsx` lines 858–913

## Changes

### 1. Replace scan() in OBDTab (only change needed)

New strategy iterates MODS and for each module tries:

**Attempt 1 — Physical addressing:**
- Set `ATCRA` to module's RX (filter for this module only)
- Set `ATSH` to module's TX
- Send `3E00`, 3000ms timeout
- Match: `/[0-9A-Fa-f]{3}\s/` present in response and no NO DATA/ERROR
- Log: `m.c + ' alive (physical ' + m.tx.toString(16).toUpperCase() + ')'`

**Attempt 2 — Functional broadcast with RX filter still set:**
- Keep `ATCRA` on module's RX (prevents cross-talk from other modules)
- Switch `ATSH7DF`
- Send `3E00`, 3000ms
- Log: `m.c + ' alive (functional 7DF → ' + m.rx.toString(16).toUpperCase() + ')'`

**Attempt 3 — Alternate offset addressing (WK2 bench variant):**
- Only runs if module TX is NOT in 7Exx range (i.e. `m.tx >= 0x7E0` skips)
- altTx = m.tx + 0x10, altRx = m.rx + 0x10
- Set ATCRA to altRx, ATSH to altTx, send 3E00, 3000ms
- Log: `m.c + ' alive (alt ' + altTx.toString(16).toUpperCase() + '/' + altRx.toString(16).toUpperCase() + ')'`

**Attempt 4 — DiagnosticSessionControl fallback:**
- Reset ATCRA to m.rx, ATSH to m.tx
- Send `1001`, 3000ms
- Log: `m.c + ' alive (DiagSession)'`

**If alive:** read VIN via `uds(m.tx, m.rx, [0x22,0xF1,0x90])` — same as before
**If not alive:** log `m.c + ': no response (all methods)'`

Scan header logs:
- `=== SCANNING ALL MODULES ===`
- `Strategy: functional broadcast 0x7DF + physical addressing per module`

Scan footer: `=== Scan complete ===`

### 2. canMonitor() — NO CHANGE
Keep existing canMonitor as-is (it already has improvements beyond the new file:
try/catch/finally for safe busy reset, and per-ID "unknown" logging).

## Done Looks Like
- Each module is tried with all 4 methods before being declared absent
- Bench modules using offset addressing are discovered automatically
- Modules that only respond to functional broadcast (with RX filter) still found
- All 4 fallback attempts log distinctly so user can see which method worked
- canMonitor unchanged from Task #19 final version

## Relevant Files
- `artifacts/srt-lab/src/App.jsx` — scan function only (~lines 861–938)