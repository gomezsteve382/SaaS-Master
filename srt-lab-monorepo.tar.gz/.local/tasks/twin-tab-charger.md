# TWIN Tab — BCM ↔ PCM Twinning (2017 Dodge Charger)

## What & Why
Create a **TWIN** tab (`artifacts/srt-lab/src/tabs/TwinTab.jsx`) implementing
the BCM → PCM synchronization workflow for the 2017 Dodge Charger:
MPC5606B/MPC5605B BCM (65536-byte full flash) + GPEC2A PCM (4096 or 8192-byte
EPROM dump). Wire into `App.jsx` as tab id `twin`. The modules are paired by
extracting the BCM SEC16, reversing it to RFH byte order, and writing the first
6 bytes (SEC6) into the PCM at offset 0x3C8.

## Done looks like
- TWIN tab appears in the nav bar (after IMMOVIN, before SWARM).
- Three working sections: INSPECT → Inspection Result → Comparison → Actions.
- Upload zone accepts BCM (MPC5606B/MPC5605B, 65536 bytes) and PCM (GPEC2A,
  4096 or 8192 bytes). "Inspect BCM / PCM" button triggers parsing.
  "Clean / Reset" clears both uploads.
- **BCM card (MPC5606B_05B)** after Inspect:
  - Header: chip label (e.g. `MPC5606B_05B`), file size in bytes
  - VIN section: "VIN detected: `<value>`" — 4 copies listed:
    `VIN 1 – CS OK (offset 4872)`, `VIN 2 – CS OK (offset 4904)`,
    `VIN 3 – CS OK (offset 4936)`, `VIN 4 – CS OK (offset 4968)`.
    CS FAIL shown when CRC16 mismatch.
  - SEC16 main section:
    - `SEC16 BCM:` — 16 bytes in BCM byte order (or blank / warning when
      not found)
    - `SEC16 RFH format:` — same key reversed
    - `SEC6 derived for PCM:` — first 6 bytes of RFH format (or `–` when
      not found, plus "No valid SEC16 detected" warning)
  - SEC16 mirrors section: lists each mirror copy with its offset, or
    "No SEC16 mirrors were detected."
  - Main issues count.
- **PCM card (GPEC2A)** after Inspect:
  - Header: chip label (`GPEC`), file size in bytes
  - IMMO badge: `IMMO_SANO` / `IMMO_DAMAGED` / `IMMO_DISABLED` / `UNKNOWN`
  - VIN: `Current VIN: <value>`, `Original VIN: <value>`
  - Security: `Pattern: <4 bytes hex>`
  - `SEC6 (PCM): <6 bytes hex>`
  - Additional information: `OS: <value>`, `PN: <value>`, `Serial: <value>`
- **Comparison table** (shown after both cards parsed):
  - Overall status badge: `⛔ NOT READY` or `✅ READY`
  - VIN row: BCM VIN vs PCM current VIN → OK / MISMATCH
  - Original VIN row: BCM VIN vs PCM original VIN → OK / MISMATCH
  - SEC6 row: BCM-derived SEC6 vs PCM current SEC6 → OK / MISMATCH
- **Actions (APPLY)** section:
  - Button "Import data from BCM → to PCM (download modified PCM)":
    disabled when SEC16 was not found in BCM; otherwise always clickable
    (user may intentionally twin mismatched VINs). On click, writes derived
    SEC6 into PCM buffer at 0x3C8 and triggers download as
    `<pcm_filename>_TWINNED.bin`.
  - Button "Re-filter / reload files" — clears both uploads and results.
- Build passes: `PORT=3000 BASE_PATH=/srt-lab pnpm run build` inside
  `artifacts/srt-lab/`.

## Out of scope
- OBD/bench write-back — file-only workflow
- RFH (24C32) parsing — BCM full-flash only
- Modifying ImmoVINTab, SecurityTab, or RFH→PCM tab

## Tasks

1. **MPC5606B BCM parser** — Implement `parseMPC5606(data, filename)` local
   to TwinTab (not added to parseModule.js). VINs: four copies at confirmed
   real-world offsets 4872 / 4904 / 4936 / 4968 (0x1308 / 0x1328 / 0x1348 /
   0x1368), each 17 VIN bytes + 2 CRC16 bytes (CRC16 over the 17 bytes). Report
   each slot: `{ slot, offset, vin, csStored, csCalc, csOk }`. Detect canonical
   VIN from the first CS-OK slot.
   SEC16 detection: scan the **entire** file for non-FF / non-00 16-byte runs
   followed by a valid 2-byte XOR-fold checksum
   (`xr = bytes.reduce(XOR); expected = (xr<<8)|xr`). Collect all valid copies
   sorted by offset. The first copy found is the "main" SEC16; subsequent copies
   are mirrors. Report per copy: `{ offset, rawHex, csStored, csCalc, csOk }`.
   Derive: `sec16RfhHex` = main reversed, `sec6Hex` = first 6 bytes of reversed,
   `sec16Count`. If no valid SEC16, return null for all three and set a warning.

2. **GPEC2A PCM parser** — Reuse existing `parseModule` from
   `../lib/parseModule.js`. Accept 4096-byte (EPROM) and 8192-byte dumps.
   Extract: IMMO status (`skimStatus`), current VIN (0x0000), original VIN
   (0x01F0), security pattern (3 bytes at 0x3C5), SEC6 (6 bytes at 0x3C8).
   For OS / PN / Serial: read from 0x0FA1 / 0x0FA6 / 0x0FB0 when within file
   bounds; skip gracefully for 4096-byte files if offset is out of range,
   falling back to reading from equivalent EPROM-layout offsets if parseable.

3. **TwinTab UI + compare + apply logic** — Build `TwinTab.jsx` with:
   - INSPECT zone: two `FileDropZone` inputs (BCM left, PCM right),
     "Inspect BCM / PCM" and "Clean / Reset" buttons.
   - Inspection Result: BCM card and PCM card as specified in Done section.
   - Comparison table: VIN current, VIN original, SEC6 rows with OK/MISMATCH
     badges; overall `⛔ NOT READY` / `✅ READY` badge.
   - Actions: APPLY download button (disabled when no SEC16 found), re-filter
     button. APPLY copies PCM buffer, writes 6 bytes at 0x3C8, downloads
     `<pcm_filename>_TWINNED.bin`.
   - Use `../lib/ui.jsx` (Card, Tag, Btn) and `../lib/constants.js` tokens.

4. **Register tab in App.jsx** — Add `{id:'twin', i:'🔗', l:'TWIN', s:'BCM→PCM Match'}`
   to the TABS array after `immovin`, import TwinTab, add render case. Touch
   nothing else.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/ui.jsx`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx`
