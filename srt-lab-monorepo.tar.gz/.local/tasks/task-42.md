---
title: Rename SKIM key grid labels to include platform context
---
---
  title: Rename SKIM key grid labels to include platform context
  ---
  # Rename SKIM key grid labels to include platform context

  ## What & Why
  The SKIM key grid currently shows headings like "Trackhawk — 0x2000", which
  users read as a vehicle identification. "Trackhawk" is just the label for
  the 0x2000 SKIM memory region — Jeep Grand Cherokee / Trackhawk BCMs use
  that address as their primary SKIM key table. Renaming to "JGC / Trackhawk"
  and "SRT / Charger" makes it clear these are platform labels, not detected
  vehicle names.

  ## Done looks like
  - SKIM key grid heading reads: "JGC / Trackhawk — 0x2000"
  - SKIM key grid heading reads: "SRT / Charger — 0x40C0"
  - Copy-to-clipboard text uses the new labels

  ## Tasks
  1. `artifacts/srt-lab/src/lib/constants.js` line 1:
     `{v:'Trackhawk',...}` → `{v:'JGC / Trackhawk',...}`
     `{v:'SRT',...}` → `{v:'SRT / Charger',...}`
  2. `artifacts/srt-lab/src/App.jsx` line 40 (duplicate definition):
     Apply the same rename.
  3. Rebuild and restart the workflow.