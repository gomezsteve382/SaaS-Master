# Add FCA Module Analyzer Tab

## What & Why
Integrate the attached FCA Module Security Analyzer component into SRT Lab as a new top-level tab. The component should be inserted as-is — no changes to its functionality, layout, or styling.

## Done looks like
- A new tab appears in the SRT Lab tab bar (e.g. "ANALYZER" or similar label with an icon, matching the existing tab style)
- Clicking it shows the full FCA Module Security Analyzer with its own internal sub-tabs (overview, security, diff, tools)
- All existing functionality of the analyzer works: file loading, module detection (GPEC2A/RFHUB/BCM), cross-validation, hex diff, VIN writer, SKIM toggle, virginize, key extraction, and download
- No changes to any existing tabs or features

## Out of scope
- Modifying the analyzer's logic, UI, or styling
- Changing existing tabs or app structure beyond adding this new entry

## Tasks
1. Copy the attached file (`attached_assets/fca_module_analyzer_1776013402484.jsx`) into the SRT Lab source as a new component file (e.g. `FcaAnalyzerTab.jsx`). Rename the default export from `App` to a tab component name (e.g. `FcaAnalyzerTab`). Remove the outer full-page wrapper (the component's own `minHeight: 100vh` background and header) so it fits as a tab panel inside the existing app shell — keep only the internal sub-tabs bar and content area. All internal logic and helper functions/components stay exactly as they are.
2. Add a new entry to the `TABS` array in `App.jsx` (e.g. `{ id: 'analyzer', i: '🔬', l: 'ANALYZER', s: 'GPEC · RFHUB · BCM' }`) and add the corresponding conditional render (`{pg === 'analyzer' && <FcaAnalyzerTab />}`) alongside the other tab renders.

## Relevant files
- `attached_assets/fca_module_analyzer_1776013402484.jsx`
- `artifacts/srt-lab/src/App.jsx:210,213,223-235`
