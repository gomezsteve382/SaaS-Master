# Write→parse round-trip tests

## What & Why
The CRC, parser, and VIN-write helpers have unit-style tests for individual pieces (XTEA vectors, sample fixtures) but no property-style "patch with random valid VIN, re-parse, assert all VIN slots and CRCs round-trip" coverage. That's the exact class of test that catches a silent regression when one of the three forks of `patchFile`/`writeModuleVIN` is consolidated, or when an offset constant is moved.

## Done looks like
- A new `__tests__/roundtrip.test.mjs` runs, for each module type (`BCM`, `RFHUB` Gen1 + Gen2, `GPEC2A`, `95640`, `PCM`):
  - Build a virgin fixture for that type (using `lib/__fixtures__/buildFixtures.js`).
  - For each of N=100 random valid VINs, call the canonical write helper, then `analyzeFile`/`parseModule`, then assert: (a) every expected VIN slot reads back identical, (b) every CRC reports `crcOk: true`, (c) no extra slots appeared, (d) check-digit validation passes.
- A second pass runs `virginizeFile` on the same fixture and asserts: zero VINs detected, IMMO records cleared (for BCM), key region cleared (for RFHUB/95640).
- A third pass for BCM specifically asserts the IMMO backup at `0x2000` is byte-identical to `0x40C0` after a write.
- Tests run as part of the existing `srt-lab-test` workflow.

## Out of scope
- Fuzzing invalid VINs or random byte buffers (not what these helpers are for).
- Testing the live UDS path; this is pure file-buffer round-trip.

## Steps
1. Add a small VIN generator: pick a random WMI from a known list, random VDS/VIS from `[A-HJ-NPR-Z0-9]`, compute the correct check digit at position 9, return a `Vin17`.
2. Extend `lib/__fixtures__/buildFixtures.js` with `makeRfhubGen1()`, `makeRfhubGen2()`, `makeGpec2a()`, `make95640()`, `makePcm()` if any are missing — they should produce virgin (all-FF) fixtures of the right size.
3. Write `__tests__/roundtrip.test.mjs` using `node:test` to mirror the existing test style. Iterate module types × 100 VINs.
4. Confirm the suite runs in <5s; if slow, drop to N=25 per type.

## Relevant files
- `artifacts/srt-lab/src/lib/__fixtures__/buildFixtures.js`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/fileUtils.js`
- `artifacts/srt-lab/src/__tests__/algos.xtea.test.mjs`
- `artifacts/srt-lab/src/lib/__tests__/parseModule.test.js`
- `artifacts/srt-lab/src/lib/constants.js`
