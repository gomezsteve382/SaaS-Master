# AlfaOBD Database Codegen

## What & Why
The drop includes a 66 MB decrypted SQLite database recovered from AlfaOBD.exe
containing 19 tables of FCA/Stellantis ground truth: `Faults`, `Diag_names`,
`STATES`, `Units`, plus six CAN/CGW config tables (`CAN_DELPHI_500_CONFIG`,
`CAN_DELPHI_RAM_CONFIG`, `CAN_MARELLI_CONFIG`, `FCM_CGW_CONFIG`,
`TIPM_CGW_CONFIG`, `BODY_PN_CONFIG`). This data is the source of truth for
two follow-on tasks (DTC translation, CGW config decoding) and we need a
clean way to ship a small, English-only slice of it into the React bundle.

The app already follows the build-time codegen pattern (see
`scripts/generate-quickref-data.mjs` → `src/lib/quickRefData.generated.js`),
so we extend that pattern with a new `extract-alfaobd.mjs` script that emits
a generated module the rest of the app can import.

## Done looks like
- `pnpm --filter @workspace/srt-lab run codegen` (or a dedicated
  `codegen:alfaobd` script) runs the extractor and writes
  `src/lib/alfaobdData.generated.js` exporting:
  - `FAULTS_BY_HEX` — `{ "P0123": { desc, category }, ... }` English only
  - `DIAG_NAMES` — `{ id: "EN name", ... }`
  - `STATES` — `{ id: "label", ... }`
  - `UNITS` — `{ id: "unit", ... }`
  - `CAN_CONFIG` — namespaced object with the six config tables, each
    entry `{ request, bit, length, setting, options[] }`
- The generated file is committed (so the app builds without the .db
  present), and the build script is idempotent: re-running it on a fresh
  checkout reproduces a byte-identical output.
- Generated module size stays under 500 KB gzipped (English-only filter
  + numeric/short-string column pruning is what gets us there). If the
  raw extract overflows that ceiling, the script logs a warning so it's
  visible during regen.
- A small README at `scripts/README.md` (alongside the flyer entry)
  documents prerequisites, the regen command, and where the source
  `.db` and 1024-byte XOR key live in `attached_assets/`.
- A `__tests__/alfaobdData.test.mjs` smoke test asserts the generated
  module loads, has > 1000 fault entries, and a hand-picked DTC
  (e.g. `P0301`) resolves to the expected text.

## Out of scope
- Wiring the data into any UI surface — that's tasks #T3 (DTCs) and
  #T4 (CGW config). This task just stages the data layer.
- Multi-language fault descriptions. Strip to EN only to keep bundle
  size sane; the .db has 9 columns per fault.
- Re-decrypting the source `.db` from the encrypted AlfaOBD original —
  we already have the decrypted output and the XOR key for posterity.

## Steps
1. **Stage the source data.** Confirm the decrypted `.db`, the 1024-byte
   XOR key, and the decrypt helper script are in `attached_assets/` and
   add a short note to `scripts/README.md` explaining what each one is.

2. **Add the extractor script.** Build `scripts/extract-alfaobd.mjs`
   that opens the SQLite file via a dev-only dependency (better-sqlite3
   preferred — small native dep, no WASM loading at build time), pulls
   the seven tables listed above, applies the EN-only / column-prune
   filter, sorts deterministically, and emits the generated JS module.

3. **Wire the codegen into pnpm.** Add a `codegen:alfaobd` script to
   `artifacts/srt-lab/package.json` (and fold it into the existing
   `codegen` script if there is one). The generated file goes under
   `src/lib/` next to `quickRefData.generated.js`.

4. **Tests.** Add a node:test smoke test that imports the generated
   module, asserts row counts in expected ranges, and resolves a few
   pinned hex codes / unit ids to known strings.

5. **Documentation.** Update `replit.md` with a one-liner pointing at
   `scripts/README.md` for AlfaOBD data regen, mirroring the flyer
   entry added in Task #140.

## Critical constraints
- The .db file is 66 MB and must NEVER be imported directly into the
  React bundle. Treat it strictly as a build-time input.
- Generated output must be committed (the app cannot depend on the
  presence of the .db at build time of every install).
- Pin the better-sqlite3 (or alternative) version in
  `artifacts/srt-lab/package.json` devDependencies, not the workspace
  root, so it stays scoped to the codegen surface.

## Relevant files
- `attached_assets/alfao_bd.decrypted_1776573163349.db`
- `attached_assets/alfao_bd.xor_key_1776573163350.bin`
- `attached_assets/alfao_bd.analysis_1776573163349.txt`
- `attached_assets/decrypt_alfaobd_1776573163348.py`
- `artifacts/srt-lab/scripts/generate-quickref-data.mjs`
- `artifacts/srt-lab/src/lib/quickRefData.generated.js`
- `artifacts/srt-lab/package.json`
- `scripts/README.md`
- `replit.md`
