# Reformat srt-lab lib/

## What & Why
Most files in `artifacts/srt-lab/src/lib/` are written as one-line crammed JS — `fileUtils.js` line 36 is ~2000 chars, `parseModule.js` and `crc.js` are similarly packed. Stack traces pointing into those files are useless and code review is impossible. A one-shot prettier pass makes every subsequent refactor sane.

## Done looks like
- Every file under `artifacts/srt-lab/src/lib/` (and `src/lib/__fixtures__/`, `src/lib/__tests__/`) is formatted with prettier at a normal print width (100 or so). Multi-statement single lines are gone.
- A `.prettierrc` (or equivalent config) exists at the workspace root or under `artifacts/srt-lab/` so future edits stay formatted.
- All existing `srt-lab-test` tests pass after the reformat — this should be a pure-whitespace change, no behavioural diff.

## Out of scope
- Reformatting `tabs/`, `components/`, or `App.jsx` (separate concern; those are mostly readable already).
- Renaming variables, splitting functions, changing logic.
- Adding ESLint or other tooling beyond prettier.

## Steps
1. Add prettier as a devDependency at the srt-lab artifact (or workspace) level if not already present. Pick a config: `printWidth: 100`, `singleQuote: false`, `semi: true`, `trailingComma: "es5"` to match the existing house style.
2. Run prettier over `artifacts/srt-lab/src/lib/**/*.{js,jsx}` and `artifacts/srt-lab/src/lib/__tests__/**` and `artifacts/srt-lab/src/lib/__fixtures__/**`.
3. Verify the diff is whitespace-only by spot-checking a couple files (`git diff --word-diff-regex='[^[:space:]]'` should show no token changes).
4. Run `pnpm --filter @workspace/srt-lab test` and confirm all tests still pass.

## Relevant files
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/fileUtils.js`
- `artifacts/srt-lab/src/lib/crc.js`
- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/lib/bridgeEngine.js`
- `artifacts/srt-lab/src/lib/audit.js`
- `artifacts/srt-lab/src/lib/obdEngine.js`
- `artifacts/srt-lab/src/lib/rfhPcmPair.js`
- `artifacts/srt-lab/src/lib/jailbreakFeatures.js`
- `artifacts/srt-lab/src/lib/tabReferences.js`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/lib/mods.js`
- `artifacts/srt-lab/src/lib/ui.jsx`
- `artifacts/srt-lab/src/lib/__fixtures__/buildFixtures.js`
- `artifacts/srt-lab/src/lib/__tests__/parseModule.test.js`
