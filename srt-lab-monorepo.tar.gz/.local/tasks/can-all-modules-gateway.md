# CAN Multi-Address Scan — All Modules

## What & Why
Right now only ECM responds reliably. Two things are needed: (1) update the existing MODS array to have multiple address variants per module so the scan tries each known address until one responds; and (2) add a new SWARM tab with a full 5-agent diagnostic scanner that attacks the bus from every angle simultaneously — passive monitor, functional broadcast, exhaustive address sweep, protocol shifter, and raw brute-force sweep. The SWARM tab is the heavy-duty diagnostic tool when the regular scan misses modules.

Two reference implementations have been provided:
- **MODS restructure**: `attached_assets/Pasted-import-React-useState-useCallback-useMemo-useRef-from-r_1776060507584.txt` (lines 44–62) — 17-module multi-address MODS array
- **Swarm component**: `attached_assets/Pasted-import-useState-useCallback-useRef-useEffect-from-react_1776060676667.txt` — full `OBDSwarmDiagnostic` React component with 5 agents, must be integrated as-written

## Done looks like
- **MODS array updated**: the existing single-address MODS is replaced with the 17-entry multi-address version; the scan loop tries each address variant in sequence and records which one responded
- **New SWARM tab** appears in the SRT Lab tab bar (e.g., `🐝 SWARM`, subtitle "5-Agent CAN Scan"), styled to match the existing tab bar
- The SWARM tab renders the full `OBDSwarmDiagnostic` component — Connect button, 5-agent launch, live color-coded log panel, found-modules table
- Agent 1 (BUS SCOUT): passive `ATMA` monitor reporting all active CAN IDs
- Agent 2 (BROADCAST HUNTER): `7DF` functional broadcast `22 F1 90` + TesterPresent to find all responders
- Agent 3 (ADDRESS SWEEPER): iterates all 50+ unique addresses from `UNIQUE_ADDRS` (CDA6 + CLAUDE + DarkVIN + SWARM + PowerNet sources), attempts `10 03` + `22 F1 90` on each
- Agent 4 (PROTOCOL SHIFTER): tries SP5/SP6/SP7 protocol variants and verifies adapter PP mode
- Agent 5 (BRUTE): raw sweep of 0x600–0x7FF address range
- PP extended mode (`ATPP2CSV81` / `ATPP2CON`) is enabled on STN adapters before the swarm launches, with a visible "MFG extended mode ACTIVE" status badge
- All found modules appear in the Found Modules table with TX/RX addresses, source database tag, and VIN if read successfully
- IHS fast-fail: when `STP61` returns `CAN ERROR` the direct IHS path is immediately abandoned (no timeout wait); the swarm address sweep takes over
- The existing LIVE OBD tab is unchanged except for the MODS array update

## Out of scope
- Bench tab changes
- DUMPS, SECURITY, SEED, GPEC tabs
- Physical dual-bus adapters (STN2120, J2534)
- Modifying the swarm component's internal logic beyond what's needed to render it inside the SRT Lab tab system

## Tasks
1. **Replace MODS array** — swap the existing single-address MODS array in `App.jsx` for the exact 17-entry multi-address version from the first reference file. Update the scan loop in the LIVE OBD tab to iterate `mod.addrs[]` and record the winning address per module.
2. **Extract swarm component** — copy the `OBDSwarmDiagnostic` component from the second reference file into `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx` (or `.tsx`); resolve any import issues and ensure it compiles.
3. **Add SWARM tab** — add a new tab entry to the `TABS` array in `App.jsx` and render `<OBDSwarmDiagnostic />` when it is active; match the tab bar icon/label style.
4. **IHS fast-fail in LIVE OBD** — detect `CAN ERROR` immediately after `STP61` and short-circuit the direct IHS scan path without waiting for per-address timeouts.
5. **Verify build** — confirm `vite build` passes with no errors and both the updated LIVE OBD scan and the new SWARM tab work at runtime.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:16,310,1060-1110`
- `attached_assets/Pasted-import-React-useState-useCallback-useMemo-useRef-from-r_1776060507584.txt:44-62`
- `attached_assets/Pasted-import-useState-useCallback-useRef-useEffect-from-react_1776060676667.txt`
