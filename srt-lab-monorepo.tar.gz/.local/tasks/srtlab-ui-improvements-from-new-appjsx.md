# SRT Lab UI Improvements (from new App.jsx)

## What & Why
The attached `App.jsx` is a newer, richer version of the SRT Lab UI. It introduces an integrated **FCA Analyzer** tab, an enhanced module parser with many more byte-level fields (transponder keys, ZZZZ tamper marker, runtime counters, vehicle secret, fobik slots, security markers, part numbers), VIN-year → SGW awareness, and an immo-backup sync helper. This task brings those improvements into the current SRT Lab without losing the work already done in the existing tab/lib structure.

## Done looks like
- A new **FCA Analyzer** tab is available in the app (component lifted from the attached `FcaAnalyzerTab` import) that lets the user drop in any module dump and see a unified parse result.
- `lib/parseModule.js` returns the additional fields the new parser exposes:
  - **GPEC2A:** secret key + mirror with `keyConsistent` flag, `transponderKeys[0..3]`, `zzzzTamper` block at `0x0c8c`, `partNumberStr`, `runtimeCounters` (counterA, counterB, distance, keyCycles).
  - **RFHUB:** known-offset VIN list with mirrored-VIN fallback and per-VIN `crcOk`, `vehicleSecret` at `0x050e..0x051e`, `fobikSlots`, `securityMarkers`, `zzzzBlocks`, and structured `partNumbers.{hw,sw,cal}`.
  - **BCM:** primary VINs at `0x5320/40/60/80` and a `partialVins` array for partial matches.
- VIN helpers gain `parseVinYear(vin)` and `vinHasSGW(vin)` (used by the AUTEL SGW task too — coordinate so only one definition exists).
- `syncImmoBackup(data)` is exposed as a helper and surfaced in the GPEC2A / ImmoVIN tab as a "Sync immo primary ↔ backup" action that mirrors `0x40C0` block down to `0x2000`.
- Per-tab views (BCM, RFHUB, GPEC2A) render the new fields where they're meaningful (transponder key list, ZZZZ tamper indicator, runtime counter readouts, fobik slot count, security/tamper markers, structured part numbers).
- Existing functionality (ImmoVIN, Twin, Jailbreak, ProgramAll, Sessions, snapshots) is unchanged.

## Out of scope
- The J2534 bridge / AUTEL SGW tab (covered by the sibling task).
- Wholesale replacement of the current tab structure with the single-file App.jsx from the attachment — we cherry-pick the parser/UI improvements, keep our modular tabs.
- Writing back any of the new fields. Read/display only.

## Tasks
1. Extend `lib/parseModule.js` to return the new GPEC2A, RFHUB, and BCM fields described above. Keep existing field names backward-compatible; add new ones alongside.
2. Add `parseVinYear` and `vinHasSGW` to the VIN helpers (single source of truth shared with the AUTEL SGW task).
3. Add `syncImmoBackup(data)` helper and an `IMMO_REC` / `IMMO_KC` / `IMMO_BLOCK` constants block; expose a small "Sync primary ↔ backup" action in the GPEC2A / ImmoVIN flow with confirm + snapshot before write.
4. Port the `FcaAnalyzerTab` component from the attachment into `tabs/FcaAnalyzerTab.jsx`, adapt imports to use our `lib/parseModule.js` and existing UI primitives, and register it in the main tab list.
5. Update `BcmTab.jsx`, `RfhubTab.jsx`, and `Gpec2aTab.jsx` to render the new fields (transponder keys, ZZZZ tamper, runtime counters, fobik slots, security markers, structured part numbers, vehicle secret hex).
6. Add lightweight unit-style fixtures or sample dumps under `scripts/` or `src/lib/__fixtures__/` so the new parser fields are exercised against known inputs.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/tabs/BcmTab.jsx`
- `artifacts/srt-lab/src/tabs/RfhubTab.jsx`
- `artifacts/srt-lab/src/tabs/Gpec2aTab.jsx`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
- `artifacts/srt-lab/src/tabs/DumpsTab.jsx`
