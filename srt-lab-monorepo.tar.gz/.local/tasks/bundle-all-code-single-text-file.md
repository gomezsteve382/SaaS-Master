# Bundle All Code Into Single Text File

## What & Why
The user can't get Replit's Download-as-zip to work in their browser, so they need an alternate way to grab the entire project. Build a single concatenated text file containing every source file in the project so they can open or download it directly from the file pane.

## Done looks like
- A new file `srt-lab-all-code.txt` exists at the project root.
- It contains the contents of every tracked source file in the project, in a deterministic order (alphabetical by path).
- Each file's section is preceded by a clear header line showing its relative path, e.g.:
  ```
  ===== artifacts/srt-lab/src/App.jsx =====
  ```
  followed by the raw file contents, then a blank line.
- The bundle includes: everything under `artifacts/`, `lib/`, `scripts/`, and root-level config files (`package.json`, `pnpm-workspace.yaml`, `tsconfig*.json`, `.replit`, `replit.md`, `.gitignore`, `.replitignore`, `.npmrc`).
- The bundle EXCLUDES: `node_modules/`, `.git/`, `.cache/`, `.config/`, `.local/`, `.agents/`, `attached_assets/`, `pnpm-lock.yaml`, any binary files (firmware blobs, images, dumps, `.bin`, `.hex`, `.dflash`, `.png`, `.jpg`, `.ico`, `.pdf`, `.zip`).
- A short header at the very top of the file lists generation timestamp, total file count, and total byte count.
- The user can open it in the file pane and use the editor's built-in download / copy-all to get it onto their machine.

## Out of scope
- Zipping or compressing the bundle.
- Uploading the bundle anywhere external.
- Including dependency source (`node_modules`) or lockfiles.
- Any code changes to the app itself.

## Steps
1. Write a small Node script under `scripts/` that walks the project, applies the include/exclude rules above, skips files detected as binary (null-byte sniff or known binary extension), and writes the concatenated output to `srt-lab-all-code.txt` at the project root.
2. Run the script once and verify the output file is reasonable in size (expect a few MB of text), the header counts look right, and a handful of spot-checked files appear in full.
3. Tell the user the file is ready at `srt-lab-all-code.txt` and explain how to open it from the file pane and copy/save it locally.

## Relevant files
- `package.json`
- `pnpm-workspace.yaml`
- `scripts`
- `artifacts/srt-lab`
- `artifacts/api-server`
- `artifacts/mockup-sandbox`
- `lib`
