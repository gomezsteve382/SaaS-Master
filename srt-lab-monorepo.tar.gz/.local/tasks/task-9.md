---
title: BCM IMMO Backup Sync & Display Fix
---
# BCM IMMO Backup Sync & Display Fix

  ## What & Why
  The BCM IMMO display has two issues:
  1. **Misaligned comparison**: The "Backup MISMATCH" message compares bytes at 0x40C8-0x40DA (primary) vs 0x40F0-0x4102 (backup), but these are actually portions of different 24-byte SKIM key records in a contiguous table — not a primary/backup pair. The real SKIM table at 0x40C0 contains multiple 24-byte key records and is not internally redundant.
  2. **No backup sync**: The backup region at 0x2000 (Trackhawk-variant SKIM table) is blank. During VIN patching, users want the option to copy the SKIM key table from 0x40C0 to 0x2000 so both regions are populated.

  The SKIM key table at 0x40C0 consists of 24-byte records: 8-byte header + 8-byte data + 8-byte key data. In the user's BCM, 8 records exist (0x40C0-0x417F). The backup at 0x2000 is a separate Trackhawk-specific copy (same 24-byte record format, 6+ slots).

  ## Done looks like
  - The DUMPS and SECURITY tabs no longer show "Backup MISMATCH" for the IMMO region when records are different (they're separate key entries, not a redundant backup)
  - The IMMO display shows the correct SKIM key record count and status for both the 0x40C0 primary table and the 0x2000 backup table
  - A "Sync Backup" button is available in the DUMPS, BENCH, and SECURITY Tools tabs that copies the 0x40C0 SKIM key data to 0x2000 when patching a BCM
  - After sync, the Backup @0x2000 shows "SET" instead of "BLANK"

  ## Out of scope
  - Modifying individual SKIM key records
  - Changing CRC algorithms (already fixed)
  - Changes to non-BCM module types

  ## Tasks
  1. Fix the IMMO primary/backup comparison in both `secAnalyze` (the enhanced parser) and `analyzeFile` (the DUMPS/BENCH parser) — remove the misleading 0x40C8-vs-0x40F0 cross-record comparison and instead count 24-byte SKIM records at 0x40C0 and report how many are populated.
  2. Update the IMMO backup display to show 0x2000 table status (BLANK vs SET with record count) rather than comparing against the 0x40C0 table.
  3. Add a "Sync IMMO Backup" action to the BCM VIN patch flow (in `patchFile`, `writeModuleVIN`, and the Security Tools tab) that copies the full SKIM key block from 0x40C0 to 0x2000 during patching.
  4. Add a standalone "Sync IMMO Backup" button in the DUMPS tab's BCM card and the SECURITY Tools tab so users can sync without patching VINs.

  ## Relevant files
  `artifacts/srt-lab/src/App.jsx:85-96`
  `artifacts/srt-lab/src/App.jsx:165-170`
  `artifacts/srt-lab/src/App.jsx:173-183`
  `artifacts/srt-lab/src/App.jsx:185-213`
  `artifacts/srt-lab/src/App.jsx:640-690`
  `artifacts/srt-lab/src/App.jsx:1005-1020`