# Add send() Timeout Diagnostic Logging

## What & Why
The OBD `send()` function silently discards adapter responses when the `>` prompt isn't detected within the timeout. This makes it impossible to diagnose why modules aren't being found — we can't tell if the adapter is sending garbage (wrong baud), valid data without `>` (prompt detection issue), or nothing at all (no communication). One diagnostic log line on timeout will reveal the root cause.

## Done looks like
- When any AT/UDS command times out, the log panel shows a warning with whatever data the adapter DID send (e.g. "RX (timeout) < ELM327 v1.5" or "RX (timeout) < OK" or empty)
- No other behavior changes — prompt detection, init sequence, and scan logic remain identical
- Connection still shows "Ready" regardless of timeout (existing behavior preserved)

## Out of scope
- Changing prompt detection logic
- Changing timeouts or init sequence
- Any other modifications to connect/send/uds

## Tasks
1. Add one line to `send()`: after the polling loop exits on timeout, log `buf` contents as a warning before returning. Exact change: replace `return buf.trim();` with `const t=buf.trim();if(t)addLog('RX (timeout) < '+t,'warn');return t;`

## Relevant files
- `artifacts/srt-lab/src/App.jsx:823`
