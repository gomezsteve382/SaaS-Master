---
title: TWIN tab — BCM SEC16 CRC validation, write-on-sync, MIRROR CS display
---
---
  title: TWIN tab — BCM SEC16 CRC validation + write-on-sync + derived-rule label
  ---
  # BCM SEC16 CRC — read/validate/write, display MIRROR CS state

  ## Context

  The FCA SINCRO reference shows the BCM (MPC5606B_05B) DFlash stores each SEC16
  mirror with a 2-byte CRC appended immediately after the 16 data bytes:

    MIRROR 1 @ 0x00C9 — bytes [0x00C9 … 0x00D8] = 16-byte SEC16
                         bytes [0x00D9, 0x00DA] = CRC (stored)
    MIRROR 2 @ 0x00F1 — bytes [0x00F1 … 0x0100] = 16-byte SEC16
                         bytes [0x0101, 0x0102] = CRC (stored)

  FCA SINCRO shows "MIRROR 1 — CS OK" / "MIRROR 2 — CS OK".
  Our app currently:
    • only reads 16 bytes per mirror — never reads the CRC bytes
    • never validates the CRC
    • when syncing (applyBcmFromRfh) writes only 16 data bytes, leaving stale CRC bytes
      → the BCM firmware CRC check will fail on a synced file

  Assumed formula: CRC16 CCITT (0x1021, init=0xFFFF) on the 16 SEC16 bytes.
  This is the same algorithm used for BCM VIN copies and is the most common CRC in
  MPC5606B-based modules. Adjust if testing reveals a different formula.

  Also noted from reference:
    • Reference says "Total: 3" implying a 3rd "main" SEC16 copy exists at an unknown
      DFlash offset. We cannot implement it without the offset — flagged as OPEN RESEARCH.
      When a real BCM dump is available, search around 0x0040–0x00C8 for a 16-byte block
      matching the other two mirrors.
    • RFH card: add a one-line "Rule: reverse bytes of the entire block" note under the
      BCM-view hex row for clarity.

  ## Done looks like
  1. parseBcm reads bytes at off+16/off+17 for each mirror → stores csStored, csCalc,
     csOk on each sec16Copies entry.
  2. BcmCard shows "MIRROR 1 — CS OK ✓" / "MIRROR 2 — CS OK ✓" (or FAIL ✗) badges.
  3. applyBcmFromRfh writes the correct CRC16 at off+16/off+17 for each mirror after
     writing the 16 SEC16 data bytes.
  4. RfhCard shows one-line rule text: "Rule: reverse bytes of the entire block."
     beneath the "BCM view (reversed)" hex.
  5. No regressions: VIN sync, SEC6 sync, RFH←BCM direction unchanged.

  ## Implementation steps

  ### 1. TwinTab.jsx — parseBcm: read + validate CRC for each SEC16 mirror
    In the sec16Copies map at BCM_SEC16_OFFSETS, change the read to 18 bytes and add:
      const csStored = (data[off + 16] << 8) | data[off + 17];
      const csCalc   = crc16(Array.from(raw));
      const csOk     = csStored === csCalc;
    Return { ..., csStored, csCalc, csOk } for each copy.

  ### 2. TwinTab.jsx — parseBcm: add secAllCsOk flag
    Add to returned object:
      secAllCsOk: sec16Copies.every(m => m.csOk)

  ### 3. TwinTab.jsx — applyBcmFromRfh: write CRC after SEC16 bytes
    After writing the 16 data bytes at each BCM_SEC16_OFFSETS position, also write:
      const cs = crc16(bcmSec16);
      out[off + 16] = (cs >> 8) & 0xFF;
      out[off + 17] = cs & 0xFF;

  ### 4. TwinTab.jsx — BcmCard: display MIRROR CS badges
    For each sec16Copies entry, add a CsBadge based on m.csOk after the mirror label.
    Also show secAllCsOk summary tag: "All CRC OK ✓" or "CRC Errors!"

  ### 5. TwinTab.jsx — RfhCard: add rule note
    Below the "BCM view (reversed)" MonoHex, add a small text:
      Rule: reverse bytes of the entire block.

  ## Files
  - artifacts/srt-lab/src/tabs/TwinTab.jsx  (parseBcm, applyBcmFromRfh, BcmCard, RfhCard)

  ## Note
  The crc16() function already exists locally in TwinTab.jsx (lines 16-24).
  No new imports are needed.