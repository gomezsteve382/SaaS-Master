---
title: Bench Tab — benchConnect Rewrite + ADCM Address Corrections
---
# Task #21: Bench Tab — benchConnect Rewrite + ADCM Address Corrections

  ## Objective
  Apply three changes from App_2_1776052891009.jsx to artifacts/srt-lab/src/App.jsx.
  Only the BenchTab section changes — all other tabs remain untouched.

  ## Change 1: MODS array (line 16) — rename DAMP → ADCM
  Current:  {c:'DAMP',n:'Damping',tx:0x7E4,rx:0x7EC}
  Replace:  {c:'ADCM',n:'Active Damping',tx:0x7A8,rx:0x7B0}
  All 13 other MODS entries unchanged.

  ## Change 2: BenchTab benchConnect — complete rewrite (App_2 lines 330-381)
  Replace the current benchConnect useCallback with the App_2 version:

  a) send() — uses local rbuf + Promise.race([rd.read(), timeout]) loop
  b) STN detection via STDI:
       const isSTN = !stdi.includes('?') && !stdi.includes('ERROR') && stdi.length>2
  c) If isSTN: PP2C 500kbps setup before main init:
       ATPP2CSV81, ATPP2CON, ATPP2DSV01, ATPP2DON, ATZ(1500ms), delay 500ms, ATE0
  d) Common init: ATL0, ATS1, ATH1, ATSP6, ATAT2, ATST96
  e) Flow control:
       STN:  ATCAF1, STCSWM1, ATFCSH7E0, ATFCSD300000, ATFCSM1
       ELM:  ATCAF1, ATFCSM1
  f) uds() — curTx/curRx caching (skip ATSH/ATCRA if unchanged)
  g) uds() — enhanced response parser:
       - Split on \r\n; skip SEARCHING/OK
       - If first tok is 3-char hex matching rxHex → take rest; else take all
       - Error check: /NO DATA|UNABLE TO CONNECT|CAN ERROR|BUS ERROR/ || '?'/'ERROR'

  ## Change 3: BenchTab Write/Read VIN buttons
  Write VIN + Read VIN buttons (UDS Bench Tools card):
    DAMP 0x7E4/0x7EC → ADCM 0x7A8/0x7B0 (label: 'ADCM')
    IPC  0x745/0x765 → IPC  0x740/0x748
    BCM  0x742/0x762 → BCM  0x750/0x758
    ECM 0x7E0/0x7E8, TCM 0x7E1/0x7E9 — unchanged

  ## Files
  - artifacts/srt-lab/src/App.jsx (only file changed)

  ## Do NOT change
  - OBDTab (scan, canMonitor, readProxi, readSkim, OBD write buttons)
  - All other 13 MODS entries
  - SecurityTab, DumpsTab, SeedTab, GpecTab, Gpec2aTab, FcaAnalyzerTab