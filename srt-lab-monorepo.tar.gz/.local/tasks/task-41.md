---
title: Security tab: Gen2 RFH reads SEC16 from 0x050E/0x0522
---
# Security tab: Gen2 RFH SEC16 at correct offsets

## What & Why
`parseModule.js` always reads RFH SEC16 from Gen1 offsets `0x00AE` / `0x00C0`
regardless of file generation. For a Gen2 RFH (4096-byte file), the actual
SEC16 slots are at `0x050E` / `0x0522` (confirmed from binary analysis). The
bytes at `0x00AE` / `0x00C0` in a Gen2 file are unrelated data, so the Security
tab shows "SLOTS MISMATCH" and the cross-module validation fires "RFHUB SEC16:
Slot 1/2 MISMATCH or unreadable" — a false alarm that misleads the user.

The Gen2 vehicleSecret is already correctly read from `0x050E` in parseModule.js.
The `sec16s` array just needs to be populated from the right offsets depending
on generation.

## Done looks like
- Loading a Gen2 (4096-byte) RFH in the Security tab shows SEC16-1/2 from
  offsets `0x050E` / `0x0522`; "SLOTS MISMATCH" disappears when the slots match
- Loading a Gen1 (2048-byte) RFH still reads SEC16 from `0x00AE` / `0x00C0`
  as before (no regression)
- The cross-module validation no longer fires a false RFHUB SEC16 mismatch
  warning for a valid Gen2 file

## Out of scope
- Changes to TWIN tab
- Changes to the `vehicleSecret` field (already correct at `0x050E`)
- The SEC16 CS validation formula for Gen2 (separate concern)

## Tasks
1. **Branch sec16s by generation** — In `parseModule.js`, after `rfhGen` is
   determined, populate `sec16s` from `[[1, 0x050E], [2, 0x0522]]` for Gen2
   files (sz === 4096 or 8192) and keep `[[1, 0xAE], [2, 0xC0]]` for Gen1
   (sz === 2048). The CS bytes for Gen2 are at offset+16 and offset+17 (2 bytes)
   rather than offset+16..17 in Gen1 — keep the same 2-byte read, it already
   works for both.
2. **Update sec16match / sec16valid** — The existing match/valid logic
   (`arrEq(sec16s[0].raw, sec16s[1].raw) && !blank`) carries over unchanged;
   just ensure it runs after the corrected offsets are read.

## Relevant files
- `artifacts/srt-lab/src/lib/parseModule.js:108-121`
- `artifacts/srt-lab/src/lib/crossValidate.js:37`