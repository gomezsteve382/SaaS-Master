# BCM + RFHUB Programmer Tabs

## What & Why
Port the dedicated BCM and RFHUB programmer tabs from the reference `App.jsx`. These two are grouped because they share the same write pattern (CDA6-style unlock + VIN write to F190/7B90/7B88 with a CRC16-CCITT footer), and RFHUB additionally needs the VIN-specific algorithm table from `RFHUB_KNOWN_ALGOS`.

## Done looks like
- A BCM tab renders the reference layout: hero card, Test Connection, Read VIN, Write VIN (gated by the Read-First modal), CDA6 unlock, optional feature unlock toggles, in-tab log.
- An RFHUB tab renders the reference layout: hero, Test Connection, Read VIN, Write VIN (with the VIN-specific CRC algorithm picked from `RFHUB_KNOWN_ALGOS`), an experimental Key Fob Programming card (routine 0x0401–0x0404), in-tab log.
- Both tabs read the VIN from the Master VIN context and update the matching slot in the module status strip (writing → ok / fail).
- Both tabs auto-snapshot the module via the shared backup helper before any write, and append paper-trail entries.
- Both tabs use the shared `initAdapter` helper (no duplicated ATZ timing logic).

## Out of scope
- ECM, ADCM, ProgramAll, UDS, Backups, Sessions, Analyzer tabs — separate chunks.
- New CRC algorithm research — only port what is in the reference.

## Tasks
1. **Port BCM tab** — Translate the reference `BcmTab` component into `src/tabs/BcmTab.jsx`, wired to the shared context, modal, backup, paper-trail, and adapter helpers.
2. **Port RFHUB tab** — Translate the reference `RfhubTab` component into `src/tabs/RfhubTab.jsx`. Include the `RFHUB_KNOWN_ALGOS` table and the experimental Key Fob Programming section.
3. **Wire into navigation** — Replace the placeholder entries from the foundations chunk with the real components.
4. **Bench smoke run** — Build, restart workflow, walk through both tabs in disconnected mode (Test Connection should fail gracefully, status strip should update, modal should appear before write attempts).

## Relevant files
- `attached_assets/App_1776444434000.jsx`
- `artifacts/srt-lab/src/tabs/`
- `artifacts/srt-lab/src/lib/mods.js`
