---
title: Fix OBD Connect Regression
---
# Fix OBD Connect Regression

## What & Why
Task #10 added baud rate auto-detection that tries multiple baud rates by closing and reopening the serial port. This broke the OBDLink EX connection that was previously working at 115200. The retry loop (close/reopen port at different baud rates) interferes with Web Serial. The user's adapter connects fine at 115200 — the only issue was module scanning, not the connection itself.

## Done looks like
- OBDLink EX connects immediately at 115200 baud (same behavior as before Task #10)
- Baud rate dropdown is still available as a simple selector but does NOT trigger auto-retry
- All other Task #10 fixes remain: timeout logging, control-char prompt detection, CAN header stripping, PCI byte stripping, increased AT command timeouts
- Connection flow: open port at selected baud → ATZ → ATI → init AT commands → Ready

## Out of scope
- Adding new adapter support
- Changing any other scan/parse behavior

## Tasks
1. Remove the baud rate auto-detection retry loop from `connect()` — revert to single-attempt open at the selected baud rate, followed by ATZ/ATI/init sequence.
2. Keep the baud rate dropdown selector but make it purely informational (user picks rate, connect uses it once).
3. Preserve all the `send()`, `uds()`, and parser improvements from Task #10.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:815-863`