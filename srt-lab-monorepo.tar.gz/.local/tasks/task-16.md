---
title: Remove ATCRA Strict Filter — Use ATAR Instead
---
# Remove ATCRA Strict Filter — Use ATAR Instead

## What & Why
Scan finds only ECM despite 6 modules connected on bench. ATCRA sets an exact CAN receive filter that may be blocking responses from modules that respond on slightly different IDs than expected. ECM works because 0x7E8 is universally standard, but other modules (BCM, RFHUB, DAMP, IPC, RADIO) may respond on different IDs depending on the vehicle platform.

Replacing ATCRA with ATAR (auto-receive) removes the strict filter and lets the adapter accept responses from any CAN ID. Since ATH1 is already ON, response CAN IDs are included in the data, and the parser already handles stripping 3-character CAN ID headers.

## Done looks like
- LIVE OBD `uds()` uses `ATAR` instead of `ATCRA + rx hex` 
- Adapter accepts responses from any CAN ID, not just the one in the MODS list
- Response parsing unchanged (parser already strips 3-char CAN ID headers)
- ECM still works as before
- Other modules that respond on any CAN ID are now discoverable

## Changes
In LIVE OBD `uds()` (~line 830):
- Replace `await send('ATCRA'+rx.toString(16).toUpperCase().padStart(3,'0'),3000);` with `await send('ATAR',3000);`

## Out of scope
- Changing connect/send/init sequence
- Changing BENCH tab uds()
- Changing scan callback logic
- Changing response parser

## Relevant files
- `artifacts/srt-lab/src/App.jsx` — uds() at ~line 830