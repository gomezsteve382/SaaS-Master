# Migration Foundations: Shared State & Helpers

## What & Why
Lay the shared infrastructure that every later chunk of the SRT Lab migration depends on. The reference `App.jsx` introduces a Master VIN context, a pre-write confirmation modal, a paper-trail logger, an auto-backup helper, a shared adapter init helper, and several extra CRC / NRC utilities. Without these in place, the per-module programmer tabs cannot be ported.

## Done looks like
- A Master VIN input + module status strip (BCM / RFHUB / ECM / ADCM = pending / writing / ok / fail) appears in the SRT Lab top bar and persists across tab switches.
- Switching tabs no longer loses the entered VIN; programmer tabs read it from the shared context.
- A "Read First" confirmation modal (technician name + work order / RO field + confirm-typed VIN) is available app-wide and gates any UDS write call sites that opt into it.
- A paper-trail log writes to `localStorage` for every tab that calls the new logger; entries survive reload.
- A safety-backup helper snapshots a module's critical DIDs to `localStorage` before writes, with an indexed list (max 50, auto-rotating).
- A shared `initAdapter` helper (preserving the known-good ATZ 3000 ms + 1000 ms settle timing and the `cleanupPort` retry on failure) replaces ad-hoc inline init code in any newly added tab.
- Tab list is reorganized to make room for the new tabs added by later chunks (placeholder entries are acceptable so navigation already shows them, disabled if needed).
- Existing tabs continue to build and run with no regressions.

## Out of scope
- Implementing any new programmer tab body (BCM, RFHUB, ECM, ADCM, ProgramAll, UDS, Backups, Sessions, Analyzer) — those are separate chunks.
- Removing legacy tabs (Twin, ImmoVIN, etc.) — flagged for triage in the final chunk.
- Refactoring the existing OBD swarm or J2534 scanner tabs.

## Tasks
1. **Shared lib modules** — Extract the reference's helpers into `src/lib/`: `masterVinContext.jsx`, `paperTrail.js` (logSession + reader), `backups.js` (backupModule, getBackup, getBackupList), `initAdapter.js`, `nrc.js` (decodeNRC), and add `crc16ccitt` + `crc16generic` to the existing CRC module. Keep names identical to the reference for easy porting.
2. **Master VIN provider & top bar** — Wrap the app in `MasterVinContext.Provider`, render the Master VIN input + 4-module status strip in the header. State must be reachable from any tab via `useContext`.
3. **Read-First modal component** — Port `ReadFirstModal` from the reference into a shared component file; expose a hook or imperative API that programmer tabs can trigger before destructive writes.
4. **Tab list scaffolding** — Update the tab registry to add entries for `programall`, `bcm`, `rfhub`, `ecm`, `adcm`, `uds`, `backups`, `sessions`, `analyzer` in the same order the reference uses. Bodies can be lightweight "Coming in next chunk" placeholders that read the shared context, so navigation is testable now.
5. **Smoke build** — Build, restart workflow, click through every tab, confirm the VIN persists, the modal opens/closes, and a manual `logSession()` call from the console produces a visible paper-trail entry.

## Relevant files
- `attached_assets/App_1776444434000.jsx`
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/`
- `artifacts/srt-lab/src/tabs/`
