---
  title: Match FCA SINCRO SEC16 display — fix CS formula, add derived BCM hex, per-slot state
  ---
  # Match FCA SINCRO SEC16 display for Gen2 RFH

  ## What & Why
  FCA SINCRO shows a richer SEC16 section than our Security tab for Gen2 RFH files:
  1. Per-slot CS validated with the correct formula (XOR(16 raw bytes) ^ 0x8B → byte[0], 0x00 → byte[1])
  2. "Derived (RFH → BCM)": byte-reversed version of the SEC16, shown explicitly so the
     user knows what value gets written into the BCM
  3. "Slots match: YES/NO" summary line
  4. Per-slot OK/FAIL badge

  Our parseModule.js has the CS formula wrong: it computes (XOR<<8)|XOR instead of
  ((XOR^0x8B)<<8)|0x00. TwinTab.jsx has the correct formula but it's local.
  This task fixes the formula, centralises it in crc.js, and enriches the display.

  ## Done looks like
  - Loading a Gen2 RFH in Security tab shows:
    - Each SEC16 slot: raw hex + "CS OK ✓" or "CS FAIL ✗" badge
    - A "Derived (RFH → BCM): <32-char hex>" row below the slots (byte-reversed)
    - A "Slots match: YES" or "Slots match: NO" summary
  - For a TWIN-synced Gen2 RFH where both slots are correct: all badges green
  - Gen1 RFH CS behaviour unchanged (no regression — Gen1 uses different formula)

  ## Tasks
  ### 1. crc.js — export RFH SEC16 CS helper
  - Add exported constant `RFH_SEC16_CS_MAGIC = 0x8B`
  - Add exported function `rfhSec16Cs(raw16)`:
      `return ((Array.from(raw16).reduce((a,b)=>a^b,0) ^ 0x8B) << 8) | 0x00;`
    Returns the 2-byte big-endian CS value (matches how it is stored and read)

  ### 2. parseModule.js — fix SEC16 per-slot parsing
  - Import `rfhSec16Cs` from crc.js
  - In the RFHUB sec16 loop, replace the wrong csCalc line with:
    `const csCalc = rfhSec16Cs(raw);`
  - Add `csOk: cs === csCalc` to each pushed object
  - Add `bcmHex`: byte-reversed version of `raw` (16 bytes reversed → hex string, no spaces):
    `const bcmHex = Array.from(raw).reverse().map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join('');`
  - Use source_slot field: `info.sec16SourceSlot = 1` (always slot 1 as reference)
  - Update `sec16valid` to also require `sec16s[0].csOk`

  ### 3. TwinTab.jsx — import rfhSec16Cs from crc.js
  - Remove the local `RFH_SEC16_CS_MAGIC` and `rfhSec16Cs` definitions (lines ~121-131)
  - Import `rfhSec16Cs` from '../lib/crc.js'
  - Adapt the call site: TwinTab currently does `out[off+16]=cs[0];out[off+17]=cs[1];`
    Change to use the new single-return-value form:
    `const csVal=rfhSec16Cs(sec16Slot);out[off+16]=(csVal>>8)&0xFF;out[off+17]=csVal&0xFF;`

  ### 4. SecurityTab.jsx — enrich SEC16 display
  In the Overview module card, replace the sec16s row renderer with:
  - Per slot row: show offset, raw hex, CS value, CS OK ✓ / FAIL ✗ badge (from `s.csOk`)
  - Below the slots: a summary row "Slots match: YES/NO" and one "Derived (RFH → BCM): <bcmHex>"
    row using sec16s[0].bcmHex. Only shown when sec16s.length === 2 and not blank.

  ## Relevant files
  - artifacts/srt-lab/src/lib/crc.js
  - artifacts/srt-lab/src/lib/parseModule.js  (lines 116-133)
  - artifacts/srt-lab/src/tabs/TwinTab.jsx    (lines 121-131, 184)
  - artifacts/srt-lab/src/tabs/SecurityTab.jsx (line 228)
  