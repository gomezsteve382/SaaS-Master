# CGW / Body Config Decoder

## What & Why
Six of the AlfaOBD database tables describe how FCA modules pack
configuration into byte-bit-length triples for the CAN gateways and
body controller:

- `CAN_DELPHI_500_CONFIG` / `CAN_DELPHI_RAM_CONFIG` — Delphi-flavored
  CGW config (RAM 500, Ram trucks)
- `CAN_MARELLI_CONFIG` — Marelli CGW (Italian-platform vehicles)
- `FCM_CGW_CONFIG` — Front Control Module gateway settings
- `TIPM_CGW_CONFIG` — TIPM gateway settings
- `BODY_PN_CONFIG` — Body part-number-driven feature options

Each row is `{request, bit, length, setting, _0...n}` where the
numbered columns hold the option labels for each possible value of
that bitfield. With this we can present BCM / TIPM / FCM dumps and
live UDS reads as labeled feature matrices ("Auto headlamp delay:
30s", "Heated seat: present", etc.) instead of raw hex.

## Done looks like
- A new `src/lib/cgwConfig.js` module exporting per-CGW decoders:
  `decodeBcmConfig(bytes)`, `decodeFcmCgwConfig(bytes)`,
  `decodeTipmCgwConfig(bytes)`, `decodeDelphi500Config(bytes)`,
  `decodeDelphiRamConfig(bytes)`, `decodeMarelliConfig(bytes)`.
  Each returns an array of `{ setting, raw, label }` rows.
- The BCM tab gains a "Feature Matrix" panel that renders the
  decoded BodyPN/Delphi config alongside the existing hex view.
  Same panel pattern (collapsible card, JetBrains Mono for raw,
  Nunito for labels) as the rest of the BCM tab.
- The FCA Analyzer tab uses the same decoder to label config
  blocks it spots in cross-module audits.
- Round-trip safety: the decoder reads only — no encode/write path
  in this task. A `// TODO: encode path` comment marks the seam
  for the inverse helper to land later.
- Tests cover one known-good byte vector per decoder (sourced from
  the BCM / TIPM dumps already in `attached_assets/`), asserting
  three or four hand-picked features decode to the expected labels.

## Out of scope
- A write-back / patcher path. Read-only decoding only.
- Encoding of config edits into a UDS write. Future work, gated on
  someone with a real bench module to verify against.
- Live OBD live-feature live-toggle UI. The decoder is offered to
  the offline (parseModule) and analyzer flows first; live OBD
  wiring is deferred until the offline path is proven.

## Steps
1. **Pin the column order per table.** The analysis.txt show the
   CREATE statements truncated mid-column; the codegen extractor
   from Task T1 has the actual column order from the live .db.
   Document the canonical column order for the six tables in a
   header comment in `cgwConfig.js`.

2. **Build the generic decoder.** One core function takes a row
   (`{request, bit, length, _0...n}`) plus the source bytes,
   pulls the bit window, looks up the matching `_<value>` label,
   and returns the labeled row. The six per-CGW exports are
   thin wrappers over this generic core, scoped to their table.

3. **BCM Feature Matrix panel.** Add a new collapsible card to
   `BcmTab.jsx` that runs the BodyPN decoder on the loaded BCM
   bytes and renders the resulting feature list.

4. **FCA Analyzer integration.** Plug the decoder into the
   analyzer's cross-module audit so config blocks it pulls from
   any module are labeled instead of raw hex.

5. **Tests.** Add `cgwConfig.test.js` next to
   `parseModule.test.js`, drive it with at least one real BCM
   dump from `attached_assets/`, and assert that a small set
   of feature labels resolves correctly.

## Critical constraints
- This task depends on Task T1 for the `CAN_CONFIG` export shape.
  If T1 drifts on the namespacing, pull the new shape — do not
  duplicate the .db parsing logic here.
- Some CAN_CONFIG rows have placeholder/garbage labels in the
  truncated CREATE statements (e.g. `_8 TExT10`). Treat
  unrecognized columns as `null` labels and surface them as
  "(unknown value 0xNN)" in the UI rather than dropping the row.
- The `request` column in some tables is a CAN request hex
  string; in others it is a part-number prefix. Decoder must
  not assume one or the other — store as opaque string.

## Relevant files
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/__tests__/parseModule.test.js`
- `artifacts/srt-lab/src/tabs/BcmTab.jsx`
- `artifacts/srt-lab/src/tabs/FcaAnalyzerTab.jsx`
- `attached_assets/alfao_bd.analysis_1776573163349.txt`
- `attached_assets/22CHARGER_REDEYE_6.2_797BCM_DFLASH_VIRGIN_1776226962777.bin`
- `attached_assets/18TRACKHAWKDFLASHBCM_DRAGKAT_OG_1C4RJFDJXEC365477_1776020054236.bin`
