---
title: TWIN tab — BCM ↔ RFH ↔ PCM twinning (2017 Dodge Charger)
---
Build a new TWIN tab (src/tabs/TwinTab.jsx) for 3-way BCM ↔ RFH ↔ PCM synchronisation on the 2017 Dodge Charger/Challenger. Wire it into App.jsx between IMMOVIN and SWARM.

  CONFIRMED OFFSETS (from real binary analysis):

  BCM (MPC5606B, 65536 bytes):
  • VINs primary (4 copies): 0x1338, 0x1358, 0x1378, 0x1398 — 17-byte ASCII + 2-byte CRC16 at +17
  • VINs secondary (6 copies, write on sync): 0x0698, 0x06B8, 0x06D8, 0x06F8, 0x0718, 0x0738 — same 32-byte records; only overwrite bytes 0..18 (leave bytes 19..31 intact)
  • SEC16 mirror 1: 0x00C9 (201 decimal), 16 bytes, no stored checksum byte after
  • SEC16 mirror 2: 0x00F1 (241 decimal), 16 bytes, no stored checksum byte after

  RFH (MC9S12X Type 1 Gen2, 4096 bytes):
  • VINs REVERSED (4 slots): 0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1 — 17 bytes stored reversed + 1-byte crc8rf CS at +17
  • SEC16 slot 1: 0x050E — 16 bytes + 2-byte CS at +16 (reference: B5 00 — try XOR-fold then CRC16)
  • SEC16 slot 2: 0x0522 — same format, must match slot 1
  • Do NOT use 0x00AE/0x00C0 — those are a different RFH generation (Gen1)

  PCM (GPEC2A, 8192 bytes) — use existing parseModule.js:
  • VINs: 0x0000 (current), 0x01F0, 0x0224
  • SEC6 at 0x03C8 (6 bytes)

  KEY RELATIONSHIP (confirmed from real files):
    RFH_SEC16 = reverse(BCM_SEC16)          // byte-for-byte 16-byte reversal
    PCM_SEC6  = reverse(BCM_SEC16)[0:6]     // first 6 of the reversed block

  THREE APPLY BUTTONS (all work without re-uploading — data stays in memory):
  A) "Import RFH → BCM":
     - Un-reverse VIN from RFH slot 1; write with CRC16 to BCM primary (0x1338…) AND secondary (0x0698…) slots
     - Reverse RFH_SEC16 → BCM_SEC16; write 16 bytes to 0x00C9 and 0x00F1
     - Trigger download as BCM_SYCNED_<filename>.bin

  B) "Import BCM → RFH":
     - Reverse BCM VIN bytes; compute crc8rf CS; write to RFH VIN slots (0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1)
     - Reverse BCM_SEC16 → RFH_SEC16; compute CS; write to 0x050E and 0x0522
     - Trigger download as RFH_SYCNED_<filename>.bin

  C) "Import BCM → PCM" (only shown when PCM file is loaded):
     - reverse(BCM_SEC16)[0:6] → SEC6; write to PCM 0x03C8
     - Trigger download as PCM_SYCNED_<filename>.bin

  INSPECT UI:
  - Drag-and-drop / file picker for BCM (required), RFH (required), PCM (optional)
  - After Inspect: show BCM card (VIN x4 with CS badges, SEC16 in BCM format + RFH-view reversed)
  - RFH card (VIN x4 with CS badges, SEC16 slot 1&2, slotsMatch badge)
  - Optional PCM card (current VIN, SEC6 hex)
  - Comparison table: VIN match, SEC16 match (BCM format vs reverse(RFH)), SEC6 match
  - "✅ Ready to apply" badge if all checks pass; "⚠ Mismatch" otherwise

  Match SRT Lab design system: C.* tokens, Card/Tag/Btn from ui.jsx, SRT Red #D32F2F.

  Plan file: .local/tasks/twin-tab-charger.md