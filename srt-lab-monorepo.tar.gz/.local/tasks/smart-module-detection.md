# Smart Unknown Module Detection

## What & Why
`parseModule` currently classifies files purely by size: 64/128 KB → BCM, 4 KB → RFHUB or GPEC2A, 8/16 KB → 95640, >128 KB → FW, everything else → UNKNOWN. Files outside these exact sizes are silently dropped and never loaded. Real-world dumps sometimes come in slightly different sizes (truncated reads, padded exports) and legitimate module types like TCM, ABS controller EEPROMs, and TIPM configuration blocks are never detected at all.

## Done looks like
- Files that are close to a known size (within ±4 KB) are inspected by content signature before being labelled UNKNOWN
- At least two additional module types are detected by content signature (magic bytes / known header patterns) rather than size alone — suggested targets: TCM EEPROM and TIPM EEPROM based on available reference data in the project
- UNKNOWN files that can't be identified still load into the tool as raw hex viewers so the user can inspect them rather than being silently ignored
- The DUMPS tab shows a badge "Unrecognized — hex view only" for UNKNOWN files instead of dropping them
- The auto-detect label at the bottom of the DUMPS tab lists the newly supported types

## Out of scope
- Full VIN patching / virginize for new types (handled in separate tasks)
- Changes to BENCH or LIVE OBD tabs

## Tasks
1. **Content-signature detection** — add byte-pattern checks inside `parseModule` for files that fail size-based classification; use magic bytes / known offsets from reference dumps in `attached_assets/`.
2. **Fuzzy size matching** — before returning UNKNOWN, check if the file is within ±4 KB of a known type's expected size and apply signature checks to confirm.
3. **UNKNOWN hex-view fallback** — instead of filtering out UNKNOWN modules in the drop handler, allow them to load with a `hexOnly: true` flag; display them in the DUMPS tab's hex viewer with a clear "Unrecognized module — read only" banner.
4. **Update UI labels** — add newly detected types to the auto-detect description chip at the bottom of the DUMPS tab.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:44-100,245-260,350-360`
