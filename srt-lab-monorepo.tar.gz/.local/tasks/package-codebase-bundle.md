# Package Codebase Bundle

## What & Why
Produce a single downloadable copy of the entire project so the user can take it offsite. They want both a compressed archive AND a single-file text concatenation of every source file.

## Done looks like
- A tarball at the project root containing the whole monorepo, excluding `node_modules`, build output (`dist`, `build`, `.cache`, `.local/state`), the `.git` directory, and any large generated SQLite databases. Final size well under 500 MB (the working tree minus those excludes is ~25 MB).
- A single concatenated text file at the project root containing every text source file in the repo, with clear `===== path/to/file =====` delimiters between files. Binary files (images, fonts, .db, .sqlite, lockfiles over a size threshold, etc.) are listed by path + size only, not inlined.
- Both files are presented to the user as downloadable assets.

## Out of scope
- Re-architecting any code.
- Regenerating the existing `srt-lab-all-code.txt` at the root in place — it will be replaced by the new whole-repo bundle.
- Including secrets, `.env*`, or anything from `.local/state/`.

## Steps
1. **Inventory & exclude list** — Walk the repo, build an explicit exclude list (`node_modules`, `.git`, `dist`, `build`, `.cache`, `.local/state`, `.local/.commit_message`, `*.db`, `*.sqlite`, `.env*`, OS junk like `.DS_Store`). Verify total size of what remains is under 500 MB.

2. **Build archive** — Create `srt-lab-monorepo.tar.gz` at the project root using the exclude list. Verify the archive size and that it extracts cleanly into a temp dir.

3. **Build concatenated text bundle** — Walk the same file set, classify each path as text vs binary by extension + a quick magic-byte sniff, and write `srt-lab-monorepo-bundle.txt` with `===== <relative path> =====` headers. For binaries, emit a `<<binary file, NNN bytes, sha256:...>>` placeholder line so the index is complete but the file is not garbled.

4. **Present both files** — Use the asset-presentation flow to surface `srt-lab-monorepo.tar.gz` and `srt-lab-monorepo-bundle.txt` in the chat as downloads, with a one-line summary of contents and sizes.

## Relevant files
- `package.json`
- `pnpm-workspace.yaml`
- `.gitignore`
- `.replitignore`
- `artifacts/srt-lab/`
- `artifacts/api-server/`
- `artifacts/mockup-sandbox/`
- `srt-lab-all-code.txt`
