---
title: SWARM — persistent agentic CAN negotiation loop
---
# SWARM — Persistent Agentic CAN Bus Negotiation Loop

## Goal

Redesign `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx` so the SWARM agents
never stop working until every discoverable module on the CAN bus has
either confirmed communication or exhausted every possible strategy. The
scan must be fully autonomous — no user intervention between attempts.

## Problem with current implementation

The current `launchSwarm` function is a **linear one-shot scan**: each
address is tried once with a small fallback chain, then abandoned. NO DATA
responses are logged and ignored. The scan ends with a final count.

## Required redesign

### 1 — Per-module state machine

Each of the 44 known CAN addresses (from `UNIQUE_ADDRS`) gets a state
object tracked in a React ref (`moduleStates`):

```
{
  tx, rx, name, src,
  state: 'pending' | 'probing' | 'retrying' | 'confirmed' | 'exhausted',
  strategyIdx: 0,          // which strategy we are on
  attempts: 0,             // total probe attempts
  lastError: '',           // last failure reason
  confirmedBy: '',         // which strategy succeeded
  vin: null,
}
```

Add a new React state `moduleStates` (array, one entry per address) that
drives a live status board (see §4 below).

### 2 — Strategy library (9 strategies, tried in order per module)

| # | Name | What it does |
|---|------|-------------|
| S0 | EXT_VIN | Extended session (10 03) → read VIN (22 F1 90) |
| S1 | DEF_VIN | Default session (10 01) → read VIN |
| S2 | RAW_VIN | VIN read with no session open |
| S3 | TESTER_PRESENT | 3E 00 ping only — confirms module is alive |
| S4 | SLOW_TIMING | ATST32 (slower timeout) + retry S0 |
| S5 | SP5_250K | Switch adapter to ATSP5 (CAN 11-bit 250kbps) + retry S0 |
| S6 | SP7_33K | Switch adapter to ATSP7 (CAN 11-bit 33.3kbps) + retry S0 |
| S7 | FUNCTIONAL_BCAST | Functional address 7DF broadcast + parse response for this module's RX |
| S8 | SOFT_RESET | ATZ + re-init + retry S0 |

After S8 fails the module is marked `exhausted`.

### 3 — The agentic main loop

Replace the sequential sweep with this async loop inside `launchSwarm`:

```
// Phase 0: passive CAN monitor (4s) + broadcast (7DF) — unchanged
// Phase 1: agentic loop

while (true) {
  const pending = moduleStates.filter(m =>
    m.state === 'pending' || m.state === 'retrying'
  );
  if (pending.length === 0) break;

  for (const mod of pending) {
    mod.state = 'probing';
    updateModuleState(mod);  // triggers re-render of status board

    const strategy = STRATEGIES[mod.strategyIdx];
    const result = await runStrategy(strategy, mod, { send, uds, isSTN });

    mod.attempts++;
    if (result.ok) {
      mod.state = 'confirmed';
      mod.confirmedBy = strategy.name;
      mod.vin = result.vin || null;
      addFound(mod.tx, mod.rx, mod.name, mod.src + '+' + strategy.name, result.vin);
    } else {
      mod.lastError = result.reason;
      mod.strategyIdx++;
      if (mod.strategyIdx >= STRATEGIES.length) {
        mod.state = 'exhausted';
      } else {
        mod.state = 'retrying';
      }
    }
    updateModuleState(mod);
  }

  // Small yield so UI can repaint between passes
  await new Promise(r => setTimeout(r, 50));
}

addLog('SYSTEM', `SWARM DONE — confirmed:${confirmed} exhausted:${exhausted}`, ...);
setRunning(false);
```

The loop only ends when **all modules are confirmed or exhausted**. There
is no condition that bypasses the loop early (unlike the current `if
(foundSet.current.size <= 2)` gates).

### 4 — Live module status board (new UI panel)

Replace the simple "MODULES FOUND" chip list with a full status grid that
updates in real time during the scan:

- One tile per module (name + TX/RX + current state + strategy label)
- Color coding:
  - **Gray** `#555` — PENDING (not yet reached)
  - **Cyan** `#00E5FF` (pulsing animation) — PROBING (actively trying now)
  - **Orange** `#FF6D00` — RETRYING (strategy N of 9)
  - **Green** `#66BB6A` — CONFIRMED (+ confirmedBy tag + VIN if found)
  - **Red** `#FF1744` — EXHAUSTED (no strategy worked)
- Progress bar at the top: `confirmed/total` fill

### 5 — Strategy isolation helpers

Each strategy is implemented as a pure async function:

```javascript
async function runStrategy(strategy, mod, eng) {
  // returns { ok: true, vin } or { ok: false, reason }
}
```

Strategies that change adapter-level protocol (S4 SLOW_TIMING, S5 SP5,
S6 SP7) must restore the adapter to SP6/ATST96 after the attempt, whether
it succeeded or failed.

### 6 — Counters / summary bar

Add a live counter row between the status board and the log:
```
Confirmed: 7   Retrying: 12   Exhausted: 3   Pending: 22   Attempts: 156
```

## Files changed

- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx` — full redesign of
  `launchSwarm`, new `STRATEGIES` array, new `runStrategy` helper, new
  status board UI. The `connect`, `resetPP`, and adapter init logic are
  unchanged.

## Acceptance criteria

1. Launching the SWARM starts the agentic loop; the log and status board
   update continuously.
2. Modules that return NO DATA on S0 are automatically retried on S1, S2,
   etc. without any user action.
3. The loop does not terminate until every module is confirmed or exhausted.
4. The status board shows all 44 modules with correct color states in real
   time.
5. Protocol-switching strategies (S5, S6) restore the adapter to SP6 after
   each attempt.
6. Build passes (`PORT=3000 BASE_PATH=/srt-lab pnpm run build` inside
   `artifacts/srt-lab/`).