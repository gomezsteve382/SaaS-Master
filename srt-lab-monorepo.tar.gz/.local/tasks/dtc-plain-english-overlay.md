# DTC Plain-English Overlay

## What & Why
Today the UDS Programmer's Read DTCs button parses
`0x19 0x02 0x08` responses into hex codes (`P0301`, `U0140`, etc.)
and dumps them into the log with no human-readable text. Once the
AlfaOBD `Faults` table is staged into `alfaobdData.generated.js`
(Task T1), we can map every code to its EN description in the same
log line — turning "DTC: P0301 status=0x09" into something like
"DTC: P0301 (Cylinder 1 misfire detected) status=0x09 — current /
confirmed".

This is the highest-leverage user-visible change in the AlfaOBD
drop and it directly feeds the already-queued
"Translate raw error codes into plain-English fixes" capability.

## Done looks like
- Read DTCs (in UDS Programmer and any other DTC surface) shows
  the description inline next to the hex code.
- Each DTC entry in the log is clickable / hoverable to open a
  small detail panel that shows: full description, status bits
  decoded via STATES (current, pending, confirmed, etc.), and
  the originating module CAN ID.
- Codes not in the AlfaOBD set fall back gracefully — log line
  still renders the hex with a "(unknown)" tag rather than
  collapsing the row.
- Vitest UI test covers: a known mock UDS response decodes into
  human-readable text; an unknown code renders the fallback;
  status-byte decoding picks up at least the "test failed",
  "pending", and "confirmed" bits.
- No DTC lookup performed at module load — table is referenced
  lazily so the bundle remains tree-shake-friendly.

## Out of scope
- Suggested fixes / diagnostic procedures per code. The AlfaOBD
  table only has names + categories; "fixes" require a separate
  knowledge source (FSM, alldata, etc.) and is not in this drop.
- Re-architecting the DTC parser. Keep the existing 0x19 0x02 0x08
  flow; only enrich the rendering.
- Multi-language descriptions — EN only (matches T1's filter).

## Steps
1. **DTC formatter helper.** Add a small lib helper (something
   like `dtcLookup(hexCode)`) that returns
   `{ code, description, category }` or null. Reads from
   `FAULTS_BY_HEX` exported by Task T1's generated module.

2. **Status byte decoder.** Add a companion helper that decodes
   the standard ISO 14229 DTC status mask byte (test failed,
   test failed this op cycle, pending, confirmed, test not
   completed since last clear, test failed since last clear,
   test not completed this op cycle, warning indicator
   requested) into a short label set.

3. **UDS Programmer wiring.** Update the `readDtcs` callback in
   `UdsTab.jsx` to call the lookup + status decoder and emit a
   richer log message. Preserve the existing paper-trail entry
   shape so audit logs don't change schema.

4. **Detail panel.** Add a click affordance on log rows tagged
   as DTCs that opens a small inline panel with the long
   description, decoded status, and a "Copy code" button.

5. **Audit other DTC surfaces.** Sweep `OBDTab.jsx`, the swarm
   diagnostic, and any other tab that calls 0x19 to either share
   the helper or note in a comment why it's exempt.

6. **Tests.** Add a vitest spec that mounts UdsTab with a mocked
   engine and asserts the rendered log contains the expected
   description text for a pinned response.

## Critical constraints
- The `FAULTS_BY_HEX` shape is owned by Task T1. If T1 drifts on
  the export shape, this task pulls the new shape — do not
  duplicate the .db parsing logic here.
- The existing paper-trail records `dtcs: codes[]` (just the hex
  list). Keep that contract; add description into the log only,
  not into the structured audit record, so historical audit
  diffs stay stable.

## Relevant files
- `artifacts/srt-lab/src/tabs/UdsTab.jsx:167-183`
- `artifacts/srt-lab/src/tabs/OBDTab.jsx`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx`
- `artifacts/srt-lab/src/lib/nrc.js`
- `artifacts/srt-lab/src/lib/__tests__/`
