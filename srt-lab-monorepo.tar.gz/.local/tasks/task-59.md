---
title: JAILBREAK / Module UDS Workshop Tab — BCM hidden options + Active Damping + DTCs + Routines
---
# JAILBREAK OPTIONS Tab

## What & Why
Add an 11th tab — JAILBREAK OPTIONS — that turns SRT Lab into a real Hellcat/Demon/Redeye hidden-feature unlocker. It connects to a vehicle through an OBDLink EX (or any ELM327/STN-compatible adapter) over Web Serial, finds the BCM, unlocks it with the CDA6 algorithm, then reads/writes 50 hidden BCM options (launch control, trans brake, drag mode, SRT performance pages, after-run chiller, valet limits, etc.) through UDS DIDs `0xDE01` and `0xDE02`. Four one-click profiles (SRT Full, Demon Package, Hellcat, Track Mode) stage dozens of changes at once. This is the headline "kill the game" feature that no public FCA tool currently exposes.

## Done looks like
- A new tab labeled `💀 JAILBREAK OPTIONS — SRT · DEMON · HELLCAT · REDEYE` appears at the end of the tab strip
- "Connect OBDLink" button uses Web Serial; auto-detects ELM327 vs STN/OBDLink and (on STN) sets MFG extended mode so DIDs `0xDE01`/`0xDE02` are actually reachable
- "Find BCM" probes the four known FCA BCM CAN address pairs (CDA6 `0x750/0x758`, CLAUDE `0x742/0x762`, Legacy `0x7E0/0x7E8`, DarkVIN `0x6B0/0x6B8`) and locks onto whichever responds
- "Unlock BCM" does session 0x10 03 → seed request 0x27 01 → CDA6-derived key 0x27 02; status badge flips to green "BCM UNLOCKED"
- "Read All Features" reads every DID once, decodes each of the 50 features into a labeled dropdown showing the current setting
- Features are grouped into 11 collapsible categories (Vehicle Configuration, Launch & Performance, Drive Modes, SRT Performance Pages, Trans Brake & Race, Handling & Stability, Powertrain, Aero & Cooling, Gauges & Displays, Telemetry, Valet & Misc) with a search box that filters across id/name/description
- Changing a dropdown stages the change (highlighted row + ⚡ marker) without writing yet; the WRITE button shows the pending count
- Quick-profile buttons (SRT Full / Demon Package / Hellcat / Track Mode) stage a preset bundle of changes in one click
- WRITE coalesces all pending changes per DID, sends a single 0x2E per DID, then issues an ECU reset (0x11 01)
- Live UDS log panel (dark terminal style) shows TX/RX/info/warn/error lines with timestamps
- Disconnecting and reconnecting works without page refresh; nothing else in the existing 10 tabs regresses

## Out of scope
- A J2534 hardware path (covered by the separate Desktop Driver task)
- Editing PCM tunes, ABS, or radio/cluster modules (BCM only)
- Persisting profiles to localStorage or sharing them across users
- Any backend — everything stays client-side
- Changes to the existing parser, Security Byte Match, or any other tab

## Tasks
1. **Shared OBD engine helper** — Extract the Web Serial connect + adapter auto-detect (ELM327 vs STN) + MFG-extended-mode setup + UDS frame send/receive logic into a reusable library module so both this tab and any future bench tooling can call it without copy-paste.

2. **JAILBREAK_FEATURES catalog** — Add a constants module containing the 50-feature table (id, display name, description, DID, byte offset, optional bitmask, option list, optional notes) and the four quick-profile presets.

3. **JailbreakTab component** — Build the new tab: header banner, connect/find-BCM/unlock/read/write toolbar, BCM address readout, profile bar, search input, collapsible category cards with per-feature dropdowns, pending-change highlighting, batched DID writes, ECU reset, and the dark UDS log panel.

4. **Tab registration** — Add `{id:'jailbreak',i:'💀',l:'JAILBREAK OPTIONS',s:'SRT · Demon · Hellcat'}` to the tab list and wire the route so the existing 10 tabs are untouched.

5. **Smoke check** — Open the tab, confirm it renders, search filters, dropdowns populate option lists, and the Connect button surfaces a clean error (not a crash) on browsers without Web Serial / when no adapter is selected.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:245,259,263-272`
- `artifacts/srt-lab/src/lib/algos.js`
- `attached_assets/Pasted-import-React-useState-useCallback-useMemo-useRef-from-r_1776429769807.txt:1551-1927`