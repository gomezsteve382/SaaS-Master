# J2534 Bridge + AUTEL SGW Tab

## What & Why
Add a real local J2534 bridge so the SRT Lab web app can drive an Autel MaxiFlash VCI on 2018+ SGW-protected FCA vehicles. There is already a WebSocket-based `j2534_bridge.py` in `public/`, but the attached spec is HTTP-based (simpler, no extra Python deps, matches the new AUTEL SGW UI). This task replaces the existing bridge with the HTTP version, adds a dedicated **AUTEL SGW** tab in the app, wires the status strip and pre-write modal to show SGW routing, and ships a setup README the user can follow.

## Done looks like
- A standalone `j2534_bridge.py` daemon (Python 3.8+, stdlib only) runs on the user's Windows/macOS/Linux box, loads the vendor J2534 DLL via `ctypes`, and serves these HTTP endpoints on `127.0.0.1:8765`: `GET /status`, `POST /open`, `POST /connect`, `POST /disconnect`, `POST /close`, `POST /sendmsg`, `POST /readmsg`, `POST /setfilter`. Permissive CORS so the hosted web app can call it from the browser.
- A new **AUTEL SGW** tab in the SRT Lab app:
  - Shows configured bridge URL (default `http://localhost:8765`), editable and persisted in localStorage under `srtlab_autel`.
  - "Run Test" button that pings `/status`, opens the device, reads firmware/DLL/API versions and serial, and shows green `[OK]` / red `[FAIL]` lines for each step.
  - Shows detected vendor name (Autel MaxiFlash / Drew Tech / generic) and connection state.
  - "Save configuration" button persists the verified bridge URL.
- Top status strip gains a `🔐 SGW REQ` chip when the current Master VIN is 2018+ (uses VIN year parsing).
- AUTEL tab header shows `✓ BRIDGE CONNECTED` / `✗ BRIDGE OFFLINE` based on last `/status` poll.
- Pre-write confirmation modal indicates "Routing through Autel MaxiFlash (SGW authenticated)" when SGW is required for the target VIN.
- A small `lib/bridgeClient.js` (or similar) module wraps `fetch` calls to the bridge, handles timeouts, and exposes a typed API used by the AUTEL tab and by future write paths.
- `README_J2534_BRIDGE.md` ships in `public/` (or `docs/`) with the setup guide from the attached spec: install Autel MaxiPC, locate `MaxiFlashJ2534.dll`, run `python3 j2534_bridge.py --dll <path>`, and verify in the AUTEL tab.

## Out of scope
- Actually performing flash writes through the bridge for production use (this task wires the plumbing and the diagnostic test only; real write flows continue to use the existing UDS workshop code paths and will be migrated separately).
- Bypassing SGW without an Autel subscription. The bridge only relays J2534 calls; SGW auth is done by VCI firmware using Autel's licensed credentials.
- Packaging the bridge as a Windows installer / signed exe.
- Replacing the existing `J2534Scanner.jsx` discovery UI.

## Tasks
1. Replace `artifacts/srt-lab/public/j2534_bridge.py` with the HTTP-based daemon from the attached spec (stdlib `http.server`, `ctypes`, `threading`). Keep the `--dll`, `--port`, `--verbose`, `--no-open` CLI flags. Implement all eight endpoints with proper J2534 error mapping and JSON responses (binary as hex).
2. Add `README_J2534_BRIDGE.md` in `artifacts/srt-lab/public/` with the setup guide, troubleshooting, and security notes from the attachment.
3. Add `lib/bridgeClient.js` exposing `getStatus()`, `open()`, `connect({protocol,flags,baudrate})`, `disconnect()`, `close()`, `sendMsg({txId,data,flags})`, `readMsg({timeoutMs})`, `setFilter({txId,rxId})`, plus a small `useBridgeStatus()` hook that polls `/status` every few seconds.
4. Add `tabs/AutelSgwTab.jsx` with bridge URL field, Run Test panel, version/serial display, and Save button. Persist config under `localStorage.srtlab_autel` using the existing `getAutelState`/`setAutelState` helpers.
5. Register the AUTEL tab in the main tab list in `App.jsx`.
6. Add VIN-year-based SGW detection helpers (`parseVinYear`, `vinHasSGW`) in `lib/vin.js` (or wherever VIN helpers live) and use them to render the `🔐 SGW REQ` chip in the top status strip.
7. Update the existing pre-write confirmation modal to show the "Routing through Autel MaxiFlash (SGW authenticated)" line when `vinHasSGW(masterVin)` is true and the bridge reports connected.

## Relevant files
- `artifacts/srt-lab/public/j2534_bridge.py`
- `artifacts/srt-lab/public/srt_lab.py`
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/J2534Scanner.jsx`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/tabs/UdsTab.jsx`
- `artifacts/srt-lab/src/tabs/ProgramAllTab.jsx`
- `artifacts/srt-lab/src/tabs/SessionsTab.jsx`
- `artifacts/srt-lab/package.json`
