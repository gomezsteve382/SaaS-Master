---
title: Design SRT Lab capabilities flyer (PDF + PNG)
---
# SRT Lab Capabilities Flyer

## What & Why

The user wants a single-page promotional flyer that shows off everything SRT Lab — Jailbreak Edition can do, in the app's own visual language (matte black + SRT red, Righteous display + Nunito body + JetBrains Mono for hex/data). Intended to be shareable as both a print-ready PDF and a high-resolution PNG (e.g. for posting in shop chats, Discord/Reddit threads, or as a wall flyer in the bay).

The flyer should feel hand-built, not template-y — closer to a metal-band tour poster than a SaaS one-pager.

## Done looks like

- A single 8.5×11 (portrait) flyer exists as **both** `attached_assets/flyers/srt_lab_flyer.pdf` and `attached_assets/flyers/srt_lab_flyer.png` (PNG ≥ 2400×3100, 300dpi-equivalent).
- Visual treatment matches the app: matte-black background, SRT-red gradient bar, Righteous wordmark "SRT LAB / JAILBREAK EDITION" hero, hex/data accents in JetBrains Mono.
- Capability content is grouped into 4–5 readable blocks (titles + tight bullet hits, no walls of text). Suggested grouping:
  1. **LIVE OBD & UDS** — Web Serial ELM327/STN, multi-module scan, raw UDS console, NRC-aware unlock chain, response-pending handling.
  2. **VIN SURGERY** — read/write VIN at F190 / 7B90 / 7B88 / 6E2025 / 6E2027 / 6EF190, 24-bit DID encoding, per-DID read-back with 8-char tail comparator, write-gating on unlock failure.
  3. **MODULE BIN WORKBENCH** — auto-detect GPEC2A / RFHUB / BCM / 95640, hex viewer + diff, virginizer, CRC-correct VIN patch, SKIM toggle, transponder-key + secret-key extract, ZZZZ tamper check, IMMO backup sync, BCM SEC16 / RFHUB SEC16 audit.
  4. **SECURITY & SEED→KEY** — 14 algorithms (CDA6, GPEC1/2/2A/3 sxor, NGC, JTEC, SBEC, TIPM ×4) plus the XTEA SGW unlock for 2018+ vehicles, ADCM Routine 0x0312 unlock with SBEC fallback, RFH↔PCM pairing, SKIM key grid (Trackhawk + SRT layouts), cross-vehicle key matcher.
  5. **HARDWARE & WORKFLOWS** — Autel MaxiFlash J2534 HTTP bridge for SGW-routed writes, Program-All guided BCM→RFHUB→ECM→ADCM flow, on-bench mode, backups (last 50) + sessions paper-trail (last 500) with PDF export, jailbreak features (SRT / Demon / Hellcat / Redeye).
- A footer strip with: "100% client-side · no telemetry · Web Serial + J2534" and a small mono-font tagline like `// FCA / STELLANTIS · 2009 → 2026`.
- Both files render cleanly when opened (PDF in any reader, PNG in any image viewer) — no clipped text, no missing fonts, no broken hex glyphs.

## Out of scope

- Multi-page brochure or printed booklet — single page only.
- Adding any in-app UI to view/share the flyer (separate concern).
- Translating capability text into non-English locales.
- Photoreal renders of hardware (Autel cable, ECU, OBD plug). Vector / typographic accents only.
- Any change to app source, parser logic, or test suites.

## Steps

1. **Build the flyer renderer.** Create a self-contained generator (small Node script using a headless render pipeline, e.g. Puppeteer + an HTML/CSS template, or a vector-first approach with PDFKit) that emits both a PDF and a high-resolution PNG from the same template. Prefer the HTML/CSS-via-headless-Chrome route so the existing brand fonts render correctly and accents like the SRT-red gradient look identical to the app.

2. **Author the flyer template.** Lay out the hero wordmark, the 4–5 capability blocks, and the footer strip using the exact palette and fonts called out in `replit.md`. Pull the capability bullets directly from the tab inventory in `replit.md` so nothing real is missed and nothing aspirational is invented. Treat hex/DID strings as monospace accents (e.g. `0xF190`, `0x6E2025`, `XTEA SGW`, `Routine 0x0312`).

3. **Produce the deliverables.** Run the renderer, drop the outputs at `attached_assets/flyers/srt_lab_flyer.pdf` and `attached_assets/flyers/srt_lab_flyer.png`, and present both to the user. Verify the PNG is at least 2400×3100 and the PDF is exactly one page.

## Relevant files

- `replit.md`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/tabs`