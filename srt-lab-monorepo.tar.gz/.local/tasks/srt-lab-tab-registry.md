# Move tab list into a registry file

## What & Why
App.jsx hardcodes the `TABS` array inline (id / label / icon / placeholder flag / sub-label per tab). Every cleanup or feature task that adds/removes/reorders a tab has to edit App.jsx, which is the most-touched file in the project and the most merge-conflict-prone. Extracting the registry to its own file makes adding a tab a one-line change to a config and zero changes to App.jsx.

## Done looks like
- A new `src/tabs/registry.js` (or `.jsx`) exports `TABS` as `[{id, label, icon, sub, component, placeholder?, demo?}]`. Each entry imports its own `component` from `tabs/<name>.jsx` (or wherever it lives).
- App.jsx imports `TABS` from the registry and does `{TABS.map(t => ...)}` to render the bar and the active tab. The inline tab definitions in App.jsx are gone.
- Adding a new tab requires: create `tabs/MyTab.jsx`, add one entry to the registry. Zero edits to App.jsx.
- Tab order, labels, icons, and the SOON/placeholder badges still render identically.

## Out of scope
- Lazy-loading tabs (could come later; for now they're all imported eagerly).
- Renaming tabs or changing the visual tab bar.
- Per-tab routing via the URL (current state-based tab switching stays).

## Steps
1. Create `src/tabs/registry.js` with the full TABS array. Each entry includes a `component:` key pointing at the imported tab component.
2. Update App.jsx: import `TABS` from the registry, render the active tab via `<tab.component />` instead of the current switch/conditional logic.
3. Confirm the placeholder / SOON badge still renders for tabs marked `placeholder: true`.
4. Smoke-test: every tab still loads, in the same order, with the same labels and icons.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/tabs/`
