# ECM + ADCM Programmer Tabs

## What & Why
Port the dedicated ECM and ADCM programmer tabs from the reference `App.jsx`. ECM auto-tries the 10 documented security algorithms; ADCM uses Routine 0x0312 for unlock plus a variant-config picker before VIN write.

## Done looks like
- An ECM tab renders the reference layout: hero, Test Connection, Read ECU info, Read VIN, Write VIN (gated by the Read-First modal), 10-algorithm auto-unlock that reports which algo succeeded, in-tab log.
- An ADCM tab renders the reference layout: hero, Test Connection, Variant selector (driven by `ADCM_VARIANTS`), Read VIN, full sequence Write (Routine 0x0312 unlock → VIN write to F190/7B90/7B88 → variant config), in-tab log.
- Both tabs read the VIN from the Master VIN context and update the matching slot in the module status strip.
- Both tabs auto-snapshot before writes and append paper-trail entries via the shared helpers.
- Both tabs use the shared `initAdapter` helper.

## Out of scope
- BCM, RFHUB, ProgramAll, UDS, Backups, Sessions, Analyzer — separate chunks.
- Adding new ECM security algorithms — port only what is in the reference.

## Tasks
1. **Port ECM tab** — Translate the reference `EcmTab` into `src/tabs/EcmTab.jsx`. Include the 10-algorithm auto-try loop with clear per-algo logging.
2. **Port ADCM tab** — Translate the reference `AdcmTab` into `src/tabs/AdcmTab.jsx`. Include the `ADCM_VARIANTS` table and the full unlock → write → variant sequence.
3. **Wire into navigation** — Replace the placeholders for `ecm` and `adcm` with the real components.
4. **Bench smoke run** — Build, restart workflow, walk through both tabs in disconnected mode and confirm the status strip + paper-trail entries respond as expected.

## Relevant files
- `attached_assets/App_1776444434000.jsx`
- `artifacts/srt-lab/src/tabs/`
- `artifacts/srt-lab/src/lib/mods.js`
