# Centralized toast / error sink

## What & Why
Every tab catches errors with `alert("PDF build failed: " + e.message)` or `alert("Import failed: ...")`. Browser `alert()` is blocking, ugly, and dumps zero context for a bug report. Replacing it with a single toast component fed by an `errorSink` context preserves the same UX surface but also captures every error to a ring buffer the user can copy-paste when something goes wrong.

## Done looks like
- A `lib/toast.jsx` exports `<ToastProvider>`, `useToast()`, with `toast.info(msg)`, `toast.warn(msg)`, `toast.error(msg, err?)`, `toast.success(msg)`.
- Toasts stack in a corner (top-right or bottom-right), auto-dismiss after 5s for info/success, 10s for warn, sticky-until-dismissed for error.
- Every `error` toast also pushes onto a 50-entry ring buffer; a small "i" button on the header opens a panel showing the recent error log and a "Copy all" button.
- All `alert(...)` calls in `src/` are replaced with the appropriate `toast.*` call. Final grep `grep -rn "alert(" artifacts/srt-lab/src` returns zero hits.
- No behavioural regressions: every code path that previously alerted now toasts.

## Out of scope
- Sending errors to a remote logging service.
- Replacing `console.error` calls (those stay; toast is for user-facing).
- Visual polish beyond a clean default look matching the existing palette.

## Steps
1. Build `lib/toast.jsx` with the provider, hook, and a tiny stacked-toast renderer using only inline styles + the existing `C` palette from `lib/constants.js`.
2. Implement the ring buffer as a module-level array with a `subscribeErrorLog(fn)` for the log panel.
3. Wrap the app root in `<ToastProvider>` (in App.jsx, alongside any other providers).
4. Sweep every tab and replace `alert(...)` and the matching `try/catch` patterns with `toast.error(...)`. Notable hits: `BackupsTab` (5x), `ImmoVINTab`, `SeedTab`, `J2534Scanner`, `OBDSwarmDiagnostic`, `App.jsx` PDF handler.
5. Add the "recent errors" panel toggle in the header.
6. Smoke-test by triggering a failing PDF build; confirm the toast appears and the error is captured in the panel.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/tabs/BackupsTab.jsx`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
- `artifacts/srt-lab/src/tabs/SeedTab.jsx`
- `artifacts/srt-lab/src/J2534Scanner.jsx`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx`
