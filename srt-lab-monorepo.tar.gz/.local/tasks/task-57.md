---
title: Add PAIRED banner preview toggle
---
# PAIRED Banner Preview Toggle

## What & Why

The Hellcat Charger animation only appears in the Security Byte Match tab when two
matching ECU files are actually loaded. Users can't easily see it without real dump
files. Add a small "Preview" toggle button to the tab so the PAIRED banner can be
forced on for demo/visual purposes without requiring any files.

## Done looks like

- A small "👁 Preview PAIRED" button appears near the top of the Security Byte Match tab.
- Clicking it forces the green PAIRED banner (with the animated Hellcat Charger) to
  render, overriding whatever the file-based state currently shows.
- Clicking it again (or a "✕ Exit Preview" button that replaces it) returns the tab
  to its normal file-driven state.
- The toggle has no effect on any other tab or any data — it is purely a local
  display override using a single React state variable.
- Styling is minimal and unobtrusive: small ghost/outline button, positioned in the
  top-right corner of the Security Byte Match card area.

## Out of scope

- Any persistence of the preview state across page reloads.
- Changes to any tab other than Security Byte Match.
- Changes to the PAIRED banner itself.

## Tasks

1. **Add preview toggle state and button** — In the Security Byte Match section of
   TwinTab.jsx, add a boolean `previewPaired` state variable. Render a small styled
   button that toggles it. When true, pass a derived status of "PAIRED" to the
   PairedBanner render condition instead of the real computed status.

## Relevant files

`artifacts/srt-lab/src/tabs/TwinTab.jsx`