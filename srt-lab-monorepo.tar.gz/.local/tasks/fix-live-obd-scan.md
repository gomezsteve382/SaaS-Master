# Fix Live OBD Scan & Serial Communication

## What & Why
The Live OBD scan connects to the ELM327 adapter and sends AT init commands successfully, but when scanning modules (ATSH/ATCRA/22F190), no responses are detected. All scan commands time out silently, resulting in "Scan complete" with zero modules found — even when 5 modules are connected on a bench via OBD. Two root causes must be fixed.

## Done looks like
- Scan successfully detects and lists modules connected via OBD/bench (ECM, TCM, BCM, IPC, DAMP, etc.)
- Timeout responses are logged so the user can see what the adapter actually sent back (debug visibility)
- VIN is correctly extracted from multi-frame UDS responses with headers enabled
- Works with common ELM327 adapter variants (clone and genuine, different baud rates)

## Out of scope
- Adding new module types beyond the existing MODS list
- WiFi/Bluetooth adapter support (Web Serial only)
- ISO 9141 / KWP2000 protocols (CAN only)

## Tasks

1. **Fix `send()` timeout logging** — When `send()` times out waiting for `>`, log whatever partial data was received in `buf` so the user can see what the adapter actually sent. This is critical for diagnosing adapter communication issues.

2. **Fix ELM327 prompt detection** — The `>` prompt detection may fail with some adapters that send `\r>`, `\r\n>`, or extra whitespace. Normalize the buffer before checking for the prompt character. Also handle `?` responses (unknown command) gracefully.

3. **Fix response hex parser for ATH1 headers** — With ATH1 enabled, each CAN response line starts with a 3-character CAN ID (e.g., `7E8`). The current `.match(/.{2}/g)` regex can't handle 3-char hex tokens. Strip the first token (CAN ID) from each response line before parsing data bytes. This requires splitting each line on spaces and skipping the first space-separated token when it's 3 characters long.

4. **Fix multi-frame ISO-TP response assembly** — With ATCAF1 and ATCFC1 enabled, multi-frame UDS responses (like VIN reads which exceed single-frame size) should be auto-assembled by the adapter. Verify the PCI byte stripping is correct: after removing the CAN ID header, also strip the ISO-TP PCI bytes (first 1-2 bytes of each frame: `10 LL` for first frame, `2x` for consecutive frames) so only the actual service response data (62 F1 90 + VIN bytes) remains.

5. **Increase AT command timeouts for scan** — The current 2000ms default is tight for ATSH/ATCRA when the adapter is on a bench with active CAN traffic. Increase AT command timeout within `uds()` to 3000ms. Keep the UDS data command at 5000ms.

6. **Add baud rate auto-detection or selection** — Some ELM327 clones use 38400 or 9600 baud instead of 115200. Try connecting at 115200 first; if ATZ doesn't respond, retry at 38400, then 9600. Alternatively, add a baud rate selector dropdown in the Live OBD UI.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:815-849`
- `artifacts/srt-lab/src/App.jsx:16`
