---
title: Two-Phase Functional Broadcast Scan + CAN Monitor Refinements
---
# Two-Phase Functional Broadcast Scan + CAN Monitor Refinements

## What & Why
Major upgrade to the OBD scan strategy: replaces sequential per-module probing 
with a two-phase approach using UDS functional broadcast (0x7DF). Also refines 
the CAN Monitor for better reliability and error reporting.

## Changes

### 1. Two-Phase Scan (replaces current scan function)

**Phase 1: Functional Broadcast Discovery**
- Clear CRA filter (`ATCRA` with no arg) to accept ALL responses
- Set `ATSH7DF` (UDS functional broadcast address)
- Send TesterPresent (`3E00`) with 4000ms timeout
- Parse ALL responding CAN IDs from the multi-line response
- Map discovered RX IDs to known MODS entries
- Log unknown modules with guessed TX address (RX-8 or RX-0x20)

**Phase 2: Individual Module VIN Read**
- Build scan targets: merge known MODS with any newly discovered unknown modules
- If broadcast found modules, SKIP known modules that weren't discovered (saves time)
- For each target: set ATCRA+ATSH, probe with 3E00/1001, read VIN via DID F190
- Handle "discovered but not individually responsive" modules (mark as `(discovered)`)
- Log: "alive" / "alive (DiagSession)" instead of verbose messages

### 2. CAN Monitor Refinements
- Better ATMA break: explicit 500ms timeout on break send `send('',500)`
- Longer post-break delay: 300ms (was 200ms) for clean recovery
- Pre-ATMA delay: 100ms (was 50ms) for CRA clear to take effect
- Numeric ID matching: `parseInt(id,16)` compared to `MODS[].rx`/`.tx` directly
- Error handling: shows raw ATMA output when no IDs found; separate message for empty ATMA
- Log formatting: `'=== CAN BUS MONITOR — listening 5 sec ==='` header

### 3. Minor Scan Log Wording
- "responded to TesterPresent: ..." → "alive"
- "responded to DiagSession: ..." → "alive (DiagSession)"
- "on bus but VIN unreadable" → "on bus, VIN unreadable"
- "on bus but VIN read failed" → "on bus, VIN read failed"
- `setBusy('Monitoring CAN...')` → `setBusy('Monitoring...')`

## Why This Matters
- Functional broadcast via 0x7DF is the standard UDS discovery method used by all professional scan tools
- On bench (no gateway), every module responds simultaneously — scan time drops from ~30s to ~5s
- Automatically discovers non-standard modules not in the MODS table
- Skipping absent modules avoids wasted 3s timeouts per missing module

## Done Looks Like
- Phase 1 broadcast shows all responding modules instantly
- Phase 2 only probes discovered modules (or falls back to full scan if broadcast fails)
- Unknown modules get auto-discovered with guessed TX addresses
- CAN Monitor reliably captures and displays traffic

## Relevant Files
- `artifacts/srt-lab/src/App.jsx` — scan function (~line 858), canMonitor (~line 941)