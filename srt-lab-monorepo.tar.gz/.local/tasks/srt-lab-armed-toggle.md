# Global ARMED/SAFE toggle

## What & Why
Today the only thing between a misclick and a bricked SGW is a per-tab "I've reviewed the current state" checkbox in `ReadFirstModal`. Wandering through tabs to read IDs/DTCs is also gated by that same modal because the underlying engine does not distinguish "read" from "write". A header-level ARMED/SAFE switch that gates every UDS write service (0x2E WriteDataByIdentifier, 0x31 RoutineControl, 0x34/0x36/0x37 RequestDownload/TransferData/TransferExit, 0x3D WriteMemoryByAddress, and 0x27 SecurityAccess when followed by a write) lets the user explore a vehicle in SAFE mode with zero risk and only arm explicitly when ready to write.

## Done looks like
- The app header shows a prominent ARMED/SAFE toggle (default SAFE on every load, never persisted to localStorage).
- A single `useArmed()` context provides the current state and a `requireArmed(action: string)` helper that throws/refuses if not armed.
- `bridgeEngine.uds()` (or a wrapper around it) refuses any service in `{0x2E, 0x31, 0x34, 0x36, 0x37, 0x3D}` when SAFE; refuses 0x27 sub-functions only if a write is queued; allows 0x10 (DiagnosticSessionControl), 0x22 (ReadDataByIdentifier), 0x19 (ReadDTC), 0x14 (ClearDTC — debatable, default to gated), 0x3E (TesterPresent), 0x11 (ECUReset — gated).
- Visible feedback: when SAFE blocks a write, a toast says "Write blocked — toggle ARMED in the header". When ARMED, the header is red/orange and a banner reminds the user.
- The `ReadFirstModal` checkbox stays — ARMED is a coarser, app-wide gate; the modal stays as the per-write confirmation.

## Out of scope
- Persisting the ARMED state across reloads (intentionally not persisted — explicit re-arm every session).
- Auditing/logging which services were attempted in SAFE mode.
- Per-module ARMED granularity.

## Steps
1. Add `lib/armed.jsx` with `ArmedProvider`, `useArmed()`, and a frozen list of write-class service IDs.
2. Wrap the app root in `<ArmedProvider>`. Add the toggle UI to the header in App.jsx with a clear visual difference (green SAFE / red ARMED, plus a "● ARMED" banner under the tab bar when on).
3. Update `bridgeEngine.js` (or wrap its `uds()` call site) to consult `useArmed()` for any service in the write-class list and refuse with a typed error otherwise.
4. Update each call site that issues writes — BcmTab, RfhubTab, EcmTab, AdcmTab, ImmoVINTab, JailbreakTab, UdsTab raw command — to handle the refusal gracefully (toast the "toggle ARMED" message instead of throwing into a generic catch).
5. Smoke-test: in SAFE mode, run a full read sweep on OBDTab and confirm no writes are issued; toggle ARMED, do a known-safe write, confirm it succeeds.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/bridgeEngine.js`
- `artifacts/srt-lab/src/lib/obdEngine.js`
- `artifacts/srt-lab/src/tabs/BcmTab.jsx`
- `artifacts/srt-lab/src/tabs/RfhubTab.jsx`
- `artifacts/srt-lab/src/tabs/EcmTab.jsx`
- `artifacts/srt-lab/src/tabs/AdcmTab.jsx`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
- `artifacts/srt-lab/src/tabs/JailbreakTab.jsx`
- `artifacts/srt-lab/src/tabs/UdsTab.jsx`
- `artifacts/srt-lab/src/tabs/OBDTab.jsx`
