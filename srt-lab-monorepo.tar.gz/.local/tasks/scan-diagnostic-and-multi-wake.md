# Scan: Add Failure Logging + Multi-Wake Strategy

## What & Why
Scan finds only ECM despite 6 modules connected on bench (ECM, BCM, RFHUB, DAMP, IPC, RADIO). The `uds()` function silently returns `{ok:false}` when modules don't respond, providing zero visibility. Additionally, different modules may need different wake-up strategies.

## Done looks like
- `uds()` returns the raw adapter response string on failure (e.g. "NO DATA") so callers can log it
- Scan logs each module attempt with the raw failure reason when a module doesn't respond
- Scan tries multiple wake strategies per module: `10 01` (default session), then `10 03` (extended session), then `3E 00` (tester present)
- If any wake strategy gets a positive UDS response, proceed to VIN read
- Per-module status shown in log: "ECM: VIN found", "BCM: NO DATA", "RFHUB: trying extended session..." etc.
- No changes to connect(), send(), init sequence, or prompt detection

## Changes

### 1. uds() — return raw response on failure (~line 827)
Change `return{ok:false}` to `return{ok:false,raw:r}` so the raw adapter string is available to callers. Both failure paths (regex match and no hex lines) should include the raw response.

### 2. scan callback — multi-wake + logging (~line 854)
For each module:
  a. Log "Trying [MODULE]..." 
  b. Try wake with 10 01 (default session), 100ms delay
  c. If wake failed, try 10 03 (extended session), 100ms delay
  d. If still failed, try 3E 00 (tester present), 100ms delay
  e. If any wake succeeded, attempt 22 F1 90 VIN read
  f. Log outcome: VIN found, present but no VIN, or failure reason (raw response)
  g. 100ms inter-module delay (existing)

## Out of scope
- Changing connect/send internals
- Changing AT init sequence
- Changing baud rate or prompt detection
- Changing the BENCH tab

## Relevant files
- `artifacts/srt-lab/src/App.jsx` — uds() at ~line 827, scan at ~line 854
