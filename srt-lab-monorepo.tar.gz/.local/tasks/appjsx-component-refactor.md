# Split App.jsx Into Component Files

## What & Why
The entire SRT Lab application lives in a single ~1500-line `App.jsx` file. Every tab (DumpsTab, OBDTab, BenchTab, SeedTab, GpecTab, SecurityTab, Gpec2aTab) is defined inline alongside shared utilities, CRC functions, the MODS array, and the root App component. This makes parallel development error-prone (merge conflicts on every feature branch) and the file very hard to navigate. Splitting each tab into its own file is the single most impactful structural change for long-term maintainability.

## Done looks like
- Each major tab is its own file under `artifacts/srt-lab/src/tabs/` (e.g., `DumpsTab.jsx`, `OBDTab.jsx`, `BenchTab.jsx`, `SeedTab.jsx`, `GpecTab.jsx`, `SecurityTab.jsx`, `Gpec2aTab.jsx`)
- Shared utilities (CRC functions, `parseModule`, `virginizeModule`, `MODS`, constants, color tokens) are extracted to `artifacts/srt-lab/src/lib/` files
- `App.jsx` becomes a thin shell: imports tabs, renders the tab bar, manages only top-level shared state
- `FcaAnalyzerTab.jsx` is moved into the same `tabs/` directory and its import in `App.jsx` updated
- The application builds without errors and all tabs function identically to before the refactor
- No features are added or removed — this is a pure structural change

## Out of scope
- Any feature changes, bug fixes, or UI changes
- Changes to `main.tsx`, `vite.config.*`, or build configuration

## Tasks
1. **Extract shared utilities** — move CRC functions, `parseModule`, `virginizeModule`, `MODS`, `ALGOS`, constants, and color tokens (`C`) into dedicated files in `src/lib/`.
2. **Extract tab components** — move each tab component into its own file in `src/tabs/`; update all imports and ensure shared state props are passed correctly.
3. **Slim down App.jsx** — reduce `App.jsx` to the root component with tab bar, shared state, and tab rendering only.
4. **Verify build and runtime** — confirm `vite build` passes with no errors and every tab works correctly after the split.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/FcaAnalyzerTab.jsx`
- `artifacts/srt-lab/src/main.tsx`
