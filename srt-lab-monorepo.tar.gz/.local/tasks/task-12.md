---
title: Revert OBD Connect to Original
---
# Revert OBD Connect to Original

## What & Why
Tasks #10 and #11 changed the `connect()` function, `send()` function, added baud rate state/dropdown, and modified the init sequence. These changes broke the working OBDLink EX connection. The connect and send functions must be reverted to their exact pre-Task #10 state. Only the `uds()` response parser (inside `eng.current`) should retain the Task #10 improvements for CAN header stripping and PCI byte handling.

## Done looks like
- Connect button works exactly as it did before Task #10 — immediate connection at 115200, no baud dropdown
- `send()` function is identical to pre-Task #10 (simple `buf.includes('>')` check, no control-char normalization)
- Init sequence is identical: ATZ (3s) → 500ms delay → ATI (default 2s timeout) → ATE0/ATL0/ATS1/ATH1/ATCAF1/ATCFC1/ATAL/ATSP6 (default 2s, 80ms gap)
- No baud rate state, no baud dropdown in UI
- `uds()` response parser retains Task #10 improvements: CAN ID header stripping, PCI byte stripping, contiguous hex fallback, 3000ms AT timeouts within uds(), 50ms inter-command delays

## Out of scope
- Any other changes to the OBD tab

## Tasks
1. Remove `baud` state and baud rate dropdown from OBDTab.
2. Revert `connect()` to exact pre-Task #10 code: hardcoded 115200 baud, original `send()` with simple `buf.includes('>')`, original init sequence timing.
3. Keep only the improved `uds()` function body (CAN header/PCI parsing, increased AT timeouts, inter-command delays).

## Relevant files
- `artifacts/srt-lab/src/App.jsx:808-853`
- `artifacts/srt-lab/src/App.jsx:921-924`