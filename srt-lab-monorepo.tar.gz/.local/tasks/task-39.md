---
title: TWIN tab: accept all GPEC2A file sizes
---
# TWIN tab: accept all GPEC2A sizes

## What & Why
The TWIN tab rejects any GPEC2A file that isn't exactly 8192 bytes. In reality
GPEC2A dumps come in three sizes — 4096 B (half-size read), 8192 B (standard),
and 16384 B (double-read). Every other tab in the app (DUMPS, IMMOVIN, GPEC2A,
SECURITY) already handles all three. The VIN (0x0000) and SEC6 (0x03C8) offsets
are identical across all three sizes, so no offset logic changes are needed.

## Done looks like
- Dropping or clicking a 4096-byte or 16384-byte GPEC2A bin into the PCM zone
  no longer shows an error; the file is accepted and parsed correctly
- The BCM card subtitle shows the actual file size instead of hardcoded "8192 bytes"
- All three APPLY buttons still work for all valid GPEC2A sizes

## Out of scope
- Changes to RFH or BCM parsing
- Any tab other than TwinTab.jsx

## Tasks
1. **Relax the size guard** — In `parsePcm()` change the strict `=== 8192` check
   to accept 4096, 8192, or 16384 bytes; return null for anything else.
2. **Relax the validation error** — Update the pre-inspect validation block that
   pushes an error for wrong PCM size to match the same three accepted sizes.
3. **Fix the subtitle** — The PcmCard subtitle currently hardcodes "8192 bytes";
   change it to display `info.size` so 4096 B and 16384 B files show correctly.

## Relevant files
- `artifacts/srt-lab/src/tabs/TwinTab.jsx:193-201`
- `artifacts/srt-lab/src/tabs/TwinTab.jsx:588-597`
- `artifacts/srt-lab/src/tabs/TwinTab.jsx:403-410`