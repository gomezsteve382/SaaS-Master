---
title: Fix 95640 EEPROM CRC-8 Algorithm (poly 0x0C → 0x42)
---
# Fix 95640 EEPROM CRC-8 Algorithm

  ## What & Why
  The 95640 EEPROM CRC-8 checksum uses the wrong polynomial. Currently the app uses `crc8a` (poly 0x0C, init 0x0C, reflected input) for 95640 files, but real ECU dumps use CRC-8 forward with polynomial 0x42. Verified against a known-good original + patched pair: original VIN "1C4RJFN9XJC309165" → CRC 0xCC, patched VIN "1C4RJFDJ7DC513874" → CRC 0xE8. Our current algorithm produces wrong values for both.

  ## Done looks like
  - Loading a 95640 EEPROM shows CRC8 ✓ (green) for known-good files
  - VIN patching a 95640 writes the correct CRC-8 byte (poly 0x42 forward) at offset-1
  - The BENCH tab CRC patch also uses the corrected algorithm for 95640 modules
  - The Virginizer clears CRC bytes correctly
  - Verified against the reference files: poly=0x42 produces 0xCC for "1C4RJFN9XJC309165" and 0xE8 for "1C4RJFDJ7DC513874"

  ## Out of scope
  - BCM CRC-16 (already correct)
  - RFHUB CRC-8 reflected (already correct with crc8rf)
  - GPEC2A (no CRC)
  - CRC-16 at offset+17/+18 in 95640 — intentionally NOT updated (matches reference tool behavior)

  ## Tasks
  1. Add a new `crc8_42` function implementing CRC-8 forward with poly=0x42 and init=0x00.
  2. Replace all `crc8a(...)` calls that operate on 95640 VIN data with `crc8_42(...)` — in `analyzeFile`, `patchFile`, `writeModuleVIN` (the bench helper), and `doCrcPatch`.
  3. Remove the `crc8a` function and `reflect8` helper if no longer used anywhere.
  4. Verify the BENCH tab's CRC8 display for 95640 modules also uses the new function.

  ## Relevant files
  `artifacts/srt-lab/src/App.jsx:1-15`
  `artifacts/srt-lab/src/App.jsx:160-210`
  `artifacts/srt-lab/src/App.jsx:300-330`