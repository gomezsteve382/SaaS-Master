---
title: Fix ELM327 v1.4b Compatibility — ATCRA, Reader, ATSTFF
---
# Fix ELM327 v1.4b Compatibility — ATCRA, Reader, ATSTFF

## What & Why
Three issues preventing module discovery on ELM327 v1.4b clone:
1. `ATAR` (line 830) is STN/OBDLink-only. ELM327 returns `?`. Without ATCRA, no receive filter = broken multi-frame flow control.
2. `TextDecoderStream` + `pipeTo` pattern (lines 820-822, 336-338) is unreliable for serial reads.
3. No `ATSTFF` in init — ELM327 defaults to short CAN timeout, bench modules respond slower.

## Done looks like
- LIVE OBD `uds()`: `ATAR` replaced back with `ATCRA` + specific RX address
- Both OBD and BENCH connect: `TextDecoderStream`/`pipeTo` replaced with direct `port.readable.getReader()` + `new TextDecoder()` 
- Both init sequences include `ATSTFF` (max CAN timeout)
- Scan inter-module delay increased to 200ms
- ECM and other modules discovered on bench

## Changes

### 1. LIVE OBD connect (~line 815)
Replace lines 820-822:
```
const dec=new TextDecoderStream();port.readable.pipeTo(dec.writable).catch(()=>{});
const rd=dec.readable.getReader();let buf='';
(async()=>{try{while(true){const{value,done}=await rd.read();if(done)break;if(value)buf+=value;}}catch(e){}})();
```
With direct reader:
```
const rd=port.readable.getReader();const td=new TextDecoder();let buf='';
(async()=>{try{while(true){const{value,done}=await rd.read();if(done)break;if(value)buf+=td.decode(value,{stream:true});}}catch(e){}})();
```

### 2. LIVE OBD uds() (~line 830)
Replace `await send('ATAR',3000);` back with `await send('ATCRA'+rx.toString(16).toUpperCase().padStart(3,'0'),3000);`

### 3. LIVE OBD init (~line 826)
Add `ATSTFF` to init command list: `['ATE0','ATL0','ATS1','ATH1','ATCAF1','ATCFC1','ATAL','ATSP6','ATSTFF']`

### 4. BENCH connect (~line 330)
Same TextDecoderStream fix as OBD connect (lines 336-338).
Add `ATSTFF` to bench init command list (line 342).

### 5. Scan inter-module delay (~line 875)
Increase from 100ms to 200ms: `setTimeout(r,200)` in finally block

## Out of scope
- Changing send() logic or prompt detection
- Changing scan wake strategy order
- Changing response parser

## Relevant files
- `artifacts/srt-lab/src/App.jsx` — OBD connect ~815, BENCH connect ~330, scan ~854