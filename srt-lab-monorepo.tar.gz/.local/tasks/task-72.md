---
title: Unlock body modules on LIVE OBD via STN extended mode
---
# Unlock body modules on LIVE OBD via STN extended mode

## What & Why
Right now LIVE OBD only talks to the engine module (ECM at 0x7E0/0x7E8). Every body
module on the bench — BCM, IPC, RFHUB, ABS, ORC, ADCM — comes back as **NO DATA**,
even though Autel and AlphaOBD scan all of them on the *same bench, same OBDLink EX*.
The bench-side debug log narrowed it down: the OBDLink EX in default mode only
processes standard OBD-II CAN IDs (0x7E0–0x7EF). All FCA body modules live above
that, in the 0x600–0x7FF range, and the adapter's CAN controller silently drops
those frames unless we set two STN programmable parameters at init time:

- `PP 2C = 0x81` → MFG extended mode (opens the full 0x600–0x7FF CAN ID range)
- `PP 2D = 0x01` → CAN protocol options (ISO-TP padding + auto FC + multi-frame)

A previous attempt to add these crashed the adapter into permanent `CAN ERROR` on
every module (including ECM) because the post-PP `ATZ` was too quick. The known-good
recipe from the working AlphaOBD reference uses **`ATZ` 3000 ms + 1000 ms settle**
after the PP writes, plus a recovery button that runs `ATPP2COFF / ATPP2DOFF /
ATPPSOFF / ATD / ATZ` to wipe the parameters back to defaults if anything goes
sideways.

This task ports just that init delta into LIVE OBD — the smallest possible change
that turns a bench full of "NO DATA" into a real module list.

## Done looks like
- Connecting to the OBDLink EX still works (no regression on ECM scan).
- An "Extended Mode (STN)" toggle appears in the connect bar, defaulted **on** when
  an STN chipset is detected, and disabled/hidden on generic ELM327 adapters.
- With Extended Mode on, scanning the bench reports body modules — at minimum BCM,
  IPC, and RFHUB — as alive, with VINs read where available.
- A small "Reset Adapter" recovery button is visible whenever connected; pressing
  it runs the documented restore sequence and reports success in the traffic log.
- The traffic log shows the new init phase (`PP 2C ← 81`, `PP 2D ← 01`, `ATZ
  3000 ms`, `settled`) so the operator can confirm extended mode came up clean.
- If a `CAN ERROR` appears on any module within the first 3 seconds after init,
  the UI surfaces a one-line hint pointing the operator at the recovery button —
  no silent failures.
- Existing CAN-IHS bus switching, single-module write helpers, BCM Proxi /
  SKIM read, RFHUB virginize, CAN monitor, and the JAILBREAK / DUMPS / SEED→KEY
  flows are untouched.

## Out of scope
- Re-validating or rewriting the multi-address candidate table in `lib/mods.js`.
  The current table already lists BCM at 0x750/0x758 and RFHUB at 0x75F/0x767,
  which match the CDA6 reference; address-table reconciliation is its own task.
- The companion `OBDSwarmDiagnostic.jsx` and the SWARM tab — they reuse the same
  init via the parent module, so they pick up the fix automatically; no
  separate changes needed.
- The desktop J2534 path (`srt_lab.py`, `j2534_bridge.py`). This is the in-browser
  WebSerial path only.
- Persisting the Extended Mode toggle across page reloads. Session-only is fine.

## Tasks
1. **Add the STN programmable-parameter init phase to the LIVE OBD connect
   sequence.** After the existing STN detection branch, write `PP 2C = 0x81` and
   `PP 2D = 0x01`, then run a single `ATZ` with a 3000 ms timeout followed by a
   1000 ms settle and a fresh `ATE0`. Re-apply the existing CAN config (`ATL0 /
   ATS1 / ATH1 / ATSP6 / ATAT2 / ATST96 / ATCAF1 / ATFCSH / ATFCSD300000 /
   ATFCSM1`) after the reset since the PP writes wipe them.

2. **Gate the extended-mode init behind an "Extended Mode (STN)" toggle in the
   connect bar.** Default on for STN chipsets, hidden for generic ELM327. The
   toggle's value at connect time decides whether the PP writes happen; flipping
   it after connect is a no-op until the next reconnect (annotate this in the
   tooltip).

3. **Add a "Reset Adapter to Factory" button to the Quick Tools row.** When
   pressed, it runs `ATPP2COFF / ATPP2DOFF / ATPPSOFF / ATD / ATZ` with
   appropriate inter-command delays, then closes and reopens the serial port so
   the next connect starts from a clean slate. Surface the result in the traffic
   log.

4. **Detect early CAN-error bricking.** If the first scan after a fresh
   extended-mode init returns `CAN ERROR` on the very first module probed,
   abort the scan and post a single highlighted log line: "Adapter rejected
   extended mode — press Reset Adapter to recover, then reconnect with Extended
   Mode off."

5. **Verify on the bench.** With Extended Mode on, the scan should pull at least
   BCM/IPC/RFHUB out of NO DATA and into the found-modules grid. With Extended
   Mode off, behavior is identical to today (only ECM/TCM respond). If the
   recovery button is pressed, a subsequent connect with Extended Mode off
   should still hit ECM cleanly.

## Relevant files
- `artifacts/srt-lab/src/tabs/OBDTab.jsx`
- `artifacts/srt-lab/src/lib/mods.js`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx`
- `attached_assets/alphabcm_1776440430460.zip`