# Restore CRC Patch & Trackhawk SKIM Key Grid

  ## What & Why
  The original SRT Lab had a CRC patch function and Trackhawk-specific SKIM key grid that were lost during the SECURITY tab rebuild. The original code included:
  - `SKIM_OFF` config with Trackhawk (base `0x2000`) and SRT (base `0x40C0`) SKIM key memory regions, each with 6 key slots of 18 bytes
  - A SKIM Key Grid UI showing keys at both Trackhawk and SRT offsets from BCM D-Flash dumps
  - Per-module CRC patching via `patchV()` that applied correct CRC16 (BCM), CRC8 (95640), mirrored bytes (RFHUB), and plain ASCII (GPEC2A) when writing VINs

  These need to be restored so users can:
  1. See Trackhawk vs SRT SKIM key slots from BCM dumps
  2. CRC-patch any module after manual hex edits (recalculate all checksums in a .bin file)

  ## Done looks like
  - BENCH tab "Quick Tools" has a new **"CRC Patch"** button: loads a .bin, scans for all VIN/data locations, recalculates and fixes CRC16/CRC8/RFHUB boot checksums, downloads corrected file, and logs every offset with old→new CRC values
  - SECURITY tab Overview sub-view includes a **SKIM Key Grid** section when a BCM is loaded, showing:
    - Trackhawk keys at `0x2000` (6 slots × 18 bytes) — only if data is present
    - SRT keys at `0x40C0` (6 slots × 18 bytes) — only if data is present
    - Each slot shows key number, hex bytes, and SET/EMPTY tag
    - "Copy Keys" button to clipboard
  - The original `SKIM_OFF` constant is restored: `[{v:'Trackhawk',base:0x2000,ks:18,kc:6},{v:'SRT',base:0x40C0,ks:18,kc:6}]`

  ## Out of scope
  - Modifying SKIM keys (read-only display)
  - Adding new CRC algorithms beyond CRC16/CRC8/RFHUB boot checksum
  - Changes to the GPEC or GPEC2A tabs

  ## Tasks
  1. Add `SKIM_OFF` constant with Trackhawk and SRT configs to App.jsx (near other constants at top of file)
  2. In the SECURITY tab `SecurityTab` component, add a `skimG` useMemo that extracts SKIM key slots from the loaded BCM module at both Trackhawk (0x2000) and SRT (0x40C0) base offsets — matching the original `skimG` logic from git commit `4b3802a`
  3. Render the SKIM Key Grid in the Overview sub-view of the SECURITY tab: show variant label (Trackhawk/SRT), base offset, 3-column grid of key slots with hex bytes and SET/EMPTY tags, plus a "Copy Keys" button
  4. Add a `doCrcPatch` function to the BENCH tab that: takes a loaded module, scans all VIN locations, recalculates CRC16 (for BCM VINs), CRC8 (for 95640 VINs), RFHUB boot checksum (sum of 17 bytes), validates/fixes each, logs old→new values, and downloads the patched file
  5. Add a "CRC Patch" button in BENCH Quick Tools section for each loaded module (or a global "CRC Patch All" button)
  6. Test all tabs still render, CRC Patch button appears in BENCH, SKIM Key Grid appears in SECURITY when BCM is loaded

  ## Relevant files
  `artifacts/srt-lab/src/App.jsx`
  `artifacts/srt-lab/src/App.jsx:1-10` (CRC functions)
  `artifacts/srt-lab/src/App.jsx:242-338` (BENCH tab)
  `artifacts/srt-lab/src/App.jsx:340-405` (SECURITY tab state/functions)
  `artifacts/srt-lab/src/App.jsx:420-460` (SECURITY tab Overview sub-view)
  