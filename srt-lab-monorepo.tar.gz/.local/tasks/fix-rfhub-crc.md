# Fix RFHUB CRC Algorithm

## What & Why
The RFHUB checksum algorithm is wrong — currently using a simple byte-sum, but the correct algorithm is CRC-8 Reflected (poly=0xA0, init=0x54). This was discovered by examining the reference VINPatcher source code from the project's attached zip files.

The RFHUB stores VINs mirrored (byte-reversed) at 4 offsets (0xEA5, 0xEB9, 0xECD, 0xEE1) with a CRC-8 byte at offset+17 computed over the stored (reversed) bytes.

## Done looks like
- A new `crc8rf` function implementing CRC-8 Reflected with poly=0xA0, init=0x54.
- `analyzeFile` (DUMPS tab) validates RFHUB CRC instead of blindly setting `ok:true`.
- `patchFile` computes correct reflected CRC-8 when writing mirrored RFHUB VINs (instead of byte-sum).
- `parseModule` (ANALYZER tab) validates RFHUB CRC correctly.
- `writeModuleVIN` computes reflected CRC-8 instead of byte-sum for both mirrored and non-mirrored RFHUB paths.
- CRC tag in the UI shows CRC8 pass/fail status instead of the generic "Boot CRC" label for RFHUB.

## Out of scope
- RFHUB dump validation against real Charger hardware (no real 4KB RFHUB dump available yet).
- Changes to 95640 CRC (already fixed with poly=0x0C).
- Changes to BCM CRC16 (already correct).

## Tasks
1. **Add `crc8rf` function** — CRC-8 Reflected, poly=0xA0, init=0x54, alongside the existing `crc8a` and `crc16` functions.
2. **Fix `analyzeFile` RFHUB parsing** — Validate CRC at offset+17 using `crc8rf` on stored (mirrored) bytes instead of setting `ok:true`.
3. **Fix `patchFile` RFHUB branch** — Replace byte-sum with `crc8rf` on the reversed VIN bytes.
4. **Fix `writeModuleVIN` RFHUB branches** — Replace byte-sum with `crc8rf` in both the mirrored and non-mirrored code paths.
5. **Fix `parseModule` RFHUB CRC validation** — Validate CRC using `crc8rf` instead of blindly marking ok.
6. **Update UI CRC tag** — Show CRC8 pass/fail for RFHUB slots instead of generic "Boot CRC" label.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:5-7`
- `artifacts/srt-lab/src/App.jsx:155-213`
- `artifacts/srt-lab/src/App.jsx:893`
