# Hoist hex offsets to lib/moduleLayout.js

## What & Why
The same per-module hex offsets are copy-pasted across 4-7 files: BCM VIN slots `[0x5320,0x5340,0x5360,0x5380]`, RFH VIN slots `[0xEA5,0xEB9,0xECD,0xEE1]`, BCM partial VIN `[0x4098,0x40B0]`, IMMO base/backup `0x40C0`/`0x2000`, IMMO block size, 95640 VIN `[0x275,0x288]`, BCM vehicle secret `0x40C9`, GPEC2A VIN `[0x0000,0x01F0,0x0224]`, GPEC2A secret-key/mirror `0x0203`/`0x0361`, transponder keys `0x0888+i*4`, etc. Centralizing them means a new offset for a Gen3 module changes one file, not seven.

## Done looks like
- A new `artifacts/srt-lab/src/lib/moduleLayout.js` exports a single `LAYOUT` map keyed by module type (`BCM`, `RFHUB`, `GPEC2A`, `95640`, `PCM`, `RFH_GEN2`) with all VIN/partial/secret/IMMO/key offsets, region sizes, and known magic constants.
- `lib/parseModule.js`, `lib/fileUtils.js`, every per-ECU tab (`BcmTab`, `RfhubTab`, `EcmTab`, `AdcmTab`, `SecurityTab`, `TwinTab`, `ImmoVINTab`, `Gpec2aTab`), and any helper that hardcodes those addresses imports from `lib/moduleLayout.js` instead.
- `grep -rn "0x5320\|0x5340\|0x5360\|0x5380\|0xEA5\|0xEB9\|0xECD\|0xEE1\|0x4098\|0x40B0\|0x40C0\|0x2000\|0x40C9" artifacts/srt-lab/src` reports zero hits outside `lib/moduleLayout.js`.
- All tests still pass.

## Out of scope
- Changing what those offsets are or adding support for new modules.
- Refactoring the parsers themselves — only the offset literals move.

## Steps
1. Catalog every hex offset literal currently used in parsers, writers, and tabs. Group by module type and by purpose (vin / partial-vin / vin-cs / vehicle-secret / immo / immo-backup / key-mirror / transponder / fobik-count / pcm-sec6).
2. Define `LAYOUT` in `lib/moduleLayout.js` as a frozen object, e.g. `LAYOUT.BCM = { vin: [0x5320,...], partialVin: [0x4098,0x40B0], immoBase: 0x40C0, immoBackup: 0x2000, immoBlock: IMMO_BLOCK, vehicleSecret: 0x40C9, immoKeys: [0x81A4,0x81C4,0x81E4], fobikParts: 0x5818 }`. Re-export the existing IMMO_BLOCK / IMMO_REC / IMMO_KC from constants so layout is self-contained.
3. Replace every literal in the consumers with the `LAYOUT.<type>.<field>` reference. Where a loop iterates VIN slots, iterate `LAYOUT.<type>.vin` instead.
4. Sanity-grep the codebase for stragglers and re-run tests.

## Relevant files
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/fileUtils.js`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/tabs/BcmTab.jsx`
- `artifacts/srt-lab/src/tabs/RfhubTab.jsx`
- `artifacts/srt-lab/src/tabs/EcmTab.jsx`
- `artifacts/srt-lab/src/tabs/AdcmTab.jsx`
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx`
- `artifacts/srt-lab/src/tabs/TwinTab.jsx`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
- `artifacts/srt-lab/src/tabs/Gpec2aTab.jsx`
- `artifacts/srt-lab/src/lib/__fixtures__/buildFixtures.js`
