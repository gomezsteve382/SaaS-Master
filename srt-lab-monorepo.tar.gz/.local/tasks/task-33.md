---
title: ImmoVIN Tab — Replace ST95640+BCM with RFHUB EEE + GPEC2A
---
---
title: ImmoVIN Tab — Replace with RFHUB EEE + GPEC2A (was ST95640 + BCM)
---

# ImmoVIN Tab — Fix Module Sections: RFHUB + GPEC2A

## What & Why
Task #32 built ImmoVINTab with the wrong modules. The two sections must be replaced:
- Section 1: ST95640 8KB EEPROM → **RFHUB EEE** (24C32, 4KB, mirrored VINs + CRC8RF)
- Section 2: BCM MPC5606B 64KB D-Flash → **GPEC2A** (95320 SPI, 4KB, plain VINs + secret key)

The two-phase Inspect / Apply UX pattern is correct and must be kept.

## Section 1 — RFHUB EEE (24C32, 4096 bytes)

### INSPECT
File size check: 4096 bytes (exactly). Also accept 2048 bytes (Gen1 24C16).

Extract and display:
- VIN slots at 0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1 (4 slots, 17 bytes each)
  - Encoding: byte-mirrored (bytes stored reversed, so decode by reversing 17 bytes)
  - CRC8RF: polynomial 0x1D, no initial value inversion (use existing crc8rf from crc.js)
  - CRC stored at offset+17 (1 byte). Show stored vs calculated, OK/FAIL badge.
- SEC16 slot 1 at 0x00AE (16 bytes + 2-byte XOR checksum at 0x00BE)
- SEC16 slot 2 at 0x00C0 (16 bytes + 2-byte XOR checksum at 0x00D0)
  - XOR checksum: csCalc = 0; for i in 0..15: csCalc ^= raw[i]; stored as (csCalc<<8)|csCalc
  - Show both slot hex strings, their match status (VALID if slot1==slot2 and non-blank)
- Secret key at 0x0040 (16 bytes) — show hex, note if all FF (blank/erased)

### APPLY
- New VIN (17 chars): write byte-reversed to all 4 VIN slots; recalculate CRC8RF
  of the reversed array; store at slot_offset+17
- Download as <original>_RFHVIN_<VIN>.bin

## Section 2 — GPEC2A (95320 SPI EEPROM, 4096 bytes)

### INSPECT
File size check: 4096 bytes exactly.

Extract and display:
- VIN slot 1 at 0x0000 (17 bytes, plain ASCII, no CRC)
- VIN slot 2 at 0x01F0 (17 bytes, plain ASCII, no CRC)
- VIN slot 3 at 0x0224 (17 bytes, plain ASCII, no CRC)
  - Valid VIN chars: A-HJ-NPR-Z 0-9 (strict regex, no I/O/Q)
  - Show each slot: offset, VIN string or "(empty/invalid)", consistency badge
  - If all three match → "CONSISTENT ✓"; any mismatch → "MISMATCH ✗"
- Secret key PRIMARY at 0x0203 (8 bytes) — hex display
- Secret key MIRROR at 0x0361 (8 bytes) — hex display
  - Consistency badge: ✓ if both match, ✗ if not
- SKIM byte at 0x0011: 0x80 = ENABLED, 0x00 = DISABLED, other = UNKNOWN
- PCM SEC6 at 0x03C8 (6 bytes): show hex; if all FF → tag "IMMO_DAMAGED"

### APPLY
- New VIN (17 chars, optional): write ASCII to all 3 slots (0x0000, 0x01F0, 0x0224), no CRC
- New secret key (16 hex digits = 8 bytes, optional): write to PRIMARY (0x0203) AND MIRROR (0x0361)
- Download as <original>_GPEC_<VIN or NOVIN>.bin

## Implementation notes
- Import crc8rf from "../lib/crc.js" (already exists, same algo used throughout)
- Both file size validations should be strict (error message if wrong size, clear state)
- Keep Badge, FileDropZone, SectionHeader helper components from current file
- Only file to modify: artifacts/srt-lab/src/tabs/ImmoVINTab.jsx (full rewrite of parse/apply/UI logic)
- App.jsx does NOT need changes (tab ID/title/nav stays the same)
- Build must pass with no errors after the change

## Files to modify
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx` — rewrite both module sections

## Out of scope
- App.jsx tab registration
- SecurityTab, OBDTab, or any other tab