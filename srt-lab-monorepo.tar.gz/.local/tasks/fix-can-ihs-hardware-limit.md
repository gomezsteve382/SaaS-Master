# CAN-IHS: Fast-fail + Gateway Fallback

## What & Why

`CAN ERROR` on every IHS module is a hardware constraint, not a protocol bug.
The OBDLink EX CAN transceiver is soldered to OBD-II pins 6/14 (HS-CAN) only.
`STP61` sets a firmware flag but the second physical CAN port is not wired to
pins 3/11 on this adapter — so every TX into "CAN-B" fires into a floating bus
and returns `CAN ERROR`. No software bitrate or protocol tweak can fix this.

Two changes are needed:

**1. Fast-fail the IHS direct sweep**
On the FIRST `CAN ERROR` in the IHS loop, break immediately. Don't waste
10+ seconds retrying 10 more dead modules. Log a definitive hardware-limit
message: "CAN-IHS direct scan requires a physical Y-cable to pins 3/11 —
OBDLink EX CAN transceiver wired to pins 6/14 only."

**2. Gateway fallback on HS-CAN (after restoring the bus)**
Many FCA vehicles (KL Cherokee, WK2, etc.) have a Gateway module on CAN-C
that forwards diagnostic requests to IHS modules. After restoring HS-CAN,
probe each IHS module's address directly over CAN-C (no bus switch) using
a single TesterPresent (3E 00). If a module responds, it is reachable via
gateway — scan its VIN (22 F1 90) and add it to found[]. Log clearly:
"BCM via gateway" etc. If none respond, log "No IHS modules reachable via
gateway — physical Y-cable required" and finish cleanly.

## Done looks like
- On CAN ERROR for BCM, the log immediately shows the hardware-limit notice
  and skips the remaining IHS modules (no 10-second wait).
- After restoring HS-CAN, a short "Gateway probe" sweep is logged.
- Any module reachable through the gateway appears in the found[] list with
  a "(via GW)" label in the vin field prefix.
- If no gateway response, a single clear message is logged and scan ends.

## Out of scope
- Changes to parsers, DUMPS tab, SECURITY tab, or any other tab.
- Permanently removing the STP61/STPBR 125000 direct sweep — keep it in case
  users have a Y-cable; just fail fast and try gateway after.

## Tasks
1. In the IHS scan loop, check if `r.raw` contains `CAN ERROR` after a `uds()`
   call. On first hit, log the hardware-limit notice and `break` the loop.
2. After the STPBR 500000 / ATSP6 return sequence, add a second gateway-probe
   loop: send TesterPresent to each IHS module's TX/RX on HS-CAN (no bus
   switch). On success, read VIN (22 F1 90) and push `{...m, vin: '(via GW) '+vin}`
   to found[]. Log each attempt result. If zero respond, log the Y-cable notice.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:1086-1107`
