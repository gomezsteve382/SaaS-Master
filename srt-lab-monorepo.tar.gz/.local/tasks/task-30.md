---
title: J2534 Raw CAN Tab
---
---
  title: J2534 Raw CAN Tab
  ---
  # J2534 Raw CAN Tab

  ## What & Why
  Add a new tab (⚡ J2534 · "Raw CAN PassThru") that bypasses ELM327 entirely and talks raw ISO 15765 CAN via the Windows J2534 PassThru DLL. This directly solves the CAN-IHS body-module access problem — where OBDLink EX's ELM327 path can't reach BCM/IPC/RFHUB because the transceiver is wired only to pins 6/14, but a J2534-compliant adapter with full dual-bus support can reach them. The user runs a lightweight local Python bridge (j2534_bridge.py) that opens a WebSocket on ws://localhost:8765; the browser connects to it and exchanges JSON UDS commands.

  Two reference implementations are provided in the attached zip (already extracted to attached_assets/):
  - **Scanner component**: `attached_assets/zip_J2534Scanner.jsx` — full `J2534Scanner` React component; integrate as-written
  - **Bridge script**: `attached_assets/zip_j2534_bridge.py` — Python 3 WebSocket bridge; needs to be served for download from the tab

  ## Done looks like
  - **New ⚡ J2534 tab** appears in the SRT Lab tab bar after SWARM, subtitle "Raw CAN PassThru"
  - **J2534Scanner.jsx** lives at `artifacts/srt-lab/src/J2534Scanner.jsx`, copied from reference with only the import path resolved
  - **j2534_bridge.py** is stored at `artifacts/srt-lab/public/j2534_bridge.py` so the browser can download it
  - The J2534 tab renders a download link for `j2534_bridge.py` before the scanner controls
  - The scanner component connects to `ws://localhost:8765`, lists J2534 devices, opens the adapter, and scans all 33 FCA module addresses
  - Build (`PORT=3000 BASE_PATH=/srt-lab pnpm --filter @workspace/srt-lab run build`) passes with no errors

  ## Out of scope
  - Modifying the scanner's internal logic or the bridge's CAN protocol handling
  - DUMPS, BENCH, SEED, GPEC, SECURITY, GPEC2A, ANALYZER, SWARM tab changes
  - Running the Python bridge in the Replit environment (it runs on the user's laptop)
  - Any server-side changes

  ## Tasks
  1. **Copy J2534Scanner.jsx** — write `artifacts/srt-lab/src/J2534Scanner.jsx` from `attached_assets/zip_J2534Scanner.jsx`; add a styled download link for `j2534_bridge.py` above the scanner controls (inline, before the main Btn row)
  2. **Serve bridge script** — copy `attached_assets/zip_j2534_bridge.py` to `artifacts/srt-lab/public/j2534_bridge.py` so Vite serves it as a static asset
  3. **Add J2534 tab** — add `{id:'j2534',i:'⚡',l:'J2534',s:'Raw CAN PassThru'}` to the TABS array in `App.jsx` (after `swarm`); import `J2534Scanner` and render `{pg==='j2534'&&<J2534Scanner/>}`
  4. **Verify build** — confirm `vite build` passes with no errors and the new tab renders

  ## Relevant files
  - `artifacts/srt-lab/src/App.jsx` — TABS array (line ~390), tab render (line ~416)
  - `artifacts/srt-lab/src/J2534Scanner.jsx` — to be created
  - `artifacts/srt-lab/public/j2534_bridge.py` — to be created
  - `attached_assets/zip_J2534Scanner.jsx` — reference source
  - `attached_assets/zip_j2534_bridge.py` — bridge script source