# JAILBREAK / Module UDS Workshop Tab

## What & Why
Add an 11th tab — **JAILBREAK OPTIONS** — that turns SRT Lab into a real over-OBD module workshop for FCA cars. It connects to a vehicle through an OBDLink EX (or any ELM327/STN-compatible adapter) over Web Serial, lets the user pick a target module (BCM CDA6 by default, ADCM Active Damping as a second one-click target, plus a custom TX/RX entry), unlocks it with the CDA6 algorithm when needed, and exposes:

1. **The 50-feature SRT/Demon/Hellcat hidden-options unlocker** against the BCM (DIDs `0xDE01` / `0xDE02`) — launch control, trans brake, drag mode, SRT performance pages, after-run chiller, valet limits, etc. — with four one-click profiles (SRT Full, Demon Package, Hellcat, Track Mode) and batched DID writes.
2. **Generic UDS service buttons** that work against whichever module is currently selected:
   - **Read DTCs** — UDS `0x19 02 08` (ReportDTCByStatusMask, mask 0x08 = confirmed) with multi-frame ISO-TP reassembly and a decoded P/B/C/U-code list.
   - **Clear DTCs** — UDS `0x14 FF FF FF` (clear all groups).
   - **Run Routine** — UDS `0x31 01 <RID>` start, with a small preset list (0x0312 = ADCM calibration, plus a free-form RID input) and result display.
   - **ECU Reset** — UDS `0x11 01` hard reset.

This is the headline "kill the game" feature. The same protocol pattern AlfaOBD uses against the Active Damping Control Module (per the user's reference screenshots: `10 03` → `31 01 03 12` → `19 02 08` → `14 FF FF FF` → `11 01`) is the same pattern every FCA module accepts, so a single workshop UI covers BCM hidden options, ADCM calibration, future PCM work, and ad-hoc module probing.

## Done looks like
- A new tab labeled `💀 JAILBREAK OPTIONS — SRT · DEMON · HELLCAT · REDEYE` appears at the end of the tab strip
- "Connect OBDLink" uses Web Serial; auto-detects ELM327 vs STN/OBDLink and (on STN) sends the MFG extended-mode init from the screenshots (`ATPP2C SV81 / ON`, `ATPP2D SV01 / ON`, `ATZ`) so DIDs `0xDE01`/`0xDE02` and ADCM routines are actually reachable
- A **target module selector** lets the user pick BCM CDA6 (TX 0x750 / RX 0x758), ADCM Active Damping (TX 0x7A8 / RX 0x7B0 — already in `lib/mods.js`), or enter a custom TX/RX pair; "Auto-find BCM" still probes the four known FCA BCM CAN address pairs (CDA6, CLAUDE Legacy 0x7E0/0x7E8, DarkVIN 0x6B0/0x6B8) and locks onto whichever responds
- "Unlock" runs session `10 03` → seed `27 01` → CDA6-derived key `27 02`; the status badge flips to green "UNLOCKED" (unlock is required for BCM writes; for ADCM/DTC services the tab still works without it)
- A **Diagnostic Services row** is always visible: "Read DTCs", "Clear DTCs", "Run Routine 0x0312", a free-form Routine ID input + "Run", and "ECU Reset" — every button targets the currently selected module
- DTC results render as a clean list (e.g. `P0301 — confirmed`, `B1310 — pending`) with the raw multi-frame hex available in the log
- BCM-only: "Read All Features" reads every DID once and decodes each of the 50 features into a labeled dropdown showing the current setting
- The 50 features are grouped into 11 collapsible categories (Vehicle Configuration, Launch & Performance, Drive Modes, SRT Performance Pages, Trans Brake & Race, Handling & Stability, Powertrain, Aero & Cooling, Gauges & Displays, Telemetry, Valet & Misc) with a search box that filters across id/name/description
- Changing a dropdown stages the change (highlighted row + ⚡ marker) without writing yet; the WRITE button shows the pending count
- Quick-profile buttons (SRT Full / Demon Package / Hellcat / Track Mode) stage a preset bundle of changes in one click
- WRITE coalesces all pending changes per DID, sends a single `0x2E` per DID, then issues an ECU reset
- Live UDS log panel (dark terminal style) shows TX/RX/info/warn/error lines with timestamps; multi-frame ISO-TP responses are reassembled before being logged
- Disconnecting and reconnecting works without page refresh; nothing else in the existing 10 tabs regresses

## Out of scope
- A J2534 hardware path (covered by the separate Desktop Driver task)
- Editing PCM tunes, ABS, or radio/cluster modules beyond what the generic Read DTCs / Clear DTCs / Run Routine buttons happen to enable
- Decoding every possible FCA DTC code into human-readable text — generic SAE P/B/C/U decoding is enough; FCA-specific labels are a follow-up
- Persisting profiles, target modules, or routine presets to localStorage / sharing them across users
- Any backend — everything stays client-side
- Changes to the existing parser, Security Byte Match, or any other tab

## Tasks
1. **Shared OBD engine helper** — Extract Web Serial connect + adapter auto-detect (ELM327 vs STN) + MFG-extended-mode setup + UDS frame send/receive + multi-frame ISO-TP reassembly into a reusable library module so this tab and any future bench tooling can call it without copy-paste.

2. **JAILBREAK_FEATURES catalog** — Add a constants module with the 50-feature table (id, display name, description, DID, byte offset, optional bitmask, option list, optional notes) and the four quick-profile presets.

3. **Target-module selector + diagnostic services row** — Build the module target picker (BCM CDA6 / ADCM Active Damping / Custom TX-RX) and the always-visible service row: Read DTCs, Clear DTCs, Run Routine (preset 0x0312 + free-form), ECU Reset. Implement a tiny SAE DTC decoder so the result list is human-readable.

4. **JailbreakTab component** — Build the new tab: header banner, connect/find-BCM/unlock toolbar, target picker, diagnostic services row, BCM-only features section (read/write/profile bar, search input, collapsible category cards with per-feature dropdowns, pending-change highlighting, batched DID writes), and the dark UDS log panel.

5. **Tab registration** — Add `{id:'jailbreak',i:'💀',l:'JAILBREAK OPTIONS',s:'SRT · Demon · Hellcat'}` to the tab list and wire the route so the existing 10 tabs are untouched.

6. **Smoke check** — Open the tab, confirm it renders, the target picker switches addresses, search filters, dropdowns populate option lists, and the Connect button surfaces a clean error (not a crash) on browsers without Web Serial or when no adapter is selected.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:27,245,259,263-272`
- `artifacts/srt-lab/src/lib/mods.js:9`
- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/tabs/BenchTab.jsx:234-242`
- `artifacts/srt-lab/src/tabs/OBDTab.jsx:274`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx:12`
- `attached_assets/Pasted-import-React-useState-useCallback-useMemo-useRef-from-r_1776429769807.txt:1551-1927`
- `attached_assets/IMG_1270_1776433234875.png`
- `attached_assets/IMG_1271_1776433234875.png`
- `attached_assets/IMG_1272_1776433234875.png`
- `attached_assets/IMG_1274_1776433234875.png`
- `attached_assets/IMG_1275_1776433234875.png`
- `attached_assets/IMG_1276_1776433234875.png`
- `attached_assets/IMG_1277_1776433234875.png`
- `attached_assets/IMG_1278_1776433234875.png`
- `attached_assets/IMG_1279_1776433234875.png`
- `attached_assets/IMG_1280_1776433234875.png`
