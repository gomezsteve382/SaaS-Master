# Automate GPEC↔BCM Key Comparison

## What & Why
The SECURITY tab currently displays a hard-coded warning: "GPEC↔BCM key comparison requires manual check (8B vs 16B)". The GPEC module stores an 8-byte secret key while the BCM stores a 16-byte key — the comparison is non-trivial because the keys use different endianness and length conventions across module types. Automating this removes a manual step that is error-prone and unclear to users.

## Done looks like
- When both a GPEC/GPEC2A and a BCM dump are loaded, the SECURITY tab automatically compares the relevant key bytes without any manual intervention
- The comparison correctly handles the 8B vs 16B size difference (e.g., compares the lower 8 bytes of the BCM key against the GPEC key, or applies the known byte-reversal/truncation rule used by FCA)
- The result shows a clear MATCH / MISMATCH status with the actual byte values displayed for both sides
- The warning "requires manual check" is removed from the UI
- The ANALYZER tab's key section is updated to reflect the same automated comparison

## Out of scope
- Changes to key sync / patching logic
- Adding new module types

## Tasks
1. **Document the comparison rule** — read the reference VINPatcher source and existing SECURITY tab code to pin down the exact byte relationship between GPEC 8B key and BCM 16B key (truncation, reversal, or XOR mask).
2. **Implement `compareGpecBcmKey(gpecKey, bcmKey)`** — a pure function that returns `{match: bool, gpecBytes, bcmBytes, rule}` using the documented rule.
3. **Update SECURITY tab** — replace the manual-check warning with the output of `compareGpecBcmKey`; show the byte comparison table inline.
4. **Update ANALYZER tab** — apply the same display in the ANALYZER's key section.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:195,648`
- `artifacts/srt-lab/src/FcaAnalyzerTab.jsx`
