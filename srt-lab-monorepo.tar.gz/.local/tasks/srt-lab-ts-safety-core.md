# TypeScript the safety-critical core

## What & Why
The most safety-critical code in the project — CRCs, seed→key algorithms, the binary parser, the VIN-write helpers, and the J2534 bridge — is plain JS with zero type discipline. A `Buffer` passed where a `Uint8Array` was expected silently computes garbage CRCs, a `number[]` confused with `Uint8Array` breaks the XTEA round-trip, and a 16-char string accepted as a VIN bricks an ECU. Converting the five hot files to TypeScript catches that whole class of bug at compile time without touching the UI.

## Done looks like
- `lib/crc.ts`, `lib/algos.ts`, `lib/parseModule.ts`, `lib/fileUtils.ts`, and `lib/bridgeEngine.ts` exist as proper TypeScript with strict typing on the byte-level functions.
- `Uint8Array` vs `number[]` is enforced — every CRC/parser function signature requires `Uint8Array` (or `ReadonlyUint8Array`) for byte buffers.
- `Vin17` is a branded type (`string & { readonly __brand: "Vin17" }`) produced only by a validator; every function that takes a VIN takes `Vin17`, not `string`.
- u32 wrap discipline is encoded — XTEA helpers take/return a branded `U32` type produced by a `u32(n: number): U32` helper that masks.
- All existing JS importers continue to work via TypeScript's emit; no behavioural change.
- `srt-lab-test` still passes; `tsc --noEmit` over the converted files passes with `strict: true`.

## Out of scope
- Converting `App.jsx`, the tabs, or the rest of `lib/` to TypeScript.
- Changing any algorithm or offset.
- Adding new tests beyond what's needed to keep the existing suite green.

## Steps
1. Confirm the srt-lab artifact already has a `tsconfig.json` (it does — there's a `main.tsx`). Add a `tsconfig.lib.json` extending it with `strict: true`, `noUncheckedIndexedAccess: true` if needed.
2. Define brand helpers in a new `lib/types.ts`: `U32`, `Vin17`, `ModuleType`, `Bytes` (alias for `Uint8Array`). Export `u32(n)`, `asVin17(s)` (validator), `isVin17(s)`.
3. Convert `lib/crc.ts` first (smallest surface, no dependencies). Every function takes `Bytes`, returns `number` (or `U32` where appropriate).
4. Convert `lib/algos.ts` next. `unlockKey(id, seed: U32): U32`, `unlockKeyBytes(id, seedBytes: Bytes): Bytes`, `ALGOS` typed as `readonly UnlockAlgo[]`.
5. Convert `lib/parseModule.ts` and `lib/fileUtils.ts`. Define `ModuleInfo`, `VinSlot`, `PartialVinSlot`, `SecurityState` interfaces. Every offset is `number`, every byte buffer is `Bytes`.
6. Convert `lib/bridgeEngine.ts`. Type the UDS request/response shapes, the J2534 bridge URL/state, and the engine factory.
7. Update importers in JSX tabs as needed — most should "just work" because TypeScript emits `.js`-compatible output. Where TS surfaces real bugs (wrong types passed), fix them in the caller.
8. Run `tsc --noEmit` and the full test suite.

## Relevant files
- `artifacts/srt-lab/src/lib/crc.js`
- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/fileUtils.js`
- `artifacts/srt-lab/src/lib/bridgeEngine.js`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/tsconfig.json`
- `artifacts/srt-lab/src/__tests__/algos.xtea.test.mjs`
- `artifacts/srt-lab/src/__tests__/bridgeEngine.test.mjs`
- `artifacts/srt-lab/src/lib/__tests__/parseModule.test.js`
