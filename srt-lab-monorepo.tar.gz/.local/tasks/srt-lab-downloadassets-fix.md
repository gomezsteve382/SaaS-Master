# Fix downloadAssets silent fallback

## What & Why
`lib/downloadAssets.js` swallows every server failure: `trackDownload` does `if (!r.ok) return cache.get(assetId) ?? 0;` and the catch block silently optimistically bumps the local count. That's exactly the "silent fallback" pattern that hides real bugs — if the api-server is down or returning 500s, the user has no idea the counter isn't actually incrementing globally.

## Done looks like
- `trackDownload` and `fetchDownloadCount` log a `console.warn` with the URL, status, and response body whenever the server returns a non-OK status or the request throws.
- Failures also push to the central toast/error sink (the `toast.warn` channel, not `error` — these aren't user-blocking) so the user can see in the recent-errors panel that a counter sync failed.
- The optimistic local bump on network failure stays (it keeps the UI responsive) but is clearly marked in the warning as "local-only, did not reach server".
- No other behavioural change.

## Out of scope
- Retrying failed counter increments.
- Persisting the local cache across reloads.

## Steps
1. Update `fetchDownloadCount`: on `!r.ok`, `console.warn("[downloadAssets] fetch failed", { assetId, status: r.status, body: await r.text() })` and call `toast.warn("Counter sync failed for " + assetId)`.
2. Same treatment in `trackDownload` for `!r.ok` and the catch branch. The catch branch additionally notes the optimistic local bump.
3. Confirm the toast sink is available — if this task lands before the toast-sink task, fall back to `console.warn` only and add a TODO to wire the toast once the sink exists.

## Relevant files
- `artifacts/srt-lab/src/lib/downloadAssets.js`
- `artifacts/srt-lab/src/lib/useDownloadCount.jsx`
