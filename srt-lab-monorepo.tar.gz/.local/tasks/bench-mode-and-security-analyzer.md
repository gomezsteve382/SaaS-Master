# Bench Mode & Cross-Vehicle Security Matcher

## What & Why
The user swaps modules between different vehicles (donor → target). They need to load dumps from both cars, see exactly which security bytes match or don't, get a tool that syncs mismatched keys/VINs across modules, and tells them which modified .bin files to flash. Additionally, they want bench-mode equivalents of all Live OBD operations (scan, VIN read/write, proxi, SKIM, RFHUB virginize) working on binary files instead of requiring a live car. The richer parsing from the attached `fca_module_analyzer_1776011879834.jsx` should be integrated for deeper module analysis.

## Done looks like
- **Bench tab**: A new BENCH tab that loads .bin files and performs everything Live OBD does but on binary dumps: auto-detect module type (BCM/RFHUB/GPEC2A/95640) with VIN display cards (mimicking OBD scan results), write VIN to all locations with CRC recalculation, display BCM proxi bytes from dump, display SKIM state byte from GPEC2A dump, virginize RFHUB dump — all with download of modified .bin files.
- **Enhanced SECURITY tab** rebuilt with 4 sub-views from the attached analyzer layout:
  - **Overview**: Per-module offset table (VIN/SKIM/SECRET/FOBIK/IMMO/TAMPER/LOCK/CTR rows), cross-module validation results (pass/warn/fail), runtime counters for GPEC2A.
  - **Security**: Per-module architecture cards showing VIN, SKIM status, vehicle secrets (with endianness), FOBIK slots/count, lock status, tamper status — side-by-side comparison between donor and target modules.
  - **Diff**: Hex diff between any two loaded modules with changed-byte highlighting, region grouping, and byte counts.
  - **Tools**: VIN writer (all modules at once), SKIM toggle, virginize PCM, extract/sync secret key, with result display and .bin download for each modified file.
- **Cross-vehicle matching workflow**: When modules from different VINs are loaded, the app clearly shows: which VINs don't match (red), which secret keys mismatch between BCM↔RFHUB↔95640↔GPEC2A (with byte-reversal awareness for BCM), which FOBIK counts disagree, and which SKIM states conflict. A "Match All" action syncs VINs and keys from a chosen source module to all others and produces downloadable .bin files for each module, with a summary telling the user exactly which files to flash.
- **Deeper module parsing** from the attached analyzer: GPEC2A gets runtime counters, transponder keys, part number, ZZZZ tamper, secret key mirror validation; RFHUB gets FOBIK slot counting (AA50), CC66AA55 security markers, ZZZZ blocks, part numbers, 16-byte vehicle secret; BCM gets security lock byte (0x8028), FOBIK count (0x5862), IMMO key entries, FOBIK part number.
- Existing DUMPS, SEED→KEY, GPEC, GPEC2A, and LIVE OBD tabs continue to work unchanged.

## Out of scope
- No changes to Seed→Key, GPEC, or GPEC2A tabs.
- No backend — everything stays client-side.
- No Web Serial changes — Live OBD tab stays as-is.

## Tasks
1. **Integrate enhanced module parser** — Port `detectModuleType`, `parseModule`, `crossValidate`, `computeDiff`, `writeVIN`, and `virginize` from the attached analyzer into `App.jsx`. Merge with existing `analyzeFile` and `secAnalyze` logic, keeping the richer field extraction (runtime counters, transponder keys, FOBIK slots, security lock, part numbers, vehicle secrets with endianness).

2. **Build Bench tab** — New tab that loads .bin files and provides all Live OBD features on binary data: module type detection with VIN display cards, VIN write with CRC to all locations, proxi byte extraction from BCM dumps, SKIM state from GPEC2A dumps, RFHUB virginize — each producing a downloadable modified .bin.

3. **Rebuild SECURITY tab as cross-vehicle matcher** — Replace the current SkimTab with the 4-sub-tab layout: Overview (offset table + cross-module validation), Security (side-by-side architecture cards for loaded modules), Diff (hex diff with highlight), Tools (VIN sync all, key sync with source picker, SKIM toggle, virginize, extract key). Add the "which files to flash" summary: after syncing, list each modified module with a download button and a plain-English note like "Flash this BCM file" / "Write this RFHUB to 95320 chip."

4. **Adapt styling** — Convert the attached analyzer's dark theme components to match SRT Lab's light theme using existing `C` palette and `Card`/`Tag`/`Btn` components.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `attached_assets/fca_module_analyzer_1776011879834.jsx`
