---
title: Fix BCM VIN Patch & CRC for 6-Slot Layout
---
# Fix BCM VIN Patch & CRC for 6-Slot Layout

## What & Why
The BCM has 6 VIN slots total: 4 full 17-char VIN entries (at 0x5320/0x5340/0x5360/0x5380) and 2 partial 8-char tail entries (at 0x4098/0x40B0). Currently the VIN patch in DUMPS only writes the 4 full slots and ignores the 2 partial tail slots. The CRC patch in BENCH also misses these partial slots because it only looks for tails that overlap with full VIN regions. Both need to be updated to handle the complete 6-slot BCM layout.

Analysis from real Trackhawk BCM dumps:
- Full VIN slots: 0x5320, 0x5340, 0x5360, 0x5380 → 17-char VIN + 2-byte CRC16 (CCITT)
- Partial tail slots: 0x4098, 0x40B0 → last 8 chars of VIN + 2-byte CRC16 (CCITT)
- The partial tail CRC is computed over just the 8 tail bytes (e.g. "EC365477" → 0xF946)
- Other software (reference tool) correctly writes all 6 slots during VIN patch

## Done looks like
- VIN patch in DUMPS writes the new VIN to all 6 BCM locations: 4 full VINs with full CRC16, and 2 partial tails (last 8 chars) with their own CRC16
- CRC patch in BENCH detects and fixes CRCs at the 2 partial tail offsets (0x4098/0x40B0) in addition to the 4 full VIN CRCs
- The parseModule/analyzeFile functions also detect the partial VIN slots so they appear in the module info
- A patched BCM from our app matches the same layout as the reference software output

## Out of scope
- Changes to RFHUB, 95640, or GPEC2A VIN handling (those are already correct)
- Any new UI elements or tabs
- The 0x5780/0x57A8 entries (these appear to be non-standard encoded VINs with pre-existing CRC mismatches in the original dump — not part of normal VIN patching)

## Tasks
1. **Update writeModuleVIN for BCM** — Add the 2 partial tail offsets (0x4098, 0x40B0) to the BCM VIN write. Write the last 8 characters of the VIN at each offset, then compute and write CRC16 over those 8 bytes at offset+8 and offset+9.

2. **Update doCrcPatch for BCM partials** — Add explicit checking of 0x4098 and 0x40B0 as known BCM partial tail CRC locations. Compute CRC16 over the 8 bytes and compare/fix the 2-byte CRC at offset+8.

3. **Update parseModule/analyzeFile** — Detect and report the partial VIN entries at 0x4098/0x40B0 in BCM modules so they show up in module info cards.

4. **Validate with test files** — Verify a VIN patch followed by CRC patch on the attached original BCM dump produces output matching the reference patched file at all 6 VIN locations.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:182-198`
- `artifacts/srt-lab/src/App.jsx:284-322`