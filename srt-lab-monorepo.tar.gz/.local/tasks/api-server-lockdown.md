# Lock down api-server write endpoints

## What & Why
The api-server's write endpoints — `POST /api/downloads/:id` (download counter increment) and the backup-sync routes — accept any traffic with no rate limiting, no auth, no origin check. As long as the server stays on localhost it doesn't matter, but the moment it's deployed (and the deployment skill is configured for it), the counters will be spammed and the backups table will fill with junk uploads from the open internet.

## Done looks like
- All write endpoints (`POST`, `PUT`, `PATCH`, `DELETE`) require either a shared-secret header (`x-srtlab-key` validated against a `SRTLAB_API_KEY` env var) OR a same-origin check (`Origin` header matches the configured allowed origin).
- A simple in-memory rate limiter caps writes at 60/minute per IP for download counters and 10/minute per IP for backup uploads. Returns 429 when exceeded.
- Read endpoints (`GET /api/downloads/:id`, `GET /api/backups`, etc.) stay open — they're idempotent and the data is non-sensitive.
- `SRTLAB_API_KEY` is set in the environment. The srt-lab frontend (`lib/downloadAssets.js`, `lib/audit.js` server-sync) reads it from a build-time env var (`VITE_SRTLAB_API_KEY`) and sends it as the header.
- A short README note in the api-server directory documents the auth model.
- Existing functionality (counter increments from the UI, backup sync from BackupsTab) still works end-to-end.

## Out of scope
- Per-user auth / OAuth / sessions — this is a single-tenant tool, a shared key is sufficient.
- Replacing the in-memory rate limiter with Redis.
- Changing the database schema.

## Steps
1. Add a `requireApiKey` Express middleware that checks the `x-srtlab-key` header against `process.env.SRTLAB_API_KEY`. Bypass for GET requests. Bypass entirely if `SRTLAB_API_KEY` is unset, but log a loud warning at boot ("API server running without auth — set SRTLAB_API_KEY").
2. Add an `originOk` middleware as a fallback when no key is present and the request is a same-origin browser request.
3. Apply both middlewares to every non-GET route in `artifacts/api-server/src/index.ts` (and any router files).
4. Add a tiny in-memory token-bucket rate limiter keyed on `req.ip + req.path`. Hardcoded limits per route family.
5. Add `VITE_SRTLAB_API_KEY` to the srt-lab build env. Update `lib/downloadAssets.js` (`trackDownload`) and `lib/audit.js` (server sync) to send the header on writes.
6. Use the environment-secrets workflow to add `SRTLAB_API_KEY` and `VITE_SRTLAB_API_KEY` (same value).
7. Smoke-test: read works without the key, write fails without the key (401), write works with the key, 11th rapid backup upload returns 429.

## Relevant files
- `artifacts/api-server/src/index.ts`
- `artifacts/srt-lab/src/lib/downloadAssets.js`
- `artifacts/srt-lab/src/lib/audit.js`
