# Backups & Sessions Audit Tabs

## What & Why
Surface the two audit tabs from the reference `App.jsx`: `Backups` (view, restore, delete, download the auto-snapshots created before every write) and `Sessions` (the paper-trail viewer/exporter). These tabs make the safety net visible to the technician.

## Done looks like
- A Backups tab lists every snapshot in `localStorage` (newest first), supports filtering by module (with per-module counts), shows the selected snapshot's DIDs in detail, and offers Restore (push DIDs back to module via UDS write), Delete, Download as JSON, and Clear All.
- Restore is gated by the shared Read-First confirmation modal.
- A Sessions tab lists every paper-trail entry from `localStorage`, supports filtering by module / outcome, search, export-to-CSV, and Clear All.
- Both tabs respond live as new backups / sessions are created in other tabs (refresh button at minimum; auto-poll acceptable).

## Out of scope
- Cloud sync, multi-tech accounts, or server-side persistence.
- ProgramAll / UDS / Analyzer — covered by other chunks.

## Tasks
1. **Port Backups tab** — Translate the reference `BackupsTab` into `src/tabs/BackupsTab.jsx`, including module filter, detail view, restore (with modal), delete, download, clear-all.
2. **Port Sessions tab** — Translate the reference paper-trail viewer into `src/tabs/SessionsTab.jsx` with filter, search, CSV export, clear-all.
3. **Wire into navigation** — Replace the placeholders for `backups` and `sessions` with the real components.
4. **Smoke run** — Build, restart workflow, manually call `logSession()` and `backupModule()` from the console, confirm both tabs reflect the new entries and that download / CSV-export produce valid files.

## Relevant files
- `attached_assets/App_1776444434000.jsx`
- `artifacts/srt-lab/src/tabs/`
- `artifacts/srt-lab/src/lib/`
