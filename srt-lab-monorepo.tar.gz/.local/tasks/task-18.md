---
title: ELM327 Refinements + CAN Bus Monitor
---
# ELM327 Refinements + CAN Bus Monitor

## What & Why
User provided a refined version of App.jsx with minor ELM327 compatibility tweaks
and a new CAN Bus Monitor feature for passive bus diagnostics.

## Changes

### 1. Variable rename in both connects
`dec` → `tdec` for TextDecoder variable (avoids potential shadowing)

### 2. Remove STN auto-detection from OBD connect
- Remove `isSTN` variable, `ATAT1` command, and `isSTN` property on eng.current
- Simplify back to `addLog('Adapter: '+(await send('ATI')),'info')`
- ELM327-focused — STN detection adds unnecessary complexity

### 3. Timeout adjustments
- OBD uds() timeout: 6000 → 5000ms
- Bench uds() timeout: 6000 → 5000ms (was already 5000 before Task #17)
- Scan probe timeouts: 4000 → 3000ms

### 4. Error regex fix
- OBD uds() error regex: `/NO DATA|ERROR|UNABLE|BUS|STOPPED/` → `/NO DATA|ERROR|UNABLE|BUS INIT|STOPPED/`
- `BUS` alone could match valid hex; `BUS INIT` is the actual ELM327 error

### 5. Scan probe cleanup
- Alive check regex: `/[0-9A-Fa-f]{2,}/` → `/^[0-9A-Fa-f\s]+$/m` (stricter multiline match)
- Remove `\?` from probe error filter (not needed with ATCRA set)
- Remove `lastRaw` variable and associated logging
- Simplify no-response log to just `'no response'`

### 6. NEW: CAN Bus Monitor function
Add `canMonitor` callback to OBDTab:
- Clears CRA filter (`ATCRA` with no arg)
- Runs `ATMA` for ~5 seconds (passive CAN monitoring)
- Breaks out of ATMA with empty send
- Parses response lines for 3-char CAN IDs
- Shows unique active CAN IDs sorted
- Maps each ID to known MODS entries
- Resets state after monitoring (ATSP6, ATCAF1)

### 7. CAN Monitor button in OBD UI
Add button next to Scan: `📻 CAN Monitor` (color C.a4, outline style)

## Done looks like
- All refinements applied
- CAN Monitor button visible when connected
- Pressing CAN Monitor shows active CAN IDs in traffic log
- No regressions to scan or write functionality

## Relevant files
- `artifacts/srt-lab/src/App.jsx` — OBD connect ~820, BENCH connect ~336, scan ~858, new canMonitor ~889, OBD UI ~978