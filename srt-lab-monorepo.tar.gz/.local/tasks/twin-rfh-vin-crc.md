# Fix RFH VIN checksum formula in TWIN tab

## What & Why
The TWIN tab writes RFH VIN checksums using an empirically-guessed formula
`XOR(17 stored bytes) ^ 0x87`. This was derived from a single reference file
where the result happened to coincide with `crc8rf` output by chance (1-in-256
probability for any given 17-byte sequence). Every other part of the app —
fileUtils.js, DUMPS, IMMOVIN — validates RFH VIN checksums using `crc8rf`.
For any VIN other than the one test case, the TWIN tab writes wrong checksums,
causing the Security tab to show "CRC8 ✗" on all 4 VIN slots.

## Done looks like
- After using the TWIN tab "Import BCM→RFH" button and loading the result in
  the Security tab, all 4 RFH VIN slots show "CRC8 ✓"
- The empirical `rfhVinCs` helper (XOR^0x87) is replaced with `crc8rf` imported
  from `../lib/crc.js`
- No changes to any other tab

## Out of scope
- The RFH SEC16 checksum formula (XOR^0x8B) — separate issue
- Changes to BCM, PCM, or Security tab code

## Tasks
1. **Replace VIN CS formula** — Import `crc8rf` from `../lib/crc.js` into
   TwinTab.jsx; replace the `rfhVinCs` function and its callsite in
   `applyRfhFromBcm` with `crc8rf(rev)` where `rev` is the 17 reversed bytes,
   matching the formula in fileUtils.js.
2. **Update TWIN inspect display** — The TwinTab RFH inspect card shows stored
   vs calculated CS for each VIN slot; the `csCalc` is already computed via
   `rfhVinCs`. Update it to use `crc8rf` as well so the badge correctly reflects
   what will be written.

## Relevant files
- `artifacts/srt-lab/src/tabs/TwinTab.jsx:119-170`
- `artifacts/srt-lab/src/lib/crc.js`
- `artifacts/srt-lab/src/lib/fileUtils.js:35`
