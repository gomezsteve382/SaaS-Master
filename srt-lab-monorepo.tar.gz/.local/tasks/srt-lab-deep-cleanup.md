# SRT Lab Deep Cleanup

## What & Why
A line-by-line audit of the SRT Lab artifact (~21k LOC) and the API Server (~1.5k LOC) turned up large amounts of dead, duplicated, and case-colliding code that is actively dangerous to maintain. The same parser/CRC/VIN-write helpers exist in three places, three incompatible "Read First" modals exist with the same casefold name, App.jsx still inlines six tab implementations that already exist as standalone files, and a previous agent layered a "paper trail" (technician name, RO/title #, free-text notes, re-type-VIN gate, session log) on top of the actually-useful binary backup library — that paperwork layer needs to come out. This task consolidates every duplicate to one source of truth, deletes the dead copies, strips the paper-trail layer while keeping binary backup snapshots, and fixes the api-server dev script that crashes with `EADDRINUSE` on every reload.

## Done looks like
- Each helper (parseModule, analyzeFile, patchFile, virginizeFile, writeModuleVIN, virginizeModule, CRC family, ALGOS) exists in exactly one file.
- App.jsx no longer redefines any of those helpers and no longer inlines the Dumps/OBD/Bench/Seed/Gpec/Gpec2a tab bodies; it imports the existing `tabs/*.jsx` modules.
- Exactly one `ReadFirstModal` remains, with a minimal API: `{module, currentState, newVin, onConfirm, onCancel}` plus a single "I've reviewed the current state" checkbox. No technician name, no RO/title # field, no notes textarea, no re-type-VIN gate.
- Binary backup snapshots (`srtlab_backup_index`) still work — pre-write snapshot, restore, prune, import/export, server sync. The session paper-trail (`srtlab_sessions`, `logSession`, SessionsTab) is removed entirely.
- Only one backup/snapshot library remains; the legacy split (`backups.js` + `paperTrail.js`) and the bloated `audit.js` superset both go, replaced by a single trimmed module that does snapshot management only.
- The api-server `dev` script uses `tsx watch` (or equivalent) so saving a file does not leave a stale `node ./dist/index.mjs` holding port 8080.
- All existing tests in `__tests__/` still pass and the SRT Lab UI renders every remaining tab without regressions.

## Out of scope
- Adding new features, new tabs, or new module support.
- Refactoring CSS / inline styles or migrating to a UI library.
- Backend schema changes beyond what is required to keep the dev script alive and to drop the unused `/api/sessions` route if one exists.
- Touching the already-PROPOSED tasks #75, #85, #86, #99 — this task supersedes #75 and #99, and supersedes #85/#86 (the BackupsTab/SessionsTab "vault & paper trail UI" work) since the paper-trail half is being deleted; the executor should mark all four CANCELLED on completion if still PROPOSED.

## Steps
1. **Collapse the parser/VIN-write helper triplet to one file.** `lib/parseModule.js` exports `parseModule/checkVin/extractVIN/extractHex/arrEq/detectBySignature/fO/countSkimRecs/syncImmoBackup`; `lib/fileUtils.js` exports a parallel `analyzeFile/patchFile/virginizeFile/writeModuleVIN/virginizeModule/syncImmoBackupF` that re-implements the same logic; App.jsx lines 29-260 inline a third copy (`crc16/crc8_42/crc8rf/sxor/cda6/ngc/tipm/ALGOS/parseModule/crossValidate/computeDiff/analyzeFile/patchFile/virginizeFile/writeModuleVIN/virginizeModule`). Pick `lib/fileUtils.js` + `lib/parseModule.js` as canonical (already imported by SecurityTab, BcmTab, RfhubTab, EcmTab, AdcmTab, ImmoVINTab), delete every duplicated symbol from App.jsx, and replace the App.jsx call sites with imports. Keep `lib/algos.js` exports of `cda6/ngc/tipm/sxor/ALGOS/xtea_sgw/unlockKey/unlockKeyBytes` — App.jsx must import them, not redefine. Add a short test that imports each canonical helper and exercises one VIN write per module type so any subtle behavioural divergence between the three forks (e.g. App.jsx's `patchFile` vs `fileUtils.patchFile` mirrored-RFHUB CRC logic) surfaces immediately.

2. **Restore the standalone tab modules.** `src/tabs/DumpsTab.jsx`, `OBDTab.jsx`, `BenchTab.jsx`, `SeedTab.jsx`, `GpecTab.jsx`, and `Gpec2aTab.jsx` exist on disk but are never imported — App.jsx defines its own inline versions instead. Delete the inline versions from App.jsx and import the file versions; reconcile any drift (the App.jsx inline copies are the more recent ones for several tabs, so port any newer logic into the standalone files first, then delete the inline copies). Confirm by grep that each `tabs/*.jsx` is imported exactly once and that App.jsx shrinks by ~900 lines.

3. **Collapse ReadFirstModal to one minimal component.** `src/lib/ReadFirstModal.jsx` (175 L, MasterVinContext-aware, takes `{title, subtitle, summary, details}`, RO/title/technician/notes inputs), `src/lib/readFirstModal.jsx` (102 L, takes `{module, currentState, newVin}`, single checkbox), and `src/components/ReadFirstModal.jsx` (97 L, takes `{module, currentState, newVin}` + technician name + RO/title # + notes textarea + re-type-VIN gate) are three separate components, and the two `lib/` copies have a casefold collision that will silently break a case-sensitive build. Make `lib/readFirstModal.jsx` (the simple 102 L version) the canonical survivor — single "I've reviewed the current state" checkbox + Apply/Cancel — but move it under `src/components/ReadFirstModal.jsx` so the import path is consistent. Strip the technician/RO/notes/re-type-VIN inputs from the components/ version. Delete the other two files. Update every importer (App.jsx, BcmTab, RfhubTab, EcmTab, AdcmTab, BackupsTab, JailbreakTab) to point at the survivor.

4. **Strip the paper-trail layer; keep binary backups.** `lib/audit.js` (669 L) bundles two unrelated concerns: (a) binary module snapshots indexed by `srtlab_backup_index` — pre-write snapshot, restore, prune, import/export, server sync — which is real safety and stays; and (b) a session log indexed by `srtlab_sessions` with `logSession`, technician name, RO/title #, free-text notes, CSV export, the whole "paper trail" — which goes. `lib/paperTrail.js` is the legacy version of (b) and also goes. `lib/backups.js` is the legacy version of (a) — its 9 remaining import sites (including JailbreakTab.jsx lines 10-11) need to migrate to the trimmed module. End state: one file (call it `lib/backups.js` after the rewrite, or keep the `audit.js` name with the sessions code surgically removed) that exports `backupModule/restoreBackup/listBackups/pruneBackups/exportBackups/importBackups/CRITICAL_DIDS` and nothing else. Delete every call to `logSession` and remove the `srtlab_sessions` localStorage key on first load (one-shot cleanup). Delete `tabs/SessionsTab.jsx` and remove it from the tab registry. If the api-server has a `/api/sessions` route, drop it too.

5. **Delete the unused top-level diagnostic copies.** `src/OBDSwarmDiagnostic.jsx` (635 L) and `src/J2534Scanner.jsx` (412 L) are imported only by App.jsx; either fold their contents into the matching `tabs/*.jsx` modules (preferred — keeps `tabs/` the single source of truth for tab UI) or move them under `src/tabs/` so the layout is consistent. The legacy "LIVE OBD" duplicate flagged in PROPOSED task #75 falls under this step.

6. **Strip App.jsx duplicate constants and inline UI helpers.** After steps 1, 2, 3, and 5 land, App.jsx should contain only the top-level shell, routing/tab registry, MasterVinContext provider, and genuinely top-level UI (header, tab bar, footer, PlaceholderTab). Anything else — helper components like `FileDropZone`, `MonoHex`, `SectionTitle`, `CsBadge`, hex-format helpers `hxb/fO/dl` — should move to `lib/ui.jsx` if reusable, or into the single tab that uses them. Target final App.jsx size under ~400 lines.

7. **Fix api-server dev script `EADDRINUSE`.** `pnpm --filter @workspace/api-server run dev` runs `build && start`, which spawns `node ./dist/index.mjs` without killing the previous instance, so the second reload always crashes with `EADDRINUSE :::8080`. Switch the dev script to `tsx watch src/index.ts` (already in devDependencies) so a single long-lived process owns the port and reloads on file changes. Keep `build` and `start` for production. Verify the workflow `artifacts/api-server: API Server` comes up clean and that hot-reload works by editing a route handler.

8. **Wire every ECU tab through the full seed/key dispatcher.** The unlock infrastructure in `lib/algos.js` is complete — `ALGOS` exports 14 algorithms (`gpec1/gpec2/gpec2f/gpec2e/gpec3/gpec2a/gpec15`, `ngc`, `jtec`, `cda6`, four `tipm` tables), `xtea_sgw` for SGW on 0x74F, and `unlockIdForTx(tx)` / `unlockKey(id, seed)` / `unlockKeyBytes(id, seedBytes)` route a UDS 27 01 seed to the right one. The live-OBD/bench/jailbreak surfaces (`OBDTab`, `BenchTab`, `JailbreakTab`) already call through the dispatcher so all 14 algos plus XTEA are reachable. The per-ECU tabs do NOT — `BcmTab.jsx:90-98`, `EcmTab.jsx:88-105`, `RfhubTab.jsx:84-90`, and `AdcmTab.jsx:103-108` all hardcode `cda6(s)` directly. That works for the BCM/RFHUB/ADCM happy-path on 0x742/0x75F/0x744 but silently fails (NRC 35/36, no surfaced error) the moment those tabs are pointed at any other tx — including the SGW on 0x74F, any GPEC ECM, an NGC variant, or a TIPM. Replace every hardcoded `cda6(seed)` call in those four tabs with `unlockKeyBytes(unlockIdForTx(tx), seedBytes)` (and surface the chosen algo id in the log line, exactly like OBDTab/BenchTab do: `"BCM (cda6, 4B key) unlocked"`). Add a UI hint when `unlockIdForTx` returns `cda6` for a tx that isn't in the standard cda6 set, so the user knows the dispatcher fell back to the default rather than positively identifying the algorithm. After this change, every algorithm in `ALGOS` plus `xtea_sgw` must be reachable from at least one per-ECU tab via the dispatcher, not just from the swarm/sweeper surfaces. Add a test that for each `(tx, expectedAlgoId)` pair in a small fixture table, `unlockIdForTx(tx)` returns the expected id and `unlockKeyBytes(id, ...)` produces the right number of key bytes (4 for everything except the 8-byte SGW XTEA path).

9. **Cleanup verification.** Run `pnpm --filter @workspace/srt-lab test` (the existing `srt-lab-test` workflow) and confirm every test still passes; restart the api-server and srt-lab workflows; click through every remaining tab in the UI to confirm no regressions. Final grep: `grep -rn "function parseModule\|function analyzeFile\|function writeModuleVIN\|function virginizeModule\|function crc16\|function crc8_42\|function crc8rf\|logSession\|srtlab_sessions" artifacts/srt-lab/src` should report exactly one definition per helper and zero hits for `logSession` / `srtlab_sessions`.

## Relevant files
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js`
- `artifacts/srt-lab/src/lib/fileUtils.js`
- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/lib/crc.js`
- `artifacts/srt-lab/src/lib/audit.js`
- `artifacts/srt-lab/src/lib/backups.js`
- `artifacts/srt-lab/src/lib/paperTrail.js`
- `artifacts/srt-lab/src/lib/ReadFirstModal.jsx`
- `artifacts/srt-lab/src/lib/readFirstModal.jsx`
- `artifacts/srt-lab/src/components/ReadFirstModal.jsx`
- `artifacts/srt-lab/src/lib/constants.js`
- `artifacts/srt-lab/src/lib/ui.jsx`
- `artifacts/srt-lab/src/lib/mods.js`
- `artifacts/srt-lab/src/tabs/DumpsTab.jsx`
- `artifacts/srt-lab/src/tabs/OBDTab.jsx`
- `artifacts/srt-lab/src/tabs/BenchTab.jsx`
- `artifacts/srt-lab/src/tabs/SeedTab.jsx`
- `artifacts/srt-lab/src/tabs/GpecTab.jsx`
- `artifacts/srt-lab/src/tabs/Gpec2aTab.jsx`
- `artifacts/srt-lab/src/tabs/JailbreakTab.jsx`
- `artifacts/srt-lab/src/tabs/BackupsTab.jsx`
- `artifacts/srt-lab/src/tabs/SessionsTab.jsx`
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx`
- `artifacts/srt-lab/src/tabs/TwinTab.jsx`
- `artifacts/srt-lab/src/tabs/ImmoVINTab.jsx`
- `artifacts/srt-lab/src/tabs/BcmTab.jsx`
- `artifacts/srt-lab/src/tabs/RfhubTab.jsx`
- `artifacts/srt-lab/src/tabs/EcmTab.jsx`
- `artifacts/srt-lab/src/tabs/AdcmTab.jsx`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx`
- `artifacts/srt-lab/src/J2534Scanner.jsx`
- `artifacts/srt-lab/src/__tests__/algos.xtea.test.mjs`
- `artifacts/srt-lab/src/__tests__/bridgeEngine.test.mjs`
- `artifacts/srt-lab/src/lib/__tests__/parseModule.test.js`
- `artifacts/api-server/package.json`
- `artifacts/api-server/src/index.ts`
