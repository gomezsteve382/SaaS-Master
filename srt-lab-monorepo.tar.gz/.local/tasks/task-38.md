---
title: TWIN tab: BCM partial VINs (0x4098 / 0x40B0)
---
# TWIN tab: show BCM partial VINs

## What & Why
The BCM stores two additional "partial VIN" slots at offsets 0x4098 and 0x40B0. Each holds the last 8 characters of the VIN (serial-number tail only) followed by a 2-byte CRC16. These are already parsed and updated in the DUMPS, IMMOVIN, and BenchTab modules, but the TWIN tab's local BCM parser was written without them, so they don't appear in the inspection card.

## Done looks like
- The BCM card in the TWIN tab shows a "Partial VINs (Tail ×2)" section beneath the 4 primary VIN rows, displaying each partial slot's offset, 8-char tail, and CRC16 badge (OK / fail)
- The `applyBcmFromRfh` write path also updates these two slots (tail bytes + recalculated CRC16) so the downloaded file is fully synced
- No changes to the RFH or PCM sections

## Out of scope
- Changes to any tab other than TwinTab.jsx
- The secondary 6-copy VIN area (0x0698–0x0738) — already handled

## Tasks
1. **Parse partial VINs** — Extend `parseBcm()` to read the 8-byte tail + CRC16 at 0x4098 and 0x40B0 and include them in the returned info object as `partialVins`.
2. **Display partial VINs** — Add a "Partial VINs" section to `BcmCard` that shows each slot's offset, tail string, and CRC16 OK/fail badge, styled consistently with the primary VIN rows.
3. **Write partial VINs on apply** — Update `applyBcmFromRfh()` to also write the last 8 chars of the new VIN and a fresh CRC16 into slots 0x4098 and 0x40B0.

## Relevant files
- `artifacts/srt-lab/src/tabs/TwinTab.jsx`
- `artifacts/srt-lab/src/lib/fileUtils.js:34-51`
- `artifacts/srt-lab/src/lib/crc.js`