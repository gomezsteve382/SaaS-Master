---
title: Fix Gen2 RFH VIN CS validation in Security/DUMPS/IMMOVIN tabs
---
# Fix Gen2 RFH VIN CS validation in Security/DUMPS/IMMOVIN tabs

## What & Why
An external reference tool (purpose-built for MC9S12X Gen2 RFH ↔ BCM sync)
confirmed that the TWIN tab's VIN checksum formula is correct for Gen2 files:
  CS = XOR(17 raw stored bytes) ^ 0x87  (single byte, stored at offset+17)

However, `parseModule.js` and `fileUtils.js` both use `crc8rf` for ALL RFHUB
VIN checksums regardless of generation. `crc8rf` is the correct formula for
Gen1 RFH (2048-byte, 24C16 chip). Gen2 (4096-byte, 24C32 chip) uses the
XOR-with-magic formula above. The result is that after a TWIN tab sync, the
Security and DUMPS tabs show "CRC8 ✗" on all 4 RFH VIN slots even though the
checksums are valid — a false failure.

Note: the TWIN tab (`TwinTab.jsx`) is correct and must NOT be changed.

## Done looks like
- Loading a TWIN-synced Gen2 RFH in the Security, DUMPS, or IMMOVIN tab shows
  "CRC8 ✓" (or equivalent OK badge) on all 4 VIN slots
- Gen1 RFH files (2048 bytes) still validate using `crc8rf` (no regression)
- The cross-module validator no longer fires a false "VIN checksum" issue for
  valid Gen2 files

## Out of scope
- Changes to TwinTab.jsx (already correct)
- Changes to BCM, 95640, or GPEC2A parsing
- The SEC16 offset fix (separate Task #41)

## Tasks
1. **parseModule.js — branch by generation** — After the rfhGen value is known
   (sz === 4096 → Gen2), use `XOR(raw_stored_17_bytes) ^ 0x87` for VIN CS
   calculation instead of `crc8rf`. Keep `crc8rf` for Gen1 (sz === 2048).
   Implement a small inline helper or use a constant for the magic value 0x87
   to match TwinTab's `RFH_VIN_CS_MAGIC`.
2. **fileUtils.js — branch by generation** — The RFHUB branch currently uses
   `crc8rf(st)` for all sizes. Add a size check: if `sz === 4096` use
   `XOR(st) ^ 0x87`; otherwise keep `crc8rf(st)`.

## Relevant files
- `artifacts/srt-lab/src/lib/parseModule.js:84-90`
- `artifacts/srt-lab/src/lib/fileUtils.js:35`
- `artifacts/srt-lab/src/tabs/TwinTab.jsx:99-105` (reference — do not change)