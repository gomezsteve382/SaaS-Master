# OBD VIN Write Per-Module Correctness

## What & Why

Deep line-by-line diff of the 680-line reference `SRTLabJailbreakEdition_1776518787584.jsx` against the current SRT Lab build surfaced three concrete behavioural gaps in the OBD VIN-write path. These are **not cosmetic** — they cause silent failures and stale mirror VINs on real vehicles:

1. **Per-module unlock algorithm + fallback chain is missing.** The reference's `tryUnlock` keeps a `MOD_KEY` map (ECM/TCM/DAMP → sxor 0xE72E3799, BCM/RFHUB/ABS/IPC/EPS/RADIO → cda6, TIPM → tipm) and on failure iterates a fallback chain `[CDA6, sxor 0xE72E3799, sxor 0x129D657F, sxor 0xCE853A6F, sxor 0x47EC21F8]`, checking the 27 02 response NRC each time. The current `unlockIdForTx(tx)` is binary — it returns `'xtea_sgw'` only for SGW @ 0x74F and `'cda6'` for everything else. Result: when the user hits "Write VIN to all modules", ECM/TCM/TIPM are sent CDA6 keys, the ECU replies NRC 0x35 (invalid key), and the code logs "unlocked" anyway because `unlockKeyBytes` returned non-null. The subsequent 0x2E DID writes are then sent in an unauthenticated session and rejected.

2. **Module-specific VIN DIDs are missing.** The reference's `VIN_DIDS` map writes BCM with `[0xF190, 0x7B90, 0x7B88, 0x6E2025]`, RFHUB with `[…, 0x6E2027]`, and EPS with `[0xF190, 0x6EF190]` (note: 3-byte DIDs). The current write loop in `OBDTab.writeAll` and `OBDTab.writeOneModule` always uses `[0xF190, 0x7B90, 0x7B88]` regardless of module. Result: BCM and RFHUB internal mirror DIDs never get refreshed, so post-write the BCM still answers the old VIN through `0x6E2025` and the RFHUB through `0x6E2027`. Customers then think the write failed.

3. **3-byte (24-bit) DID encoding is unsupported.** Every UDS write in the codebase hard-codes `[(did>>8)&0xFF, did&0xFF]`, which truncates 24-bit DIDs to their low 16 bits (e.g. `0x6E2025` → `0x2025`). Without a `did > 0xFFFF ? 3-byte : 2-byte` ternary, gap #2 cannot be fixed even after the map is added.

The reference also has a small sanity item: after each module's writes, send `[0x11, 0x01]` (ECU reset) — already present in the current code (`OBDTab.jsx:177, 227, 257`), so no change needed there.

## Done looks like

- "Scan + Write VIN to all modules" successfully unlocks ECM, TCM, TIPM (sxor / tipm keys), as well as the existing BCM/RFHUB/ABS/IPC paths. Each unlock attempt logs the algorithm tried and its 27 02 NRC; on NRC ≠ 0x00 the next algorithm in the fallback chain is tried; only when all five are exhausted does the module log a hard "unlock failed" line and skip the writes for that module (rather than pretending success).
- Per-module write-DID lists are honoured: BCM also writes `0x6E2025`, RFHUB also writes `0x6E2027`, EPS writes `[0xF190, 0x6EF190]` instead of the default trio, and the rest of the modules continue to write the existing `[0xF190, 0x7B90, 0x7B88]`. Each DID is logged with its actual numeric value (no truncation).
- A read-back verification step (after the post-write 11 01 reset) re-issues `0x22` for every DID just written and surfaces a per-DID OK / MISMATCH tag in the OBD log — so the user can tell at a glance whether the BCM mirror DID actually picked up the new VIN.
- The same per-module unlock map + DID list is shared with `BenchTab` (which currently also calls `unlockIdForTx`) so bench-mode writes inherit the fix.
- Existing tests stay green; new tests cover the unlock fallback chain, the 24-bit DID encoder, and the per-module DID list.

## Out of scope

- Touching `EcmTab`/`AdcmTab` per-module unlock — they already have their own custom seed-key logic (SBEC `(seed*4)+0x9018` etc.) that is correct for their dedicated flows.
- Changing the SGW XTEA path — XTEA stays for `tx === 0x74F` only.
- Anything in the file-mode (`fileUtils.js`, `parseModule.js`) VIN write path — those are byte-level and already match the reference.
- Cosmetic Gpec2aTab tile-card layout (tracked separately if the user wants it).
- Any new module addresses or NRC translations — the existing `MODS` table and `nrc.js` cover what is needed.

## Steps

1. **Per-module unlock map + fallback chain in `lib/algos.js`.** Add a `MOD_UNLOCK` map keyed by module code (ECM/TCM/DAMP/BCM/RFHUB/ABS/IPC/EPS/RADIO/TIPM) returning the primary algorithm id, plus a `UNLOCK_FALLBACK` ordered list of algorithm ids. Replace `unlockIdForTx(tx)` callers with a new helper that takes the module code (or tx) and an attempt index, so the engine can iterate primary → fallbacks. Keep `xtea_sgw` as the forced primary for `tx === 0x74F`.

2. **NRC-aware unlock loop in `OBDTab` and `BenchTab`.** Wrap the existing `27 01 → unlockKeyBytes → 27 02` block in a loop that inspects the 27 02 response (success when first byte is `0x67`, NRC when `0x7F 0x27 ..`). On NRC, advance to the next algorithm and re-issue `27 01` to get a fresh seed. Log each attempt. Stop on success or after the fallback list is exhausted; on hard failure, skip the module's DID writes and continue with the next module.

3. **24-bit DID encoder + per-module DID list.** Add a small `encodeDid(did)` helper in `lib/algos.js` (or a new `lib/uds.js`) that returns 2 or 3 bytes based on magnitude. Add `VIN_WRITE_DIDS` map: default `[0xF190, 0x7B90, 0x7B88]`, BCM `[..., 0x6E2025]`, RFHUB `[..., 0x6E2027]`, EPS `[0xF190, 0x6EF190]`. Replace the hard-coded write loops in `OBDTab.writeAll`, `OBDTab.writeOneModule`, and the EPS path so each module pulls its own list.

4. **Read-back verification after the 11 01 reset.** After the post-write reset, re-issue `0x22` for every DID just written and compare the returned ASCII against the new VIN (or its 8-char tail for `0x6E2025`/`0x6E2027`). Surface per-DID OK / MISMATCH in the log row for the module.

5. **Tests.** Extend `lib/__tests__` with: unlock fallback iteration (a fake bridge that NRCs the first 3 algos and accepts the 4th), `encodeDid` boundaries (`0xF190` → 2B, `0x6E2025` → 3B), per-module DID list lookup, and read-back verification mismatch detection.

## Relevant files

- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/lib/mods.js`
- `artifacts/srt-lab/src/lib/nrc.js`
- `artifacts/srt-lab/src/lib/bridgeEngine.js`
- `artifacts/srt-lab/src/lib/obdEngine.js`
- `artifacts/srt-lab/src/tabs/OBDTab.jsx`
- `artifacts/srt-lab/src/tabs/BenchTab.jsx`
- `artifacts/srt-lab/src/tabs/JailbreakTab.jsx`
- `artifacts/srt-lab/src/lib/__tests__`
- `attached_assets/SRTLabJailbreakEdition_1776518787584.jsx`
