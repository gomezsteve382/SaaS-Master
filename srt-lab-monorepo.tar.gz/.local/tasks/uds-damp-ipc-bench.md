# UDS VIN Write for DAMP & IPC (Bench + Live)

## What & Why
Add dedicated UDS VIN writing for Active Dampening (DAMP) and Instrument Panel Cluster (IPC) modules. These are needed for bench swaps where only specific modules need VIN updates rather than writing to all modules at once.

Also fixes a leftover bug: the BENCH tab's CRC Patch function still uses byte-sum for RFHUB instead of the corrected CRC-8 Reflected algorithm (crc8rf) from Task #6.

## Done looks like
- LIVE OBD tab has individual "Write VIN to DAMP" and "Write VIN to IPC" buttons alongside the existing "Write All" button
- BENCH tab has a new "UDS Bench Tools" section with its own Web Serial connection for writing VINs to DAMP and IPC over CAN while modules are on the bench
- Both use the standard UDS flow: Extended Session (10 03) → Seed (27 01) → CDA6 key → Key Send (27 02) → WriteDataByIdentifier (2E) to DIDs 0xF190, 0x7B90, 0x7B88 → ECU Reset (11 01)
- DAMP uses TX 0x7E4 / RX 0x7EC, IPC uses TX 0x745 / RX 0x765
- BENCH tab RFHUB CRC patch uses crc8rf instead of byte-sum

## Out of scope
- New seed/key algorithms (DAMP and IPC both use CDA6)
- Additional DIDs beyond the standard VIN set
- Other module types beyond DAMP and IPC

## Tasks
1. **LIVE OBD — individual module write buttons** — Add "Write VIN to DAMP" and "Write VIN to IPC" buttons in the Quick Tools section that perform the full UDS security-access + VIN write flow to a single module using the existing serial connection.
2. **BENCH — UDS bench connection** — Add a Web Serial connect section in the BENCH tab with its own OBDLink connection, separate from the LIVE OBD tab's connection, for bench-only UDS operations.
3. **BENCH — DAMP and IPC VIN write** — Add "Write VIN to DAMP" and "Write VIN to IPC" buttons in the BENCH tab that use the bench serial connection to perform the full UDS flow.
4. **Fix BENCH RFHUB CRC patch** — Replace byte-sum with crc8rf in the BENCH tab's doCrcPatch function for RFHUB modules.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:17`
- `artifacts/srt-lab/src/App.jsx:250-383`
- `artifacts/srt-lab/src/App.jsx:700-830`
