---
title: Fix BCM VIN Offsets in parseModule/writeModuleVIN
---
# Fix BCM VIN Offsets & Triple-Check All Paths

## What & Why
Triple-check of real Trackhawk BCM dumps revealed that `parseModule` and `writeModuleVIN` use wrong BCM VIN offsets. They use 0x5328/0x5348/0x5368/0x5388 but the actual full 17-char VINs start at 0x5320/0x5340/0x5360/0x5380 (confirmed by binary analysis of the original dump). Writing at the wrong offset corrupts the VIN data structure by overwriting 8 bytes into the existing VIN block.

The DUMPS tab (`analyzeFile` + `patchFile`) works correctly because `analyzeFile` dynamically scans for VIN patterns and finds them at the real offsets. But the SECURITY/BENCH tab code path (`parseModule` + `writeModuleVIN`) hardcodes the wrong offsets.

Binary proof from the original BCM dump:
- 0x5320: "1C4RJFDJXEC365477" CRC=0xD115 OK (real VIN start)
- 0x5328: starts at "XEC365477..." — this is byte 9 of the VIN, not a VIN start
- Same pattern repeats at 0x5340 vs 0x5348, 0x5360 vs 0x5368, 0x5380 vs 0x5388

## Done looks like
- `parseModule` reads BCM VINs at corrected offsets 0x5320/0x5340/0x5360/0x5380
- `writeModuleVIN` writes full VINs at corrected offsets with CRC16 at offset+17/+18
- `virginizeModule` clears the correct VIN ranges
- VIN patch from SECURITY/BENCH tab produces output identical to DUMPS tab for all 6 slots (4 full + 2 partial tails)
- Validated against real binary dumps: patched output matches reference software

## Out of scope
- RFHUB, 95640, GPEC2A VIN handling (those are already correct)
- The 0x5780/0x57A8 entries (non-standard, out of scope)

## Tasks
1. **Fix BCM VIN offsets in parseModule** — Change from 0x5328/0x5348/0x5368/0x5388 to 0x5320/0x5340/0x5360/0x5380.

2. **Fix BCM VIN offsets in writeModuleVIN** — Change from 0x5328/0x5348/0x5368/0x5388 to 0x5320/0x5340/0x5360/0x5380.

3. **Fix BCM VIN offsets in virginizeModule** — Change from 0x5328/0x5348/0x5368/0x5388 to 0x5320/0x5340/0x5360/0x5380.

4. **Validate all paths** — Run end-to-end binary validation against real Trackhawk BCM dumps, confirming all 6 VIN slots are correct across writeModuleVIN, doCrcPatch, parseModule, analyzeFile, and patchFile paths.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:83`
- `artifacts/srt-lab/src/App.jsx:190`
- `artifacts/srt-lab/src/App.jsx:205`