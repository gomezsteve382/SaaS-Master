---
title: GPEC2A Tile Card Layout
---
# GPEC2A Tile Card Layout

## What & Why

The reference `SRTLabJailbreakEdition_1776518787584.jsx` renders the GPEC2A view as a series of large hero "tile cards" — a SKIM ENABLED/DISABLED status block in big type, 28-pixel runtime counter values (counterA / counterB / distance / keyCycles), a 4-up transponder-key grid, and a prominent ZZZZ tamper indicator. The current `Gpec2aTab.jsx` delivers the same data but routes it through the dense `ModuleFieldsPanel` row-list, which is information-equivalent but visually flatter and harder to scan when the user is verifying a dump at a glance.

This is purely cosmetic — every field is already parsed and displayed. The change is about visual hierarchy and readability for the GPEC2A flow, which is the most common module the user inspects.

## Done looks like

- The GPEC2A tab opens with a hero status card (SKIM ENABLED green / DISABLED amber, large) at the top, mirroring the reference layout.
- Runtime counters render as a 4-column grid of large-number tiles (counterA, counterB, distance, keyCycles), each showing the value in 24–28px type with a label and the byte offset underneath.
- Transponder keys render as a 4-up grid of mono-font hex tiles with the offset label.
- ZZZZ tamper marker shows as its own bordered tile (green INTACT / red TAMPERED).
- Existing data — secret key + mirror, part-number string, PCM Sec6, VIN list — keeps its current placement; no functional changes.

## Out of scope

- Any change to `lib/parseModule.js` (data is already there).
- Functional behavior changes (write paths, downloads, virginization).
- Restyling other tabs.

## Steps

1. **Replace the `ModuleFieldsPanel` call in `Gpec2aTab` with inline hero/grid layout.** Use the existing `Card` / `Tag` / palette primitives so it stays consistent with the rest of the app's design language. Keep it under ~150 LOC.

2. **Manual visual check.** Load a known GPEC2A dump and confirm the status card, counter grid, transponder grid, and tamper tile render correctly with realistic data widths.

## Relevant files

- `artifacts/srt-lab/src/tabs/Gpec2aTab.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js:59-83`
- `artifacts/srt-lab/src/lib/ui.jsx`
- `attached_assets/SRTLabJailbreakEdition_1776518787584.jsx`