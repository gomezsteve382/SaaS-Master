# RFH VIN Checksum — Auto-detect Magic Constant

## What & Why

The RFH Gen2 VIN checksum is XOR(17 raw bytes) ^ magic, but the magic constant
varies by hardware variant: 0x87 on older Gen2, 0xDB on 2020+ Redeye. The code
currently hardcodes 0x87, causing "stored=EF calc=DD" CS FAIL badges on newer files.

The fix: on parse, derive the magic from the first slot whose stored checksum is
non-trivial (not 0x00 or 0xFF), then re-validate all slots with the detected magic.
Write the same detected magic back when producing a twinned RFH download.

The user has already provided the corrected crc.js and a diff/patch guide (in
attached_assets/files_(1)_1776306107478.zip) that fully specify both changes.

## Done looks like

- Loading a 2020 Redeye RFH: all 4 VIN slots show CS OK (was FAIL with stored=EF)
- Loading an older Gen2 RFH (magic=0x87): all 4 VIN slots still show CS OK
- Twinned RFH download uses the auto-detected magic when writing VIN checksums
- No regressions on SEC16 checksums or BCM side

## Out of scope

- Changing BCM VIN logic
- Changing any tab other than TWIN (and crc.js shared lib)
- The partial VIN tail debug logging mentioned in the patch file (diagnostic only, not a real bug)

## Tasks

1. Replace `crc.js` with the version from the zip (adds `rfhGen2DetectMagic`,
   `RFH_GEN2_VIN_CS_KNOWN_MAGICS`, updates exports; `rfhSec16Cs` unchanged).

2. In `TwinTab.jsx`:
   - Add `rfhGen2DetectMagic` to the crc.js import
   - Replace `const RFH_VIN_CS_MAGIC = 0x87` + `rfhVinCs()` with a module-level
     `let _rfhVinMagic = 0xDB` variable and a `rfhVinCs()` that uses it
   - In `parseRfhGen2()`, immediately after the `vins` map block, add the
     auto-detection block: find the first slot with a non-trivial `csStored`,
     derive `_rfhVinMagic = csStored ^ xorAll`, then re-run csCalc/csOk on all slots
   - `applyRfhFromBcm()` already calls `rfhVinCs(rev)` which will automatically
     use the detected magic — no additional change needed there

## Relevant files

`artifacts/srt-lab/src/lib/crc.js`
`artifacts/srt-lab/src/tabs/TwinTab.jsx:144-200`
`attached_assets/files_(1)_1776306107478.zip`
