# Fix CAN-IHS Speed and Return Path

## What & Why
Task #23 fixed the physical-layer switch (`STP61` → OK), but IHS modules still
return NO DATA because of two remaining bugs:

1. **Wrong protocol after STP61**: `ATSP7` selects ISO 15765-4 at 250 kbps and
   **29-bit** headers. FCA CAN-IHS (MS-CAN) uses **125 kbps, 11-bit** headers.
   Fix: remove `ATSP7`; instead issue `STPBR 125000` which overrides the baud
   rate on the current protocol (ISO 15765-4 11-bit from ATSP6) to 125 kbps.

2. **Return path — `STP60` returns `?`**: OBDLink EX r2.1 firmware does not
   recognise `STP60`. Fix: use `STPBR 500000` to restore 500 kbps and then
   re-issue `ATSP6` (which re-initialises the protocol back to CAN-A at the
   restored speed). Drop `STP60` entirely.

Real-world log evidence (session 00:51):
- `STP61 OK`, `ATSP7 OK`, all IHS → `NO DATA`
- `STP60 ?`

## Done looks like
- UDS log shows `STPBR 125000` instead of `ATSP7` after `STP61`.
- UDS log shows `STPBR 500000` then `ATSP6` for the return path — no `STP60`.
- BCM, RFHUB, ABS, IPC, and other IHS modules return live responses on a
  vehicle where those modules are active.

## Out of scope
- Changes to parsers, DUMPS tab, SECURITY tab, or any other tab.
- ELM327 path — already warns user it cannot reach CAN-IHS.

## Tasks
1. In `OBDTab` `scan()`, replace `ATSP7` (after `STP61`) with `STPBR 125000`.
2. In the return block, remove `STP60` and change the sequence to:
   `STPBR 500000` → `ATSP6` → 100 ms delay → `ATST96`.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:1079-1108`
