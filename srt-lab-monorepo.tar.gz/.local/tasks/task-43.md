---
title: Remove ANALYZER tab (duplicate of SECURITY)
---
---
  title: Remove ANALYZER tab (duplicate of SECURITY)
  ---
  # Remove ANALYZER tab

  ## What & Why
  The ANALYZER tab (`FcaAnalyzerTab`) duplicates functionality already in the
  SECURITY tab. The user has confirmed they are the same and wants ANALYZER removed.

  ## Done looks like
  - The ANALYZER tab no longer appears in the tab bar
  - No runtime errors or broken imports

  ## Tasks
  1. `artifacts/srt-lab/src/App.jsx`:
     - Remove `import FcaAnalyzerTab from "./FcaAnalyzerTab";` (line 2)
     - Remove the `{id:'analyzer',...}` entry from the TABS array (line 247)
     - Remove `{pg==='analyzer'&&<FcaAnalyzerTab/>}` render (line 272)
  2. Delete `artifacts/srt-lab/src/FcaAnalyzerTab.jsx`
  3. Delete `artifacts/srt-lab/src/tabs/FcaAnalyzerTab.jsx` (if present)
  4. Rebuild and restart the workflow.