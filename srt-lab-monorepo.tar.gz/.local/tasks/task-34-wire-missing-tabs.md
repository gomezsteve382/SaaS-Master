# Wire SWARM + J2534 Tabs + Fix Security Tab

## What & Why

Three significant gaps were found during a full code audit:

1. **SWARM tab is invisible**: `OBDSwarmDiagnostic.jsx` (517 lines) exists but is not imported by App.jsx and does not appear in the TABS array. The user cannot reach it.

2. **J2534 tab is invisible**: `J2534Scanner.jsx` (383 lines) exists but is not imported by App.jsx and does not appear in the TABS array. The user cannot reach it.

3. **Security tab is the old inline version**: App.jsx defines `SecurityTab` inline (lines 527–850), while `src/tabs/SecurityTab.jsx` (the enhanced version from Task #31) exists but is never imported. The inline version is missing critical features: the `🔗 Sync GPEC2A + RFHUB` button (`syncGpecRfh`), the `rfhPcmSync` and `rfhBcmSync` doTool actions, `setMods` after doTool patches (so the Overview cross-validates live results), the RFHUB→GPEC2A SEC6 write inside `matchAll`, and the SEC16/PCM-SEC6/BCM-SEC16/rfhVin92 display rows in the Overview table.

## Done looks like

- 10 tabs visible in the tab bar: the existing 9 plus **SWARM** (🌐) and **⚡ J2534** appear.
- Clicking SWARM shows the `OBDSwarmDiagnostic` component (CAN Bus scan UI).
- Clicking J2534 shows the `J2534Scanner` component (Raw CAN PassThru UI).
- The SECURITY tab now has the "🔗 Sync GPEC2A + RFHUB" button and the "RFH→PCM SEC6 Import" and "RFH→BCM SEC16 Import" tool cards.
- After any doTool action that patches a file (Virginize, Write VIN, SKIM Toggle, RFH→PCM sync, etc.), the Overview table refreshes immediately to reflect the change.
- The Overview table shows SEC16-1, SEC16-2, PCM-SEC6, BCM-SEC16, and VIN@92 rows when the corresponding data is present in loaded RFHUB and GPEC2A files.
- Build completes without errors.

## Out of scope

- Changes to the SWARM or J2534 component logic itself.
- Removing the orphan tab files in `src/tabs/` (DumpsTab, BenchTab, OBDTab, SeedTab, GpecTab, Gpec2aTab) — leave them for a later cleanup task.
- Any changes to `parseModule.js` or `crossValidate.js`.

## Tasks

1. **Fix SecurityTab.jsx imports** — Add a local `const hxb` definition (one line, same as App.jsx line 47), and add `fO`, `countSkimRecs`, `syncImmoBackup` to the existing `parseModule.js` import in SecurityTab.jsx (they are already exported from that file).

2. **Replace App.jsx's inline SecurityTab** — Remove the inline `function SecurityTab()` block (lines 527–850 of App.jsx) and add `import SecurityTab from "./tabs/SecurityTab"` at the top of App.jsx alongside the existing FcaAnalyzerTab and ImmoVINTab imports.

3. **Wire SWARM tab** — Add `import OBDSwarmDiagnostic from "./OBDSwarmDiagnostic"` to App.jsx, append `{id:'swarm',i:'🌐',l:'SWARM',s:'CAN Bus Scan'}` to the TABS array (after `immovin`), and add `{pg==='swarm'&&<OBDSwarmDiagnostic/>}` to the render block.

4. **Wire J2534 tab** — Add `import J2534Scanner from "./J2534Scanner"` to App.jsx, append `{id:'j2534',i:'⚡',l:'J2534',s:'Raw CAN PassThru'}` to the TABS array (after `swarm`), and add `{pg==='j2534'&&<J2534Scanner/>}` to the render block.

5. **Verify build** — Run `pnpm run build` inside `artifacts/srt-lab/` and confirm it exits cleanly with no undefined-symbol errors.

## Relevant files

- `artifacts/srt-lab/src/App.jsx:1-10,243,527-850,1430-1530`
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx:1-10`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx`
- `artifacts/srt-lab/src/J2534Scanner.jsx`
- `artifacts/srt-lab/src/lib/parseModule.js:158`
