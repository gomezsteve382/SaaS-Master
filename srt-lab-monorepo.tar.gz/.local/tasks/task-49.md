---
title: Remove Security tab, rename TWIN → Security Byte Match
---
# Remove Security Tab, Rename TWIN to "Security Byte Match"

## What & Why

The standalone SECURITY tab is redundant now that the TWIN tab covers cross-matching
BCM and RFH security bytes with full validation. Remove SECURITY and rename TWIN to
"SECURITY BYTE MATCH" so the function is clearly named in the nav.

## Done looks like

- 11 tabs → 10 tabs; the SECURITY tab is gone
- The former TWIN tab now appears as "SECURITY BYTE MATCH" in the nav bar
- Everything inside the tab (BCM ↔ RFH load, sync, download) works exactly as before
- No dead imports or console errors

## Out of scope

- Any changes to the content or logic inside TwinTab
- Changing any other tab

## Tasks

1. In the TABS array in App.jsx, remove the `skim` entry (label: SECURITY) and change
   the `twin` entry label from `TWIN` to `SECURITY BYTE MATCH` (subtitle can stay or
   be updated to `BCM ↔ RFH Sync`).
2. Remove the now-unused `SecurityTab` import from App.jsx and remove its render case
   in the tab switcher.
3. Confirm the SecurityTab.jsx file itself can stay (no need to delete it), just
   no longer imported or rendered.

## Relevant files

`artifacts/srt-lab/src/App.jsx:246`