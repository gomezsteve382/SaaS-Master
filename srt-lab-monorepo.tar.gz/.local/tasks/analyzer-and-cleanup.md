# FCA Analyzer + Byte-Level Audit + Legacy Cleanup

## What & Why
Final migration chunk. Three jobs in one task because they all touch the same surface (tab list, lib/ helpers, replit.md):

1. **Port the FCA Module Analyzer tab** verbatim from `attached_assets/fca_module_analyzer_1776013402484.jsx` plus the merged-in helpers in the reference `App.jsx` (lines 50–234).
2. **Byte-level audit pass** — diff every already-migrated tab (BCM, RFHUB, ECM, ADCM, ProgramAll, UDS, Backups, Sessions) against the reference `App.jsx` to confirm every constant, address, algorithm coefficient, DID, routine ID, byte offset, CRC seed, and timing value matches. File drift-fix follow-ups for anything missing.
3. **Legacy cleanup** — reconcile the tab list with the reference, archive superseded drafts, refresh `replit.md`.

## Done looks like
- An Analyzer tab loads `.bin` files (multi-select), auto-detects module type, parses every documented field per type, runs `crossValidate`, supports the four sub-tabs (overview / security / diff / tools), supports virginize / writeVIN / SKIM toggle / extract-key with a download button.
- Audit report is checked into `.local/tasks/audit-report.md` listing, per tab, every constant verified vs the reference and any drift items.
- Drift items become small follow-up project tasks (one per drift, not bundled), each with the exact reference line numbers cited.
- Tab list matches the reference order exactly. Legacy tabs not present in the reference are either removed or explicitly retained with a one-line justification in `replit.md`.
- Superseded drafts are cancelled (see "Drafts to archive" below) after user confirmation.
- `replit.md` reflects the new architecture (Master VIN context, per-module tabs, paper trail, backups, J2534 driver).

## Out of scope
- Implementing any drift-fix follow-ups (those become separate tasks).
- Re-implementing OBD swarm / J2534 scanner from scratch — only delete or relabel.
- New algorithms beyond the reference.

## Tasks
1. **Port Analyzer tab** — see "Analyzer spec" below for the complete byte-level contract.
2. **Run byte-level audit** — see "Audit checklist" below.
3. **File drift-fix follow-ups** — one project task per drift item, never batched.
4. **Reconcile tab list** — see "Tab reconciliation" below.
5. **Archive superseded drafts** — see "Drafts to archive" below; confirm with user before cancelling.
6. **Refresh `replit.md`** — record the new architecture, file layout, J2534 driver swap, paper-trail / backups conventions.
7. **Final smoke** — `PORT=3000 BASE_PATH=/srt-lab pnpm run build`, restart workflow, click every tab.

## Analyzer spec (byte-level)

### Module type detection
- `length === 65536 || 131072` → BCM (also confirm `FEE1000` magic anywhere in first 256 bytes).
- `length === 8192 || 16384` → 95640.
- `length === 4096`: if first 17 bytes are alphanumeric ASCII and `data[0x0011]` is `0x80 / 0x00 / 0x02` (or VIN at `0x01F0` decodes) → GPEC2A; otherwise RFHUB.
- `length > 131072` → FW.
- `MODULE_TYPES`: `GPEC2A` (95320 SPI / 4096B / #ff6b35), `RFHUB` (Internal EEPROM / 4096B / #00d4aa), `BCM` (FEE Emulation / 65536B / #5b8cff), `UNKNOWN` (— / 0 / #7a8194).

### Per-type field extraction
**GPEC2A** (use the reference's offsets — note these supersede any older analyzer copy):
- VINs at `0x0000`, `0x01F0`, `0x0224` (17B ASCII).
- `skimByte = data[0x0011]`; `SKIM_VALUES = {0x80:"ENABLED", 0x00:"DISABLED", 0x02:"DISABLED (alt)"}`.
- `secretKey` at `0x0203` (8B), `secretKeyMirror` at `0x0361` (8B), `keyConsistent = arrEq(...)`.
- `transponderKeys[i]` at `0x0888 + i*4` for i in 0..3 (4B each).
- `zzzzTamper` at `0x0C8C` (8B), `intact = data[0x0C8C] === 0x5A`.
- `partNumberStr = extractVIN(data, 0x0FA1, 13) || extractHex(data, 0x0FA1, 13)`.
- `runtimeCounters`: counterA `0x0E61` (4B u32), counterB `0x0E69`, distance `0x0E6D`, keyCycles `0x0E75`.

**RFHUB**:
- VINs at `0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1` (17B). For each, also store `sc = data[off+17]` (stored CRC), `cc = crc8rf(data.slice(off, off+17))`, `crcOk = sc === cc`. If none decode forward, try mirrored (reverse 17 bytes) — set `mirrored: true`.
- Fallback: if no known offset hits, `scanForVINs(data)` (17-byte alphanumeric run, no I/O/Q, with non-alphanumeric boundaries).
- `vehicleSecret` at `0x050E` (16B, big-endian).
- `fobikSlots = countAA50(data, 0x0880, 10)` (count of `AA 50` pairs in 20 bytes).
- `securityMarkers = countPat(data, 0xCC, 0x66, 0xAA, 0x55)`.
- `zzzzBlocks = countPat(data, 0x5A, 0x5A, 0x5A, 0x5A)`.
- `partNumbers.hw` at `0x0808` (10B), `.sw` at `0x0812` (10B), `.cal` at `0x082C` (14B). Fall back to hex if not ASCII.
- `skey = data.slice(0x40, 0x50)`, `skoff = 0x40`, `skb = all 0xFF`.

**BCM** (note: the merged App.jsx parser uses `0x5320/0x5340/0x5360/0x5380` — newer than the older analyzer's `0x5328/0x5348/0x5368/0x5388`. **Use the reference App.jsx offsets**):
- VINs at `0x5320, 0x5340, 0x5360, 0x5380` (17B + 2B CRC16 footer poly `0x1021` init `0xFFFF`).
- `partialVins` at `0x4098` and `0x40B0`: 8B ASCII tail + 2B CRC16 of those 8 bytes.
- `vehicleSecret` at `0x40C9` (16B, little-endian).
- `securityLock` at `0x8028`, `locked = value === 0x5A`.
- `fobikCount = data[0x5862]`.
- `immoKeys` at `0x81A4, 0x81C4, 0x81E4` (16B each).
- `fobikParts = extractVIN(data, 0x5818, 10) || extractHex(data, 0x5818, 10)`.
- `skey = data.slice(0x40C9, 0x40D9)` (16B, little-endian).
- IMMO blocks: live `0x40C0`, backup `0x2000`, block size `IMMO_REC * IMMO_KC = 24 * 8 = 192` bytes. `immoSynced` true when both blocks have records and are byte-equal.

**95640**:
- VINs at `0x275, 0x288` (17B + 1B CRC8/0x42 stored at `off-1`).
- `skey = data.slice(0x40, 0x50)`, `fobBlank = data.slice(0x200, 0x240) all 0xFF`.

### Cross-validation rules
- VIN consistency: union of all `vins[*].vin` — size 0 = warn "no VINs", size 1 = pass "VIN consistent: …", size > 1 = error "VIN MISMATCH: …".
- RFHUB ↔ BCM vehicle secret: BCM bytes reversed must equal RFHUB bytes → pass "MATCH (byte-reversed)" else issue "MISMATCH".
- GPEC2A SKIM: `0x80` = pass ENABLED, `0x00` = warn DISABLED.
- GPEC2A `keyConsistent` false → issue.
- GPEC2A ZZZZ tamper: intact = pass, cleared = warn.
- BCM securityLock: locked = pass, unlocked = warn.
- RFHUB FOBIK slots count + `CC66AA55` marker count → pass info.
- BCM FOBIK count → pass info; mismatch with RFHUB.fobikSlots → warn.
- 95640 secret key all-FF = warn ERASED, otherwise pass SET.
- 95640 ↔ RFHUB skey arrEq → pass MATCH else issue MISMATCH.

### Tools
- **virginize** (GPEC2A): `data[0x0011]=0x00`, zero `0x0203..0x020A`, zero `0x0361..0x0368`, fill `0x0888..0x0898` with `0xFF`, zero `0x0C8C..0x0C93`.
- **virginize** (RFHUB): zero 18B at each VIN offset, fill `skey 0x40..0x4F` and `0x200..0x23F` with `0xFF`.
- **virginize** (BCM): zero 19B at each VIN offset, fill IMMO blocks (`0x2000` and `0x40C0`, 192B) with `0xFF`.
- **virginize** (95640): zero `[off-1, off+16]` at each VIN offset, fill skey with `0xFF`.
- **writeVIN**: per-type offsets above + recompute CRCs (BCM crc16, 95640 crc8/0x42, RFHUB crc8rf or mirrored crc8rf for mirrored variants).
- **skimToggle** (GPEC2A): flip `data[0x0011]` between `0x80` and `0x00`.
- **extractKey**: dump `secretKey.hex` (GPEC2A) or `vehicleSecret.hex` (BCM/RFHUB).

### Diff
- `computeDiff(a, b)` returns `{totalChanged, groups: [[start,end], ...], changedSet}`. Adjacent changed bytes group together.

## Audit checklist (verify each is in the merged code; file drift task per miss)

### Foundation (#77) — verify in `src/lib/`
- `crc16` (poly `0x1021` init `0xFFFF`), `crc8_42` (init `0x2E`), `crc8rf` (init `0x54`, ref poly `0xA0`), `crc16ccitt`, `u32`.
- `MasterVinContext`: vin, vinValid (`/^[A-HJ-NPR-Z0-9]{17}$/`), moduleStatus per BCM/RFHUB/ECM/ADCM, updateStatus, resetStatus, setPg.
- `initAdapter`: ATZ 3000 ms + 1000 ms settle + STN PP2C/PP2D.
- Backups capped at 50, sessions capped at 500.
- `decodeNRC` covers the standard UDS NRCs.

### BCM tab (#78)
- Address candidates: `[0x750/0x758 'CDA6 primary (2017 Scat Pack)', 0x742/0x762, 0x7E0/0x7E8, 0x6B0/0x6B8]` (reference line 3052).
- Unlock: `0x10 0x03` → `0x27 0x01` (seed) → `cda6(seed)` key → `0x27 0x02 + key bytes`. Fallback algorithms list in reference line 3113+.
- VIN write triple: DIDs `0xF190, 0x7B90, 0x7B88` (reference line 3079, 3170).
- Short-VIN CRC display: `crc16ccitt(masterVin.slice(-8) bytes)`.

### RFHUB tab (#78)
- Address: `0x75F/0x767` primary.
- `RFHUB_KNOWN_ALGOS[masterVin]` lookup (reference line 3448).
- Key fob routines: learn `0x0401`, locate `0x0403`, erase all `0x0404` (reference lines 3651–3653).
- PIN attempts capped at 3.

### ECM tab (#79)
- Address: `0x7E0/0x7E8`.
- `ECM_ALGOS` (10 entries, reference lines 3703–3714):
  1. GPEC2 Continental — `sxor(seed, 0xE72E3799)`
  2. GPEC2 Flash — `sxor(seed, 0x966AEEB1)`
  3. GPEC2 EPROM — `sxor(seed, 0x3F711F5A)`
  4. GPEC3 2018+ — `sxor(seed, 0x129D657F)`
  5. GPEC2A — `sxor(seed, 0xCE853A6F)`
  6. GPEC2 2015 — `sxor(seed, 0x47EC21F8)`
  7. GPEC1 — `sxor(seed, 670269)`
  8. NGC — `ngc(seed)` with NT/NS tables (reference line 11)
  9. SBEC legacy — `u32(seed*4 + 0x9018)`
  10. JTEC — fixed `0x00000000`
- `sxor` body: `for(i=0;i<5;i++) k = (k & 0x80000000) ? u32((k<<1) ^ c) : u32(k<<1)`.
- Re-request seed after each failed key attempt (300 ms delay).
- Read DIDs in this order: `0xF190 VIN, 0xF187 PN, 0xF189 SW, 0xF18C Serial, 0xF191 HW, 0xF194 SW Fingerprint, 0xF195 Cal ID`.

### ADCM tab (#79)
- `ADCM_MODULES`: 5 candidates (reference line 1971).
- `ADCM_VARIANTS`: 14 entries (reference line 1977).
- Unlock: Routine `0x0312` (`0x31 0x01 0x03 0x12`) — if rejected, fall back to security unlock.
- Triple VIN write: `0xF190, 0x7B90, 0x7B88`.
- Variant-config DIDs: `0xF1A1, 0xDE10, 0xDE11`.

### Backups (#81) — `CRITICAL_DIDS` per module (reference lines 2720–2760)
- BCM: `0xF190, 0xF1A1`, `0x7B90, 0x7B88`, plus standard set.
- RFHUB: `0xF190` + standard.
- ECM: `0xF190` + standard.
- ADCM: `0xF190, 0xF1A1, 0xDE10, 0xDE11, 0x7B90, 0x7B88`.
- Backup key prefix: `srtlab_backup_`, index key: `srtlab_backup_index`, max 50 with auto-rotate.

### Sessions (#81)
- Storage key: `srtlab_sessions`, cap 500.
- Entry fields: `module, operation, oldVin, newVin, moduleAddr {tx,rx}, adapter, algorithm, success, technician, titleRef, titleNotes, preWriteConfirmed (ISO timestamp)`.

### ProgramAll + UDS (#80, in flight)
- `MODULE_PRESETS` (16 entries, reference lines 3917–3926):
  - BCM `0x750/0x758`, RFHUB `0x75F/0x767`, ECM `0x7E0/0x7E8`, TCM `0x7E1/0x7E9`,
  - ABS `0x760/0x768`, IPC `0x740/0x748`, ORC `0x758/0x760`, ADCM `0x7A8/0x7B0`,
  - RADIO `0x772/0x77A`, HVAC `0x751/0x759`, EPS `0x761/0x769`, SCCM `0x74D/0x76D`,
  - TIPM `0x74C/0x76C`, AMP `0x7A0/0x7A8`, BSM `0x770/0x778`, TPMS `0x752/0x75A`.
- UDS quick-ops: read DID `0x22`, write DID `0x2E`, session `0x10 ss`, tester present `0x3E 0x00`, ECU reset `0x11 0x01`, routine `0x31 ctrl rid+rid data` (ctrl 01/02/03), read DTCs `0x19 0x02 0x08`, clear DTCs `0x14 0xFF 0xFF 0xFF`.
- DTC decode: `prefix = ['P','C','B','U'][(byte0 >> 6) & 3]`, code = prefix + `(byte0 & 0x3F)` nibble + byte1 + byte2.
- ProgramAll cross-verify: probe each of the 4 modules, send `0x10 0x03` then `0x22 0xF1 0x90`, parse VIN from `0x62` response, compare against masterVin.
- ProgramAll status grid: `pending` (`#9E9E9E`), `writing` (`#FFB300`), `ok` (`#00C853`), `fail` (`#FF1744`).

## Tab reconciliation

**Reference tab order** (TABS, lines 242–256+):
program, bcm, rfhub, ecm, adcm, uds, backups, sessions, jailbreak, dumps, obd, bench, seed, …

**Currently in srt-lab not in reference** (decide remove vs retain):
- `TwinTab` — superseded by ProgramAll cross-verify.
- `ImmoVINTab` — overlaps Analyzer + Backups.
- `OBDSwarmDiagnostic` — keep as advanced diagnostic; not in reference but useful.
- `J2534Scanner` — keep, paired with the Python J2534 driver.

## Drafts to archive (confirm with user before cancelling)
Superseded by the migration:
- #1 Bench Mode — covered by ProgramAll.
- #2 Add FCA Module Analyzer — implemented by this task.
- #3 CRC Patch & Trackhawk SKIM — covered by Analyzer + foundation CRCs.
- #4–#9 BCM/RFH parser + CRC fixes — covered by Foundations + BCM/RFHUB tabs.
- #14–#21 Live OBD scan / ELM327 / multi-attempt — covered by `initAdapter`.
- #22, #34, #37–#46 Twin/RFH/BCM SEC16 work — superseded by ProgramAll cross-verify + Analyzer.
- #29 Split App.jsx — naturally happens through the migration.
- #31–#33 Security/ImmoVIN tabs — superseded by Analyzer.
- #43 Remove Analyzer tab — obsolete (Analyzer is back).
- #47–#58 SEC16/checksum work — superseded by Foundations + Analyzer.
- #59 JAILBREAK / UDS Workshop — superseded by UDS tab (#80).
- #60 Desktop J2534 Driver — superseded by #76.

Keep open: #61–#68, #73–#75, #83+ (active follow-ups).

## Relevant files
- `attached_assets/App_1776444434000.jsx`
- `attached_assets/fca_module_analyzer_1776013402484.jsx`
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/src/tabs/`
- `artifacts/srt-lab/src/lib/`
- `replit.md`
