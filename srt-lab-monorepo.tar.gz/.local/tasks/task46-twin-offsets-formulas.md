# Fix All TWIN Tab Offsets & Checksum Formulas

## What & Why

Binary forensic analysis of 4 real ECU dumps (original + FCA-SINCRO-twinned BCM and RFH)
revealed that every offset and every checksum formula in the TWIN tab is wrong.
These bugs mean the TWIN tab displays incorrect data and produces corrupt synced files.
All corrections below are verified byte-for-byte against real FCA SINCRO output.

## Done looks like

- BCM SEC16 mirrors parsed at the correct addresses (0x40C9 / 0x40F1, not 0x00C9 / 0x00F1)
- BCM SEC16 MIRROR CS badge shows OK/FAIL using the verified CRC formula
- BCM VIN read from correct addresses (0x5328 / 0x5348 / 0x5368 / 0x5388)
- BCM VIN CS badge continues to show OK (formula unchanged, just offset fixed)
- RFH SEC16 CS computed with verified formula; SLOT CS badges show OK on real files
- Synced BCM download (BCM←RFH) writes correct data and CRC to all 5 BCM SEC16 locations
- Synced RFH download (RFH←BCM) writes correct data and CS to both RFH slots

## Out of scope

- Any tab other than TWIN
- BCM VIN write-back (VIN was already identical in both directions in the reference files)
- UI redesign

## Verified corrections (all confirmed with real binaries)

### A. BCM SEC16 mirror offsets
- WRONG: `[0x00C9, 0x00F1]`
- CORRECT: `[0x40C9, 0x40F1]`

### B. BCM SEC16 CRC position
- WRONG: off+16 / off+17 (immediately after 16 data bytes)
- CORRECT: off+19 / off+20
- Bytes off+16..+18 are the fixed gap `8F FF FF` — never rewrite them

### C. BCM SEC16 CRC formula
- WRONG: CRC16 CCITT of 16 bytes only
- CORRECT: CRC16 CCITT (poly=0x1021, init=0xFFFF) of **20 bytes** starting at `off-1`
  - Range = `[ buf[off-1], buf[off..off+15], buf[off+16], buf[off+17], buf[off+18] ]`
  - The pre-byte at `off-1` is a fixed structural byte (`0x02` in every verified dump);
    read it from the file at parse time rather than hard-coding it, so the formula
    correctly handles any file where it might differ.
  - Result stored big-endian at off+19 / off+20

### D. BCM VIN primary offsets
- WRONG: `[0x1338, 0x1358, 0x1378, 0x1398]`
- CORRECT: `[0x5328, 0x5348, 0x5368, 0x5388]`
- VIN CS formula (CRC16 CCITT of 17 ASCII bytes → stored at off+17/off+18) is unchanged
  and already correct — only the base offsets were wrong

### E. RFH SEC16 CS formula
- WRONG: `(XOR(16 bytes) ^ 0x8B) << 8 | 0x00`
- CORRECT: `CRC8(poly=0x65, init=0xBF, no-reflect, no-xorOut)` of the 16 data bytes
  - Result in byte[0] (off+16); byte[1] (off+17) = 0x00 always
  - Must update `crc.js` (add / replace `rfhSec16Cs`) and all call sites

### F. BCM 0x81xx additional SEC16 copies
FCA SINCRO writes to 3 more copies when doing BCM←RFH. Their structure is split:
- Copy offsets: 0x81A9, 0x81C9, 0x81E9
- Bytes 0-6 of SEC16 → write to `copy_off + 0..6`
- Fixed gap `04 04 00 14` at `copy_off + 7..10` → do NOT overwrite
- Bytes 7-15 of SEC16 → write to `copy_off + 11..19`
- No CRC bytes follow these copies

## Tasks

1. Update `crc.js`: replace the `rfhSec16Cs` export with CRC8(poly=0x65, init=0xBF); no XOR magic.
2. Update `TwinTab.jsx` constants: fix `BCM_SEC16_OFFSETS` to `[0x40C9, 0x40F1]` and `BCM_VIN_PRIMARY` to `[0x5328, 0x5348, 0x5368, 0x5388]`.
3. Update `parseBcm` in `TwinTab.jsx`: read CRC at off+19/off+20 (not off+16/17); compute CRC16 CCITT over 20 bytes starting at off-1; set `csOk` accordingly.
4. Update `applyBcmFromRfh` in `TwinTab.jsx`: write CRC at off+19/off+20 (not off+16/17); compute CRC16 CCITT over 20 bytes including the pre-byte and gap bytes. Also write the 3 additional copies at 0x81A9, 0x81C9, 0x81E9 using the split structure (bytes 0-6 at copy+0..6, bytes 7-15 at copy+11..19, gap copy+7..10 untouched).
5. Update all call sites that use `rfhSec16Cs` from `crc.js` (SecurityTab, TwinTab, parseModule) to pass the 16 raw bytes directly — no XOR step needed at the call site.
6. Verify: parse both the OG and HERMANADO files in the TWIN tab UI; all CS badges should show OK.

## Relevant files

`artifacts/srt-lab/src/lib/crc.js`
`artifacts/srt-lab/src/tabs/TwinTab.jsx`
`artifacts/srt-lab/src/tabs/SecurityTab.jsx`
`artifacts/srt-lab/src/lib/parseModule.js`
