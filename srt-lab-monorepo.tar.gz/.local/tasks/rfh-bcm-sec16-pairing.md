# RFH → BCM (95640) SEC16 Byte-Reverse Pairing

## What & Why

The FCA SINCRO reference tool has a second pairing path: **RFH (24C32) → BCM (ST95640/25C640)** that is completely separate from the RFH → PCM path already implemented. The ST95640 (our module type `95640`) stores the pairing SEC16 at **offset 0x838** — but in **byte-reversed** order relative to the RFH SEC16. The 95640 also has a VIN at **0x1B82** not yet scanned, and the RFHUB has a secondary VIN at **0x92** that the reference tool checks but we don't parse.

Key rules extracted from reference screenshots:
- **RFH SEC16 slots**: Slot 1 @ 0xAE, Slot 2 @ 0xC0, each 16B + 2B CS (already parsed ✓)
- **BCM (95640) SEC16**: @ 0x838, 16B + 2B CS (CRC16 of the 16B). The 16 bytes are the RFH SEC16 with bytes reversed (index 0↔15, 1↔14, etc.)
- **Sync operation**: take RFH SEC16 slot 1 (16B) → reverse all 16 bytes → write to 95640 @ 0x838 → recompute 2B CRC16 → write at 0x848
- **VIN additions**: RFHUB has a VIN at 0x92 (17B + 2B CS); 95640 has a VIN at 0x1B82 (17B + 2B CRC16)

## Done looks like

1. Drop a 95640 dump → Overview table shows a **BCM-SEC16** row at 0x838 with the raw hex, CS valid/bad badge, and the "→ RFH form" (byte-reversed hex) on the same row
2. Drop a RFHUB dump → Overview also shows any VIN found at offset 0x92 as **RFH-VIN-92**
3. Drop a 95640 dump → it checks offset 0x1B82 for a VIN and includes it in the VIN list
4. ANALYZER → TOOLS sub-tab → new **"RFH → BCM (95640) SEC16 Import"** card appears; it shows RFHUB generation, SEC16 validity, current 95640 SEC16 state, and an import button — requires target module to be 95640 and RFHUB to have `sec16valid`
5. Clicking the import button writes the byte-reversed RFH SEC16 + updated CRC16 to the 95640 at 0x838, then outputs a downloadable modified `.bin`
6. ANALYZER → SECURITY (cross-validate) shows new checks: **95640 SEC16 (reversed) ↔ RFH SEC16: MATCH/MISMATCH** and **RFH VIN@0x92 vs 95640 VIN@0x1B82**
7. SECURITY sub-tab per-module card for 95640 shows BCM SEC16 hex + CS state inline

## Out of scope

- PIN derivation from SEC16 (5-digit "66666" in reference — algorithm unknown)
- RFH Part Number / Serial parsing (offsets not documented in the reference screenshots)
- Generation scoring algorithm (gen1=3, gen2=6 numeric scores — scoring heuristic unknown; retain the existing size-based rfhGen label)
- Any live OBD read/write of the 95640 — this is offline dump analysis only

## Tasks

1. **95640 parser additions** — In `parseModule` for type `95640`: parse BCM SEC16 at 0x838 (16B raw + 2B CS, validate with CRC16, compute byte-reversed form, store as `bcmSec16`); add 0x1B82 to the VIN offset scan list (bounds-check: only if file ≥ 7061 bytes).
2. **RFHUB parser addition** — Add VIN scan at offset 0x92 in the `RFHUB` branch: 17B + 2B CRC16 checksum, stored as `rfhVin92` (separate from existing VIN list which uses 0x0ea5–0x0ee1 range).
3. **doTool 'rfhBcmSync'** — Add new action: source = first `RFHUB` module in `mods` with `sec16valid`; target = `mods[tt]` which must be type `95640`; byte-reverse the 16B of SEC16 slot 1; write to 95640 @ 0x838; compute CRC16 of the 16 reversed bytes; write 2B big-endian at 0x848; produce downloadable `.bin`.
4. **TOOLS sub-tab card** — Add "RFH → BCM (95640) SEC16 Import" card after the existing "RFH → PCM SEC6 Import" card. Show RFHUB gen badge + SEC16 validity, current 95640 BCM-SEC16 state (hex + CS), import button. Button disabled if RFHUB `!sec16valid` or target not 95640. Show reversed-byte preview.
5. **Overview table** — In the overview table rows section, add a `bcmSec16` row for 95640 modules: offset 0x838, label "BCM-SEC16", hex, CS valid/bad badge, "→RFH" byte-reversed hex. Add `rfhVin92` row for RFHUB modules if `info.rfhVin92` is set.
6. **Cross-validate** — In `crossValidate`: compare `e95.bcmSec16.reversedHex` with `rfhub.sec16s[0].hex` and push pass/warn. Compare `rfhub.rfhVin92` with `e95.vins` if available. Also add security sub-tab inline display for 95640 cards (BCM-SEC16 row with CS state).

## Relevant files

- `artifacts/srt-lab/src/App.jsx:44-132` — `parseModule` function (all type branches)
- `artifacts/srt-lab/src/App.jsx:135-200` — `crossValidate` function
- `artifacts/srt-lab/src/App.jsx:621-641` — `doTool` function
- `artifacts/srt-lab/src/App.jsx:700-715` — overview table rows (sec16s / pcmSec6 rendering)
- `artifacts/srt-lab/src/App.jsx:770-780` — security sub-tab per-module card rows
- `artifacts/srt-lab/src/App.jsx:851-865` — TOOLS sub-tab existing RFH→PCM card
