---
title: Fix Scan: Wake Modules Before VIN Read
---
# Fix Scan: Wake Modules Before VIN Read

## What & Why
Scan found only ECM despite 5 modules on bench. Most Stellantis modules require a `10 01` (Start Default Diagnostic Session) to wake before they respond to DID reads like `22 F1 90`. The ECM is typically always awake, explaining why only it responded.

## Done looks like
- Scan sends `10 01` to wake each module before attempting `22 F1 90` VIN read
- If VIN read still fails, module is still added to found list with "NO VIN" if the `10 01` got any positive response (presence detection)
- Small settling delay (100ms) between modules to let adapter switch cleanly
- All 5 bench modules should now be discovered
- No changes to connect(), send(), init sequence, or uds() parser

## Changes
In the `scan` callback (~line 854):
1. Before `uds(m.tx,m.rx,[0x22,0xF1,0x90])`, add `uds(m.tx,m.rx,[0x10,0x01])` wake-up call
2. Add 100ms delay after wake-up before VIN read  
3. If VIN read fails but wake-up succeeded (r.ok), add module with vin='NO VIN' as presence fallback
4. Add 100ms delay between modules

## Out of scope
- Changing connect/send/uds internals
- Changing AT init sequence
- Changing baud rate or prompt detection

## Relevant files
- `artifacts/srt-lab/src/App.jsx` — scan callback at ~line 854, MODS at line 16