---
title: AlfaOBD seed-key bridge (w6 core + 380 wrappers + ht/f/ao + de-DEMO)
---
# AlfaOBD Seed-Key Algorithms (w6 core + ht / f / ao + 740-wrapper catalog)

## What & Why
The AlfaOBD reverse-engineering drop reveals that AlfaOBD's seed-key
universe is built on a small number of shared algorithm cores that get
parameterized per-ECU, plus three standalone crypto methods. The drop
delivers:

- **3 standalone algorithms** — `ht` (linear bit-shuffle), `f`
  (XTEA, custom delta `0x8F750A1D`, little-endian seed),
  `ao` (same XTEA, big-endian seed). Triggered by specific ECU
  type / security-level combinations in AlfaOBD's `abf()` dispatcher.
- **`w6` shared core, fully translated** — a parameterized linear
  cipher `(r, s)` where `ht` itself is `w6(0x41AA42BB, 0x22BA9A31)`.
  **380 per-ECU wrappers** are catalogued with concrete `(r, s)`
  pairs in `AOBD_W6_TABLE`.
- **`w7` shared core, data staged** — all **360 per-ECU `(n, o, p)`
  parameter triples are decoded** (Dotfuscator string-decryption
  reversed). The arithmetic core itself is not yet translated, so the
  triples are stored but the cipher cannot be evaluated yet.
- **Dispatcher map** — 8 cleanly extracted ECU families
  (`af::ge` ∈ {17, 21, 22, 27, 31, 37, 39, 66}) across security
  levels 1 / 3 / 5, plus 41 explicit per-ECU branches (ORC,
  UCONNECT, RADIO_FGA, EVCU, OBCM, …).
- **`alfaobd_algorithm_catalog.json`** — a 3378-line machine-readable
  bundle containing all 740 wrappers + dispatch map. Perfect codegen
  input; this is what we ingest at build time.

The user has explicitly directed: **no DEMO flags anywhere.** That
includes stripping the existing `demo:true` flag from the SGW XTEA
entry and the four documentation/code callsites that reference its
"unverified" status. Validation will happen against a real car.

## Done looks like
- The SEED→KEY tab gains a much broader algorithm picker:
  - The 3 standalone algorithms (`alfa_ht`, `alfa_f`, `alfa_ao`).
  - The `w6` core exposed as a single picker entry that takes either
    an ECU wrapper name (`ez`, `tt`, `tu`, …) or a manual `(r, s)`
    pair.
  - A "Lookup by ECU family + security level" dropdown wired to the
    dispatcher map — pick a family (e.g. `27 → tt/tu/tv`) and a level
    (1 / 3 / 5) and get the right `w6` wrapper auto-selected.
  - The 360 `w7` parameter rows are visible in a read-only table
    flagged "algorithm pending — data only" so the catalog is
    visibly staged for when the cipher lands.
- The Live OBD / UDS unlock chain auto-tries `alfa_ao` after CDA6
  for body-bus modules, so a real UCONNECT / RADIO_FGA at security
  level 5 authenticates without per-module overrides.
- The unlock chain also tries the `w6`-family algorithms mapped from
  the dispatcher (specifically the 7 wrappers from families that
  resolve directly to a `w6` entry without needing `w7`).
- `xtea_sgw` no longer carries the `— DEMO` suffix in its display
  name and no longer carries the `demo:true` flag in the registry,
  in `MODULE_TARGETS`, or in any UI surface. The "unverified on
  vehicle" copy in `OBDSwarmDiagnostic.jsx` and the SGW XTEA doc is
  rewritten to describe it as ground-truth from CDA.swf.
- Tests cover:
  - Pinned vectors for `alfa_ht` (the simplest case, exact byte
    match against the Python reference impl).
  - Pinned vectors for `alfa_f` and `alfa_ao` (XTEA — exact byte
    match against Python reference) plus an avalanche check
    (≥ 14.5 average bits flipped per single-bit input perturbation).
  - Pinned vectors for `alfaW6(seed, r, s)` against a small
    sampling of the 380 wrappers (e.g. `tt`, `ez`, `c0` — the
    same wrappers the family map identifies as live ECUs).
  - The existing SGW XTEA test that asserts `demo === true` flips
    to assert the absence of the flag.
  - Catalog integrity: the generated `alfaobdAlgorithms.generated.js`
    parses cleanly, exposes 380 w6 entries and 360 w7 entries, and
    matches the source JSON byte-for-byte after re-running the
    codegen.
- `npm test` (vitest + node:test) stays green.

## Out of scope
- **Translating `w7`.** The arithmetic core (`ad::w7` plus 7
  big-integer helpers `b/g/h/i/j/k/l/m/o`) is upstream RE work
  the user is still doing. We stage the 360 parameter triples
  but do not invent a `w7` implementation. A follow-up task can
  drop in the cipher when it's ready and the data will already
  be wired.
- The remaining ~100 non-switch per-ECU branches in `abf()` that
  haven't been mapped to a family yet.
- A live `seed → key` capture from a real car. Validation against
  a real vehicle is the user's domain; this task ships the
  algorithms ready for that test.

## Steps
1. **Stage the catalog as a build-time input.** Confirm
   `alfaobd_algorithm_catalog.json` lands under `attached_assets/`
   and add a one-liner to `scripts/README.md` (alongside the
   AlfaOBD database entry from Task #141) documenting where it
   comes from and that it is committed alongside the generated
   output.

2. **Codegen for the catalog.** Add
   `scripts/extract-alfaobd-algorithms.mjs` that reads the JSON,
   sorts deterministically, and emits
   `src/lib/alfaobdAlgorithms.generated.js` exporting
   `AOBD_W6` (`{ name: [r, s] }`), `AOBD_W7`
   (`{ name: [n, o, p] }` — data only), and `AOBD_DISPATCH`
   (`{ family: { level: wrapperName } }` plus the 41 special-ECU
   entries). Wire it into the existing `codegen` script next to
   the AlfaOBD database codegen.

3. **Add the cipher primitives.** Port the JS reference
   implementation from
   `attached_assets/alfaobd_seedkey_1776573875649.js` into
   `src/lib/algos.js`, exposing `alfaHt`, `alfaF`, `alfaAo`,
   `alfaW6(seed, r, s)`, and `alfaW6By(seed, name)`. Match the
   existing module's u32-clamping style. Keep `alfaHt` defined as
   a literal call to `alfaW6(seed, 0x41AA42BB, 0x22BA9A31)` so
   the equivalence is visible in the source, not just in a
   comment.

4. **Register and wire.** Add registry entries for the 3
   standalone algorithms plus the 7 directly-hittable w6 family
   wrappers identified in the dispatcher map (the level-mapped
   entries from families 27 and 66 — the rows where a `w6`
   wrapper appears explicitly). Also add a single
   "AlfaOBD w6 (custom)" entry that lets the user enter an
   arbitrary wrapper name from `AOBD_W6` to compute a key on
   demand. Append `alfa_ao` to `UNLOCK_FALLBACK` so it gets
   tried automatically after CDA6 on non-SGW modules.

5. **De-DEMO the SGW XTEA.** Drop the `demo:true` flag and the
   "— DEMO" / "(unverified on vehicle)" copy from:
   - `src/lib/algos.js` (registry entry)
   - `src/lib/jailbreakFeatures.js` (MODULE_TARGETS sgw-xtea entry)
   - `src/OBDSwarmDiagnostic.jsx` (any "demo" copy in the SGW path)
   - `docs/SGW_XTEA_ALGORITHM.md` (rewrite the unverified caveat)
   Update the corresponding test assertion in
   `src/__tests__/algos.xtea.test.mjs` so it now requires the flag
   to be absent.

6. **Generate pinned test vectors.** Run the Python reference in
   `attached_assets/alfaobd_seedkey_1776573875649.py` against the
   same seed list used in the SGW XTEA test (zero, 0x12345678,
   0xDEADBEEF, 0xFFFFFFFF, plus 2-3 more), capture outputs for
   `ht`, `f`, `ao`, plus the four dispatch-mapped w6 wrappers
   (`tt`, `tu`, `tv`, `ez`), and bake them into a new
   `src/__tests__/algos.alfaobd.test.mjs`.

7. **Avalanche tests.** Add a single test per XTEA variant that
   flips each input bit, recomputes the output, and asserts the
   mean Hamming distance from the unperturbed key is in
   [14.5, 17.5] bits. For `w6` add a separate avalanche check
   asserting ≤ 4 average bits flipped (matches the linear
   structure noted in the README — ~1.41 bits/flip).

8. **SeedTab UI updates.** The picker today iterates ALGOS, which
   covers the standalone algorithms automatically. Add the
   "Lookup by family + level" affordance and the manual w6 wrapper
   input above the existing list so the 380-wrapper catalog is
   reachable without polluting the main picker with 380 entries.
   Add a separate read-only "w7 catalog" panel that lists the 360
   entries with a "(algorithm pending translation)" badge.

## Critical constraints
- The new XTEA delta `0x8F750A1D` is non-standard. Do NOT collapse
  it into a shared XTEA primitive with the SGW key — keep them as
  two distinct constants in the file, clearly commented as belonging
  to the SGW (CDA.swf) and AlfaOBD (.NET IL) extractions.
- `pickUnlockChain` is the single source of truth for unlock order.
  Do not duplicate the chain into per-tab logic.
- The AlfaOBD `eEcutype` numeric IDs (UCONNECT=0x149, RADIO_FGA=
  0x14E, etc.) are NOT CAN IDs — they are AlfaOBD's internal type
  enum. Do not add them to any CAN-ID map. The fallback chain
  handles them implicitly via RADIO's CAN tx `0x772`.
- The catalog JSON is the source of truth for `(r, s)` and
  `(n, o, p)` values. Do not hand-copy them into source — always
  regenerate from the JSON via the codegen script. This keeps the
  app honest if the upstream catalog gets a correction.
- The 380 w6 wrappers must NOT all be added as discrete `ALGOS`
  registry entries — that would overflow the SEED→KEY picker
  unusably. Surface them through the wrapper-name lookup
  affordance instead. Only the 7 dispatcher-mapped wrappers get
  first-class registry entries.

## Relevant files
- `attached_assets/alfaobd_seedkey_1776573875649.py`
- `attached_assets/alfaobd_seedkey_1776573875649.js`
- `attached_assets/alfaobd_seedkey_README_1776573875647.md`
- `attached_assets/alfaobd_algorithm_catalog_1776573875648.json`
- `attached_assets/SRTLabJailbreakEdition_1776573875648.jsx`
- `artifacts/srt-lab/src/lib/algos.js:1-258`
- `artifacts/srt-lab/src/lib/jailbreakFeatures.js`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx`
- `artifacts/srt-lab/src/__tests__/algos.xtea.test.mjs:90-98`
- `artifacts/srt-lab/docs/SGW_XTEA_ALGORITHM.md`
- `artifacts/srt-lab/src/tabs/SeedTab.jsx`
- `scripts/README.md`