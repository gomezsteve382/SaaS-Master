# Auto-probe ECU addresses in per-module tabs

## What & Why
`lib/mods.js` lists multiple known tx/rx address pairs per module class (BCM has 5, RFHUB has 4, ABS has 3, IPC has 5, etc.) but the per-ECU tabs (`BcmTab`, `RfhubTab`, `EcmTab`, `AdcmTab`) hardcode a single picked address and ignore the rest. Result: the long list ships in the active code but only the first entry is ever tried, so users with a slightly different model-year wiring see "no response" with no signal that other addresses exist.

## Done looks like
- Each per-ECU tab, before issuing the first 0x10 / 0x22 / 0x27 request, probes the full list of known addresses for that module class with a quick TesterPresent (0x3E 00) or DiagnosticSessionControl (0x10 03) and uses the first one that ACKs.
- The active address is shown in the tab UI ("BCM @ 0x742/0x762") so the user knows which one was picked.
- A small "rescan" button re-runs the probe.
- If no address ACKs, the UI shows "BCM not found on any known address — check wiring / vehicle compat" instead of silently issuing requests against a dead address.
- The probe is fast (≤500ms per address with a tight timeout) so the worst-case startup is bounded.

## Out of scope
- Adding new addresses to `lib/mods.js`.
- Auto-probing the OBDTab swarm — it already iterates all addresses by design.
- Persisting the discovered address across sessions (re-probe is cheap).

## Steps
1. Add a `probeAddress(engine, tx, rx, timeoutMs = 250)` helper somewhere reusable (likely `lib/bridgeEngine.js` or a new `lib/probe.js`). Sends `0x3E 00`, returns true on positive response.
2. Add `probeModuleClass(engine, classCode)` that walks `MODS.find(m => m.c === classCode).addrs` and returns the first ACKing pair, or null.
3. Wire BcmTab, RfhubTab, EcmTab, AdcmTab to call `probeModuleClass` on connect / on a "rescan" button. Replace the hardcoded `bcmAddr` / `rfhubAddr` / `ecmAddr` / `adcmAddr` constants with state populated by the probe.
4. Add the active-address display to each tab's status header.
5. Verify the address probe respects the ARMED/SAFE gate (TesterPresent is read-class, should be allowed in SAFE).

## Relevant files
- `artifacts/srt-lab/src/lib/mods.js`
- `artifacts/srt-lab/src/lib/bridgeEngine.js`
- `artifacts/srt-lab/src/tabs/BcmTab.jsx`
- `artifacts/srt-lab/src/tabs/RfhubTab.jsx`
- `artifacts/srt-lab/src/tabs/EcmTab.jsx`
- `artifacts/srt-lab/src/tabs/AdcmTab.jsx`
