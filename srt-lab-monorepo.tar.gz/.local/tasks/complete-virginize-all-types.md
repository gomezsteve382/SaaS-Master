# Complete Virginize for All Module Types

## What & Why
The virginize feature currently only works for BCM, 95640, RFHUB, and GPEC2A. Modules detected as type `FW` (firmware images — large files > 128 KB) have no automated virginize routine and the button is effectively a no-op. This leaves users who upload ECM/TCM/PCM firmware files without any way to strip VINs and security data from them.

## Done looks like
- Virginizing any supported dump type produces a correctly blanked output file
- FW-type modules (ECM/TCM/PCM firmware) have a virginize routine that zeroes or patterns-out known VIN regions, SKIM key blocks, and security seed regions using offset tables derived from the existing reference data in the codebase
- GPEC2A virginize is verified to clear both the SKIM status byte and the tamper ("ZZZZ") marker
- The Virginize button in the DUMPS tab is never silently disabled for a recognized module — if a type is unsupported it shows a clear "Not supported for this module type" message instead of doing nothing
- The BENCH tab's Virginize RFHUB button continues to work correctly

## Out of scope
- Adding new module type detection (handled separately)
- Live OBD virginize flows

## Tasks
1. **Audit existing virginize routines** — review `virginizeModule` and `virginizeFile` to document exactly which byte ranges are cleared for each current type (BCM, 95640, RFHUB, GPEC2A).
2. **FW type virginize** — implement a routine for FW-type files that zeroes known VIN fields and SKIM key regions using the offset patterns already used in BCM and GPEC2A routines; apply the appropriate CRC patch after blanking.
3. **Unknown/unsupported feedback** — replace silent no-ops with an explicit user-facing message when virginize is called on a module type that has no routine.
4. **Verify all types end-to-end** — confirm each type produces a file that re-parses correctly after virginization (type detected, VINs blank, keys zeroed).

## Relevant files
- `artifacts/srt-lab/src/App.jsx:266-309`
- `artifacts/srt-lab/src/App.jsx:682,911-913`
