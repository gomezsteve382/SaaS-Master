# Program All Orchestrator + UDS Workshop

## What & Why
Add the two cross-cutting tabs that sit on top of the per-module programmers: `ProgramAll` (the bench wizard with cross-module VIN verification, status grid, and one-click jump to each programmer) and `UDS` (the universal raw UDS workshop with module presets, raw send, read/write DID, session control, routine control, DTC read/clear).

## Done looks like
- A Program All tab renders the reference layout: hero, Master VIN status card with computed CRC16-CCITT preview, "Verify All 4 Modules" button that probes BCM/RFHUB/ECM/ADCM and reports per-module match/mismatch, the 4-step workflow grid with live status badges, "Open <module>" buttons that jump to the matching tab, and the bench tips card.
- A UDS Workshop tab renders the reference layout: hero, Module presets row (BCM, RFHUB, ECM, ADCM, custom), TX/RX inputs, Connect, Raw UDS command sender, Read DID / Write DID / Diag Session / Tester Present / Reset quick-ops grid, Routine Control (start/stop/results), Read DTCs / Clear DTCs, in-tab log.
- Both tabs read/write the shared Master VIN + module status, use the shared adapter init, and append paper-trail entries on every send.
- "Verify All 4 Modules" works against a live adapter (probes each module, parses VIN from response, compares against Master VIN).

## Out of scope
- Backups, Sessions, Analyzer tabs — next chunk.
- Removing or renaming any legacy tabs.

## Tasks
1. **Port ProgramAll tab** — Translate the reference `ProgramAllTab` into `src/tabs/ProgramAllTab.jsx`, including the cross-module VIN verification flow.
2. **Port UDS tab** — Translate the reference `UdsTab` into `src/tabs/UdsTab.jsx` with the module presets, raw command sender, quick ops, routine control, and DTC tools.
3. **Wire into navigation** — Replace the placeholders for `programall` and `uds` with the real components.
4. **Smoke run** — Build, restart workflow, confirm tabs render, presets load TX/RX, hex parsing handles spaced and unspaced input.

## Relevant files
- `attached_assets/App_1776444434000.jsx`
- `artifacts/srt-lab/src/tabs/`
