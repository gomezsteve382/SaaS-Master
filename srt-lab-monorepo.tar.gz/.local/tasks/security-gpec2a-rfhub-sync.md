---
title: Security Tab — GPEC2A ↔ RFHUB Sync + doTool Live Update
---

# Security Tab — GPEC2A ↔ RFHUB Sync

## What & Why

Two bugs prevent the GPEC2A ↔ RFHUB security byte matching from working, plus the user
needs a single "sync" operation that patches both the PCM SEC6 bytes AND VINs (with CRC) together.

### Bug 1 — `doTool` never updates in-memory module state
`doTool` in `SecurityTab.jsx` patches bytes and puts the result in `tr` (for download display)
but never calls `setMods`. So when the user runs "RFH→PCM Import", then clicks back to Overview,
crossValidate still reads the original unpatched module — always showing MISMATCH.
Fix: after every `doTool` that produces `res.data`, call `setMods` to re-parse and replace
the module in the list (same pattern `syncKey` and `matchAll` already use).

### Bug 2 — `matchAll` skips PCM SEC6
`matchAll` patches VINs and the 8-byte secret key (0x0203 / 0x0361) but does not touch
PCM SEC6 at 0x3C8. After a full match-all, the "RFHUB SEC16[0:6] ↔ PCM SEC6" crossValidate
check still fails.
Fix: inside `matchAll`, when patching a GPEC2A module, if a valid RFHUB (sec16valid=true)
is also loaded, write `rfhub.sec16s[0].raw.slice(0,6)` into `patched[0x3C8..0x3CD]`.

### New Feature — Dedicated GPEC2A ↔ RFHUB Sync button
A single action that does everything at once for the GPEC2A + RFHUB pair:
1. Write RFHUB SEC16[0:6] → GPEC2A PCM SEC6 (0x3C8, 6 bytes)
2. Patch VIN in GPEC2A at all three slots (0x0000, 0x01F0, 0x0224) — no CRC for GPEC2A
3. Patch VIN in RFHUB at all four mirrored slots (0xEA5, 0xEB9, 0xECD, 0xEE1) — byte-reversed + CRC8RF per slot
4. Update both modules in `mods` state immediately so Overview reflects the changes
5. Trigger download of both patched files

## Done looks like
- After running "RFH→PCM Import" from the Tools tab, Overview crossValidate immediately
  shows "RFHUB SEC16[0:6] ↔ PCM SEC6: MATCH ✓" without requiring a download-and-reload cycle
- After "Match All Modules", RFHUB SEC16[0:6] ↔ PCM SEC6 also passes in the post-match check
- A new "🔗 Sync GPEC2A + RFHUB" button appears in the Security sub-tab (or Tools tab)
  when both module types are loaded; clicking it patches PCM SEC6 + VINs in both modules,
  updates the live state, and downloads both patched files
- RFHUB VIN CRC8RF is computed correctly per slot using the mirrored byte array (as `writeModuleVIN` already does)
- Build passes with no errors

## Implementation notes
- All relevant files are in `artifacts/srt-lab/src/`
- `SecurityTab.jsx` — main fix target (doTool, matchAll, new sync button)
- `parseModule.js` — `sec16s[0].raw` is 16 bytes from offset 0xAE (no checksum included); slice(0,6) is the SEC6 source
- `writeModuleVIN` in `fileUtils.js` already handles RFHUB mirrored VIN + CRC8RF correctly — reuse it
- `crc8rf` is in `crc.js` — already imported in SecurityTab
- The sync button should only appear when `mods.find(m=>m.type==='GPEC2A')` AND `mods.find(m=>m.type==='RFHUB'&&m.sec16valid)` are both present and `tv.length===17`

## Files to modify
- `artifacts/srt-lab/src/tabs/SecurityTab.jsx`

## Out of scope
- Changes to BENCH, LIVE OBD, SWARM, J2534, ANALYZER, DUMPS, SEED, GPEC2A tabs
- BCM / 95640 sync logic (those tools already work correctly)
- Python bridge or server-side changes
