# Swap Python Driver to J2534 Build

## What & Why
Replace the current `public/srt_lab.py` (WebSerial / ELM327 reference) with the new 891-line J2534 / Autel IM608 desktop driver from the attached file. This is the Python script the user actually runs on Windows, and the in-app download link must serve the new version.

## Done looks like
- `public/srt_lab.py` content matches the attached J2534 reference byte-for-byte.
- Downloading the desktop driver from the SRT Lab page yields the J2534 version.
- In-page version banner / changelog blurb (if any) reflects the new driver name and purpose (Windows · J2534 · Autel IM608) instead of the old WebSerial wording.
- Build still succeeds (`PORT=3000 BASE_PATH=/srt-lab pnpm run build` in `artifacts/srt-lab/`) and the workflow restarts cleanly.

## Out of scope
- Bundling DLLs, an installer, or auto-update infrastructure.
- Re-architecting the in-page driver section (handled in later chunks).
- Touching the existing `public/j2534_bridge.py` companion file.

## Tasks
1. **Replace the Python file** — Overwrite `public/srt_lab.py` with the attached J2534 reference verbatim.
2. **Refresh in-app copy** — Update any visible description, version string, or changelog snippet near the download button so it accurately describes the J2534 driver. Keep wording short.
3. **Verify build & download** — Rebuild, restart the web workflow, confirm the served file size and first-line shebang match the new script.

## Relevant files
- `attached_assets/srt_lab_1776444434001.py`
- `artifacts/srt-lab/public/srt_lab.py`
- `artifacts/srt-lab/public/j2534_bridge.py`
- `artifacts/srt-lab/src/App.jsx`
