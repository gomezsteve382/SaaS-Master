---
title: Desktop J2534 Driver Bundle (srt_lab.py)
---
# Desktop J2534 Driver Bundle

## What & Why
The browser-based JAILBREAK / BENCH path is great for OBDLink-class adapters, but real shops use J2534 PassThru hardware (Autel MaxiFlash / MaxiPro, DrewTech, etc.) that can only be driven from a desktop process. Bundle the user's complete 942-line `srt_lab.py` — direct ctypes bindings to PassThru DLLs, full UDS stack, all 17 FCA security algorithms, BCM auto-discovery, TesterPresent thread, and the end-to-end `bcm-write` macro — as a downloadable companion to the web app, with a one-page quick-start. This unlocks a whole class of users (mobile mechanics, restoration shops) the browser app can't reach today.

## Done looks like
- The Python script ships in the SRT Lab artifact as a downloadable static asset (served alongside the web app, not duplicated in the repo)
- A new "DESKTOP DRIVER" card on the DUMPS tab (or BENCH tab — whichever feels more natural) shows:
  - One-line pitch ("Real J2534 hardware bridge — Windows + Autel MaxiFlash / MaxiPro / DrewTech")
  - A prominent "Download srt_lab.py" button that pulls the script as a single file
  - A short "Quick start" block with the four core CLI commands (`devices`, `scan`, `unlock-test BCM`, `bcm-write --vin …`)
  - Requirements line (Windows 10/11, Python 3.8+, J2534 vendor drivers installed)
- Downloading and running `python srt_lab.py devices` on a Windows machine with Autel drivers lists the PassThru DLLs from the registry
- `python srt_lab.py scan` enumerates the 17 known FCA modules and reports which respond
- `python srt_lab.py bcm-write --vin <17chars>` runs the full sequence: find BCM → enter session 0x10 03 → cycle through all 17 algorithms until one unlocks → write VIN to DIDs `0xF190`, `0x7B90`, `0x7B88` → verify readback → ECU reset → summary
- The script is a single file with no third-party Python dependencies (stdlib only); no Replit-side runtime is required

## Out of scope
- Porting the Python script to a web equivalent (the whole point is hardware that the browser cannot touch)
- A GUI wrapper for the Python script
- macOS or Linux J2534 support (vendor DLLs are Windows-only)
- Code-signing or packaging into a `.exe` installer
- Any change to the existing 10 web tabs beyond adding the download card

## Tasks
1. **Asset placement** — Drop the Python driver into the SRT Lab artifact's static assets so the dev server and the production build both serve it as a plain file download (preserve the original filename `srt_lab.py`).

2. **Download card UI** — Add a compact "Desktop Driver" card to one existing tab with the pitch text, requirements line, download button, and copy-pasteable quick-start commands. Match the existing SRT Red / Nunito / JetBrains Mono visual language.

3. **Sanity verification** — Confirm the file downloads with the correct filename and content-type, the byte count matches the source, and the rest of the app is unchanged.

## Relevant files
- `attached_assets/Pasted--usr-bin-env-python3-SRT-LAB-v2-Direct-J2534-BCM-VIN-Pr_1776429789407.txt`
- `artifacts/srt-lab/src/App.jsx`
- `artifacts/srt-lab/vite.config.ts`