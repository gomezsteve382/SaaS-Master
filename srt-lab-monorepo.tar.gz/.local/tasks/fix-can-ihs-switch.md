# Fix CAN-IHS Bus Switching in OBD Scanner

## What & Why
The LIVE OBD tab currently uses `STPX H:030B` and `STPX H:0E06` to switch between CAN-C (HS-CAN, pins 6/14) and CAN-IHS (MS-CAN, pins 3/11). A real-world OBDLink EX r2.1 test log confirmed both commands return `?` (unrecognised), so every IHS-bus module (BCM, RFHUB, ABS, IPC, RADIO, ADCM, EPS, TIPM) reports "no response".

A verified App_5 snapshot shows the correct STN physical-layer switching sequence:
- **Into CAN-IHS:** `STP61` (select physical-layer B / pins 3/11) → `ATSP7` → 300 ms settle → `ATCRA` (clear receive filter) → `ATH1` → `ATST50` (320 ms module timeout)
- **Back to HS-CAN:** `ATSP6` → `STP60` (restore physical-layer A) → 100 ms settle → `ATST96` (600 ms timeout)

## Done looks like
- The UDS log shows `STP61` and `ATSP7` where `STPX H:030B` used to appear.
- If `STP61` returns `?` the log shows a fallback warning and continues with `ATSP7` anyway (graceful degradation).
- Modules on CAN-IHS (BCM, RFHUB, ABS, IPC, etc.) now get proper UDS responses on equipped vehicles.
- After the IHS sweep, the log shows "Back on HS-CAN" and the adapter is restored to 500 kbps (`ATST96`).

## Out of scope
- Changes to parsers, DUMPS tab, SECURITY tab, or any other tab.
- ELM327 (non-STN) path — that already warns the user it cannot reach CAN-IHS.

## Tasks
1. In `OBDTab`'s `scan` callback, replace the `STPX H:030B` + 200 ms settle block with: `STP61` → check response for `?`/`ERROR` → log fallback warning if triggered → `ATSP7` → 300 ms settle → `ATCRA` → `ATH1` → `ATST50`.
2. Replace the return-path `STPX H:0E06` + `ATSP6` block with: `ATSP6` → `STP60` → 100 ms settle → `ATST96`.

## Relevant files
- `artifacts/srt-lab/src/App.jsx:1076-1101`
