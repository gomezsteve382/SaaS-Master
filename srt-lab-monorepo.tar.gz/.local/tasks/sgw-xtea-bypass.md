# SGW XTEA Bypass — Extract & Wire In

## What & Why
The cracked dcctools/wiTECH SWF (`attached_assets/CDA_1776448059516.swf`) contains the XTEA secret key and the AS3 routines used to authenticate against the 2018+ FCA Secure Gateway (SGW). Pull the key + algorithm out of the SWF, document them, then wire a JS port into SRT Lab so the existing UDS unlock flow can target the SGW (CAN 0x74F/0x76F) the same way it currently targets the BCM with `cda6`.

## Done looks like
- A new reference doc in the repo describing the extracted XTEA key, IV (if any), block mode, padding, and the exact byte sequence the SGW expects (seed in → key out).
- The Seed→Key tab lists a new "SGW (XTEA)" algorithm next to the existing GPEC / NGC / CDA6 / TIPM entries; pasting a 4-byte seed produces the correct response.
- The UDS unlock flow used by the Jailbreak tab, Bench tab, and OBD tab can target SGW (0x74F/0x76F) and successfully complete `27 01 → 27 02` against a real 2018+ vehicle.
- The SGW shows up in the OBD module list (it already does as a label — needs the `unlock: "xtea_sgw"` wiring).
- Python mirror (`srt_lab.py`) gets the same algorithm so the J2534 bridge / desktop driver stay in sync.

## Out of scope
- Any new UI for managing multiple SGW key sets — single hard-coded key is fine for v1.
- Re-implementing the full `com.hurlant.crypto` library — only XTEA (and CBC + whatever padding the SWF uses) is needed.
- Reverse-engineering the WinLicense-protected GPEC unlocker pattern (separate task already exists).

## Tasks
1. **Extract key + algorithm from SWF.** Decompress `CDA_1776448059516.swf` (CWS → FWS), locate the AS3 method that calls `xtea` / `SecretKey` / `SecurityGatewayCommand`, and capture: the full 128-bit key (the two 8-byte halves found at offset `0x24664A`: `BC474048A33B483A` + `6368727973313372`), the block mode (CBC vs ECB), IV bytes, padding (PKCS5 was in the cipher list), endianness, and round count (32 = standard XTEA, or custom). Cross-check by running the algorithm against any seed/key pairs visible in the SWF's test/log strings.

2. **Write a reference doc.** Add a new markdown file under the existing reference-doc location used by other algos (alongside `GPEC_UNLOCK_ALGORITHM.md` style notes) covering: where the key lives in the SWF, the AS3 call graph that uses it, the seed→key transform, and a worked example.

3. **Add `xtea_sgw` to the JS algorithm library.** Add an XTEA implementation (encipher + CBC wrapper if needed) and a new entry in the `ALGOS` table so the Seed→Key tab picks it up automatically. Mirror the function in `algos.js` style (no new deps).

4. **Wire SGW into the UDS unlock targets.** Add an SGW entry to `MODULE_TARGETS` in `obdEngine.js` (`tx: 0x74F, rx: 0x76F, unlock: "xtea_sgw", needsUnlock: true`), and extend the unlock dispatch in `JailbreakTab.jsx`, `OBDTab.jsx`, and `BenchTab.jsx` so when `unlock === "xtea_sgw"` the code runs the new algorithm instead of `cda6`.

5. **Mirror in Python.** Port the same XTEA + key into `srt_lab.py` and append an entry to its algorithm table so the desktop/J2534 path stays consistent.

6. **Smoke tests.** Add unit tests covering: known seed → known key vector(s) extracted from the SWF, round-trip XTEA encipher/decipher, and the `MODULE_TARGETS` lookup returning the SGW entry with the right unlock id.

## Notes for the executor
- The SWF is zlib-compressed (`CWS` header). Use `zlib.inflateSync` on bytes 8+ after rewriting the header to `FWS` to get a flat SWF body. The constants live in the AS3 constant pool; offset `0x24664A` is the anchor.
- Key material discovered so far: label `KEY`, value `BC474048A33B483A6368727973313372` (16 bytes = 128-bit XTEA key). IV must be confirmed from the same constant pool — search near the `_iv` and `_useSecretKey` references at offsets `0x185774` / `0x16ACB4`.
- This key was extracted from a cracked OEM diagnostic tool. Treat the reference doc as private — do not commit it to a public repo without the user's go-ahead.

## Relevant files
- `attached_assets/CDA_1776448059516.swf`
- `artifacts/srt-lab/src/lib/algos.js`
- `artifacts/srt-lab/src/lib/obdEngine.js:204-212`
- `artifacts/srt-lab/src/tabs/SeedTab.jsx`
- `artifacts/srt-lab/src/tabs/JailbreakTab.jsx:131-158`
- `artifacts/srt-lab/src/tabs/OBDTab.jsx:153-196`
- `artifacts/srt-lab/src/tabs/BenchTab.jsx:149-152`
- `artifacts/srt-lab/src/OBDSwarmDiagnostic.jsx:33`
- `artifacts/srt-lab/public/srt_lab.py:199-207`
- `artifacts/srt-lab/public/j2534_bridge.py:64`
