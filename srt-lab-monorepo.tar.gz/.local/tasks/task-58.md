---
title: Make Charger photo actually visible in PAIRED banner
---
# Fix Charger Photo Visibility in PAIRED Banner

## What & Why

The Charger photo in the PAIRED banner is barely visible because the banner's
height is determined purely by its text content (~80px of padding + two lines),
causing the image to be clipped down to a thin sliver. The user wants to actually
see the car.

## Done looks like

- The full Charger is clearly visible on the right side of the PAIRED banner.
- The car image is tall enough to show the body, wheels, and headlights.
- The banner is taller overall (minimum height ~130–150px) so there's room for the car.
- The left side (PAIRED text + subtitle) remains unchanged and vertically centered.
- The image still fades in from the left edge via the mask gradient.
- The bouncing animation and green glow are preserved.

## Out of scope

- Any changes to MismatchBanner, other tabs, or logic.

## Tasks

1. **Increase banner height and fix image sizing** — Set a `minHeight` on the
   PairedBanner outer div (e.g. 130px). Change the image from `height: "100%"`
   to a fixed pixel height that's slightly taller than the banner (e.g. 150px)
   so it fills and overflows naturally. Adjust `objectPosition` so the car front
   and body (not just sky) are centered in the visible area.

## Relevant files

`artifacts/srt-lab/src/tabs/TwinTab.jsx:470-530`