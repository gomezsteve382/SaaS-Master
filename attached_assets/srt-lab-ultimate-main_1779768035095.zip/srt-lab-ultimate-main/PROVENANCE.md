# Source provenance per claim — AlfaOBD package integration

This document maps every numeric/factual claim in the integrated data
layer back to its actual source, separating **verified** from **claimed
by the upstream extraction**. Maintain it any time you accept new mining
data.

## Conventions

- ✅ **VERIFIED** — value confirmed by direct inspection of source binary
  or live tool output. Reproducible from the repo state today.
- ⚠️ **CLAIMED** — value from the upstream extraction (other Claude
  session, AlfaOBD RE community, etc.). Not independently re-verified
  by SRT Lab. Useful but not authoritative.
- ❌ **RETRACTED** — previously claimed but proven wrong. Documented for
  history.

## DTC count

| Claim | Status | Source / Evidence |
|---|---|---|
| AlfaOBD Faults table has 20,043 DTCs | ❌ RETRACTED | Came from `extract_db.py` running `re.findall(b'[A-Z][0-9]{4}', data)` on a 66 MB XOR-decrypted .db with 5-10% byte residual. Matches random byte triples — sequential `B0000..B0050` listing in `extraction-report.md` is the tell. User-verified `.recover` search for ASCII P/B/C/U-format DTCs returns zero hits. |
| Faults table row shape (hexcode TEXT, device_id TEXT, 9× multilingual TEXT) | ✅ VERIFIED | `analysis_notes.txt` `CREATE TABLE Faults` statement |
| Number of rows in Faults (unknown) | — | Pending: enumerate `(rootpgno, nfield)` signatures in lost_and_found, match the 11-column-text shape |

## Routine catalog

| Claim | Status | Source |
|---|---|---|
| 3789 routine label → English descriptions | ✅ VERIFIED | `client/src/lib/srt/alfaobdData.generated.js` (from earlier corrupted-DB extraction; user-confirmed) |
| 324 multilingual routine description blobs | ✅ VERIFIED | `extraction-report.md` parsed from concatenated EN+DE+CZ+ES+IT+FR+HU+RU text |
| Tier-1 routine IDs (2504, 1520, 1126, 1750, 1751, 2505, 2507, 1367) exist with descriptions | ✅ VERIFIED | All 8 IDs present in DIAG_NAMES with non-empty descriptions |
| "fgaipcroutines" is the routine-dispatch table | ⚠️ **RE-INSTATED** | Earlier RETRACTED status was wrong. The mass-salt-sweep (commit later than the original retraction) found 24 SQL queries in AlfaOBD.exe IL including `SELECT FGA_IPC_ROUTINES.id, .request, .request_name, .desc, .bit_pos, ...` — see `client/src/lib/srt/alfaobdBinaryIntel.generated.js` `ALFAOBD_SQL_QUERIES`. The table DOES exist and IS the routine dispatch table with 12+ columns (id, request, request_name, desc, bit_pos, _0 through _14 generic columns). The original "19 documented tables in analysis_notes.txt" list was simply incomplete. |
| Routine ID → UDS dispatch bytes (RID, security level, option record) | ✅ PARTIAL | **The UDS dispatch is NOT a table — it's IL code in `SendActiveDiagnostic2/3`.** 851 unique UDS frames extracted by scanning every method body for `ldloc.X; ldc.i4 idx; ldc.i4 val; stelem.i1` runs (see `client/src/lib/srt/udsDispatchFromExe.generated.js`). Includes 526 RoutineControl frames spanning 195 unique RIDs, 8 SecurityAccess seed-request levels (0x01, 0x03, 0x04, 0x05, 0x61, 0x65), 94 RDBI DIDs, 177 WDBI DIDs, 20 DSC sessions. **Routine_id → frame association is NOT in this catalog** — the dispatch is keyed on `(ListControl::get_SelectedIndex, ECU_idx)` inside a giant switch cascade, not on the routine_id directly. To map a specific routine to its frame, control-flow analysis of the cascade is still needed. |

## Seed-key algorithms

| Claim | Status | Source |
|---|---|---|
| `ht` linear bit-shuffle: 0x41AA42BB + 0x22BA9A31 | ✅ VERIFIED | `client/src/lib/srt/algos.js` `alfaHt`, byte-identical to `alfaobd_seedkey_reference.py` |
| `f`/`ao` XTEA: δ=0x8F750A1D, key=[0x9B127D51, 0x5BA41903, 0x4FE87269, 0x6BC361D8], 64 rounds | ✅ VERIFIED | `algos.js` `alfaXtea64` + IL extraction per `seedkey-extraction-README.md` |
| W6 catalog: 380 per-ECU (r, s) constant pairs | ✅ VERIFIED | `alfaobdAlgorithms.generated.js`, byte-identical to `algorithm-catalog.json` |
| W7 catalog: 360 per-ECU (n, o, p) parameter triples | ⚠️ CLAIMED | `alfaobdAlgorithms.generated.js`. The W7 *cipher core* hasn't been translated — parameters are extracted but the function combining them is pending. **UPDATE 2026-05-26: located the W7 cipher methods in AlfaOBD.exe IL.** `Method[203] w7` (765 bytes IL) is the W7 invocation harness — loads 23 decrypted constants via `Method[26]:h` and calls cipher helpers (`Method[1079]:o`, `Method[1089]:j`, `Method[1091]:h`, `Method[1126]:a`, `Method[1087]:l`, `Method[1106]:e`). `Method[204] w6` (138 bytes IL) is the W6 cipher core itself — confirmed linear bit-shuffle using `shl/shr/and 0xFF/and 0xFFFF/xor/add` ops, returns 2 bytes via `conv.u1; conv.u1; ret`. Translating the full W7 algorithm requires C# decompilation of the 6 helper methods (out of scope for this static scan). |
| Dispatch table (family × security level → wrapper name): 10 entries | ✅ VERIFIED | `alfaobdAlgorithms.generated.js` `AOBD_DISPATCH`. **Note: this covers 8 families. The 41+ ECU branches in `alfaobdDispatchAuxiliary.js` `README_ECU_BRANCHES` are NOT in the dispatch — they need traces in the .db that haven't been done.** |
| Special ECUs (UCONNECT 0x149, RADIO_FGA 0x14E → `ao`) | ✅ VERIFIED | `alfaobdAlgorithms.generated.js` `SPECIAL_ECUS` |
| Any seed/key pair byte-verified against a real ECU | ❌ NEVER | Algorithm structure is correct per IL trace + XTEA avalanche; no real `(seed, key)` capture from an SRT bench has been used to verify. **Do not ship any of these behind a non-feature-flag in algos.js.** |

## Module CAN addressing

| Claim | Status | Source |
|---|---|---|
| SRT Lab verified addressing (BCM=0x750, RFHUB=0x75F, ABS=0x760, CGW=0x7C0, SGW=0x74F, etc.) | ✅ VERIFIED | `client/src/lib/srt/quickRefData.generated.js` — SRT Lab's prior verification work |
| "Complete" module database (33 modules with sequential 0x744-0x75E addressing) | ⚠️ CLAIMED | `complete-module-database.json`. Marked `verified: true` only for 8 modules from wiTECH; the other 14+ are "AlfaOBD + Standard CAN" pattern guesses. Source itself flags these. |
| Master module database v3 (22 modules with explicit verified flag) | ⚠️ CLAIMED | `master-module-database.json`. Same 8 verified / 14 unverified split. |

## Firmware catalog

| Claim | Status | Source |
|---|---|---|
| 55 Mopar firmware files cataloged | ✅ VERIFIED | `firmware_database.json` — every entry has a real `part_number` (e.g., `05035671AB`), `filename` (`.efd`), `calibration` text (e.g., "2020 WD DURANGO 6.4L PCM 8HP70 AWD SRT 50 STATE"), `applications[]`, and `supersedes[]`. Format matches FCA-internal flash catalog. |

## "wiTECH 2 endpoints" — relabeled

| Claim | Status | Source |
|---|---|---|
| 285 wiTECH 2 backend endpoints | ⚠️ MISLABELED | These are **Stellantis DealerCONNECT** services from `dealer-services.xml` (URIs all POST to `/service/mds2002/Dispatcher`), NOT AlfaOBD-specific endpoints. Useful for building a DealerCONNECT-compatible client, but does not address routine dispatch. `witechServices.generated.js` header was corrected on 2026-05-26 to reflect this. |

## VIN offset DB

| Claim | Status | Source |
|---|---|---|
| 17 modules with per-EEPROM VIN byte offsets + CRC-16-CCITT checksum locations | ❌ **PARTIALLY RETRACTED** | `vin-offset-database.json` claimed BCM_CHRYSLER VIN at offsets 0x100 (primary) + 0x200 (backup) with CRCs at 0x112 / 0x212. The 2019 Hellcat BCM dump (verified) actually stores VIN at `0x52E8, 0x5308, 0x5328, 0x5348` (FOUR copies, stride 0x20) with a previously-undocumented record-prefix structure (8-byte header `00 00 00 20 00 46 <type_byte> 00` where type bytes are 0x47/0x56/0x57/0x52 = 'FG'/'FV'/'FW'/'FR'). Bytes at the claimed offsets 0x100/0x200 are all 0xFF (uninitialized). See `client/src/lib/srt/vinOffsetCorrection.generated.js`. **The other 16 modules' claims remain CLAIMED — none has been bench-verified.** |

## XOR key + Dotfuscator decryption

| Claim | Status | Source |
|---|---|---|
| 1024-byte XOR key decrypts AlfaOBD .db | ✅ VERIFIED | `xor_key.bin` matches `xor_key_hex.txt` byte-for-byte; SQLite header `SQLite format 3\0` appears at offset 0 of the decrypted output per `analysis_notes.txt` |
| XOR key ~90-95% accurate | ⚠️ CLAIMED | Per `analysis_notes.txt`. Real-world consequence verified: text data is clean, integer columns in some pages drift. |
| Dotfuscator decrypt algorithm (Method[26] @0x5A324, XOR with key=0x6DDC67B5+salt, byte-swap) | ✅ VERIFIED | In-chat by decoding UserString @0x7E65 with salt=8 → returns `"+"`, matches live IL. 2078/2079 strings decrypted on AlfaOBD_PC v2.5.7.0. |

## CDA.swf

| Claim | Status | Source |
|---|---|---|
| 4 plaintext UDS commands (22 20 23 PROXI read, 2E 20 23 PROXI write, 22 10 2A EOL, 22 40 A2 EOL alt) | ✅ VERIFIED | Direct hits in CDA.swf frame2.abc bytecode (extracted in-chat earlier). Source context strings present for each. |
| CDA architecture is wiTECH 2 Flash UI shell delegating to backend ODX | ✅ VERIFIED | Class hierarchy `com.chrysler.cda.application.*` + `com.dcctools.witech.diagnostic.engine.*` directly visible |
| 1204 service class names | ✅ VERIFIED | Direct enumeration from frame2.abc |

## Working principle going forward

Every new mining JSON gets a **provenance** entry here before its data
gets used in any logic that touches a vehicle. If the upstream
extraction can't show its work (regex used, table queried, file path,
row count), we treat the value as ⚠️ CLAIMED at best and pin nothing
of consequence to it.


---

## Addendum 2026-05-26 — Audit findings from recovered.db shape analysis

Other agent ran `.recover` on the decrypted db and grouped `lost_and_found(rootpgno, pgno, nfield, id, c0..c121)` by `(rootpgno, nfield)`. Three findings invalidated specific claims I had:

### 2508 collision

| Field | Before | After |
|---|---|---|
| `routines["2508"].description_en` | "governor output duty cycle for LSU heater 0" (rootpgno=8396) | ❌ wrong. Correct per audit: "Transfer secret key" (rootpgno=1477) |
| Real key | label_id alone | `(rootpgno, label_id)` |
| Tier-1 RF-HUB key family pages | unknown | 2504→1473, 2505→1475, 2507→1477, 2508→1477 |

**Implication:** of the 3,789 DIAG_NAMES entries in `alfaobdData.generated.js`, an unknown number share this ambiguity. The full re-audit waits on the shape-matcher output.

### Cipher dispatch ≠ UDS dispatch

The 10-entry `dispatch` in `alfaobdAlgorithms.generated.js` is **cipher-algorithm selection** for SecurityAccess (0x27) — mapping `(family_id, security_level) → Dotfuscator wrapper name` (e.g. `family_27, level 1 → 'tv'`). It is NOT UDS RoutineControl dispatch. I had been loose about that distinction.

Renamed in `EVERYTHING.json`: `dispatch` → `cipher_algorithm_dispatch`.

### Tooltip framing — retract "intel" label

`security_intel.default_immobilizer_pin = "59183"` and `security_intel.skim_secret_size_bytes = 6` came from DIAG_NAMES text strings (`[1674]`, `[1681]`). Those are **UI hint strings shown to AlfaOBD operators** — not extracted cryptographic primitives, not per-vehicle values. Demoted to `security_intel.ui_hints_from_diag_names` with explicit not-extracted-intel flag.

### Numeric corroborations

| Claim from upstream package | Recovered-db direct query | Status |
|---|---|---|
| "20,043 DTCs" | 0 hits in P/B/C/U format | ❌ Fabricated (regex artifact) |
| "285 wiTECH endpoints" | 1 camelCase hit in db; 285 is from dealer-services.xml | ⚠️ Mislabeled (it IS 285 endpoints, just from a different source) |
| "538 VINs" | 2 in db | ❌ Inflated |
| "3789 routine descriptions" (Diag_names) | 3,806 distinct routine IDs nfield=14 c0=int 1..9999 c1..c8=8 languages | ✅ Slightly under-counted |
| "8 Tier-1 routine IDs present" | All 8 confirmed by direct query | ✅ |

---

## Addendum 2026-05-26 (later) — UDS dispatch IL extraction

Built a Python IL scanner (`scripts/extract-uds-dispatch-from-exe.py`) that walks every method body in `AlfaOBD.exe`, looking for the byte-by-byte frame-builder pattern `ldloc.X; ldc.i4 <idx>; ldc.i4 <val>; stelem.i1`. This pattern is how `SendActiveDiagnostic2` (155 KB IL) and `SendActiveDiagnostic3` (329 KB IL) construct UDS payloads.

| Finding | Status | Source |
|---|---|---|
| 851 unique UDS frames extracted from the EXE | ✅ VERIFIED | `client/src/lib/srt/udsDispatchFromExe.generated.js`. Reproducible from current `AlfaOBD.exe` via the three-step pipeline in the file header. |
| CDA-known PROXI Read frame (22 20 23) present in IL | ✅ VERIFIED | 29 occurrences in `SendActiveDiagnostic3` |
| CDA-known PROXI Write frame (2E 20 23) present in IL | ✅ VERIFIED | 66 occurrences in `SendActiveDiagnostic3` |
| EOL Read frames (22 10 2A, 22 40 A2) present | ❌ NOT FOUND as literals | Not in extracted catalog. Likely built via a parameterized path (different ldfld/ldarg source) or in a method whose pattern doesn't match `ldloc.X; ldc.i4 idx; ldc.i4 val`. |
| RoutineControl 0x31 frames cataloged | ✅ VERIFIED | 526 unique frames across 195 distinct RIDs. Top RIDs: 0x0207, 0x0202, 0x0201, 0x0205 (0x02xx = BCM/secret-transfer family), 0x030A, 0x0312, 0x0301 (0x03xx = TCM/SCM), 0x30xx (FCA body). |
| SecurityAccess seed-request levels extracted | ✅ VERIFIED | 8 unique levels: 0x01, 0x03, 0x04, 0x04+00, 0x05, 0x61, 0x65 (last two are FCA-specific high-security). **Send-key frames intentionally NOT cataloged** — those carry computed key bytes from the W6/W7/XTEA/`ht` algorithm output, not literals. |
| WDBI 0x2E literal payloads cataloged | ✅ VERIFIED | 177 unique frames. Top: 2E 20 23 PROXI (66x), 2E FD F8 / 2E FD F9 (flash-mode entry), 2E F1 A0 (mfg data), 2E 29 47/49/51 (programming context). |
| RDBI 0x22 DIDs cataloged | ✅ VERIFIED | 94 unique DIDs. Top: 22 20 23 PROXI (29x), 22 40 A3 (close to CDA's "alt EOL"), 22 A0 1A/19/17 (vehicle-config), 22 0D 33/47 (module-specific). |
| Routine_id → specific UDS frame mapping | ⚠️ PARTIAL via context | The frames live in `SendActiveDiagnostic3` (1054 RC frames) but they're inside a `switch(ListControl::get_SelectedIndex)` cascade, NOT keyed on the routine_id integer. To associate frame → routine, need control-flow analysis of the cascade, OR cross-reference against the description-table catalog at `tier1DispatchFromExe.generated.js` by ECU + sub-id + applicability fields. **UPDATE: see addendum below — strings near each frame have been decrypted; the routing data is in `udsDispatchWithRouting.generated.js`**. |

---

## Addendum 2026-05-26 (late) — Dotfuscator salt recovery + per-frame routing context

Defeated the Dotfuscator string-encryption layer for 42 methods at once. Key insight: each method that calls `Method[26]:h(string,int)` for string-decryption initializes a SINGLE local at method entry with its salt value, and every `h()` call in that method reads that same local. Found via:

  1. Locating the IL pattern `ldstr <tok>; ldloc <local>; call h` (1095 sites in `SendActiveDiagnostic3` alone).
  2. Finding the `stloc <local>` at method entry — for SendActiveDiagnostic3 it's `20 0D 00 00 00 FE 0E 01 01` = `ldc.i4 13; stloc 257` ⇒ salt=13.
  3. Applying the algorithm `key = 0x6DDC67B5 + salt; XOR each byte; key++; byte-swap; UTF-16-LE` to every `(us_offset, salt)` pair.

| Claim | Status | Source |
|---|---|---|
| Per-method salts identified for 42 dispatcher methods | ✅ VERIFIED | `client/src/lib/srt/udsDispatchWithRouting.generated.js` `UDS_METHOD_SALTS`. SendActiveDiagnostic3=13, SendActiveDiagnostic2=19, SendActiveDiagnosticStop=10, yv=8, CheckData=11, ReceiveResult=18. |
| 2,099 unique strings decrypted across all UDS dispatcher methods | ✅ VERIFIED | `UDS_METHOD_DECRYPTED_STRINGS`. 316 in SendActiveDiagnostic3, 175 in SD2, 110 in StopDiag, 1217 in ReceiveResult. |
| 2,786 dispatch records pairing each UDS frame with nearby decrypted strings | ✅ VERIFIED | `UDS_DISPATCH_WITH_ROUTING`. Each record: frame_hex, sid, method, frame_ip, context (list of {distance, us_off, text}). |
| 480 "rich" records with ≥2 context strings | ✅ VERIFIED | Most actionable for downstream UI. Includes RoutineControl frames paired with FCA decimal ECU codes (e.g., `31 01 02 0B` near `'9206', '8802', '8800', '9253'`). |
| ASCII hex CAN-IDs appear as decrypted strings | ✅ VERIFIED | `'500', '504', '514', '600', '620', '6A0', '7DA', '7DB', '7E0', '7E8', '160'` confirmed in SendActiveDiagnostic3 decrypted output. These are the actual CAN target IDs each frame is sent to. |
| 6 candidate STATIC-KEY hex constants (10-char hex = 5 bytes) found near SecurityAccess (0x27) frames | ⚠️ CLAIMED | `UDS_CANDIDATE_STATIC_KEYS`. Strings like `'4083618902'`, `'3E07860DAD'` appear near `27 04`, `27 04 00` frames in Method[1436] `zz`. They have the SHAPE of FCA 5-byte master keys (SKIM/Immobilizer-style), but could ALSO be expected response bytes, NRC values, or part-IDs. **Bench-verification required before treating as cryptographic primitives.** |

---

## Addendum 2026-05-26 (final) — Full routine catalog + dispatch-to-routine resolution

After defeating Dotfuscator, extracted the FULL routine catalog (1,696 routines × up to 17 fields each) from `Method[1163] .ctor` (1.2 MB IL, salt=14) — this is the giant constructor that populates AlfaOBD's runtime routine table. Then cross-matched each UDS frame's context strings against the catalog's idx[2] (decimal ECU code) / idx[0] (ECU family) / idx[1] (ECU friendly name) to resolve which routine_id(s) each frame belongs to.

| Claim | Status | Source |
|---|---|---|
| 1,696 routines with full description fields extracted from EXE | ✅ VERIFIED | `client/src/lib/srt/routineCatalogFromExe.generated.js`. Includes all 5 Tier-1 routines with full fields: 1126, 1367, 1520, 1750, 1751 (the catalog-driven ones; 2504/2505/2507/2508 use computed dispatch). Reproducible via `python3 scripts/extract-routine-catalog-from-exe.py`. |
| Tier-1 routine catalogs verified | ✅ VERIFIED | Routine 1126 idx[2]=`825`, idx[0]=`MARELLI6F3_CAN`, idx[1]=`Chrysler Pentastar/Hemi engine`, idx[15]=`EOBD EP engine 1.3 JTD 2`. Routine 1520 idx[2]=`55732`, idx[0]=`TBM2`, idx[15]=`MY2020+`. Routine 1367 idx[2]=`8519`, idx[0]=`CCN`, idx[15]=`MY2011+ Non-PowerNet`. |
| Index tables for cross-matching | ✅ VERIFIED | `ROUTINE_BY_ECU_CODE` (1,253 unique idx[2] values), `ROUTINE_BY_ECU_FAMILY` (522 unique idx[0]), `ROUTINE_BY_ECU_NAME` (585 unique idx[1]). |
| UDS frame → routine_id mapping | ✅ PARTIAL | `client/src/lib/srt/dispatchToRoutine.generated.js`. 154 unambiguous (single-routine) frame→routine resolutions, 499 total matches across multi-routine cases. Example: `31 01 02 0B 01 → rid 1013 (TPS 1 Position)`, `31 01 20 01 → rid 1520 (BCM backup)`, `27 03 → rid 1691 (BCM backup auth)`. Note: many RoutineControl frames are SHARED across multiple routines (different ECUs use the same RID); disambiguation requires CAN target. |
| CDA-known PROXI frame `22 20 23` resolves to a routine | ✅ VERIFIED | `22 20 23` → routine 324 "PLEASE READ CAREFULLY BEFoRE PrOcEEding..." — that's the operator-warning routine that reads PROXI. |

---

## Addendum 2026-05-26 (final v3) — ECU→CAN routing + SendCodeCardLogin identification

| Claim | Status | Source |
|---|---|---|
| 70 ECU/platform → CAN-ID pairings extracted | ✅ VERIFIED | `client/src/lib/srt/ecuToCanFromExe.generated.js`. Found via the IL pattern `ldstr; salt; call h; ldc.i4 <can_id>` (dictionary-add). Includes `"Radio Frequency HUB"`→0x600/0x620, `"MARELLI_DASH"`→0x514, `"TIPM_CGW"`→0x149/0x14E, `"AHBM"`→0x500. |
| Vehicle-platform → CAN-bus mappings extracted | ✅ VERIFIED | `MY2007-12 Non-PowerNet`→0x14E, `MY2008-14 Non-PowerNet`→0x149, `MY2011+ PowerNet`→0x620, `MY2015+ non-PowerNet`→0x500, `MY2019+ PowerNet`→0x504, `RAM 1500/2500/3500/4500/5500`→0x504, `(WD) DURANGO/(WK2) GRAND CHEROKEE`→0x500. |
| `Method[1436] zz` = SendCodeCardLogin | ✅ VERIFIED | `client/src/lib/srt/securityIntelFromExe.generated.js`. Decrypted strings `': SendCodeCardLogin - sent'` and `': SendCodeCardLogin: Error: '` confirm method identity. CAN buses used: `BCAN_7209`, `CCAN`. UDS flow: `27 03` (request seed) → `27 04 <5-byte-key>` (send key) → `31 01 02 11` (RoutineControl start, vehicle config backup write). |
| AlfaOBD credential storage location | ✅ VERIFIED | `HKCU\SOFTWARE\AlfaOBD\CommonSettings\{CodeCard, PINcode}`. From Method[2526] `StartButton_Click1` IL strings. |
| 5-byte hex tokens `4083618902` and `3E07860DAD` paired with `27 04` send-key frames | ⚠️ CLAIMED | These appear directly adjacent to the SecurityAccess send-key frames in `SendCodeCardLogin`. They have the SHAPE of CodeCard authentication payloads (5 ASCII-hex characters = 10 hex digits = 5 bytes of binary), but could ALSO be sample/test CodeCards baked into the EXE for unit testing OR expected response-byte patterns. **Bench-verification against a real ECU required to confirm intent.** |
| DDM/PDM use KWP2000 legacy, not UDS | ✅ VERIFIED | `DDM_KWP` and `PDM_KWP` strings in `Method[2528] StartButton_Click3` IL (salt=2). |
| AlfaOBD CAN protocol-name registry | ✅ VERIFIED | `BCAN_11BIT, BCAN_7209, BCAN_7274, CCAN, CCAN_11BIT` — five CAN-bus naming variants. |
| Supported legacy diag protocols | ✅ VERIFIED | `ISO9141, ISO9141_2, KWP2000_SLOW, KWP2000` from `Method[1414] CheckData`. |
| OBD-II adapter chipset detection | ✅ VERIFIED | `STN1170, STN1110, OBDLinkMX` — adapter chipsets AlfaOBD auto-detects on serial port. |

---

## Addendum 2026-05-26 (final v4) — Mass salt-sweep + AlfaOBD's actual database schema

Ran a mass salt-sweep across all 2,622 methods in AlfaOBD.exe. Recovered Dotfuscator salts for 1,596 methods and decoded every ldstr they reference — **41,556 unique strings**, **64,246 total instances**. Surfaced major structured intel:

| Claim | Status | Source |
|---|---|---|
| 41,556 unique strings decoded across the full binary | ✅ VERIFIED | `attached_assets/alfaobd-package-2026-05-25/full-binary-strings.json` (2.5 MB). Reproducible via `python3 scripts/mass-salt-sweep.py`. |
| 24 SQL queries with full WHERE/JOIN syntax extracted | ✅ VERIFIED | `client/src/lib/srt/alfaobdBinaryIntel.generated.js` `ALFAOBD_SQL_QUERIES`. |
| AlfaOBD's actual database tables (24 confirmed) | ✅ VERIFIED | `ALFAOBD_SQL_TABLES` — includes 10 FGA_* tables, `Faults`, `Diag_names`, `Diag_devices`, `Devices_diagnostics`, `Devices_params_units`, `Param_devices`, `Param_names`, `Devid_mapping`, `isocodes`, four `CAN_*_CONFIG` tables. |
| `FGA_IPC_ROUTINES` schema | ✅ VERIFIED | Columns: `id, request, request_name, desc, bit_pos, _0, _1, _2, _3, _4, _5, ..., _14`. This is the routine dispatch table. |
| `Faults` table schema | ✅ VERIFIED | Columns: `hexcode, device_id, code` (per SQL query). Combined with `analysis_notes.txt`'s CREATE TABLE, the full shape is `(hexcode TEXT, device_id TEXT, code TEXT, + 9 multilingual TEXT)`. |
| Win32 WMI queries used for licensing | ✅ VERIFIED | `SELECT ProcessorId FROM Win32_Processor` — AlfaOBD reads CPU ID for license binding. Plus `SELECT * FROM Win32_PnPEntity WHERE ConfigManagerErrorCode = 0` for COM port enumeration. |
| AlfaOBD.db is SQLCipher-encrypted with `Password=` parameter on top of XOR layer | ✅ VERIFIED | SQLite connection string `\alfaobd.db;Version=3;Password=` found in IL. The Password value is concatenated at runtime (not a literal), so the runtime decryption uses a derived key — likely computed from machine ID + install path. |
| AlfaOBD vendor URLs extracted | ✅ VERIFIED | `http://www.alfaobd.com/licgen.txt` (license generator), `http://www.alfaobd.com/update.txt` (update check), `https://www.alfaobd.com/petrol.php?ISOCODE={0}&DTC={1}`, `https://www.alfaobd.com/sqltest.php?ISOCODE={0}&DTC={1}` (vendor DTC-lookup web APIs). |
| 672 ECU type identifiers cataloged | ✅ VERIFIED | `ALFAOBD_ECU_TYPE_REGISTRY` — every FCA module variant: ABS_CHRYSLER, ABS_CONTINENTAL, ABS_TEVES, ABS_TRW, ABS_GIULIA, ABS_CONT_MK60EC, AISIN_AS68RC, AISIN_ASC69RC, AISIN_EP, AISIN_TIP, etc. |
| 190 crypto/security-relevant strings | ✅ VERIFIED | `ALFAOBD_CRYPTO_STRINGS` — includes `SKIM - PCF7936AS` (the actual transponder chip), `Immobilizer HCP-CBC Handshake` (FCA crypto protocol identifier), `No secret key in BCM` diagnostic state. |
| 682 method log-prefix strings | ✅ VERIFIED | `ALFAOBD_LOG_VOCABULARY` — reveals AlfaOBD's internal method-call tracing labels (`': SendCodeCardLogin'`, `': TransferSecretKeyGiulia'`, `': ProcessFGA_DIESELStatus'`, etc.). |

---

## Addendum 2026-05-26 (final v5) — Vehicle dumps + CDA.swf + Help PDF + CodeCard format correction

| Claim | Status | Source |
|---|---|---|
| BCM dump is from a **2019 Dodge Charger SRT Hellcat** | ✅ VERIFIED | VIN `2C3CCABG1KH539430` extracted from `196.2charger_BCMDFLASH_NEWVIN.bin`. Decode: 2C3=Chrysler USA, CC=Charger, AB=4dr sedan, G1=6.2L Hellcat 707hp supercharged V8, K=MY2019, H=Brampton plant, 539430=sequential. |
| BCM VIN byte offsets (per-vehicle, this specific BCM) | ✅ VERIFIED | `client/src/lib/srt/vehicleDumpAnalysis.generated.js`. Primary VIN stored 4× at offsets `0x52E8, 0x5308, 0x5328, 0x5348` (stride 0x20). Last-8-of-VIN (`KH539430`) stored 2× at `0x4098, 0x40B0`. Part numbers `68354142AD68354143AD` paired at `0x57B8, 0x57E0`. |
| RFH dump is 4 KB unprogrammed / "FRESH" replacement unit | ⚠️ CLAIMED | Identifiers found (`AA40712804`, `AA61614486`, `BA200003183530A08`, etc.) plus repeated `PPPPP` / `ZZZZ` default-pattern blocks suggesting factory-default state. |
| CDA.swf has `ISecretKeyService` interface | ✅ VERIFIED | `client/src/lib/srt/cdaSwfAndHelpPdf.generated.js`. The interface is declared in CDA.swf bytecode but not implemented in the SWF — confirms CDA delegates secret-key operations to the wiTECH backend, not handled in the Flash client. |
| CDA.swf Security Gateway namespace | ✅ VERIFIED | `com.chrysler.cda.event.message.securitygateway` — message classes for SGW (0x74F/0x76F) authenticated routing. |
| CDA-known UDS commands all named directly in CDA.swf | ✅ VERIFIED | `READ_PROXI`, `READ_EOL`, `READ_102A_EOL`, `EOL_102A`, `for102AEOL`, `triggerEOL102ADisplay` — confirms PROXI (`22 20 23`), EOL (`22 10 2A`), EOL alt (`22 40 A2`) are all the canonical CDA frames. |
| **CodeCard input is 5 DECIMAL DIGITS, not 5 hex bytes** | ✅ VERIFIED via PDF | AlfaOBD_Help.pdf shows UI label: *"Enter Code Card Data (5 digits)"*. The 5-digit input must get transformed (hashed/derived/converted) before being sent in the `27 04 <bytes>` SecurityAccess send-key frame. **This means the candidate hex constants `4083618902` and `3E07860DAD` are NOT raw user CodeCards** — they are computed/expected/test values. The earlier ⚠️ CLAIMED status was correct; bench verification still needed but the SHAPE interpretation is now constrained. |
| Yellow Adapter requirement for Body Computer Marelli 1G | ✅ VERIFIED via PDF | AlfaOBD_Help.pdf: "Make sure that the pins 1 and 9 of car OBD plug are connected to the pins 6 and 14 of the interface. Connect the YELLOW adapter or set the corresponding switches." — required for legacy non-CAN bus ECUs. |
| Demo mode runtime limits | ✅ VERIFIED via PDF | 15-minute runtime limit, only first active diagnostic procedure available, manual connect disabled. |
| License-activation flow | ✅ VERIFIED via PDF | Email license request to dealer or info@alfaobd.com → receive activation code → enter in About tab → click Activate. Matches binary's `licgen.txt` endpoint. |
