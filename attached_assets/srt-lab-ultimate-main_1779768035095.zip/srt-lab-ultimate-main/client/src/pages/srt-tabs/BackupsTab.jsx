import React, { useState, useEffect, useCallback, useRef } from "react";
import { C } from "@/lib/srt/constants.js";
import { Card, Btn } from "@/lib/srt/ui.jsx";
import {
  getBackupList, getBackup, getBackupAsync, deleteBackup, clearBackups,
  restoreModule, subscribeAudit, refreshBackupsFromServer,
  getBackupStorageUsage, pruneNonCriticalBackups,
  subscribeToast, formatBytes, BACKUP_WARN_PERCENT,
  exportAllBackups, importBackups, logSession,
} from "@/lib/srt/audit.js";
import { createObdEngine } from "@/lib/srt/obdEngine.js";
import ReadFirstModal from "@/lib/srt/readFirstModal.jsx";

const hx = (n, w = 2) => n.toString(16).toUpperCase().padStart(w, "0");

export default function BackupsTab() {
  const [backups, setBackups] = useState(getBackupList());
  const [usage, setUsage] = useState(getBackupStorageUsage());
  const [toast, setToast] = useState(null);
  const [selected, setSelected] = useState(null);
  const [selectedData, setSelectedData] = useState(null);
  const [filter, setFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [busy, setBusy] = useState("");
  const [conn, setConn] = useState(false);
  const [restoreLog, setRestoreLog] = useState([]);
  const eng = useRef(null);
  const importInputRef = useRef(null);

  const refresh = useCallback(() => {
    const list = getBackupList();
    setBackups(list);
    setUsage(getBackupStorageUsage());
    if (selected && !list.some(b => b.key === selected)) {
      setSelected(null); setSelectedData(null);
    }
  }, [selected]);

  /* Toast bus — surfaces save failures from any tab while Backups is open. */
  useEffect(() => {
    return subscribeToast((detail) => {
      setToast(detail);
      const id = setTimeout(() => {
        setToast((cur) => (cur && cur.ts === detail.ts ? null : cur));
      }, detail.durationMs || 6000);
      return () => clearTimeout(id);
    });
  }, []);

  const handlePrune = useCallback(() => {
    const r = pruneNonCriticalBackups();
    if (r.prunedCount === 0) {
      alert("No redundant snapshots to prune. Each backup is the latest for its module + VIN. Use 'Clear All' or delete entries individually if you need more space.");
    } else {
      alert("Pruned " + r.prunedCount + " redundant snapshot(s) — freed " + formatBytes(r.freedBytes) + ".");
    }
    refresh();
  }, [refresh]);

  const refreshFromServer = useCallback(() => {
    refreshBackupsFromServer().catch(() => {/* offline ok */});
  }, []);

  // Pull from the database on mount + on every focus so backups created in
  // another browser show up here too. Local cache + audit events keep the
  // UI snappy in between server hits.
  useEffect(() => {
    refreshFromServer();
    const onFocus = () => refreshFromServer();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [refreshFromServer]);

  // Auto-update + cross-tab notifications + 4s poll fallback.
  useEffect(() => {
    const unsub = subscribeAudit(refresh);
    const id = setInterval(refresh, 4000);
    return () => { unsub(); clearInterval(id); };
  }, [refresh]);

  // Deep-link: select a backup pre-chosen via URL hash or History panel event.
  useEffect(() => {
    const applyHash = () => {
      const m = (window.location.hash || "").match(/backup=([^&]+)/);
      if (!m) return;
      const key = decodeURIComponent(m[1]);
      const data = getBackup(key);
      if (data) { setSelected(key); setSelectedData(data); }
      try { history.replaceState(null, "", window.location.pathname + window.location.search); } catch {}
    };
    applyHash();
    const onNav = (e) => {
      if (e?.detail?.tab !== "backups" || !e?.detail?.key) return;
      const data = getBackup(e.detail.key);
      if (data) { setSelected(e.detail.key); setSelectedData(data); }
    };
    window.addEventListener("hashchange", applyHash);
    window.addEventListener("srtlab:navigate", onNav);
    return () => {
      window.removeEventListener("hashchange", applyHash);
      window.removeEventListener("srtlab:navigate", onNav);
    };
  }, []);

  // Release Web Serial port when this tab unmounts.
  useEffect(() => () => {
    if (eng.current) { try { eng.current.disconnect(); } catch {} eng.current = null; }
  }, []);

  const addRestoreLog = useCallback((m, t = "info") => {
    const ts = new Date().toLocaleTimeString("en", { hour12: false });
    setRestoreLog(p => [...p.slice(-200), { t: ts, m, type: t }]);
  }, []);

  const loadBackup = useCallback(async (key) => {
    setSelected(key);
    setSelectedData(null);
    const data = await getBackupAsync(key);
    setSelectedData(data);
  }, []);

  // Deep-link from SessionsTab: if there's a pending backup key, auto-select it.
  useEffect(() => {
    const consume = () => {
      try {
        const key = localStorage.getItem("srtlab_pending_backup_select");
        if (!key) return;
        localStorage.removeItem("srtlab_pending_backup_select");
        const data = getBackup(key);
        if (data) {
          setSelected(key);
          setSelectedData(data);
          addRestoreLog("Loaded backup from session deep-link: " + key, "info");
        }
      } catch {/* ignore */}
    };
    consume();
    window.addEventListener("srtlab:backupSelect", consume);
    return () => window.removeEventListener("srtlab:backupSelect", consume);
  }, [addRestoreLog]);

  const handleDelete = useCallback((key) => {
    if (!window.confirm("Delete this backup? Cannot be undone.")) return;
    deleteBackup(key);
    if (selected === key) { setSelected(null); setSelectedData(null); }
    refresh();
  }, [selected, refresh]);

  const handleClearAll = useCallback(() => {
    if (!window.confirm("Delete ALL " + backups.length + " backups? Cannot be undone.")) return;
    clearBackups();
    setSelected(null); setSelectedData(null);
    refresh();
  }, [backups.length, refresh]);

  const handleExportAll = useCallback(() => {
    const archive = exportAllBackups();
    if (archive.count === 0) {
      alert("No backups to export.");
      return;
    }
    const blob = new Blob([JSON.stringify(archive, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    a.download = "srtlab_backups_archive_" + stamp + ".json";
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  const handleImportClick = useCallback(() => {
    importInputRef.current?.click();
  }, []);

  const handleImportFile = useCallback(async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const text = await file.text();
      const archive = JSON.parse(text);
      const r = importBackups(archive);
      refresh();
      const parts = [r.imported + " imported", r.skipped + " skipped (duplicate)"];
      if (r.invalid > 0) parts.push(r.invalid + " invalid");
      alert("Backup import complete: " + parts.join(", ") + ".");
    } catch (err) {
      alert("Import failed: " + err.message);
    }
  }, [refresh]);

  const downloadBackup = useCallback(async (key) => {
    const data = await getBackupAsync(key); if (!data) return;
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "srtlab_backup_" + data.module + "_" +
      (data.dids[0xF190]?.ascii?.slice(-17) || "unknown") + ".json";
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  const handleConnect = useCallback(async () => {
    if (conn) {
      try { await eng.current?.disconnect(); } catch {}
      eng.current = null; setConn(false); return;
    }
    setBusy("Connecting...");
    try {
      eng.current = createObdEngine(addRestoreLog);
      await eng.current.connect();
      setConn(true);
      addRestoreLog("Adapter connected.", "info");
    } catch (e) {
      addRestoreLog("Connect failed: " + e.message, "error");
    } finally { setBusy(""); }
  }, [conn, addRestoreLog]);

  const handleRestore = useCallback(() => {
    if (!selectedData) return;
    if (!conn) {
      alert("Connect to the adapter first (button at the top of this tab).");
      return;
    }
    setModalOpen(true);
  }, [selectedData, conn]);

  const onConfirmRestore = useCallback(async (meta = {}) => {
    setModalOpen(false);
    if (!eng.current || !selectedData) return;
    setBusy("Restoring...");
    let ok = false;
    try {
      ok = await restoreModule(
        eng.current.uds,
        selectedData.tx, selectedData.rx,
        selectedData, addRestoreLog, true,
      );
    } catch (e) {
      addRestoreLog("Restore exception: " + e.message, "error");
    } finally { setBusy(""); }

    logSession({
      module: selectedData.module,
      operation: "Restore from backup",
      success: !!ok,
      moduleAddr: { tx: selectedData.tx, rx: selectedData.rx },
      newVin: selectedData.dids?.[0xF190]?.ascii?.slice(-17) || "",
      backupKey: selected,
      titleRef: meta.titleRef,
      titleNotes: meta.titleNotes,
      technician: meta.technician,
      preWriteConfirmed: meta.preWriteConfirmed,
      notes: "Restored from snapshot " + selectedData.timestamp,
    });
  }, [selectedData, selected, addRestoreLog]);

  const filtered = filter === "all" ? backups : backups.filter(b => b.module === filter);
  const moduleCounts = {};
  backups.forEach(b => { moduleCounts[b.module] = (moduleCounts[b.module] || 0) + 1; });

  return (
    <div>
      <Card style={{
        background: "linear-gradient(135deg,#0A3D1A 0%,#1E6F3A 40%,#00BFA5 100%)",
        color: "#fff", marginBottom: 18,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ fontSize: 32 }}>💾</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "'Righteous'", fontSize: 24, letterSpacing: 2 }}>MODULE BACKUPS</div>
            <div style={{ fontSize: 10, opacity: 0.7, letterSpacing: 3, fontWeight: 700 }}>
              PRE-WRITE SNAPSHOTS · ONE-CLICK RESTORE
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
            <div style={{ fontSize: 11, padding: "6px 12px", background: "rgba(255,255,255,0.15)", borderRadius: 8 }}>
              {backups.length} backup{backups.length === 1 ? "" : "s"}
            </div>
            <div data-testid="backup-storage-usage" style={{ fontSize: 10, padding: "4px 10px", background: "rgba(0,0,0,0.25)", borderRadius: 6, fontFamily: "'JetBrains Mono'", letterSpacing: 0.5 }}>
              {formatBytes(usage.used)} / {formatBytes(usage.max)} ({usage.percent}%)
            </div>
            <div style={{ width: 160, height: 4, background: "rgba(255,255,255,0.15)", borderRadius: 2, overflow: "hidden" }}>
              <div style={{
                width: usage.percent + "%", height: "100%",
                background: usage.percent >= 90 ? "#FF5252"
                  : usage.percent >= BACKUP_WARN_PERCENT ? "#FFB300" : "#00E676",
                transition: "all 0.3s",
              }} />
            </div>
          </div>
        </div>
        <div style={{ fontSize: 12, opacity: 0.85, marginTop: 10 }}>
          Every write operation automatically creates a snapshot of all critical DIDs.
          If a write goes wrong, restore from here. Max 50 backups kept (auto-rotates).
        </div>
      </Card>

      {usage.percent >= BACKUP_WARN_PERCENT && (
        <Card data-testid="backup-quota-warning" style={{
          marginBottom: 14, padding: 14,
          background: usage.percent >= 90 ? "#FFEBEE" : "#FFF8E1",
          border: "1.5px solid " + (usage.percent >= 90 ? "#FF5252" : "#FFB300"),
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontSize: 24 }}>{usage.percent >= 90 ? "🚨" : "⚠️"}</div>
            <div style={{ flex: 1, fontSize: 12, color: C.ts, lineHeight: 1.5 }}>
              <b>Backup storage is {usage.percent}% full</b> ({formatBytes(usage.used)} of {formatBytes(usage.max)}).
              {usage.percent >= 90
                ? " The next backup may fail or silently drop the audit index. Free space now."
                : " Approaching the browser's localStorage cap — older snapshots will start to be auto-pruned."}
            </div>
            <Btn onClick={handlePrune} color={usage.percent >= 90 ? C.er : C.wn}>
              🧹 Prune older duplicates
            </Btn>
          </div>
        </Card>
      )}

      {toast && (
        <Card data-testid="backup-toast" style={{
          marginBottom: 14, padding: 12,
          background: toast.type === "error" ? "#FFEBEE" : toast.type === "warn" ? "#FFF8E1" : "#E8F5E9",
          border: "1.5px solid " + (toast.type === "error" ? "#FF5252" : toast.type === "warn" ? "#FFB300" : "#00E676"),
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontSize: 18 }}>
              {toast.type === "error" ? "✗" : toast.type === "warn" ? "⚠" : "✓"}
            </div>
            <div style={{ flex: 1, fontSize: 12, color: C.ts, lineHeight: 1.5 }}>{toast.message}</div>
            <button onClick={() => setToast(null)} style={{
              border: "none", background: "transparent", cursor: "pointer",
              fontSize: 16, color: C.tm, padding: "0 6px",
            }}>×</button>
          </div>
        </Card>
      )}

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: C.ts, letterSpacing: 2 }}>FILTER:</div>
          <button onClick={() => setFilter("all")} style={pill(filter === "all", C.a2)}>All ({backups.length})</button>
          {Object.entries(moduleCounts).map(([m, n]) => (
            <button key={m} onClick={() => setFilter(m)} style={pill(filter === m, C.a2)}>{m} ({n})</button>
          ))}
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <Btn onClick={handleConnect} color={conn ? C.gn : C.a3} outline>
              {busy === "Connecting..." ? "..." : (conn ? "🔌 Disconnect" : "🔌 Connect Adapter")}
            </Btn>
            <Btn onClick={refreshFromServer} color={C.a3} outline>🔄 Refresh</Btn>
            {backups.length > 0 && (
              <Btn onClick={handleExportAll} color={C.a2} outline data-testid="export-all-backups">
                📦 Export All
              </Btn>
            )}
            <Btn onClick={handleImportClick} color={C.a2} outline data-testid="import-backups">
              📥 Import
            </Btn>
            <input
              ref={importInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleImportFile}
              style={{ display: "none" }}
              data-testid="import-backups-input"
            />
            {backups.length > 0 && <Btn onClick={handleClearAll} color={C.er} outline>🗑️ Clear All</Btn>}
          </div>
        </div>
        {restoreLog.length > 0 && (
          <div style={{
            maxHeight: 110, overflow: "auto", background: "#111", color: "#9CFF9C",
            fontFamily: "'JetBrains Mono'", fontSize: 11, padding: 10, borderRadius: 6,
          }}>
            {restoreLog.map((l, i) => (
              <div key={i} style={{ color: l.type === "error" ? "#ff7676" : l.type === "warn" ? "#ffd279" : l.type === "tx" ? "#9bd1ff" : "#9CFF9C" }}>
                [{l.t}] {l.m}
              </div>
            ))}
          </div>
        )}
      </Card>

      {backups.length === 0 ? (
        <Card style={{ textAlign: "center", padding: 40, color: C.tm }}>
          <div style={{ fontSize: 40, marginBottom: 10 }}>📭</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: C.ts }}>No backups yet</div>
          <div style={{ fontSize: 11, marginTop: 6 }}>
            Backups are created automatically every time you write to a module.
          </div>
        </Card>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.5fr", gap: 14 }}>
          <Card style={{ padding: 0, overflow: "hidden" }}>
            <div style={listHeader}>BACKUP HISTORY ({filtered.length})</div>
            <div style={{ maxHeight: 600, overflowY: "auto" }}>
              {filtered.map(b => {
                const isSel = selected === b.key;
                const date = new Date(b.timestamp);
                return (
                  <div key={b.key} onClick={() => loadBackup(b.key)}
                    style={{
                      padding: "12px 16px", borderBottom: "1px solid " + C.bd, cursor: "pointer",
                      background: isSel ? C.a2 + "10" : "#fff",
                      borderLeft: "3px solid " + (isSel ? C.a2 : "transparent"),
                      transition: "all 0.15s",
                    }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ fontWeight: 800, fontSize: 13, color: isSel ? C.a2 : C.tx }}>{b.module}</div>
                      <div style={{ fontSize: 9, color: C.tm, fontFamily: "'JetBrains Mono'" }}>{b.didCount} DIDs</div>
                    </div>
                    <div style={{ fontFamily: "'JetBrains Mono'", fontSize: 11, fontWeight: 700, color: C.ts, marginTop: 3 }}>{b.vin}</div>
                    <div style={{ fontSize: 10, color: C.tm, marginTop: 3 }}>{date.toLocaleString()}</div>
                  </div>
                );
              })}
            </div>
          </Card>

          {selectedData ? (
            <Card style={{ padding: 0, overflow: "hidden" }}>
              <div style={{
                padding: "12px 16px", background: "linear-gradient(90deg,#0A3D1A,#1E6F3A)",
                color: "#fff", display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <div>
                  <div style={{ fontSize: 10, opacity: 0.7, letterSpacing: 2, fontWeight: 700 }}>BACKUP DETAILS</div>
                  <div style={{ fontFamily: "'Righteous'", fontSize: 16, letterSpacing: 1 }}>{selectedData.module}</div>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button onClick={handleRestore} disabled={busy === "Restoring..."} style={chip("#fff3", "#fff")}>
                    ↩ Restore
                  </button>
                  <button onClick={() => downloadBackup(selected)} style={chip("rgba(255,255,255,0.1)", "#fff")}>⬇ Download</button>
                  <button onClick={() => handleDelete(selected)} style={chip("#FF525222", "#fff", "#FF525255")}>🗑 Delete</button>
                </div>
              </div>
              <div style={{ padding: 16 }}>
                <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "6px 12px", fontSize: 11, marginBottom: 16 }}>
                  <span style={{ color: C.ts }}>Created:</span>
                  <span style={{ fontFamily: "'JetBrains Mono'" }}>{new Date(selectedData.timestamp).toLocaleString()}</span>
                  <span style={{ color: C.ts }}>TX / RX:</span>
                  <span style={{ fontFamily: "'JetBrains Mono'" }}>
                    {selectedData.moduleAddr
                      ? "0x" + hx(selectedData.moduleAddr.tx, 3) + " / 0x" + hx(selectedData.moduleAddr.rx, 3)
                      : "—"}
                  </span>
                  <span style={{ color: C.ts }}>DIDs captured:</span>
                  <span style={{ fontFamily: "'JetBrains Mono'", fontWeight: 700 }}>{Object.keys(selectedData.dids).length}</span>
                </div>

                <div style={{
                  padding: 10, background: "#FFF8F0", border: "1px solid " + C.wn,
                  borderRadius: 6, fontSize: 11, color: C.ts, marginBottom: 14, lineHeight: 1.5,
                }}>
                  <b>⚠ Restore writes the DIDs below back to the module via UDS 0x2E.</b>{" "}
                  Connect to the adapter, then click Restore — you'll be asked to confirm via the Read-First check.
                </div>

                <div style={{ fontSize: 10, fontWeight: 800, color: C.ts, letterSpacing: 2, marginBottom: 8 }}>DID SNAPSHOT</div>
                <div style={{ maxHeight: 380, overflowY: "auto" }}>
                  {Object.entries(selectedData.dids).map(([did, data]) => (
                    <div key={did} style={{
                      padding: "8px 10px", borderBottom: "1px solid " + C.bd,
                      background: data.critical ? "#FFF8F0" : "#FAFAFA",
                    }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ fontSize: 11, fontWeight: 800, color: data.critical ? C.sr : C.tx }}>
                          {data.critical && "🔴 "}0x{hx(parseInt(did, 10), 4)} · {data.name}
                        </div>
                        {data.missing && <div style={{ fontSize: 9, color: C.er, fontWeight: 700 }}>NOT READABLE</div>}
                      </div>
                      {data.ascii && (
                        <div style={{ fontFamily: "'JetBrains Mono'", fontSize: 11, color: C.a2, marginTop: 3, fontWeight: 700 }}>
                          "{data.ascii}"
                        </div>
                      )}
                      {data.hex && (
                        <div style={{ fontFamily: "'JetBrains Mono'", fontSize: 10, color: C.tm, marginTop: 2, wordBreak: "break-all" }}>
                          {data.hex}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          ) : (
            <Card style={{ textAlign: "center", padding: 40, color: C.tm }}>
              <div style={{ fontSize: 40, marginBottom: 10 }}>👈</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.ts }}>Select a backup to view details</div>
            </Card>
          )}
        </div>
      )}

      {modalOpen && selectedData && (
        <ReadFirstModal
          title={"Restore " + selectedData.module + " from backup"}
          subtitle={"Snapshot taken " + new Date(selectedData.timestamp).toLocaleString()}
          module={selectedData.module + "  (TX 0x" + hx(selectedData.tx, 3) + " / RX 0x" + hx(selectedData.rx, 3) + ")"}
          summary={
            "This will write " +
            Object.values(selectedData.dids).filter(d => d.bytes && d.bytes.length).length +
            " DIDs back to the live module via UDS 0x2E. The current module values will be overwritten."
          }
          details={
            <>
              {Object.entries(selectedData.dids).map(([did, data]) => (
                <div key={did} style={{ marginBottom: 4 }}>
                  0x{hx(parseInt(did, 10), 4)} · {data.name}
                  {data.ascii ? '  "' + data.ascii + '"' : data.hex ? "  " + data.hex : "  (empty)"}
                </div>
              ))}
            </>
          }
          destructiveLabel="RESTORE NOW"
          onConfirm={onConfirmRestore}
          onCancel={() => setModalOpen(false)}
        />
      )}
    </div>
  );
}

const pill = (active, color) => ({
  padding: "6px 12px", fontSize: 11, fontWeight: 800, borderRadius: 6,
  border: "1.5px solid " + (active ? color : C.bd),
  background: active ? color + "15" : "#fff",
  color: active ? color : C.ts, cursor: "pointer",
});

const listHeader = {
  padding: "12px 16px", background: "#F8F6F2", fontSize: 11, fontWeight: 800,
  color: C.ts, letterSpacing: 2, borderBottom: "1px solid " + C.bd,
};

const chip = (bg, color, border = "rgba(255,255,255,0.3)") => ({
  padding: "6px 12px", fontSize: 11, fontWeight: 800, borderRadius: 6,
  border: "1px solid " + border, background: bg, color, cursor: "pointer",
});
