/**
 * SRT Lab — Autonomous Swarm Coordinator
 *
 * This is the REAL multi-agent system. Unlike the basic coordinator that
 * runs agents in parallel with no communication, this one:
 *
 * 1. Creates a shared investigation bus
 * 2. Launches all agents simultaneously with bus access
 * 3. Runs a VENOM oversight loop that monitors progress
 * 4. VENOM can redirect agents mid-investigation based on findings
 * 5. Agents terminate based on confidence, not iteration count
 * 6. Final synthesis uses the full investigation bus state
 */

import * as fs from "fs/promises";
import { mkdtemp, writeFile, readdir, stat } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { execSync } from "child_process";
import { SPECIALIST_AGENTS, VENOM_SYSTEM_PROMPT } from "../swarm/agents.js";
import type { QueryEngineResult, ToolCallTrace } from "../queryEngine.js";
import type { SwarmEvent } from "../swarm/coordinator.js";
import { calculateAgentWeights, applyWeightsToAgent } from "../agent-weights.js";
import { InvestigationBus, createInvestigationBus } from "./investigation-bus.js";
import { runAutonomousAgent, type AutonomousAgentResult } from "./autonomous-agent.js";
import { profileBinary, getActiveAgents } from "./specialization-router.js";

// ─── VENOM Oversight Loop ───────────────────────────────────────────────────

async function runVenomOversight(
  bus: InvestigationBus,
  onEvent?: (event: SwarmEvent) => void
): Promise<void> {
  const FORGE_API_URL = process.env.BUILT_IN_FORGE_API_URL || "";
  const FORGE_API_KEY = process.env.BUILT_IN_FORGE_API_KEY || "";

  // VENOM checks in every 15 seconds while agents are running
  const checkInterval = 15000;
  let checks = 0;
  const maxChecks = 8; // Max 2 minutes of oversight

  const oversightLoop = async () => {
    while (checks < maxChecks) {
      await new Promise(r => setTimeout(r, checkInterval));
      checks++;

      const states = bus.getAllAgentStates();
      const activeAgents = states.filter(s => s.status === "investigating");

      // If all agents are done, stop oversight
      if (activeAgents.length === 0) break;

      // Get investigation summary
      const summary = bus.getInvestigationSummary();
      const swarmConfidence = bus.getSwarmConfidence();

      onEvent?.({
        type: "venom_start",
        agentId: "venom",
        codename: "VENOM",
        message: `VENOM oversight check #${checks}: ${activeAgents.length} agents active, swarm confidence ${swarmConfidence.toFixed(0)}%`,
      });

      // If swarm confidence is high enough, let them finish
      if (swarmConfidence >= 75) {
        console.log(`[VENOM] Swarm confidence ${swarmConfidence.toFixed(0)}% — letting agents wrap up`);
        break;
      }

      // Check for stalled agents
      const stalled = bus.getStalledAgents(25000);
      for (const stalledAgent of stalled) {
        // Issue a directive to pivot
        bus.issueDirective({
          targetAgent: stalledAgent.agentId,
          action: "pivot",
          reason: "You appear stalled. Try a different approach or check team findings for new leads.",
          context: `Current focus: ${stalledAgent.currentFocus}. Confidence: ${stalledAgent.confidence}%`,
          priority: "medium",
        });

        onEvent?.({
          type: "venom_start",
          agentId: "venom",
          codename: "VENOM",
          message: `VENOM directive: ${stalledAgent.codename} appears stalled, issuing pivot directive`,
        });
      }

      // If there are critical findings that haven't been followed up, direct the right agent
      const criticalLeads = bus.getAllLeads().filter(
        l => l.priority === "critical" && !l.acknowledged && l.toAgent
      );
      for (const lead of criticalLeads.slice(0, 3)) {
        bus.issueDirective({
          targetAgent: lead.toAgent!,
          action: "investigate",
          reason: `Critical finding from ${bus.getAgentState(lead.fromAgent)?.codename || lead.fromAgent} needs your attention: ${lead.title}`,
          context: lead.details.slice(0, 500),
          priority: "high",
        });
      }
    }
  };

  // Run oversight in background (non-blocking)
  oversightLoop().catch(err => {
    console.error("[VENOM Oversight] Error:", err.message);
  });
}

// ─── VENOM Final Synthesis (Enhanced with Bus Data) ─────────────────────────

async function runVenomSynthesisAutonomous(
  agentResults: AutonomousAgentResult[],
  bus: InvestigationBus,
  filename: string,
  fileSize: number,
  onEvent?: (event: SwarmEvent) => void
): Promise<string> {
  const FORGE_API_URL = process.env.BUILT_IN_FORGE_API_URL || "";
  const FORGE_API_KEY = process.env.BUILT_IN_FORGE_API_KEY || "";

  onEvent?.({
    type: "venom_start",
    agentId: "venom",
    codename: "VENOM",
    message: "VENOM synthesizing all agent findings + investigation bus data...",
  });

  // Build comprehensive context from bus
  const busSummary = bus.getInvestigationSummary();
  const allLeads = bus.getAllLeads();
  const criticalFindings = allLeads.filter(l => l.priority === "critical");
  const highFindings = allLeads.filter(l => l.priority === "high");

  // Build agent reports
  let agentReports = "";
  for (const result of agentResults) {
    agentReports += `\n${"═".repeat(60)}\n`;
    agentReports += `AGENT: ${result.codename} (${result.specialty})\n`;
    agentReports += `Status: ${result.terminationReason} | Confidence: ${result.confidence}% | Iterations: ${result.iterations} | Tools: ${result.toolCallTrace.length} | Leads Posted: ${result.leadsPosted}\n`;
    agentReports += `${"═".repeat(60)}\n`;
    if (result.error) {
      agentReports += `ERROR: ${result.error}\n`;
    }
    agentReports += `FINDINGS:\n${JSON.stringify(result.findings, null, 2)}\n`;
    // Include key tool results
    const keyResults = result.toolCallTrace
      .filter(t => !["post_finding", "check_team_findings", "update_confidence", "request_collaboration"].includes(t.toolName))
      .filter(t => t.result.length > 100)
      .slice(0, 5)
      .map(t => `  [${t.toolName}] ${t.result.slice(0, 800)}`);
    if (keyResults.length > 0) {
      agentReports += `KEY TOOL OUTPUTS:\n${keyResults.join("\n")}\n`;
    }
  }

  // Build cross-agent collaboration summary
  let collaborationSummary = "\n=== CROSS-AGENT COLLABORATION ===\n";
  collaborationSummary += `Total leads shared: ${allLeads.length}\n`;
  collaborationSummary += `Critical findings: ${criticalFindings.length}\n`;
  collaborationSummary += `High-priority findings: ${highFindings.length}\n\n`;

  for (const lead of criticalFindings) {
    const from = bus.getAgentState(lead.fromAgent)?.codename || lead.fromAgent;
    const to = lead.toAgent ? (bus.getAgentState(lead.toAgent)?.codename || lead.toAgent) : "ALL";
    collaborationSummary += `[CRITICAL] ${from} → ${to}: ${lead.title}\n  ${lead.details.slice(0, 300)}\n\n`;
  }

  const messages: any[] = [
    { role: "system", content: VENOM_SYSTEM_PROMPT },
    {
      role: "user",
      content: `File: "${filename}" (${fileSize} bytes, ${(fileSize / 1024).toFixed(1)} KB)

Your 5 specialist agents have completed their AUTONOMOUS investigation with real-time collaboration. They communicated findings to each other during analysis.

${busSummary}

${collaborationSummary}

=== FULL AGENT REPORTS ===
${agentReports}

Now synthesize ALL findings into a single comprehensive intelligence report. Pay special attention to:
1. Cross-referenced findings (multiple agents confirming the same thing)
2. Critical findings that were handed off between agents
3. Gaps where agents had low confidence
4. Contradictions between agent findings

Return ONLY the JSON object in the format specified in your system prompt.`,
    },
  ];

  try {
    const response = await fetch(`${FORGE_API_URL}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${FORGE_API_KEY}`,
      },
      body: JSON.stringify({ messages, max_tokens: 8192 }),
    });

    if (!response.ok) throw new Error(`VENOM synthesis failed: ${response.status}`);
    const data = await response.json();
    const text = data.choices?.[0]?.message?.content || "";

    onEvent?.({
      type: "venom_complete",
      agentId: "venom",
      codename: "VENOM",
      message: `VENOM synthesis complete — ${allLeads.length} leads analyzed, ${criticalFindings.length} critical findings cross-referenced`,
    });

    return text;
  } catch (error: any) {
    console.error("[VENOM] Synthesis error:", error.message);
    onEvent?.({
      type: "venom_complete",
      agentId: "venom",
      codename: "VENOM",
      message: `VENOM synthesis error: ${error.message}`,
    });
    return "";
  }
}

// ─── JSON Repair ────────────────────────────────────────────────────────────

function repairAndParseJSON(raw: string): any {
  try { return JSON.parse(raw); } catch {}
  const codeBlock = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlock) { try { return JSON.parse(codeBlock[1].trim()); } catch {} }
  const firstBrace = raw.indexOf("{");
  const lastBrace = raw.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    try { return JSON.parse(raw.substring(firstBrace, lastBrace + 1)); } catch {}
  }
  return { findings: {}, rawNotes: raw.slice(0, 2000) };
}

// ─── Main Autonomous Swarm Runner ───────────────────────────────────────────

export async function runAutonomousSwarm(
  buffer: Buffer,
  filename: string,
  passNumber: number = 1,
  priorFindings?: string,
  onEvent?: (event: SwarmEvent) => void,
  onBusEvent?: (busEvent: any) => void,
  additionalFiles?: Array<{ filename: string; buffer: Buffer }>
): Promise<QueryEngineResult> {
  const swarmStart = Date.now();
  // Hard wall-clock timeout: 90 seconds to guarantee completion on production.
  // The platform kills processes after ~120-300s; we must finish before that.
  const SWARM_TIMEOUT_MS = 90_000;

  // Write buffer to temp file
  const tmpDir = await mkdtemp(join(tmpdir(), "srtlab-auto-"));
  const safeFilename = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  const filePath = join(tmpDir, safeFilename);
  await writeFile(filePath, buffer);

  // ═══════════════════════════════════════════════════════════════════════════
  // SERVER-SIDE ARCHIVE PRE-EXTRACTION
  // Before agents even start, detect and unpack any archive automatically.
  // This guarantees agents ALWAYS receive extracted files, never raw archives.
  // Agents never need to call archive_extract themselves — it's already done.
  // ═══════════════════════════════════════════════════════════════════════════
  const serverExtractedPaths: string[] = [];
  let isArchiveFile = false;
  try {
    const magic = buffer.slice(0, 8);
    const isGzip = magic[0] === 0x1f && magic[1] === 0x8b;
    const isZip = magic[0] === 0x50 && magic[1] === 0x4b;
    const lowerName = filename.toLowerCase();
    const isArchiveByName = lowerName.endsWith('.tar.gz') || lowerName.endsWith('.tgz') ||
      lowerName.endsWith('.tar') || lowerName.endsWith('.zip') || lowerName.endsWith('.gz');

    if (isGzip || isZip || isArchiveByName) {
      isArchiveFile = true;
      const extractDir = join(tmpDir, '_extracted');
      await fs.mkdir(extractDir, { recursive: true });
      console.log(`[Autonomous Swarm] ARCHIVE DETECTED: ${filename} — pre-extracting server-side to ${extractDir}`);

      try {
        if (isZip || lowerName.endsWith('.zip')) {
          execSync(`unzip -q "${filePath}" -d "${extractDir}"`, { timeout: 30000 });
        } else {
          // tar.gz, .tgz, .tar, .gz — try multiple methods
          try {
            execSync(`tar -xzf "${filePath}" -C "${extractDir}"`, { timeout: 30000 });
          } catch {
            try {
              execSync(`tar -xf "${filePath}" -C "${extractDir}"`, { timeout: 30000 });
            } catch {
              execSync(`gzip -d -c "${filePath}" > "${extractDir}/extracted_file"`, { timeout: 30000 });
            }
          }
        }

        // Walk the extracted directory and collect all file paths
        const walkDir = async (dir: string): Promise<string[]> => {
          const entries = await readdir(dir, { withFileTypes: true });
          const paths: string[] = [];
          for (const entry of entries) {
            const fullPath = join(dir, entry.name);
            if (entry.isDirectory()) {
              paths.push(...await walkDir(fullPath));
            } else {
              const s = await stat(fullPath);
              if (s.size > 0 && s.size < 50 * 1024 * 1024) {
                paths.push(fullPath);
              }
            }
          }
          return paths;
        };

        const allExtracted = await walkDir(extractDir);
        serverExtractedPaths.push(...allExtracted);
        console.log(`[Autonomous Swarm] Pre-extracted ${serverExtractedPaths.length} files from archive`);
        serverExtractedPaths.slice(0, 15).forEach(p => console.log(`  -> ${p.replace(tmpDir, '')}`))
      } catch (extractErr: any) {
        console.error(`[Autonomous Swarm] Archive extraction failed: ${extractErr.message}`);
      }
    }
  } catch (archiveErr: any) {
    console.error(`[Autonomous Swarm] Archive detection error: ${archiveErr.message}`);
  }

  // Write additional files to the same temp dir so agents can access them by path
  const additionalFilePaths: string[] = [];
  const extraFiles = additionalFiles || ((buffer as any).__additionalFiles as Array<{ filename: string; buffer: Buffer }> | undefined);
  if (extraFiles && extraFiles.length > 0) {
    for (const af of extraFiles) {
      const safeName = af.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
      const afPath = join(tmpDir, safeName);
      await writeFile(afPath, af.buffer);
      additionalFilePaths.push(afPath);
    }
    console.log(`[Autonomous Swarm] Wrote ${additionalFilePaths.length} additional files to ${tmpDir}`);
  }

  // Create the investigation bus
  const bus = createInvestigationBus();

  // Wire bus events to external listener (for SSE streaming to frontend)
  if (onBusEvent) {
    bus.on("new_lead", (lead: any) => {
      const fromState = bus.getAgentState(lead.fromAgent);
      onBusEvent({
        type: "lead_posted",
        timestamp: lead.timestamp,
        fromAgent: fromState?.codename || lead.fromAgent,
        toAgent: lead.toAgent ? (bus.getAgentState(lead.toAgent)?.codename || lead.toAgent) : "ALL",
        priority: lead.priority,
        category: lead.category,
        title: lead.title,
        details: lead.details.slice(0, 300),
        confidence: lead.confidence,
      });
    });
    bus.on("agent_state_change", ({ agentId, state }: any) => {
      onBusEvent({
        type: "agent_state",
        timestamp: Date.now(),
        agentId,
        codename: state.codename,
        status: state.status,
        confidence: state.confidence,
        currentFocus: state.currentFocus,
        toolCallCount: state.toolCallCount,
      });
    });
    bus.on("new_directive", (directive: any) => {
      const targetState = bus.getAgentState(directive.targetAgent);
      onBusEvent({
        type: "venom_directive",
        timestamp: directive.timestamp,
        targetAgent: targetState?.codename || directive.targetAgent,
        action: directive.action,
        reason: directive.reason,
        priority: directive.priority,
      });
    });
  }

  // Load pattern context
  let patternContext = "";
  try {
    const { getPatterns } = await import("../db-patterns.js");
    const allPatterns = await getPatterns("system");
    if (allPatterns.length > 0) {
      const patternSummary = allPatterns.slice(0, 50).map((p: any) =>
        `[${p.category}] ${p.name}: ${p.description}${p.hexSignature ? ` (sig: ${p.hexSignature})` : ""}`
      ).join("\n");
      patternContext = `\n\n=== KNOWN PATTERN LIBRARY (${allPatterns.length} patterns) ===\n${patternSummary}\n\nMatch these known patterns against what you find.`;
    }
  } catch {}

  try {
    // ── Phase 0: Calculate agent weights ──────────────────────────────────
    const agentWeights = await calculateAgentWeights();
    if (agentWeights.size > 0) {
      const weightSummary = Array.from(agentWeights.values())
        .map(w => `${w.agentId}: ${w.tier} (${Math.round(w.accuracyScore * 100)}%, ${w.maxIterations} iters)`)
        .join(", ");
      console.log(`[Autonomous Swarm] Agent weights: ${weightSummary}`);
      onEvent?.({ type: "swarm_weights", message: `Agent weights: ${weightSummary}` });
    }

    // ── Phase 0.5: Profile binary and route agents ────────────────────
    const fileProfile = profileBinary(buffer, filename);
    const { activeAgents, skippedAgents, routing } = getActiveAgents(fileProfile);

    const routingSummary = routing.map(r => `${r.codename}: ${r.relevanceScore}% (${r.reason.slice(0, 60)})`).join("\n");
    console.log(`[Autonomous Swarm] File profile: ${fileProfile.fileType}, auto=${fileProfile.isAutomotive}, crypto=${fileProfile.hasCrypto}, net=${fileProfile.hasNetwork}, hw=${fileProfile.hasHardware}`);
    console.log(`[Autonomous Swarm] Active agents: ${activeAgents.join(", ")}. Skipped: ${skippedAgents.map(s => s.codename).join(", ") || "none"}`);

    onEvent?.({
      type: "swarm_complete",
      totalToolCalls: 0,
      durationMs: 0,
      message: `Agent routing: ${activeAgents.length} agents active (${skippedAgents.length} skipped). Profile: ${fileProfile.fileType}, automotive=${fileProfile.isAutomotive}, crypto=${fileProfile.hasCrypto}`,
    });

    onBusEvent?.({
      type: "routing_decision",
      timestamp: Date.now(),
      fileProfile: {
        fileType: fileProfile.fileType,
        isAutomotive: fileProfile.isAutomotive,
        hasCrypto: fileProfile.hasCrypto,
        hasNetwork: fileProfile.hasNetwork,
        hasHardware: fileProfile.hasHardware,
        isPython: fileProfile.isPython,
        markers: fileProfile.markers.slice(0, 20),
      },
      routing: routing.map(r => ({ codename: r.codename, score: r.relevanceScore, reason: r.reason })),
      activeAgents,
      skippedAgents: skippedAgents.map(s => s.codename),
    });

    // ── Phase 1: Launch VENOM oversight (background) ─────────────────────
    console.log(`[Autonomous Swarm] Deploying ${activeAgents.length} autonomous agents against ${filename} (${buffer.length} bytes)`);
    onEvent?.({
      type: "swarm_complete",
      totalToolCalls: 0,
      durationMs: 0,
      message: `Autonomous swarm deploying ${activeAgents.length} agents — collaborating in real-time via investigation bus`,
    });

    runVenomOversight(bus, onEvent);

    // ── Phase 2: Launch ONLY relevant agents with bus access (parallel) ───
    // Agents run in parallel with a hard 75s wall-clock timeout.
    // If any agent exceeds the timeout, we use its partial results.
    const AGENT_TIMEOUT_MS = 75_000;
    // Build additional files context for agents
    let additionalFilesContext = patternContext;

    // Inject server-pre-extracted archive contents into agent context
    if (serverExtractedPaths.length > 0) {
      const extractedList = serverExtractedPaths
        .slice(0, 50) // cap at 50 to avoid context overflow
        .map((p, i) => `  [${i + 1}] ${p.replace(tmpDir, '')} → ${p}`)
        .join("\n");
      additionalFilesContext += `\n\n=== ARCHIVE PRE-EXTRACTED BY SERVER ===\nThe archive "${filename}" has been AUTOMATICALLY UNPACKED. You are NOT analyzing a compressed file.\nAll ${serverExtractedPaths.length} extracted files are available at the paths below. Analyze EACH ONE.\n\nExtracted files:\n${extractedList}\n\nSTART with file_identify on the first few files, then read_hex and extract_strings on each binary/EEPROM file. Do NOT call archive_extract — it's already done.`;
    }

    if (additionalFilePaths.length > 0) {
      const fileList = additionalFilePaths.map((p, i) => `  File ${i + 2}: ${p} (${extraFiles![i].filename})`).join("\n");
      additionalFilesContext += `\n\n=== ADDITIONAL FILES IN THIS SESSION ===\nPrimary file: ${filePath} (${filename})\n${fileList}\n\nYou MUST analyze ALL files listed above. Call file_identify and read_hex on EACH path. Do not stop after the primary file.`;
    }

    const relevantAgents = SPECIALIST_AGENTS.filter(a => activeAgents.includes(a.id));
    const agentResults = await Promise.all(
      relevantAgents.map(agent => {
        const { systemPrompt, maxIterations } = applyWeightsToAgent(agent, agentWeights);
        const weightedAgent = { ...agent, systemPrompt, maxIterations };
        const agentPromise = runAutonomousAgent({
          filePath,
          filename,
          fileSize: buffer.length,
          agent: weightedAgent,
          bus,
          patternContext: additionalFilesContext,
          confidenceThreshold: 80,
          onEvent,
        });
        // Race against timeout — if agent times out, return partial result
        const timeoutPromise = new Promise<AutonomousAgentResult>((resolve) =>
          setTimeout(() => {
            console.warn(`[Autonomous Swarm] Agent ${agent.codename} timed out after ${AGENT_TIMEOUT_MS}ms — using partial results`);
            bus.updateAgentState(agent.id, { status: "complete", confidence: 50 });
            resolve({
              agentId: agent.id,
              codename: agent.codename,
              specialty: agent.specialty,
              rawNotes: "[TIMED OUT — partial results]",
              toolCallTrace: [],
              findings: {},
              iterations: 0,
              durationMs: AGENT_TIMEOUT_MS,
              confidence: 50,
              leadsPosted: 0,
              leadsInvestigated: 0,
              terminationReason: "max_iterations",
              error: "Agent timed out",
            });
          }, AGENT_TIMEOUT_MS)
        );
        return Promise.race([agentPromise, timeoutPromise]);
      })
    );

    // ── Phase 3: VENOM synthesis with full bus context ───────────────────
    console.log("[Autonomous Swarm] All agents complete. Running VENOM synthesis with collaboration data...");
    // Synthesis also has a hard timeout (12s) to stay within the 90s wall-clock budget
    const venomText = await Promise.race([
      runVenomSynthesisAutonomous(agentResults, bus, filename, buffer.length, onEvent),
      new Promise<string>((resolve) =>
        setTimeout(() => {
          console.warn("[Autonomous Swarm] VENOM synthesis timed out — using partial JSON");
          resolve("{}");
        }, 12_000)
      ),
    ]);

    // ── Phase 4: Build unified result ────────────────────────────────────
    const allToolCalls: ToolCallTrace[] = [];
    for (const result of agentResults) {
      for (const trace of result.toolCallTrace) {
        allToolCalls.push({
          ...trace,
          toolName: `[${result.codename}] ${trace.toolName}`,
        });
      }
    }

    let parsed: any = {};
    try { parsed = repairAndParseJSON(venomText); } catch {}

    // Build dissection report with collaboration data
    const agentSummaries = agentResults.map(r =>
      `${r.codename}: ${r.toolCallTrace.length} tools, ${r.iterations} iters, ${(r.durationMs / 1000).toFixed(1)}s, confidence ${r.confidence}%, leads posted ${r.leadsPosted}, terminated: ${r.terminationReason}${r.error ? ` (ERROR: ${r.error})` : ""}`
    ).join("\n");

    const busLeads = bus.getAllLeads();
    const dissectionReport = `═══ AUTONOMOUS SWARM ANALYSIS REPORT ═══
Mode: Autonomous (inter-agent collaboration enabled)
Agents deployed: ${SPECIALIST_AGENTS.length}
Total tool calls: ${allToolCalls.length}
Total duration: ${((Date.now() - swarmStart) / 1000).toFixed(1)}s
Swarm confidence: ${bus.getSwarmConfidence().toFixed(0)}%
Leads shared: ${busLeads.length} (${busLeads.filter(l => l.priority === "critical").length} critical)

${agentSummaries}

VENOM synthesis: ${venomText ? "Complete" : "Failed"}`;

    // Deep findings
    const deepFindings: any[] = Array.isArray(parsed.deepFindings) ? parsed.deepFindings : [];

    // Add bus leads as deep findings
    for (const lead of busLeads.filter(l => l.priority === "critical" || l.priority === "high")) {
      const fromAgent = bus.getAgentState(lead.fromAgent)?.codename || lead.fromAgent;
      deepFindings.push({
        category: lead.category,
        title: `[${fromAgent}] ${lead.title}`,
        offset: lead.offset || "",
        details: lead.details,
        programmingRelevance: `Confidence: ${lead.confidence}% | Priority: ${lead.priority} | From: ${fromAgent}`,
      });
    }

    // Add gaps
    if (Array.isArray(parsed.gaps)) {
      for (const gap of parsed.gaps) {
        deepFindings.push({
          category: "gap",
          title: "Investigation Gap",
          offset: "",
          details: typeof gap === "string" ? gap : JSON.stringify(gap),
          programmingRelevance: "Needs further investigation",
        });
      }
    }

    const swarmDuration = Date.now() - swarmStart;
    console.log(`[Autonomous Swarm] Complete: ${allToolCalls.length} tool calls, ${busLeads.length} leads shared, ${(swarmDuration / 1000).toFixed(1)}s`);

    onEvent?.({
      type: "swarm_complete",
      totalToolCalls: allToolCalls.length,
      durationMs: swarmDuration,
      message: `Autonomous swarm complete — ${allToolCalls.length} tool calls, ${busLeads.length} leads shared between agents, swarm confidence ${bus.getSwarmConfidence().toFixed(0)}%`,
    });

    // Cleanup bus
    bus.reset();

    return {
      summary: parsed.summary || `Autonomous swarm analysis of ${filename} — ${SPECIALIST_AGENTS.length} agents collaborated, ${allToolCalls.length} tool calls, ${busLeads.length} leads shared.`,
      algorithms: Array.isArray(parsed.algorithms) ? parsed.algorithms : [],
      seedKeys: Array.isArray(parsed.seedKeys) ? parsed.seedKeys : [],
      canIds: (Array.isArray(parsed.canAddresses) ? parsed.canAddresses : []).map((c: any) => ({
        id: c.txId || c.id || "",
        description: c.description || "",
      })),
      canAddresses: Array.isArray(parsed.canAddresses) ? parsed.canAddresses : [],
      securityBytes: Array.isArray(parsed.securityBytes) ? parsed.securityBytes : [],
      checksums: Array.isArray(parsed.checksums) ? parsed.checksums : [],
      memoryMaps: Array.isArray(parsed.memoryMaps) ? parsed.memoryMaps : [],
      deepFindings,
      strings: Array.isArray(parsed.strings) ? parsed.strings : [],
      cryptoConstants: Array.isArray(parsed.cryptoConstants) ? parsed.cryptoConstants : [],
      toolCallTrace: allToolCalls,
      passNumber,
      analysisMode: "autonomous_swarm" as const,
      dissectionReport,
      agentResults: agentResults.map(r => ({
        agentId: r.agentId,
        codename: r.codename,
        specialty: r.specialty,
        rawNotes: r.rawNotes,
        toolCallCount: r.toolCallTrace.length,
        iterations: r.iterations,
        durationMs: r.durationMs,
        error: r.error,
      })),
    };
  } finally {
    try {
      await fs.rm(tmpDir, { recursive: true, force: true });
    } catch {}
  }
}
