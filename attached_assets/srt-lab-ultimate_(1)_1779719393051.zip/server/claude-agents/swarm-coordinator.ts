/**
 * SRT Lab — Claude Code Swarm Coordinator
 *
 * Replaces the custom swarm with Claude Code's agent framework.
 * Spawns all specialist agents in parallel, coordinates their execution,
 * and synthesizes findings via VENOM.
 */

import * as fs from "fs/promises";
import { mkdtemp, writeFile } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { SPECIALIST_AGENTS, VENOM_SYSTEM_PROMPT } from "../swarm/agents.js";
import { spawnAgent, type ClaudeAgentTask } from "./adapter.js";
import type { QueryEngineResult, ToolCallTrace } from "../queryEngine.js";
import type { SwarmEvent } from "../swarm/coordinator.js";
import { calculateAgentWeights, applyWeightsToAgent } from "../agent-weights.js";

// ─── Types ──────────────────────────────────────────────────────────────────

interface AgentResult {
  agentId: string;
  codename: string;
  specialty: string;
  findings: any;
  rawNotes: string;
  toolCallTrace: ToolCallTrace[];
  durationMs: number;
  iterations: number;
  error?: string;
}

// ─── LLM Call ───────────────────────────────────────────────────────────────

async function callLLM(
  messages: any[],
  toolSchemas?: any[],
  toolChoice: "auto" | "required" | "none" = "auto",
  retries = 4
): Promise<{ message: any; finishReason: string }> {
  const FORGE_API_URL = process.env.BUILT_IN_FORGE_API_URL || "";
  const FORGE_API_KEY = process.env.BUILT_IN_FORGE_API_KEY || "";
  const RETRYABLE = new Set([412, 429, 500, 502, 503, 504]);

  for (let attempt = 1; attempt <= retries; attempt++) {
    let response: Response;
    try {
      const body: any = {
        messages,
        max_tokens: 8192,
      };
      if (toolSchemas && toolSchemas.length > 0) {
        body.tools = toolSchemas;
        body.tool_choice = toolChoice;
      }

      const abortCtrl = new AbortController();
      const abortTimer = setTimeout(() => abortCtrl.abort(), 40_000);
      try {
        response = await fetch(`${FORGE_API_URL}/v1/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${FORGE_API_KEY}`,
          },
          body: JSON.stringify(body),
          signal: abortCtrl.signal,
        });
      } finally {
        clearTimeout(abortTimer);
      }
    } catch (networkErr: any) {
      if (attempt === retries) throw new Error(`LLM network error: ${networkErr.message}`);
      await new Promise(r => setTimeout(r, 2000 * attempt));
      continue;
    }

    if (!response.ok) {
      const errText = await response.text();
      if (RETRYABLE.has(response.status) && attempt < retries) {
        console.warn(`[Swarm] LLM ${response.status} attempt ${attempt}, retrying...`);
        await new Promise(r => setTimeout(r, 2000 * attempt));
        continue;
      }
      throw new Error(`LLM API error ${response.status}: ${errText.substring(0, 200)}`);
    }

    const data = await response.json();
    const choice = data.choices?.[0];
    if (!choice) {
      if (attempt < retries) {
        console.warn(`[Swarm] Empty LLM response attempt ${attempt}, retrying...`);
        await new Promise(r => setTimeout(r, 2000 * attempt));
        continue;
      }
      throw new Error("Empty LLM response");
    }

    return {
      message: choice.message as any,
      finishReason: choice.finish_reason || "stop",
    };
  }

  throw new Error("LLM API failed after all retries");
}

// ─── VENOM Synthesis ────────────────────────────────────────────────────────

async function runVenomSynthesis(
  agentResults: AgentResult[],
  filename: string,
  fileSize: number,
  onEvent?: (event: SwarmEvent) => void
): Promise<string> {
  onEvent?.({
    type: "venom_start",
    agentId: "venom",
    codename: "VENOM",
    message: "VENOM synthesizing all agent findings...",
  });

  // Build the synthesis prompt with all agent findings
  let agentReports = "";
  for (const result of agentResults) {
    agentReports += `\n${"═".repeat(60)}\n`;
    agentReports += `AGENT: ${result.codename} (${result.iterations} iterations, ${result.toolCallTrace.length} tool calls, ${(result.durationMs / 1000).toFixed(1)}s)\n`;
    agentReports += `${"═".repeat(60)}\n`;
    if (result.error) {
      agentReports += `ERROR: ${result.error}\n`;
    }
    agentReports += `FINDINGS:\n${JSON.stringify(result.findings, null, 2)}\n`;
    if (result.rawNotes) {
      agentReports += `RAW NOTES: ${result.rawNotes}\n`;
    }
    // Include key tool results for context
    const keyResults = result.toolCallTrace
      .filter(t => t.result.length > 100)
      .slice(0, 5)
      .map(t => `  [${t.toolName}] ${t.result.slice(0, 1000)}`);
    if (keyResults.length > 0) {
      agentReports += `KEY TOOL OUTPUTS:\n${keyResults.join("\n")}\n`;
    }
  }

  const messages: any[] = [
    { role: "system", content: VENOM_SYSTEM_PROMPT },
    {
      role: "user",
      content: `File: "${filename}" (${fileSize} bytes, ${(fileSize / 1024).toFixed(1)} KB)

Your 5 specialist agents have completed their independent analysis. Here are their full reports:

${agentReports}

Now synthesize ALL findings into a single comprehensive intelligence report. Cross-reference findings between agents. Identify what they found, what they missed, and what needs deeper investigation.

Return ONLY the JSON object in the format specified in your system prompt.`,
    },
  ];

  try {
    const { message } = await callLLM(messages, undefined, "none");
    const text = typeof message.content === "string" ? message.content : "";

    onEvent?.({
      type: "venom_complete",
      agentId: "venom",
      codename: "VENOM",
      message: "VENOM synthesis complete",
    });

    return text;
  } catch (error: any) {
    console.error("[Swarm/VENOM] Synthesis error:", error.message);
    onEvent?.({
      type: "venom_complete",
      agentId: "venom",
      codename: "VENOM",
      message: `VENOM synthesis error: ${error.message}`,
    });
    return "";
  }
}

// ─── JSON Repair ────────────────────────────────────────────────────────────

function repairAndParseJSON(raw: string): any {
  try { return JSON.parse(raw); } catch {}

  const codeBlock = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlock) {
    try { return JSON.parse(codeBlock[1].trim()); } catch {}
  }

  const firstBrace = raw.indexOf("{");
  const lastBrace = raw.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    try { return JSON.parse(raw.substring(firstBrace, lastBrace + 1)); } catch {}
  }

  return { findings: {}, rawNotes: raw.slice(0, 2000) };
}

// ─── Main Swarm Runner (Claude Code Agent Version) ──────────────────────────

export async function runClaudeCodeSwarm(
  buffer: Buffer,
  filename: string,
  passNumber: number = 1,
  priorFindings?: string,
  onEvent?: (event: SwarmEvent) => void
): Promise<QueryEngineResult> {
  const swarmStart = Date.now();

  // Write buffer to temp file
  const tmpDir = await mkdtemp(join(tmpdir(), "srtlab-swarm-"));
  const safeFilename = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  const filePath = join(tmpDir, safeFilename);
  await writeFile(filePath, buffer);

  // Load matching patterns from library for context injection
  let patternContext = "";
  try {
    const { getPatterns } = await import("../db-patterns.js");
    const allPatterns = await getPatterns("system");
    if (allPatterns.length > 0) {
      const patternSummary = allPatterns.slice(0, 50).map((p: any) =>
        `[${p.category}] ${p.name}: ${p.description}${p.hexSignature ? ` (sig: ${p.hexSignature})` : ""}`
      ).join("\n");
      patternContext = `\n\n=== KNOWN FCA PATTERN LIBRARY (${allPatterns.length} patterns) ===\n${patternSummary}\n\nMatch these known patterns against what you find in the binary.`;
    }
  } catch {}

  try {
    // ── Phase 0a: Pre-flight file type check ─────────────────────────────
    const headerBuf = buffer.slice(0, 512);
    const headerStr = headerBuf.slice(0, 64).toString("utf8").trim().toLowerCase();
    const isGzip = buffer[0] === 0x1f && buffer[1] === 0x8b;
    const isZip = buffer[0] === 0x50 && buffer[1] === 0x4b;
    const isTar = buffer.length > 262 && buffer.slice(257, 262).toString() === "ustar";
    const isArchive = isGzip || isZip || isTar || filename.match(/\.(tar\.gz|tgz|tar|zip|7z|rar|gz)$/i);
    const isHtml = headerStr.startsWith("<!doctype html") || headerStr.startsWith("<html");
    const isJson = buffer[0] === 0x7b || buffer[0] === 0x5b;

    // If filename says archive but content is HTML/JSON, flag the mismatch
    let fileTypeMismatch = "";
    if (isArchive && !isGzip && !isZip && !isTar && (isHtml || isJson)) {
      fileTypeMismatch = `⚠️ FILE TYPE MISMATCH: Filename "${filename}" suggests an archive, but the actual content starts with "${headerStr.slice(0, 30)}..." — this is ${isHtml ? "an HTML web application bundle" : "JSON data"}, NOT a compressed archive. The file was likely already extracted or exported incorrectly. Analyze it as ${isHtml ? "HTML/JavaScript" : "JSON"}, NOT as firmware. Do NOT call archive_extract — it will fail.`;
      console.warn(`[Swarm] ${fileTypeMismatch}`);
      onEvent?.({
        type: "swarm_complete",
        totalToolCalls: 0,
        durationMs: 0,
        message: fileTypeMismatch,
      });
    }

    // If the content is HTML/web app, inject that context into agent prompts
    let fileTypeContext = "";
    if (isHtml) {
      fileTypeContext = `\n\n⚠️ CRITICAL FILE TYPE NOTICE: This file is an HTML/JavaScript web application bundle, NOT raw firmware or an EEPROM dump. The file starts with "<!doctype html>". Do NOT waste tool calls running firmware-specific patterns against web code. Instead: look for embedded automotive data within JavaScript code, base64-encoded binaries, API endpoints, hardcoded constants, and configuration objects that may contain CAN IDs, UDS service definitions, seed-key parameters, or other automotive protocol data embedded in the web app logic.`;
    }
    if (fileTypeMismatch) {
      fileTypeContext += `\n\n${fileTypeMismatch}`;
    }

    // ── Phase 0b: Calculate agent weights from feedback data ──────────────
    const agentWeights = await calculateAgentWeights();
    if (agentWeights.size > 0) {
      const weightSummary = Array.from(agentWeights.values())
        .map(w => `${w.agentId}: ${w.tier} (${Math.round(w.accuracyScore * 100)}%, ${w.maxIterations} iters)`)
        .join(", ");
      console.log(`[Swarm] Agent weights: ${weightSummary}`);
      onEvent?.({
        type: "swarm_weights",
        message: `Agent weights calculated: ${weightSummary}`,
      });
    }

    // ── Phase 1: Launch all 5 specialists in parallel (Claude Code agents) ───
    console.log(`[Swarm] Deploying 5 specialist agents against ${filename} (${buffer.length} bytes)`);

    const agentTasks = await Promise.all(
      SPECIALIST_AGENTS.map(agent => {
        // Apply weighted adjustments to agent parameters
        const { systemPrompt, maxIterations } = applyWeightsToAgent(agent, agentWeights);
        const weightedAgent = { ...agent, systemPrompt, maxIterations };
        return spawnAgent({
          filePath,
          filename,
          fileSize: buffer.length,
          agent: weightedAgent,
          patternContext: patternContext + fileTypeContext,
          onEvent,
        });
      })
    );

    // Convert Claude Code tasks to agent results
    const agentResults: AgentResult[] = agentTasks.map(task => ({
      agentId: task.agentId,
      codename: task.codename,
      specialty: SPECIALIST_AGENTS.find(a => a.id === task.agentId)?.specialty || "",
      findings: task.findings,
      rawNotes: "",
      toolCallTrace: task.toolCallTrace,
      durationMs: (task.endTime || Date.now()) - task.startTime,
      iterations: task.iterations,
      error: task.error,
    }));

    // ── Phase 2: VENOM synthesis ────────────────────────────────────────
    console.log("[Swarm] All specialists complete. Running VENOM synthesis...");
    const venomText = await runVenomSynthesis(agentResults, filename, buffer.length, onEvent);

    // ── Phase 3: Parse and merge results ────────────────────────────────
    const allToolCalls: ToolCallTrace[] = [];
    for (const result of agentResults) {
      for (const trace of result.toolCallTrace) {
        allToolCalls.push({
          ...trace,
          toolName: `[${result.codename}] ${trace.toolName}`,
        });
      }
    }

    // Parse VENOM's synthesis
    let parsed: any = {};
    try {
      parsed = repairAndParseJSON(venomText);
    } catch {}

    // Build the dissection report
    const agentSummaries = agentResults.map(r =>
      `${r.codename}: ${r.toolCallTrace.length} tools, ${r.iterations} iterations, ${(r.durationMs / 1000).toFixed(1)}s${r.error ? ` (ERROR: ${r.error})` : ""}`
    ).join("\n");

    const dissectionReport = `═══ SWARM ANALYSIS REPORT (Claude Code Agents) ═══
Agents deployed: ${SPECIALIST_AGENTS.length}
Total tool calls: ${allToolCalls.length}
Total duration: ${((Date.now() - swarmStart) / 1000).toFixed(1)}s

${agentSummaries}

VENOM synthesis: ${venomText ? "Complete" : "Failed"}`;

    // Merge agent notes into deep findings
    const deepFindings: any[] = Array.isArray(parsed.deepFindings) ? parsed.deepFindings : [];

    // Add per-agent raw notes as deep findings
    for (const result of agentResults) {
      if (result.rawNotes && result.rawNotes.length > 10) {
        deepFindings.push({
          category: result.agentId,
          title: `${result.codename} Intelligence Notes`,
          offset: "",
          details: result.rawNotes.slice(0, 2000),
          programmingRelevance: `From ${result.codename}`,
        });
      }
    }

    // Add gaps as deep findings
    if (Array.isArray(parsed.gaps)) {
      for (const gap of parsed.gaps) {
        deepFindings.push({
          category: "gap",
          title: "Investigation Gap",
          offset: "",
          details: typeof gap === "string" ? gap : JSON.stringify(gap),
          programmingRelevance: "Needs further investigation",
        });
      }
    }

    const swarmDuration = Date.now() - swarmStart;
    console.log(`[Swarm] Complete: ${allToolCalls.length} total tool calls in ${(swarmDuration / 1000).toFixed(1)}s`);



    onEvent?.({
      type: "swarm_complete",
      totalToolCalls: allToolCalls.length,
      durationMs: swarmDuration,
      message: `Swarm analysis complete — ${allToolCalls.length} tool calls across ${SPECIALIST_AGENTS.length} agents`,
    });

    // Return unified result compatible with QueryEngineResult
    return {
      summary: parsed.summary || `Swarm analysis of ${filename} — ${SPECIALIST_AGENTS.length} agents deployed, ${allToolCalls.length} tool calls executed.`,
      algorithms: Array.isArray(parsed.algorithms) ? parsed.algorithms : [],
      seedKeys: Array.isArray(parsed.seedKeys) ? parsed.seedKeys : [],
      canIds: (Array.isArray(parsed.canAddresses) ? parsed.canAddresses : []).map((c: any) => ({
        id: c.txId || c.id || "",
        description: c.description || "",
      })),
      canAddresses: Array.isArray(parsed.canAddresses) ? parsed.canAddresses : [],
      securityBytes: Array.isArray(parsed.securityBytes) ? parsed.securityBytes : [],
      checksums: Array.isArray(parsed.checksums) ? parsed.checksums : [],
      memoryMaps: Array.isArray(parsed.memoryMaps) ? parsed.memoryMaps : [],
      deepFindings,
      strings: Array.isArray(parsed.strings) ? parsed.strings : [],
      cryptoConstants: Array.isArray(parsed.cryptoConstants) ? parsed.cryptoConstants : [],
      toolCallTrace: allToolCalls,
      passNumber,
      analysisMode: "deep_agent" as const,
      dissectionReport,
      agentResults: agentResults.map(r => ({
        agentId: r.agentId,
        codename: r.codename,
        specialty: r.specialty,
        rawNotes: r.rawNotes,
        toolCallCount: r.toolCallTrace.length,
        iterations: r.iterations,
        durationMs: r.durationMs,
        error: r.error,
      })),
    };
  } finally {
    try {
      await fs.rm(tmpDir, { recursive: true, force: true });
    } catch {}
  }
}
