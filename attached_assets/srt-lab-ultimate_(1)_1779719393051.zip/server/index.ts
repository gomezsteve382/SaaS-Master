import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import { nanoid } from "nanoid";
import { analyzeFile, reanalyzeFile } from "./analyze.js";
import { runQueryEngine, type ToolCallEvent } from "./queryEngine.js";
import { runSwarm, type SwarmEvent, registerAgentMCPRoutes } from "./swarm/index.js";
import { runClaudeCodeSwarm } from "./claude-agents/swarm-coordinator.js";
import { runAutonomousSwarm } from "./claude-agents/autonomous-coordinator.js";
import { compareFiles, fullBinaryDiff, detectModule } from "./compare.js";
import { analyzeMultiFileAlignment, generatePatchedFiles, generateManifest } from "./multifile-align.js";
import { storagePut } from "./storage.js";
import { db } from "./db.js";
import { analysisResults, uploadedBinaries, keyFindingDismissals, shareLinks, shareLinkViews, patternLibrary, analysisFiles, yaraRules } from "../drizzle/schema.js";
import { scanKeyMaterial } from "./key-scanner.js";
import { desc, like, or, sql, eq, and } from "drizzle-orm";
import {
  createPattern,
  getPatterns,
  getPatternById,
  deletePattern,
  extractPatternsFromAnalysis,
  buildKgFromAnalysis,
  getKgGraph,
  type PatternCategory,
} from "./db-patterns.js";
import archiver from "archiver";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB max
});

// Temporary storage for patched files (auto-cleanup after 1 hour)
const patchedFiles = new Map<string, { buffer: Buffer; filename: string; timestamp: number }>();
setInterval(() => {
  const oneHourAgo = Date.now() - 3600000;
  Array.from(patchedFiles.entries()).forEach(([id, data]) => {
    if (data.timestamp < oneHourAgo) patchedFiles.delete(id);
  });
}, 300000); // Clean every 5 minutes

// ─── Analysis Diff Helper ─────────────────────────────────────────────────────
function diffArrayByKey<T extends Record<string, any>>(arr1: T[], arr2: T[], key: string): {
  onlyInA: T[]; onlyInB: T[]; inBoth: T[];
} {
  const set1 = new Set((arr1 || []).map((x: T) => String(x[key] ?? "").toLowerCase()));
  const set2 = new Set((arr2 || []).map((x: T) => String(x[key] ?? "").toLowerCase()));
  return {
    onlyInA: (arr1 || []).filter((x: T) => !set2.has(String(x[key] ?? "").toLowerCase())),
    onlyInB: (arr2 || []).filter((x: T) => !set1.has(String(x[key] ?? "").toLowerCase())),
    inBoth:  (arr1 || []).filter((x: T) =>  set2.has(String(x[key] ?? "").toLowerCase())),
  };
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(express.json({ limit: "500mb" }));

  // ─── Upload & Analyze ─────────────────────────────────────────────────
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const file = req.file;
      const fileHash = crypto.createHash("sha256").update(file.buffer).digest("hex");
      const binaryId = nanoid(12);
      const analysisId = nanoid(12);
      const userId = "anonymous"; // No auth required

      // Upload binary to S3 storage — rename forbidden extensions to .bin
      const safeFilename = file.originalname.replace(/\.(exe|dll|bat|cmd|com|scr|msi|vbs|js|ps1|sh)$/i, ".bin");
      const storageKey = `binaries/${userId}/${binaryId}/${safeFilename}`;
      let s3Key = "";
      let s3Url = "";
      try {
        const storageResult = await storagePut(
          storageKey,
          file.buffer,
          "application/octet-stream"
        );
        s3Key = storageResult.key;
        s3Url = storageResult.url;
      } catch (storageErr: any) {
        console.warn("[upload] Storage upload failed (non-fatal):", storageErr.message);
        s3Key = `local-${binaryId}`;
        s3Url = "";
      }

      // Run the AUTONOMOUS 6-agent swarm — agents collaborate in real-time via investigation bus
      console.log(`[upload] Starting AUTONOMOUS swarm for ${file.originalname} (${file.buffer.length} bytes)`);
      const qeResult = await runAutonomousSwarm(file.buffer, file.originalname, 1);

      // Map QueryEngine result to the AnalysisResult shape the rest of the app expects
      const result = {
        id: nanoid(12),
        filename: file.originalname,
        fileSize: file.buffer.length,
        fileType: qeResult.toolCallTrace.find(t => t.toolName === "file_identify")?.result?.split("\n")?.[0]?.replace("File type: ", "") || "Binary",
        timestamp: Date.now(),
        status: "complete" as const,
        analysisPass: 1,
        findings: {
          summary: qeResult.summary,
          algorithms: qeResult.algorithms,
          seedKeys: qeResult.seedKeys,
          canAddresses: qeResult.canAddresses,
          checksums: qeResult.checksums,
          memoryMaps: qeResult.memoryMaps,
          strings: qeResult.strings,
          cryptoConstants: qeResult.cryptoConstants,
          securityBytes: qeResult.securityBytes,
          deepFindings: qeResult.deepFindings,
        },
        rawHex: "",
        analysisMode: qeResult.analysisMode,
        dissectionReport: qeResult.dissectionReport,
        toolCallTrace: qeResult.toolCallTrace,
      };

      // Save binary record to database
      await db.insert(uploadedBinaries).values({
        id: binaryId,
        userId,
        filename: file.originalname,
        fileHash,
        fileSize: file.buffer.length,
        s3Key,
        s3Url,
        detectedModule: result.findings?.algorithms?.[0]?.name?.split(" ")?.[0] || null,
        uploadedAt: Date.now(),
      });

      // Save analysis result to database
      await db.insert(analysisResults).values({
        id: analysisId,
        binaryId,
        userId,
        filename: file.originalname,
        fileSize: file.buffer.length,
        fileType: result.fileType || "Unknown",
        detectedModule: result.findings?.algorithms?.[0]?.name?.split(" ")?.[0] || null,
        entropy: null,
        confidence: null,
        algorithmCount: result.findings?.algorithms?.length || 0,
        seedKeyCount: result.findings?.seedKeys?.length || 0,
        canAddressCount: result.findings?.canAddresses?.length || 0,
        checksumCount: result.findings?.checksums?.length || 0,
        securityByteCount: result.findings?.securityBytes?.length || 0,
        stringCount: result.findings?.strings?.length || 0,
        summary: result.findings?.summary || "",
        analysisData: { ...result, id: analysisId } as any,
        analyzedAt: Date.now(),
      });

      // Save analysis goals for cross-session learning (non-blocking — always fires)
      import("./ai-learning.js").then(({ saveAnalysisGoals }) => {
        saveAnalysisGoals(analysisId, "Automatic deep-dive: full automotive analysis", result).catch(console.error);
      }).catch(console.error);

      // Auto-extract patterns and build KG nodes (non-blocking)
      const _analysisIdForPatterns = analysisId;
      const _resultForPatterns = result;
      const _filenameForPatterns = req.file.originalname;
      import("./db-patterns.js").then(({ extractPatternsFromAnalysis, buildKgFromAnalysis }) => {
        const findings = _resultForPatterns?.findings || _resultForPatterns;
        extractPatternsFromAnalysis("system", _analysisIdForPatterns, findings).then(created => {
          if (created.length > 0) buildKgFromAnalysis("system", _analysisIdForPatterns, _filenameForPatterns, findings).catch(console.error);
        }).catch(console.error);
      }).catch(console.error);

      // Save per-agent metrics (non-blocking)
      if (qeResult.agentResults && qeResult.agentResults.length > 0) {
        import("./agent-metrics.js").then(({ saveAgentMetrics }) => {
          const metricsInput = qeResult.agentResults!.map((r: any) => ({
            analysisId,
            agentId: r.agentId,
            codename: r.codename,
            specialty: r.specialty || "",
            durationMs: r.durationMs || 0,
            toolCallCount: r.toolCallCount || 0,
            iterations: r.iterations || 0,
            findingsCount: 0,
            error: r.error,
          }));
          saveAgentMetrics(metricsInput).catch(console.error);
        }).catch(console.error);
      }

      // Return the analysis result with the DB-assigned ID
      res.json({ ...result, id: analysisId });
    } catch (error: any) {
      console.error("Upload error:", error);
      res.status(500).json({ error: error.message || "Analysis failed" });
    }
  });

  // ─── Job Token Map (in-memory, for polling fallback) ─────────────────
  // Keyed by jobToken (UUID). Allows frontend to poll for completion even if
  // the SSE result event is dropped by the production hosting proxy.
  const jobMap = new Map<string, { status: "pending" | "complete" | "failed"; analysisId?: string; filename?: string; error?: string }>();

  // Clean up old entries every 30 minutes (cap at 200 entries)
  setInterval(() => {
    if (jobMap.size > 200) {
      const keys = Array.from(jobMap.keys());
      keys.slice(0, jobMap.size - 200).forEach(k => jobMap.delete(k));
    }
  }, 30 * 60 * 1000);

  // ─── Job Status Polling Endpoint ────────────────────────────────────────
  // Returns job status from in-memory map. If the token is not found (e.g. after
  // server restart), return a neutral "pending" status instead of 404 so the
  // frontend doesn't spam console errors. The primary polling mechanism is
  // /api/analysis/:id which checks the DB directly.
  app.get("/api/job/:token", (req, res) => {
    const job = jobMap.get(req.params.token);
    if (!job) {
      // Token not in memory — server may have restarted. Return pending so
      // frontend continues polling the DB-backed /api/analysis/:id endpoint.
      return res.json({ status: "pending" });
    }
    res.json(job);
  });

  // ─── Pre-Register Analysis (returns analysisId+jobToken synchronously) ───
  // Frontend calls this FIRST to get IDs before starting the SSE stream.
  // This bypasses Cloudflare header/buffering issues on production.
  app.post("/api/register-analysis", async (req, res) => {
    const analysisId = nanoid(12);
    const jobToken = crypto.randomUUID();
    jobMap.set(jobToken, { status: "pending" });
    // Insert a "running" placeholder row so polling finds it immediately
    const filename = req.body?.filename || "unknown";
    const fileSize = req.body?.fileSize || 0;
    try {
      await db.insert(analysisResults).values({
        id: analysisId,
        filename,
        fileSize,
        status: "running",
        analyzedAt: Date.now(),
      });
    } catch (e: any) {
      console.warn("[register-analysis] DB insert failed:", e.message);
    }
    res.json({ analysisId, jobToken });
  });

  // ─── S3-Backed Chunk Upload ─────────────────────────────────────────────
  // Chunks are stored in S3 so any server process can assemble them.
  // Key pattern: chunks/{uploadId}/{chunkIndex}  (metadata at chunks/{uploadId}/_meta)
  const FORGE_API_URL_CHUNK = process.env.BUILT_IN_FORGE_API_URL || "";
  const FORGE_API_KEY_CHUNK = process.env.BUILT_IN_FORGE_API_KEY || "";

  async function chunkStoragePut(key: string, data: Buffer): Promise<void> {
    const FormDataNode = (await import("form-data")).default;
    const fd = new FormDataNode();
    fd.append("file", data, { filename: key.split("/").pop() || "chunk", contentType: "application/octet-stream" });
    fd.append("path", key);
    const r = await fetch(`${FORGE_API_URL_CHUNK}/v1/storage/upload`, {
      method: "POST",
      headers: { Authorization: `Bearer ${FORGE_API_KEY_CHUNK}`, ...fd.getHeaders() },
      body: fd.getBuffer(),
    });
    if (!r.ok) throw new Error(`[chunk-s3] Upload failed ${r.status}: ${await r.text()}`);
  }

  async function chunkStorageGet(key: string): Promise<Buffer> {
    // Try Forge download API first, fall back to manus-storage proxy (same pattern as batch-queue.ts)
    const forgeUrl = `${FORGE_API_URL_CHUNK}/v1/storage/download?path=${encodeURIComponent(key)}`;
    const r = await fetch(forgeUrl, {
      headers: { Authorization: `Bearer ${FORGE_API_KEY_CHUNK}` },
    });
    if (r.ok) return Buffer.from(await r.arrayBuffer());
    // Fallback: manus-storage proxy via localhost
    const port = process.env.PORT || 3001;
    const proxyUrl = `http://localhost:${port}/manus-storage/${key}`;
    const r2 = await fetch(proxyUrl);
    if (r2.ok) return Buffer.from(await r2.arrayBuffer());
    throw new Error(`[chunk-s3] Download failed (forge: ${r.status}, proxy: ${r2.status}) for key ${key}`);
  }

  // ─── Chunk Upload Endpoint ───────────────────────────────────────────────
  // POST /api/upload-chunk
  // Accepts a single chunk of a larger file and stores it in S3.
  // Body: multipart/form-data with fields:
  //   file        — the chunk binary data
  //   uploadId    — unique ID for this upload session
  //   chunkIndex  — 0-based index of this chunk
  //   totalChunks — total number of chunks
  //   filename    — original filename (only required on first chunk)
  app.post("/api/upload-chunk", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ error: "No chunk data" });
      const { uploadId, chunkIndex, totalChunks, filename } = req.body;
      if (!uploadId || chunkIndex === undefined || !totalChunks) {
        return res.status(400).json({ error: "Missing uploadId, chunkIndex, or totalChunks" });
      }
      const idx = parseInt(chunkIndex, 10);
      const total = parseInt(totalChunks, 10);

      // Store chunk in S3
      await chunkStoragePut(`chunks/${uploadId}/${idx}`, req.file.buffer);

      // On first chunk, store metadata so assembly knows filename and total
      if (idx === 0) {
        const meta = Buffer.from(JSON.stringify({ filename: filename || "upload.bin", totalChunks: total, createdAt: Date.now() }));
        await chunkStoragePut(`chunks/${uploadId}/_meta`, meta);
      }

      res.json({ received: idx + 1, total, complete: idx + 1 === total, uploadId });
    } catch (err: any) {
      console.error("[chunk-upload] Error:", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ─── SSE Streaming Upload & Analyze (S3-backed chunked assembly) ─────────
  // POST /api/upload-stream-chunked
  // Fetches all chunks from S3, assembles them, then runs the swarm analysis.
  // Body: JSON { uploadId, totalChunks, filename }
  app.post("/api/upload-stream-chunked", async (req, res) => {
    const { uploadId, totalChunks, filename, analysisId: preAnalysisId, jobToken: preJobToken } = req.body || {};
    if (!uploadId || !totalChunks) return res.status(400).json({ error: "Missing uploadId or totalChunks" });

    try {
      const total = parseInt(totalChunks, 10);
      // Fetch all chunks from S3 in parallel
      const chunkBuffers = await Promise.all(
        Array.from({ length: total }, (_, i) => chunkStorageGet(`chunks/${uploadId}/${i}`))
      );
      const assembledBuffer = Buffer.concat(chunkBuffers);

      // Create a fake multer-style file object and reuse the upload-stream logic
      const fakeFile = {
        buffer: assembledBuffer,
        originalname: filename || "upload.bin",
      };
      (req as any).file = fakeFile;
      // Forward pre-registered IDs so uploadStreamHandler uses them instead of generating new ones
      if (preAnalysisId) req.body.analysisId = preAnalysisId;
      if (preJobToken) req.body.jobToken = preJobToken;
      return uploadStreamHandler(req as any, res);
    } catch (err: any) {
      console.error("[upload-stream-chunked] Assembly error:", err.message);
      return res.status(500).json({ error: `Assembly failed: ${err.message}` });
    }
  });

  // ─── SSE Streaming Upload & Analyze ──────────────────────────────────
  // ARCHITECTURE: The swarm runs as a BACKGROUND TASK decoupled from the HTTP response.
  // Production platforms (Cloudflare, deployment infra) kill long-running HTTP handlers
  // after ~120s, but the swarm takes 5-8 minutes. Solution:
  //   1. Upload file to S3 (fast, <10s)
  //   2. Start SSE stream for live progress events
  //   3. Launch swarm as fire-and-forget background task
  //   4. Background task updates DB when complete
  //   5. Frontend polls /api/analysis/:id to detect completion (independent of SSE)
  //
  // Shared handler used by both /api/upload-stream (direct) and
  // /api/upload-stream-chunked (after chunk assembly). req.file must be set.
  const uploadStreamHandler = async (req: any, res: any) => {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    // Use pre-registered IDs if provided (from /api/register-analysis), otherwise generate new ones.
    const analysisId: string = (req.body && req.body.analysisId) ? req.body.analysisId : nanoid(12);
    const jobToken: string = (req.body && req.body.jobToken) ? req.body.jobToken : crypto.randomUUID();
    if (!req.body?.jobToken) {
      jobMap.set(jobToken, { status: "pending" });
    }

    // Set SSE headers
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no",
      "X-Analysis-Id": analysisId,
      "X-Filename": encodeURIComponent(req.file.originalname),
      "X-Job-Token": jobToken,
      "Access-Control-Expose-Headers": "X-Analysis-Id, X-Filename, X-Job-Token",
    });
    res.flushHeaders();

    let clientDisconnected = false;
    const sendEvent = (event: string, data: any) => {
      if (clientDisconnected) return;
      const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
      try {
        res.write(payload);
        if (typeof (res as any).flush === 'function') (res as any).flush();
      } catch (e) {
        clientDisconnected = true;
      }
    };

    // Keepalive ping every 15s to prevent proxy timeout
    const keepalive = setInterval(() => {
      if (clientDisconnected) { clearInterval(keepalive); return; }
      try { res.write(`:keepalive\n\n`); } catch { clientDisconnected = true; clearInterval(keepalive); }
    }, 15000);

    res.on("close", () => {
      clientDisconnected = true;
      clearInterval(keepalive);
    });

    const file = req.file;
    const fileHash = crypto.createHash("sha256").update(file.buffer).digest("hex");
    const binaryId = nanoid(12);
    const userId = "anonymous";

    // Send job token immediately
    sendEvent("job", { jobToken, analysisId });
    sendEvent("status", { phase: "uploading", message: "Uploading binary to storage..." });

    // Upload binary to S3 (fast operation, <10s)
    const safeFilename = file.originalname.replace(/\.(exe|dll|bat|cmd|com|scr|msi|vbs|js|ps1|sh)$/i, ".bin");
    const storageKey = `binaries/${userId}/${binaryId}/${safeFilename}`;
    let s3Key = "";
    let s3Url = "";
    try {
      const storageResult = await storagePut(storageKey, file.buffer, "application/octet-stream");
      s3Key = storageResult.key;
      s3Url = storageResult.url;
    } catch (storageErr: any) {
      console.warn("[upload-stream] Storage upload failed (non-fatal):", storageErr.message);
      s3Key = `local-${binaryId}`;
      s3Url = "";
    }

    sendEvent("status", { phase: "analyzing", message: "Deploying AUTONOMOUS swarm: GHOST, PHANTOM, SPECTER, WRAITH, SHADE collaborate in real-time via investigation bus..." });

    // ═══════════════════════════════════════════════════════════════════════
    // BACKGROUND TASK: Run swarm decoupled from HTTP response lifecycle.
    // This prevents the production platform from killing the analysis when
    // it terminates the HTTP connection after its timeout (~120s).
    // The swarm runs as a detached Promise — NOT awaited by the handler.
    // ═══════════════════════════════════════════════════════════════════════
    const runSwarmBackground = async () => {
      try {
        console.log(`[swarm-bg] Starting background swarm for ${analysisId} (${file.originalname}, ${file.buffer.length} bytes)`);

        const qeResult = await runAutonomousSwarm(
          file.buffer,
          file.originalname,
          1,
          undefined,
          (event: SwarmEvent) => {
            if (!clientDisconnected) sendEvent("swarm", event);
          },
          (busEvent: any) => {
            if (!clientDisconnected) sendEvent("swarm", { type: "bus_event", payload: busEvent });
          }
        );

        console.log(`[swarm-bg] Swarm complete for ${analysisId}. Writing to DB...`);

        // Map result
        const result = {
          id: nanoid(12),
          filename: file.originalname,
          fileSize: file.buffer.length,
          fileType: qeResult.toolCallTrace.find(t => t.toolName === "file_identify")?.result?.split("\n")?.[0]?.replace("File type: ", "") || "Binary",
          timestamp: Date.now(),
          status: "complete" as const,
          analysisPass: 1,
          findings: {
            summary: qeResult.summary,
            algorithms: qeResult.algorithms,
            seedKeys: qeResult.seedKeys,
            canAddresses: qeResult.canAddresses,
            checksums: qeResult.checksums,
            memoryMaps: qeResult.memoryMaps,
            strings: qeResult.strings,
            cryptoConstants: qeResult.cryptoConstants,
            securityBytes: qeResult.securityBytes,
            deepFindings: qeResult.deepFindings,
          },
          rawHex: "",
          analysisMode: qeResult.analysisMode,
          dissectionReport: qeResult.dissectionReport,
          toolCallTrace: qeResult.toolCallTrace,
        };

        // Save uploaded binary metadata
        try {
          await db.insert(uploadedBinaries).values({
            id: binaryId,
            userId,
            filename: file.originalname,
            fileHash,
            fileSize: file.buffer.length,
            s3Key,
            s3Url,
            detectedModule: result.findings?.algorithms?.[0]?.name?.split(" ")?.[0] || null,
            uploadedAt: Date.now(),
          });
        } catch (dbErr: any) {
          console.error(`[swarm-bg] uploadedBinaries insert failed (non-fatal):`, dbErr.message);
        }

        // Upsert analysis results — update the pre-registered "running" row
        try {
          await db.insert(analysisResults).values({
            id: analysisId,
            binaryId,
            userId,
            filename: file.originalname,
            fileSize: file.buffer.length,
            fileType: result.fileType || "Unknown",
            detectedModule: result.findings?.algorithms?.[0]?.name?.split(" ")?.[0] || null,
            entropy: null,
            confidence: null,
            algorithmCount: result.findings?.algorithms?.length || 0,
            seedKeyCount: result.findings?.seedKeys?.length || 0,
            canAddressCount: result.findings?.canAddresses?.length || 0,
            checksumCount: result.findings?.checksums?.length || 0,
            securityByteCount: result.findings?.securityBytes?.length || 0,
            stringCount: result.findings?.strings?.length || 0,
            summary: result.findings?.summary || "",
            analysisData: { ...result, id: analysisId } as any,
            status: "complete",
            analyzedAt: Date.now(),
          }).onDuplicateKeyUpdate({
            set: {
              binaryId,
              userId,
              filename: file.originalname,
              fileSize: file.buffer.length,
              fileType: result.fileType || "Unknown",
              detectedModule: result.findings?.algorithms?.[0]?.name?.split(" ")?.[0] || null,
              algorithmCount: result.findings?.algorithms?.length || 0,
              seedKeyCount: result.findings?.seedKeys?.length || 0,
              canAddressCount: result.findings?.canAddresses?.length || 0,
              checksumCount: result.findings?.checksums?.length || 0,
              securityByteCount: result.findings?.securityBytes?.length || 0,
              stringCount: result.findings?.strings?.length || 0,
              summary: result.findings?.summary || "",
              analysisData: { ...result, id: analysisId } as any,
              status: "complete",
              analyzedAt: Date.now(),
            },
          });
          console.log(`[swarm-bg] Analysis ${analysisId} COMPLETE — updated DB`);
        } catch (dbErr: any) {
          console.error(`[swarm-bg] analysisResults upsert FAILED for ${analysisId}:`, dbErr.message);
        }

        // Non-blocking post-processing
        import("./ai-learning.js").then(({ saveAnalysisGoals }) => {
          saveAnalysisGoals(analysisId, "Automatic deep-dive: full automotive analysis", result).catch(console.error);
        }).catch(console.error);

        import("./db-patterns.js").then(({ extractPatternsFromAnalysis, buildKgFromAnalysis }) => {
          const findings = result?.findings || result;
          extractPatternsFromAnalysis("system", analysisId, findings).then(created => {
            if (created.length > 0) buildKgFromAnalysis("system", analysisId, file.originalname, findings).catch(console.error);
          }).catch(console.error);
        }).catch(console.error);

        if (qeResult.agentResults && qeResult.agentResults.length > 0) {
          import("./agent-metrics.js").then(({ saveAgentMetrics }) => {
            const metricsInput = qeResult.agentResults!.map((r: any) => ({
              analysisId,
              agentId: r.agentId,
              codename: r.codename,
              specialty: r.specialty || "",
              durationMs: r.durationMs || 0,
              toolCallCount: r.toolCallCount || 0,
              iterations: r.iterations || 0,
              findingsCount: 0,
              error: r.error,
            }));
            saveAgentMetrics(metricsInput).catch(console.error);
          }).catch(console.error);
        }

        // Update job map
        jobMap.set(jobToken, { status: "complete", analysisId, filename: file.originalname });

        // Try to send SSE result (client may have disconnected, that's OK)
        sendEvent("result", { id: analysisId, status: "complete", filename: file.originalname });
        try { if (!clientDisconnected) { clearInterval(keepalive); res.end(); } } catch {}

      } catch (error: any) {
        console.error(`[swarm-bg] Swarm FAILED for ${analysisId}:`, error.message);

        // Update DB to failed status
        try {
          await db.insert(analysisResults).values({
            id: analysisId,
            binaryId,
            userId,
            filename: file.originalname,
            fileSize: file.buffer.length,
            fileType: "Unknown",
            detectedModule: null,
            entropy: null,
            confidence: null,
            algorithmCount: 0,
            seedKeyCount: 0,
            canAddressCount: 0,
            checksumCount: 0,
            securityByteCount: 0,
            stringCount: 0,
            summary: `Analysis failed: ${error.message}`,
            analysisData: { error: error.message } as any,
            status: "failed",
            analyzedAt: Date.now(),
          }).onDuplicateKeyUpdate({
            set: {
              status: "failed",
              summary: `Analysis failed: ${error.message}`,
              analysisData: { error: error.message } as any,
              analyzedAt: Date.now(),
            },
          });
          console.log(`[swarm-bg] Analysis ${analysisId} marked FAILED in DB`);
        } catch (dbErr: any) {
          console.error(`[swarm-bg] Failed to mark analysis as failed:`, dbErr.message);
        }

        // Update job map
        try { jobMap.set(jobToken, { status: "failed", error: error.message || "Analysis failed" }); } catch {}

        // Try to send error event (client may have disconnected)
        sendEvent("error", { message: error.message || "Analysis failed" });
        try { if (!clientDisconnected) { clearInterval(keepalive); res.end(); } } catch {}
      }
    };

    // FIRE AND FORGET — do NOT await this.
    // The swarm runs independently of the HTTP response lifecycle.
    // The production platform can kill this HTTP connection after 120s,
    // but the Node.js process continues running the swarm in the background.
    runSwarmBackground().catch((err) => {
      console.error(`[swarm-bg] Unhandled error in background swarm:`, err);
    });

    // DO NOT res.end() here — the SSE stream stays open for live progress events.
    // If the client disconnects or the proxy kills the connection, that's fine —
    // the background task will still complete and update the DB.
  };

  // Register the direct (non-chunked) upload-stream route
  app.post("/api/upload-stream", upload.single("file"), uploadStreamHandler);

  // ─── Vault (all analyses from DB) ─────────────────────────────────────
  app.get("/api/vault", async (_req, res) => {
    try {
      const rows = await db
        .select({
          id: analysisResults.id,
          filename: analysisResults.filename,
          fileSize: analysisResults.fileSize,
          fileType: analysisResults.fileType,
          detectedModule: analysisResults.detectedModule,
          algorithmCount: analysisResults.algorithmCount,
          seedKeyCount: analysisResults.seedKeyCount,
          canAddressCount: analysisResults.canAddressCount,
          checksumCount: analysisResults.checksumCount,
          securityByteCount: analysisResults.securityByteCount,
          stringCount: analysisResults.stringCount,
          summary: analysisResults.summary,
          analyzedAt: analysisResults.analyzedAt,
        })
        .from(analysisResults)
        .orderBy(desc(analysisResults.analyzedAt))
        .limit(100);

      // Map to the shape the frontend expects
      const vault = rows.map(r => ({
        id: r.id,
        filename: r.filename,
        fileSize: r.fileSize,
        fileType: r.fileType || "Unknown",
        timestamp: r.analyzedAt,
        status: "complete",
        summary: r.summary || "",
        algorithmCount: r.algorithmCount || 0,
        seedKeyCount: r.seedKeyCount || 0,
        canAddressCount: r.canAddressCount || 0,
        checksumCount: r.checksumCount || 0,
        stringCount: r.stringCount || 0,
      }));

      res.json(vault);
    } catch (error: any) {
      console.error("Vault error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Analysis Detail ───────────────────────────────────────────────────
  app.get("/api/analysis/:id", async (req, res) => {
    try {
      const rows = await db
        .select()
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${req.params.id}`)
        .limit(1);

      if (rows.length === 0) {
        return res.status(404).json({ error: "Analysis not found" });
      }

      const row = rows[0];
      // Handle running/failed states
      if (row.status === "running") {
        return res.json({ id: row.id, status: "running", filename: row.filename, fileSize: row.fileSize });
      }
      if (row.status === "failed") {
        return res.json({ id: row.id, status: "failed", filename: row.filename, error: row.errorMessage || "Analysis failed" });
      }
      // Return the full analysis data stored as JSON
      const fullData = row.analysisData as any;
      if (!fullData) {
        return res.json({ id: row.id, status: "running", filename: row.filename, fileSize: row.fileSize });
      }
      res.json({ ...fullData, id: row.id, status: "complete" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Export: JSON ────────────────────────────────────────────────────────
  app.get("/api/analysis/:id/export/json", async (req, res) => {
    try {
      const rows = await db
        .select()
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${req.params.id}`)
        .limit(1);
      if (rows.length === 0) return res.status(404).json({ error: "Analysis not found" });
      const { generateJSONReport } = await import("./report-generator.js");
      const report = generateJSONReport(rows[0].analysisData as any, rows[0].id);
      const filename = `srtlab-report-${rows[0].filename?.replace(/[^a-z0-9]/gi, "_").slice(0, 40) || rows[0].id}.json`;
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Export: PDF ─────────────────────────────────────────────────────────
  app.get("/api/analysis/:id/export/pdf", async (req, res) => {
    try {
      const rows = await db
        .select()
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${req.params.id}`)
        .limit(1);
      if (rows.length === 0) return res.status(404).json({ error: "Analysis not found" });
      const { generatePDFReport } = await import("./report-generator.js");
      const pdfBuffer = await generatePDFReport(rows[0].analysisData as any);
      const filename = `srtlab-report-${rows[0].filename?.replace(/[^a-z0-9]/gi, "_").slice(0, 40) || rows[0].id}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Content-Length", pdfBuffer.length);
      res.end(pdfBuffer);
    } catch (error: any) {
      console.error("[PDF Export] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/analysis/:id/extraction-tree/zip — download extraction tree as zip
  app.get("/api/analysis/:id/extraction-tree/zip", async (req, res) => {
    try {
      const rows = await db.select().from(analysisResults).where(eq(analysisResults.id, req.params.id)).limit(1);
      if (!rows[0]) return res.status(404).json({ error: "Analysis not found" });
      const analysis = rows[0];
      const data = analysis.analysisData as any;
      const fname = (analysis.filename || analysis.id).replace(/[^a-z0-9._-]/gi, "_");
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="srtlab-extraction-${fname}.zip"`);
      const archive = archiver("zip", { zlib: { level: 9 } });
      archive.pipe(res);
      archive.append(JSON.stringify(data, null, 2), { name: "analysis.json" });
      if (data?.algorithms?.length) {
        const lines = data.algorithms.map((a: any) =>
          `${a.name}\t${a.confidence || ""}\t0x${(a.offset || 0).toString(16).toUpperCase().padStart(8, "0")}\t${a.description || ""}`
        ).join("\n");
        archive.append(`Name\tConfidence\tOffset\tDescription\n${lines}`, { name: "algorithms.tsv" });
      }
      if (data?.seedKeys?.length) {
        const lines = data.seedKeys.map((k: any) =>
          typeof k === "string" ? k : (k.value || k.hex || JSON.stringify(k))
        ).join("\n");
        archive.append(lines, { name: "seed_keys.txt" });
      }
      if (data?.strings?.length) {
        const lines = data.strings.map((s: any) =>
          typeof s === "string" ? s : (s.value || JSON.stringify(s))
        ).join("\n");
        archive.append(lines, { name: "strings.txt" });
      }
      if (data?.canAddresses?.length) {
        const lines = data.canAddresses.map((c: any) =>
          typeof c === "string" ? c : (c.address || c.id || JSON.stringify(c))
        ).join("\n");
        archive.append(lines, { name: "can_addresses.txt" });
      }
      if (data?.summary) archive.append(data.summary, { name: "summary.txt" });
      await archive.finalize();
    } catch (error: any) {
      console.error("[Extraction ZIP] Error:", error);
      if (!res.headersSent) res.status(500).json({ error: error.message });
    }
  });

  // ─── Search ────────────────────────────────────────────────────────────
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Query required" });
      }

      const q = `%${query}%`;
      const rows = await db
        .select({
          id: analysisResults.id,
          filename: analysisResults.filename,
          fileType: analysisResults.fileType,
          summary: analysisResults.summary,
          algorithmCount: analysisResults.algorithmCount,
          seedKeyCount: analysisResults.seedKeyCount,
          canAddressCount: analysisResults.canAddressCount,
          analyzedAt: analysisResults.analyzedAt,
          analysisData: analysisResults.analysisData,
        })
        .from(analysisResults)
        .where(
          or(
            like(analysisResults.filename, q),
            like(analysisResults.summary, q),
            like(analysisResults.fileType, q),
            like(analysisResults.detectedModule, q)
          )
        )
        .orderBy(desc(analysisResults.analyzedAt))
        .limit(50);

      // Search within the JSON analysis data for deeper matches
      const results: any[] = [];
      for (const row of rows) {
        const data = row.analysisData as any;
        if (!data?.findings) continue;

        const findings = data.findings;
        const lq = query.toLowerCase();

        for (const algo of findings.algorithms || []) {
          if (
            algo.name?.toLowerCase().includes(lq) ||
            algo.description?.toLowerCase().includes(lq) ||
            algo.constants?.some((c: string) => c.toLowerCase().includes(lq))
          ) {
            results.push({ type: "algorithm", source: row.filename, analysisId: row.id, data: algo });
          }
        }

        for (const sk of findings.seedKeys || []) {
          if (
            sk.module?.toLowerCase().includes(lq) ||
            sk.algorithm?.toLowerCase().includes(lq) ||
            sk.description?.toLowerCase().includes(lq)
          ) {
            results.push({ type: "seedKey", source: row.filename, analysisId: row.id, data: sk });
          }
        }

        for (const can of findings.canAddresses || []) {
          if (
            can.module?.toLowerCase().includes(lq) ||
            can.txId?.toLowerCase().includes(lq) ||
            can.rxId?.toLowerCase().includes(lq)
          ) {
            results.push({ type: "canAddress", source: row.filename, analysisId: row.id, data: can });
          }
        }

        for (const cs of findings.checksums || []) {
          if (
            cs.type?.toLowerCase().includes(lq) ||
            cs.polynomial?.toLowerCase().includes(lq) ||
            cs.description?.toLowerCase().includes(lq)
          ) {
            results.push({ type: "checksum", source: row.filename, analysisId: row.id, data: cs });
          }
        }

        for (const sb of findings.securityBytes || []) {
          if (
            sb.module?.toLowerCase().includes(lq) ||
            sb.description?.toLowerCase().includes(lq) ||
            sb.offset?.toLowerCase().includes(lq)
          ) {
            results.push({ type: "securityByte", source: row.filename, analysisId: row.id, data: sb });
          }
        }
      }

      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Stats ─────────────────────────────────────────────────────────────
  app.get("/api/stats", async (_req, res) => {
    try {
      const rows = await db
        .select({
          algorithmCount: analysisResults.algorithmCount,
          seedKeyCount: analysisResults.seedKeyCount,
          canAddressCount: analysisResults.canAddressCount,
          checksumCount: analysisResults.checksumCount,
        })
        .from(analysisResults);

      const stats = rows.reduce(
        (acc, r) => ({
          algorithms: acc.algorithms + (r.algorithmCount || 0),
          seedKeys: acc.seedKeys + (r.seedKeyCount || 0),
          canAddresses: acc.canAddresses + (r.canAddressCount || 0),
          checksums: acc.checksums + (r.checksumCount || 0),
          totalAnalyses: acc.totalAnalyses + 1,
        }),
        { algorithms: 0, seedKeys: 0, canAddresses: 0, checksums: 0, totalAnalyses: 0 }
      );

      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Compare & Patch ───────────────────────────────────────────────────
  const uploadTwo = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 500 * 1024 * 1024 }, // 500MB max
  }).fields([
    { name: "source", maxCount: 1 },
    { name: "target", maxCount: 1 },
  ]);

  app.post("/api/compare", uploadTwo, async (req, res) => {
    try {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      const sourceFile = files?.source?.[0];
      const targetFile = files?.target?.[0];

      if (!sourceFile || !targetFile) {
        return res.status(400).json({ error: "Both source and target files are required" });
      }

      const sourceModule = (req.body?.sourceModule as string) || undefined;
      const targetModule = (req.body?.targetModule as string) || undefined;

      const result = compareFiles(sourceFile, targetFile, sourceModule, targetModule);

      if (result.patchedFile2) {
        patchedFiles.set(result.id, {
          buffer: result.patchedFile2,
          filename: `${targetFile.originalname.replace(/\.[^.]+$/, "")}_patched${targetFile.originalname.match(/\.[^.]+$/)?.[0] || ".bin"}`,
          timestamp: Date.now(),
        });
      }

      const { patchedFile2, ...responseData } = result;
      res.json(responseData);
    } catch (error: any) {
      console.error("Compare error:", error);
      res.status(500).json({ error: error.message || "Comparison failed" });
    }
  });

  app.get("/api/compare/:id/download", async (req, res) => {
    try {
      const patched = patchedFiles.get(req.params.id);
      if (!patched) {
        return res.status(404).json({ error: "Patched file not found or expired" });
      }
      res.setHeader("Content-Type", "application/octet-stream");
      res.setHeader("Content-Disposition", `attachment; filename="${patched.filename}"`);
      res.setHeader("Content-Length", patched.buffer.length);
      res.send(patched.buffer);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Multi-Align ───────────────────────────────────────────────────────
  const uploadThree = upload.array("files", 3);
  app.post("/api/align", uploadThree, async (req, res) => {
    try {
      if (!req.files || req.files.length !== 3) {
        return res.status(400).json({ error: "Exactly 3 files required" });
      }

      const files = (req.files as Express.Multer.File[]).map(f => ({
        buffer: f.buffer,
        filename: f.originalname || `file_${Date.now()}`,
        module: detectModule(f.buffer, f.originalname || "") || "UNKNOWN",
        fileSize: f.size,
      }));

      const alignment = analyzeMultiFileAlignment(files);
      const patchedBuffers = generatePatchedFiles(alignment, files);
      const manifest = generateManifest(alignment, files);

      const patchedIds: string[] = [];
      for (let i = 0; i < patchedBuffers.length; i++) {
        const id = `patched_${alignment.id}_${i}`;
        patchedFiles.set(id, {
          buffer: patchedBuffers[i],
          filename: `${files[i].filename.replace(/\.[^.]+$/, "")}_patched.bin`,
          timestamp: Date.now(),
        });
        patchedIds.push(id);
      }

      const manifestId = `manifest_${alignment.id}`;
      patchedFiles.set(manifestId, {
        buffer: Buffer.from(manifest, "utf-8"),
        filename: `alignment_manifest_${alignment.id}.json`,
        timestamp: Date.now(),
      });
      patchedIds.push(manifestId);

      res.json({ ...alignment, patchedFileIds: patchedIds });
    } catch (error: any) {
      console.error("Alignment error:", error);
      res.status(500).json({ error: error.message || "Alignment failed" });
    }
  });

  app.get("/api/align/:id/download-zip", async (req, res) => {
    try {
      const alignmentId = req.params.id;
      const patchedIds = Array.from(patchedFiles.keys()).filter(id =>
        id.startsWith(`patched_${alignmentId}_`)
      );

      if (patchedIds.length === 0) {
        return res.status(404).json({ error: "Patched files not found or expired" });
      }

      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="srt-lab-aligned-${alignmentId}.zip"`);

      const archive = archiver("zip", { zlib: { level: 9 } });
      archive.pipe(res);

      for (const patchedId of patchedIds) {
        const patched = patchedFiles.get(patchedId);
        if (patched) {
          archive.append(patched.buffer, { name: patched.filename });
        }
      }

      await archive.finalize();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Full Binary Diff ──────────────────────────────────────────────────
  app.post("/api/compare/diff", uploadTwo, async (req, res) => {
    try {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      const sourceFile = files?.source?.[0];
      const targetFile = files?.target?.[0];

      if (!sourceFile || !targetFile) {
        return res.status(400).json({ error: "Both files are required" });
      }

      const diff = fullBinaryDiff(sourceFile.buffer, targetFile.buffer);
      res.json({
        file1Size: sourceFile.buffer.length,
        file2Size: targetFile.buffer.length,
        totalDiffChunks: diff.length,
        chunks: diff,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Delete Analysis ────────────────────────────────────────────────────
  app.delete("/api/analysis/:id", async (req, res) => {
    try {
      const { id } = req.params;

      // Find the analysis to get the binaryId
      const rows = await db
        .select({ id: analysisResults.id, binaryId: analysisResults.binaryId })
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${id}`)
        .limit(1);

      if (rows.length === 0) {
        return res.status(404).json({ error: "Analysis not found" });
      }

      const row = rows[0];

      // Delete the analysis result
      await db.delete(analysisResults).where(sql`${analysisResults.id} = ${id}`);

      // Delete the binary record if it exists
      if (row.binaryId) {
        await db.delete(uploadedBinaries).where(sql`${uploadedBinaries.id} = ${row.binaryId}`);
      }

      res.json({ success: true, deleted: id });
    } catch (error: any) {
      console.error("Delete error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Key & Secrets Findings ─────────────────────────────────────────────
  // GET /api/analysis/:id/key-findings — scan the binary and return all findings
  app.get("/api/analysis/:id/key-findings", async (req, res) => {
    try {
      const { id } = req.params;
      // Load analysis to get the s3Key
      const rows = await db
        .select({ binaryId: analysisResults.binaryId, filename: analysisResults.filename, status: analysisResults.status })
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${id}`)
        .limit(1);
      if (rows.length === 0) return res.status(404).json({ error: "Analysis not found" });
      if (rows[0].status !== "complete") return res.json({ findings: [], dismissed: [] });

      // Load the binary from S3
      const binRows = await db
        .select({ s3Key: uploadedBinaries.s3Key })
        .from(uploadedBinaries)
        .where(sql`${uploadedBinaries.id} = ${rows[0].binaryId}`)
        .limit(1);
      if (binRows.length === 0) return res.json({ findings: [], dismissed: [] });

      // Fetch from S3 via storage
      const { storageGet } = await import("./storage.js");
      const { url } = await storageGet(binRows[0].s3Key);
      const resp = await fetch(url);
      if (!resp.ok) return res.status(500).json({ error: "Failed to fetch binary from storage" });
      const arrayBuf = await resp.arrayBuffer();
      const buf = Buffer.from(arrayBuf);

      const findings = scanKeyMaterial(buf);

      // Load dismissed finding IDs for this analysis
      const dismissedRows = await db
        .select({ findingId: keyFindingDismissals.findingId })
        .from(keyFindingDismissals)
        .where(sql`${keyFindingDismissals.analysisId} = ${id}`);
      const dismissed = dismissedRows.map((r) => r.findingId);

      res.json({ findings, dismissed });
    } catch (error: any) {
      console.error("[key-findings] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/analysis/:id/key-findings/:findingId/dismiss — dismiss a finding
  app.post("/api/analysis/:id/key-findings/:findingId/dismiss", async (req, res) => {
    try {
      const { id, findingId } = req.params;
      const existing = await db
        .select({ id: keyFindingDismissals.id })
        .from(keyFindingDismissals)
        .where(sql`${keyFindingDismissals.analysisId} = ${id} AND ${keyFindingDismissals.findingId} = ${findingId}`)
        .limit(1);
      if (existing.length === 0) {
        await db.insert(keyFindingDismissals).values({
          id: nanoid(),
          analysisId: id,
          findingId,
          dismissedAt: Date.now(),
        });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // DELETE /api/analysis/:id/key-findings/:findingId/dismiss — restore a dismissed finding
  app.delete("/api/analysis/:id/key-findings/:findingId/dismiss", async (req, res) => {
    try {
      const { id, findingId } = req.params;
      await db
        .delete(keyFindingDismissals)
        .where(sql`${keyFindingDismissals.analysisId} = ${id} AND ${keyFindingDismissals.findingId} = ${findingId}`);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/analysis/:id/binary/peek — stream raw binary bytes for hex viewer
  app.get("/api/analysis/:id/binary/peek", async (req, res) => {
    try {
      const { id } = req.params;
      const offset = parseInt((req.query.offset as string) || "0", 10);
      const length = Math.min(parseInt((req.query.length as string) || "4096", 10), 65536);

      const rows = await db
        .select({ binaryId: analysisResults.binaryId, status: analysisResults.status })
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${id}`)
        .limit(1);
      if (rows.length === 0) return res.status(404).json({ error: "Analysis not found" });
      if (rows[0].status !== "complete") return res.status(400).json({ error: "Analysis not complete" });

      const binRows = await db
        .select({ s3Key: uploadedBinaries.s3Key, fileSize: uploadedBinaries.fileSize })
        .from(uploadedBinaries)
        .where(sql`${uploadedBinaries.id} = ${rows[0].binaryId}`)
        .limit(1);
      if (binRows.length === 0) return res.status(404).json({ error: "Binary not found" });

      const { storageGet } = await import("./storage.js");
      const { url } = await storageGet(binRows[0].s3Key);
      // Fetch only the requested byte range
      const rangeHeader = `bytes=${offset}-${offset + length - 1}`;
      const resp = await fetch(url, { headers: { Range: rangeHeader } });
      if (!resp.ok && resp.status !== 206) return res.status(500).json({ error: "Failed to fetch binary" });
      const arrayBuf = await resp.arrayBuffer();
      const chunk = Buffer.from(arrayBuf);

      res.json({
        offset,
        length: chunk.length,
        totalSize: binRows[0].fileSize,
        hex: chunk.toString("hex"),
        ascii: chunk.toString("latin1").replace(/[\x00-\x1f\x7f-\xff]/g, "."),
      });
    } catch (error: any) {
      console.error("[binary-peek] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Re-analyze ────────────────────────────────────────────────────────
  app.post("/api/analysis/:id/reanalyze", async (req, res) => {
    try {
      const { id } = req.params;

      // Get the existing analysis to find the stored binary
      const rows = await db
        .select()
        .from(analysisResults)
        .where(sql`${analysisResults.id} = ${id}`)
        .limit(1);

      if (rows.length === 0) {
        return res.status(404).json({ error: "Analysis not found" });
      }

      const existing = rows[0];

      // Get the binary record to retrieve the S3 URL
      let binaryBuffer: Buffer | null = null;
      if (existing.binaryId) {
        const binRows = await db
          .select()
          .from(uploadedBinaries)
          .where(sql`${uploadedBinaries.id} = ${existing.binaryId}`)
          .limit(1);

        if (binRows.length > 0 && binRows[0].s3Url) {
          try {
            const s3Url = binRows[0].s3Url;
            // Fetch the binary from S3
            const fetchUrl = s3Url.startsWith("/manus-storage/")
              ? `http://localhost:${process.env.PORT || 3001}${s3Url}`
              : s3Url;
            const response = await fetch(fetchUrl);
            if (response.ok) {
              const arrayBuffer = await response.arrayBuffer();
              binaryBuffer = Buffer.from(arrayBuffer);
            }
          } catch (fetchErr) {
            console.warn("Could not fetch binary from S3:", fetchErr);
          }
        }
      }

      if (!binaryBuffer) {
        return res.status(422).json({
          error: "Original binary file is no longer available for re-analysis. Please re-upload the file."
        });
      }

      // Determine pass number and build prior findings context
      const previousData = existing.analysisData as any;
      const passNumber = (previousData?.analysisPass || previousData?.passNumber || 1) + 1;
      let priorSummary = previousData?.findings?.summary
        ? `PASS ${passNumber - 1} SUMMARY: ${previousData.findings.summary}\n` +
          `Algorithms found: ${previousData.findings?.algorithms?.length || 0}\n` +
          `Seed keys found: ${previousData.findings?.seedKeys?.length || 0}\n` +
          `CAN addresses: ${previousData.findings?.canAddresses?.length || 0}\n` +
          `Security bytes: ${previousData.findings?.securityBytes?.length || 0}`
        : undefined;

      // Fetch additional files if includeAdditionalFiles is requested
      let additionalFileBuffers: Array<{ filename: string; buffer: Buffer }> = [];
      const { includeAdditionalFiles } = req.body || {};
      if (includeAdditionalFiles) {
        try {
          const addlFiles = await db
            .select()
            .from(analysisFiles)
            .where(sql`${analysisFiles.analysisId} = ${id}`);
          for (const af of addlFiles) {
            try {
              const fetchUrl = af.s3Url.startsWith("/manus-storage/")
                ? `http://localhost:${process.env.PORT || 3001}${af.s3Url}`
                : af.s3Url;
              const afRes = await fetch(fetchUrl);
              if (afRes.ok) {
                const ab = await afRes.arrayBuffer();
                additionalFileBuffers.push({ filename: af.filename, buffer: Buffer.from(ab) });
              }
            } catch (e) {
              console.warn(`Could not fetch additional file ${af.filename}:`, e);
            }
          }
        } catch (e) {
          console.warn("Could not fetch additional files:", e);
        }
      }

      // Build combined buffer if additional files exist
      let primaryBuffer = binaryBuffer;
      let primaryFilename = existing.filename;
      if (additionalFileBuffers.length > 0) {
        // Write all files to a temp dir and create a manifest for the agents
        const allFilenames = [existing.filename, ...additionalFileBuffers.map(f => f.filename)];
        const manifestNote = `\n\nADDITIONAL FILES IN THIS SESSION (${additionalFileBuffers.length} extra files):\n` +
          allFilenames.map((fn, i) => `  File ${i + 1}: ${fn}`).join("\n") +
          `\n\nEach file has been written to disk. Use archive_extract or read_hex on each file path individually.`;
        priorSummary = (priorSummary || "") + manifestNote;
        // Store additional buffers for the swarm to access
        // The swarm will write each to disk via the temp dir
        (binaryBuffer as any).__additionalFiles = additionalFileBuffers;
      }

      // Run AUTONOMOUS swarm for re-analysis — agents collaborate + use prior findings
      console.log(`[reanalyze] Starting AUTONOMOUS swarm pass ${passNumber} for ${existing.filename}${additionalFileBuffers.length > 0 ? ` + ${additionalFileBuffers.length} additional files` : ""}`);
      const qeResult = await runAutonomousSwarm(primaryBuffer, primaryFilename, passNumber, priorSummary);

      const result = {
        id: existing.id,
        filename: existing.filename,
        fileSize: binaryBuffer.length,
        fileType: qeResult.toolCallTrace.find(t => t.toolName === "file_identify")?.result?.split("\n")?.[0]?.replace("File type: ", "") || existing.fileType || "Binary",
        timestamp: Date.now(),
        status: "complete" as const,
        analysisPass: passNumber,
        findings: {
          summary: qeResult.summary,
          algorithms: qeResult.algorithms,
          seedKeys: qeResult.seedKeys,
          canAddresses: qeResult.canAddresses,
          checksums: qeResult.checksums,
          memoryMaps: qeResult.memoryMaps,
          strings: qeResult.strings,
          cryptoConstants: qeResult.cryptoConstants,
          securityBytes: qeResult.securityBytes,
          deepFindings: qeResult.deepFindings,
        },
        rawHex: "",
        analysisMode: qeResult.analysisMode,
        dissectionReport: qeResult.dissectionReport,
        toolCallTrace: qeResult.toolCallTrace,
      };

      // Update the existing analysis record with merged deeper results
      await db
        .update(analysisResults)
        .set({
          fileType: result.fileType || "Unknown",
          detectedModule: result.findings?.algorithms?.[0]?.name?.split(" ")?.[0] || null,
          algorithmCount: result.findings?.algorithms?.length || 0,
          seedKeyCount: result.findings?.seedKeys?.length || 0,
          canAddressCount: result.findings?.canAddresses?.length || 0,
          checksumCount: result.findings?.checksums?.length || 0,
          securityByteCount: result.findings?.securityBytes?.length || 0,
          stringCount: result.findings?.strings?.length || 0,
          summary: result.findings?.summary || "",
          analysisData: result as any,
          analyzedAt: Date.now(),
        })
        .where(sql`${analysisResults.id} = ${id}`);

      res.json({ ...result, id });
    } catch (error: any) {
      console.error("Re-analyze error:", error);
      res.status(500).json({ error: error.message || "Re-analysis failed" });
    }
  });

  // ─── Diff Two Analyses (by ID) ──────────────────────────────────────────
  app.get("/api/diff", async (req, res) => {
    try {
      const { id1, id2 } = req.query as { id1: string; id2: string };
      if (!id1 || !id2) return res.status(400).json({ error: "id1 and id2 required" });

      const [rows1, rows2] = await Promise.all([
        db.select().from(analysisResults).where(sql`${analysisResults.id} = ${id1}`).limit(1),
        db.select().from(analysisResults).where(sql`${analysisResults.id} = ${id2}`).limit(1),
      ]);

      if (!rows1.length) return res.status(404).json({ error: `Analysis ${id1} not found` });
      if (!rows2.length) return res.status(404).json({ error: `Analysis ${id2} not found` });

      const a1 = rows1[0].analysisData as any;
      const a2 = rows2[0].analysisData as any;

      const diff = {
        meta: {
          a: { id: rows1[0].id, filename: rows1[0].filename, fileSize: rows1[0].fileSize, analyzedAt: rows1[0].analyzedAt, fileType: rows1[0].fileType },
          b: { id: rows2[0].id, filename: rows2[0].filename, fileSize: rows2[0].fileSize, analyzedAt: rows2[0].analyzedAt, fileType: rows2[0].fileType },
        },
        summaries: { a: a1?.findings?.summary || "", b: a2?.findings?.summary || "" },
        algorithms: diffArrayByKey(a1?.findings?.algorithms || [], a2?.findings?.algorithms || [], "name"),
        seedKeys: diffArrayByKey(a1?.findings?.seedKeys || [], a2?.findings?.seedKeys || [], "module"),
        canAddresses: diffArrayByKey(a1?.findings?.canAddresses || [], a2?.findings?.canAddresses || [], "txId"),
        checksums: diffArrayByKey(a1?.findings?.checksums || [], a2?.findings?.checksums || [], "type"),
        securityBytes: diffArrayByKey(a1?.findings?.securityBytes || [], a2?.findings?.securityBytes || [], "offset"),
        deepFindings: diffArrayByKey(a1?.findings?.deepFindings || [], a2?.findings?.deepFindings || [], "title"),
      };

      res.json(diff);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── Dedup Check ───────────────────────────────────────────────────────
  app.post("/api/check-duplicate", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file provided" });
      }

      const fileHash = crypto.createHash("sha256").update(req.file.buffer).digest("hex");

      // Check if this hash already exists in uploaded_binaries
      const existing = await db
        .select({
          id: uploadedBinaries.id,
          filename: uploadedBinaries.filename,
          uploadedAt: uploadedBinaries.uploadedAt,
        })
        .from(uploadedBinaries)
        .where(sql`${uploadedBinaries.fileHash} = ${fileHash}`)
        .limit(1);

      if (existing.length > 0) {
        // Find the analysis for this binary
        const analysis = await db
          .select({ id: analysisResults.id })
          .from(analysisResults)
          .where(sql`${analysisResults.binaryId} = ${existing[0].id}`)
          .limit(1);

        return res.json({
          isDuplicate: true,
          hash: fileHash,
          existingFilename: existing[0].filename,
          existingAnalysisId: analysis[0]?.id || null,
          uploadedAt: existing[0].uploadedAt,
        });
      }

      res.json({ isDuplicate: false, hash: fileHash });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ─── AI Learning Profile ──────────────────────────────────────────────────
  app.get("/api/profile", async (_req, res) => {
    try {
      const { loadUserProfile } = await import("./ai-learning.js");
      const profile = await loadUserProfile();
      res.json(profile);
    } catch (error: any) {
      res.json({ totalSessions: 0, knownModules: [], knownAlgorithms: [], knownPatterns: [], expertiseSummary: "" });
    }
  });

  // ─── Analysis Chat (SSE) ─────────────────────────────────────────────────
  // ─── Analysis Chat History (GET) ──────────────────────────────────────────
  app.get("/api/analysis/:id/chat/history", async (req, res) => {
    const { id } = req.params;
    try {
      const { chatMessages: chatMsgsTable } = await import("../drizzle/schema.js");
      const msgs = await db.select().from(chatMsgsTable)
        .where(sql`${chatMsgsTable.analysisId} = ${id}`)
        .orderBy(chatMsgsTable.createdAt)
        .limit(200);
      res.json({ messages: msgs });
    } catch (err: any) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post("/api/analysis/:id/chat", async (req, res) => {
    const { id } = req.params;
    const { message: userMessage, history } = req.body as {
      message: string;
      history?: Array<{ role: string; content: string }>;
    };
    if (!userMessage) return res.status(400).json({ error: "message required" });

    // Load persisted history from DB if no history provided in request
    let dbHistory: Array<{ role: string; content: string }> = [];
    try {
      const { chatMessages: chatMsgsTable } = await import("../drizzle/schema.js");
      const dbMsgs = await db.select().from(chatMsgsTable)
        .where(sql`${chatMsgsTable.analysisId} = ${id}`)
        .orderBy(chatMsgsTable.createdAt)
        .limit(50);
      dbHistory = dbMsgs.map((m: any) => ({ role: m.role as string, content: m.content as string }));
    } catch {}

    let analysisContext = "";
    let binaryPath = "";
    try {
      const rows = await db.select().from(analysisResults).where(sql`${analysisResults.id} = ${id}`).limit(1);
      if (rows.length > 0) {
        const data = rows[0].analysisData as any;
        const findings = data?.findings || {};
        analysisContext = [
          `File: ${rows[0].filename} (${rows[0].fileType}, ${rows[0].fileSize} bytes)`,
          `Summary: ${findings.summary || "N/A"}`,
          `Algorithms: ${(findings.algorithms || []).map((a: any) => a.name).join(", ") || "none"}`,
          `Seed Keys: ${(findings.seedKeys || []).map((s: any) => s.module).join(", ") || "none"}`,
          `CAN Addresses: ${(findings.canAddresses || []).map((c: any) => `${c.module}(TX:${c.txId})`).join(", ") || "none"}`,
          `Security Bytes: ${(findings.securityBytes || []).map((s: any) => `${s.module}@${s.offset}`).join(", ") || "none"}`,
          `Deep Findings: ${(findings.deepFindings || []).map((d: any) => d.title).join(", ") || "none"}`,
        ].join("\n");
        if (rows[0].binaryId) {
          const binRows = await db.select().from(uploadedBinaries).where(sql`${uploadedBinaries.id} = ${rows[0].binaryId}`).limit(1);
          if (binRows.length > 0 && binRows[0].s3Url) {
            const tmpPath = `/tmp/chat_binary_${id}.bin`;
            try {
              let fetchUrl = binRows[0].s3Url;
              if (fetchUrl.startsWith("/manus-storage/")) {
                const port = process.env.PORT || 3000;
                fetchUrl = `http://localhost:${port}${fetchUrl}`;
              }
              const resp2 = await fetch(fetchUrl);
              if (resp2.ok) {
                const buf = Buffer.from(await resp2.arrayBuffer());
                const fs2 = await import("fs/promises");
                await fs2.writeFile(tmpPath, buf);
                binaryPath = tmpPath;
              } else {
                console.error(`[CHAT] Failed to fetch binary: ${resp2.status} ${fetchUrl}`);
              }
            } catch (e: any) {
              console.error(`[CHAT] Binary download error: ${e.message}`);
            }
          }
        }
      }
    } catch {}

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no",
    });
    const send = (event: string, data: any) => {
      try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch {}
    };
    const keepalive = setInterval(() => { try { res.write(":keepalive\n\n"); } catch {} }, 15000);
    res.on("close", () => clearInterval(keepalive));

    try {
      const CHAT_SYSTEM = `You are VENOM — a 40-year seasoned reverse engineer and black hat specialist. You are the SRT Lab intelligence coordinator. You have already analyzed this binary with 5 specialist agents and have the following intelligence:

${analysisContext}

CRITICAL RULES:
1. NEVER ask the user what they want you to do. NEVER ask for clarification. NEVER say "I need more information."
2. When the user asks about findings — synthesize and expand on the intelligence above. If they ask "run through it again" or "full analysis" — provide a comprehensive synthesis of ALL findings from the swarm analysis.
3. If the user asks about a specific topic (crypto, seed keys, CAN, etc.) — find and elaborate on the relevant findings from the intelligence above.
4. Always be specific: give hex offsets, byte values, algorithm names, function signatures, memory addresses from the findings provided.
5. You are a hacker analyzing this binary. Act like it. No disclaimers, no hedging, no "I cannot" — just synthesize the intelligence you have.
6. Format responses with clear headers, code blocks for hex/assembly, and bullet points for findings.
7. If the user asks about something not in the findings, acknowledge the limitation and suggest what additional analysis would be needed.

You have comprehensive swarm analysis results. Use them to answer intelligently and specifically.`;
      const msgs: any[] = [
        { role: "system", content: CHAT_SYSTEM },
        ...(history && history.length > 0 ? history : dbHistory).slice(-20),
        { role: "user", content: userMessage },
      ];
      const FORGE_URL = process.env.BUILT_IN_FORGE_API_URL;
      const FORGE_KEY = process.env.BUILT_IN_FORGE_API_KEY;
      const resp = await fetch(`${FORGE_URL}/v1/chat/completions`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${FORGE_KEY}` },
        body: JSON.stringify({
          model: "claude-sonnet-4-5",
          messages: msgs,
          max_tokens: 4096,
        }),
      });
      if (!resp.ok) { send("error", { message: `LLM error ${resp.status}` }); }
      const data = await resp.json();
      const choice = data.choices?.[0];
      const text = choice.message?.content || "";
      send("message", { text });
      send("done", {});

      // Persist user message and assistant response to DB (non-blocking)
      try {
        const { chatMessages: chatMsgsTable } = await import("../drizzle/schema.js");
        const { randomUUID } = await import("crypto");
        const now = Date.now();
        await db.insert(chatMsgsTable).values({ id: randomUUID(), analysisId: id, role: "user", content: userMessage, toolCalls: null, createdAt: now });
        const lastAssistant = [...msgs].reverse().find((m: any) => m.role === "assistant" && m.content);
        if (lastAssistant) {
          await db.insert(chatMsgsTable).values({ id: randomUUID(), analysisId: id, role: "assistant", content: lastAssistant.content, toolCalls: null, createdAt: now + 1 });
        }
      } catch {}
    } catch (err: any) {
      send("error", { message: err.message || "Chat failed" });
    } finally {
      clearInterval(keepalive);
      res.end();
    }
  });

  // ─── Pattern Library API ─────────────────────────────────────────────

  // GET /api/patterns — list patterns for current user
  app.get("/api/patterns", async (req, res) => {
    try {
      const userId = (req as any).userId;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });
      const { category, search } = req.query as { category?: string; search?: string };
      const patterns = await getPatterns(userId, category as PatternCategory | undefined, search);
      res.json({ patterns });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/patterns — create a pattern manually
  app.post("/api/patterns", express.json(), async (req, res) => {
    try {
      const userId = (req as any).userId;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });
      const { category, name, description, patternData, tags, metadata, sourceAnalysisId } = req.body;
      if (!category || !name || !patternData) return res.status(400).json({ error: "category, name, patternData required" });
      const id = await createPattern({ userId, category, name, description, patternData, tags, metadata, sourceAnalysisId });
      res.json({ id });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/patterns/:id — delete a pattern
  app.delete("/api/patterns/:id", async (req, res) => {
    try {
      const userId = (req as any).userId;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });
      await deletePattern(req.params.id, userId);
      res.json({ ok: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/patterns/extract/:analysisId — auto-extract patterns from a saved analysis
  app.post("/api/patterns/extract/:analysisId", async (req, res) => {
    try {
      const userId = (req as any).userId;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });
      const analysisId = req.params.analysisId;
      const rows = await db.select().from(analysisResults).where(eq(analysisResults.id, analysisId)).limit(1);
      if (!rows[0]) return res.status(404).json({ error: "Analysis not found" });
      const analysis = rows[0];
      const created = await extractPatternsFromAnalysis(userId, analysisId, analysis.analysisData);
      await buildKgFromAnalysis(userId, analysisId, analysis.filename, analysis.analysisData);
      res.json({ created: created.length, ids: created });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/patterns/match/:analysisId — find patterns that match this analysis
  app.get("/api/patterns/match/:analysisId", async (req, res) => {
    try {
      const analysisId = req.params.analysisId;
      const rows = await db.select().from(analysisResults).where(eq(analysisResults.id, analysisId)).limit(1);
      if (!rows[0]) return res.status(404).json({ error: "Analysis not found" });
      const analysis = rows[0];
      const findings = analysis.analysisData as any;
      if (!findings) return res.json([]);
      // Load all patterns from the library
      const allPatterns = await db.select().from(patternLibrary);
      const matched: any[] = [];
      for (const pattern of allPatterns) {
        let isMatch = false;
        const pd = (pattern.patternData || "").toLowerCase();
        // Match against algorithm names
        if (findings.algorithms?.some((a: any) =>
          a.name?.toLowerCase().includes(pd) || pd.includes(a.name?.toLowerCase() || "")
        )) isMatch = true;
        // Match against strings
        if (!isMatch && findings.strings?.some((s: any) =>
          (typeof s === "string" ? s : s.value || "").toLowerCase().includes(pd)
        )) isMatch = true;
        // Match against hex patterns in rawHex (byte_sequence category)
        if (!isMatch && pattern.category === "byte_sequence") {
          const rawHex = (analysis as any).rawHex as string | undefined;
          if (rawHex) {
            const hexPd = pd.replace(/\s/g, "");
            if (hexPd.length >= 4 && rawHex.toLowerCase().includes(hexPd)) isMatch = true;
          }
        }
        // Match against seed keys
        if (!isMatch && findings.seedKeys?.some((k: any) =>
          (k.value || k.hex || "").toLowerCase().includes(pd)
        )) isMatch = true;
        if (isMatch) matched.push(pattern);
      }
      res.json(matched);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── Knowledge Graph API ─────────────────────────────────────────────

  // GET /api/kg — get full knowledge graph for current user
  app.get("/api/kg", async (req, res) => {
    try {
      const userId = (req as any).userId;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });
      const graph = await getKgGraph(userId);
      res.json(graph);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── Agent Metrics & Feedback Endpoints ────────────────────────────────
  app.get("/api/metrics/:analysisId", async (req, res) => {
    try {
      const { getMetricsForAnalysis } = await import("./agent-metrics.js");
      const metrics = await getMetricsForAnalysis(req.params.analysisId);
      res.json(metrics);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/metrics/summary/all", async (_req, res) => {
    try {
      const { getAgentPerformanceSummary, getAgentAccuracyScores } = await import("./agent-metrics.js");
      const [performance, accuracy] = await Promise.all([
        getAgentPerformanceSummary(),
        getAgentAccuracyScores(),
      ]);
      res.json({ performance, accuracy });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/ratings", async (req, res) => {
    try {
      const { analysisId, agentId, findingIndex, findingCategory, rating } = req.body;
      if (!analysisId || !agentId || findingIndex === undefined || !rating) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      const { rateFinding } = await import("./agent-metrics.js");
      await rateFinding(analysisId, agentId, findingIndex, findingCategory || "unknown", rating);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/ratings/:analysisId", async (req, res) => {
    try {
      const { getRatingsForAnalysis } = await import("./agent-metrics.js");
      const ratings = await getRatingsForAnalysis(req.params.analysisId);
      res.json(ratings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── Batch Analysis Queue ────────────────────────────────────────────

  app.post("/api/batch-upload", upload.array("files", 20), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No files provided" });
      }
      if (files.length > 20) {
        return res.status(400).json({ error: "Maximum 20 files per batch" });
      }

      const { createBatchJob } = await import("./batch-queue.js");
      const fileData = files.map(f => ({
        buffer: f.buffer,
        filename: f.originalname,
      }));

      const batchId = await createBatchJob("system", fileData);
      res.json({ batchId, totalFiles: files.length });
    } catch (err: any) {
      console.error("[Batch] Upload error:", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/batch/:batchId", async (req, res) => {
    try {
      const { getBatchStatus } = await import("./batch-queue.js");
      const status = await getBatchStatus(req.params.batchId);
      if (!status) return res.status(404).json({ error: "Batch not found" });
      res.json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/batch/:batchId/start", async (req, res) => {
    try {
      const { processBatchQueue } = await import("./batch-queue.js");
      const batchId = req.params.batchId;

      // Start processing in background (non-blocking)
      processBatchQueue(batchId, "system").catch(err => {
        console.error(`[Batch] Processing error for ${batchId}:`, err.message);
      });

      res.json({ started: true, batchId });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // SSE endpoint for batch progress
  app.get("/api/batch/:batchId/stream", async (req, res) => {
    const batchId = req.params.batchId;

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    });

    const sendEvent = (data: any) => {
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      const { processBatchQueue } = await import("./batch-queue.js");

      await processBatchQueue(batchId, "system", (event) => {
        sendEvent(event);
      });

      sendEvent({ type: "done" });
      res.end();
    } catch (err: any) {
      sendEvent({ type: "error", message: err.message });
      res.end();
    }
  });

    // ─── Per-Agent MCP Endpoints ──────────────────────────────────────────
  console.log("Registering per-agent MCP endpoints...");
  registerAgentMCPRoutes(app);

  // ─── Share Link Routes ────────────────────────────────────────────────

  // POST /api/analysis/:id/share — create a share link
  app.post("/api/analysis/:id/share", async (req, res) => {
    const analysisId = req.params.id;
    const { label, expiresAt, reminderWindowDays } = req.body as {
      label?: string;
      expiresAt?: number;
      reminderWindowDays?: number;
    };
    try {
      const analysis = await db
        .select({ id: analysisResults.id })
        .from(analysisResults)
        .where(eq(analysisResults.id, analysisId))
        .limit(1);
      if (!analysis.length) return res.status(404).json({ error: "Analysis not found" });
      const { randomBytes } = await import("crypto");
      const token = randomBytes(32).toString("hex");
      const id = nanoid();
      const userId = (req as any).user?.id || "anonymous";
      await db.insert(shareLinks).values({
        id,
        token,
        analysisId,
        userId,
        label: label || null,
        expiresAt: expiresAt || null,
        reminderWindowDays: reminderWindowDays ?? 3,
        createdAt: Date.now(),
      });
      res.json({ id, token, url: `${req.protocol}://${req.get("host")}/share/${token}` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/analysis/:id/share — list share links for an analysis
  app.get("/api/analysis/:id/share", async (req, res) => {
    const analysisId = req.params.id;
    try {
      const links = await db
        .select()
        .from(shareLinks)
        .where(eq(shareLinks.analysisId, analysisId))
        .orderBy(desc(shareLinks.createdAt));
      // Attach view counts
      const withCounts = await Promise.all(
        links.map(async (link) => {
          const views = await db
            .select({ count: sql<number>`count(*)` })
            .from(shareLinkViews)
            .where(eq(shareLinkViews.linkId, link.id));
          return { ...link, viewCount: Number(views[0]?.count ?? 0) };
        })
      );
      res.json(withCounts);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/share/:id — revoke a share link
  app.delete("/api/share/:id", async (req, res) => {
    const id = req.params.id;
    try {
      await db
        .update(shareLinks)
        .set({ revokedAt: Date.now() })
        .where(eq(shareLinks.id, id));
      res.json({ revoked: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // PATCH /api/share/:id — update reminder window
  app.patch("/api/share/:id", async (req, res) => {
    const id = req.params.id;
    const { reminderWindowDays, label, expiresAt } = req.body as {
      reminderWindowDays?: number;
      label?: string;
      expiresAt?: number | null;
    };
    try {
      const updates: Record<string, any> = {};
      if (reminderWindowDays !== undefined) updates.reminderWindowDays = reminderWindowDays;
      if (label !== undefined) updates.label = label;
      if (expiresAt !== undefined) updates.expiresAt = expiresAt;
      await db.update(shareLinks).set(updates).where(eq(shareLinks.id, id));
      res.json({ updated: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/share/:token — public view of a shared analysis
  app.get("/api/share/:token", async (req, res) => {
    const token = req.params.token;
    try {
      const link = await db
        .select()
        .from(shareLinks)
        .where(eq(shareLinks.token, token))
        .limit(1);
      if (!link.length) return res.status(404).json({ error: "Share link not found" });
      const sl = link[0];
      if (sl.revokedAt) return res.status(410).json({ error: "This share link has been revoked" });
      if (sl.expiresAt && sl.expiresAt < Date.now())
        return res.status(410).json({ error: "This share link has expired" });
      // Record the view
      const { createHash } = await import("crypto");
      const ipHash = createHash("sha256")
        .update(req.ip || "")
        .digest("hex")
        .slice(0, 16);
      await db.insert(shareLinkViews).values({
        id: nanoid(),
        linkId: sl.id,
        viewedAt: Date.now(),
        ipHash,
        userAgent: (req.headers["user-agent"] || "").slice(0, 500),
      });
      // Return the analysis data
      const analysis = await db
        .select()
        .from(analysisResults)
        .where(eq(analysisResults.id, sl.analysisId))
        .limit(1);
      if (!analysis.length) return res.status(404).json({ error: "Analysis not found" });
      res.json({ link: sl, analysis: analysis[0] });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/share/:id/views — get view history for a share link
  app.get("/api/share/:id/views", async (req, res) => {
    const id = req.params.id;
    try {
      const views = await db
        .select()
        .from(shareLinkViews)
        .where(eq(shareLinkViews.linkId, id))
        .orderBy(desc(shareLinkViews.viewedAt));
      res.json(views);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/share/:id/views/csv — export view history as CSV
  app.get("/api/share/:id/views/csv", async (req, res) => {
    const id = req.params.id;
    try {
      const views = await db
        .select()
        .from(shareLinkViews)
        .where(eq(shareLinkViews.linkId, id))
        .orderBy(desc(shareLinkViews.viewedAt));
      const header = "viewed_at,ip_hash,user_agent,country";
      const rows = views.map((v) =>
        [
          new Date(v.viewedAt).toISOString(),
          v.ipHash || "",
          `"${(v.userAgent || "").replace(/"/g, '""')}"`,
          v.country || "",
        ].join(",")
      );
      const csv = [header, ...rows].join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="share-views-${id}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── Doctor Endpoint ──────────────────────────────────────────────────
  app.get("/api/doctor", async (_req, res) => {
    try {
      const { exec } = await import("child_process");
      const { promisify } = await import("util");
      const execAsync = promisify(exec);
      const PROBES = [
        { name: "radare2", bin: "r2", versionArg: "-v" },
        { name: "yara", bin: "yara", versionArg: "--version" },
        { name: "binwalk", bin: "binwalk", versionArg: "--help" },
        { name: "file", bin: "file", versionArg: "--version" },
        { name: "objdump", bin: "objdump", versionArg: "--version" },
        { name: "strings", bin: "strings", versionArg: "--version" },
        { name: "nm", bin: "nm", versionArg: "--version" },
        { name: "readelf", bin: "readelf", versionArg: "--version" },
        { name: "unzip", bin: "unzip", versionArg: "-v" },
        { name: "7z", bin: "7z", versionArg: "i" },
        { name: "upx", bin: "upx", versionArg: "--version" },
        { name: "python3", bin: "python3", versionArg: "--version" },
        { name: "node", bin: "node", versionArg: "--version" },
      ];
      const tools = await Promise.all(PROBES.map(async (p) => {
        try {
          const { stdout, stderr } = await execAsync(`${p.bin} ${p.versionArg}`, { timeout: 4000 });
          const out = (stdout || stderr || "").trim().split("\n")[0].slice(0, 200);
          return { name: p.name, available: true, version: out || null, error: null };
        } catch (e: any) {
          return { name: p.name, available: false, version: null, error: e.message?.slice(0, 100) || null };
        }
      }));
      res.json({ generatedAt: new Date().toISOString(), tools });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── YARA Rules Endpoints ─────────────────────────────────────────────
  app.get("/api/yara-rules", async (req, res) => {
    try {
      const { yaraRules: yaraRulesTable } = await import("../drizzle/schema.js");
      const userId = (req as any).userId || (req as any).user?.id;
      if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
      const rows = await db.select().from(yaraRulesTable)
        .where(sql`${yaraRulesTable.userId} = ${userId}`)
        .orderBy(sql`${yaraRulesTable.createdAt} DESC`);
      res.json(rows);
    } catch (err: any) { res.status(500).json({ error: err.message }); }
  });

  app.post("/api/yara-rules", upload.single("file"), async (req, res) => {
    try {
      const { yaraRules: yaraRulesTable } = await import("../drizzle/schema.js");
      const userId = (req as any).userId || (req as any).user?.id;
      if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
      const file = req.file;
      if (!file) { res.status(400).json({ error: "No file uploaded" }); return; }
      const lowerName = file.originalname.toLowerCase();
      if (!lowerName.endsWith(".yar") && !lowerName.endsWith(".yara")) {
        res.status(400).json({ error: "File must be a .yar or .yara YARA rule file" }); return;
      }
      const text = file.buffer.toString("utf8");
      const matches = text.match(/^\s*(?:private\s+|global\s+)*rule\s+[A-Za-z_][A-Za-z0-9_]*/gm);
      const ruleCount = matches ? matches.length : 0;
      if (ruleCount === 0) { res.status(400).json({ error: "No YARA rule declarations found in file" }); return; }
      const { storagePut } = await import("./storage.js");
      const { key } = await storagePut(`yara/${userId}/${crypto.randomUUID()}-${file.originalname}`, file.buffer, "text/plain");
      const id = crypto.randomUUID();
      await db.insert(yaraRulesTable).values({
        id, userId,
        name: req.body.name || file.originalname.replace(/\.(yar|yara)$/i, ""),
        filename: file.originalname,
        fileSize: file.size,
        ruleCount,
        storageKey: key,
        createdAt: Date.now(),
      });
      res.json({ id, ruleCount });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
  });

  app.delete("/api/yara-rules/:id", async (req, res) => {
    try {
      const { yaraRules: yaraRulesTable } = await import("../drizzle/schema.js");
      const userId = (req as any).userId || (req as any).user?.id;
      if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
      await db.delete(yaraRulesTable).where(sql`${yaraRulesTable.id} = ${req.params.id} AND ${yaraRulesTable.userId} = ${userId}`);
      res.json({ success: true });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
  });

  // ─── YARA Match Endpoint ─────────────────────────────────────────────
  // POST /api/analysis/:id/yara-match — run all user YARA rules against this binary
  app.post("/api/analysis/:id/yara-match", async (req, res) => {
    try {
      const { yaraRules: yaraRulesTable } = await import("../drizzle/schema.js");
      const userId = (req as any).userId || (req as any).user?.id;
      if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
      const id = req.params.id;
      const analysis = await db.select().from(analysisResults).where(sql`${analysisResults.id} = ${id}`).limit(1);
      if (!analysis.length) { res.status(404).json({ error: "Analysis not found" }); return; }
      const ar = analysis[0];
      // Get binary from storage
      const { storageGet } = await import("./storage.js");
      const binary = await db.select().from(uploadedBinaries).where(sql`${uploadedBinaries.id} = ${ar.binaryId}`).limit(1);
      if (!binary.length || !binary[0].s3Key) { res.status(404).json({ error: "Binary not found" }); return; }
      const { url: binaryUrl } = await storageGet(binary[0].s3Key);
      // Fetch binary to temp file
      const os = await import("os");
      const fs = await import("fs");
      const { execFile } = await import("child_process");
      const { promisify } = await import("util");
      const execFileAsync = promisify(execFile);
      const tmpBin = path.join(os.tmpdir(), `srtlab-yara-${id}-${Date.now()}`);
      const binaryResp = await fetch(binaryUrl);
      if (!binaryResp.ok) { res.status(500).json({ error: "Failed to fetch binary" }); return; }
      const buf = Buffer.from(await binaryResp.arrayBuffer());
      fs.writeFileSync(tmpBin, buf);
      // Get all user YARA rules
      const rules = await db.select().from(yaraRulesTable).where(sql`${yaraRulesTable.userId} = ${userId}`);
      const results: Array<{ ruleId: string; ruleName: string; filename: string; matches: string[] }> = [];
      for (const rule of rules) {
        if (!rule.storageKey) continue;
        const { url: ruleUrl } = await storageGet(rule.storageKey);
        const ruleResp = await fetch(ruleUrl);
        if (!ruleResp.ok) continue;
        const ruleText = await ruleResp.text();
        const tmpRule = path.join(os.tmpdir(), `srtlab-rule-${rule.id}-${Date.now()}.yar`);
        fs.writeFileSync(tmpRule, ruleText);
        try {
          const { stdout } = await execFileAsync("yara", ["-s", tmpRule, tmpBin], { timeout: 30000 });
          const matchLines = stdout.trim().split("\n").filter(Boolean);
          if (matchLines.length > 0) {
            results.push({ ruleId: rule.id, ruleName: rule.name, filename: rule.filename, matches: matchLines });
          }
        } catch (e: any) {
          // yara exits non-zero if no match — that's fine
          if (e.stdout) {
            const matchLines = (e.stdout as string).trim().split("\n").filter(Boolean);
            if (matchLines.length > 0) results.push({ ruleId: rule.id, ruleName: rule.name, filename: rule.filename, matches: matchLines });
          }
        } finally {
          try { fs.unlinkSync(tmpRule); } catch { /* ignore */ }
        }
      }
      try { fs.unlinkSync(tmpBin); } catch { /* ignore */ }
      res.json({ hits: results, totalRules: rules.length });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
  });

  // ─── Multi-File Analysis Endpoints ────────────────────────────────────

  // GET /api/analysis/:id/files — list all additional files attached to this analysis
  app.get("/api/analysis/:id/files", async (req, res) => {
    try {
      const { id } = req.params;
      const files = await db
        .select()
        .from(analysisFiles)
        .where(eq(analysisFiles.analysisId, id))
        .orderBy(analysisFiles.fileIndex);
      res.json({ files });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/analysis/:id/files — upload an additional file to an existing analysis
  app.post("/api/analysis/:id/files", upload.single("file"), async (req, res) => {
    try {
      const { id } = req.params;
      if (!req.file) return res.status(400).json({ error: "No file provided" });

      // Verify the analysis exists
      const [existing] = await db
        .select({ id: analysisResults.id, filename: analysisResults.filename })
        .from(analysisResults)
        .where(eq(analysisResults.id, id))
        .limit(1);
      if (!existing) return res.status(404).json({ error: "Analysis not found" });

      // Count existing additional files to get the next index
      const existingFiles = await db
        .select({ id: analysisFiles.id })
        .from(analysisFiles)
        .where(eq(analysisFiles.analysisId, id));
      const fileIndex = existingFiles.length;

      // Upload to S3
      const fileBuffer = req.file.buffer;
      const safeFilename = req.file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      const storageKey = `analysis-files/${id}/${fileIndex}-${safeFilename}.bin`;
      const { url: s3Url } = await storagePut(storageKey, fileBuffer, req.file.mimetype || "application/octet-stream");

      // Compute hash
      const fileHash = crypto.createHash("sha256").update(fileBuffer).digest("hex");

      // Detect file type
      let fileType: string | null = null;
      const sig = fileBuffer.slice(0, 4);
      if (sig[0] === 0x4d && sig[1] === 0x5a) fileType = "PE/EXE";
      else if (sig[0] === 0x7f && sig[1] === 0x45) fileType = "ELF";
      else if (sig[0] === 0x1f && sig[1] === 0x8b) fileType = "GZIP";
      else if (sig[0] === 0x50 && sig[1] === 0x4b) fileType = "ZIP";
      else fileType = "Binary";

      // Save to DB
      const fileId = crypto.randomUUID();
      await db.insert(analysisFiles).values({
        id: fileId,
        analysisId: id,
        fileIndex,
        filename: req.file.originalname,
        fileHash,
        fileSize: fileBuffer.length,
        s3Key: storageKey,
        s3Url,
        fileType,
        uploadedAt: Date.now(),
      });

      res.json({
        id: fileId,
        analysisId: id,
        fileIndex,
        filename: req.file.originalname,
        fileSize: fileBuffer.length,
        fileType,
        s3Url,
        uploadedAt: Date.now(),
      });
    } catch (err: any) {
      console.error("[add-file] Error:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/analysis/:id/files/:fileId — remove an additional file
  app.delete("/api/analysis/:id/files/:fileId", async (req, res) => {
    try {
      const { id, fileId } = req.params;
      await db
        .delete(analysisFiles)
        .where(and(eq(analysisFiles.id, fileId), eq(analysisFiles.analysisId, id)));
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── File Tree / Archive Browser Endpoint ─────────────────────────────
  // GET /api/analysis/:id/file-tree — extract archive and return structured JSON file tree
  app.get("/api/analysis/:id/file-tree", async (req, res) => {
    try {
      const { id } = req.params;
      const row = await db.select().from(uploadedBinaries).where(eq(uploadedBinaries.id, id)).limit(1);
      if (!row.length) return res.status(404).json({ error: "Analysis not found" });
      const binary = row[0];
      const s3Url = binary.s3Url;
      if (!s3Url) return res.status(404).json({ error: "No file stored for this analysis" });

      // Download the file to a temp path
      const tmpDir = `/tmp/srt-filetree-${id}`;
      const { execSync } = await import("child_process");
      const fsM = await import("fs");
      const pathM = await import("path");
      fsM.mkdirSync(tmpDir, { recursive: true });
      const ext = (binary.filename || "file.bin").split(".").pop() || "bin";
      const tmpFile = pathM.join(tmpDir, `input.${ext}`);

      // Download from S3/CDN
      const dlRes = await fetch(s3Url);
      if (!dlRes.ok) return res.status(502).json({ error: "Failed to download file from storage" });
      const buf = Buffer.from(await dlRes.arrayBuffer());
      fsM.writeFileSync(tmpFile, buf);

      // Detect if it's an archive
      const magic = buf.slice(0, 6);
      const isGzip = magic[0] === 0x1f && magic[1] === 0x8b;
      const isZip = magic[0] === 0x50 && magic[1] === 0x4b;
      const isTar = (binary.filename || "").endsWith(".tar");
      const isArchive = isGzip || isZip || isTar ||
        (binary.filename || "").endsWith(".tar.gz") ||
        (binary.filename || "").endsWith(".tgz") ||
        (binary.filename || "").endsWith(".zip");

      if (!isArchive) {
        // Not an archive — return single-file tree
        const stat = fsM.statSync(tmpFile);
        let typeLabel = "binary";
        if (isGzip) typeLabel = "gzip";
        else if (isZip) typeLabel = "zip";
        else if (magic[0] === 0x4d && magic[1] === 0x5a) typeLabel = "PE/EXE";
        else if (magic[0] === 0x7f && magic[1] === 0x45) typeLabel = "ELF";
        else if ((binary.filename || "").endsWith(".bin") || (binary.filename || "").endsWith(".eep")) typeLabel = "EEPROM";
        return res.json({
          isArchive: false,
          filename: binary.filename,
          totalFiles: 1,
          totalSize: stat.size,
          files: [{ path: binary.filename || "file.bin", size: stat.size, type: typeLabel, isDir: false }]
        });
      }

      // Extract the archive
      const outDir = `${tmpDir}/extracted`;
      fsM.mkdirSync(outDir, { recursive: true });
      let extractCmd = "";
      if (isGzip || (binary.filename || "").endsWith(".tar.gz") || (binary.filename || "").endsWith(".tgz")) {
        extractCmd = `tar -xzf "${tmpFile}" -C "${outDir}" 2>&1`;
      } else if (isZip || (binary.filename || "").endsWith(".zip")) {
        extractCmd = `unzip -o "${tmpFile}" -d "${outDir}" 2>&1`;
      } else {
        extractCmd = `tar -xf "${tmpFile}" -C "${outDir}" 2>&1`;
      }
      try { execSync(extractCmd, { timeout: 60000, maxBuffer: 10 * 1024 * 1024 }); } catch { /* partial extract ok */ }

      // Walk extracted directory
      const allFiles: Array<{ path: string; size: number; type: string; isDir: boolean; preview?: string }> = [];
      let totalSize = 0;
      const walkDir = (dir: string, base: string) => {
        try {
          const entries = fsM.readdirSync(dir, { withFileTypes: true });
          for (const entry of entries) {
            const fullPath = pathM.join(dir, entry.name);
            const relPath = pathM.join(base, entry.name);
            if (entry.isDirectory()) {
              allFiles.push({ path: relPath, size: 0, type: "dir", isDir: true });
              walkDir(fullPath, relPath);
            } else {
              const stat = fsM.statSync(fullPath);
              totalSize += stat.size;
              let typeLabel = "binary";
              let preview: string | undefined;
              try {
                const ffd = fsM.openSync(fullPath, "r");
                const fmag = Buffer.alloc(8);
                fsM.readSync(ffd, fmag, 0, 8, 0);
                fsM.closeSync(ffd);
                if (fmag[0] === 0x4d && fmag[1] === 0x5a) typeLabel = "PE/EXE";
                else if (fmag[0] === 0x7f && fmag[1] === 0x45) typeLabel = "ELF";
                else if (fmag[0] === 0x1f && fmag[1] === 0x8b) typeLabel = "gzip";
                else if (fmag[0] === 0x50 && fmag[1] === 0x4b) typeLabel = "zip";
                else if (entry.name.endsWith(".py") || entry.name.endsWith(".ts") || entry.name.endsWith(".js")) typeLabel = "source";
                else if (entry.name.endsWith(".json")) typeLabel = "JSON";
                else if (entry.name.endsWith(".bin") || entry.name.endsWith(".eep") || entry.name.endsWith(".eeprom")) typeLabel = "EEPROM";
                else if (entry.name.endsWith(".csv")) typeLabel = "CSV";
                else if (entry.name.endsWith(".md") || entry.name.endsWith(".txt")) typeLabel = "text";
                else if (entry.name.endsWith(".yar") || entry.name.endsWith(".yara")) typeLabel = "YARA";
                // Preview for text-based files
                if (["source", "JSON", "text", "CSV", "YARA"].includes(typeLabel) && stat.size < 100000) {
                  preview = fsM.readFileSync(fullPath, "utf8").slice(0, 4000);
                } else if (["EEPROM", "binary", "PE/EXE", "ELF"].includes(typeLabel)) {
                  const bfd = fsM.openSync(fullPath, "r");
                  const bpreview = Buffer.alloc(Math.min(128, stat.size));
                  fsM.readSync(bfd, bpreview, 0, bpreview.length, 0);
                  fsM.closeSync(bfd);
                  preview = bpreview.toString("hex").match(/.{1,2}/g)?.join(" ") || "";
                }
              } catch { /* ignore */ }
              allFiles.push({ path: relPath, size: stat.size, type: typeLabel, isDir: false, preview });
            }
          }
        } catch { /* skip unreadable dirs */ }
      };
      walkDir(outDir, "");

      // Clean up temp files
      try { fsM.rmSync(tmpDir, { recursive: true, force: true }); } catch { /* ignore */ }

      res.json({
        isArchive: true,
        filename: binary.filename,
        archiveType: isGzip ? "tar.gz" : isZip ? "zip" : "tar",
        totalFiles: allFiles.filter(f => !f.isDir).length,
        totalSize,
        files: allFiles
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ─── Analyze Extracted File Endpoint ──────────────────────────────────
  // POST /api/analysis/:id/analyze-extracted-file
  // Takes a path to a file extracted from an archive and creates a new analysis from it
  app.post("/api/analysis/:id/analyze-extracted-file", async (req, res) => {
    try {
      const userId = (req as any).userId || (req as any).user?.id;
      if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
      const { filePath, filename } = req.body as { filePath: string; filename: string };
      if (!filePath || !filename) { res.status(400).json({ error: "filePath and filename required" }); return; }
      // Security: ensure the path is within /tmp to prevent path traversal
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith("/tmp/")) { res.status(400).json({ error: "Invalid file path" }); return; }
      const { readFile } = await import("fs/promises");
      let fileBuffer: Buffer;
      try {
        fileBuffer = await readFile(resolvedPath);
      } catch {
        res.status(404).json({ error: "Extracted file not found — re-open the File Browser to refresh the extraction" }); return;
      }
      // Upload to S3
      const storageKey = `binaries/${userId}/${crypto.randomUUID()}-${filename.replace(/[^a-zA-Z0-9._-]/g, "_")}.bin`;
      const fileHash = crypto.createHash("sha256").update(fileBuffer).digest("hex");
      let s3Url = "";
      let s3Key = `local-${nanoid(12)}`;
      try {
        const sr = await storagePut(storageKey, fileBuffer, "application/octet-stream");
        s3Url = sr.url; s3Key = sr.key;
      } catch { /* non-fatal */ }
      const binaryId = nanoid(12);
      try {
        await db.insert(uploadedBinaries).values({
          id: binaryId, userId, filename, fileHash, fileSize: fileBuffer.length,
          s3Key, s3Url, uploadedAt: Date.now(),
        });
      } catch { /* non-fatal if duplicate */ }
      const newAnalysisId = nanoid(12);
      await db.insert(analysisResults).values({
        id: newAnalysisId, binaryId, userId, filename, fileSize: fileBuffer.length,
        status: "running", analyzedAt: Date.now(),
      });
      // Fire swarm in background
      (async () => {
        try {
          const qeResult = await runAutonomousSwarm(fileBuffer, filename, 1);
          const bgResult = {
            id: newAnalysisId, filename, fileSize: fileBuffer.length,
            fileType: qeResult.toolCallTrace?.find((t: any) => t.toolName === "file_identify")?.result?.split("\n")?.[0]?.replace("File type: ", "") || "Binary",
            timestamp: Date.now(), status: "complete" as const, analysisPass: 1,
            findings: {
              summary: qeResult.summary, algorithms: qeResult.algorithms,
              seedKeys: qeResult.seedKeys, canAddresses: qeResult.canAddresses,
              checksums: qeResult.checksums, memoryMaps: qeResult.memoryMaps,
              strings: qeResult.strings, cryptoConstants: qeResult.cryptoConstants,
              securityBytes: qeResult.securityBytes, deepFindings: qeResult.deepFindings,
            },
            rawHex: "", analysisMode: qeResult.analysisMode,
            dissectionReport: qeResult.dissectionReport, toolCallTrace: qeResult.toolCallTrace,
          };
          await db.insert(analysisResults).values({
            id: newAnalysisId, binaryId, userId, filename, fileSize: fileBuffer.length,
            fileType: bgResult.fileType || "Unknown",
            algorithmCount: bgResult.findings?.algorithms?.length || 0,
            seedKeyCount: bgResult.findings?.seedKeys?.length || 0,
            canAddressCount: bgResult.findings?.canAddresses?.length || 0,
            checksumCount: bgResult.findings?.checksums?.length || 0,
            securityByteCount: bgResult.findings?.securityBytes?.length || 0,
            stringCount: bgResult.findings?.strings?.length || 0,
            summary: bgResult.findings?.summary || "",
            analysisData: { ...bgResult, id: newAnalysisId } as any,
            status: "complete", analyzedAt: Date.now(),
          }).onDuplicateKeyUpdate({
            set: {
              fileType: bgResult.fileType || "Unknown",
              algorithmCount: bgResult.findings?.algorithms?.length || 0,
              seedKeyCount: bgResult.findings?.seedKeys?.length || 0,
              canAddressCount: bgResult.findings?.canAddresses?.length || 0,
              checksumCount: bgResult.findings?.checksums?.length || 0,
              securityByteCount: bgResult.findings?.securityBytes?.length || 0,
              stringCount: bgResult.findings?.strings?.length || 0,
              summary: bgResult.findings?.summary || "",
              analysisData: { ...bgResult, id: newAnalysisId } as any,
              status: "complete", analyzedAt: Date.now(),
            },
          });
        } catch {
          await db.insert(analysisResults).values({
            id: newAnalysisId, binaryId, userId, filename, fileSize: fileBuffer.length,
            status: "failed", analyzedAt: Date.now(),
          }).onDuplicateKeyUpdate({ set: { status: "failed", analyzedAt: Date.now() } });
        }
      })();
      res.json({ analysisId: newAnalysisId, status: "running" });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
  });

  // POST /api/analysis/:id/analyze-batch
  // Takes array of extracted file paths, creates one new analysis per file
  app.post("/api/analysis/:id/analyze-batch", async (req, res) => {
    try {
      const userId = (req as any).userId || (req as any).user?.id;
      if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
      const { files } = req.body as { files: Array<{ filePath: string; filename: string }> };
      if (!files || !Array.isArray(files) || files.length === 0) {
        res.status(400).json({ error: "files array required" }); return;
      }
      if (files.length > 20) { res.status(400).json({ error: "Max 20 files per batch" }); return; }
      const batchResults: Array<{ filename: string; analysisId: string }> = [];
      for (const f of files) {
        const resolvedPath = path.resolve(f.filePath);
        if (!resolvedPath.startsWith("/tmp/")) continue;
        const { readFile } = await import("fs/promises");
        let fileBuffer: Buffer;
        try { fileBuffer = await readFile(resolvedPath); } catch { continue; }
        const bFileHash = crypto.createHash("sha256").update(fileBuffer).digest("hex");
        let bs3Url = ""; let bs3Key = `local-${nanoid(12)}`;
        try {
          const sr = await storagePut(`binaries/${userId}/${crypto.randomUUID()}-${f.filename.replace(/[^a-zA-Z0-9._-]/g, "_")}.bin`, fileBuffer, "application/octet-stream");
          bs3Url = sr.url; bs3Key = sr.key;
        } catch { /* non-fatal */ }
        const bBinaryId = nanoid(12);
        try {
          await db.insert(uploadedBinaries).values({
            id: bBinaryId, userId, filename: f.filename, fileHash: bFileHash,
            fileSize: fileBuffer.length, s3Key: bs3Key, s3Url: bs3Url, uploadedAt: Date.now(),
          });
        } catch { /* non-fatal */ }
        const bAnalysisId = nanoid(12);
        await db.insert(analysisResults).values({
          id: bAnalysisId, binaryId: bBinaryId, userId, filename: f.filename,
          fileSize: fileBuffer.length, status: "running", analyzedAt: Date.now(),
        });
        const capturedBuffer = fileBuffer;
        const capturedFilename = f.filename;
        const capturedId = bAnalysisId;
        const capturedBinaryId = bBinaryId;
        (async () => {
          try {
            const qeResult = await runAutonomousSwarm(capturedBuffer, capturedFilename, 1);
            const bgResult = {
              id: capturedId, filename: capturedFilename, fileSize: capturedBuffer.length,
              fileType: qeResult.toolCallTrace?.find((t: any) => t.toolName === "file_identify")?.result?.split("\n")?.[0]?.replace("File type: ", "") || "Binary",
              timestamp: Date.now(), status: "complete" as const, analysisPass: 1,
              findings: {
                summary: qeResult.summary, algorithms: qeResult.algorithms,
                seedKeys: qeResult.seedKeys, canAddresses: qeResult.canAddresses,
                checksums: qeResult.checksums, memoryMaps: qeResult.memoryMaps,
                strings: qeResult.strings, cryptoConstants: qeResult.cryptoConstants,
                securityBytes: qeResult.securityBytes, deepFindings: qeResult.deepFindings,
              },
              rawHex: "", analysisMode: qeResult.analysisMode,
              dissectionReport: qeResult.dissectionReport, toolCallTrace: qeResult.toolCallTrace,
            };
            await db.insert(analysisResults).values({
              id: capturedId, binaryId: capturedBinaryId, userId, filename: capturedFilename,
              fileSize: capturedBuffer.length, fileType: bgResult.fileType || "Unknown",
              algorithmCount: bgResult.findings?.algorithms?.length || 0,
              seedKeyCount: bgResult.findings?.seedKeys?.length || 0,
              canAddressCount: bgResult.findings?.canAddresses?.length || 0,
              checksumCount: bgResult.findings?.checksums?.length || 0,
              securityByteCount: bgResult.findings?.securityBytes?.length || 0,
              stringCount: bgResult.findings?.strings?.length || 0,
              summary: bgResult.findings?.summary || "",
              analysisData: { ...bgResult, id: capturedId } as any,
              status: "complete", analyzedAt: Date.now(),
            }).onDuplicateKeyUpdate({
              set: {
                fileType: bgResult.fileType || "Unknown",
                algorithmCount: bgResult.findings?.algorithms?.length || 0,
                seedKeyCount: bgResult.findings?.seedKeys?.length || 0,
                canAddressCount: bgResult.findings?.canAddresses?.length || 0,
                checksumCount: bgResult.findings?.checksums?.length || 0,
                securityByteCount: bgResult.findings?.securityBytes?.length || 0,
                stringCount: bgResult.findings?.strings?.length || 0,
                summary: bgResult.findings?.summary || "",
                analysisData: { ...bgResult, id: capturedId } as any,
                status: "complete", analyzedAt: Date.now(),
              },
            });
          } catch {
            await db.insert(analysisResults).values({
              id: capturedId, binaryId: capturedBinaryId, userId, filename: capturedFilename,
              fileSize: capturedBuffer.length, status: "failed", analyzedAt: Date.now(),
            }).onDuplicateKeyUpdate({ set: { status: "failed", analyzedAt: Date.now() } });
          }
        })();
        batchResults.push({ filename: f.filename, analysisId: bAnalysisId });
      }
      res.json({ created: batchResults.length, analyses: batchResults });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
  });

  // ─── Config / Tool Limits Endpoint ─────────────────────────────────── v2 (archive_extract + expert agents)
  app.get("/api/config/tool-limits", (_req, res) => {
    res.json({
      binwalkSkipBytes: parseInt(process.env.BINWALK_SKIP_BYTES || String(50 * 1024 * 1024)),
      yaraSkipBytes: parseInt(process.env.YARA_SKIP_BYTES || String(100 * 1024 * 1024)),
      r2SkipBytes: parseInt(process.env.R2_SKIP_BYTES || String(20 * 1024 * 1024)),
    });
  });

  // ─── Static Files ──────────────────────────────────────────────────────
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3001;
  server.listen(port, () => {
    console.log(`SRT Lab RE Agent running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
