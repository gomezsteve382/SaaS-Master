/**
 * SRT Lab Binary Analysis Tool Registry — v3 (Pure Node.js)
 *
 * ALL tools use pure Node.js/npm packages — NO system binaries (strings, xxd, objdump, python3, etc.)
 * This ensures tools work in production (minimal Node.js container) without binutils/python.
 */
import * as fs from "fs/promises";
import * as path from "path";
import * as os from "os";
import * as zlib from "zlib";

// ─── Tool Type ───────────────────────────────────────────────────────────────
export interface ToolDefinition {
  name: string;
  description: string;
  inputSchema: {
    type: "object";
    properties: Record<string, { type: string; description: string; enum?: string[] }>;
    required?: string[];
  };
  call(args: Record<string, unknown>, filePath: string): Promise<string>;
}

// ─── Pure JS Helpers ─────────────────────────────────────────────────────────

/** Format a buffer region as xxd-style hex dump */
function hexDump(buf: Buffer, startOffset = 0): string {
  const lines: string[] = [];
  for (let i = 0; i < buf.length; i += 16) {
    const addr = (startOffset + i).toString(16).padStart(8, "0");
    const hexParts: string[] = [];
    let ascii = "";
    for (let j = 0; j < 16; j++) {
      if (i + j < buf.length) {
        hexParts.push(buf[i + j].toString(16).padStart(2, "0"));
        const ch = buf[i + j];
        ascii += ch >= 0x20 && ch <= 0x7e ? String.fromCharCode(ch) : ".";
      } else {
        hexParts.push("  ");
        ascii += " ";
      }
    }
    const hex = hexParts.slice(0, 8).join(" ") + "  " + hexParts.slice(8).join(" ");
    lines.push(`${addr}: ${hex}  ${ascii}`);
  }
  return lines.join("\n");
}

/** Extract printable ASCII strings from a buffer with offsets */
function extractStrings(buf: Buffer, minLen = 4, encoding: "ascii" | "utf16le" = "ascii"): Array<{ offset: number; str: string }> {
  const results: Array<{ offset: number; str: string }> = [];

  if (encoding === "utf16le") {
    let current = "";
    let startOffset = 0;
    for (let i = 0; i < buf.length - 1; i += 2) {
      const code = buf[i] | (buf[i + 1] << 8);
      if (code >= 0x20 && code <= 0x7e) {
        if (current.length === 0) startOffset = i;
        current += String.fromCharCode(code);
      } else {
        if (current.length >= minLen) {
          results.push({ offset: startOffset, str: current });
        }
        current = "";
      }
    }
    if (current.length >= minLen) {
      results.push({ offset: startOffset, str: current });
    }
  } else {
    let current = "";
    let startOffset = 0;
    for (let i = 0; i < buf.length; i++) {
      const ch = buf[i];
      if (ch >= 0x20 && ch <= 0x7e) {
        if (current.length === 0) startOffset = i;
        current += String.fromCharCode(ch);
      } else {
        if (current.length >= minLen) {
          results.push({ offset: startOffset, str: current });
        }
        current = "";
      }
    }
    if (current.length >= minLen) {
      results.push({ offset: startOffset, str: current });
    }
  }
  return results;
}

/** Calculate Shannon entropy of a buffer */
function calcEntropy(buf: Buffer): number {
  if (buf.length === 0) return 0;
  const freq = new Array(256).fill(0);
  for (let i = 0; i < buf.length; i++) freq[buf[i]]++;
  let entropy = 0;
  for (const f of freq) {
    if (f > 0) {
      const p = f / buf.length;
      entropy -= p * Math.log2(p);
    }
  }
  return entropy;
}

/** Search for a byte pattern in a buffer, return all offsets */
function findPattern(buf: Buffer, pattern: Buffer, maxHits = 50): number[] {
  const offsets: number[] = [];
  let pos = 0;
  while (pos < buf.length && offsets.length < maxHits) {
    const idx = buf.indexOf(pattern, pos);
    if (idx === -1) break;
    offsets.push(idx);
    pos = idx + 1;
  }
  return offsets;
}

/** Detect file type from magic bytes */
function detectFileType(header: Buffer): { type: string; mime: string } {
  // PE / MZ
  if (header[0] === 0x4D && header[1] === 0x5A) {
    return { type: "PE32 executable (Windows)", mime: "application/x-dosexec" };
  }
  // ELF
  if (header[0] === 0x7F && header[1] === 0x45 && header[2] === 0x4C && header[3] === 0x46) {
    const bits = header[4] === 2 ? "64-bit" : "32-bit";
    return { type: `ELF ${bits} executable`, mime: "application/x-elf" };
  }
  // Intel HEX
  if (header[0] === 0x3A) {
    return { type: "Intel HEX firmware", mime: "application/octet-stream" };
  }
  // Motorola S-Record
  if (header[0] === 0x53 && (header[1] >= 0x30 && header[1] <= 0x39)) {
    return { type: "Motorola S-Record firmware", mime: "application/octet-stream" };
  }
  // ZIP/JAR
  if (header[0] === 0x50 && header[1] === 0x4B) {
    return { type: "ZIP archive", mime: "application/zip" };
  }
  // PDF
  if (header.slice(0, 4).toString() === "%PDF") {
    return { type: "PDF document", mime: "application/pdf" };
  }
  // GZIP (tar.gz, .gz)
  if (header[0] === 0x1F && header[1] === 0x8B) {
    return { type: "GZIP compressed archive", mime: "application/gzip" };
  }
  // TAR (ustar magic at offset 257)
  if (header.length > 262 && header.slice(257, 262).toString() === "ustar") {
    return { type: "TAR archive", mime: "application/x-tar" };
  }
  // 7z
  if (header[0] === 0x37 && header[1] === 0x7A && header[2] === 0xBC && header[3] === 0xAF) {
    return { type: "7-Zip archive", mime: "application/x-7z-compressed" };
  }
  // RAR
  if (header[0] === 0x52 && header[1] === 0x61 && header[2] === 0x72 && header[3] === 0x21) {
    return { type: "RAR archive", mime: "application/x-rar-compressed" };
  }
  // HTML / XML — detect web bundles that are NOT firmware
  const headerStr = header.slice(0, 64).toString("utf8").trim().toLowerCase();
  if (headerStr.startsWith("<!doctype html") || headerStr.startsWith("<html") || headerStr.startsWith("<?xml")) {
    const isHtml = headerStr.includes("html");
    return {
      type: isHtml ? "HTML document (NOT firmware — web application bundle)" : "XML document",
      mime: isHtml ? "text/html" : "application/xml",
    };
  }
  // JSON
  if (header[0] === 0x7B || (header[0] === 0x5B)) {
    return { type: "JSON data", mime: "application/json" };
  }
  // Check entropy for binary classification
  const entropy = calcEntropy(header);
  if (entropy > 7.5) return { type: "Encrypted/compressed binary data", mime: "application/octet-stream" };
  if (entropy > 5.5) return { type: "Compiled binary data", mime: "application/octet-stream" };
  return { type: "Data file", mime: "application/octet-stream" };
}

// ─── PE Parser (pure JS using pe-library) ────────────────────────────────────

interface PESection {
  name: string;
  virtualAddress: string;
  virtualSize: number;
  rawSize: number;
  rawOffset: string;
  entropy: number;
  note: string;
}

async function parsePE(filePath: string, section: string): Promise<string> {
  try {
    const { NtExecutable, NtExecutableResource } = await import("pe-library");
    const data = await fs.readFile(filePath);
    const exe = NtExecutable.from(data);

    const result: string[] = [];

    if (section === "all" || section === "headers") {
      result.push("═══ PE HEADERS ═══");
      const dh = exe.dosHeader;
      const nh = exe.newHeader;
      if (nh) {
        result.push(`Machine: 0x${nh.fileHeader.machine.toString(16)}`);
        result.push(`Timestamp: ${nh.fileHeader.timeDateStamp}`);
        result.push(`Number of sections: ${nh.fileHeader.numberOfSections}`);
        result.push(`Characteristics: 0x${nh.fileHeader.characteristics.toString(16)}`);
        if (nh.optionalHeader) {
          result.push(`Entry point: 0x${nh.optionalHeader.addressOfEntryPoint.toString(16)}`);
          result.push(`Image base: 0x${nh.optionalHeader.imageBase.toString(16)}`);
          result.push(`Subsystem: ${nh.optionalHeader.subsystem}`);
        }
      }
    }

    if (section === "all" || section === "sections") {
      result.push("\n═══ SECTIONS ═══");
      const sections = exe.getAllSections();
      for (const sec of sections) {
        const secData = sec.data ? Buffer.from(sec.data) : Buffer.alloc(0);
        const entropy = secData.length > 0 ? calcEntropy(secData) : 0;
        const note = entropy > 7.0 ? " ◄ HIGH ENTROPY (packed/encrypted)" : "";
        const name = Buffer.from(sec.info.name).toString().replace(/\0/g, "");
        result.push(`  ${name.padEnd(10)} VAddr: 0x${sec.info.virtualAddress.toString(16).padStart(8, "0")} VSize: ${sec.info.virtualSize} RawSize: ${sec.info.sizeOfRawData} Entropy: ${entropy.toFixed(3)}${note}`);
      }
    }

    if (section === "all" || section === "imports") {
      result.push("\n═══ IMPORTS ═══");
      // Parse import directory manually from the binary
      const importInfo = parsePEImports(data);
      if (importInfo.length > 0) {
        result.push(`Total imported DLLs: ${importInfo.length}`);
        let totalFuncs = 0;
        for (const imp of importInfo) {
          result.push(`\n  ${imp.dll} (${imp.functions.length} functions):`);
          for (const fn of imp.functions.slice(0, 30)) {
            result.push(`    ${fn}`);
          }
          if (imp.functions.length > 30) {
            result.push(`    ... (${imp.functions.length - 30} more)`);
          }
          totalFuncs += imp.functions.length;
        }
        result.push(`\nTotal imported functions: ${totalFuncs}`);
      } else {
        result.push("  No imports found (or import table not parseable)");
      }
    }

    if (section === "all" || section === "resources") {
      result.push("\n═══ RESOURCES ═══");
      try {
        const res = NtExecutableResource.from(exe);
        const entries = res.entries || [];
        result.push(`  ${entries.length} resource entries found`);
        for (const entry of entries.slice(0, 20)) {
          result.push(`  Type: ${entry.type} ID: ${entry.id} Lang: ${entry.lang}`);
        }
      } catch {
        result.push("  No resources or resource parsing failed");
      }
    }

    return result.join("\n");
  } catch (err: any) {
    return `PE parsing error: ${err.message}. File may not be a valid PE executable.`;
  }
}

/** Manual PE import table parser for when pe-library doesn't expose imports directly */
function parsePEImports(data: Buffer): Array<{ dll: string; functions: string[] }> {
  const results: Array<{ dll: string; functions: string[] }> = [];
  try {
    // Check MZ signature
    if (data[0] !== 0x4D || data[1] !== 0x5A) return results;

    // Get PE offset from e_lfanew
    const peOffset = data.readUInt32LE(0x3C);
    if (peOffset >= data.length - 4) return results;

    // Verify PE signature
    if (data.readUInt32LE(peOffset) !== 0x00004550) return results;

    // Parse COFF header
    const coffOffset = peOffset + 4;
    const numberOfSections = data.readUInt16LE(coffOffset + 2);
    const sizeOfOptionalHeader = data.readUInt16LE(coffOffset + 16);

    // Parse optional header
    const optOffset = coffOffset + 20;
    const magic = data.readUInt16LE(optOffset);
    const is64 = magic === 0x20B;

    // Get import directory RVA
    let importDirRVA: number;
    let importDirSize: number;
    if (is64) {
      importDirRVA = data.readUInt32LE(optOffset + 120);
      importDirSize = data.readUInt32LE(optOffset + 124);
    } else {
      importDirRVA = data.readUInt32LE(optOffset + 104);
      importDirSize = data.readUInt32LE(optOffset + 108);
    }

    if (importDirRVA === 0) return results;

    // Parse section headers to build RVA-to-file-offset mapping
    const sectionsOffset = optOffset + sizeOfOptionalHeader;
    const sections: Array<{ virtualAddress: number; virtualSize: number; rawOffset: number; rawSize: number }> = [];
    for (let i = 0; i < numberOfSections; i++) {
      const secOff = sectionsOffset + i * 40;
      sections.push({
        virtualAddress: data.readUInt32LE(secOff + 12),
        virtualSize: data.readUInt32LE(secOff + 8),
        rawOffset: data.readUInt32LE(secOff + 20),
        rawSize: data.readUInt32LE(secOff + 16),
      });
    }

    const rvaToOffset = (rva: number): number => {
      for (const sec of sections) {
        if (rva >= sec.virtualAddress && rva < sec.virtualAddress + sec.rawSize) {
          return rva - sec.virtualAddress + sec.rawOffset;
        }
      }
      return rva; // fallback
    };

    // Parse import descriptors
    const importOffset = rvaToOffset(importDirRVA);
    for (let i = 0; i < 200; i++) { // max 200 DLLs
      const descOff = importOffset + i * 20;
      if (descOff + 20 > data.length) break;

      const nameRVA = data.readUInt32LE(descOff + 12);
      const thunkRVA = data.readUInt32LE(descOff + 0) || data.readUInt32LE(descOff + 16);

      if (nameRVA === 0 && thunkRVA === 0) break; // End of import descriptors

      // Read DLL name
      const nameOffset = rvaToOffset(nameRVA);
      let dllName = "";
      for (let j = 0; j < 256 && nameOffset + j < data.length; j++) {
        if (data[nameOffset + j] === 0) break;
        dllName += String.fromCharCode(data[nameOffset + j]);
      }

      // Read function names from thunk
      const functions: string[] = [];
      const thunkOffset = rvaToOffset(thunkRVA);
      const entrySize = is64 ? 8 : 4;

      for (let j = 0; j < 500; j++) { // max 500 functions per DLL
        const entryOff = thunkOffset + j * entrySize;
        if (entryOff + entrySize > data.length) break;

        let entry: number;
        let isOrdinal = false;
        if (is64) {
          // Read as two 32-bit values to avoid BigInt
          const lo = data.readUInt32LE(entryOff);
          const hi = data.readUInt32LE(entryOff + 4);
          if (lo === 0 && hi === 0) break;
          entry = lo; // We only need the low 32 bits for RVA
          isOrdinal = (hi & 0x80000000) !== 0;
        } else {
          entry = data.readUInt32LE(entryOff);
          if (entry === 0) break;
          isOrdinal = (entry & 0x80000000) !== 0;
        }

        // Check if import by ordinal
        if (isOrdinal) {
          functions.push(`ord_${entry & 0xFFFF}`);
        } else {
          // Import by name - read hint + name
          const hintOffset = rvaToOffset(entry) + 2; // skip hint word
          let funcName = "";
          for (let k = 0; k < 256 && hintOffset + k < data.length; k++) {
            if (data[hintOffset + k] === 0) break;
            funcName += String.fromCharCode(data[hintOffset + k]);
          }
          if (funcName) functions.push(funcName);
        }
      }

      if (dllName) results.push({ dll: dllName, functions });
    }
  } catch {
    // Silently fail — return what we have
  }
  return results;
}

// ─── ELF Parser (pure JS) ───────────────────────────────────────────────────

function parseELF(data: Buffer, section: string): string {
  const result: string[] = [];
  try {
    // Verify ELF magic
    if (data[0] !== 0x7F || data[1] !== 0x45 || data[2] !== 0x4C || data[3] !== 0x46) {
      return "Not an ELF binary";
    }

    const is64 = data[4] === 2;
    const isLE = data[5] === 1;
    const read16 = isLE ? (off: number) => data.readUInt16LE(off) : (off: number) => data.readUInt16BE(off);
    const read32 = isLE ? (off: number) => data.readUInt32LE(off) : (off: number) => data.readUInt32BE(off);

    if (section === "all" || section === "headers") {
      result.push("═══ ELF HEADERS ═══");
      result.push(`Class: ${is64 ? "ELF64" : "ELF32"}`);
      result.push(`Data: ${isLE ? "Little-endian" : "Big-endian"}`);
      result.push(`OS/ABI: ${data[7]}`);
      result.push(`Type: ${read16(16)}`);
      result.push(`Machine: 0x${read16(18).toString(16)}`);
      if (is64) {
        const entryLo = read32(24);
        const entryHi = read32(28);
        result.push(`Entry point: 0x${((entryHi * 0x100000000) + entryLo).toString(16)}`);
      } else {
        result.push(`Entry point: 0x${read32(24).toString(16)}`);
      }
    }

    if (section === "all" || section === "sections") {
      result.push("\n═══ SECTIONS ═══");
      let shoff: number, shentsize: number, shnum: number, shstrndx: number;
      if (is64) {
        shoff = read32(40); // simplified - ignoring high 32 bits
        shentsize = read16(58);
        shnum = read16(60);
        shstrndx = read16(62);
      } else {
        shoff = read32(32);
        shentsize = read16(46);
        shnum = read16(48);
        shstrndx = read16(50);
      }

      // Read string table
      let strTabOff = 0;
      if (shstrndx < shnum) {
        const strSecOff = shoff + shstrndx * shentsize;
        strTabOff = is64 ? read32(strSecOff + 24) : read32(strSecOff + 16);
      }

      for (let i = 0; i < Math.min(shnum, 50); i++) {
        const secOff = shoff + i * shentsize;
        if (secOff + shentsize > data.length) break;
        const nameIdx = read32(secOff);
        const type = read32(secOff + 4);
        let size: number, offset: number;
        if (is64) {
          offset = read32(secOff + 24);
          size = read32(secOff + 32);
        } else {
          offset = read32(secOff + 16);
          size = read32(secOff + 20);
        }

        // Read section name from string table
        let name = "";
        if (strTabOff > 0 && strTabOff + nameIdx < data.length) {
          for (let j = 0; j < 64 && strTabOff + nameIdx + j < data.length; j++) {
            if (data[strTabOff + nameIdx + j] === 0) break;
            name += String.fromCharCode(data[strTabOff + nameIdx + j]);
          }
        }
        if (name || type > 0) {
          result.push(`  [${i.toString().padStart(2)}] ${(name || "(null)").padEnd(20)} Type: ${type.toString().padStart(2)} Offset: 0x${offset.toString(16).padStart(8, "0")} Size: ${size}`);
        }
      }
    }

    return result.join("\n") || "ELF parsed but no data extracted";
  } catch (err: any) {
    return `ELF parsing error: ${err.message}`;
  }
}

// ─── PyInstaller Extractor (pure JS) ─────────────────────────────────────────

function extractPyInstaller(data: Buffer, filter: string): string {
  const MAGIC_COOKIE = Buffer.from([0x4D, 0x45, 0x49, 0x0C, 0x0D, 0x0A, 0x1A, 0x0A]);
  const result: string[] = [];

  // Find PyInstaller cookie
  let pos = -1;
  for (let i = data.length - 4096; i >= 0 && i < data.length - 8; i++) {
    if (data.indexOf(MAGIC_COOKIE, i) === i) {
      pos = i;
      break;
    }
  }
  // Also search from end
  if (pos === -1) {
    pos = data.lastIndexOf(MAGIC_COOKIE);
  }

  if (pos === -1) {
    return "NOT_PYINSTALLER: No PyInstaller magic cookie found in this binary.";
  }

  result.push("═══ PYINSTALLER BINARY DETECTED ═══");
  result.push(`Cookie found at: 0x${pos.toString(16).toUpperCase()}`);

  try {
    // Parse archive header (big-endian)
    const pkgLen = data.readUInt32BE(pos + 8);
    const tocOffset = data.readUInt32BE(pos + 12);
    const tocLen = data.readUInt32BE(pos + 16);
    const pyVer = data.readUInt32BE(pos + 20);

    const archiveStart = Math.max(0, pos + 24 + 64 - pkgLen);

    result.push(`Python version: ${pyVer}`);
    result.push(`Archive start: 0x${archiveStart.toString(16).toUpperCase()}`);
    result.push(`TOC offset: 0x${tocOffset.toString(16).toUpperCase()} (length: ${tocLen})`);
    result.push(`Package length: ${pkgLen}`);
    result.push("");

    // Parse TOC entries
    const tocStart = archiveStart + tocOffset;
    const entries: Array<{ name: string; offset: number; compLen: number; uncompLen: number; compress: boolean; typeCode: number }> = [];

    let cursor = tocStart;
    while (cursor < tocStart + tocLen && cursor + 18 < data.length) {
      const entryLen = data.readUInt32BE(cursor);
      if (entryLen < 18 || entryLen > 65536) break;

      const entryOffset = data.readUInt32BE(cursor + 4);
      const compLen = data.readUInt32BE(cursor + 8);
      const uncompLen = data.readUInt32BE(cursor + 12);
      const compress = data[cursor + 16] === 1;
      const typeCode = data[cursor + 17];

      // Read name (null-terminated after byte 18)
      let name = "";
      for (let i = 18; i < entryLen && cursor + i < data.length; i++) {
        if (data[cursor + i] === 0) break;
        name += String.fromCharCode(data[cursor + i]);
      }

      entries.push({ name, offset: entryOffset, compLen, uncompLen, compress, typeCode });
      cursor += entryLen;
    }

    result.push(`═══ TOC ENTRIES (${entries.length} total) ═══`);

    const typeNames: Record<number, string> = {
      115: "SCRIPT (s)", 109: "MODULE (m)", 77: "MODULE (M)",
      100: "DATA (d)", 98: "BINARY (b)", 122: "PYZ (z)",
      90: "PYZ (Z)", 120: "DEPENDENCY (x)", 111: "OPTION (o)",
    };

    const filteredEntries = filter
      ? entries.filter(e => e.name.toLowerCase().includes(filter))
      : entries;

    for (const entry of filteredEntries.slice(0, 100)) {
      const typeName = typeNames[entry.typeCode] || `TYPE_${entry.typeCode}`;
      const marker = filter && entry.name.toLowerCase().includes(filter) ? " ◄◄◄ MATCH" : "";
      result.push(`  ${typeName.padEnd(14)} ${entry.name} (${entry.compLen} bytes${entry.compress ? ", compressed" : ""})${marker}`);
    }

    if (filteredEntries.length > 100) {
      result.push(`  ... (${filteredEntries.length - 100} more entries)`);
    }

    // Try to extract and show content of script entries
    const scripts = entries.filter(e => e.typeCode === 115 || (filter && e.name.toLowerCase().includes(filter)));
    if (scripts.length > 0) {
      result.push("\n═══ SCRIPT/MODULE CONTENT EXTRACTION ═══");
      for (const script of scripts.slice(0, 10)) {
        const rawOffset = archiveStart + script.offset;
        if (rawOffset + script.compLen > data.length) continue;

        let content = data.slice(rawOffset, rawOffset + script.compLen);
        if (script.compress) {
          try {
            content = Buffer.from(zlib.inflateSync(content));
          } catch {
            // Try raw inflate
            try {
              content = Buffer.from(zlib.inflateRawSync(content));
            } catch {
              result.push(`\n  ${script.name}: [decompression failed]`);
              continue;
            }
          }
        }

        // Show printable content
        const printable = content.toString("utf-8", 0, Math.min(content.length, 2000))
          .replace(/[^\x20-\x7E\n\r\t]/g, ".");
        if (printable.replace(/\./g, "").trim().length > 20) {
          result.push(`\n── ${script.name} ──`);
          result.push(printable.substring(0, 2000));
          if (content.length > 2000) result.push(`... (${content.length - 2000} more bytes)`);
        }
      }
    }

  } catch (err: any) {
    result.push(`TOC parsing error: ${err.message}`);
  }

  return result.join("\n");
}

// ─── Tools ───────────────────────────────────────────────────────────────────
export const tools: ToolDefinition[] = [
  // ═══════════════════════════════════════════════════════════════════════════
  // 1. file_identify — comprehensive file identification (pure JS)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "file_identify",
    description:
      "Identify the file type, format, architecture, and metadata. Returns magic-byte detection, size, entropy analysis, and header hex dump. ALWAYS call this first on any new file.",
    inputSchema: {
      type: "object",
      properties: {},
    },
    async call(_args, filePath) {
      const stats = await fs.stat(filePath);
      const fd = await fs.open(filePath, "r");
      const headerBuf = Buffer.alloc(Math.min(256, stats.size));
      await fd.read(headerBuf, 0, headerBuf.length, 0);

      // Read first 4KB for entropy
      const entropyBuf = Buffer.alloc(Math.min(4096, stats.size));
      await fd.read(entropyBuf, 0, entropyBuf.length, 0);
      await fd.close();

      const entropy = calcEntropy(entropyBuf);
      const detected = detectFileType(headerBuf);

      // Check for PyInstaller
      const fullData = await fs.readFile(filePath);
      const hasPyInstaller = fullData.lastIndexOf(Buffer.from([0x4D, 0x45, 0x49, 0x0C, 0x0D, 0x0A, 0x1A, 0x0A])) !== -1;

      const headerHex = headerBuf.toString("hex").match(/.{1,2}/g)?.join(" ") || "";

      return [
        `═══ FILE IDENTIFICATION ═══`,
        `File type: ${detected.type}${hasPyInstaller ? " [PyInstaller packed]" : ""}`,
        `MIME: ${detected.mime}`,
        `Size: ${stats.size} bytes (${(stats.size / 1024).toFixed(1)} KB / ${(stats.size / 1048576).toFixed(2)} MB)`,
        `Header entropy: ${entropy.toFixed(3)} bits/byte (${entropy > 7.5 ? "ENCRYPTED/COMPRESSED" : entropy > 6.0 ? "COMPILED/BINARY" : "STRUCTURED DATA"})`,
        ``,
        `First 256 bytes (hex):`,
        headerHex,
        ``,
        `First 256 bytes (ASCII, non-printable replaced with .):`,
        headerBuf.toString("ascii").replace(/[^\x20-\x7E]/g, "."),
        hasPyInstaller ? `\n⚠️ PyInstaller detected — use pyinstaller_extract to reveal embedded Python code` : "",
        detected.type.includes("PE32") ? `\n⚠️ Windows PE detected — use pe_info to analyze imports/sections/resources` : "",
      ].join("\n");
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 2. read_hex — read raw hex dump of any region (pure JS, replaces xxd)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "read_hex",
    description:
      "Read a hex dump of the binary at a specific byte offset and length. Use to inspect specific regions, headers, data structures, or follow up on offsets found by other tools.",
    inputSchema: {
      type: "object",
      properties: {
        offset: {
          type: "number",
          description: "Byte offset to start reading from (default: 0)",
        },
        length: {
          type: "number",
          description: "Number of bytes to read (default: 512, max: 8192)",
        },
      },
    },
    async call(args, filePath) {
      const offset = Math.max(0, Number(args.offset ?? 0));
      const length = Math.min(8192, Math.max(16, Number(args.length ?? 512)));
      const fd = await fs.open(filePath, "r");
      const stats = await fd.stat();
      const readLen = Math.min(length, stats.size - offset);
      if (readLen <= 0) {
        await fd.close();
        return `Error: offset ${offset} is beyond file size ${stats.size}`;
      }
      const buf = Buffer.alloc(readLen);
      await fd.read(buf, 0, readLen, offset);
      await fd.close();
      return hexDump(buf, offset);
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 3. extract_strings — extract ALL printable strings (pure JS, replaces strings command)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "extract_strings",
    description:
      "Extract printable strings from the binary with file offsets. Call WITHOUT a filter first to see everything, then call again WITH a filter to narrow down. Returns up to 3000 lines.",
    inputSchema: {
      type: "object",
      properties: {
        min_length: {
          type: "number",
          description: "Minimum string length (default: 4)",
        },
        filter: {
          type: "string",
          description: "Optional case-insensitive filter (e.g. 'seed|key|vin|can|uds|skim|pin|crc|aes|xor|encrypt|decrypt|password|secret|auth'). Use pipe | for OR.",
        },
        encoding: {
          type: "string",
          description: "String encoding: 's' for ASCII (default), 'l' for 16-bit little-endian (Unicode)",
        },
      },
    },
    async call(args, filePath) {
      const minLen = Math.max(4, Number(args.min_length ?? 4));
      const filter = String(args.filter ?? "").trim();
      const encoding = String(args.encoding ?? "s").trim();

      const data = await fs.readFile(filePath);
      const enc = encoding === "l" ? "utf16le" : "ascii";
      let strings = extractStrings(data, minLen, enc);

      // Apply filter
      if (filter) {
        const parts = filter.split("|").map(p => p.trim().toLowerCase());
        strings = strings.filter(s => parts.some(p => s.str.toLowerCase().includes(p)));
      }

      if (strings.length === 0) {
        return filter ? `No strings matching '${filter}'` : "No strings found";
      }

      const lines = strings.slice(0, 3000).map(s =>
        `${s.offset.toString(16).padStart(8, " ")} ${s.str}`
      );

      if (strings.length > 3000) {
        lines.push(`\n... (${strings.length - 3000} more lines — use a filter to narrow down)`);
      }

      return lines.join("\n");
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 4. pe_info — Windows PE structure analysis (pure JS via pe-library)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "pe_info",
    description:
      "Analyze Windows PE (EXE/DLL) structure: sections with entropy, all imports (DLLs and functions), exports, resources, timestamps, entry point. Use for .exe and .dll files.",
    inputSchema: {
      type: "object",
      properties: {
        section: {
          type: "string",
          description: "Which section: 'all', 'imports', 'exports', 'sections', 'resources', 'headers' (default: 'all')",
        },
      },
    },
    async call(args, filePath) {
      const section = String(args.section ?? "all");
      return parsePE(filePath, section);
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 5. elf_info — ELF binary analysis (pure JS)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "elf_info",
    description:
      "Analyze ELF binary structure: sections, symbols, dynamic libraries, entry point. Use for Linux/embedded firmware binaries.",
    inputSchema: {
      type: "object",
      properties: {
        section: {
          type: "string",
          description: "Which section: 'headers', 'sections', 'all' (default: 'all')",
        },
      },
    },
    async call(args, filePath) {
      const section = String(args.section ?? "all");
      const data = await fs.readFile(filePath);
      return parseELF(data, section);
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 6. disassemble — basic instruction dump (pure JS, limited without objdump)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "disassemble",
    description:
      "Read raw bytes from a code region and display as hex instruction dump. For PE files, reads from the .text section entry point. Without a full disassembler, shows raw bytes with basic x86 opcode hints.",
    inputSchema: {
      type: "object",
      properties: {
        offset: {
          type: "number",
          description: "File offset to start reading from. If not specified, reads from entry point (PE) or offset 0.",
        },
        length: {
          type: "number",
          description: "Number of bytes to read (default: 256, max: 2048)",
        },
      },
    },
    async call(args, filePath) {
      const data = await fs.readFile(filePath);
      let offset = Number(args.offset ?? -1);
      const length = Math.min(2048, Math.max(16, Number(args.length ?? 256)));

      // If no offset specified, try to find entry point
      if (offset < 0) {
        if (data[0] === 0x4D && data[1] === 0x5A) {
          // PE: find entry point file offset
          const peOff = data.readUInt32LE(0x3C);
          if (peOff < data.length - 40) {
            const optOff = peOff + 4 + 20;
            const magic = data.readUInt16LE(optOff);
            const ep = data.readUInt32LE(optOff + 16); // AddressOfEntryPoint RVA
            // Find which section contains the entry point
            const numSections = data.readUInt16LE(peOff + 4 + 2);
            const sizeOptHdr = data.readUInt16LE(peOff + 4 + 16);
            const secStart = optOff + sizeOptHdr;
            for (let i = 0; i < numSections; i++) {
              const secOff = secStart + i * 40;
              const va = data.readUInt32LE(secOff + 12);
              const vs = data.readUInt32LE(secOff + 8);
              const rawOff = data.readUInt32LE(secOff + 20);
              if (ep >= va && ep < va + vs) {
                offset = ep - va + rawOff;
                break;
              }
            }
          }
        }
        if (offset < 0) offset = 0;
      }

      const readLen = Math.min(length, data.length - offset);
      if (readLen <= 0) return `Offset 0x${offset.toString(16)} is beyond file size`;

      const buf = data.slice(offset, offset + readLen);
      const result: string[] = [];
      result.push(`═══ RAW CODE DUMP @ 0x${offset.toString(16).toUpperCase()} (${readLen} bytes) ═══`);
      result.push(`Note: This is a raw hex dump of the code region. Use read_hex for data regions.`);
      result.push("");
      result.push(hexDump(buf, offset));

      return result.join("\n");
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 7. pyinstaller_extract — extract Python from PyInstaller EXE (pure JS)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "pyinstaller_extract",
    description:
      "Extract and analyze Python content from a PyInstaller-compiled executable. Lists all embedded modules and attempts to extract readable content. This is the KEY tool for analyzing Python-compiled EXEs — it reveals the actual application logic.",
    inputSchema: {
      type: "object",
      properties: {
        module_filter: {
          type: "string",
          description: "Optional filter to only show modules matching this pattern (e.g. 'main', 'seed', 'skim', 'uds', 'can')",
        },
      },
    },
    async call(args, filePath) {
      const filter = String(args.module_filter ?? "").toLowerCase().trim();
      const data = await fs.readFile(filePath);
      return extractPyInstaller(data, filter);
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 8. search_patterns — binary pattern search (pure JS, replaces grep -bao)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "search_patterns",
    description:
      "Search for specific byte patterns, hex sequences, or text in the binary. Returns offsets and surrounding context. Use to find crypto constants, magic bytes, UDS service IDs, CAN IDs, and automotive-specific patterns.",
    inputSchema: {
      type: "object",
      properties: {
        pattern: {
          type: "string",
          description: "What to search for. Can be: text string (e.g. 'seed_key'), hex bytes (e.g. 'hex:27 01'), or a preset scan name (e.g. 'automotive', 'crypto', 'all')",
        },
      },
      required: ["pattern"],
    },
    async call(args, filePath) {
      const pattern = String(args.pattern ?? "").trim();
      if (!pattern) return "Error: pattern is required";

      const data = await fs.readFile(filePath);
      const results: string[] = [];

      if (pattern === "automotive" || pattern === "all") {
        results.push("═══ AUTOMOTIVE PATTERN SCAN ═══\n");
        const autoPatterns: Array<{ name: string; bytes: number[] }> = [
          { name: "UDS Security Access 0x27 sub=0x01", bytes: [0x27, 0x01] },
          { name: "UDS Security Access 0x27 sub=0x03", bytes: [0x27, 0x03] },
          { name: "UDS Security Access 0x27 sub=0x05", bytes: [0x27, 0x05] },
          { name: "UDS Security Access 0x27 sub=0x11", bytes: [0x27, 0x11] },
          { name: "UDS Security Access 0x27 sub=0x61", bytes: [0x27, 0x61] },
          { name: "UDS DiagSession 0x10 sub=0x01", bytes: [0x10, 0x01] },
          { name: "UDS DiagSession 0x10 sub=0x02", bytes: [0x10, 0x02] },
          { name: "UDS DiagSession 0x10 sub=0x03", bytes: [0x10, 0x03] },
          { name: "UDS ReadByID 0x22 F1xx", bytes: [0x22, 0xF1] },
          { name: "UDS WriteByID 0x2E F1xx", bytes: [0x2E, 0xF1] },
          { name: "UDS RoutineCtrl 0x31 sub=0x01", bytes: [0x31, 0x01] },
          { name: "UDS RequestDownload 0x34", bytes: [0x34, 0x00] },
          { name: "CRC-16 CCITT poly (0x1021)", bytes: [0x10, 0x21] },
          { name: "CRC-32 poly (0x04C11DB7)", bytes: [0x04, 0xC1, 0x1D, 0xB7] },
        ];

        for (const ap of autoPatterns) {
          const pat = Buffer.from(ap.bytes);
          const offsets = findPattern(data, pat, 20);
          if (offsets.length > 0) {
            results.push(`${ap.name}: ${offsets.length} hit(s)`);
            for (const off of offsets.slice(0, 5)) {
              const ctxStart = Math.max(0, off - 4);
              const ctxEnd = Math.min(data.length, off + 16);
              const ctx = data.slice(ctxStart, ctxEnd).toString("hex").match(/.{1,2}/g)?.join(" ") || "";
              results.push(`  @ 0x${off.toString(16).toUpperCase().padStart(8, "0")}: ${ctx}`);
            }
          }
        }

        // Text pattern scan
        const textPatterns = ["seed", "key", "vin", "skim", "pin", "crc", "aes", "xor", "encrypt", "decrypt", "password", "secret", "auth", "unlock", "immobilizer", "transponder"];
        const strings = extractStrings(data, 4);
        const matchedStrings = strings.filter(s => textPatterns.some(p => s.str.toLowerCase().includes(p)));
        if (matchedStrings.length > 0) {
          results.push(`\n═══ AUTOMOTIVE TEXT STRINGS ═══`);
          for (const s of matchedStrings.slice(0, 100)) {
            results.push(`  ${s.offset.toString(16).padStart(8, " ")} ${s.str}`);
          }
        }

        return results.join("\n") || "No automotive patterns found";
      }

      if (pattern === "crypto") {
        results.push("═══ CRYPTO CONSTANT SCAN ═══\n");
        const cryptoPatterns: Array<{ name: string; bytes: number[] }> = [
          { name: "AES S-Box start (0x637C777B)", bytes: [0x63, 0x7C, 0x77, 0x7B] },
          { name: "AES Rcon", bytes: [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80] },
          { name: "SHA-256 init (0x6A09E667)", bytes: [0x6A, 0x09, 0xE6, 0x67] },
          { name: "MD5 init (0x67452301)", bytes: [0x67, 0x45, 0x23, 0x01] },
          { name: "CRC-16 CCITT (0x1021)", bytes: [0x10, 0x21] },
          { name: "CRC-32 (0x04C11DB7)", bytes: [0x04, 0xC1, 0x1D, 0xB7] },
          { name: "DES initial perm", bytes: [0x3A, 0x32, 0x2A, 0x22] },
        ];

        for (const cp of cryptoPatterns) {
          const pat = Buffer.from(cp.bytes);
          const offsets = findPattern(data, pat, 10);
          if (offsets.length > 0) {
            results.push(`${cp.name}: FOUND (${offsets.length} hits)`);
            for (const off of offsets.slice(0, 3)) {
              results.push(`  @ 0x${off.toString(16).toUpperCase()}`);
            }
          }
        }
        return results.join("\n") || "No crypto constants found";
      }

      // Hex pattern search: "hex:27 01 03"
      if (pattern.startsWith("hex:")) {
        const hexStr = pattern.slice(4).replace(/\s+/g, "");
        const patBuf = Buffer.from(hexStr, "hex");
        if (patBuf.length === 0) return "Error: invalid hex pattern";

        const offsets = findPattern(data, patBuf, 50);
        if (offsets.length > 0) {
          results.push(`Found ${offsets.length} matches for hex pattern:`);
          for (const off of offsets.slice(0, 20)) {
            const ctxStart = Math.max(0, off - 8);
            const ctxEnd = Math.min(data.length, off + 24);
            const ctx = hexDump(data.slice(ctxStart, ctxEnd), ctxStart).split("\n")[0];
            results.push(`  0x${off.toString(16).toUpperCase().padStart(8, "0")}: ${ctx}`);
          }
        }
        return results.join("\n") || `No matches for hex pattern`;
      }

      // Text pattern search
      const strings = extractStrings(data, 4);
      const parts = pattern.split("|").map(p => p.trim().toLowerCase());
      const matched = strings.filter(s => parts.some(p => s.str.toLowerCase().includes(p)));

      if (matched.length > 0) {
        for (const s of matched.slice(0, 200)) {
          results.push(`${s.offset.toString(16).padStart(8, " ")} ${s.str}`);
        }
        if (matched.length > 200) results.push(`... (${matched.length - 200} more matches)`);
      }
      return results.join("\n") || `No matches for '${pattern}'`;
    },
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // 9. eeprom_layout_parse — FCA EEPROM/binary module layout (pure JS)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    name: "eeprom_layout_parse",
    description:
      "Identify and map the layout of FCA/Stellantis EEPROM dumps or module binaries. Detects module type (RFHUB, WCM, BCM, PCM, etc.), maps known offset regions, finds VINs, UDS references, and CAN IDs. Essential for automotive module analysis.",
    inputSchema: {
      type: "object",
      properties: {
        module_hint: {
          type: "string",
          description: "Optional hint for module type: 'rfhub', 'wcm', 'bcm', 'pcm', 'skim', 'auto' (default: 'auto')",
        },
      },
    },
    async call(args, filePath) {
      const hint = String(args.module_hint ?? "auto").toLowerCase();
      const data = await fs.readFile(filePath);
      const size = data.length;
      const results: string[] = [];

      results.push("═══ EEPROM LAYOUT ANALYSIS ═══");
      results.push(`File size: ${size} bytes (${(size / 1024).toFixed(1)} KB)`);

      // Module detection signatures
      const moduleSignatures: Record<string, { markers: string[]; typicalSizes: Array<[number, number]> }> = {
        RFHUB: { markers: ["RFHUB", "RF_HUB", "FOBIK", "RFH"], typicalSizes: [[1024, 8192], [16384, 65536]] },
        WCM: { markers: ["WCM", "SKREEM", "SKIM"], typicalSizes: [[2048, 16384]] },
        BCM: { markers: ["BCM", "TIPM", "BODY"], typicalSizes: [[32768, 262144]] },
        PCM: { markers: ["PCM", "ECM", "ENGINE"], typicalSizes: [[262144, 4194304]] },
        TCM: { markers: ["TCM", "TRANS"], typicalSizes: [[65536, 524288]] },
        ABS: { markers: ["ABS", "ESP", "BRAKE"], typicalSizes: [[32768, 262144]] },
        IPC: { markers: ["IPC", "CLUSTER", "INSTRUMENT"], typicalSizes: [[16384, 131072]] },
      };

      // Detect module type
      let detectedModule = "UNKNOWN";
      let bestScore = 0;
      const dataStr = data.toString("ascii").replace(/[^\x20-\x7E]/g, "");

      for (const [modName, sig] of Object.entries(moduleSignatures)) {
        let score = 0;
        if (hint === modName.toLowerCase()) score += 50;
        for (const marker of sig.markers) {
          if (dataStr.includes(marker)) {
            score += 10;
            results.push(`  Signature: "${marker}" found`);
          }
        }
        for (const [minSz, maxSz] of sig.typicalSizes) {
          if (size >= minSz && size <= maxSz) { score += 5; break; }
        }
        if (score > bestScore) { bestScore = score; detectedModule = modName; }
      }

      results.push(`\nDetected module: ${detectedModule} (confidence: ${Math.min(100, bestScore)}%)`);

      // VIN scan (17 alphanumeric chars, excluding I, O, Q)
      const vinRegex = /[A-HJ-NPR-Z0-9]{17}/g;
      const vinMatches: Array<{ offset: number; vin: string }> = [];
      for (let i = 0; i < data.length - 17; i++) {
        const slice = data.slice(i, i + 17).toString("ascii");
        if (/^[A-HJ-NPR-Z0-9]{17}$/.test(slice)) {
          vinMatches.push({ offset: i, vin: slice });
          i += 16; // skip ahead
        }
      }
      if (vinMatches.length > 0) {
        results.push(`\n═══ VIN LOCATIONS ═══`);
        for (const v of vinMatches.slice(0, 10)) {
          results.push(`  0x${v.offset.toString(16).toUpperCase().padStart(4, "0")}: ${v.vin}`);
        }
      }

      // UDS 0x27 Security Access references
      const seedKeyOffsets: string[] = [];
      for (let i = 0; i < data.length - 2; i++) {
        if (data[i] === 0x27 && [0x01, 0x03, 0x05, 0x11, 0x61].includes(data[i + 1])) {
          seedKeyOffsets.push(`0x${i.toString(16).toUpperCase().padStart(4, "0")} (sub=0x${data[i + 1].toString(16).padStart(2, "0")})`);
        }
      }
      if (seedKeyOffsets.length > 0) {
        results.push(`\n═══ UDS SECURITY ACCESS (0x27) REFERENCES ═══`);
        for (const ref of seedKeyOffsets.slice(0, 20)) {
          results.push(`  ${ref}`);
        }
        if (seedKeyOffsets.length > 20) results.push(`  ... (${seedKeyOffsets.length - 20} more)`);
      }

      // CAN ID scan
      const canIds: Array<{ pattern: Buffer; label: string }> = [
        { pattern: Buffer.from([0x07, 0x40]), label: "0x740 (RFHUB Tx)" },
        { pattern: Buffer.from([0x07, 0x42]), label: "0x742 (RFHUB Rx)" },
        { pattern: Buffer.from([0x07, 0xE0]), label: "0x7E0 (PCM Tx)" },
        { pattern: Buffer.from([0x07, 0xE8]), label: "0x7E8 (PCM Rx)" },
        { pattern: Buffer.from([0x06, 0x40]), label: "0x640 (BCM Tx)" },
        { pattern: Buffer.from([0x06, 0x48]), label: "0x648 (BCM Rx)" },
      ];
      const foundCan: string[] = [];
      for (const { pattern: canPat, label } of canIds) {
        const idx = data.indexOf(canPat);
        if (idx !== -1) {
          foundCan.push(`${label} at 0x${idx.toString(16).toUpperCase().padStart(4, "0")}`);
        }
      }
      if (foundCan.length > 0) {
        results.push(`\n═══ CAN IDs FOUND ═══`);
        for (const c of foundCan) results.push(`  ${c}`);
      }

      // Generic region map based on size
      results.push(`\n═══ OFFSET REGION MAP ═══`);
      const regionSize = Math.min(size, 256);
      const firstRegion = data.slice(0, regionSize);
      const isEmpty = firstRegion.every(b => b === 0x00 || b === 0xFF);
      results.push(`  [0x0000 - 0x${regionSize.toString(16).toUpperCase()}] Header region ${isEmpty ? "[EMPTY]" : "[DATA]"}`);
      results.push(`    Hex: ${data.slice(0, 32).toString("hex").match(/.{1,2}/g)?.join(" ")}`);

      if (size > 256) {
        const midStart = Math.floor(size / 4);
        const midData = data.slice(midStart, midStart + 32);
        results.push(`  [0x${midStart.toString(16).toUpperCase()} - ...] Mid-file region`);
        results.push(`    Hex: ${midData.toString("hex").match(/.{1,2}/g)?.join(" ")}`);
            }
      return results.join("\n");
    },
  },
  // ─── archive_extract ─────────────────────────────────────────────────────
  {
    name: "archive_extract",
    description: `MANDATORY FIRST STEP when the file is a .tar.gz, .tar, .zip, .gz, .7z, or any compressed/archived container. Extracts ALL contents from the archive, returns a full manifest of every extracted file with its size, type, and a hex/string preview. ALWAYS call this BEFORE any other tool when file_identify shows gzip, tar, zip, or archive magic bytes. Do NOT try to analyze the archive container itself - extract first, then analyze each extracted file individually.`,
    inputSchema: {
      type: "object" as const,
      properties: {
        filePath: { type: "string", description: "Absolute path to the archive file to extract" },
        outputDir: { type: "string", description: "Optional: directory to extract into" },
      },
      required: ["filePath"],
    },
    call: async (args: Record<string, unknown>): Promise<string> => {
      const filePath = args.filePath as string;
      const outputDir = args.outputDir as string | undefined;
      const { execSync } = await import("child_process");
      const fsM = await import("fs");
      const pathM = await import("path");
      if (!fsM.existsSync(filePath)) return `ERROR: File not found: ${filePath}`;
      const outDir = outputDir || `/tmp/srt-extract-${Date.now()}`;
      fsM.mkdirSync(outDir, { recursive: true });
      const results: string[] = [];
      try {
        const fd = fsM.openSync(filePath, "r");
        const magic = Buffer.alloc(6);
        fsM.readSync(fd, magic, 0, 6, 0);
        fsM.closeSync(fd);
        const isGzip = magic[0] === 0x1f && magic[1] === 0x8b;
        const isZip = magic[0] === 0x50 && magic[1] === 0x4b;
        let extractCmd = "";
        if (isGzip || filePath.endsWith(".tar.gz") || filePath.endsWith(".tgz")) {
          extractCmd = `tar -xzf "${filePath}" -C "${outDir}" 2>&1`;
        } else if (filePath.endsWith(".tar")) {
          extractCmd = `tar -xf "${filePath}" -C "${outDir}" 2>&1`;
        } else if (isZip || filePath.endsWith(".zip")) {
          extractCmd = `unzip -o "${filePath}" -d "${outDir}" 2>&1`;
        } else if (filePath.endsWith(".gz")) {
          const outFile = pathM.join(outDir, pathM.basename(filePath, ".gz"));
          extractCmd = `gunzip -c "${filePath}" > "${outFile}" 2>&1`;
        } else {
          extractCmd = `tar -xf "${filePath}" -C "${outDir}" 2>&1`;
        }
        results.push(`[ARCHIVE EXTRACT] Running: ${extractCmd}`);
        try {
          const out = execSync(extractCmd, { timeout: 60000, maxBuffer: 10 * 1024 * 1024 }).toString();
          if (out.trim()) results.push(`[OUTPUT] ${out.slice(0, 500)}`);
        } catch (e: any) {
          results.push(`[EXTRACT WARNING] ${e.message?.slice(0, 300)}`);
        }
        const allFiles: string[] = [];
        const walkDir = (dir: string) => {
          try {
            const entries = fsM.readdirSync(dir, { withFileTypes: true });
            for (const entry of entries) {
              const fullPath = pathM.join(dir, entry.name);
              if (entry.isDirectory()) walkDir(fullPath);
              else allFiles.push(fullPath);
            }
          } catch { /* skip */ }
        };
        walkDir(outDir);
        results.push(`\n=== EXTRACTED ${allFiles.length} FILES ===`);
        results.push(`Output directory: ${outDir}\n`);
        for (const fp of allFiles.slice(0, 200)) {
          const relPath = fp.replace(outDir + "/", "");
          const stat = fsM.statSync(fp);
          const sizeFmt = stat.size > 1048576 ? `${(stat.size / 1048576).toFixed(1)}MB` : `${(stat.size / 1024).toFixed(1)}KB`;
          let typeLabel = "binary";
          try {
            const ffd = fsM.openSync(fp, "r");
            const fmag = Buffer.alloc(8);
            fsM.readSync(ffd, fmag, 0, 8, 0);
            fsM.closeSync(ffd);
            if (fmag[0] === 0x4d && fmag[1] === 0x5a) typeLabel = "PE/EXE";
            else if (fmag[0] === 0x7f && fmag[1] === 0x45) typeLabel = "ELF";
            else if (fmag[0] === 0x1f && fmag[1] === 0x8b) typeLabel = "GZIP";
            else if (fmag[0] === 0x50 && fmag[1] === 0x4b) typeLabel = "ZIP";
            else if (fp.endsWith(".py") || fp.endsWith(".ts") || fp.endsWith(".js")) typeLabel = "source";
            else if (fp.endsWith(".json")) typeLabel = "JSON";
            else if (fp.endsWith(".bin") || fp.endsWith(".eep") || fp.endsWith(".eeprom")) typeLabel = "EEPROM/binary";
            else if (fp.endsWith(".csv")) typeLabel = "CSV";
            else if (fp.endsWith(".md") || fp.endsWith(".txt")) typeLabel = "text";
          } catch { /* ignore */ }
          results.push(`  [${typeLabel}] ${fp}  (${sizeFmt})`);
          if ((typeLabel === "source" || typeLabel === "JSON" || typeLabel === "text" || typeLabel === "CSV") && stat.size < 50000) {
            try {
              const content = fsM.readFileSync(fp, "utf8").slice(0, 2000);
              results.push(`    --- PREVIEW ---`);
              results.push(content.split("\n").slice(0, 40).map((l: string) => `    ${l}`).join("\n"));
              results.push(`    --- END ---`);
            } catch { /* skip */ }
          } else if (typeLabel === "EEPROM/binary" || typeLabel === "binary") {
            try {
              const bfd = fsM.openSync(fp, "r");
              const bpreview = Buffer.alloc(Math.min(64, stat.size));
              fsM.readSync(bfd, bpreview, 0, bpreview.length, 0);
              fsM.closeSync(bfd);
              results.push(`    Hex[0:64]: ${bpreview.toString("hex").match(/.{1,2}/g)?.join(" ")}`);
            } catch { /* skip */ }
          }
        }
        if (allFiles.length > 200) results.push(`  ... (${allFiles.length - 200} more files)`);
        results.push(`\n[NEXT STEP] Use the absolute file paths above with file_identify, read_hex, extract_strings, eeprom_layout_parse, etc. to analyze each extracted file.`);
        return results.join("\n");
      } catch (err: any) {
        return `ERROR extracting archive: ${err.message}`;
      }
    },
  },
];
// ─── Tool Registry ────────────────────────────────────────────────────────────
export function getToolByName(name: string): ToolDefinition | undefined {
  return tools.find((t) => t.name === name);
}

export function getToolSchemas() {
  return tools.map((t) => ({
    type: "function" as const,
    function: {
      name: t.name,
      description: t.description,
      parameters: t.inputSchema,
    },
  }));
}
