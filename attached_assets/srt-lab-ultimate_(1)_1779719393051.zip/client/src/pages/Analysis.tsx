import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  Binary,
  Key,
  Radio,
  HardDrive,
  Shield,
  Lock,
  Copy,
  Check,
  RefreshCw,
  Terminal,
  ChevronDown,
  ChevronRight,
  FileDown,
  BookOpen,
  MessageCircle,
  X,
  Send,
  Cpu,
  Layers,
  Activity,
  Eye,
  AlertTriangle,
  EyeOff,
  Share2,
  Link,
  Trash2,
  Download,
  Clock,
  Users,
  ExternalLink,
  Archive,
  BookMarked,
  PlusCircle,
  FilePlus,
  FolderOpen,
  FileCheck,
  Loader2,
} from "lucide-react";
import { AnalysisMetricsPanel } from "@/components/AgentMetrics";
import { FindingRatingButtons } from "@/components/FindingRating";

// ─── Types ───────────────────────────────────────────────────────────────────

interface ToolCallTrace {
  toolName: string;
  args: Record<string, unknown>;
  result: string;
  durationMs: number;
}

interface AnalysisData {
  id: string;
  filename: string;
  fileSize: number;
  fileType: string;
  timestamp: number;
  status: string;
  analysisPass?: number;
  analysisMode?: string;
  dissectionReport?: string;
  toolCallTrace?: ToolCallTrace[];
  agentResults?: Array<{ agentId: string; specialty: string; notes: string }>;
  findings: {
    summary: string;
    algorithms: any[];
    seedKeys: any[];
    canAddresses: any[];
    checksums: any[];
    memoryMaps: any[];
    strings: any[];
    cryptoConstants: any[];
    securityBytes: any[];
    deepFindings?: any[];
  };
  rawHex: string;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  toolCalls?: Array<{ toolName: string; result?: string }>;
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function Analysis() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [copiedIdx, setCopiedIdx] = useState<string | null>(null);
  const [showFindings, setShowFindings] = useState(false);
  const [showMetrics, setShowMetrics] = useState(false);
  const [reanalyzing, setReanalyzing] = useState(false);
  const [showKeys, setShowKeys] = useState(false);
  const [keyFindings, setKeyFindings] = useState<any[] | null>(null);
  const [keyDismissed, setKeyDismissed] = useState<string[]>([]);
  const [keyLoading, setKeyLoading] = useState(false);
  const [showDismissed, setShowDismissed] = useState(false);
  // Share Link state
  const [showShare, setShowShare] = useState(false);
  const [shareLinks, setShareLinks] = useState<any[] | null>(null);
  const [shareLoading, setShareLoading] = useState(false);
  const [shareLabel, setShareLabel] = useState("");
  const [shareExpiry, setShareExpiry] = useState("");
  const [shareReminderDays, setShareReminderDays] = useState(3);
  const [shareCreating, setShareCreating] = useState(false);
  const [shareCopied, setShareCopied] = useState<string | null>(null);
  // Pattern matches state
  const [showPatterns, setShowPatterns] = useState(false);
  const [patternMatches, setPatternMatches] = useState<any[] | null>(null);
  const [patternLoading, setPatternLoading] = useState(false);
  // Add Files state
  const [showAddFiles, setShowAddFiles] = useState(false);
  const [additionalFiles, setAdditionalFiles] = useState<any[] | null>(null);
  const [addFilesLoading, setAddFilesLoading] = useState(false);
  const [addFileUploading, setAddFileUploading] = useState(false);
  const addFileInputRef = useRef<HTMLInputElement>(null);
  // File Browser state
  const [showFileBrowser, setShowFileBrowser] = useState(false);
  const [fileTree, setFileTree] = useState<any | null>(null);
  const [fileTreeLoading, setFileTreeLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<any | null>(null);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set());
  // YARA rules match state
  const [showYaraHits, setShowYaraHits] = useState(false);
  const [yaraHits, setYaraHits] = useState<Array<{ ruleId: string; ruleName: string; filename: string; matches: string[] }> | null>(null);
  const [yaraMatchLoading, setYaraMatchLoading] = useState(false);
  const [yaraMatchTotal, setYaraMatchTotal] = useState(0);

  useEffect(() => {
    if (params.id) fetchAnalysis(params.id);
  }, [params.id]);

  // Auto-poll every 3s while analysis is still running
  useEffect(() => {
    if (!analysis || analysis.status !== "running") return;
    const interval = setInterval(() => {
      if (params.id) fetchAnalysis(params.id);
    }, 3000);
    return () => clearInterval(interval);
  }, [analysis?.status, params.id]);

  const fetchAnalysis = async (id: string) => {
    try {
      const res = await fetch(`/api/analysis/${id}`);
      if (res.status === 404) {
        setFetchError("This analysis no longer exists.");
        setLoading(false);
        setTimeout(() => navigate("/"), 3000);
        return;
      }
      if (!res.ok) {
        let msg = `Server error (${res.status})`;
        try { const body = await res.json(); msg = body.error || msg; } catch {}
        setFetchError(msg);
        setLoading(false);
        return;
      }
      setAnalysis(await res.json());
    } catch (e: any) {
      setFetchError(e.message || "Failed to load analysis");
    }
    setLoading(false);
  };

  const loadKeyFindings = async () => {
    if (!params.id || keyFindings !== null) return;
    setKeyLoading(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/key-findings`);
      const data = await res.json();
      setKeyFindings(data.findings || []);
      setKeyDismissed(data.dismissed || []);
    } catch {}
    setKeyLoading(false);
  };

  const dismissKeyFinding = async (findingId: string) => {
    if (!params.id) return;
    await fetch(`/api/analysis/${params.id}/key-findings/${encodeURIComponent(findingId)}/dismiss`, { method: "POST" });
    setKeyDismissed((prev) => [...prev, findingId]);
  };

  const restoreKeyFinding = async (findingId: string) => {
    if (!params.id) return;
    await fetch(`/api/analysis/${params.id}/key-findings/${encodeURIComponent(findingId)}/dismiss`, { method: "DELETE" });
    setKeyDismissed((prev) => prev.filter((id) => id !== findingId));
  };

  const loadShareLinks = async () => {
    if (!params.id) return;
    setShareLoading(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/share`);
      const data = await res.json();
      setShareLinks(Array.isArray(data) ? data : []);
    } catch {}
    setShareLoading(false);
  };
  const createShareLink = async () => {
    if (!params.id) return;
    setShareCreating(true);
    try {
      const body: any = { label: shareLabel || undefined, reminderWindowDays: shareReminderDays };
      if (shareExpiry) body.expiresAt = new Date(shareExpiry).getTime();
      const res = await fetch(`/api/analysis/${params.id}/share`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (res.ok) {
        setShareLabel("");
        setShareExpiry("");
        await loadShareLinks();
        // Copy URL to clipboard
        try { await navigator.clipboard.writeText(data.url); setShareCopied(data.token); setTimeout(() => setShareCopied(null), 3000); } catch {}
      }
    } catch {}
    setShareCreating(false);
  };
  const revokeShareLink = async (id: string) => {
    await fetch(`/api/share/${id}`, { method: "DELETE" });
    setShareLinks((prev) => prev ? prev.map((l) => l.id === id ? { ...l, revokedAt: Date.now() } : l) : prev);
  };
  const loadPatternMatches = async () => {
    if (!params.id || patternMatches !== null) return;
    setPatternLoading(true);
    try {
      const res = await fetch(`/api/patterns/match/${params.id}`);
      const data = await res.json();
      setPatternMatches(Array.isArray(data) ? data : []);
    } catch { setPatternMatches([]); }
    setPatternLoading(false);
  };
  const loadYaraMatch = async () => {
    if (!params.id || yaraHits !== null) return;
    setYaraMatchLoading(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/yara-match`, { method: "POST" });
      const data = await res.json();
      setYaraHits(Array.isArray(data.hits) ? data.hits : []);
      setYaraMatchTotal(data.totalRules || 0);
    } catch { setYaraHits([]); }
    setYaraMatchLoading(false);
  };

  const loadFileTree = async () => {
    if (!params.id || fileTree !== null) return;
    setFileTreeLoading(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/file-tree`);
      const data = await res.json();
      if (res.ok) setFileTree(data);
      else setFileTree({ error: data.error || "Failed to load file tree" });
    } catch (e: any) { setFileTree({ error: e.message }); }
    setFileTreeLoading(false);
  };

  const handleReanalyze = async () => {
    if (!params.id) return;
    setReanalyzing(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/reanalyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (res.ok) setAnalysis(data);
    } catch {}
    setReanalyzing(false);
  };

  const loadAdditionalFiles = async () => {
    if (!params.id) return;
    setAddFilesLoading(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/files`);
      const data = await res.json();
      setAdditionalFiles(Array.isArray(data) ? data : []);
    } catch { setAdditionalFiles([]); }
    setAddFilesLoading(false);
  };

  const uploadAdditionalFile = async (file: File) => {
    if (!params.id) return;
    setAddFileUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch(`/api/analysis/${params.id}/files`, { method: "POST", body: fd });
      if (res.ok) {
        await loadAdditionalFiles();
      }
    } catch {}
    setAddFileUploading(false);
  };

  const deleteAdditionalFile = async (fileId: string) => {
    if (!params.id) return;
    await fetch(`/api/analysis/${params.id}/files/${fileId}`, { method: "DELETE" });
    setAdditionalFiles((prev) => prev ? prev.filter((f) => f.id !== fileId) : prev);
  };

  const reanalyzeWithAllFiles = async () => {
    if (!params.id) return;
    setReanalyzing(true);
    try {
      const res = await fetch(`/api/analysis/${params.id}/reanalyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ includeAdditionalFiles: true }),
      });
      const data = await res.json();
      if (res.ok) {
        setAnalysis(data);
        setShowAddFiles(false);
      }
    } catch {}
    setReanalyzing(false);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(id);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  // ─── Loading / Error States ─────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Cpu className="w-8 h-8 text-primary animate-pulse mx-auto" />
          <p className="text-muted-foreground text-sm">Loading analysis...</p>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4 max-w-md px-4">
          <Shield className="w-8 h-8 text-destructive mx-auto" />
          <p className="text-muted-foreground text-sm">{fetchError || "Analysis not found."}</p>
          <Button onClick={() => navigate("/")} size="sm">
            <ArrowLeft className="w-4 h-4 mr-1" /> Back
          </Button>
        </div>
      </div>
    );
  }

  // Handle running/failed states (no findings yet)
  if (analysis.status === "running" || analysis.status === "failed" || !analysis.findings) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4 max-w-md px-4">
          {analysis.status === "failed" ? (
            <>
              <Shield className="w-8 h-8 text-destructive mx-auto" />
              <p className="text-foreground font-medium">Analysis Failed</p>
              <p className="text-muted-foreground text-sm">{(analysis as any).error || "The analysis encountered an error. Please try uploading again."}</p>
              <Button onClick={() => navigate("/")} size="sm">
                <ArrowLeft className="w-4 h-4 mr-1" /> Back to Upload
              </Button>
            </>
          ) : (
            <>
              <Cpu className="w-8 h-8 text-primary animate-pulse mx-auto" />
              <p className="text-foreground font-medium">Analysis in Progress</p>
              <p className="text-muted-foreground text-sm">
                The 6-agent swarm is analyzing <span className="font-mono text-xs">{analysis.filename || "your file"}</span>...
              </p>
              <p className="text-muted-foreground text-xs">This page will auto-refresh when results are ready.</p>
            </>
          )}
        </div>
      </div>
    );
  }

  // Safe defaults for all findings arrays (guard against partial data)
  const findings = {
    summary: analysis.findings?.summary || "",
    algorithms: analysis.findings?.algorithms || [],
    seedKeys: analysis.findings?.seedKeys || [],
    canAddresses: analysis.findings?.canAddresses || [],
    checksums: analysis.findings?.checksums || [],
    memoryMaps: analysis.findings?.memoryMaps || [],
    strings: analysis.findings?.strings || [],
    cryptoConstants: analysis.findings?.cryptoConstants || [],
    securityBytes: analysis.findings?.securityBytes || [],
    deepFindings: analysis.findings?.deepFindings || [],
  };
  const totalFindings =
    findings.algorithms.length +
    findings.seedKeys.length +
    findings.canAddresses.length +
    findings.checksums.length +
    findings.securityBytes.length +
    findings.deepFindings.length;

  // ─── Main Layout: Chat-First with Findings Drawer ───────────────────────────

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Compact Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-12">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-2">
              <Binary className="w-4 h-4 text-primary" />
              <span className="font-mono font-bold text-sm truncate max-w-[200px]">
                {analysis.filename}
              </span>
            </div>
            <Badge variant="outline" className="text-[10px] hidden sm:inline-flex">
              {analysis.fileType} · {(analysis.fileSize / 1024).toFixed(1)} KB
            </Badge>
            {(analysis.analysisPass || 1) > 1 && (
              <Badge className="text-[10px] bg-primary/20 text-primary border-primary/30">
                Pass {analysis.analysisPass}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFindings(!showFindings)}
              className="gap-1.5 text-xs"
            >
              <Layers className="w-3.5 h-3.5" />
              Findings ({totalFindings})
              {showFindings ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowMetrics(!showMetrics)}
              className={`gap-1.5 text-xs ${showMetrics ? 'border-cyan-500/50 text-cyan-400 bg-cyan-500/10' : ''}`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Metrics</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setShowKeys(!showKeys); if (!showKeys) loadKeyFindings(); }}
              className={`gap-1.5 text-xs ${showKeys ? 'border-amber-500/50 text-amber-400 bg-amber-500/10' : ''}`}
            >
              <Key className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Keys</span>
              {keyFindings && keyFindings.filter(f => !keyDismissed.includes(f.id)).length > 0 && (
                <Badge className="text-[9px] h-4 px-1 bg-amber-500/20 text-amber-400 border-amber-500/30">
                  {keyFindings.filter(f => !keyDismissed.includes(f.id)).length}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/hex/${analysis.id}`)}
              className="gap-1.5 text-xs border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10 hidden sm:flex"
            >
              <Binary className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Hex View</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const a = document.createElement("a");
                a.href = `/api/analysis/${analysis.id}/export/pdf`;
                a.download = `srtlab-report-${(analysis.filename || analysis.id).replace(/[^a-z0-9]/gi, "_").slice(0, 40)}.pdf`;
                a.click();
              }}
              className="gap-1.5 text-xs border-red-500/30 text-red-400 hover:bg-red-500/10 hidden sm:flex"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export PDF</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setShowPatterns(!showPatterns); if (!showPatterns) loadPatternMatches(); }}
              className={`gap-1.5 text-xs hidden sm:flex ${showPatterns ? 'border-violet-500/50 text-violet-400 bg-violet-500/10' : ''}`}
            >
              <BookMarked className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Rules</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setShowYaraHits(!showYaraHits); if (!showYaraHits) loadYaraMatch(); }}
              className={`gap-1.5 text-xs hidden sm:flex ${showYaraHits ? 'border-orange-500/50 text-orange-400 bg-orange-500/10' : ''}`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span className="hidden md:inline">YARA</span>
              {yaraHits && yaraHits.length > 0 && (
                <Badge className="text-[9px] h-4 px-1 bg-orange-500/20 text-orange-400 border-orange-500/30">
                  {yaraHits.length}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setShowShare(!showShare); if (!showShare) loadShareLinks(); }}
              className={`gap-1.5 text-xs ${showShare ? 'border-blue-500/50 text-blue-400 bg-blue-500/10' : ''}`}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Share</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleReanalyze}
              disabled={reanalyzing}
              className="gap-1.5 text-xs border-primary/30 text-primary hover:bg-primary/10"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${reanalyzing ? "animate-spin" : ""}`} />
              <span className="hidden sm:inline">Re-analyze</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setShowAddFiles(!showAddFiles); if (!showAddFiles) loadAdditionalFiles(); }}
              className={`gap-1.5 text-xs ${showAddFiles ? 'border-teal-500/50 text-teal-400 bg-teal-500/10' : 'border-teal-500/30 text-teal-400 hover:bg-teal-500/10'}`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Add Files</span>
              {additionalFiles && additionalFiles.length > 0 && (
                <Badge className="text-[9px] h-4 px-1 bg-teal-500/20 text-teal-400 border-teal-500/30">
                  {additionalFiles.length}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setShowFileBrowser(!showFileBrowser); if (!showFileBrowser) loadFileTree(); }}
              className={`gap-1.5 text-xs ${showFileBrowser ? 'border-indigo-500/50 text-indigo-400 bg-indigo-500/10' : 'border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10'}`}
            >
              <Archive className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">File Browser</span>
              {fileTree && !fileTree.error && (
                <Badge className="text-[9px] h-4 px-1 bg-indigo-500/20 text-indigo-400 border-indigo-500/30">
                  {fileTree.totalFiles}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Summary Banner */}
      {findings.summary && (
        <div className="border-b border-border/30 bg-card/40 px-4 py-2">
          <p className="container text-sm text-muted-foreground leading-relaxed">
            <span className="text-primary font-semibold">Summary:</span> {findings.summary}
          </p>
        </div>
      )}

      {/* Add Files Drawer (collapsible) */}
      {showAddFiles && (
        <div className="border-b border-teal-500/20 bg-teal-950/20 overflow-y-auto max-h-[60vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-teal-400" />
                <span className="font-semibold text-sm text-teal-300">Additional Files</span>
                <span className="text-xs text-zinc-500">Add more files to this analysis session — agents will analyze all files together</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  ref={addFileInputRef}
                  type="file"
                  multiple
                  className="hidden"
                  onChange={async (e) => {
                    const files = Array.from(e.target.files || []);
                    for (const f of files) await uploadAdditionalFile(f);
                    e.target.value = "";
                  }}
                />
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 text-xs border-teal-500/40 text-teal-400 hover:bg-teal-500/10"
                  onClick={() => addFileInputRef.current?.click()}
                  disabled={addFileUploading}
                >
                  {addFileUploading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <FilePlus className="w-3.5 h-3.5" />
                  )}
                  {addFileUploading ? "Uploading..." : "Upload Files"}
                </Button>
                {additionalFiles && additionalFiles.length > 0 && (
                  <Button
                    size="sm"
                    onClick={reanalyzeWithAllFiles}
                    disabled={reanalyzing}
                    className="gap-1.5 text-xs bg-teal-600 hover:bg-teal-500 text-white"
                  >
                    {reanalyzing ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5" />
                    )}
                    Re-analyze All Files
                  </Button>
                )}
              </div>
            </div>

            {/* Drop zone */}
            <div
              className="border-2 border-dashed border-teal-500/30 rounded-lg p-6 text-center mb-4 cursor-pointer hover:border-teal-500/60 hover:bg-teal-500/5 transition-colors"
              onClick={() => addFileInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={async (e) => {
                e.preventDefault();
                const files = Array.from(e.dataTransfer.files);
                for (const f of files) await uploadAdditionalFile(f);
              }}
            >
              <FilePlus className="w-8 h-8 text-teal-500/50 mx-auto mb-2" />
              <p className="text-sm text-teal-400/70">Drop files here or click to browse</p>
              <p className="text-xs text-zinc-600 mt-1">Supports any binary, firmware, EEPROM dump, archive, or document</p>
            </div>

            {/* File list */}
            {addFilesLoading ? (
              <div className="text-center py-4 text-teal-400/60 text-sm animate-pulse">Loading files...</div>
            ) : additionalFiles && additionalFiles.length > 0 ? (
              <div className="space-y-2">
                {additionalFiles.map((f: any) => (
                  <div key={f.id} className="flex items-center justify-between bg-card/60 border border-teal-500/20 rounded-lg px-3 py-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileCheck className="w-4 h-4 text-teal-400 flex-shrink-0" />
                      <span className="font-mono text-xs text-zinc-300 truncate">{f.filename}</span>
                      <Badge className="text-[9px] bg-zinc-800 text-zinc-400 border-zinc-700 flex-shrink-0">
                        {f.fileSize ? `${(f.fileSize / 1024).toFixed(1)} KB` : ""}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteAdditionalFile(f.id)}
                      className="text-zinc-500 hover:text-red-400 h-6 w-6 p-0 flex-shrink-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-xs text-zinc-600 py-2">No additional files attached yet</p>
            )}
          </div>
        </div>
      )}

      {/* File Browser Drawer (collapsible) */}
      {showFileBrowser && (
        <div className="border-b border-indigo-500/20 bg-indigo-950/20 overflow-y-auto max-h-[70vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Archive className="w-4 h-4 text-indigo-400" />
                <span className="font-semibold text-sm text-indigo-300">File Browser</span>
                {fileTree && !fileTree.error && (
                  <Badge className="text-[9px] bg-indigo-500/20 text-indigo-400 border-indigo-500/30">
                    {fileTree.totalFiles} file{fileTree.totalFiles !== 1 ? 's' : ''}
                    {fileTree.isArchive ? ` · ${fileTree.archiveType}` : ''}
                  </Badge>
                )}
              </div>
              {fileTree && !fileTree.error && fileTree.isArchive && (
                <a
                  href={`/api/analysis/${params.id}/extraction-tree/zip`}
                  className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 border border-indigo-500/30 rounded px-2 py-1 hover:bg-indigo-500/10 transition-colors"
                >
                  <Download className="w-3 h-3" /> Download All
                </a>
              )}
            </div>

            {fileTreeLoading ? (
              <div className="text-center py-8 text-indigo-400/60 text-sm animate-pulse">
                <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
                Extracting archive and building file tree...
              </div>
            ) : fileTree?.error ? (
              <div className="text-center py-4 text-red-400 text-sm">{fileTree.error}</div>
            ) : fileTree ? (
              <div className="flex gap-4 h-[50vh]">
                {/* File Tree Panel */}
                <div className="w-72 flex-shrink-0 overflow-y-auto border border-indigo-500/20 rounded-lg bg-card/40">
                  <div className="p-2 space-y-0.5">
                    {fileTree.files?.map((f: any, i: number) => {
                      const depth = f.path.split('/').length - 1;
                      const name = f.path.split('/').pop();
                      const typeColors: Record<string, string> = {
                        'dir': 'text-yellow-400',
                        'source': 'text-green-400',
                        'JSON': 'text-cyan-400',
                        'text': 'text-zinc-300',
                        'CSV': 'text-emerald-400',
                        'YARA': 'text-orange-400',
                        'EEPROM': 'text-purple-400',
                        'PE/EXE': 'text-red-400',
                        'ELF': 'text-red-400',
                        'binary': 'text-zinc-400',
                        'gzip': 'text-blue-400',
                        'zip': 'text-blue-400',
                      };
                      const color = typeColors[f.type] || 'text-zinc-400';
                      if (f.isDir) {
                        const isExpanded = expandedDirs.has(f.path);
                        return (
                          <button
                            key={i}
                            className="w-full flex items-center gap-1 px-2 py-0.5 rounded hover:bg-indigo-500/10 text-left"
                            style={{ paddingLeft: `${8 + depth * 12}px` }}
                            onClick={() => {
                              setExpandedDirs(prev => {
                                const next = new Set(prev);
                                if (next.has(f.path)) next.delete(f.path);
                                else next.add(f.path);
                                return next;
                              });
                            }}
                          >
                            {isExpanded ? <ChevronDown className="w-3 h-3 text-yellow-400 flex-shrink-0" /> : <ChevronRight className="w-3 h-3 text-yellow-400 flex-shrink-0" />}
                            <FolderOpen className="w-3 h-3 text-yellow-400 flex-shrink-0" />
                            <span className="text-xs text-yellow-300 truncate">{name}</span>
                          </button>
                        );
                      }
                      // Check if parent dir is expanded (or no parent dir)
                      const parentDir = f.path.includes('/') ? f.path.substring(0, f.path.lastIndexOf('/')) : null;
                      if (parentDir && !expandedDirs.has(parentDir)) return null;
                      return (
                        <button
                          key={i}
                          className={`w-full flex items-center gap-1.5 px-2 py-0.5 rounded text-left transition-colors ${
                            selectedFile?.path === f.path
                              ? 'bg-indigo-500/20 border border-indigo-500/40'
                              : 'hover:bg-indigo-500/10'
                          }`}
                          style={{ paddingLeft: `${8 + depth * 12}px` }}
                          onClick={() => setSelectedFile(f)}
                        >
                          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${color.replace('text-', 'bg-')}`} />
                          <span className={`text-xs truncate ${color}`}>{name}</span>
                          <span className="text-[10px] text-zinc-600 ml-auto flex-shrink-0">
                            {f.size > 1048576 ? `${(f.size / 1048576).toFixed(1)}M` : f.size > 1024 ? `${(f.size / 1024).toFixed(0)}K` : `${f.size}B`}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Preview Panel */}
                <div className="flex-1 overflow-hidden border border-indigo-500/20 rounded-lg bg-card/40 flex flex-col">
                  {selectedFile ? (
                    <>
                      <div className="flex items-center gap-2 px-3 py-2 border-b border-indigo-500/20 bg-card/60">
                        <span className="font-mono text-xs text-indigo-300 truncate">{selectedFile.path}</span>
                        <Badge className="text-[9px] bg-indigo-500/20 text-indigo-400 border-indigo-500/30 flex-shrink-0">{selectedFile.type}</Badge>
                        <span className="text-[10px] text-zinc-500 flex-shrink-0 ml-auto">
                          {selectedFile.size > 1048576 ? `${(selectedFile.size / 1048576).toFixed(2)} MB` : `${(selectedFile.size / 1024).toFixed(1)} KB`}
                        </span>
                      </div>
                      <div className="flex-1 overflow-y-auto p-3">
                        {selectedFile.preview ? (
                          ['EEPROM', 'binary', 'PE/EXE', 'ELF'].includes(selectedFile.type) ? (
                            <div className="font-mono text-[11px] text-emerald-400 leading-relaxed break-all whitespace-pre-wrap">
                              <div className="text-zinc-500 text-[10px] mb-1">Hex preview (first 128 bytes):</div>
                              {selectedFile.preview}
                            </div>
                          ) : (
                            <pre className="font-mono text-[11px] text-zinc-300 leading-relaxed whitespace-pre-wrap overflow-x-auto">{selectedFile.preview}</pre>
                          )
                        ) : (
                          <div className="text-center py-8 text-zinc-600 text-sm">No preview available for this file type</div>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-zinc-600 text-sm">
                      <div className="text-center">
                        <Archive className="w-8 h-8 mx-auto mb-2 opacity-30" />
                        <p>Select a file to preview</p>
                        <p className="text-xs mt-1 text-zinc-700">{fileTree.totalFiles} files extracted from {fileTree.filename}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Agent Metrics Drawer (collapsible) */}
      {showMetrics && analysis && (
        <div className="border-b border-border/30 bg-card/60 overflow-y-auto max-h-[50vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <AnalysisMetricsPanel analysisId={analysis.id} />
          </div>
        </div>
      )}

      {/* Keys & Secrets Drawer (collapsible) */}
      {showKeys && (
        <div className="border-b border-amber-500/20 bg-amber-950/20 overflow-y-auto max-h-[50vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span className="font-semibold text-sm text-amber-300">Keys & Secrets Scanner</span>
                {keyFindings && (
                  <Badge className="text-[10px] bg-amber-500/20 text-amber-400 border-amber-500/30">
                    {keyFindings.filter(f => !keyDismissed.includes(f.id)).length} active
                  </Badge>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDismissed(!showDismissed)}
                className="text-xs text-zinc-500 hover:text-zinc-300 gap-1"
              >
                {showDismissed ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                {showDismissed ? "Hide dismissed" : `Show dismissed (${keyDismissed.length})`}
              </Button>
            </div>
            {keyLoading && (
              <div className="text-center py-8 text-amber-400/60 text-sm animate-pulse">Scanning binary for key material...</div>
            )}
            {!keyLoading && keyFindings !== null && keyFindings.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm">No key material found in this binary.</div>
            )}
            {!keyLoading && keyFindings && keyFindings.length > 0 && (
              <div className="space-y-2">
                {keyFindings
                  .filter(f => showDismissed || !keyDismissed.includes(f.id))
                  .map((f: any) => {
                    const isDismissed = keyDismissed.includes(f.id);
                    return (
                      <div
                        key={f.id}
                        className={`p-3 rounded-lg border transition-all ${
                          isDismissed
                            ? "border-zinc-700/40 bg-zinc-900/40 opacity-50"
                            : "border-amber-500/30 bg-amber-950/30"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <span className="font-semibold text-xs text-amber-300">{f.type}</span>
                              <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-400">
                                {f.confidence} confidence
                              </Badge>
                              <span className="font-mono text-[10px] text-zinc-500">@0x{f.offset?.toString(16).toUpperCase().padStart(8, '0')}</span>
                            </div>
                            <code className="block font-mono text-xs text-emerald-300 bg-black/40 rounded px-2 py-1 truncate max-w-full">
                              {f.preview}
                            </code>
                            {f.description && (
                              <p className="text-[11px] text-zinc-400 mt-1">{f.description}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(`/hex/${analysis.id}#offset=${f.offset?.toString(16).toUpperCase().padStart(8, '0')}`)}
                              className="h-7 w-7 p-0 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                              title="View in Hex Viewer"
                            >
                              <Binary className="w-3.5 h-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => isDismissed ? restoreKeyFinding(f.id) : dismissKeyFinding(f.id)}
                              className={`h-7 w-7 p-0 ${
                                isDismissed
                                  ? "text-zinc-400 hover:text-zinc-200"
                                  : "text-zinc-500 hover:text-zinc-300"
                              }`}
                              title={isDismissed ? "Restore" : "Dismiss"}
                            >
                              {isDismissed ? <Eye className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Pattern Matches Drawer */}
      {showPatterns && (
        <div className="border-b border-violet-500/20 bg-violet-950/20 overflow-y-auto max-h-[50vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <div className="flex items-center gap-2 mb-3">
              <BookMarked className="w-4 h-4 text-violet-400" />
              <span className="font-semibold text-sm text-violet-300">Custom Rules Hits</span>
              {patternMatches && (
                <Badge className="text-[10px] bg-violet-500/20 text-violet-400 border-violet-500/30">
                  {patternMatches.length} matched
                </Badge>
              )}
            </div>
            {patternLoading && (
              <div className="text-center py-8 text-violet-400/60 text-sm animate-pulse">Matching patterns against analysis findings...</div>
            )}
            {!patternLoading && patternMatches !== null && patternMatches.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm">No custom rule patterns matched this analysis.</div>
            )}
            {!patternLoading && patternMatches && patternMatches.length > 0 && (
              <div className="space-y-2">
                {patternMatches.map((m: any) => (
                  <div key={m.id} className="p-3 rounded-lg border border-violet-500/30 bg-violet-950/30">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <BookMarked className="w-3.5 h-3.5 text-violet-400 shrink-0" />
                          <span className="font-semibold text-xs text-violet-300">{m.name}</span>
                          <Badge variant="outline" className="text-[9px] border-violet-500/30 text-violet-400">{m.category}</Badge>
                          {m.matchCount > 1 && (
                            <Badge className="text-[9px] bg-violet-500/20 text-violet-400 border-violet-500/30">{m.matchCount}x</Badge>
                          )}
                        </div>
                        {m.description && <p className="text-[11px] text-zinc-400">{m.description}</p>}
                        {m.patternData && (
                          <code className="block font-mono text-xs text-violet-300 bg-black/40 rounded px-2 py-1 mt-1 truncate">{m.patternData}</code>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      {/* YARA Rules Hits Drawer */}
      {showYaraHits && (
        <div className="border-b border-orange-500/20 bg-orange-950/20 overflow-y-auto max-h-[50vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4 text-orange-400" />
              <span className="font-semibold text-sm text-orange-300">YARA Rules Hits</span>
              {yaraHits && (
                <Badge className="text-[10px] bg-orange-500/20 text-orange-400 border-orange-500/30">
                  {yaraHits.length} / {yaraMatchTotal} rules matched
                </Badge>
              )}
            </div>
            {yaraMatchLoading && (
              <div className="text-center py-8 text-orange-400/60 text-sm animate-pulse">Running YARA rules against binary...</div>
            )}
            {!yaraMatchLoading && yaraHits !== null && yaraHits.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm">
                {yaraMatchTotal === 0 ? "No YARA rules uploaded yet. Go to the Rules page to upload .yar files." : `No matches found across ${yaraMatchTotal} rule file${yaraMatchTotal !== 1 ? 's' : ''}.`}
              </div>
            )}
            {!yaraMatchLoading && yaraHits && yaraHits.length > 0 && (
              <div className="space-y-3">
                {yaraHits.map((hit) => (
                  <div key={hit.ruleId} className="p-3 rounded-lg border border-orange-500/30 bg-orange-950/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                      <span className="font-semibold text-xs text-orange-300">{hit.ruleName}</span>
                      <Badge variant="outline" className="text-[9px] border-orange-500/30 text-orange-400">{hit.filename}</Badge>
                      <Badge className="text-[9px] bg-orange-500/20 text-orange-400 border-orange-500/30">{hit.matches.length} hit{hit.matches.length !== 1 ? 's' : ''}</Badge>
                    </div>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {hit.matches.map((line, i) => (
                        <code key={i} className="block font-mono text-[10px] text-orange-200/80 bg-black/40 rounded px-2 py-0.5 truncate">{line}</code>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Share Link Drawer */}
      {showShare && (
        <div className="border-b border-blue-500/20 bg-blue-950/20 overflow-y-auto max-h-[60vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4">
            <div className="flex items-center gap-2 mb-4">
              <Share2 className="w-4 h-4 text-blue-400" />
              <span className="font-semibold text-sm text-blue-300">Share Analysis</span>
            </div>
            {/* Create new share link */}
            <div className="p-3 rounded-lg border border-blue-500/20 bg-blue-950/30 mb-4">
              <p className="text-xs text-blue-300 font-semibold mb-3">Create Share Link</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-3">
                <input
                  type="text"
                  placeholder="Label (optional)"
                  value={shareLabel}
                  onChange={(e) => setShareLabel(e.target.value)}
                  className="col-span-1 bg-black/30 border border-blue-500/20 rounded px-3 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-blue-500/50"
                />
                <input
                  type="datetime-local"
                  value={shareExpiry}
                  onChange={(e) => setShareExpiry(e.target.value)}
                  className="col-span-1 bg-black/30 border border-blue-500/20 rounded px-3 py-1.5 text-xs text-foreground focus:outline-none focus:border-blue-500/50"
                  title="Expiry date (optional)"
                />
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  <span className="text-xs text-muted-foreground whitespace-nowrap">Remind after</span>
                  <select
                    value={shareReminderDays}
                    onChange={(e) => setShareReminderDays(Number(e.target.value))}
                    className="flex-1 bg-black/30 border border-blue-500/20 rounded px-2 py-1.5 text-xs text-foreground focus:outline-none focus:border-blue-500/50"
                  >
                    {[1, 2, 3, 5, 7, 14, 30].map((d) => (
                      <option key={d} value={d}>{d} day{d !== 1 ? 's' : ''}</option>
                    ))}
                  </select>
                </div>
              </div>
              <Button
                size="sm"
                onClick={createShareLink}
                disabled={shareCreating}
                className="gap-1.5 text-xs bg-blue-600 hover:bg-blue-500 text-white"
              >
                <Link className="w-3.5 h-3.5" />
                {shareCreating ? "Creating..." : "Create & Copy Link"}
              </Button>
              {shareCopied && (
                <span className="ml-3 text-xs text-green-400 animate-in fade-in">Link copied to clipboard!</span>
              )}
            </div>
            {/* Existing share links */}
            {shareLoading && <div className="text-center py-4 text-blue-400/60 text-sm animate-pulse">Loading share links...</div>}
            {!shareLoading && shareLinks && shareLinks.length === 0 && (
              <div className="text-center py-4 text-muted-foreground text-sm">No share links created yet.</div>
            )}
            {!shareLoading && shareLinks && shareLinks.length > 0 && (
              <div className="space-y-2">
                {shareLinks.map((sl: any) => (
                  <div key={sl.id} className={`p-3 rounded-lg border transition-all ${sl.revokedAt ? 'border-zinc-700/40 bg-zinc-900/40 opacity-50' : 'border-blue-500/20 bg-blue-950/20'}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Link className="w-3 h-3 text-blue-400 shrink-0" />
                          <span className="font-mono text-[11px] text-blue-300 truncate">{sl.label || `Link ${sl.id.slice(0, 8)}`}</span>
                          {sl.revokedAt && <Badge className="text-[9px] bg-red-500/20 text-red-400 border-red-500/30">Revoked</Badge>}
                          {sl.expiresAt && sl.expiresAt < Date.now() && !sl.revokedAt && <Badge className="text-[9px] bg-orange-500/20 text-orange-400 border-orange-500/30">Expired</Badge>}
                          <Badge variant="outline" className="text-[9px] border-blue-500/30 text-blue-400">
                            <Users className="w-2.5 h-2.5 mr-1" />{sl.viewCount || 0} views
                          </Badge>
                          {sl.reminderWindowDays && (
                            <Badge variant="outline" className="text-[9px] border-zinc-600 text-zinc-400">
                              <Clock className="w-2.5 h-2.5 mr-1" />Remind {sl.reminderWindowDays}d
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[10px] text-zinc-500">{new Date(sl.createdAt).toLocaleString()}</span>
                          {sl.expiresAt && <span className="text-[10px] text-zinc-500">· Expires {new Date(sl.expiresAt).toLocaleString()}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => { const url = `${window.location.origin}/share/${sl.token}`; navigator.clipboard.writeText(url); setShareCopied(sl.token); setTimeout(() => setShareCopied(null), 2000); }}
                          className="h-7 w-7 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                          title="Copy link"
                        >
                          {shareCopied === sl.token ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </Button>
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => window.open(`/share/${sl.token}`, '_blank')}
                          className="h-7 w-7 p-0 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-500/10"
                          title="Open link"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => window.open(`/api/share/${sl.id}/views/csv`, '_blank')}
                          className="h-7 w-7 p-0 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-500/10"
                          title="Export view history CSV"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </Button>
                        {!sl.revokedAt && (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => revokeShareLink(sl.id)}
                            className="h-7 w-7 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            title="Revoke link"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      {/* Findings Drawer (collapsible) */}
      {showFindings && (
        <div className="border-b border-border/30 bg-card/60 overflow-y-auto max-h-[50vh] animate-in slide-in-from-top duration-200">
          <div className="container py-4 space-y-4">
            {/* Quick Stats */}
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {[
                { label: "Algorithms", count: findings.algorithms.length, icon: Binary },
                { label: "Seed Keys", count: findings.seedKeys.length, icon: Key },
                { label: "CAN Addrs", count: findings.canAddresses.length, icon: Radio },
                { label: "Checksums", count: findings.checksums.length, icon: HardDrive },
                { label: "Security", count: findings.securityBytes.length, icon: Lock },
              ].map((s) => (
                <div key={s.label} className="flex items-center gap-2 bg-muted/30 rounded-lg px-3 py-2">
                  <s.icon className="w-3.5 h-3.5 text-primary" />
                  <span className="font-mono font-bold text-sm">{s.count}</span>
                  <span className="text-[10px] text-muted-foreground">{s.label}</span>
                </div>
              ))}
            </div>

            {/* Findings Sections */}
            {findings.algorithms.length > 0 && (
              <FindingSection title="Algorithms" icon={Binary} count={findings.algorithms.length}>
                {findings.algorithms.map((a: any, i: number) => (
                  <div key={i} className="p-3 bg-muted/20 rounded-lg border border-border/30 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm">{a.name}</span>
                        <Badge variant="outline" className="text-[10px]">{a.type}</Badge>
                      </div>
                      <FindingRatingButtons
                        analysisId={analysis.id}
                        agentId={a.agentId || "ghost"}
                        findingIndex={i}
                        findingCategory="algorithm"
                      />
                    </div>
                    {a.description && <p className="text-xs text-muted-foreground">{a.description}</p>}
                    {a.pseudocode && (
                      <pre className="text-[11px] font-mono bg-black/40 rounded p-2 mt-1 overflow-x-auto whitespace-pre-wrap text-green-400/80 max-h-[200px] overflow-y-auto">
                        {a.pseudocode}
                      </pre>
                    )}
                  </div>
                ))}
              </FindingSection>
            )}

            {findings.seedKeys.length > 0 && (
              <FindingSection title="Seed Keys" icon={Key} count={findings.seedKeys.length}>
                {findings.seedKeys.map((sk: any, i: number) => (
                  <div key={i} className="p-3 bg-muted/20 rounded-lg border border-border/30 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm">{sk.module}</span>
                        <Badge variant="secondary" className="text-[10px]">Level {sk.level}</Badge>
                        <Badge variant="outline" className="text-[10px] font-mono">{sk.algorithm}</Badge>
                      </div>
                      <FindingRatingButtons
                        analysisId={analysis.id}
                        agentId={sk.agentId || "phantom"}
                        findingIndex={i}
                        findingCategory="seed_key"
                      />
                    </div>
                    {sk.description && <p className="text-xs text-muted-foreground">{sk.description}</p>}
                  </div>
                ))}
              </FindingSection>
            )}

            {findings.canAddresses.length > 0 && (
              <FindingSection title="CAN Addresses" icon={Radio} count={findings.canAddresses.length}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {findings.canAddresses.map((c: any, i: number) => (
                    <div key={i} className="p-2 bg-muted/20 rounded border border-border/30 flex items-center gap-2">
                      <span className="font-mono text-xs text-primary">{c.module}</span>
                      <span className="text-[10px] text-muted-foreground">TX:{c.txId} RX:{c.rxId}</span>
                    </div>
                  ))}
                </div>
              </FindingSection>
            )}

            {findings.securityBytes.length > 0 && (
              <FindingSection title="Security Bytes" icon={Lock} count={findings.securityBytes.length}>
                {findings.securityBytes.map((sb: any, i: number) => (
                  <div key={i} className="p-2 bg-muted/20 rounded border border-border/30 flex items-center gap-3">
                    <span className="font-mono text-xs text-primary">{sb.module}</span>
                    <span className="text-[10px] text-muted-foreground">@{sb.offset}</span>
                    <Badge variant="outline" className="text-[10px]">{sb.status}</Badge>
                  </div>
                ))}
              </FindingSection>
            )}

            {(findings.deepFindings || []).length > 0 && (
              <FindingSection title="Deep Findings" icon={Shield} count={(findings.deepFindings || []).length}>
                {(findings.deepFindings || []).map((df: any, i: number) => (
                  <div key={i} className="p-3 bg-muted/20 rounded-lg border border-border/30 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm">{df.title}</span>
                      <FindingRatingButtons
                        analysisId={analysis.id}
                        agentId={df.category || "venom"}
                        findingIndex={i}
                        findingCategory="deep_finding"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">{df.content || df.details}</p>
                  </div>
                ))}
              </FindingSection>
            )}

            {/* Dissection Report */}
            {analysis.dissectionReport && (
              <FindingSection title="Raw Dissection Report" icon={Terminal} count={0}>
                <pre className="text-[11px] font-mono bg-black/40 rounded p-3 overflow-x-auto whitespace-pre-wrap text-green-400/80 max-h-[300px] overflow-y-auto">
                  {analysis.dissectionReport}
                </pre>
              </FindingSection>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2 border-t border-border/30">
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  try {
                    const res = await fetch(`/api/patterns/extract/${analysis.id}`, { method: "POST" });
                    const data = await res.json();
                    if (res.ok) alert(`Extracted ${data.created} patterns.`);
                  } catch { alert("Extraction failed"); }
                }}
                className="gap-1.5 text-xs border-green-500/30 text-green-400 hover:bg-green-500/10"
              >
                <BookOpen className="w-3.5 h-3.5" /> Extract Patterns
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const a = document.createElement("a");
                  a.href = `/api/analysis/${analysis.id}/export/json`;
                  a.download = `srtlab-report-${(analysis.filename || analysis.id).replace(/[^a-z0-9]/gi, "_").slice(0, 40)}.json`;
                  a.click();
                }}
                className="gap-1.5 text-xs"
              >
                <FileDown className="w-3.5 h-3.5" /> Full Report (JSON)
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const a = document.createElement("a");
                  a.href = `/api/analysis/${analysis.id}/export/pdf`;
                  a.download = `srtlab-report-${(analysis.filename || analysis.id).replace(/[^a-z0-9]/gi, "_").slice(0, 40)}.pdf`;
                  a.click();
                }}
                className="gap-1.5 text-xs border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                <FileDown className="w-3.5 h-3.5" /> Full Report (PDF)
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const a = document.createElement("a");
                  a.href = `/api/analysis/${analysis.id}/extraction-tree/zip`;
                  a.download = `srtlab-extraction-${(analysis.filename || analysis.id).replace(/[^a-z0-9]/gi, "_").slice(0, 40)}.zip`;
                  a.click();
                }}
                className="gap-1.5 text-xs border-violet-500/30 text-violet-400 hover:bg-violet-500/10"
              >
                <Archive className="w-3.5 h-3.5" /> Extraction Tree (ZIP)
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* ─── CHAT (Primary Interface) ─────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-h-0">
        <VenomChat analysisId={analysis.id} filename={analysis.filename} />
      </div>
    </div>
  );
}

// ─── Collapsible Finding Section ─────────────────────────────────────────────

function FindingSection({
  title,
  icon: Icon,
  count,
  children,
}: {
  title: string;
  icon: any;
  count: number;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-border/30 rounded-lg overflow-hidden">
      <button
        className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted/20 transition-colors text-left"
        onClick={() => setOpen(!open)}
      >
        <Icon className="w-4 h-4 text-primary shrink-0" />
        <span className="font-semibold text-sm">{title}</span>
        {count > 0 && <Badge variant="secondary" className="text-[10px] ml-1">{count}</Badge>}
        <div className="ml-auto">
          {open ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
        </div>
      </button>
      {open && <div className="px-3 pb-3 space-y-2">{children}</div>}
    </div>
  );
}

// ─── VENOM Chat (Primary Interface) ──────────────────────────────────────────

function VenomChat({ analysisId, filename }: { analysisId: string; filename: string }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeToolCalls, setActiveToolCalls] = useState<string[]>([]);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load persisted chat history from DB on mount
  useEffect(() => {
    if (historyLoaded) return;
    fetch(`/api/analysis/${analysisId}/chat/history`)
      .then((r) => (r.ok ? r.json() : { messages: [] }))
      .then((data) => {
        if (data.messages && data.messages.length > 0) {
          setMessages(
            data.messages.map((m: any) => ({
              role: m.role as "user" | "assistant",
              content: m.content,
              toolCalls: [],
            }))
          );
        }
        setHistoryLoaded(true);
      })
      .catch(() => setHistoryLoaded(true));
  }, [analysisId, historyLoaded]);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, activeToolCalls]);

  const sendMessage = async (text?: string) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    setInput("");
    setLoading(true);
    setActiveToolCalls([]);

    const userMsg: ChatMessage = { role: "user", content: msg };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);

    const history = newMessages.slice(-20).map((m) => ({ role: m.role, content: m.content }));
    const assistantMsg: ChatMessage = { role: "assistant", content: "", toolCalls: [] };
    setMessages((prev) => [...prev, assistantMsg]);

    try {
      const response = await fetch(`/api/analysis/${analysisId}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: msg, history: history.slice(0, -1) }),
      });

      if (!response.ok || !response.body) {
        setMessages((prev) => {
          const updated = [...prev];
          updated[updated.length - 1] = { ...assistantMsg, content: "Request failed. Try again." };
          return updated;
        });
        setLoading(false);
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let lastEvent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.startsWith("event: ")) {
            lastEvent = line.replace("event: ", "").trim();
          } else if (line.startsWith("data: ")) {
            const dataStr = line.replace("data: ", "").trim();
            if (!dataStr) continue;
            try {
              const data = JSON.parse(dataStr);
              if (lastEvent === "tool_start") {
                setActiveToolCalls((prev) => [...prev, data.toolName]);
              } else if (lastEvent === "tool_end") {
                setActiveToolCalls((prev) => prev.filter((t) => t !== data.toolName));
                setMessages((prev) => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last.role === "assistant") {
                    const tc = last.toolCalls || [];
                    tc.push({ toolName: data.toolName, result: data.result });
                    updated[updated.length - 1] = { ...last, toolCalls: tc };
                  }
                  return updated;
                });
              } else if (lastEvent === "message") {
                setMessages((prev) => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last.role === "assistant") {
                    updated[updated.length - 1] = { ...last, content: data.text || "" };
                  }
                  return updated;
                });
              } else if (lastEvent === "error") {
                setMessages((prev) => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last.role === "assistant") {
                    updated[updated.length - 1] = { ...last, content: `Error: ${data.message}` };
                  }
                  return updated;
                });
              }
            } catch {}
          }
        }
      }
    } catch (err: any) {
      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1] = { ...assistantMsg, content: `Error: ${err.message}` };
        return updated;
      });
    }

    setLoading(false);
    setActiveToolCalls([]);
  };

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-6" ref={scrollRef}>
        <div className="max-w-3xl mx-auto space-y-4">
          {/* Empty State — Onboarding */}
          {messages.length === 0 && (
            <div className="text-center py-16 space-y-6">
              <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                <MessageCircle className="w-8 h-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-bold">Ask VENOM about <span className="text-primary font-mono">{filename}</span></h2>
                <p className="text-muted-foreground text-sm max-w-md mx-auto">
                  VENOM has already analyzed this binary with 5 specialist agents. Ask anything — it can also run tools in real-time to dig deeper.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 justify-center max-w-lg mx-auto">
                {[
                  "What did you find in this binary?",
                  "Show me the seed-key algorithm",
                  "What crypto is being used?",
                  "Find all CAN bus IDs",
                  "What UDS services are implemented?",
                  "Dig into the XOR key loop",
                  "What's the EEPROM layout?",
                  "Find the VIN storage location",
                ].map((suggestion) => (
                  <button
                    key={suggestion}
                    className="text-xs px-3 py-2 rounded-lg border border-border/60 hover:border-primary/40 hover:bg-primary/5 transition-all text-muted-foreground hover:text-foreground"
                    onClick={() => sendMessage(suggestion)}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Chat Messages */}
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] space-y-2`}>
                {/* Tool call indicators */}
                {msg.role === "assistant" && msg.toolCalls && msg.toolCalls.length > 0 && (
                  <div className="space-y-1">
                    {msg.toolCalls.map((tc, tci) => (
                      <div key={tci} className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/30 rounded px-2 py-1 font-mono">
                        <Terminal className="w-3 h-3 text-primary shrink-0" />
                        <span className="text-primary">{tc.toolName}</span>
                        {tc.result && (
                          <span className="opacity-60 truncate max-w-[200px]">{tc.result}</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                {/* Message bubble */}
                {(msg.content || (msg.role === "assistant" && loading && idx === messages.length - 1)) && (
                  <div
                    className={`rounded-xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-card border border-border/40 text-foreground"
                    }`}
                  >
                    {msg.role === "assistant" && !msg.content && loading && idx === messages.length - 1 ? (
                      <span className="animate-pulse text-muted-foreground">
                        {activeToolCalls.length > 0
                          ? `Running ${activeToolCalls[activeToolCalls.length - 1]}...`
                          : "Thinking..."}
                      </span>
                    ) : (
                      <pre className="whitespace-pre-wrap font-sans">{msg.content}</pre>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Input Bar — Always Visible at Bottom */}
      <div className="border-t border-border/40 bg-card/80 backdrop-blur-sm px-4 py-3">
        <div className="max-w-3xl mx-auto flex gap-2">
          <input
            ref={inputRef}
            className="flex-1 bg-muted/30 border border-border/40 rounded-xl px-4 py-3 text-sm outline-none focus:border-primary/50 transition-colors placeholder:text-muted-foreground"
            placeholder="Ask VENOM anything about this binary..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            disabled={loading}
          />
          <Button
            size="lg"
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            className="shrink-0 rounded-xl px-4"
          >
            {loading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
