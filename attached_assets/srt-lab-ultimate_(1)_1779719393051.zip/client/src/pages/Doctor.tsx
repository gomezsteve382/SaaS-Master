import { useState, useCallback } from "react";
import { Stethoscope, CheckCircle, XCircle, AlertCircle, RefreshCw, Loader2, Terminal, Cpu, Shield, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface ToolStatus {
  name: string;
  available: boolean;
  version: string | null;
  error: string | null;
}

interface DoctorResult {
  generatedAt: string;
  tools: ToolStatus[];
}

const TOOL_CATEGORIES: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  yara: { label: "YARA Scanner", icon: Shield, color: "text-emerald-400" },
  binwalk: { label: "Binwalk", icon: Cpu, color: "text-blue-400" },
  strings: { label: "Strings", icon: Terminal, color: "text-amber-400" },
  file: { label: "File", icon: Terminal, color: "text-amber-400" },
  xxd: { label: "xxd (Hex Dump)", icon: Terminal, color: "text-purple-400" },
  objdump: { label: "objdump", icon: Cpu, color: "text-blue-400" },
  readelf: { label: "readelf", icon: Cpu, color: "text-blue-400" },
  nm: { label: "nm (Symbol Table)", icon: Cpu, color: "text-blue-400" },
  python3: { label: "Python 3", icon: Zap, color: "text-yellow-400" },
  node: { label: "Node.js", icon: Zap, color: "text-green-400" },
};

export default function Doctor() {
  const [result, setResult] = useState<DoctorResult | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const runDiagnostics = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch("/api/doctor");
      if (!r.ok) throw new Error(await r.text());
      setResult(await r.json());
    } catch (e: any) {
      toast({ title: "Diagnostics failed", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  // Auto-run on mount
  useState(() => { runDiagnostics(); });

  const available = result?.tools.filter(t => t.available) ?? [];
  const missing = result?.tools.filter(t => !t.available) ?? [];
  const allGood = result && missing.length === 0;

  return (
    <div className="min-h-screen bg-background text-foreground p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <Stethoscope className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">System Doctor</h1>
            <p className="text-sm text-muted-foreground">Diagnostic check of all analysis tools and dependencies</p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={runDiagnostics} disabled={loading} className="gap-2">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Re-run Diagnostics
        </Button>
      </div>

      {/* Status Summary */}
      {result && (
        <Card className={`border ${allGood ? "border-emerald-500/30 bg-emerald-500/5" : "border-amber-500/30 bg-amber-500/5"}`}>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              {allGood ? (
                <CheckCircle className="w-6 h-6 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-6 h-6 text-amber-400 shrink-0" />
              )}
              <div>
                <p className="font-medium text-foreground">
                  {allGood
                    ? "All systems operational"
                    : `${available.length} of ${result.tools.length} tools available`}
                </p>
                <p className="text-xs text-muted-foreground">
                  Last checked: {new Date(result.generatedAt).toLocaleString()}
                </p>
              </div>
              <div className="ml-auto flex gap-2">
                <Badge variant="outline" className="text-xs border-emerald-500/30 text-emerald-400">
                  {available.length} OK
                </Badge>
                {missing.length > 0 && (
                  <Badge variant="outline" className="text-xs border-red-500/30 text-red-400">
                    {missing.length} Missing
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {loading && !result && (
        <div className="flex items-center justify-center py-20">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
            <p className="text-sm text-muted-foreground">Running diagnostics...</p>
          </div>
        </div>
      )}

      {/* Tools Grid */}
      {result && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {result.tools.map(tool => {
            const meta = TOOL_CATEGORIES[tool.name] || { label: tool.name, icon: Terminal, color: "text-muted-foreground" };
            const Icon = meta.icon;
            return (
              <Card
                key={tool.name}
                className={`border transition-colors ${
                  tool.available
                    ? "border-border bg-card hover:border-emerald-500/30"
                    : "border-red-500/20 bg-red-500/5"
                }`}
              >
                <CardContent className="pt-4">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-md shrink-0 ${tool.available ? "bg-accent/30" : "bg-red-500/10"}`}>
                      <Icon className={`w-4 h-4 ${tool.available ? meta.color : "text-red-400"}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-foreground">{meta.label}</p>
                        {tool.available ? (
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                        )}
                      </div>
                      {tool.available && tool.version && (
                        <p className="text-xs text-muted-foreground mt-0.5 truncate font-mono">{tool.version}</p>
                      )}
                      {!tool.available && tool.error && (
                        <p className="text-xs text-red-400/80 mt-0.5 truncate">{tool.error}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Info Card */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Terminal className="w-4 h-4 text-muted-foreground" />
            About These Tools
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p><strong className="text-foreground">YARA</strong> — Pattern matching engine used to scan binaries against your uploaded rule sets.</p>
          <p><strong className="text-foreground">Binwalk</strong> — Firmware extraction and analysis. Identifies embedded file systems, compression, and encryption.</p>
          <p><strong className="text-foreground">strings / xxd / file</strong> — Core Unix utilities for string extraction, hex dumps, and file type detection.</p>
          <p><strong className="text-foreground">objdump / readelf / nm</strong> — ELF/PE binary analysis tools for disassembly, symbol tables, and section headers.</p>
          <p><strong className="text-foreground">Python 3 / Node.js</strong> — Runtime environments used by analysis scripts and agent tools.</p>
        </CardContent>
      </Card>
    </div>
  );
}
