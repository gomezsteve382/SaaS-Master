import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Activity,
  Cpu,
  FileDigit,
  LayoutDashboard,
  ShieldCheck,
  Stethoscope,
  GitCompare,
  History,
  Network,
  BookOpen,
  Layers,
  HexagonIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [apiStatus, setApiStatus] = useState<"ok" | "error" | "unknown">("unknown");

  useEffect(() => {
    fetch("/api/health")
      .then((r) => r.ok ? setApiStatus("ok") : setApiStatus("error"))
      .catch(() => setApiStatus("error"));
  }, []);

  const navItems = [
    { href: "/", label: "Upload & Analyze", icon: LayoutDashboard },
    { href: "/history", label: "Vault / History", icon: History },
    { href: "/analysis", label: "Analyses", icon: Activity, matchPrefix: true },
    { href: "/hex", label: "Hex Viewer", icon: HexagonIcon, matchPrefix: true },
    { href: "/compare", label: "Compare", icon: GitCompare },
    { href: "/align", label: "Multi-Align", icon: Layers },
    { href: "/diff", label: "Diff", icon: FileDigit },
    { href: "/batch", label: "Batch Analysis", icon: Cpu },
    { href: "/patterns", label: "Pattern Library", icon: BookOpen },
    { href: "/knowledge-graph", label: "Knowledge Graph", icon: Network },
    { href: "/rules", label: "YARA Rules", icon: ShieldCheck },
    { href: "/doctor", label: "Doctor", icon: Stethoscope },
  ];

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden text-foreground">
      {/* Sidebar */}
      <div className="w-64 border-r border-border bg-sidebar flex flex-col justify-between shrink-0">
        <div className="overflow-y-auto">
          <div className="p-6 flex items-center gap-3">
            <Cpu className="w-8 h-8 text-primary shrink-0" />
            <div>
              <h1 className="font-bold text-sm tracking-widest uppercase text-sidebar-foreground">SRT Lab</h1>
              <div className="text-xs text-muted-foreground font-mono">Ultimate Edition</div>
            </div>
          </div>
          <nav className="px-4 space-y-1 pb-4">
            {navItems.map((item) => {
              const active =
                location === item.href ||
                (item.matchPrefix && item.href !== "/" && location.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-sm text-sm font-medium transition-colors",
                    active
                      ? "bg-sidebar-primary/10 text-sidebar-primary-foreground border border-sidebar-primary/20"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <item.icon className="w-4 h-4 shrink-0" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="border-t border-sidebar-border shrink-0">
          <div className="px-4 py-4 flex items-center gap-2">
            <div
              className={cn(
                "w-2 h-2 rounded-full",
                apiStatus === "ok"
                  ? "bg-primary"
                  : apiStatus === "error"
                  ? "bg-destructive animate-pulse"
                  : "bg-muted-foreground"
              )}
            />
            <span className="text-xs font-mono text-muted-foreground">
              API: {apiStatus === "unknown" ? "checking..." : apiStatus}
            </span>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <div className="absolute inset-0 pointer-events-none tactical-grid opacity-20" />
        <div className="relative flex-1 overflow-auto p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
