import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppShell } from "./components/AppShell";
import Home from "./pages/Home";
import Analysis from "./pages/Analysis";
import History from "./pages/History";
import Compare from "./pages/Compare";
import Align from "./pages/Align";
import Diff from "./pages/Diff";
import PatternLibrary from "./pages/PatternLibrary";
import KnowledgeGraph from "./pages/KnowledgeGraph";
import BatchAnalysis from "./pages/BatchAnalysis";
import HexViewer from "./pages/HexViewer";
import SharedAnalysis from "./pages/SharedAnalysis";
import Rules from "./pages/Rules";
import Doctor from "./pages/Doctor";

function Router() {
  return (
    <Switch>
      {/* Public routes (no AppShell) */}
      <Route path={"\\share/:token"} component={SharedAnalysis} />
      {/* Protected routes (with AppShell) */}
      <Route>
        <AppShell>
          <Switch>
            {/* Dashboard & Main */}
            <Route path={"\\"} component={Home} />
            {/* Binaries & Analyses */}
            <Route path={"\\analysis/:id"} component={Analysis} />
            {/* Tools & Features */}
            <Route path={"\\history"} component={History} />
            <Route path={"\\compare"} component={Compare} />
            <Route path={"\\align"} component={Align} />
            <Route path={"\\diff"} component={Diff} />
            <Route path={"\\patterns"} component={PatternLibrary} />
            <Route path={"\\knowledge-graph"} component={KnowledgeGraph} />
            <Route path={"\\batch"} component={BatchAnalysis} />
            <Route path={"\\hex/:id"} component={HexViewer} />
            <Route path={"\\rules"} component={Rules} />
            <Route path={"\\doctor"} component={Doctor} />
            {/* 404 */}
            <Route path={"\\404"} component={NotFound} />
            <Route component={NotFound} />
          </Switch>
        </AppShell>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
