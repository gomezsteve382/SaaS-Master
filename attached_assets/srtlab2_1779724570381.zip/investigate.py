#!/usr/bin/env python3
"""
SRT Lab Investigation Swarm — CLI runner.

Usage:
  python3 investigate.py <target.bin> [reference.bin]

Runs the 5-agent read-only swarm against a dump and prints the unified report.
Add a known-good reference dump to enable CROSS_REF donor/foreign-secret
comparison.
"""
import sys
import json
from swarm_run import run_swarm


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    target = sys.argv[1]
    reference = sys.argv[2] if len(sys.argv) > 2 else None
    out = run_swarm(target, reference)

    rep = out["report"]
    print(f"\n=== INVESTIGATION: {out['target']} ===")
    if out["reference"]:
        print(f"reference: {out['reference']}")
    print(f"\n{rep['summary']}\n")

    print("FINDINGS (ranked by confidence):")
    for f in rep["findings"]:
        src = ",".join(f["sources"])
        off = (" @ " + ", ".join(f["offsets"])) if f["offsets"] else ""
        print(f"  [{f['confidence']:.2f}] ({f['status']}/{src}) {f['title']}{off}")
        print(f"        {f['detail']}")

    if rep["contradictions"]:
        print("\nCONTRADICTIONS:")
        for c in rep["contradictions"]:
            print(f"  {c['topic']}: {c['adjudication']}")
            for p in c["positions"]:
                print(f"     - {p['agent']}: {p['claim']} ({p['confidence']})")

    if rep["gaps"]:
        print("\nGAPS:")
        for g in rep["gaps"]:
            print(f"  - {g}")

    if rep["recommended_next_steps"]:
        print("\nRECOMMENDED NEXT STEPS:")
        for n in rep["recommended_next_steps"]:
            print(f"  - {n}")

    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
