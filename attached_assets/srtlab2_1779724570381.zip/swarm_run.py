"""
Working investigation swarm — runs the five FCA specialist agents against
loaded dumps and synthesizes a unified report. Rule-based agent driver (no LLM)
so it executes end-to-end here; the agent logic mirrors what each specialist's
prompt instructs the model to do. Swap the driver for an Anthropic ModelClient
in the repo and the tool layer + coordinator are unchanged.

READ-ONLY GUARANTEE: agents may only call tools in READ_ONLY_TOOLS. Any other
tool name raises ForbiddenTool. There is no write/UDS-vehicle path in this file.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable
import json

from tools import fca_tools as T
from tools.fca_tools import Dump

READ_ONLY_TOOLS = {
    "read_hex", "search_patterns", "key_secrets_scan",
    "eeprom_layout_scan", "parse_module", "uds_static_decode", "pattern_lookup",
}
FORBIDDEN_TOOLS = {"uds_send", "write_hex", "flash_module", "modify_backup", "security_access"}


class ForbiddenTool(Exception):
    pass


@dataclass
class Finding:
    id: str
    title: str
    detail: str
    offsets: list[str]
    confidence: float
    evidence: list[str]
    status: str  # VERIFIED | UNVERIFIED

    def key(self) -> str:
        return f"{','.join(sorted(self.offsets))}|{self.title.strip().lower()}"


@dataclass
class AgentReport:
    agent: str
    findings: list[Finding] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    needs: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------
# Guarded tool dispatch
# --------------------------------------------------------------------------
def call_tool(_agent: str, _allowed: set[str], _tool: str, **kwargs) -> Any:
    if _tool in FORBIDDEN_TOOLS or _tool not in READ_ONLY_TOOLS:
        raise ForbiddenTool(f"{_agent} attempted forbidden tool '{_tool}'")
    if _tool not in _allowed:
        raise ForbiddenTool(f"{_agent} tool '{_tool}' not in its specialty allowlist")
    fn = getattr(T, _tool)
    return fn(**kwargs)


# --------------------------------------------------------------------------
# Specialist agents (rule-based drivers)
# --------------------------------------------------------------------------
def agent_crypto(dump: Dump) -> AgentReport:
    allowed = {"key_secrets_scan", "search_patterns", "read_hex", "pattern_lookup"}
    r = AgentReport(agent="CRYPTO")
    scan = call_tool("CRYPTO", allowed, "key_secrets_scan", dump=dump)
    sig = call_tool("CRYPTO", allowed, "pattern_lookup", name="mirrored_aes_secret")
    for i, c in enumerate(scan["candidates"]):
        conf = 0.85 if c["mirrored"] else 0.5
        r.findings.append(Finding(
            id=f"CRYPTO-{i}",
            title="immobilizer secret block" if c["mirrored"] else "high-entropy block",
            detail=f"{c['value']} (entropy {c['entropy']}, mirrored={c['mirrored']})",
            offsets=[c["offset"]],
            confidence=conf,
            evidence=[f"key_secrets_scan -> {c['offset']}", f"pattern_lookup -> {sig['name']}"],
            status="VERIFIED" if c["mirrored"] else "UNVERIFIED",
        ))
    if not scan["candidates"]:
        r.gaps.append("no high-entropy secret blocks found — module may be virgin/secret-cleared")
    return r


def agent_layout(dump: Dump) -> AgentReport:
    allowed = {"eeprom_layout_scan", "parse_module", "read_hex"}
    r = AgentReport(agent="LAYOUT")
    lay = call_tool("LAYOUT", allowed, "eeprom_layout_scan", dump=dump)
    r.findings.append(Finding(
        id="LAYOUT-map", title="region map",
        detail=f"{lay['region_counts']} across {lay['size']} bytes",
        offsets=[], confidence=0.95,
        evidence=["eeprom_layout_scan"], status="VERIFIED",
    ))
    # VIN consistency check — the operative fault-finder
    vins = lay["vins"]
    if len(vins) > 1:
        r.findings.append(Finding(
            id="LAYOUT-vin", title="VIN slot mismatch",
            detail="multiple distinct VINs stored: " + "; ".join(f"{v} @ {offs}" for v, offs in vins.items()),
            offsets=[o for offs in vins.values() for o in offs],
            confidence=0.9,
            evidence=["eeprom_layout_scan.vins"], status="VERIFIED",
        ))
    elif len(vins) == 1:
        v, offs = next(iter(vins.items()))
        r.findings.append(Finding(
            id="LAYOUT-vin", title="VIN consistent",
            detail=f"single VIN {v} in {len(offs)} slot(s): {offs}",
            offsets=offs, confidence=0.9,
            evidence=["eeprom_layout_scan.vins"], status="VERIFIED",
        ))
    else:
        r.gaps.append("no VIN string found in dump")
    # flag large blank regions
    for reg in lay["regions"]:
        size = int(reg["end"], 16) - int(reg["start"], 16)
        if reg["type"] == "blank" and size >= 0x100:
            r.needs.append(f"confirm blank region {reg['start']}-{reg['end']} ({size}b) is normal vs missing data")
    return r


def agent_immobilizer(dump: Dump) -> AgentReport:
    allowed = {"key_secrets_scan", "search_patterns", "read_hex", "pattern_lookup"}
    r = AgentReport(agent="IMMOBILIZER")
    scan = call_tool("IMMOBILIZER", allowed, "key_secrets_scan", dump=dump)
    secrets = [c for c in scan["candidates"] if c["mirrored"]]
    if secrets:
        r.findings.append(Finding(
            id="IMMO-married", title="module appears married",
            detail=f"{len(secrets)} mirror-consistent secret block(s) present at "
                   + ", ".join(s["offset"] for s in secrets),
            offsets=[s["offset"] for s in secrets],
            confidence=0.8,
            evidence=["key_secrets_scan mirrored=true"], status="VERIFIED",
        ))
        r.needs.append("if marrying to a different BCM, secret must be cleared/rewritten via tool RF Hub Replacement")
    else:
        r.findings.append(Finding(
            id="IMMO-virgin", title="no paired secret detected",
            detail="no mirror-consistent secret blocks — module reads unmarried/secret-cleared",
            offsets=[], confidence=0.6, evidence=["key_secrets_scan"], status="UNVERIFIED",
        ))
    return r


def agent_protocol(dump: Dump) -> AgentReport:
    allowed = {"uds_static_decode", "search_patterns", "read_hex"}
    r = AgentReport(agent="PROTOCOL")
    uds = call_tool("PROTOCOL", allowed, "uds_static_decode", dump=dump)
    for d in uds["did_constants"]:
        r.findings.append(Finding(
            id=f"PROTO-{d['did']}", title=f"DID constant {d['label']}",
            detail=f"{d['label']} at {d['offset']}",
            offsets=[d["offset"]], confidence=0.7,
            evidence=["uds_static_decode"], status="VERIFIED",
        ))
    if not uds["did_constants"]:
        r.gaps.append("no known FCA DID constants located in dump")
    return r


def agent_crossref(dump: Dump, reference: Dump | None) -> AgentReport:
    allowed = {"pattern_lookup", "search_patterns", "read_hex"}
    r = AgentReport(agent="CROSS_REF")
    if reference is None:
        r.gaps.append("no reference dump supplied for comparison")
        return r
    # compare secret regions against a known-good reference
    tgt = call_tool("CROSS_REF", allowed, "search_patterns", dump=dump, pattern="ff ff", is_regex=False)  # touch tool
    ref_scan = T.key_secrets_scan(reference)
    tgt_scan = T.key_secrets_scan(dump)
    ref_secrets = {c["value"] for c in ref_scan["candidates"] if c["mirrored"]}
    tgt_secrets = {c["value"] for c in tgt_scan["candidates"] if c["mirrored"]}
    foreign = tgt_secrets - ref_secrets
    shared = tgt_secrets & ref_secrets
    if foreign:
        r.findings.append(Finding(
            id="XREF-foreign", title="secret(s) not present in reference",
            detail=f"{len(foreign)} secret block(s) in target absent from reference '{reference.name}' "
                   f"— consistent with a foreign/donor marriage",
            offsets=[], confidence=0.7,
            evidence=[f"compare vs {reference.name}"], status="UNVERIFIED",
        ))
    if shared:
        r.findings.append(Finding(
            id="XREF-shared", title="secret matches reference",
            detail=f"{len(shared)} secret block(s) shared with reference",
            offsets=[], confidence=0.6,
            evidence=[f"compare vs {reference.name}"], status="UNVERIFIED",
        ))
    return r


# --------------------------------------------------------------------------
# Coordinator: merge / dedupe / contradictions
# --------------------------------------------------------------------------
def synthesize(reports: list[AgentReport]) -> dict[str, Any]:
    by_key: dict[str, dict[str, Any]] = {}
    offset_index: dict[str, list[dict[str, Any]]] = {}

    for rep in reports:
        for f in rep.findings:
            k = f.key()
            if k in by_key:
                m = by_key[k]
                m["confidence"] = max(m["confidence"], f.confidence)
                m["evidence"] = sorted(set(m["evidence"]) | set(f.evidence))
                if rep.agent not in m["sources"]:
                    m["sources"].append(rep.agent)
                if f.status == "VERIFIED":
                    m["status"] = "VERIFIED"
            else:
                m = {
                    "id": f.id, "title": f.title, "detail": f.detail,
                    "offsets": f.offsets, "confidence": f.confidence,
                    "evidence": list(f.evidence), "status": f.status,
                    "sources": [rep.agent],
                }
                by_key[k] = m
                for off in f.offsets:
                    offset_index.setdefault(off, []).append(m)

    contradictions = []
    for off, arr in offset_index.items():
        if len(arr) > 1 and len({a["status"] for a in arr}) > 1:
            contradictions.append({
                "topic": f"offset {off}",
                "positions": [{"agent": a["sources"][0], "claim": f"{a['title']} ({a['status']})", "confidence": a["confidence"]} for a in arr],
                "adjudication": "needs operator/coordinator review",
                "confidence": 0.3,
            })

    findings = sorted(by_key.values(), key=lambda x: -x["confidence"])
    gaps = sorted({g for r in reports for g in r.gaps})
    needs = sorted({n for r in reports for n in r.needs})
    return {
        "summary": f"{len(findings)} distinct finding(s) from {len(reports)} agents; {len(contradictions)} contradiction(s).",
        "findings": findings,
        "contradictions": contradictions,
        "gaps": gaps,
        "recommended_next_steps": needs,
    }


def run_swarm(target_path: str, reference_path: str | None = None) -> dict[str, Any]:
    dump = Dump.load(target_path)
    reference = Dump.load(reference_path) if reference_path else None
    reports = [
        agent_crypto(dump),
        agent_layout(dump),
        agent_immobilizer(dump),
        agent_protocol(dump),
        agent_crossref(dump, reference),
    ]
    report = synthesize(reports)
    return {
        "target": dump.name,
        "reference": reference.name if reference else None,
        "agents": {r.agent: {"findings": len(r.findings), "gaps": r.gaps, "needs": r.needs} for r in reports},
        "report": report,
    }
