"""
Real, deterministic analysis tools for FCA/Stellantis ECU dumps.

These are the actual implementations behind the swarm's read-only tool names.
No LLM, no network — pure byte analysis. This is the same logic used to
diagnose the donor RFHub by hand, codified so the swarm can call it.

Tool surface (matches READ_ONLY_TOOLS in the TS core):
  read_hex, search_patterns, key_secrets_scan, eeprom_layout_scan,
  parse_module, uds_static_decode, pattern_lookup
"""
from __future__ import annotations
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any


# --------------------------------------------------------------------------
# Dump container
# --------------------------------------------------------------------------
@dataclass
class Dump:
    name: str
    data: bytes

    @classmethod
    def load(cls, path: str) -> "Dump":
        with open(path, "rb") as f:
            return cls(name=path.split("/")[-1], data=f.read())


def _entropy(b: bytes) -> float:
    if not b:
        return 0.0
    c = Counter(b)
    n = len(b)
    return -sum((v / n) * math.log2(v / n) for v in c.values())


def _ascii(b: bytes) -> str:
    return "".join(chr(x) if 32 <= x < 127 else "." for x in b)


# --------------------------------------------------------------------------
# read_hex
# --------------------------------------------------------------------------
def read_hex(dump: Dump, offset: int, length: int = 16) -> dict[str, Any]:
    seg = dump.data[offset : offset + length]
    return {
        "offset": hex(offset),
        "length": len(seg),
        "hex": seg.hex(" "),
        "ascii": _ascii(seg),
    }


# --------------------------------------------------------------------------
# search_patterns — substring / regex / VIN heuristic
# --------------------------------------------------------------------------
def search_patterns(dump: Dump, pattern: str, is_regex: bool = False) -> dict[str, Any]:
    hits: list[dict[str, Any]] = []
    if is_regex:
        for m in re.finditer(pattern.encode(), dump.data):
            hits.append({"offset": hex(m.start()), "match": _ascii(m.group())})
    else:
        needle = pattern.encode() if not all(c in "0123456789abcdefABCDEF " for c in pattern) else bytes.fromhex(pattern.replace(" ", ""))
        i = dump.data.find(needle)
        while i != -1:
            hits.append({"offset": hex(i), "match": needle.hex(" ")})
            i = dump.data.find(needle, i + 1)
    return {"pattern": pattern, "count": len(hits), "hits": hits}


def find_vins(dump: Dump) -> dict[str, Any]:
    """FCA VIN heuristic: 17-char VINs with a plausible WMI and the
    correct structure. FCA/Stellantis NA WMIs start with 1C/2C/3C/ZD/etc.
    Position 9 is a check digit (0-9 or X); positions 10-17 are the serial.
    This is deliberately strict to avoid matching part-number fragments."""
    FCA_WMI = ("1C3", "1C4", "1C6", "2C3", "2C4", "3C4", "3C6", "ZAC", "ZDF")
    vins: dict[str, list[str]] = {}
    for m in re.finditer(rb"[A-HJ-NPR-Z0-9]{17}", dump.data):
        s = m.group().decode("latin1")
        if s[:3] not in FCA_WMI:
            continue
        # model-year code (pos 10) must be a valid VIN year char, plant (pos 11) a letter
        if not (s[9].isalnum() and s[10].isalpha()):
            continue
        vins.setdefault(s, []).append(hex(m.start()))
    return {"vins": vins, "distinct": len(vins)}


# --------------------------------------------------------------------------
# key_secrets_scan — high-entropy 16-byte blocks + mirror detection
# --------------------------------------------------------------------------
def key_secrets_scan(dump: Dump, block: int = 16, ent_threshold: float = 3.6) -> dict[str, Any]:
    data = dump.data
    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    off = 0
    while off < len(data) - block:
        w = data[off : off + block]
        # printable-ASCII ratio: real crypto is binary, not text. Reject blocks
        # that are mostly printable (those are mirrored part-number/cal strings).
        printable = sum(1 for b in w if 32 <= b < 127)
        ascii_heavy = printable >= block * 0.75
        if w.count(0xFF) <= 3 and w.count(0x00) <= 6 and not ascii_heavy:
            h = _entropy(w)
            if h >= ent_threshold:
                key = w.hex()
                if key not in seen:
                    seen.add(key)
                    nxt = data.find(w, off + 1)
                    mirrored = nxt != -1 and (nxt - off) <= 64
                    candidates.append({
                        "offset": hex(off),
                        "value": w.hex(" "),
                        "entropy": round(h, 2),
                        "mirrored": mirrored,
                        "mirror_offset": hex(nxt) if mirrored else None,
                    })
        off += block
    return {"block_size": block, "candidates": candidates, "count": len(candidates)}


# --------------------------------------------------------------------------
# eeprom_layout_scan — region map by fill state
# --------------------------------------------------------------------------
def eeprom_layout_scan(dump: Dump, win: int = 16) -> dict[str, Any]:
    data = dump.data
    runs: list[dict[str, Any]] = []
    cur_type = None
    start = 0

    def classify(w: bytes) -> str:
        if all(b == 0xFF for b in w):
            return "blank"
        if all(b == 0x00 for b in w):
            return "zero"
        if _entropy(w) >= 3.6 and w.count(0xFF) <= 3:
            return "highent"
        return "data"

    for off in range(0, len(data), win):
        t = classify(data[off : off + win])
        if t != cur_type:
            if cur_type is not None:
                runs.append({"start": hex(start), "end": hex(off), "type": cur_type})
            cur_type = t
            start = off
    if cur_type is not None:
        runs.append({"start": hex(start), "end": hex(len(data)), "type": cur_type})

    summary = Counter(r["type"] for r in runs)
    return {
        "size": len(data),
        "regions": runs,
        "region_counts": dict(summary),
        "vins": find_vins(dump)["vins"],
    }


# --------------------------------------------------------------------------
# parse_module — printable strings that look like part/hw numbers
# --------------------------------------------------------------------------
def parse_module(dump: Dump) -> dict[str, Any]:
    strings: list[dict[str, str]] = []
    for m in re.finditer(rb"[ -~]{6,}", dump.data):
        s = m.group().decode("latin1")
        strings.append({"offset": hex(m.start()), "text": s})
    # FCA part numbers: 8 digits + 2 letters (e.g. 68441616AA)
    part_nos = [s for s in strings if re.fullmatch(r"\d{8}[A-Z]{2}", s["text"])]
    return {"strings": strings[:40], "part_number_candidates": part_nos, "vins": find_vins(dump)["vins"]}


# --------------------------------------------------------------------------
# uds_static_decode — known UDS/DID constants present as bytes
# --------------------------------------------------------------------------
FCA_DIDS = {
    b"\xF1\x90": "VIN (DID 0xF190)",
    b"\x20\x23": "PROXI (DID 0x2023)",
    b"\xF1\x8C": "ECU Serial (DID 0xF18C)",
}
UDS_SERVICES = {0x27: "SecurityAccess", 0x2E: "WriteDataByID", 0x22: "ReadDataByID", 0x31: "RoutineControl"}


def uds_static_decode(dump: Dump) -> dict[str, Any]:
    found = []
    for did, label in FCA_DIDS.items():
        i = dump.data.find(did)
        if i != -1:
            found.append({"offset": hex(i), "did": did.hex(), "label": label})
    return {"did_constants": found}


# --------------------------------------------------------------------------
# pattern_lookup — tiny built-in signature library (extend in repo)
# --------------------------------------------------------------------------
SIGNATURES = [
    {"name": "mirrored_aes_secret", "desc": "16-byte high-entropy block stored twice with ffff delimiter — FCA immobilizer secret signature"},
    {"name": "fca_vin_slot", "desc": "17-char VIN string; modules store 2-3 copies, all should agree"},
    {"name": "continental_rfhub", "desc": "RFHub part 68xxxxxxAA, Continental supplier"},
]


def pattern_lookup(name: str) -> dict[str, Any]:
    for s in SIGNATURES:
        if s["name"] == name:
            return {"found": True, **s}
    return {"found": False, "name": name}
