# SRT Lab Investigation Swarm — working version

Runs **right now** on FCA ECU dumps. Real deterministic byte analysis, five
read-only specialist agents, a coordinator that merges/dedupes/ranks. No LLM and
no network required to execute — the agent logic is rule-based and mirrors what
each specialist prompt instructs.

## Run it

```bash
cd investigation-swarm-working
python3 investigate.py <target.bin> [reference.bin]

# examples:
python3 investigate.py RFH_donor.bin                 # solo
python3 investigate.py RFH_donor.bin good_charger.bin # with cross-ref
```

## What it found on real dumps (validated against manual analysis)

- **Donor RFHub**: flagged mirrored immobilizer secrets at `0x510` / `0xb80`,
  concluded "module appears married," and CROSS_REF reported those secrets are
  absent from the good-Charger reference — "consistent with a foreign/donor
  marriage." Same conclusion the manual teardown reached, in one run.
- **Recovered BAD_RFHUB**: no high-confidence secret findings — correctly shows
  the module self-cleared its secrets.

## Files

- `tools/fca_tools.py` — real tool implementations: `read_hex`,
  `search_patterns`, `key_secrets_scan` (entropy + mirror detection, ASCII-block
  rejection), `eeprom_layout_scan` (region map + strict FCA-WMI VIN detection),
  `parse_module`, `uds_static_decode`, `pattern_lookup`.
- `swarm_run.py` — five agents + guarded dispatch (`ForbiddenTool` on any
  write/UDS tool) + coordinator merge/dedupe/contradiction.
- `investigate.py` — CLI.

## Honest limits

- The `0.50`-confidence "high-entropy block" tail is normal config data crossing
  the entropy floor. Real secrets are promoted to `0.85` by mirror detection, so
  the signal isn't buried — but the entropy floor + alignment want tuning against
  a larger known-dump corpus (this is what the Pattern Library / KG dependency
  feeds).
- **Static only.** This analyzes dumps. It cannot see a live UDS session and will
  not diagnose a runtime RF Hub Replacement timeout — that remains a J2534-trace
  question.

## Repo path (LLM-driven version)

The TypeScript core (`investigation-swarm/`) is the API-server version: same tool
contracts and coordinator, driven by the Anthropic Messages API instead of the
rule-based driver. Wire `ToolExecutor` to these same `fca_tools` analyses (port to
TS or call via a bridge) and `ModelClient` to your Anthropic client.
