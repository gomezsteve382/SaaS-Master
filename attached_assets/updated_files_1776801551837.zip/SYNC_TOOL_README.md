# SRT Lab — Module Sync Tool

**Offline BCM ↔ RFHUB VIN sync for 2017 and below FCA modules.** Reads both dumps, 
shows you what's in them, and generates correctly-patched bins with VIN, CRC-16, 
and checksums all updated so the modules boot paired.

## Three files delivered

1. **`SRTLAB_SYNC_TOOL.html`** — standalone web UI. Open in any browser. Zero setup.
2. **`ModuleSync.jsx`** — React component for the SRT Lab monorepo.
3. **`srtlab_validate.py`** — CLI validator to sanity-check dumps before AND after sync.

## What it supports

- **BCM**: Huntsville Continental MPC5606B DFLASH dumps
  - P/N `68525720AA` family (2014-2015 LX: 300, Charger, Challenger)
  - P/N `68277389AC` family (2015-2017 LX/LD: Scat Pack, R/T, SRT)
  - Auto-detects VIN slot offsets — works whether VINs are at 0x5308 or 0x1308
- **RFHUB**: Yazaki FCM Gen2 EEPROM dumps  
  - P/N `AA30712804` family with various BA-prefix part numbers

## The CRC finding

The **2-byte trailer after each VIN in the BCM is a CRC-16/CCITT** (init=0xFFFF, poly=0x1021, 
stored big-endian). Verified across three different VINs:

| VIN                   | CRC-16 stored   | Computed  |
|-----------------------|-----------------|-----------|
| `2C3CDXKT3FH796320`   | `0x2D56`        | `0x2D56`  |
| `2C3CDXHG7GH214845`   | `0x0D7F`        | `0x0D7F`  |
| `2C3CDXEJ1FH857853`   | `0x74B0`        | `0x74B0`  |

**The sync tool automatically recomputes this CRC when writing a new VIN.** If you 
flash a BCM bin with a stale VIN CRC, the module may behave oddly (programming tools 
reading VIN-CRC mismatches have unpredictable behavior).

## The RFHUB checksum finding

The **18th byte of each RFHUB VIN slot is a checksum**: `chk = (0xF9 - sum(reversed_VIN)) & 0xFF`

Verified across 2015-2017 LX platforms. Older 2011-era modules use `(0xFA - sum)` — the 
validator warns on mismatch rather than erroring so you can tell which variant you have.

## Sync actions (unchanged from before)

- **➡ RFH VIN → BCM**: Copy RFHUB VIN into BCM at all 4 slots, recompute CRC-16
- **⬅ BCM VIN → RFH**: Copy BCM VIN into RFHUB (byte-reversed), recompute checksum
- **🎯 TARGET VIN → BOTH**: Write typed VIN into both modules with correct CRCs/checksums
- **🆕 VIRGINIZE checkbox**: Wipes RFHUB SEC16 slots to FF so modules re-pair on power-up

## Validation before AND after

The `srtlab_validate.py` script checks dumps for:
- BCM: FEE1000 magic, bank sequence numbers, VIN consistency, **VIN CRC-16 validity**
- RFHUB: VIN consistency (reversed decode), **VIN checksum validity**, SEC16 slot state
- Pairing: BCM and RFHUB must both carry the same VIN or tools will fail

Usage:
```
python srtlab_validate.py --bcm my_bcm.bin --rfh my_rfhub.bin
```

Run this on:
- Dumps you just pulled off bench (sanity check before anything)
- Dumps the sync tool generated (sanity check before flashing)
- Dumps from OTHER tools (e.g., ImmoVin) to see if they did the CRC right

## Typical workflow for a salvage rebuild

1. Pull EEPROM dumps off bench via MultiProg/UPA/OBDStar
2. `python srtlab_validate.py --bcm bcm.bin --rfh rfh.bin` — confirm dumps are healthy
3. Open `SRTLAB_SYNC_TOOL.html` in a browser
4. Drop both bins, type target VIN, check virginize, click Target → Both
5. `python srtlab_validate.py --bcm BCM_SYNCED_*.bin --rfh RFH_SYNCED_*.bin` — confirm output
6. Flash both bins to their modules
7. Power-cycle the bench 30 seconds
8. Program keys with dealer PIN

## What the tool does NOT do

- **ECM VIN programming**: GPEC2A ECM uses XTEA with key `DAIMLERCHRYSLER3` — separate path
- **PIN extraction**: the 4-digit dealer PIN is not stored plaintext in these dumps. 
  Path to extract it would require firmware RE of the RFHUB's `CryLib.c` / `SecVer.c` 
  (we identified these in Angel's full pflash dump).
- **Key programming**: this is VIN sync only. Key learn happens via UDS routine 
  `31 01 03 9C` after the modules are paired and unlocked.

## Verified end-to-end

- 2017 LX Scat Pack salvage (FH796320 + FH795771) → correctly flagged as mismatched
- 2016 LD Scat Pack factory (both GH214845) → correctly flagged as paired
- ImmoVin-edited set (both FH857853, SEC16 from 2016 donor) → SEC16 needs virginize
- Round-trip sync: target VIN 2C3CDXL90MH582899 → BCM CRC=0x6AEE (verified), RFH chk=0xDF (verified)
