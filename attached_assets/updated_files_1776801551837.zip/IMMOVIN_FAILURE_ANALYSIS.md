# Diagnosis: "Password Couldn't Be Read" + 5-Min Lockout

## TL;DR

The ImmoVin-style tool that produced your `immovin_f1bf3d1830604c8b96fe15cbc1d0dc0a` 
RFHUB and `MPC5606B_DFLASH_17SCAT_RAMON_CHERRY_EDIT` BCM did a **VIN-only edit** on 
donor modules from a 2016 Scat Pack. It correctly updated the VIN bytes and the VIN 
CRC-16 checksums. **But it did not virginize the RFHUB's SEC16 slots.**

The "password couldn't be read" error when you tried key programming isn't about the 
actual car PIN (9259) — it's the programming tool failing its internal consistency 
check because the donor modules still carry their old factory pairing state.

## What's actually in the files

### BCM (`MPC5606B_DFLASH_17SCAT_RAMON_CHERRY_EDIT.bin`)

- **Origin**: 2016 Scat Pack donor BCM, Mopar P/N `68277389AC` / `68277390AC`
- **Original VIN**: `2C3CDXHG7GH214845`  
- **Edit result**: VIN changed to `2C3CDXEJ1FH857853` (target: 2015 Charger)
- **VIN CRC-16 (at byte 18-19 of each slot)**: correctly recomputed to `74 B0`
- **44 bytes changed total** — exactly VIN + CRC, nothing else touched
- **No other VIN-derived data** in the BCM (I searched every 2-byte value pattern)

### RFHUB (`immovin_....bin`)

- **Origin**: 2016 Scat Pack donor RFHUB, same factory pair as the BCM above
- **VIN slots (4 × reversed)**: now reading as `2C3CDXEJ1FH857853` ✓
- **VIN checksum (byte 18 of each slot)**: correctly recomputed to `E0`  
- **SEC16 slots (0x0226 + 0x023A)**: STILL the 2016 Scat Pack's original values
  - `26CC6754F19EEE18E3C0653BE2A673106600` — identical in both slots
- **Both modules still mutually paired** via this SEC16 — they'll handshake fine

### ECM (`FCA_CONTINENTAL_GPEC2A_EXT_EEPROM_2C3CDXEJ1FH857853_OG.bin`)

- GPEC2A external EEPROM from the TARGET car (2015 Charger, same VIN `FH857853`)
- Different module family (Continental GPEC2A, XTEA-based auth)
- Separate from the BCM/RFHUB issue — address ECM VIN programming separately

## Why key programming fails

Your programming tool's flow is likely:

1. ✓ Read VIN from BCM → returns `2C3CDXEJ1FH857853`
2. ✓ Look up PIN for that VIN (from its DB or Chrysler's server) → gets `9259`
3. **? Read PIN/secret from RFHUB or BCM** → **FAILS** → "password couldn't be read"

The tool is trying to verify the module's internal PIN state matches what Chrysler's 
database says. Since these are donor modules, their internal PIN state is tied to the 
ORIGINAL 2016 Scat Pack, not the target VIN `FH857853`. The consistency check bombs out.

The 5-minute delay is the tool's own retry lockout, not the BCM's. No actual UDS 
security-access failures happened yet.

## The fix

You need to reset the immobilizer state so the modules accept fresh programming. 
The easiest way: **virginize the SEC16 AND re-run VIN programming with SRT Lab Sync Tool**.

### Option 1 — Use my sync tool with virginize (recommended)

1. Drop `MPC5606B_DFLASH_17SCAT_RAMON_CHERRY_EDIT.bin` and `immovin_....bin` into the 
   SRT Lab Sync Tool
2. Type target VIN `2C3CDXEJ1FH857853` in the input
3. **Check the virginize checkbox**
4. Click "🎯 TARGET VIN → BOTH"
5. Flash both new bins to their modules
6. Power-cycle the bench 30 seconds
7. Now try key programming with PIN 9259

The virginize step wipes RFHUB SEC16 slots to `0xFF FF...`. On first power-up after flash, 
BCM and RFHUB will negotiate a fresh SEC16. At that point the dealer PIN (9259) should 
authenticate cleanly because the modules are in a fresh-pairing state.

### Option 2 — Try key programming again but with exhaustive pre-work

1. Make sure the BCM IS flashed (you might have only flashed the RFHUB, based on file naming)
2. Power everything down for 30+ seconds
3. Power back up, wait 30 seconds for BCM↔RFHUB handshake  
4. THEN start key programming with PIN 9259

The 5-min lockout should clear if you power-cycle and wait. If the lockout is in the 
BCM's EEPROM (not just the tool's cache), it'll need a full 5 minutes of continuous 
power.

### Option 3 — Use OBDStar/wiTECH's "Immo System Reset" 

Some dealer tools have a specific routine to reset the immobilizer system state without 
full module replacement. Look for "Immo Reset", "Secret Key Reset", or "Pair Modules" 
options in your tool. These might succeed where straight key-add fails on donor modules.

## What about ECM VIN?

The ECM dump `FCA_CONTINENTAL_GPEC2A_EXT_EEPROM_2C3CDXEJ1FH857853_OG.bin` is for the 
same VIN — good. GPEC2A uses a completely different auth scheme (XTEA with FCA's 
`DAIMLERCHRYSLER3` key). The ECM VIN is usually written via UDS after security access, 
not by direct flash editing. Leave the ECM alone and write its VIN via UDS once the 
BCM/RFHUB are clean.

## What I'd verify before your next attempt

1. Check that BOTH modules got flashed with the edited bins (not just RFHUB)
2. Read VIN from each module via UDS 22 F1 90 after flash to confirm they report 
   `2C3CDXEJ1FH857853`
3. If the BCM was never flashed and still has `2C3CDXHG7GH214845`, that's your real 
   problem right there — programming tool sees VIN mismatch across modules, refuses 
   to continue
