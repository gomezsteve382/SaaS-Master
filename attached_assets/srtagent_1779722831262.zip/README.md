# Multi-Agent Investigation Swarm — domain core

Read-only, transport-agnostic core for the FCA ECU investigation swarm. Built to
drop into `artifacts/api-server/src/routes/anthropic/`. All 12 Vitest cases pass.

## What's here (spec steps 1, 2, 3-schema, 5, 6)

- **`src/agents.ts`** — Step 1. Five FCA-domain specialist prompts (CRYPTO,
  PROTOCOL, LAYOUT, IMMOBILIZER, CROSS_REF) + COORDINATOR. Per-agent tool
  subsets, iteration caps (default 8), and the findings JSON contract. A
  load-time assertion guarantees no agent declares a non-read-only tool.
- **`src/coordinator.ts`** — Step 2 + Step 5. Parallel `Promise.allSettled`
  fan-out, per-agent tool-use loop, **read-only guard** (`ForbiddenToolError`),
  cumulative token budget, cancellation via `AbortSignal`, deterministic
  merge/dedupe/contradiction detection, and model-backed synthesis with a
  deterministic fallback.
- **`src/sse.ts`** — Step 3. SSE frame (de)serialization matching the tool-use
  loop's shape with a per-agent prefix, plus the `investigation_runs` +
  `investigation_agent_findings` schema (SQL + row types).
- **`test/swarm.test.ts`** — Step 6. Guard, merge, contradiction, SSE,
  cancellation, budget, and a synthetic two-agent end-to-end run through
  synthesis + persistence.

## What's deliberately NOT here

- **The real tool executor.** `ToolExecutor` is an interface; wire it to the
  tool-use loop's actual `read_hex` / `key_secrets_scan` / `eeprom_layout_scan`
  / etc. once those signatures are stable. The swarm depends on that open task —
  this core is the part that's testable without it.
- **The real `ModelClient`.** Inject your Anthropic Messages client. It must
  pass `allowedTools` straight through as the API `tools` array so the model
  physically cannot emit a tool outside the allowlist.
- **UI** (Step 4) — `InvestigationTab` + the Inspector "Investigate" launcher
  live in `artifacts/srt-lab/src/`. The SSE event union in `coordinator.ts` is
  the contract the UI columns key off (`event.agent` → column, `synthesis` →
  right pane, `agent_aborted`/`budget_exceeded` → status chips).

## Wiring checklist

1. Implement `ModelClient.runTurn` against `moduleAssistant.ts`'s Anthropic
   client; map `allowedTools` → API `tools`.
2. Implement `ToolExecutor.execute` against the tool-use loop registry. Keep
   `READ_ONLY_TOOLS` in `agents.ts` in lockstep with that registry.
3. Run `CREATE_TABLES_SQL` (or port to Drizzle) and pass a `persist` callback.
4. Add an SSE route that calls `runSwarm` and pipes `emit` through `toSseFrame`.
   Pass the request's `AbortController.signal`; the UI cancel button aborts it.
5. Build `InvestigationTab` against the `SwarmEvent` union.

## Read-only guarantee

Three layers: agents only *declare* read-only tools (load-time assertion); the
orchestrator refuses any tool not in the agent's allowlist at dispatch
(`assertToolAllowed`); and `FORBIDDEN_TOOLS` is an explicit denylist for audit
logging. Even a prompt-injection inside a dump that says "call flash_module"
results in `ForbiddenToolError` → that agent aborts, the run continues, an
`agent_error` event is emitted. No swarm agent can write bytes or touch a
vehicle.
