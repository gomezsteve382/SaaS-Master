/**
 * Multi-Agent Investigation Swarm — coordinator / orchestrator
 *
 * Runs the specialist agents in parallel against a loaded dump, enforces the
 * read-only guard + token/iteration budgets, streams per-agent SSE events, and
 * synthesizes the unified report.
 *
 * Transport-agnostic: the Anthropic client and the tool executor are injected,
 * so tests drive a synthetic run with a mock transport (see test/swarm.test.ts).
 */

import {
  AGENTS,
  COORDINATOR_SYSTEM,
  FORBIDDEN_TOOLS,
  READ_ONLY_TOOLS,
  type AgentDef,
  type AgentId,
  type ReadOnlyTool,
} from "./agents";

// ---- Injected dependencies -------------------------------------------------

/** A single tool call requested by an agent. */
export interface ToolCall {
  name: string;
  input: Record<string, unknown>;
}

/** Result of executing a tool. Read-only tools only. */
export interface ToolResult {
  name: string;
  output: unknown;
}

/**
 * Minimal model-turn abstraction. Returns either tool calls to execute or a
 * final text payload (expected to be the agent's JSON findings object).
 */
export interface ModelTurn {
  toolCalls: ToolCall[];
  finalText: string | null;
  /** Tokens consumed this turn, for budget accounting. */
  tokensUsed: number;
}

export interface ModelClient {
  /**
   * Run one model turn for an agent. Implementations append the prior
   * messages + any tool results and call the Anthropic Messages API with the
   * agent's tool allowlist. `signal` aborts an in-flight request.
   */
  runTurn(args: {
    system: string;
    messages: unknown[];
    allowedTools: ReadOnlyTool[];
    signal: AbortSignal;
  }): Promise<ModelTurn>;
}

/** Executes a read-only analysis tool against the loaded dump(s). */
export interface ToolExecutor {
  execute(call: ToolCall, signal: AbortSignal): Promise<ToolResult>;
}

// ---- SSE event protocol ----------------------------------------------------
// Reuses the tool-use loop's streaming shape, prefixed per agent. The UI keys
// a column on `agent` and renders `synthesis` events in the right-hand pane.

export type SwarmEvent =
  | { type: "agent_start"; agent: AgentId; ts: number }
  | { type: "agent_tool_call"; agent: AgentId; tool: string; input: unknown; ts: number }
  | { type: "agent_tool_result"; agent: AgentId; tool: string; ok: boolean; ts: number }
  | { type: "agent_partial"; agent: AgentId; note: string; confidence?: number; ts: number }
  | { type: "agent_done"; agent: AgentId; findings: AgentFindings; ts: number }
  | { type: "agent_error"; agent: AgentId; error: string; ts: number }
  | { type: "agent_aborted"; agent: AgentId; reason: string; ts: number }
  | { type: "synthesis"; report: UnifiedReport; ts: number }
  | { type: "run_done"; runId: string; ts: number }
  | { type: "budget_exceeded"; scope: "tokens"; used: number; cap: number; ts: number };

export type EmitFn = (e: SwarmEvent) => void;

// ---- Finding / report shapes ----------------------------------------------

export interface Finding {
  id: string;
  title: string;
  detail: string;
  offsets: string[];
  confidence: number;
  evidence: string[];
  status: "VERIFIED" | "UNVERIFIED";
}

export interface AgentFindings {
  agent: AgentId;
  findings: Finding[];
  gaps: string[];
  needs: string[];
}

export interface UnifiedReport {
  summary: string;
  findings: (Finding & { sources: AgentId[] })[];
  contradictions: {
    topic: string;
    positions: { agent: AgentId; claim: string; confidence: number }[];
    adjudication: string;
    confidence: number;
  }[];
  gaps: string[];
  recommended_next_steps: string[];
}

// ---- Guards ----------------------------------------------------------------

export class ForbiddenToolError extends Error {
  constructor(public agent: AgentId, public tool: string) {
    super(`Agent ${agent} attempted forbidden tool "${tool}" — swarm is read-only`);
    this.name = "ForbiddenToolError";
  }
}

/** True iff `name` is a permitted read-only tool. */
export function isReadOnlyTool(name: string): name is ReadOnlyTool {
  return (READ_ONLY_TOOLS as readonly string[]).includes(name);
}

function assertToolAllowed(agent: AgentDef, call: ToolCall): void {
  if ((FORBIDDEN_TOOLS as readonly string[]).includes(call.name) || !isReadOnlyTool(call.name)) {
    throw new ForbiddenToolError(agent.id, call.name);
  }
  if (!agent.tools.includes(call.name)) {
    // In-scope-but-not-for-this-agent: also refused, keeps specialties clean.
    throw new ForbiddenToolError(agent.id, call.name);
  }
}

// ---- Config ----------------------------------------------------------------

export interface SwarmConfig {
  /** Cumulative token budget across the whole run. */
  tokenBudget: number;
  /** Override per-agent iteration caps (defaults come from each AgentDef). */
  maxIterationsOverride?: number;
  /** Which agents to run; defaults to all five. */
  agents?: AgentId[];
}

export const DEFAULT_CONFIG: SwarmConfig = {
  tokenBudget: 200_000,
};

// ---- Single-agent loop -----------------------------------------------------

interface RunAgentDeps {
  model: ModelClient;
  tools: ToolExecutor;
  emit: EmitFn;
  signal: AbortSignal;
  /** Shared token accounting; returns false if the budget is now exhausted. */
  spend: (tokens: number) => boolean;
}

async function runAgent(
  agent: AgentDef,
  initialUserMessage: unknown,
  maxIterations: number,
  deps: RunAgentDeps,
): Promise<AgentFindings> {
  const { model, tools, emit, signal, spend } = deps;
  emit({ type: "agent_start", agent: agent.id, ts: Date.now() });

  const messages: unknown[] = [initialUserMessage];

  for (let i = 0; i < maxIterations; i++) {
    if (signal.aborted) {
      emit({ type: "agent_aborted", agent: agent.id, reason: "cancelled", ts: Date.now() });
      return emptyFindings(agent.id, "aborted before completion");
    }

    const turn = await model.runTurn({
      system: agent.system,
      messages,
      allowedTools: agent.tools,
      signal,
    });

    if (!spend(turn.tokensUsed)) {
      emit({ type: "agent_aborted", agent: agent.id, reason: "token budget", ts: Date.now() });
      return finalizeFromText(agent, turn.finalText) ?? emptyFindings(agent.id, "budget exhausted");
    }

    // Final answer this turn → parse and return.
    if (turn.finalText) {
      const parsed = finalizeFromText(agent, turn.finalText);
      if (parsed) {
        emit({ type: "agent_done", agent: agent.id, findings: parsed, ts: Date.now() });
        return parsed;
      }
      // Non-JSON final text: nudge once by feeding it back, else finalize empty.
      messages.push({ role: "assistant", content: turn.finalText });
      messages.push({
        role: "user",
        content: "Your previous message was not valid findings JSON. Re-emit JSON only.",
      });
      continue;
    }

    // Otherwise execute the requested tool calls, guarding each.
    const results: ToolResult[] = [];
    for (const call of turn.toolCalls) {
      assertToolAllowed(agent, call); // throws ForbiddenToolError → aborts run
      emit({ type: "agent_tool_call", agent: agent.id, tool: call.name, input: call.input, ts: Date.now() });
      try {
        const res = await tools.execute(call, signal);
        results.push(res);
        emit({ type: "agent_tool_result", agent: agent.id, tool: call.name, ok: true, ts: Date.now() });
      } catch (err) {
        results.push({ name: call.name, output: { error: String(err) } });
        emit({ type: "agent_tool_result", agent: agent.id, tool: call.name, ok: false, ts: Date.now() });
      }
    }
    messages.push({ role: "assistant", content: turn.toolCalls });
    messages.push({ role: "tool", content: results });
  }

  // Hit the iteration cap without a final answer.
  emit({ type: "agent_partial", agent: agent.id, note: "iteration cap reached", ts: Date.now() });
  return emptyFindings(agent.id, "iteration cap reached without finalization");
}

function emptyFindings(agent: AgentId, reason: string): AgentFindings {
  return { agent, findings: [], gaps: [reason], needs: [] };
}

function finalizeFromText(agent: AgentDef, text: string | null): AgentFindings | null {
  if (!text) return null;
  const json = extractJson(text);
  if (!json) return null;
  try {
    const obj = JSON.parse(json) as AgentFindings;
    if (obj && Array.isArray(obj.findings)) {
      return {
        agent: agent.id,
        findings: obj.findings ?? [],
        gaps: obj.gaps ?? [],
        needs: obj.needs ?? [],
      };
    }
  } catch {
    /* fallthrough */
  }
  return null;
}

/** Pull the first balanced top-level JSON object out of a text blob. */
export function extractJson(text: string): string | null {
  const start = text.indexOf("{");
  if (start === -1) return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
    } else if (c === '"') inStr = true;
    else if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

// ---- Coordinator: parallel run + synthesis ---------------------------------

export interface RunSwarmArgs {
  runId: string;
  /** The user/operator framing message — typically describes the loaded dump(s). */
  initialUserMessage: unknown;
  model: ModelClient;
  tools: ToolExecutor;
  emit: EmitFn;
  signal: AbortSignal;
  config?: Partial<SwarmConfig>;
  /** Persist a completed run; injected so tests can assert on it. */
  persist?: (row: PersistedRun) => Promise<void>;
}

export interface PersistedRun {
  runId: string;
  agentFindings: AgentFindings[];
  report: UnifiedReport;
  aborted: boolean;
  tokensUsed: number;
}

export async function runSwarm(args: RunSwarmArgs): Promise<PersistedRun> {
  const cfg: SwarmConfig = { ...DEFAULT_CONFIG, ...args.config };
  const ids = cfg.agents ?? (Object.keys(AGENTS) as AgentId[]);

  let tokensUsed = 0;
  let budgetBlown = false;
  const spend = (t: number): boolean => {
    tokensUsed += t;
    if (tokensUsed > cfg.tokenBudget && !budgetBlown) {
      budgetBlown = true;
      args.emit({ type: "budget_exceeded", scope: "tokens", used: tokensUsed, cap: cfg.tokenBudget, ts: Date.now() });
    }
    return !budgetBlown;
  };

  const deps: RunAgentDeps = {
    model: args.model,
    tools: args.tools,
    emit: args.emit,
    signal: args.signal,
    spend,
  };

  // Promise.all-style parallel fan-out. Each agent is independently guarded and
  // cancellable; one agent erroring does not kill the others (settled, not all).
  const settled = await Promise.allSettled(
    ids.map((id) => {
      const def = AGENTS[id];
      const cap = cfg.maxIterationsOverride ?? def.maxIterations;
      return runAgent(def, args.initialUserMessage, cap, deps);
    }),
  );

  const agentFindings: AgentFindings[] = settled.map((s, idx) => {
    if (s.status === "fulfilled") return s.value;
    const id = ids[idx];
    args.emit({ type: "agent_error", agent: id, error: String(s.reason), ts: Date.now() });
    return emptyFindings(id, `agent failed: ${String(s.reason)}`);
  });

  const report = await synthesize(agentFindings, deps, args.initialUserMessage);
  args.emit({ type: "synthesis", report, ts: Date.now() });

  const row: PersistedRun = {
    runId: args.runId,
    agentFindings,
    report,
    aborted: args.signal.aborted || budgetBlown,
    tokensUsed,
  };
  if (args.persist) await args.persist(row);
  args.emit({ type: "run_done", runId: args.runId, ts: Date.now() });
  return row;
}

/**
 * Synthesis. We do a deterministic local merge/dedupe first (so the report is
 * never worse than mechanical union), then hand the merged material to the
 * coordinator model for adjudication + ranking. If the model fails or is over
 * budget, we fall back to the deterministic merge.
 */
export async function synthesize(
  agentFindings: AgentFindings[],
  deps: RunAgentDeps,
  initialUserMessage: unknown,
): Promise<UnifiedReport> {
  const merged = deterministicMerge(agentFindings);

  if (deps.signal.aborted) return merged;

  try {
    const turn = await deps.model.runTurn({
      system: COORDINATOR_SYSTEM,
      messages: [
        initialUserMessage,
        { role: "user", content: JSON.stringify({ agentFindings, deterministicMerge: merged }) },
      ],
      allowedTools: [], // coordinator synthesizes; it does not call tools
      signal: deps.signal,
    });
    deps.spend(turn.tokensUsed);
    const json = extractJson(turn.finalText ?? "");
    if (json) {
      const parsed = JSON.parse(json) as UnifiedReport;
      if (parsed && Array.isArray(parsed.findings)) return parsed;
    }
  } catch {
    /* fall back to deterministic merge below */
  }
  return merged;
}

/**
 * Deterministic merge: dedupe findings by (sorted offsets + normalized title),
 * union evidence + sources, keep max confidence, and aggregate gaps/needs.
 * Contradictions are detected as same-offset findings whose status disagrees
 * (one VERIFIED-normal vs one flagged), surfaced for the model/operator.
 */
export function deterministicMerge(agentFindings: AgentFindings[]): UnifiedReport {
  const byKey = new Map<string, Finding & { sources: AgentId[] }>();
  const offsetIndex = new Map<string, (Finding & { sources: AgentId[] })[]>();

  for (const af of agentFindings) {
    for (const f of af.findings) {
      const key = `${[...f.offsets].sort().join(",")}|${f.title.trim().toLowerCase()}`;
      const existing = byKey.get(key);
      if (existing) {
        existing.confidence = Math.max(existing.confidence, f.confidence);
        existing.evidence = [...new Set([...existing.evidence, ...f.evidence])];
        if (!existing.sources.includes(af.agent)) existing.sources.push(af.agent);
        if (f.status === "VERIFIED") existing.status = "VERIFIED";
      } else {
        const merged = { ...f, sources: [af.agent] };
        byKey.set(key, merged);
        for (const off of f.offsets) {
          const arr = offsetIndex.get(off) ?? [];
          arr.push(merged);
          offsetIndex.set(off, arr);
        }
      }
    }
  }

  // Contradiction heuristic: same offset, differing status across sources.
  const contradictions: UnifiedReport["contradictions"] = [];
  for (const [off, arr] of offsetIndex) {
    if (arr.length < 2) continue;
    const statuses = new Set(arr.map((a) => a.status));
    if (statuses.size > 1) {
      contradictions.push({
        topic: `offset ${off}`,
        positions: arr.map((a) => ({
          agent: a.sources[0],
          claim: `${a.title} (${a.status})`,
          confidence: a.confidence,
        })),
        adjudication: "Unresolved by deterministic merge; operator/coordinator review.",
        confidence: 0.3,
      });
    }
  }

  const findings = [...byKey.values()].sort((a, b) => b.confidence - a.confidence);
  const gaps = [...new Set(agentFindings.flatMap((a) => a.gaps))];
  const needs = [...new Set(agentFindings.flatMap((a) => a.needs))];

  return {
    summary: `Deterministic merge of ${agentFindings.length} agent report(s): ` +
      `${findings.length} distinct finding(s), ${contradictions.length} contradiction(s).`,
    findings,
    contradictions,
    gaps,
    recommended_next_steps: needs,
  };
}
