/**
 * SSE serialization + persistence schema for swarm runs.
 *
 * The SSE format mirrors the existing tool-use loop stream so the frontend can
 * reuse its EventSource parser; we only add the per-agent prefix in the data
 * payload (the `agent` field on each event).
 */

import type { SwarmEvent, AgentFindings, UnifiedReport, AgentId } from "./coordinator";

/** Serialize one event as an SSE frame. `event:` lets the client switch on type. */
export function toSseFrame(e: SwarmEvent): string {
  return `event: ${e.type}\ndata: ${JSON.stringify(e)}\n\n`;
}

/** Parse a single SSE `data:` line back into an event (used in tests/clients). */
export function fromSseData(data: string): SwarmEvent {
  return JSON.parse(data) as SwarmEvent;
}

// ---- Persistence -----------------------------------------------------------
// New `investigation_runs` table (parent) + `investigation_agent_findings`
// (per-agent rows). Drizzle-style description kept framework-light so it can be
// adapted to the project's actual ORM in api-server.

export interface InvestigationRunRow {
  run_id: string;            // PK
  created_at: string;        // ISO
  dump_refs: string[];       // ids/paths of the loaded dump(s) investigated
  aborted: boolean;
  tokens_used: number;
  report_json: UnifiedReport;
}

export interface InvestigationAgentFindingRow {
  run_id: string;            // FK -> investigation_runs.run_id
  agent: AgentId;            // PK part
  findings_json: AgentFindings;
}

export const CREATE_TABLES_SQL = `
CREATE TABLE IF NOT EXISTS investigation_runs (
  run_id        TEXT PRIMARY KEY,
  created_at    TEXT NOT NULL,
  dump_refs     TEXT NOT NULL,           -- JSON array
  aborted       INTEGER NOT NULL DEFAULT 0,
  tokens_used   INTEGER NOT NULL DEFAULT 0,
  report_json   TEXT NOT NULL            -- JSON UnifiedReport
);

CREATE TABLE IF NOT EXISTS investigation_agent_findings (
  run_id        TEXT NOT NULL REFERENCES investigation_runs(run_id) ON DELETE CASCADE,
  agent         TEXT NOT NULL,
  findings_json TEXT NOT NULL,           -- JSON AgentFindings
  PRIMARY KEY (run_id, agent)
);

CREATE INDEX IF NOT EXISTS idx_inv_runs_created ON investigation_runs(created_at);
`;
