import { describe, it, expect, vi } from "vitest";
import {
  runSwarm,
  deterministicMerge,
  extractJson,
  isReadOnlyTool,
  ForbiddenToolError,
  type ModelClient,
  type ToolExecutor,
  type SwarmEvent,
  type AgentFindings,
  type ModelTurn,
} from "../src/coordinator";
import { AGENTS, READ_ONLY_TOOLS } from "../src/agents";
import { toSseFrame, fromSseData } from "../src/sse";

// --- helpers ----------------------------------------------------------------

function findingsJson(agent: string, conf: number, offset: string): string {
  return JSON.stringify({
    agent,
    findings: [
      {
        id: `${agent}-1`,
        title: "secret block",
        detail: `mirrored AES at ${offset}`,
        offsets: [offset],
        confidence: conf,
        evidence: [`key_secrets_scan ${offset}`],
        status: "VERIFIED",
      },
    ],
    gaps: [`${agent} gap`],
    needs: [`${agent} needs`],
  });
}

/** Model that returns a tool call on turn 0, then final JSON on turn 1. */
function scriptedModel(agentFinal: Record<string, string>): ModelClient {
  const calls = new Map<string, number>();
  return {
    async runTurn({ system }): Promise<ModelTurn> {
      // identify which agent by a marker in its system prompt
      const id = Object.values(AGENTS).find((a) => system.includes(a.system.slice(0, 40)))?.id
        ?? "COORDINATOR";
      const n = calls.get(id) ?? 0;
      calls.set(id, n + 1);

      if (id === "COORDINATOR") {
        return {
          toolCalls: [],
          finalText: JSON.stringify({
            summary: "synth ok",
            findings: [],
            contradictions: [],
            gaps: [],
            recommended_next_steps: [],
          }),
          tokensUsed: 10,
        };
      }
      if (n === 0) {
        return {
          toolCalls: [{ name: "read_hex", input: { offset: "0x510", len: 16 } }],
          finalText: null,
          tokensUsed: 5,
        };
      }
      return { toolCalls: [], finalText: agentFinal[id] ?? findingsJson(id, 0.9, "0x510"), tokensUsed: 5 };
    },
  };
}

const okExecutor: ToolExecutor = {
  async execute(call) {
    return { name: call.name, output: { bytes: "ab 80 15 d7" } };
  },
};

function collect(): { emit: (e: SwarmEvent) => void; events: SwarmEvent[] } {
  const events: SwarmEvent[] = [];
  return { emit: (e) => events.push(e), events };
}

// --- tests ------------------------------------------------------------------

describe("read-only guard", () => {
  it("every declared agent tool is in the read-only allowlist", () => {
    for (const def of Object.values(AGENTS)) {
      for (const t of def.tools) expect(READ_ONLY_TOOLS).toContain(t);
    }
  });

  it("isReadOnlyTool rejects vehicle/write tools", () => {
    expect(isReadOnlyTool("read_hex")).toBe(true);
    expect(isReadOnlyTool("uds_send")).toBe(false);
    expect(isReadOnlyTool("flash_module")).toBe(false);
  });

  it("an agent requesting a forbidden tool aborts that agent, not the run", async () => {
    const rogue: ModelClient = {
      async runTurn({ system }) {
        const isCoord = system.includes("COORDINATOR of an FCA");
        if (isCoord) {
          return { toolCalls: [], finalText: JSON.stringify({ summary: "", findings: [], contradictions: [], gaps: [], recommended_next_steps: [] }), tokensUsed: 1 };
        }
        return { toolCalls: [{ name: "flash_module", input: {} }], finalText: null, tokensUsed: 1 };
      },
    };
    const { emit, events } = collect();
    const ctrl = new AbortController();
    const res = await runSwarm({
      runId: "r1",
      initialUserMessage: { role: "user", content: "investigate" },
      model: rogue,
      tools: okExecutor,
      emit,
      signal: ctrl.signal,
      config: { agents: ["CRYPTO"] },
    });
    // run completes (didn't throw), CRYPTO produced empty findings via error path
    expect(res.agentFindings[0].findings).toHaveLength(0);
    expect(events.some((e) => e.type === "agent_error")).toBe(true);
  });
});

describe("deterministic merge", () => {
  it("dedupes same offset+title and unions sources + evidence", () => {
    const a: AgentFindings = JSON.parse(findingsJson("CRYPTO", 0.7, "0x510"));
    const b: AgentFindings = JSON.parse(findingsJson("IMMOBILIZER", 0.9, "0x510"));
    b.findings[0].evidence = ["pattern_lookup match"];
    const merged = deterministicMerge([a, b]);
    expect(merged.findings).toHaveLength(1);
    expect(merged.findings[0].confidence).toBe(0.9); // max
    expect(merged.findings[0].sources.sort()).toEqual(["CRYPTO", "IMMOBILIZER"]);
    expect(merged.findings[0].evidence).toContain("pattern_lookup match");
  });

  it("flags a contradiction when same offset has differing status", () => {
    const a: AgentFindings = JSON.parse(findingsJson("LAYOUT", 0.6, "0x280"));
    a.findings[0].title = "blank region (normal)";
    a.findings[0].status = "VERIFIED";
    const b: AgentFindings = JSON.parse(findingsJson("IMMOBILIZER", 0.6, "0x280"));
    b.findings[0].title = "cleared secret slot";
    b.findings[0].status = "UNVERIFIED";
    const merged = deterministicMerge([a, b]);
    expect(merged.contradictions.length).toBeGreaterThanOrEqual(1);
    expect(merged.contradictions[0].topic).toContain("0x280");
  });
});

describe("SSE protocol", () => {
  it("round-trips an event through frame/parse", () => {
    const e: SwarmEvent = { type: "agent_done", agent: "CRYPTO", findings: { agent: "CRYPTO", findings: [], gaps: [], needs: [] }, ts: 1 };
    const frame = toSseFrame(e);
    expect(frame).toContain("event: agent_done");
    const dataLine = frame.split("\n").find((l) => l.startsWith("data: "))!.slice(6);
    expect(fromSseData(dataLine)).toEqual(e);
  });
});

describe("extractJson", () => {
  it("pulls a balanced object out of surrounding prose", () => {
    expect(extractJson('noise {"a":{"b":1}} trailing')).toBe('{"a":{"b":1}}');
  });
  it("handles braces inside strings", () => {
    expect(extractJson('{"s":"a}b","n":2}')).toBe('{"s":"a}b","n":2}');
  });
  it("returns null when no object", () => {
    expect(extractJson("no json here")).toBeNull();
  });
});

describe("synthetic two-agent run end-to-end", () => {
  it("drives agents through a tool call to synthesis and persists", async () => {
    const { emit, events } = collect();
    const persisted: unknown[] = [];
    const ctrl = new AbortController();
    const res = await runSwarm({
      runId: "run-2a",
      initialUserMessage: { role: "user", content: "investigate loaded RFHub dump" },
      model: scriptedModel({}),
      tools: okExecutor,
      emit,
      signal: ctrl.signal,
      config: { agents: ["CRYPTO", "IMMOBILIZER"], tokenBudget: 10_000 },
      persist: async (row) => { persisted.push(row); },
    });

    expect(res.agentFindings).toHaveLength(2);
    expect(res.agentFindings.every((a) => a.findings.length === 1)).toBe(true);
    expect(persisted).toHaveLength(1);

    // event ordering sanity: each agent starts, calls a tool, finishes; synth + done
    expect(events.some((e) => e.type === "agent_start" && e.agent === "CRYPTO")).toBe(true);
    expect(events.some((e) => e.type === "agent_tool_call")).toBe(true);
    expect(events.filter((e) => e.type === "agent_done")).toHaveLength(2);
    expect(events.some((e) => e.type === "synthesis")).toBe(true);
    expect(events.at(-1)?.type).toBe("run_done");
  });

  it("token budget abort emits budget_exceeded and still synthesizes", async () => {
    const { emit, events } = collect();
    const ctrl = new AbortController();
    const res = await runSwarm({
      runId: "run-budget",
      initialUserMessage: { role: "user", content: "x" },
      model: scriptedModel({}),
      tools: okExecutor,
      emit,
      signal: ctrl.signal,
      config: { agents: ["CRYPTO", "IMMOBILIZER"], tokenBudget: 1 }, // immediately blown
    });
    expect(events.some((e) => e.type === "budget_exceeded")).toBe(true);
    expect(res.aborted).toBe(true);
  });

  it("pre-aborted signal yields aborted agents and no tool calls", async () => {
    const { emit, events } = collect();
    const ctrl = new AbortController();
    ctrl.abort();
    await runSwarm({
      runId: "run-cancel",
      initialUserMessage: { role: "user", content: "x" },
      model: scriptedModel({}),
      tools: okExecutor,
      emit,
      signal: ctrl.signal,
      config: { agents: ["CRYPTO"] },
    });
    expect(events.some((e) => e.type === "agent_aborted")).toBe(true);
    expect(events.some((e) => e.type === "agent_tool_call")).toBe(false);
  });
});
