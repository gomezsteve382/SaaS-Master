import express, { type Express, type Request, type Response } from "express";
import { mkdir, writeFile, readdir, stat } from "node:fs/promises";
import { spawn } from "node:child_process";
import { join, resolve, isAbsolute, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { Agent } from "../src/core/agent.ts";
import { ALL_TOOLS } from "../src/tools/index.ts";
import { which, execTool } from "../src/core/exec.ts";
import { config } from "../src/core/config.ts";
import { ModelAuthError } from "../src/core/model.ts";
import {
  loadSession,
  saveSession,
  listSessions,
  deleteSession,
} from "../src/core/sessionStore.ts";

const UPLOAD_DIR = resolve(process.cwd(), "uploads");
const UDSSIM = join(
  dirname(fileURLToPath(import.meta.url)),
  "..",
  "src",
  "py",
  "udssim.py"
);
const DEFAULT_BENCH_MODULES = ["ecm", "bcm", "rfhub", "cluster"];

/** Module sims running on the virtual bench, keyed by module name. */
const benchSims = new Map<
  string,
  { module: string; pid: number; log: string[] }
>();

/** One Agent (= one conversation) per browser session id. In-memory cache; backed by disk. */
const sessions = new Map<string, Agent>();

async function getAgent(id: string): Promise<Agent> {
  let a = sessions.get(id);
  if (!a) {
    a = new Agent(process.cwd());
    const stored = await loadSession(id); // resume across restarts
    if (stored) a.restore(stored.messages);
    sessions.set(id, a);
  }
  return a;
}

/** Persist a session transcript (best-effort). */
async function persist(id: string, agent: Agent): Promise<void> {
  const messages = agent.savedMessages;
  if (messages.length === 0) return;
  const prev = await loadSession(id);
  await saveSession({
    id,
    title: agent.firstUserText.trim().slice(0, 60) || "Untitled session",
    createdAt: prev?.createdAt ?? Date.now(),
    updatedAt: Date.now(),
    messages,
  });
}

export function registerApi(app: Express): void {
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, model: config.model, hasKey: Boolean(config.apiKey) });
  });

  // Tool catalog + availability of the underlying binaries.
  app.get("/api/tools", async (_req, res) => {
    const bins = new Set<string>();
    for (const t of ALL_TOOLS) for (const b of t.requires ?? []) bins.add(b);
    ["r2", "rabin2", "strace", "ltrace"].forEach(b => bins.add(b));
    const status: Record<string, boolean> = {};
    for (const b of [...bins].sort()) status[b] = await which(b);
    res.json({
      tools: ALL_TOOLS.map(t => ({
        name: t.name,
        description: t.description.split("\n")[0],
        requires: t.requires ?? [],
      })),
      bins: status,
    });
  });

  // List switchable projects under PROJECTS_ROOT (dirs that look like code projects).
  app.get("/api/projects", async (req, res) => {
    const id = String(req.query.sessionId || "");
    const markers = [
      "package.json",
      ".git",
      "pyproject.toml",
      "Cargo.toml",
      "go.mod",
      "Makefile",
      "requirements.txt",
    ];
    const found: Array<{ name: string; path: string }> = [];
    try {
      const entries = await readdir(config.projectsRoot, {
        withFileTypes: true,
      });
      for (const ent of entries) {
        if (!ent.isDirectory() || ent.name.startsWith(".")) continue;
        const full = join(config.projectsRoot, ent.name);
        for (const m of markers) {
          try {
            await stat(join(full, m));
            found.push({ name: ent.name, path: full });
            break;
          } catch {
            /* not a marker */
          }
        }
      }
    } catch {
      /* projectsRoot unreadable */
    }
    const active = sessions.get(id)?.workdir ?? process.cwd();
    res.json({
      root: config.projectsRoot,
      active,
      projects: found.sort((a, b) => a.name.localeCompare(b.name)),
    });
  });

  // Point this session's agent at a project directory.
  app.post("/api/project", async (req, res) => {
    const { sessionId, path } = (req.body ?? {}) as {
      sessionId?: string;
      path?: string;
    };
    if (!sessionId || !path) {
      res.status(400).json({ error: "sessionId and path required" });
      return;
    }
    const abs = isAbsolute(path) ? path : resolve(config.projectsRoot, path);
    try {
      const s = await stat(abs);
      if (!s.isDirectory()) throw new Error("not a directory");
    } catch {
      res.status(400).json({ error: `not a directory: ${abs}` });
      return;
    }
    (await getAgent(sessionId)).setCwd(abs);
    res.json({ ok: true, active: abs });
  });

  // List persisted sessions (newest first).
  app.get("/api/sessions", async (_req, res) => {
    res.json({ sessions: await listSessions() });
  });

  // Load one session's transcript (to resume it in the UI).
  app.get("/api/session/:id", async (req, res) => {
    const s = await loadSession(req.params.id);
    if (!s) {
      res.status(404).json({ error: "not found" });
      return;
    }
    res.json({ id: s.id, title: s.title, messages: s.messages });
  });

  // Virtual CAN bus control for the UI "Simulator" toggle.
  app.post("/api/vcan", async (req, res) => {
    const { action, name } = (req.body ?? {}) as {
      action?: string;
      name?: string;
    };
    const iface = /^[a-zA-Z0-9_]+$/.test(name ?? "") ? name! : "vcan0";
    const SUDO = process.getuid && process.getuid() === 0 ? "" : "sudo ";
    let script: string;
    if (action === "down") {
      script = `${SUDO}ip link set down ${iface} 2>&1; ${SUDO}ip link delete ${iface} 2>&1; echo "removed ${iface}"`;
    } else if (action === "status") {
      script = `ip -br link show type vcan 2>&1 || echo 'no vcan interfaces'`;
    } else {
      script = `${SUDO}modprobe vcan 2>&1; ${SUDO}ip link add dev ${iface} type vcan 2>&1; ${SUDO}ip link set up ${iface} 2>&1; echo '---'; ip -br link show ${iface} 2>&1`;
    }
    const { exec } = await import("node:child_process");
    exec(script, { timeout: 20000 }, (_err, stdout, stderr) => {
      const out = `${stdout}${stderr}`.trim();
      const up =
        /UP|UNKNOWN/.test(out) && !/does not exist|Cannot find/.test(out);
      res.json({
        action: action ?? "up",
        interface: iface,
        up: action === "down" ? false : up,
        output: out,
      });
    });
  });

  // One-click: boot the virtual bench (vcan up + a default set of module sims).
  app.post("/api/bench/boot", async (req, res) => {
    const body = (req.body ?? {}) as {
      channel?: string;
      modules?: string[];
      vin?: string;
    };
    const ch = /^[a-zA-Z0-9_]+$/.test(body.channel ?? "")
      ? body.channel!
      : "vcan0";
    const mods = (
      body.modules?.length ? body.modules : DEFAULT_BENCH_MODULES
    ).filter(m => DEFAULT_BENCH_MODULES.includes(m) || ["tcm"].includes(m));
    if (!(await which("python3"))) {
      res.status(500).json({ error: "python3 not available" });
      return;
    }
    // bring up vcan
    const SUDO = process.getuid && process.getuid() === 0 ? "" : "sudo ";
    const vr = await execTool(
      "sh",
      [
        "-c",
        `${SUDO}modprobe vcan 2>&1; ${SUDO}ip link add dev ${ch} type vcan 2>&1; ${SUDO}ip link set up ${ch} 2>&1; ip -br link show ${ch} 2>&1`,
      ],
      { timeoutMs: 15_000 }
    );
    const busUp =
      /UP|UNKNOWN/.test(vr.stdout) &&
      !/does not exist|Cannot find/.test(vr.stdout);

    // start each sim (skip ones already running)
    for (const m of mods) {
      if (benchSims.has(m)) continue;
      const args = [UDSSIM, "--module", m, "--channel", ch];
      if (body.vin) args.push("--vin", body.vin);
      const p = spawn("python3", args, { stdio: ["ignore", "pipe", "pipe"] });
      const log: string[] = [];
      const c = (b: Buffer) => log.length < 30 && log.push(b.toString("utf8"));
      p.stdout?.on("data", c);
      p.stderr?.on("data", c);
      benchSims.set(m, { module: m, pid: p.pid!, log });
    }
    await new Promise(r => setTimeout(r, 1600)); // let them bind

    const modules = mods.map(m => {
      const s = benchSims.get(m);
      const first = (s?.log.join("") || "").trim().split("\n")[0] || "";
      const ready = !/error/i.test(first);
      if (!ready && s) {
        try {
          process.kill(s.pid, "SIGTERM");
        } catch {
          /* gone */
        }
        benchSims.delete(m);
      }
      return { module: m, ready, info: first.slice(0, 140) };
    });
    res.json({
      channel: ch,
      bus_up: busUp,
      bus_info: vr.stdout.trim().slice(0, 200),
      modules,
    });
  });

  // Tear the bench down (stop all sims).
  app.post("/api/bench/shutdown", (_req, res) => {
    for (const s of benchSims.values()) {
      try {
        process.kill(s.pid, "SIGTERM");
      } catch {
        /* gone */
      }
    }
    benchSims.clear();
    res.json({ ok: true });
  });

  app.get("/api/bench/status", (_req, res) => {
    res.json({
      modules: [...benchSims.values()].map(s => ({
        module: s.module,
        pid: s.pid,
      })),
    });
  });

  // Live CAN tap (SSE) — streams candump frames for the visual bench.
  app.get("/api/can/tap", (req, res) => {
    const ch = /^[a-zA-Z0-9_]+$/.test(String(req.query.channel || ""))
      ? String(req.query.channel)
      : "vcan0";
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();
    const send = (o: Record<string, unknown>) =>
      res.write(`data: ${JSON.stringify(o)}\n\n`);
    send({ type: "open", channel: ch });
    const child = spawn("candump", ["-L", ch]); // -L: "(ts) iface id#data"
    child.on("error", () =>
      send({
        type: "error",
        message:
          "candump unavailable — install can-utils and bring up the interface (vcan).",
      })
    );
    let buf = "";
    child.stdout?.on("data", (b: Buffer) => {
      buf += b.toString("utf8");
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const l of lines)
        if (l.trim()) send({ type: "frame", raw: l.trim() });
    });
    child.stderr?.on("data", (b: Buffer) =>
      send({ type: "error", message: b.toString("utf8").slice(0, 200) })
    );
    req.on("close", () => {
      try {
        child.kill("SIGKILL");
      } catch {
        /* gone */
      }
      res.end();
    });
  });

  // Inject a CAN frame (the bench START button etc.).
  app.post("/api/can/send", (req, res) => {
    const { channel, id, data } = (req.body ?? {}) as {
      channel?: string;
      id?: string;
      data?: string;
    };
    const ch = /^[a-zA-Z0-9_]+$/.test(channel ?? "") ? channel! : "vcan0";
    if (
      !/^[0-9A-Fa-f]{1,8}$/.test(id ?? "") ||
      !/^([0-9A-Fa-f]{2}){0,8}$/.test(data ?? "")
    ) {
      res
        .status(400)
        .json({ error: "id (hex) and data (0-8 hex bytes) required" });
      return;
    }
    const child = spawn("cansend", [ch, `${id}#${data}`]);
    child.on("error", () =>
      res.status(500).json({ error: "cansend unavailable (install can-utils)" })
    );
    child.on("close", code =>
      res.json({ ok: code === 0, sent: `${id}#${data}`, channel: ch })
    );
  });

  // Cross-check programmed module dumps (ECM/BCM/RFHub) — MATCHED / MISMATCH + fixes.
  app.post("/api/marriage", async (req, res) => {
    const dumps = ((req.body ?? {}) as { dumps?: string[] }).dumps;
    if (!Array.isArray(dumps) || dumps.length < 1) {
      res
        .status(400)
        .json({ error: "dumps[] required (paths from /api/upload)" });
      return;
    }
    const tool = ALL_TOOLS.find(t => t.name === "module_marriage_check");
    if (!tool) {
      res.status(500).json({ error: "tool unavailable" });
      return;
    }
    const ctx = { cwd: process.cwd(), log: () => {}, record: () => {} };
    const parsed = tool.zodSchema.safeParse({ dumps });
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    try {
      const r = await tool.handler(ctx as never, parsed.data as never);
      res.json(r.ok ? r.data : { error: r.message, code: r.code });
    } catch (err) {
      res
        .status(500)
        .json({ error: err instanceof Error ? err.message : String(err) });
    }
  });

  // Raw file upload: body is the file bytes, name in the X-Filename header.
  app.post(
    "/api/upload",
    express.raw({ type: () => true, limit: "1024mb" }),
    async (req: Request, res: Response) => {
      try {
        const raw = (req.header("x-filename") || "upload.bin").trim();
        const name =
          raw.replace(/[^\w.\-]+/g, "_").slice(0, 200) || "upload.bin";
        await mkdir(UPLOAD_DIR, { recursive: true });
        const path = join(UPLOAD_DIR, `${Date.now()}-${name}`);
        const body = req.body as Buffer;
        await writeFile(path, body);
        res.json({ path, name, size: body.length });
      } catch (err) {
        res
          .status(500)
          .json({ error: err instanceof Error ? err.message : String(err) });
      }
    }
  );

  // Reset a session's conversation (and forget the persisted transcript).
  app.post("/api/reset", async (req, res) => {
    const id = String(req.body?.sessionId || "");
    sessions.get(id)?.reset();
    await deleteSession(id);
    res.json({ ok: true });
  });

  // Stream an agent turn over SSE.
  app.post("/api/analyze", async (req: Request, res: Response) => {
    const { sessionId, message, file } = (req.body ?? {}) as {
      sessionId?: string;
      message?: string;
      file?: string | null;
    };
    if (!sessionId || !message || !message.trim()) {
      res.status(400).json({ error: "sessionId and message are required" });
      return;
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders?.();

    const send = (event: Record<string, unknown>) => {
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    };

    const ac = new AbortController();
    req.on("close", () => ac.abort());

    const agent = await getAgent(sessionId);
    const text = file ? `[Active file: ${file}]\n\n${message}` : message;

    try {
      await agent.send(
        text,
        {
          onText: delta => send({ type: "text", delta }),
          onEvent: ev => send(ev as unknown as Record<string, unknown>),
        },
        ac.signal
      );
      send({ type: "done" });
    } catch (err) {
      if (err instanceof ModelAuthError) {
        send({ type: "error", message: err.message, auth: true });
      } else if (ac.signal.aborted) {
        send({ type: "aborted" });
      } else {
        send({
          type: "error",
          message: err instanceof Error ? err.message : String(err),
        });
      }
    } finally {
      await persist(sessionId, agent).catch(() => {});
      res.end();
    }
  });
}
