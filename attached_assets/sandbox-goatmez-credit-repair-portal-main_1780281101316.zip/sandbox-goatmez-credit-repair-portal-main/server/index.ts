import express from "express";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";
import { registerApi } from "./api.ts";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(here, "..");
const isProd = process.env.NODE_ENV === "production";
const PORT = Number(process.env.PORT || 5173);

async function main(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: "4mb" }));

  // API routes first so they aren't shadowed by the SPA/static handler.
  registerApi(app);

  if (isProd) {
    const dist = join(ROOT, "web", "dist");
    app.use(express.static(dist));
    app.get("*", (_req, res) => res.sendFile(join(dist, "index.html")));
  } else {
    // Dev: Vite in middleware mode gives HMR for the React app in-process.
    const { createServer } = await import("vite");
    const vite = await createServer({
      root: join(ROOT, "web"),
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    // eslint-disable-next-line no-console
    console.log(
      `\n  ⚡ RE-Agent UI  →  http://localhost:${PORT}  (${isProd ? "production" : "dev"})\n`
    );
  });
}

main().catch(err => {
  // eslint-disable-next-line no-console
  console.error("fatal:", err);
  process.exit(1);
});
