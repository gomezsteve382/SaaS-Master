# Ghidra headless post-script: decompile functions to a text file.
# Args: <outfile> [functionNameOrAddress]
# @category RE-Agent
from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor

args = getScriptArgs()
outpath = args[0] if len(args) > 0 else "/tmp/ghidra_decomp.txt"
target = args[1] if len(args) > 1 else None

program = getCurrentProgram()
fm = program.getFunctionManager()
dec = DecompInterface()
dec.openProgram(program)
monitor = ConsoleTaskMonitor()


def decompile_func(func):
    res = dec.decompileFunction(func, 60, monitor)
    if res and res.decompileCompleted():
        return res.getDecompiledFunction().getC()
    return "// (decompilation failed for %s)" % func.getName()


funcs = list(fm.getFunctions(True))
if target:
    matched = [f for f in funcs if f.getName() == target]
    if not matched:
        try:
            addr = toAddr(target)
            f = fm.getFunctionContaining(addr)
            if f:
                matched = [f]
        except:
            pass
    funcs = matched

out = open(outpath, "w")
count = 0
for f in funcs:
    out.write("// ===== %s @ %s =====\n" % (f.getName(), f.getEntryPoint()))
    out.write(decompile_func(f))
    out.write("\n\n")
    count += 1
    if count >= 400:
        break
out.close()
print("DECOMPILED %d function(s) to %s" % (count, outpath))
