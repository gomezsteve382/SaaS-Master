// Generates standalone HTML snapshots of the RE-Agent UI (Chat + Bench views)
// from the real web/src/styles.css, so they can be opened without running the
// app. Run: node scripts/gen-previews.mjs  → writes previews/chat.html + bench.html
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const css = readFileSync(resolve(root, "web/src/styles.css"), "utf8");
mkdirSync(resolve(root, "previews"), { recursive: true });

const page = (title, body) => `<!doctype html><html lang="en"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/><title>${title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet"/>
<style>${css}</style></head><body>${body}</body></html>`;

const header = (chat) => `
  <header class="header">
   <div class="brand"><span class="logo-chip">RE</span>
    <div><h1 class="logo">RE<span>·</span>AGENT</h1>
    <p class="tagline">crack open anything · reverse the code &amp; keys · screen for malware</p></div></div>
   <div class="header-actions">
    <div class="view-toggle"><button class="${chat ? "on" : ""}">💬 Chat</button><button class="${chat ? "" : "on"}">🔧 Bench</button></div>
    <button class="btn ghost">⟳ New analysis</button>
   </div>
  </header>`;

const sidebar = `
 <aside class="sidebar">
  <div class="drop has-file"><div class="drop-icon">📦</div><div class="drop-file">rfhub_dump.bin</div><div class="drop-meta">512 KB</div><button class="btn tiny">clear</button></div>
  <button class="auto-toggle on"><span class="auto-dot"></span>⚡ Auto-analyze on upload · ON</button>
  <div class="panel"><div class="panel-head"><span>Toolchain</span><span class="pill good">11/12</span></div>
   <div class="bins">${["r2","rabin2","yara","binwalk","ghidra","monodis","java","python3","candump","wine","strings"].map(b=>`<span class="bin on">● ${b}</span>`).join("")}<span class="bin off">○ ltrace</span></div></div>
  <div class="panel"><div class="panel-head"><span>Project</span><span class="pill good">3</span></div><div class="model-name">/home/ubuntu/srt-lab-ultimate</div></div>
  <div class="panel"><div class="panel-head"><span>CAN bus</span><span class="pill good">vcan0 sim</span></div><button class="auto-toggle on"><span class="auto-dot"></span>🚌 Simulator ON</button></div>
  <div class="panel grow"><div class="panel-head"><span>History</span><span class="pill good">3</span></div>
   <div class="history"><button class="history-item active">analyze rfhub dump + find key table</button><button class="history-item">decompile CDA.swf</button><button class="history-item">is this exe malware?</button></div></div>
 </aside>`;

const chatBody = `
<div class="app"><div class="aurora"></div>
 ${sidebar}
 <main class="main">
  ${header(true)}
  <div class="stream">
   <div class="row user"><div class="bubble user-bubble">Analyze this RFHub dump — find the key table and the seed→key routine</div><div class="avatar you">YOU</div></div>
   <div class="row asst"><div class="avatar bot">🤖</div><div class="bubble asst-bubble">
    <div class="ops">
     <span class="op ok"><span class="op-ico">🔎</span><span class="op-name">identify rfhub_dump.bin</span><span class="op-state">✓<em>41ms</em></span></span>
     <span class="op ok"><span class="op-ico">🔌</span><span class="op-name">load_firmware</span><span class="op-state">✓<em>120ms</em></span></span>
     <span class="op ok"><span class="op-ico">🪪</span><span class="op-name">keyrecord</span><span class="op-state">✓<em>88ms</em></span></span>
     <span class="op ok"><span class="op-ico">🔐</span><span class="op-name">find_crypto</span><span class="op-state">✓<em>63ms</em></span></span>
     <span class="op running"><span class="op-ico">🐲</span><span class="op-name">ghidra_decompile @ sym.SecurityAccess</span><span class="op-state"><span class="spinner"></span></span></span>
    </div>
    <div class="md"><h2>RFHub dump — findings</h2>
     <table><thead><tr><th>Item</th><th>Result</th></tr></thead><tbody>
     <tr><td>MCU</td><td>Renesas RH850 (V850 family)</td></tr>
     <tr><td>Key table</td><td>16-byte records @ <code>0x3A40</code> · 2 keys + 6 empty</td></tr>
     <tr><td>Red/black flag</td><td>byte[10] · <code>0x01</code> = master</td></tr>
     </tbody></table>
     <p><strong>🔑 Crypto:</strong> AES S-box @ <code>0x1C20</code>; SecurityAccess (0x27) handler at <code>0x80124A0</code>.</p>
     <p>Decompiling the seed→key routine now — then I'll generate a <code>keyfn.py</code> so you can validate your tester on the bench.</p></div>
    <div class="usage">anthropic/claude-sonnet-4.5 · 5120+412 tok</div>
   </div></div>
  </div>
  <div class="activity"><span class="activity-orb"></span><span class="activity-text">running Ghidra headless analysis…</span><span class="dots"><i></i><i></i><i></i></span></div>
  <div class="composer"><div class="active-file">📎 rfhub_dump.bin</div>
   <div class="composer-bar"><textarea rows="1" placeholder="Ask anything about rfhub_dump.bin…"></textarea><button class="btn stop">■ Stop</button></div></div>
 </main></div>`;

const mods=[["ECM","🔥",1,1],["TCM","⚙️",0,0],["BCM","💡",1,0],["RF Hub","📡",1,1],["Cluster","🎛️",1,0]];
const frames=[["7E0","02 10 03"],["7E8","06 50 03 00 32 01 F4"],["751","02 27 01"],["759","06 67 01 A1 B2 C3 D4"],["751","06 27 02 5A E8 99 8E"],["759","02 67 02"],["7E0","03 22 F1 90"],["7E8","10 14 62 F1 90 31 43"],["760","02 19 02"],["768","04 59 02 FF 00"]];
const benchBody = `
<div class="app"><div class="aurora"></div>
 <main class="main">
  ${header(false)}
  <div class="bench">
   <div class="bench-toolbar"><button class="btn send boot-btn">⚡ Boot virtual bench</button><button class="btn stop">■ Shut down bench</button><span class="bench-conn on">● tap live</span><button class="btn ghost">🚌 vcan0 UP</button><span class="bench-note">bus UP · modules: ecm, bcm, rfhub, cluster</span></div>
   <div class="marriage">
    <div class="marriage-head"><span>💍 ECM / BCM / RF Hub match</span><button class="btn send">Drop module dumps</button></div>
    <div class="marriage-verdict bad">MISMATCH ✗ — MISMATCH — 2 thing(s) to fix before these will pair (see below). The car would reject the set as-is.</div>
    <ul class="marriage-fixes">
     <li><b>rfhub.bin</b>: VIN is 2A4RR8DG0BR654321, others are 1C3CDZBG5FN123456 → <i>reprogram this module's VIN to 1C3CDZBG5FN123456 so it matches the set</i></li>
     <li><b>(set)</b>: no shared immobilizer secret across all dumps → <i>re-run your SKIM/PIN sync so they share the secret</i></li>
    </ul>
    <div class="marriage-note">This checks dump validity + cross-module consistency only. It does NOT prove the car starts — the live PCM↔RFHub↔BCM handshake, ECU timing, whether the write physically stuck, and hardware are only testable on the real bench/vehicle.</div>
   </div>
   <div class="bench-stage">
    <div class="node laptop hot"><div class="node-emoji">💻</div><div class="node-label">Tester / J2534</div></div>
    <div class="cable hot"><span class="cable-plug">⟜</span><span class="cable-line"></span><span class="cable-label">OBD-II → vcan0</span></div>
    <div class="harness"><div class="harness-spine hot"></div><div class="modules">
     ${mods.map(([l,e,live,hot])=>`<div class="node module ${hot?"hot":""} ${live?"live":""}"><div class="node-emoji">${e}</div><div class="node-label">${l}</div>${live?'<div class="node-live">● sim</div>':''}</div>`).join("")}
    </div></div>
    <div class="bench-bottom"><div class="cluster crank"><div class="gauge"><div class="needle" style="transform:rotate(120deg)"></div></div><div class="node-label">Cluster · CRANKING</div></div><button class="start-btn cranking">STARTING…</button></div>
   </div>
   <div class="bench-feed"><div class="bench-feed-head">CAN bus · ${frames.length} frames</div><div class="bench-frames">${frames.map(([id,d])=>`<div class="frame-row"><span class="frame-id">${id}</span><span class="frame-data">${d}</span></div>`).join("")}</div></div>
  </div>
 </main></div>`;

writeFileSync(resolve(root, "previews/chat.html"), page("RE-Agent — Chat view", chatBody));
writeFileSync(resolve(root, "previews/bench.html"), page("RE-Agent — Virtual Bench", benchBody));
console.log("wrote previews/chat.html + previews/bench.html");
