#!/usr/bin/env bash
#
# bootstrap.sh — provision the RE-Agent toolchain.
#
# This container is ephemeral, so the toolchain must be reproducible. Run this
# once per fresh environment (the SessionStart hook does it automatically on
# Claude Code web sessions). Safe to re-run; it skips what's already present.
#
set -uo pipefail

TOOLS_DIR="${RE_TOOLS_DIR:-/opt/re-tools}"
SUDO=""
if [ "$(id -u)" -ne 0 ]; then SUDO="sudo"; fi

log() { printf '\033[36m[bootstrap]\033[0m %s\n' "$*"; }
have() { command -v "$1" >/dev/null 2>&1; }

# ---- apt packages (native RE toolchain) ----------------------------------
APT_PKGS=(radare2 yara binwalk mono-utils binutils file gdb)
MISSING_APT=()
for p in "${APT_PKGS[@]}"; do
  case "$p" in
    radare2) have r2 || MISSING_APT+=("$p");;
    yara)    have yara || MISSING_APT+=("$p");;
    binwalk) have binwalk || MISSING_APT+=("$p");;
    mono-utils) have monodis || MISSING_APT+=("$p");;
    binutils) have objdump || MISSING_APT+=("$p");;
    file)    have file || MISSING_APT+=("$p");;
    gdb)     have gdb || MISSING_APT+=("$p");;
  esac
done
# Optional dynamic-analysis tracers.
have strace || MISSING_APT+=(strace)
have ltrace || MISSING_APT+=(ltrace)

# Wine: run Windows PE (.exe/.dll) for dynamic analysis. Needs i386 multiarch
# for broad (32-bit) compatibility; installed separately so a wine failure
# doesn't block the rest of the toolchain.
if ! have wine && ! have wine64; then
  log "installing wine (Windows PE execution)"
  $SUDO dpkg --add-architecture i386 2>/dev/null || true
  $SUDO apt-get update -qq 2>/dev/null || true
  if $SUDO apt-get install -y -qq wine 2>/dev/null; then
    log "  ✓ wine"
  elif $SUDO apt-get install -y -qq --no-install-recommends wine64 2>/dev/null; then
    log "  ✓ wine64 (64-bit only)"
  else
    log "  ✗ wine (skipped; static analysis of PEs still works)"
  fi
fi
# Ensure `wine` is on PATH even if only the wine64 binary got installed.
if ! have wine && [ -x /usr/lib/wine/wine64 ]; then
  $SUDO ln -sf /usr/lib/wine/wine64 /usr/local/bin/wine && log "  ✓ linked wine -> wine64"
fi

if [ "${#MISSING_APT[@]}" -gt 0 ]; then
  log "apt installing: ${MISSING_APT[*]}"
  $SUDO apt-get update -qq || true
  # install individually so one missing package doesn't abort the batch
  for p in "${MISSING_APT[@]}"; do
    $SUDO apt-get install -y -qq "$p" >/dev/null 2>&1 && log "  ✓ $p" || log "  ✗ $p (skipped)"
  done
else
  log "apt toolchain already present"
fi

# ---- python analysis libraries -------------------------------------------
log "pip installing python RE libs"
pip install --quiet --disable-pip-version-check capstone lief pefile pyelftools 2>/dev/null \
  && log "  ✓ capstone lief pefile pyelftools" \
  || log "  ✗ some python libs failed"
# Automotive / firmware / emulation / CAN libraries.
log "pip installing automotive + emulation libs"
pip install --quiet --disable-pip-version-check unicorn bincopy intelhex cantools python-can pya2l can-isotp 2>/dev/null \
  && log "  ✓ unicorn bincopy intelhex cantools python-can pya2l can-isotp" \
  || log "  ✗ some automotive libs failed"
# can-utils gives candump/cansend for live SocketCAN (optional, needs an interface).
have candump || $SUDO apt-get install -y -qq can-utils 2>/dev/null && log "  ✓ can-utils" || true

# ---- jar-based decompilers -----------------------------------------------
$SUDO mkdir -p "$TOOLS_DIR"

if [ ! -f "$TOOLS_DIR/cfr.jar" ]; then
  log "downloading CFR (Java decompiler)"
  $SUDO curl -fsSL -o "$TOOLS_DIR/cfr.jar" \
    https://github.com/leibnitz27/cfr/releases/download/0.152/cfr-0.152.jar \
    && log "  ✓ cfr.jar" || log "  ✗ cfr.jar"
fi

# Ghidra — heavyweight decompiler with embedded/automotive CPU support
# (TriCore, PowerPC, V850, SuperH, AVR, ARM, ...). ~420 MB; downloaded from the
# GitHub release (the api.github.com lookup is avoided in case it's rate-limited).
if [ ! -x "$TOOLS_DIR/ghidra/support/analyzeHeadless" ]; then
  log "downloading Ghidra (large, ~420MB)"
  GZ="https://github.com/NationalSecurityAgency/ghidra/releases/download/Ghidra_11.1.2_build/ghidra_11.1.2_PUBLIC_20240709.zip"
  if $SUDO curl -fsSL -o /tmp/ghidra.zip "$GZ"; then
    $SUDO unzip -q -o /tmp/ghidra.zip -d "$TOOLS_DIR/" \
      && $SUDO ln -sfn "$(ls -d "$TOOLS_DIR"/ghidra_*PUBLIC | head -1)" "$TOOLS_DIR/ghidra" \
      && log "  ✓ ghidra" || log "  ✗ ghidra unzip"
    $SUDO rm -f /tmp/ghidra.zip
  else
    log "  ✗ ghidra download (embedded-CPU decompilation will be unavailable)"
  fi
fi

if [ ! -f "$TOOLS_DIR/ffdec/ffdec.jar" ]; then
  log "downloading JPEXS ffdec (SWF/Flash decompiler)"
  tmp="$(mktemp -d)"
  if curl -fsSL -o "$tmp/ffdec.zip" \
      https://github.com/jindrapetrik/jpexs-decompiler/releases/download/version21.0.5/ffdec_21.0.5.zip; then
    $SUDO mkdir -p "$TOOLS_DIR/ffdec"
    $SUDO unzip -q -o "$tmp/ffdec.zip" -d "$TOOLS_DIR/ffdec" && log "  ✓ ffdec.jar" || log "  ✗ ffdec unzip"
  else
    log "  ✗ ffdec download"
  fi
  rm -rf "$tmp"
fi

# ---- node deps -----------------------------------------------------------
if [ -f package.json ] && [ ! -d node_modules ]; then
  log "installing node deps"
  if have pnpm; then pnpm install --silent; else npm install --silent; fi
fi

log "done. Verify with:  pnpm agent -- --check-tools"
