import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { Bench } from "./Bench.tsx";
import {
  streamAnalyze,
  uploadFile,
  fetchTools,
  fetchHealth,
  fetchProjects,
  setProject,
  vcanControl,
  fetchSessions,
  loadSessionMessages,
  type SseEvent,
  type ToolsResponse,
  type UploadInfo,
  type ProjectsResponse,
  type SessionSummary,
} from "./api.ts";

type ToolRun = {
  id: string;
  name: string;
  summary: string;
  status: "running" | "ok" | "err";
  ms?: number;
};
type Msg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  tools: ToolRun[];
  usage?: { prompt: number; completion: number; model: string };
};

const uid = () =>
  crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2);

const EXAMPLES = [
  "Crack this .exe all the way open — decompile it and pull every key/secret",
  "Is this file malware? List suspicious imports and IOCs",
  "Decompile the ActionScript in this .swf and explain what it does",
  "Show me everything inside this binary: format, sections, strings, symbols",
];

// Fired automatically when a file is uploaded (auto-run mode). The agent then
// chains tools on its own until it produces the full report.
const AUTO_PROMPT =
  "A file was just uploaded. Run a FULL autonomous reverse-engineering pass now — do not wait for further instructions. " +
  "Identify the format; enumerate everything inside (sections, strings, symbols, imports/exports); extract any embedded keys/secrets; " +
  "decompile the important logic; and screen it for malware (entropy/packers, suspicious imports, YARA, embedded payloads). " +
  "Then give a structured report with these sections: **Overview**, **What's Inside**, **Keys & Secrets**, **Notable Code**, and **Malware Verdict** (risk level + IOCs).";

const TOOL_EMOJI: Record<string, string> = {
  identify: "🔎",
  binary_metadata: "🧬",
  list_strings: "🔤",
  hexdump: "🧱",
  entropy: "📈",
  find_secrets: "🔑",
  symbols: "🏷️",
  pe_info: "🪟",
  elf_info: "🐧",
  disassemble: "⚙️",
  decompile: "🧠",
  r2: "📟",
  swf: "🎞️",
  jvm_decompile: "☕",
  dotnet_disasm: "🟣",
  deobfuscate_js: "✨",
  yara_scan: "🛡️",
  carve: "🔪",
  load_firmware: "🔌",
  ghidra_decompile: "🐲",
  find_crypto: "🔐",
  find_maps: "🗺️",
  parse_a2l: "📐",
  emulate: "🕹️",
  diff_firmware: "🔀",
  fca_profile: "🧭",
  ecu_report: "📋",
  keyrecord: "🪪",
  keytable_diff: "🗝️",
  checksum_scan: "🧮",
  eeprom_map: "🗂️",
  module_marriage_check: "💍",
  patch_bytes: "✒️",
  fix_checksum: "🧮",
  dbc_info: "🚗",
  dbc_decode: "🛰️",
  uds_reference: "📖",
  can_monitor: "📡",
  can_send: "📤",
  can_replay: "🔁",
  list_dir: "📂",
  read_file: "📄",
  search_code: "🔍",
  edit_file: "✏️",
  write_file: "📝",
  sandbox_run: "🧪",
  run_tests: "✅",
  sandbox_preview: "🖥️",
  vcan: "🚌",
  uds_sim: "🔧",
  sim_from_dump: "📥",
  make_keyfn: "🔑",
  uds_conformance: "🧾",
  renode_scaffold: "🧰",
  run_target: "▶️",
  run_shell: "💻",
};

function storedToUi(
  msgs: Array<{ role: string; content: string | null }>
): Msg[] {
  const out: Msg[] = [];
  for (const m of msgs) {
    if (m.role === "user" && m.content)
      out.push({ id: uid(), role: "user", content: m.content, tools: [] });
    else if (m.role === "assistant" && m.content)
      out.push({ id: uid(), role: "assistant", content: m.content, tools: [] });
  }
  return out;
}

export function App() {
  const [sessionId, setSessionId] = useState(uid);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [sessions, setSessions] = useState<SessionSummary[]>([]);
  const [input, setInput] = useState("");
  const [file, setFile] = useState<UploadInfo | null>(null);
  const [busy, setBusy] = useState(false);
  const [activity, setActivity] = useState<string | null>(null);
  const [autoRun, setAutoRun] = useState(true);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [tools, setTools] = useState<ToolsResponse | null>(null);
  const [health, setHealth] = useState<{
    model: string;
    hasKey: boolean;
  } | null>(null);
  const [banner, setBanner] = useState<string | null>(null);
  const [projects, setProjects] = useState<ProjectsResponse | null>(null);
  const [view, setView] = useState<"chat" | "bench">("chat");
  const [spend, setSpend] = useState<{
    prompt: number;
    completion: number;
    cost: number | null;
  } | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    fetchTools()
      .then(setTools)
      .catch(() => {});
    fetchHealth()
      .then(h => setHealth({ model: h.model, hasKey: h.hasKey }))
      .catch(() => {});
    fetchProjects(sessionId)
      .then(setProjects)
      .catch(() => {});
  }, [sessionId]);

  const refreshSessions = useCallback(() => {
    fetchSessions()
      .then(r => setSessions(r.sessions))
      .catch(() => {});
  }, []);

  useEffect(() => {
    refreshSessions();
  }, [refreshSessions]);

  const openSession = useCallback(async (id: string) => {
    const s = await loadSessionMessages(id).catch(() => null);
    if (!s) return;
    setSessionId(id);
    setMessages(storedToUi(s.messages));
  }, []);

  const switchProject = useCallback(
    async (path: string) => {
      const r = await setProject(sessionId, path).catch(() => null);
      if (r?.ok) setProjects(p => (p ? { ...p, active: r.active } : p));
    },
    [sessionId]
  );

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages]);

  const patchAssistant = useCallback((id: string, fn: (m: Msg) => Msg) => {
    setMessages(prev => prev.map(m => (m.id === id ? fn(m) : m)));
  }, []);

  const send = useCallback(
    async (textArg?: string, fileArg?: UploadInfo | null) => {
      const text = (textArg ?? input).trim();
      if (!text || busy) return;
      if (textArg === undefined) setInput("");
      setBanner(null);
      const activeFile = fileArg !== undefined ? fileArg : file;

      const userMsg: Msg = {
        id: uid(),
        role: "user",
        content: text,
        tools: [],
      };
      const asstId = uid();
      const asstMsg: Msg = {
        id: asstId,
        role: "assistant",
        content: "",
        tools: [],
      };
      setMessages(p => [...p, userMsg, asstMsg]);
      setBusy(true);
      setActivity("thinking…");

      const ac = new AbortController();
      abortRef.current = ac;

      const onEvent = (ev: SseEvent) => {
        switch (ev.type) {
          case "text":
            // Answer is streaming in — that's its own feedback.
            setActivity(null);
            patchAssistant(asstId, m => ({
              ...m,
              content: m.content + ev.delta,
            }));
            break;
          case "status":
            setActivity(ev.line);
            break;
          case "tool_start":
            setActivity(ev.summary || ev.name);
            patchAssistant(asstId, m => ({
              ...m,
              tools: [
                ...m.tools,
                {
                  id: uid(),
                  name: ev.name,
                  summary: ev.summary,
                  status: "running",
                },
              ],
            }));
            break;
          case "tool_end":
            patchAssistant(asstId, m => {
              const tools = [...m.tools];
              for (let i = tools.length - 1; i >= 0; i--) {
                if (
                  tools[i].name === ev.name &&
                  tools[i].status === "running"
                ) {
                  tools[i] = {
                    ...tools[i],
                    status: ev.ok ? "ok" : "err",
                    ms: ev.ms,
                  };
                  break;
                }
              }
              return { ...m, tools };
            });
            setActivity("thinking…"); // deciding the next step
            break;
          case "usage":
            setSpend({
              prompt: ev.totalPrompt,
              completion: ev.totalCompletion,
              cost: ev.totalCostUsd,
            });
            patchAssistant(asstId, m => ({
              ...m,
              usage: {
                prompt: ev.prompt,
                completion: ev.completion,
                model: ev.model,
              },
            }));
            break;
          case "error":
            setBanner(ev.auth ? `🔌 ${ev.message}` : `⚠️ ${ev.message}`);
            break;
          case "aborted":
            patchAssistant(asstId, m => ({
              ...m,
              content: m.content + "\n\n_(stopped)_",
            }));
            break;
        }
      };

      try {
        await streamAnalyze(
          { sessionId, message: text, file: activeFile?.path ?? null },
          onEvent,
          ac.signal
        );
      } catch (e) {
        if (!ac.signal.aborted)
          setBanner(`⚠️ ${e instanceof Error ? e.message : String(e)}`);
      } finally {
        setBusy(false);
        setActivity(null);
        abortRef.current = null;
        refreshSessions();
      }
    },
    [input, busy, sessionId, file, patchAssistant, refreshSessions]
  );

  const onUpload = useCallback(
    async (f: File) => {
      setUploading(true);
      setBanner(null);
      try {
        const info = await uploadFile(f);
        setFile(info);
        if (autoRun) void send(AUTO_PROMPT, info); // autonomous kickoff
      } catch (e) {
        setBanner(
          `Upload failed: ${e instanceof Error ? e.message : String(e)}`
        );
      } finally {
        setUploading(false);
      }
    },
    [autoRun, send]
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);
  // "New analysis" starts a fresh session and keeps the old one in history.
  const resetAll = useCallback(() => {
    abortRef.current?.abort();
    setSessionId(uid());
    setMessages([]);
    setBanner(null);
  }, []);

  return (
    <div className="app">
      <div className="aurora" aria-hidden />
      <Sidebar
        tools={tools}
        health={health}
        file={file}
        uploading={uploading}
        dragOver={dragOver}
        onDragState={setDragOver}
        onUpload={onUpload}
        onClearFile={() => setFile(null)}
        autoRun={autoRun}
        onToggleAuto={() => setAutoRun(v => !v)}
        projects={projects}
        onSwitchProject={switchProject}
        sessions={sessions}
        activeSession={sessionId}
        onOpenSession={openSession}
      />

      <main className="main">
        <Header
          onReset={resetAll}
          busy={busy}
          view={view}
          onView={setView}
          spend={spend}
        />

        {banner && <div className="banner">{banner}</div>}

        {view === "bench" ? (
          <Bench />
        ) : (
          <>
            <div className="stream" ref={scrollRef}>
              {messages.length === 0 ? (
                <Welcome onPick={t => setInput(t)} hasFile={Boolean(file)} />
              ) : (
                messages.map(m => <Bubble key={m.id} msg={m} />)
              )}
            </div>

            {busy && activity && (
              <div className="activity">
                <span className="activity-orb" />
                <span className="activity-text">{activity}</span>
                <span className="dots">
                  <i />
                  <i />
                  <i />
                </span>
              </div>
            )}

            <Composer
              input={input}
              setInput={setInput}
              onSend={send}
              onStop={stop}
              busy={busy}
              file={file}
            />
          </>
        )}
      </main>
    </div>
  );
}

function Header({
  onReset,
  busy,
  view,
  onView,
  spend,
}: {
  onReset: () => void;
  busy: boolean;
  view: "chat" | "bench";
  onView: (v: "chat" | "bench") => void;
  spend: { prompt: number; completion: number; cost: number | null } | null;
}) {
  return (
    <header className="header">
      <div className="brand">
        <span className="logo-chip">RE</span>
        <div>
          <h1 className="logo">
            RE<span>·</span>AGENT
          </h1>
          <p className="tagline">
            crack open anything · reverse the code &amp; keys · screen for
            malware
          </p>
        </div>
      </div>
      <div className="header-actions">
        {busy && <span className="live-dot">analyzing</span>}
        {spend && (
          <span
            className="spend"
            title={`${spend.prompt + spend.completion} tokens this session`}
          >
            {spend.cost != null
              ? `$${spend.cost.toFixed(4)}`
              : `${((spend.prompt + spend.completion) / 1000).toFixed(1)}k tok`}
          </span>
        )}
        <div className="view-toggle">
          <button
            className={view === "chat" ? "on" : ""}
            onClick={() => onView("chat")}
          >
            💬 Chat
          </button>
          <button
            className={view === "bench" ? "on" : ""}
            onClick={() => onView("bench")}
          >
            🔧 Bench
          </button>
        </div>
        <button className="btn ghost" onClick={onReset}>
          ⟳ New analysis
        </button>
      </div>
    </header>
  );
}

function Sidebar(props: {
  tools: ToolsResponse | null;
  health: { model: string; hasKey: boolean } | null;
  file: UploadInfo | null;
  uploading: boolean;
  dragOver: boolean;
  onDragState: (v: boolean) => void;
  onUpload: (f: File) => void;
  onClearFile: () => void;
  autoRun: boolean;
  onToggleAuto: () => void;
  projects: ProjectsResponse | null;
  onSwitchProject: (path: string) => void;
  sessions: SessionSummary[];
  activeSession: string;
  onOpenSession: (id: string) => void;
}) {
  const {
    tools,
    health,
    file,
    uploading,
    dragOver,
    onDragState,
    onUpload,
    onClearFile,
    autoRun,
    onToggleAuto,
    projects,
    onSwitchProject,
    sessions,
    activeSession,
    onOpenSession,
  } = props;
  const inputRef = useRef<HTMLInputElement | null>(null);
  const onlineBins = tools
    ? Object.values(tools.bins).filter(Boolean).length
    : 0;
  const totalBins = tools ? Object.keys(tools.bins).length : 0;

  return (
    <aside className="sidebar">
      <div
        className={`drop ${dragOver ? "over" : ""} ${file ? "has-file" : ""}`}
        onDragOver={e => {
          e.preventDefault();
          onDragState(true);
        }}
        onDragLeave={() => onDragState(false)}
        onDrop={e => {
          e.preventDefault();
          onDragState(false);
          const f = e.dataTransfer.files?.[0];
          if (f) onUpload(f);
        }}
        onClick={() => inputRef.current?.click()}
      >
        <input
          ref={inputRef}
          type="file"
          hidden
          onChange={e => {
            const f = e.target.files?.[0];
            if (f) onUpload(f);
          }}
        />
        <div className="drop-icon">{uploading ? "⏳" : file ? "📦" : "⬆️"}</div>
        {file ? (
          <>
            <div className="drop-file">{file.name}</div>
            <div className="drop-meta">{prettyBytes(file.size)}</div>
            <button
              className="btn tiny"
              onClick={e => {
                e.stopPropagation();
                onClearFile();
              }}
            >
              clear
            </button>
          </>
        ) : (
          <>
            <div className="drop-title">
              {uploading ? "Uploading…" : "Drop a file"}
            </div>
            <div className="drop-meta">
              exe · dll · so · swf · jar · bin · js
            </div>
          </>
        )}
      </div>

      <button
        className={`auto-toggle ${autoRun ? "on" : "off"}`}
        onClick={onToggleAuto}
      >
        <span className="auto-dot" />⚡ Auto-analyze on upload ·{" "}
        {autoRun ? "ON" : "OFF"}
      </button>

      <div className="panel">
        <div className="panel-head">
          <span>Toolchain</span>
          <span
            className={`pill ${onlineBins === totalBins && totalBins > 0 ? "good" : "warn"}`}
          >
            {onlineBins}/{totalBins || "—"}
          </span>
        </div>
        <div className="bins">
          {tools ? (
            Object.entries(tools.bins).map(([bin, ok]) => (
              <span key={bin} className={`bin ${ok ? "on" : "off"}`}>
                {ok ? "●" : "○"} {bin}
              </span>
            ))
          ) : (
            <span className="muted">checking…</span>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <span>Model</span>
          <span className={`pill ${health?.hasKey ? "good" : "warn"}`}>
            {health?.hasKey ? "key set" : "no key"}
          </span>
        </div>
        <div className="model-name">{health?.model ?? "…"}</div>
        {!health?.hasKey && (
          <div className="muted small">Set OPENROUTER_API_KEY in .env</div>
        )}
      </div>

      <div className="panel">
        <div className="panel-head">
          <span>Project</span>
          <span className="pill good">
            {(projects?.projects.length ?? 0) || "—"}
          </span>
        </div>
        {projects && projects.projects.length > 0 ? (
          <select
            className="project-select"
            value={projects.active}
            onChange={e => onSwitchProject(e.target.value)}
          >
            {!projects.projects.some(p => p.path === projects.active) && (
              <option value={projects.active}>
                {projects.active.split("/").pop()} (current)
              </option>
            )}
            {projects.projects.map(p => (
              <option key={p.path} value={p.path}>
                {p.name}
              </option>
            ))}
          </select>
        ) : (
          <div className="muted small">
            No projects under {projects?.root ?? "…"}. Set
            RE_AGENT_PROJECTS_ROOT.
          </div>
        )}
        <div className="model-name" style={{ marginTop: 8, fontSize: 11 }}>
          {projects?.active ?? "…"}
        </div>
      </div>

      <CanSimulator />

      <div className="panel">
        <div className="panel-head">
          <span>History</span>
          <span className="pill good">{sessions.length || "—"}</span>
        </div>
        <div className="history">
          {sessions.length === 0 ? (
            <span className="muted small">No saved sessions yet.</span>
          ) : (
            sessions.slice(0, 30).map(s => (
              <button
                key={s.id}
                className={`history-item ${s.id === activeSession ? "active" : ""}`}
                onClick={() => onOpenSession(s.id)}
                title={new Date(s.updatedAt).toLocaleString()}
              >
                {s.title || "Untitled"}
              </button>
            ))
          )}
        </div>
      </div>

      <div className="panel grow">
        <div className="panel-head">
          <span>Capabilities</span>
        </div>
        <div className="caps">
          {tools?.tools.map(t => (
            <span key={t.name} className="cap" title={t.description}>
              {TOOL_EMOJI[t.name] ?? "•"} {t.name}
            </span>
          ))}
        </div>
      </div>
    </aside>
  );
}

function CanSimulator() {
  const [up, setUp] = useState(false);
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState<string>("");

  const run = useCallback(async (action: "up" | "down" | "status") => {
    setBusy(true);
    try {
      const r = await vcanControl(action);
      setUp(r.up);
      setOut(r.output.slice(0, 240));
    } catch (e) {
      setOut(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }, []);

  return (
    <div className="panel">
      <div className="panel-head">
        <span>CAN bus</span>
        <span className={`pill ${up ? "good" : "warn"}`}>
          {up ? "vcan0 sim" : "hardware"}
        </span>
      </div>
      <button
        className={`auto-toggle ${up ? "on" : "off"}`}
        onClick={() => run(up ? "down" : "up")}
        disabled={busy}
      >
        <span className="auto-dot" />
        {busy
          ? "…"
          : up
            ? "🚌 Simulator ON — switch to hardware"
            : "🚌 Switch to vcan simulator"}
      </button>
      {out && (
        <div className="model-name" style={{ marginTop: 8, fontSize: 10 }}>
          {out}
        </div>
      )}
    </div>
  );
}

function Welcome({
  onPick,
  hasFile,
}: {
  onPick: (t: string) => void;
  hasFile: boolean;
}) {
  return (
    <div className="welcome">
      <div className="welcome-orb" aria-hidden />
      <h2>Let's tear something apart.</h2>
      <p>
        {hasFile
          ? "Your file is loaded. Ask away — or try one of these:"
          : "Drop a file on the left — with Auto-analyze on, the agent immediately rips it apart on its own. Or ask:"}
      </p>
      <div className="examples">
        {EXAMPLES.map(e => (
          <button key={e} className="example" onClick={() => onPick(e)}>
            {e}
          </button>
        ))}
      </div>
    </div>
  );
}

function Bubble({ msg }: { msg: Msg }) {
  if (msg.role === "user") {
    return (
      <div className="row user">
        <div className="bubble user-bubble">{msg.content}</div>
        <div className="avatar you">YOU</div>
      </div>
    );
  }
  return (
    <div className="row asst">
      <div className="avatar bot">🤖</div>
      <div className="bubble asst-bubble">
        {msg.tools.length > 0 && (
          <div className="ops">
            {msg.tools.map(t => (
              <span key={t.id} className={`op ${t.status}`}>
                <span className="op-ico">{TOOL_EMOJI[t.name] ?? "•"}</span>
                <span className="op-name">{t.summary || t.name}</span>
                <span className="op-state">
                  {t.status === "running" ? (
                    <span className="spinner" />
                  ) : t.status === "ok" ? (
                    "✓"
                  ) : (
                    "✕"
                  )}
                  {t.ms != null && <em>{t.ms}ms</em>}
                </span>
              </span>
            ))}
          </div>
        )}
        {msg.content ? (
          <div className="md">
            <ReactMarkdown>{msg.content}</ReactMarkdown>
          </div>
        ) : msg.tools.length === 0 ? (
          <div className="thinking">
            <span className="spinner" /> thinking…
          </div>
        ) : null}
        {msg.usage && (
          <div className="usage">
            {msg.usage.model} · {msg.usage.prompt}+{msg.usage.completion} tok
          </div>
        )}
      </div>
    </div>
  );
}

function Composer(props: {
  input: string;
  setInput: (v: string) => void;
  onSend: () => void;
  onStop: () => void;
  busy: boolean;
  file: UploadInfo | null;
}) {
  const { input, setInput, onSend, onStop, busy, file } = props;
  return (
    <div className="composer">
      {file && <div className="active-file">📎 {file.name}</div>}
      <div className="composer-bar">
        <textarea
          value={input}
          placeholder={
            file
              ? `Ask anything about ${file.name}…`
              : "Ask the agent… (drop a file on the left first)"
          }
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              onSend();
            }
          }}
          rows={1}
        />
        {busy ? (
          <button className="btn stop" onClick={onStop}>
            ■ Stop
          </button>
        ) : (
          <button
            className="btn send"
            onClick={onSend}
            disabled={!input.trim()}
          >
            Analyze ↵
          </button>
        )}
      </div>
    </div>
  );
}

function prettyBytes(n: number): string {
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(i ? 1 : 0)} ${u[i]}`;
}
