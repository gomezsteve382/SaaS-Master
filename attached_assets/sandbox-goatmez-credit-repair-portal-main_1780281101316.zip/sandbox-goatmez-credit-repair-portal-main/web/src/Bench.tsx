import { useEffect, useRef, useState, useCallback } from "react";
import {
  vcanControl,
  canSendFrame,
  benchBoot,
  benchShutdown,
  uploadFile,
  checkMarriage,
  type MarriageResult,
} from "./api.ts";

function MarriageCheck() {
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<
    (MarriageResult & { error?: string }) | null
  >(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const onFiles = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setBusy(true);
    setResult(null);
    try {
      const paths: string[] = [];
      for (const f of Array.from(files)) paths.push((await uploadFile(f)).path);
      setResult(await checkMarriage(paths));
    } catch (e) {
      setResult({ error: e instanceof Error ? e.message : String(e) } as any);
    } finally {
      setBusy(false);
    }
  }, []);

  const matched = result?.match_status?.startsWith("MATCHED");
  return (
    <div className="marriage">
      <input
        ref={inputRef}
        type="file"
        multiple
        hidden
        onChange={e => onFiles(e.target.files)}
      />
      <div className="marriage-head">
        <span>💍 ECM / BCM / RF Hub match</span>
        <button
          className="btn send"
          disabled={busy}
          onClick={() => inputRef.current?.click()}
        >
          {busy ? "Checking…" : "Drop module dumps"}
        </button>
      </div>
      {result && !result.error && (
        <>
          <div className={`marriage-verdict ${matched ? "ok" : "bad"}`}>
            {result.match_status} — {result.verdict}
          </div>
          {result.to_fix?.length > 0 && (
            <ul className="marriage-fixes">
              {result.to_fix.map((f, i) => (
                <li key={i}>
                  <b>{f.dump}</b>: {f.problem} → <i>{f.action}</i>
                </li>
              ))}
            </ul>
          )}
          <div className="marriage-note">{result.important}</div>
        </>
      )}
      {result?.error && (
        <div className="marriage-verdict bad">⚠️ {result.error}</div>
      )}
    </div>
  );
}

type Frame = { id: string; data: string; raw: string; t: number };

const MODULES = [
  { key: "ecm", label: "ECM", emoji: "🔥", ids: [0x7e0, 0x7e8] },
  { key: "tcm", label: "TCM", emoji: "⚙️", ids: [0x7e1, 0x7e9] },
  { key: "bcm", label: "BCM", emoji: "💡", ids: [0x720, 0x728] },
  { key: "rfhub", label: "RF Hub", emoji: "📡", ids: [0x751, 0x759] },
  { key: "cluster", label: "Cluster", emoji: "🎛️", ids: [0x760, 0x768] },
];

function moduleForId(id: number): string | null {
  for (const m of MODULES)
    if (id >= m.ids[0] - 8 && id <= m.ids[1] + 8) return m.key;
  return null;
}

// Parse a candump -L line: "(ts) iface 7E8#0011..."
function parseLine(raw: string): Frame | null {
  const m = raw.match(/\)\s+\S+\s+([0-9A-Fa-f]+)#([0-9A-Fa-f]*)/);
  if (!m) return null;
  return {
    id: m[1].toUpperCase(),
    data: m[2].toUpperCase(),
    raw,
    t: Date.now(),
  };
}

export function Bench() {
  const [frames, setFrames] = useState<Frame[]>([]);
  const [connected, setConnected] = useState(false);
  const [note, setNote] = useState<string>("");
  const [busUp, setBusUp] = useState(false);
  const [cranking, setCranking] = useState(false);
  const [hot, setHot] = useState<Record<string, number>>({});
  const [booting, setBooting] = useState(false);
  const [liveModules, setLiveModules] = useState<string[]>([]);
  const esRef = useRef<EventSource | null>(null);

  const flash = useCallback((key: string) => {
    setHot(h => ({ ...h, [key]: Date.now() }));
  }, []);

  useEffect(() => {
    const es = new EventSource("/api/can/tap?channel=vcan0");
    esRef.current = es;
    es.onopen = () => setConnected(true);
    es.onerror = () => setConnected(false);
    es.onmessage = ev => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === "frame") {
          const f = parseLine(msg.raw);
          if (f) {
            setFrames(prev => [f, ...prev].slice(0, 80));
            const mod = moduleForId(parseInt(f.id, 16));
            if (mod) flash(mod);
            flash("bus");
          }
        } else if (msg.type === "error") {
          setNote(msg.message);
        } else if (msg.type === "open") {
          setNote("tap open on " + msg.channel);
        }
      } catch {
        /* ignore */
      }
    };
    return () => es.close();
  }, [flash]);

  // decay highlights
  const [, force] = useState(0);
  useEffect(() => {
    const i = setInterval(() => force(n => n + 1), 300);
    return () => clearInterval(i);
  }, []);
  const isHot = (key: string) => Date.now() - (hot[key] ?? 0) < 600;

  const toggleBus = useCallback(async () => {
    const r = await vcanControl(busUp ? "down" : "up").catch(() => null);
    if (r) setBusUp(r.up);
  }, [busUp]);

  const boot = useCallback(async () => {
    setBooting(true);
    setNote("booting virtual bench…");
    try {
      const r = await benchBoot();
      setBusUp(r.bus_up);
      const ready = r.modules.filter(m => m.ready).map(m => m.module);
      setLiveModules(ready);
      const failed = r.modules.filter(m => !m.ready);
      setNote(
        `bus ${r.bus_up ? "UP" : "down"} · modules: ${ready.join(", ") || "none"}` +
          (failed.length
            ? ` · failed: ${failed.map(f => f.module).join(", ")} (${failed[0]?.info || ""})`
            : "")
      );
    } catch (e) {
      setNote(e instanceof Error ? e.message : String(e));
    } finally {
      setBooting(false);
    }
  }, []);

  const shutdown = useCallback(async () => {
    await benchShutdown().catch(() => {});
    setLiveModules([]);
    setNote("bench shut down");
  }, []);

  const start = useCallback(async () => {
    setCranking(true);
    // Inject an "ignition/start" request frame onto the bus.
    await canSendFrame("7DF", "0210030000000000").catch(() => {});
    flash("ecm");
    flash("bus");
    setTimeout(() => setCranking(false), 1600);
  }, [flash]);

  return (
    <div className="bench">
      <div className="bench-toolbar">
        <button className="btn send boot-btn" onClick={boot} disabled={booting}>
          {booting ? "⏳ Booting…" : "⚡ Boot virtual bench"}
        </button>
        {liveModules.length > 0 && (
          <button className="btn stop" onClick={shutdown}>
            ■ Shut down bench
          </button>
        )}
        <span className={`bench-conn ${connected ? "on" : "off"}`}>
          {connected ? "● tap live" : "○ tap idle"}
        </span>
        <button className="btn ghost" onClick={toggleBus}>
          {busUp ? "🚌 vcan0 UP" : "🚌 vcan0 only"}
        </button>
        {note && <span className="bench-note">{note}</span>}
      </div>

      <MarriageCheck />

      <div className="bench-stage">
        {/* Optional dashboard backdrop: drop an image at web/public/dashboard.jpg */}
        <div className="dash-bg" />
        {/* Laptop + tester */}
        <div className={`node laptop ${isHot("bus") ? "hot" : ""}`}>
          <div className="node-emoji">💻</div>
          <div className="node-label">Tester / J2534</div>
        </div>

        {/* OBD2 cable */}
        <div className={`cable ${isHot("bus") ? "hot" : ""}`}>
          <span className="cable-plug">⟜</span>
          <span className="cable-line" />
          <span className="cable-label">OBD-II → vcan0</span>
        </div>

        {/* Harness spine + modules */}
        <div className="harness">
          <div className={`harness-spine ${isHot("bus") ? "hot" : ""}`} />
          <div className="modules">
            {MODULES.map(m => (
              <div
                key={m.key}
                className={`node module ${isHot(m.key) ? "hot" : ""} ${liveModules.includes(m.key) ? "live" : ""}`}
              >
                <div className="node-emoji">{m.emoji}</div>
                <div className="node-label">{m.label}</div>
                {liveModules.includes(m.key) && (
                  <div className="node-live">● sim</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Cluster + START */}
        <div className="bench-bottom">
          <div className={`cluster ${cranking ? "crank" : ""}`}>
            <div className="gauge">
              <div
                className="needle"
                style={{ transform: `rotate(${cranking ? 120 : -40}deg)` }}
              />
            </div>
            <div className="node-label">
              Cluster {cranking ? "· CRANKING" : "· idle"}
            </div>
          </div>
          <button
            className={`start-btn ${cranking ? "cranking" : ""}`}
            onClick={start}
          >
            {cranking ? "STARTING…" : "START"}
          </button>
        </div>
      </div>

      {/* Live frame feed */}
      <div className="bench-feed">
        <div className="bench-feed-head">CAN bus · {frames.length} frames</div>
        <div className="bench-frames">
          {frames.length === 0 ? (
            <div className="muted small">
              No frames yet. Start vcan0, run a module sim (uds_sim), then ask
              the agent to send requests — they'll light up here.
            </div>
          ) : (
            frames.map((f, i) => (
              <div key={i} className="frame-row">
                <span className="frame-id">{f.id}</span>
                <span className="frame-data">{f.data || "—"}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
