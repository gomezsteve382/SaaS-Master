export type SseEvent =
  | { type: "text"; delta: string }
  | { type: "tool_start"; name: string; summary: string }
  | { type: "tool_end"; name: string; ok: boolean; ms: number }
  | { type: "status"; line: string }
  | {
      type: "usage";
      model: string;
      prompt: number;
      completion: number;
      costUsd: number | null;
      totalPrompt: number;
      totalCompletion: number;
      totalCostUsd: number | null;
    }
  | { type: "done" }
  | { type: "aborted" }
  | { type: "error"; message: string; auth?: boolean };

export type UploadInfo = { path: string; name: string; size: number };

export async function streamAnalyze(
  body: { sessionId: string; message: string; file: string | null },
  onEvent: (ev: SseEvent) => void,
  signal: AbortSignal
): Promise<void> {
  const res = await fetch("/api/analyze", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok || !res.body) {
    onEvent({ type: "error", message: `HTTP ${res.status}` });
    return;
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const blocks = buf.split("\n\n");
    buf = blocks.pop() ?? "";
    for (const block of blocks) {
      const line = block.trim();
      if (!line.startsWith("data:")) continue;
      try {
        onEvent(JSON.parse(line.slice(5).trim()) as SseEvent);
      } catch {
        /* ignore partial frame */
      }
    }
  }
}

export async function uploadFile(file: File): Promise<UploadInfo> {
  const res = await fetch("/api/upload", {
    method: "POST",
    headers: { "x-filename": file.name },
    body: await file.arrayBuffer(),
  });
  if (!res.ok) throw new Error(`upload failed: ${res.status}`);
  return res.json();
}

export type ToolsResponse = {
  tools: Array<{ name: string; description: string; requires: string[] }>;
  bins: Record<string, boolean>;
};

export async function fetchTools(): Promise<ToolsResponse> {
  return (await fetch("/api/tools")).json();
}

export async function fetchHealth(): Promise<{
  ok: boolean;
  model: string;
  hasKey: boolean;
}> {
  return (await fetch("/api/health")).json();
}

export async function resetSession(sessionId: string): Promise<void> {
  await fetch("/api/reset", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ sessionId }),
  });
}

export type ProjectsResponse = {
  root: string;
  active: string;
  projects: Array<{ name: string; path: string }>;
};

export async function fetchProjects(
  sessionId: string
): Promise<ProjectsResponse> {
  return (
    await fetch(`/api/projects?sessionId=${encodeURIComponent(sessionId)}`)
  ).json();
}

export async function setProject(
  sessionId: string,
  path: string
): Promise<{ ok: boolean; active: string }> {
  return (
    await fetch("/api/project", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ sessionId, path }),
    })
  ).json();
}

export type SessionSummary = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: number;
};

export async function fetchSessions(): Promise<{ sessions: SessionSummary[] }> {
  return (await fetch("/api/sessions")).json();
}

export async function loadSessionMessages(id: string): Promise<{
  id: string;
  title: string;
  messages: Array<{ role: string; content: string | null }>;
}> {
  return (await fetch(`/api/session/${encodeURIComponent(id)}`)).json();
}

export type VcanResponse = {
  action: string;
  interface: string;
  up: boolean;
  output: string;
};

export async function vcanControl(
  action: "up" | "down" | "status"
): Promise<VcanResponse> {
  return (
    await fetch("/api/vcan", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action }),
    })
  ).json();
}

export type BenchBootResponse = {
  channel: string;
  bus_up: boolean;
  bus_info: string;
  modules: Array<{ module: string; ready: boolean; info: string }>;
};

export async function benchBoot(vin?: string): Promise<BenchBootResponse> {
  return (
    await fetch("/api/bench/boot", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(vin ? { vin } : {}),
    })
  ).json();
}

export async function benchShutdown(): Promise<{ ok: boolean }> {
  return (await fetch("/api/bench/shutdown", { method: "POST" })).json();
}

export type MarriageResult = {
  match_status: string;
  reference_vin: string | null;
  vin_per_dump: Record<string, string | null>;
  to_fix: Array<{ dump: string; problem: string; action: string }>;
  verdict: string;
  important: string;
};

export async function checkMarriage(
  dumps: string[]
): Promise<MarriageResult & { error?: string }> {
  return (
    await fetch("/api/marriage", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ dumps }),
    })
  ).json();
}

export async function canSendFrame(
  id: string,
  data: string,
  channel = "vcan0"
): Promise<{ ok: boolean; sent?: string; error?: string }> {
  return (
    await fetch("/api/can/send", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ channel, id, data }),
    })
  ).json();
}
