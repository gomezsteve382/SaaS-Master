Drop a dashboard photo here named exactly:  dashboard.jpg
It will appear (faded) as the backdrop of the virtual Bench stage.
If absent, the bench just uses its normal gradient background — nothing breaks.
