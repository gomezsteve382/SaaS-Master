# Key programming workflow (with RE-Agent)

This covers **both** meanings of "program a key":

1. **File-level** — edit the bin dump itself (write a transponder ID into a key
   slot, set the master/valet flag, fix the checksum). RE-Agent does this directly.
2. **Hardware** — read the dump off the module and write the finished `.bin` back.
   That's your **programmer / key tool** (Autel IM608, Xhorse VVDI, AutoProPad,
   XPROG/CG-Pro, J2534 + SGW cable). RE-Agent does NOT touch hardware or the car.

Owner / right-to-repair on a vehicle you own.

---

## The loop

```
[your tool] read dump → RE-Agent: decode → RE-Agent: EDIT key into the bin → RE-Agent: fix checksum + verify → [your tool] write dump back → car start test
```

RE-Agent owns the middle (decode + edit + verify). Your hardware owns the ends
(read off the module, write back, and the final crank).

---

## 1. Read the dump off the module (YOUR hardware — not RE-Agent)

Get the `.bin` by one of:
- **Bench EEPROM/flash read** — chip programmer (XPROG, CG-Pro, Autel XP400), clip/solder.
- **OBD / J2534 read** — Autel/VVDI/your utility over the bus (SGW cable on 2018+).
- **Bootloader / BDM** — direct MCU read.

Save `rfhub_stock.bin` and **keep an untouched copy** before editing anything.

## 2. Understand the module (RE-Agent)

```
fca_profile rfhub                 # MCU, where the secret/key-table/red-black flag live,
                                  # AND transponder generation (Hitag2/ID46 vs encrypted 4A)
ecu_report   rfhub_stock.bin      # one-shot: format, MCU, key table, crypto
keyrecord    rfhub_stock.bin      # locate + label key slots, transponder-ID field,
                                  # and the red(master)/black(valet) flag byte  ← note the offsets
eeprom_map   rfhub_stock.bin      # VIN + strings (confirm it's the right car/module)
checksum_scan rfhub_stock.bin     # locate the checksum: note its OFFSET + ALGORITHM ← you need these
```

> Check the transponder generation. Older Hitag2/ID46 keys renew freely; encrypted
> **4A** keys often need an unlock/renew step your key tool handles. RE-Agent tells
> you which you've got, it can't change the silicon.

## 3. (Optional) Recover the seed→key (RE-Agent)

```
find_crypto      rfhub_stock.bin
ghidra_decompile rfhub_stock.bin processor=<id>          # find the 0x27 key routine
make_keyfn       rfhub_stock.bin --start 0x.. --stop 0x.. \
                 --seed_reg r0 --key_reg r0 --out keyfn.py
```

`keyfn.py` computes the correct key for any seed — used to validate on the bench (step 6).

## 4. EDIT the key into the dump — FILE-LEVEL (RE-Agent)

Work on a copy so the original is preserved (`--out`). Using the offsets from
`keyrecord` in step 2:

```
# write the transponder ID into the key slot's ID field
patch_bytes  rfhub_stock.bin --offset 0x<slot_id_offset> --hex <TRANSPONDER_ID_HEX> --out rfhub_new.bin

# set the key type flag:  01 = master/red,  00 = valet/black
patch_bytes  rfhub_new.bin   --offset 0x<flag_offset>    --hex 01

# (any other field the same way — VIN, config, etc.)
```

Sanity-check that ONLY what you meant changed:

```
keytable_diff  rfhub_stock.bin  rfhub_new.bin     # exact changed bytes, before/after
```

## 5. Fix the checksum so the module accepts it (RE-Agent)

Editing the dump breaks any checksum covering that region — fix it with the offset +
algorithm from step 2's `checksum_scan`:

```
fix_checksum   rfhub_new.bin --offset 0x<ck_offset> --algorithm "CRC32(LE)"
checksum_scan  rfhub_new.bin                        # confirm it now VERIFIES ✓
```

(Algorithms `fix_checksum` supports: `CRC32(LE)`, `sum32(LE)`, `sum16(LE)`, `CRC16-CCITT`.)

> A bad/forgotten checksum is the #1 reason a programmed module won't work. Don't skip this.

## 6. Verify the whole result (RE-Agent — the money step)

```
keyrecord              rfhub_new.bin                       # slot/flag look right?
module_marriage_check  pcm.bin rfhub_new.bin bcm.bin       # ECM/BCM/RFHub agree (VIN + secret)?
                                                           # MATCHED ✓ or exactly what to fix
# optional off-car proof of the security exchange:
sim_from_dump   rfhub_new.bin --module rfhub --key_start 0x.. --key_stop 0x.. --seed_reg r0 --key_reg r0
uds_conformance "python my_tester.py" --modules rfhub --keyfn keyfn.py
```

## 7. Write the finished dump back (YOUR hardware — not RE-Agent)

Flash `rfhub_new.bin` back to the module with your programmer (OBD/bench; SGW
bypass/auth as your setup needs). Then the real start test on the vehicle.

---

## Quick reference — the file-level edit

```
checksum_scan  dump.bin                      # → offset 0x400, algorithm CRC32(LE)
keyrecord      dump.bin                      # → key slot @ 0x200, ID field +2, flag byte +10
patch_bytes    dump.bin --offset 0x202 --hex DEADBEEFCAFE1234 --out new.bin
patch_bytes    new.bin  --offset 0x20A --hex 01                # 01 master / 00 valet
fix_checksum   new.bin  --offset 0x400 --algorithm "CRC32(LE)"
checksum_scan  new.bin                       # verifies ✓  → ready to flash back
keytable_diff  dump.bin new.bin              # double-check only intended bytes changed
```

---

## What this proves vs. doesn't

**✅ Proves (off-car):** the transponder ID is in the correct slot, the master/valet
flag is set as intended, the checksum is valid, the modules are consistently married,
and the seed→key exchange succeeds. The edited `.bin` is structurally correct and
internally consistent.

**❌ Does NOT prove the car starts** — the live PCM↔RFHub↔BCM immobilizer handshake,
ECU timing/self-tests, transponder RF pairing, and whether the flash write physically
stuck are only testable on the real bench/vehicle. RE-Agent removes the "is my dump/
key wrong" failures; the final crank is still the car.

## Division of labor

| Step | Who |
|---|---|
| Read the dump off the module | **your programmer / key tool** |
| Decode it, find key table + checksum + algorithm | RE-Agent |
| **Edit the key into the bin (ID + flag), fix checksum** | **RE-Agent** |
| Verify (keytable_diff / checksum_scan / marriage / bench) | RE-Agent |
| Write the finished `.bin` back to the module | **your programmer** |
| Final "does it start" | the real car |

## Tools used

`fca_profile` · `ecu_report` · `keyrecord` · `eeprom_map` · `checksum_scan` ·
`find_crypto` · `ghidra_decompile` · `make_keyfn` · **`patch_bytes`** ·
**`fix_checksum`** · `keytable_diff` · `module_marriage_check` · `sim_from_dump` ·
`uds_conformance` · `hexdump`
