# Testing a real dump on the virtual bench

Goal: after you read/modify/program a module dump, check on the bench whether it's
**internally valid and behaves correctly over UDS** — before (and instead of)
trial-and-error in the car. Read the "What this proves vs. doesn't" section first
so you know exactly what a green result means.

Run all of this on the **VM** (it has `vcan` + `can-utils` + `can-isotp` + root).

---

## 0. One-time bench prereqs

```bash
bash scripts/bootstrap.sh        # installs radare2/Ghidra/unicorn/can-utils/can-isotp/...
sudo modprobe vcan
sudo ip link add dev vcan0 type vcan
sudo ip link set up vcan0
ip -br link show vcan0           # should report UP / UNKNOWN
```

In the web UI you can skip the `ip` commands — the Bench view's **⚡ Boot virtual
bench** does it for you.

---

## 1. Validate the dump itself (static — catches bad writes)

This is the highest-value check for "did my programming actually take." No CAN needed.

```text
ecu_report      my_dump.bin                 # format, MCU, key table, crypto — one shot
checksum_scan   my_dump.bin                 # are the stored checksums still VALID after editing?
keyrecord       my_dump.bin                 # key slots + red/black flag laid out correctly?
eeprom_map      my_dump.bin                 # VIN / strings / mirrored blocks intact?
```

If you edited the dump, **diff it against the original** to confirm only what you
intended changed (and nothing else, e.g. a checksum you forgot to fix):

```text
keytable_diff   stock_dump.bin   programmed_dump.bin     # exact changed bytes
diff_firmware   stock_dump.bin   programmed_dump.bin     # byte/region diff
```

> A bad checksum or an unintended changed region here is almost certainly why a
> programmed module won't work in the car. Fix it before you go further.

---

## 2. Recover the real seed→key from the dump (optional but powerful)

So the bench validates the *actual* security algorithm, not a stub. Find the
SecurityAccess (0x27) routine first (`ghidra_decompile` / `find_crypto`), then:

```text
make_keyfn  my_dump.bin  --arch arm --bits 32 --base 0x0 \
            --start 0x<keyfn_entry> --stop 0x<keyfn_ret> \
            --seed_reg r0 --key_reg r0  --out keyfn.py
```

This emits `keyfn.py` that runs the dump's real routine for **any** seed.

---

## 3. Bring the module up on the bench from the dump

```text
sim_from_dump  my_dump.bin --module rfhub \
               --key_start 0x<entry> --key_stop 0x<ret> --seed_reg r0 --key_reg r0
```

This extracts the dump's **real VIN + key table**, generates the **real seed→key**,
and launches a UDS module sim on `vcan0` serving that real data.

(Or manually: `vcan up` → `uds_sim --module rfhub --vin <real> --keyfn keyfn.py`.)

---

## 4. Run YOUR tester / programmer against it → pass/fail

```text
uds_conformance "python my_tester.py --channel vcan0" \
                --modules rfhub --keyfn keyfn.py \
                --baseline real_bench_capture.log
```

You get: **passed/failed**, the exit code, every request/response frame seen, and —
if you provide a `candump -L` capture from the **real** bench — a diff of which
arbitration IDs differ between sim and reality.

To capture a real baseline once (on the actual bench/car interface):
```bash
candump -L can0 > real_bench_capture.log     # while you run the same sequence for real
```

---

## What this PROVES vs. what it DOESN'T

**✅ A green bench result proves:**
- The dump is structurally valid — checksums pass, key table / VIN / config are well-formed.
- Only the bytes you intended changed (via the diff).
- Your tester/programmer speaks the protocol correctly: ISO-TP framing, session
  control, the **real** SecurityAccess seed→key, DID reads, the write sequence.
- The UDS conversation completes end-to-end without errors.

**❌ It does NOT prove the module will run the car**, because the bench models
behavior — it does not execute the module's firmware or its I/O:
- **Real ECU timing/quirks** — true P2/P2* timings, lockout-after-N, boot self-tests.
- **Cross-module immobilizer handshake** — RFHub↔PCM↔BCM crypto on the real bus.
- **Hardware/physical** — transponder RF, the SGW, sensors/actuators, power-on init.
- **That the write physically "stuck"** in the module's flash/EEPROM.

**So the realistic workflow is:** use the bench to catch the ~80% of failures that
are *your* fault (bad checksum, wrong key algorithm, malformed write, protocol
bug) **before** touching the car — then do the final "does it actually start the
car" validation on the real bench/vehicle, where you're now only chasing
hardware/timing, not your own code or a corrupt dump.

> Owner / right-to-repair on a vehicle you own. The bench is for verifying your
> own work, not defeating protections.
