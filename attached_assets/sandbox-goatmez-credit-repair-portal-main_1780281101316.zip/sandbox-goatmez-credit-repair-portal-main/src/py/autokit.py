#!/usr/bin/env python3
"""
autokit — RE-Agent's automotive / firmware analysis bridge.

Subcommands (each prints one JSON object):
    autokit.py loadfw    <file> [--base 0x0]   # HEX/SREC/raw -> memory map + MCU fingerprint
    autokit.py findcrypto <file>                # locate crypto constants (AES/SHA/MD5/CRC)
    autokit.py maps      <file> [--min-len 8]   # heuristic calibration axis/table finder
"""

import argparse
import json
import sys


def out(o):
    json.dump(o, sys.stdout, default=str)
    sys.stdout.write("\n")


def err(m):
    out({"error": str(m)})
    sys.exit(0)


# ---- MCU / supplier fingerprints (ASCII markers seen in ECU firmware) --------
MCU_MARKERS = [
    "Infineon", "AURIX", "TriCore", "TC17", "TC2", "TC3", "Renesas", "RH850",
    "V850", "SH7", "Bosch", "Continental", "DELPHI", "Denso", "Siemens", "VDO",
    "Marelli", "EDC17", "EDC16", "MED17", "MED9", "ME7", "MG1", "MD1", "SIMOS",
    "MPC5", "PowerPC", "Freescale", "NXP", "ST10", "Cortex", "Keihin", "Hitachi",
]


def cmd_loadfw(a):
    import bincopy

    path = a.file
    data = open(path, "rb").read()
    fmt = "raw"
    segments = []
    exec_addr = None
    lower = path.lower()
    try:
        bf = bincopy.BinFile()
        if lower.endswith((".hex", ".ihex", ".ihx")):
            bf.add_ihex_file(path); fmt = "intel-hex"
        elif lower.endswith((".s19", ".s28", ".s37", ".srec", ".mot", ".s")):
            bf.add_srec_file(path); fmt = "motorola-srec"
        else:
            # sniff: Intel HEX lines start with ':', SREC with 'S'
            head = data[:4].lstrip()
            if head[:1] == b":":
                bf.add_ihex_file(path); fmt = "intel-hex"
            elif head[:1] == b"S":
                bf.add_srec_file(path); fmt = "motorola-srec"
        if fmt != "raw":
            for seg in bf.segments:
                segments.append({"address": hex(seg.address), "length": len(seg.data)})
            exec_addr = hex(bf.execution_start_address) if bf.execution_start_address is not None else None
            flat = bf.as_binary()
        else:
            flat = data
            segments.append({"address": hex(a.base), "length": len(data)})
    except Exception as e:
        # fall back to treating as raw
        fmt = "raw"
        flat = data
        segments = [{"address": hex(a.base), "length": len(data)}]

    # MCU fingerprint: scan flat image for supplier/part markers.
    text = flat.decode("latin1", "replace")
    hits = sorted({m for m in MCU_MARKERS if m.lower() in text.lower()})

    # Reset-vector heuristic for raw images: first/last 32-bit words as candidate addresses.
    import struct
    vec = {}
    if len(flat) >= 8:
        vec["first_word_le"] = hex(struct.unpack_from("<I", flat, 0)[0])
        vec["first_word_be"] = hex(struct.unpack_from(">I", flat, 0)[0])

    out({
        "path": path, "format": fmt, "size": len(flat),
        "segments": segments[:64], "segment_count": len(segments),
        "execution_start_address": exec_addr,
        "mcu_fingerprints": hits,
        "reset_vector_candidates": vec,
        "note": "For a raw .bin, pass --base with the real load address (from the MCU memory map) before disassembling.",
    })


# ---- crypto constant signatures ---------------------------------------------
SIGS = {
    "AES S-box": "637c777bf26b6fc53001672bfed7ab76",
    "AES inverse S-box": "52096ad53036a538bf40a39e81f3d7fb",
    "AES Rcon": "01020408102040801b366cd8ab4d9a",
    "SHA-1 init (BE)": "67452301efcdab8998badcfe10325476c3d2e1f0",
    "SHA-256 init (BE)": "6a09e667bb67ae853c6ef372a54ff53a510e527f9b05688c1f83d9ab5be0cd19",
    "SHA-256 K (BE)": "428a2f9871374491b5c0fbcfe9b5dba5",
    "MD5 sine T[0..3] (LE)": "78a46ad2d76aa47847656e16c89b38c8",
    "CRC32 reflected poly bytes": "2083b8ed",   # 0xEDB88320 little-endian
    "CRC32 normal poly bytes": "b71dc104",       # 0x04C11DB7 little-endian
    "CRC-CCITT poly 0x1021 (BE)": "1021",
}


def cmd_findcrypto(a):
    data = open(a.file, "rb").read()
    findings = []
    for name, hx in SIGS.items():
        pat = bytes.fromhex(hx)
        start = 0
        while True:
            i = data.find(pat, start)
            if i < 0:
                break
            findings.append({"type": name, "offset": hex(i), "bytes": hx[:32]})
            start = i + 1
            if len(findings) > 200:
                break
    out({"path": a.file, "size": len(data), "match_count": len(findings),
         "findings": findings,
         "note": "Heuristic constant matches; confirm by disassembling around the offset. CRC-CCITT 0x1021 is short and may false-positive."})


def cmd_maps(a):
    """Heuristic calibration-axis finder: runs of monotonically increasing values."""
    import struct
    data = open(a.file, "rb").read()
    min_len = a.min_len
    candidates = []

    def scan(width, unpack, label):
        i = 0
        n = len(data)
        while i + width * 2 <= n:
            run = 1
            prev = unpack(data, i)
            j = i + width
            while j + width <= n:
                cur = unpack(data, j)
                if cur > prev:
                    run += 1
                    prev = cur
                    j += width
                else:
                    break
            if run >= min_len:
                vals = [unpack(data, i + k * width) for k in range(min(run, 16))]
                candidates.append({"offset": hex(i), "type": label, "length": run, "sample": vals})
                i = j
            else:
                i += width

    scan(1, lambda d, o: d[o], "u8 axis")
    scan(2, lambda d, o: struct.unpack_from("<H", d, o)[0], "u16le axis")
    scan(2, lambda d, o: struct.unpack_from(">H", d, o)[0], "u16be axis")
    candidates.sort(key=lambda c: -c["length"])
    out({"path": a.file, "size": len(data), "candidate_axes": len(candidates),
         "axes": candidates[:80],
         "note": "Monotonic runs are likely map axis breakpoints; the 2D/3D table usually sits adjacent. Cross-check with an A2L if you have one."})


def cmd_a2l(a):
    """Lightweight A2L (ASAP2) parser: pull CHARACTERISTIC / MEASUREMENT names + ECU addresses."""
    import re
    text = open(a.file, "r", errors="replace").read()
    chars = []
    for m in re.finditer(
        r"/begin\s+CHARACTERISTIC\s+(\S+)\s+\"([^\"]*)\"\s+(\w+)\s+(0x[0-9A-Fa-f]+)", text
    ):
        chars.append({"name": m.group(1), "desc": m.group(2), "kind": m.group(3), "address": m.group(4)})
    meas = []
    for m in re.finditer(r"/begin\s+MEASUREMENT\s+(\S+)\s+\"([^\"]*)\"", text):
        block = text[m.start():m.start() + 600]
        addr = re.search(r"ECU_ADDRESS\s+(0x[0-9A-Fa-f]+)", block)
        meas.append({"name": m.group(1), "desc": m.group(2), "address": addr.group(1) if addr else None})
    out({
        "file": a.file,
        "characteristic_count": len(chars), "measurement_count": len(meas),
        "characteristics": chars[:150], "measurements": meas[:150],
        "note": "Calibration objects (maps/curves/values) and their ECU addresses — line these up with find_maps offsets.",
    })


def cmd_keydiff(a):
    """Byte-diff two module dumps; group contiguous changes into regions."""
    da = open(a.a, "rb").read()
    db = open(a.b, "rb").read()
    n = min(len(da), len(db))
    diffs = [off for off in range(n) if da[off] != db[off]]
    regions = []
    cur = None
    gap = a.gap
    for off in diffs:
        if cur and off - cur[1] <= gap:
            cur[1] = off
        else:
            if cur:
                regions.append(cur)
            cur = [off, off]
    if cur:
        regions.append(cur)
    out_regions = []
    for s, e in regions[:300]:
        e2 = e + 1
        out_regions.append({"offset": hex(s), "length": e2 - s, "before": da[s:e2].hex(), "after": db[s:e2].hex()})
    out_regions.sort(key=lambda r: -r["length"])
    note = "Contiguous changed regions (gaps <= %d merged). Diffing an RFHub dump taken before vs after adding a key: the largest changed region is usually the key slot / transponder-ID table; tiny isolated changes are often counters or checksums; a single flipped byte near a key entry can be the red(master)/black(valet) flag." % gap
    if len(da) != len(db):
        note = ("size differs (%d vs %d). " % (len(da), len(db))) + note
    out({"a": a.a, "b": a.b, "compared": n, "changed_bytes": len(diffs),
         "region_count": len(out_regions), "regions": out_regions, "note": note})


def cmd_keyrecord(a):
    """Heuristically locate a fixed-size key-record table and label its fields."""
    data = open(a.file, "rb").read()
    n = len(data)
    sizes = [a.record_size] if a.record_size else [8, 12, 16, 20, 24, 32, 48, 64]

    def is_empty(b):
        return all(x == 0xFF for x in b) or all(x == 0 for x in b)

    def populated(b):
        return (not is_empty(b)) and len(set(b)) >= 3

    candidates = []
    for R in sizes:
        for align in range(0, R):
            blocks = []
            j = align
            while j + R <= n:
                b = data[j : j + R]
                blocks.append((j, "E" if is_empty(b) else ("P" if populated(b) else "X")))
                j += R
            # Cluster populated slots, allowing up to 2 empty gaps between them.
            i = 0
            while i < len(blocks):
                if blocks[i][1] == "P":
                    s = i
                    last_p = i
                    k = i + 1
                    while k < len(blocks):
                        if blocks[k][1] == "P":
                            last_p = k
                            k += 1
                        elif blocks[k][1] == "E" and (k - last_p) <= 2:
                            k += 1
                        else:
                            break
                    pcount = sum(1 for _, c in blocks[s : last_p + 1] if c == "P")
                    before_e = s > 0 and blocks[s - 1][1] == "E"
                    after_e = (last_p + 1) < len(blocks) and blocks[last_p + 1][1] == "E"
                    # A real key table has SPARE (empty) slots adjacent — rejects dense/random regions.
                    if 1 <= pcount <= 16 and (before_e or after_e):
                        pops = [data[o : o + R] for (o, c) in blocks[s : last_p + 1] if c == "P"]
                        # Reject wrong/misaligned record sizes whose "records" are mostly
                        # padding/erased (0x00/0xFF) — that means R is too big or off-grid.
                        pad_frac = sum(b in (0x00, 0xFF) for rec in pops for b in rec) / float(R * max(1, len(pops)))
                        if pad_frac > 0.6:
                            i = last_p + 1
                            continue
                        # Structural regularity: a true record has BOTH varying columns (the
                        # ID) AND a MEANINGFUL constant column (a marker/type byte that isn't
                        # just 0x00/0xFF padding). Random config blobs have neither.
                        meaningful_const = (
                            sum(1 for pos in range(R)
                                if len({rec[pos] for rec in pops}) == 1 and next(iter({rec[pos] for rec in pops})) not in (0x00, 0xFF))
                            if len(pops) >= 2 else 0
                        )
                        var_cols = sum(1 for pos in range(R) if len({rec[pos] for rec in pops}) > 1) if len(pops) >= 2 else 0
                        structured = 1 if (meaningful_const >= 1 and var_cols >= 2 and len(pops) >= 2) else 0
                        const_cols = meaningful_const
                        start = s
                        le = 0
                        while start > 0 and blocks[start - 1][1] == "E" and le < 2:
                            start -= 1
                            le += 1
                        end = last_p
                        te = 0
                        while end + 1 < len(blocks) and blocks[end + 1][1] == "E" and te < 4:
                            end += 1
                            te += 1
                        win = blocks[start : end + 1]
                        # Prefer finer (smaller) record sizes on ties via the -R*0.1 term.
                        score = structured * 40 + const_cols * 8 + pcount * 3 + (5 if R in (16, 20, 24, 32) else 0) + (3 if (before_e and after_e) else 0) - R * 0.1
                        candidates.append({"score": score, "R": R, "off": win[0][0], "win": win,
                                           "pcount": pcount, "const_cols": const_cols, "structured": bool(structured)})
                    i = last_p + 1
                else:
                    i += 1

    if not candidates:
        out({"file": a.file, "size": n,
             "note": "No obvious fixed-size key-record table found. Try --record-size, or (most reliable) keytable_diff on a before/after pair."})
        return

    # Rank by structural score; drop overlapping duplicates so alternatives are distinct.
    candidates.sort(key=lambda c: -c["score"])
    chosen = []
    for c in candidates:
        span = (c["off"], c["off"] + c["R"] * len(c["win"]))
        if any(not (span[1] <= x["off"] or span[0] >= x["off"] + x["R"] * len(x["win"])) for x in chosen):
            continue
        chosen.append(c)
        if len(chosen) >= 5:
            break

    best = chosen[0]
    R = best["R"]
    records = [(o, c, data[o : o + R]) for (o, c) in best["win"]]
    pops = [b for (_, c, b) in records if c == "P"]

    segs = []
    if pops:
        varies = [len({rec[pos] for rec in pops}) > 1 for pos in range(R)]
        p = 0
        while p < R:
            q = p
            while q < R and varies[q] == varies[p]:
                q += 1
            kind = "varying → likely transponder ID / unique key data" if varies[p] else "constant → candidate type / master(red)-valet(black) flag / padding"
            segs.append({"bytes": f"{p}..{q - 1}", "len": q - p, "kind": kind,
                         "values": sorted({rec[b] for rec in pops for b in range(p, q)})[:8] if not varies[p] else None})
            p = q

    out({
        "file": a.file, "size": n,
        "best_guess": {"record_size": R, "table_offset": hex(best["off"]),
                       "structured": best["structured"], "constant_columns": best["const_cols"], "score": best["score"]},
        "slots": len(records),
        "populated": sum(1 for (_, c, _b) in records if c == "P"),
        "empty": sum(1 for (_, c, _b) in records if c == "E"),
        "records": [{"offset": hex(o), "state": "populated" if c == "P" else "empty", "hex": b.hex()} for (o, c, b) in records[:24]],
        "field_layout": segs,
        "other_candidates": [{"record_size": c["R"], "table_offset": hex(c["off"]), "populated": c["pcount"],
                              "constant_columns": c["const_cols"], "structured": c["structured"]} for c in chosen[1:]],
        "note": "Heuristic, ranked by structural regularity (records with BOTH varying ID bytes AND constant flag/padding columns rank highest). field_layout splits the record into varying (ID-like) vs constant (flag/type/pad) ranges. CONFIRM the real layout with keytable_diff on a before/after dump.",
    })


def _crc16_ccitt(b):
    crc = 0xFFFF
    for byte in b:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if (crc & 0x8000) else (crc << 1) & 0xFFFF
    return crc


def cmd_checksum(a):
    """Identify checksum/CRC regions: report whole-file sums and find stored values that verify a preceding region."""
    import struct, binascii
    data = open(a.file, "rb").read()
    n = len(data)
    sum16 = sum(struct.unpack_from("<%dH" % (n // 2), data, 0)) & 0xFFFF if n >= 2 else 0
    sum32 = sum(struct.unpack_from("<%dI" % (n // 4), data, 0)) & 0xFFFFFFFF if n >= 4 else 0
    xor8 = 0
    for byte in data:
        xor8 ^= byte
    whole = {
        "sum8": sum(data) & 0xFF, "xor8": xor8, "sum16le": hex(sum16),
        "sum32le": hex(sum32), "crc32": hex(binascii.crc32(data) & 0xFFFFFFFF),
        "crc16_ccitt": hex(_crc16_ccitt(data)),
    }
    # Hunt for a STORED checksum: a 2/4-byte value whose preceding bytes hash to it.
    found = []
    # candidate positions: 4-aligned offsets in the last 256 bytes, plus block ends every 0x10000
    cands = set()
    for off in range(max(0, n - 256), n - 1, 2):
        cands.add(off)
    for blk in range(0x10000, n, 0x10000):
        cands.update([blk - 4, blk - 2])
    for pos in sorted(c for c in cands if 0 <= c <= n - 2):
        region = data[:pos]
        if pos + 4 <= n:
            stored32 = struct.unpack_from("<I", data, pos)[0]
            if stored32 == (binascii.crc32(region) & 0xFFFFFFFF):
                found.append({"offset": hex(pos), "width": 4, "stored": hex(stored32), "algorithm": "CRC32(LE)", "covers": f"0x0..{hex(pos)}"})
            elif region and stored32 == (sum(struct.unpack_from("<%dI" % (pos // 4), data, 0)) & 0xFFFFFFFF if pos >= 4 else 0):
                found.append({"offset": hex(pos), "width": 4, "stored": hex(stored32), "algorithm": "sum32(LE)", "covers": f"0x0..{hex(pos)}"})
        stored16 = struct.unpack_from("<H", data, pos)[0]
        if region and stored16 == (sum(struct.unpack_from("<%dH" % (pos // 2), data, 0)) & 0xFFFF if pos >= 2 else 0):
            found.append({"offset": hex(pos), "width": 2, "stored": hex(stored16), "algorithm": "sum16(LE)", "covers": f"0x0..{hex(pos)}"})
        elif stored16 == _crc16_ccitt(region):
            found.append({"offset": hex(pos), "width": 2, "stored": hex(stored16), "algorithm": "CRC16-CCITT", "covers": f"0x0..{hex(pos)}"})
    out({"file": a.file, "size": n, "whole_file": whole, "verified_checksums": found[:40],
         "note": "whole_file = checksums over the entire image (compare to a value you expect). verified_checksums = stored values that actually equal a hash of the bytes before them — i.e. located + identified checksums, for verification/repair of your own dump."})


def cmd_eepmap(a):
    """Label common EEPROM structures: VIN candidates, ASCII strings, mirrored/redundant blocks."""
    import re
    data = open(a.file, "rb").read()
    text = data.decode("latin1", "replace")
    vins = []
    for m in re.finditer(r"[A-HJ-NPR-Z0-9]{17}", text):
        v = m.group(0)
        if any(c.isdigit() for c in v) and any(c.isalpha() for c in v):
            vins.append({"offset": hex(m.start()), "vin": v})
    strings = []
    for m in re.finditer(rb"[\x20-\x7e]{6,}", data):
        strings.append({"offset": hex(m.start()), "text": m.group(0).decode("latin1")[:60]})
        if len(strings) >= 120:
            break
    # Mirrored/redundant 16-byte blocks (odometer/config redundancy stores duplicates).
    mirrors = []
    seen = {}
    for off in range(0, len(data) - 16, 16):
        block = data[off:off + 16]
        if block.count(block[0:1]) == 16:  # skip all-same padding
            continue
        h = block.hex()
        if h in seen:
            mirrors.append({"offsets": [hex(seen[h]), hex(off)], "hex": h})
            if len(mirrors) >= 40:
                break
        else:
            seen[h] = off
    out({"file": a.file, "size": len(data),
         "vin_candidates": vins[:10], "strings": strings, "mirrored_blocks": mirrors,
         "note": "Heuristic EEPROM labeling. VIN candidates use the valid VIN charset; mirrored_blocks are identical 16-byte regions (often redundant odometer/config copies). Use keyrecord for the key table and find_crypto for secrets."})


def cmd_xcheck(a):
    """Cross-check multiple module dumps: VIN consistency + shared secret bytes."""
    import re
    files = a.files
    blobs = {f: open(f, "rb").read() for f in files}

    # VIN per dump.
    vins = {}
    for f, d in blobs.items():
        t = d.decode("latin1", "replace")
        found = None
        for m in re.finditer(r"[A-HJ-NPR-Z0-9]{17}", t):
            v = m.group(0)
            if any(c.isdigit() for c in v) and any(c.isalpha() for c in v):
                found = v
                break
        vins[f] = found
    vin_set = {v for v in vins.values() if v}
    vin_match = len(vin_set) == 1 and all(vins[f] for f in files)

    # Shared byte sequences present in EVERY dump (candidate immobilizer secret).
    # Take 8-byte windows from the smallest dump, keep those that appear in all,
    # skip padding/low-entropy runs, then merge adjacent hits into ranges.
    def windows(d, n=8):
        out = set()
        for i in range(0, len(d) - n, 4):
            w = d[i : i + n]
            if len(set(w)) < 4:  # skip padding / repetitive
                continue
            if all(b in (0x00, 0xFF) for b in w):
                continue
            out.add(w)
        return out

    if len(files) >= 2:
        smallest = min(blobs.values(), key=len)
        cand = windows(smallest)
        for d in blobs.values():
            cand = {w for w in cand if w in d}
        shared = sorted({w.hex() for w in cand})[:20]
    else:
        shared = []

    secret_match = len(shared) > 0
    verdict = "consistent" if (vin_match and (secret_match or len(files) < 2)) else "inconsistent"
    notes = []
    if not vin_match:
        notes.append("VIN does NOT match across all dumps — modules are not married to the same vehicle.")
    if len(files) >= 2 and not secret_match:
        notes.append("No shared secret bytes found across the dumps — they likely aren't paired (or the secret is encrypted/relocated).")
    if verdict == "consistent":
        notes.append("Dumps share a VIN" + (" and common secret bytes" if secret_match else "") + " — consistent as a set. This is necessary, NOT sufficient: the car's live multi-module handshake + hardware still decide if it starts.")

    out({
        "files": files, "vin_per_dump": vins, "vin_match": vin_match,
        "shared_secret_candidates": shared, "shared_secret_found": secret_match,
        "cross_module_consistency": verdict, "notes": notes,
    })


def cmd_patch(a):
    """Write hex bytes at an offset into a copy of the file (binary editor)."""
    import shutil
    data = bytearray(open(a.file, "rb").read())
    off = a.offset
    patch = bytes.fromhex(a.hex.replace(" ", ""))
    if off < 0 or off + len(patch) > len(data):
        err(f"patch out of range: offset {hex(off)} + {len(patch)} bytes > file size {len(data)}")
    before = bytes(data[off:off + len(patch)]).hex()
    data[off:off + len(patch)] = patch
    out_path = a.out or a.file
    open(out_path, "wb").write(bytes(data))
    out({"file": a.file, "out": out_path, "offset": hex(off), "length": len(patch),
         "before": before, "after": patch.hex(),
         "note": "Bytes written. If this region is covered by a checksum, run fix_checksum next or the module will reject the dump."})


def _recompute(data, pos, width, algo):
    import binascii, struct
    region = data[:pos]
    if algo == "crc32":
        return struct.pack("<I", binascii.crc32(region) & 0xFFFFFFFF)
    if algo == "sum32":
        n = (pos // 4) * 4
        return struct.pack("<I", sum(struct.unpack_from("<%dI" % (n // 4), data, 0)) & 0xFFFFFFFF if n else 0)
    if algo == "sum16":
        n = (pos // 2) * 2
        return struct.pack("<H", sum(struct.unpack_from("<%dH" % (n // 2), data, 0)) & 0xFFFF if n else 0)
    if algo == "crc16":
        return struct.pack("<H", _crc16_ccitt(region))
    return None


def cmd_fixck(a):
    """Recompute a stored checksum (as located by 'checksum') and write the corrected value."""
    data = bytearray(open(a.file, "rb").read())
    pos = a.offset
    algo_map = {"CRC32(LE)": ("crc32", 4), "sum32(LE)": ("sum32", 4), "sum16(LE)": ("sum16", 2), "CRC16-CCITT": ("crc16", 2)}
    if a.algorithm not in algo_map:
        err(f"unknown algorithm '{a.algorithm}'. Use one reported by checksum_scan: {list(algo_map)}")
    algo, width = algo_map[a.algorithm]
    if pos + width > len(data):
        err("checksum position out of range")
    old = bytes(data[pos:pos + width]).hex()
    new = _recompute(data, pos, width, algo)
    data[pos:pos + width] = new
    out_path = a.out or a.file
    open(out_path, "wb").write(bytes(data))
    out({"file": a.file, "out": out_path, "offset": hex(pos), "algorithm": a.algorithm,
         "old": old, "new": new.hex(), "changed": old != new.hex(),
         "note": "Checksum recalculated over 0x0.." + hex(pos) + " and written. Re-run checksum_scan to confirm it now verifies."})


def main():
    p = argparse.ArgumentParser(prog="autokit")
    sub = p.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("loadfw"); sp.add_argument("file"); sp.add_argument("--base", type=lambda x: int(x, 0), default=0)
    sp = sub.add_parser("findcrypto"); sp.add_argument("file")
    sp = sub.add_parser("maps"); sp.add_argument("file"); sp.add_argument("--min-len", type=int, default=8, dest="min_len")
    sp = sub.add_parser("a2l"); sp.add_argument("file")
    sp = sub.add_parser("keydiff"); sp.add_argument("a"); sp.add_argument("b"); sp.add_argument("--gap", type=int, default=4)
    sp = sub.add_parser("keyrecord"); sp.add_argument("file"); sp.add_argument("--record-size", type=int, default=0, dest="record_size")
    sp = sub.add_parser("checksum"); sp.add_argument("file")
    sp = sub.add_parser("eepmap"); sp.add_argument("file")
    sp = sub.add_parser("xcheck"); sp.add_argument("files", nargs="+")
    sp = sub.add_parser("patch"); sp.add_argument("file"); sp.add_argument("--offset", type=lambda x: int(x, 0), required=True); sp.add_argument("--hex", required=True); sp.add_argument("--out", default=None)
    sp = sub.add_parser("fixck"); sp.add_argument("file"); sp.add_argument("--offset", type=lambda x: int(x, 0), required=True); sp.add_argument("--algorithm", required=True); sp.add_argument("--out", default=None)
    a = p.parse_args()
    if getattr(a, "record_size", 0) == 0:
        a.record_size = None
    try:
        {"loadfw": cmd_loadfw, "findcrypto": cmd_findcrypto, "maps": cmd_maps,
         "a2l": cmd_a2l, "keydiff": cmd_keydiff, "keyrecord": cmd_keyrecord,
         "checksum": cmd_checksum, "eepmap": cmd_eepmap, "xcheck": cmd_xcheck,
         "patch": cmd_patch, "fixck": cmd_fixck}[a.cmd](a)
    except FileNotFoundError:
        err(f"file not found: {getattr(a, 'file', '?')}")
    except ImportError as e:
        err(f"missing python dependency: {e}. Run scripts/bootstrap.sh.")
    except Exception as e:
        err(f"{type(e).__name__}: {e}")


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        sys.exit(0)
