#!/usr/bin/env python3
"""
cankit — RE-Agent's CAN / diagnostics bridge.

    cankit.py dbc-info   --dbc bus.dbc
    cankit.py dbc-decode --dbc bus.dbc --id 0x3D0 --data 0011223344556677
    cankit.py uds-ref     [--service 0x27] [--nrc 0x35]

Decoding uses cantools. Live CAN (candump/cansend) needs a SocketCAN interface
and is handled by the `can_*` shell paths, not here.
"""

import argparse
import json
import sys


def out(o):
    json.dump(o, sys.stdout, default=str)
    sys.stdout.write("\n")


def err(m):
    out({"error": str(m)})
    sys.exit(0)


UDS_SERVICES = {
    0x10: "DiagnosticSessionControl", 0x11: "ECUReset", 0x14: "ClearDiagnosticInformation",
    0x19: "ReadDTCInformation", 0x22: "ReadDataByIdentifier", 0x23: "ReadMemoryByAddress",
    0x27: "SecurityAccess (seed/key)", 0x28: "CommunicationControl", 0x2A: "ReadDataByPeriodicID",
    0x2C: "DynamicallyDefineDataIdentifier", 0x2E: "WriteDataByIdentifier", 0x2F: "InputOutputControlByIdentifier",
    0x31: "RoutineControl", 0x34: "RequestDownload", 0x35: "RequestUpload", 0x36: "TransferData",
    0x37: "RequestTransferExit", 0x38: "RequestFileTransfer", 0x3D: "WriteMemoryByAddress",
    0x3E: "TesterPresent", 0x85: "ControlDTCSetting", 0x87: "LinkControl",
}

UDS_NRC = {
    0x10: "generalReject", 0x11: "serviceNotSupported", 0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat", 0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError", 0x31: "requestOutOfRange", 0x33: "securityAccessDenied",
    0x35: "invalidKey", 0x36: "exceedNumberOfAttempts", 0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted", 0x78: "requestCorrectlyReceived-ResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession", 0x7F: "serviceNotSupportedInActiveSession",
}


def cmd_dbc_info(a):
    import cantools
    db = cantools.database.load_file(a.dbc)
    msgs = []
    for m in db.messages:
        msgs.append({
            "name": m.name, "id": hex(m.frame_id), "length": m.length,
            "signals": [{"name": s.name, "start": s.start, "length": s.length,
                         "scale": s.scale, "offset": s.offset, "unit": s.unit} for s in m.signals],
        })
    out({"dbc": a.dbc, "message_count": len(msgs), "messages": msgs[:200]})


def cmd_dbc_decode(a):
    import cantools
    db = cantools.database.load_file(a.dbc)
    data = bytes.fromhex(a.data.replace(" ", ""))
    decoded = db.decode_message(a.id, data)
    out({"id": hex(a.id), "data": a.data, "decoded": {k: str(v) for k, v in decoded.items()}})


def cmd_uds_ref(a):
    res = {"services": {hex(k): v for k, v in UDS_SERVICES.items()},
           "negative_response_codes": {hex(k): v for k, v in UDS_NRC.items()}}
    if a.service is not None:
        res = {"service": hex(a.service), "name": UDS_SERVICES.get(a.service, "unknown/manufacturer-specific")}
    if a.nrc is not None:
        res = {"nrc": hex(a.nrc), "meaning": UDS_NRC.get(a.nrc, "unknown/manufacturer-specific")}
    out(res)


def main():
    p = argparse.ArgumentParser(prog="cankit")
    sub = p.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("dbc-info"); sp.add_argument("--dbc", required=True)
    sp = sub.add_parser("dbc-decode"); sp.add_argument("--dbc", required=True)
    sp.add_argument("--id", required=True, type=lambda x: int(x, 0)); sp.add_argument("--data", required=True)
    sp = sub.add_parser("uds-ref"); sp.add_argument("--service", type=lambda x: int(x, 0), default=None)
    sp.add_argument("--nrc", type=lambda x: int(x, 0), default=None)
    a = p.parse_args()
    try:
        {"dbc-info": cmd_dbc_info, "dbc-decode": cmd_dbc_decode, "uds-ref": cmd_uds_ref}[a.cmd](a)
    except FileNotFoundError:
        err(f"file not found: {getattr(a, 'dbc', '?')}")
    except ImportError as e:
        err(f"missing python dependency: {e}. Run scripts/bootstrap.sh.")
    except Exception as e:
        err(f"{type(e).__name__}: {e}")


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        sys.exit(0)
