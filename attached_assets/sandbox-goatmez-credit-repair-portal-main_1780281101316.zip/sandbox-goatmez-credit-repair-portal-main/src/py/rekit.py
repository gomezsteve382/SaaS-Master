#!/usr/bin/env python3
"""
rekit — RE-Agent's Python analysis bridge.

Each subcommand prints a single JSON object to stdout. The TypeScript tools
shell out to this and parse the result. Heavy lifting uses capstone (disasm),
lief (universal PE/ELF/Mach-O parser), pefile (rich PE detail) and pyelftools.

Usage:
    rekit.py identify <file>
    rekit.py meta     <file>
    rekit.py pe       <file>
    rekit.py elf      <file>
    rekit.py entropy  <file> [--block 4096]
    rekit.py disasm   <file> --offset 0 --size 256 [--arch x86] [--bits 64] [--base 0]
"""

import argparse
import hashlib
import json
import math
import sys


def out(obj):
    json.dump(obj, sys.stdout, default=str)
    sys.stdout.write("\n")


def err(msg):
    out({"error": str(msg)})
    sys.exit(0)  # report errors as data, not crashes — the agent handles them


def shannon(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    h = 0.0
    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)
    return round(h, 4)


def read_bytes(path, offset=0, size=None):
    with open(path, "rb") as f:
        f.seek(offset)
        return f.read() if size is None else f.read(size)


def cmd_identify(a):
    data = read_bytes(a.file)
    md5 = hashlib.md5(data).hexdigest()
    sha1 = hashlib.sha1(data).hexdigest()
    sha256 = hashlib.sha256(data).hexdigest()
    magic = data[:16].hex()
    kind = "unknown"
    head = data[:8]
    if head[:2] == b"MZ":
        kind = "PE/DOS executable (.exe/.dll)"
    elif head[:4] == b"\x7fELF":
        kind = "ELF executable/shared object"
    elif head[:4] in (b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe", b"\xca\xfe\xba\xbe"):
        kind = "Mach-O / universal binary"
    elif head[:3] in (b"FWS", b"CWS", b"ZWS"):
        comp = {"F": "uncompressed", "C": "zlib", "Z": "lzma"}[chr(head[0])]
        kind = f"Adobe Flash SWF ({comp})"
    elif head[:4] == b"\xca\xfe\xba\xbe":
        kind = "Java class file"
    elif head[:2] == b"PK":
        kind = "ZIP archive (jar/apk/zip/office)"
    elif head[:4] == b"dex\n":
        kind = "Android DEX"
    out({
        "path": a.file,
        "size": len(data),
        "kind": kind,
        "magic_hex": magic,
        "entropy": shannon(data[:1 << 20]),  # first 1 MiB
        "md5": md5,
        "sha1": sha1,
        "sha256": sha256,
    })


def cmd_meta(a):
    import lief
    binary = lief.parse(a.file)
    if binary is None:
        err("lief could not parse this file (not a native executable format)")
    fmt = str(binary.format).split(".")[-1]
    info = {"format": fmt, "entrypoint": hex(binary.entrypoint)}
    try:
        info["arch"] = str(binary.header.machine_type).split(".")[-1]
    except Exception:
        pass
    secs = []
    for s in binary.sections:
        try:
            ent = round(s.entropy, 3)
        except Exception:
            ent = None
        secs.append({"name": s.name, "size": s.size, "vaddr": hex(getattr(s, "virtual_address", 0)), "entropy": ent})
    info["sections"] = secs
    try:
        info["libraries"] = list(binary.libraries)
    except Exception:
        pass
    # high-entropy section => likely packed/encrypted
    info["packed_hint"] = any((s["entropy"] or 0) > 7.2 for s in secs)
    out(info)


SUSPICIOUS_APIS = {
    "VirtualAlloc", "VirtualProtect", "WriteProcessMemory", "CreateRemoteThread",
    "LoadLibraryA", "LoadLibraryW", "GetProcAddress", "WinExec", "ShellExecuteA",
    "ShellExecuteW", "URLDownloadToFileA", "URLDownloadToFile", "InternetOpenA",
    "InternetOpenUrlA", "CreateProcessA", "CreateProcessW", "RegSetValueExA",
    "RegCreateKeyExA", "CryptEncrypt", "CryptDecrypt", "SetWindowsHookExA",
    "IsDebuggerPresent", "CheckRemoteDebuggerPresent", "NtQueryInformationProcess",
    "VirtualAllocEx", "ResumeThread", "WriteFile", "CreateServiceA", "OpenSCManagerA",
}


def cmd_pe(a):
    import pefile
    pe = pefile.PE(a.file, fast_load=False)
    res = {
        "machine": hex(pe.FILE_HEADER.Machine),
        "timestamp": pe.FILE_HEADER.TimeDateStamp,
        "subsystem": pe.OPTIONAL_HEADER.Subsystem,
        "dll": bool(pe.FILE_HEADER.Characteristics & 0x2000),
        "entrypoint": hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint),
        "image_base": hex(pe.OPTIONAL_HEADER.ImageBase),
    }
    res["sections"] = [
        {
            "name": s.Name.rstrip(b"\x00").decode("latin1", "replace"),
            "vaddr": hex(s.VirtualAddress),
            "vsize": s.Misc_VirtualSize,
            "rawsize": s.SizeOfRawData,
            "entropy": round(s.get_entropy(), 3),
        }
        for s in pe.sections
    ]
    imports = {}
    suspicious = []
    if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
        for entry in pe.DIRECTORY_ENTRY_IMPORT:
            dll = entry.dll.decode("latin1", "replace") if entry.dll else "?"
            funcs = []
            for imp in entry.imports:
                nm = imp.name.decode("latin1", "replace") if imp.name else f"ord_{imp.ordinal}"
                funcs.append(nm)
                if nm in SUSPICIOUS_APIS:
                    suspicious.append(f"{dll}!{nm}")
            imports[dll] = funcs
    res["imports"] = imports
    res["suspicious_imports"] = sorted(set(suspicious))
    exports = []
    if hasattr(pe, "DIRECTORY_ENTRY_EXPORT"):
        for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
            if exp.name:
                exports.append(exp.name.decode("latin1", "replace"))
    res["exports"] = exports
    res["packed_hint"] = any(s["entropy"] > 7.2 for s in res["sections"])
    out(res)


def cmd_elf(a):
    from elftools.elf.elffile import ELFFile
    with open(a.file, "rb") as f:
        elf = ELFFile(f)
        res = {
            "class": elf.elfclass,
            "machine": elf["e_machine"],
            "type": elf["e_type"],
            "entry": hex(elf["e_entry"]),
            "sections": [{"name": s.name, "size": s["sh_size"], "addr": hex(s["sh_addr"])} for s in elf.iter_sections()],
        }
        needed, runpath = [], []
        dyn = elf.get_section_by_name(".dynamic")
        if dyn is not None:
            for tag in dyn.iter_tags():
                if tag.entry.d_tag == "DT_NEEDED":
                    needed.append(tag.needed)
                elif tag.entry.d_tag in ("DT_RUNPATH", "DT_RPATH"):
                    runpath.append(getattr(tag, "runpath", getattr(tag, "rpath", "")))
        res["needed"] = needed
        res["runpath"] = runpath
        out(res)


def cmd_entropy(a):
    data = read_bytes(a.file)
    block = a.block
    blocks = []
    for i in range(0, len(data), block):
        blocks.append({"offset": hex(i), "entropy": shannon(data[i : i + block])})
    out({"size": len(data), "block": block, "overall": shannon(data), "blocks": blocks[:512]})


CS = {
    ("x86", 16): ("CS_ARCH_X86", "CS_MODE_16"),
    ("x86", 32): ("CS_ARCH_X86", "CS_MODE_32"),
    ("x86", 64): ("CS_ARCH_X86", "CS_MODE_64"),
    ("arm", 32): ("CS_ARCH_ARM", "CS_MODE_ARM"),
    ("arm", 64): ("CS_ARCH_ARM64", "CS_MODE_ARM"),
    ("mips", 32): ("CS_ARCH_MIPS", "CS_MODE_32"),
    ("mips", 64): ("CS_ARCH_MIPS", "CS_MODE_64"),
}


def cmd_disasm(a):
    import capstone
    key = (a.arch, a.bits)
    if key not in CS:
        err(f"unsupported arch/bits {a.arch}/{a.bits}; supported: {list(CS.keys())}")
    arch_name, mode_name = CS[key]
    md = capstone.Cs(getattr(capstone, arch_name), getattr(capstone, mode_name))
    code = read_bytes(a.file, a.offset, a.size)
    insns = []
    for ins in md.disasm(code, a.base if a.base else a.offset):
        insns.append({
            "addr": hex(ins.address),
            "bytes": ins.bytes.hex(),
            "mnemonic": ins.mnemonic,
            "op_str": ins.op_str,
        })
    out({"arch": a.arch, "bits": a.bits, "count": len(insns), "insns": insns})


def main():
    p = argparse.ArgumentParser(prog="rekit")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("identify", "meta", "pe", "elf"):
        sp = sub.add_parser(name)
        sp.add_argument("file")
    sp = sub.add_parser("entropy")
    sp.add_argument("file")
    sp.add_argument("--block", type=int, default=4096)
    sp = sub.add_parser("disasm")
    sp.add_argument("file")
    sp.add_argument("--offset", type=int, default=0)
    sp.add_argument("--size", type=int, default=256)
    sp.add_argument("--arch", default="x86")
    sp.add_argument("--bits", type=int, default=64)
    sp.add_argument("--base", type=int, default=0)
    args = p.parse_args()

    handlers = {
        "identify": cmd_identify, "meta": cmd_meta, "pe": cmd_pe, "elf": cmd_elf,
        "entropy": cmd_entropy, "disasm": cmd_disasm,
    }
    try:
        handlers[args.cmd](args)
    except FileNotFoundError:
        err(f"file not found: {getattr(args, 'file', '?')}")
    except ImportError as e:
        err(f"missing python dependency: {e}. Run scripts/bootstrap.sh.")
    except Exception as e:
        err(f"{type(e).__name__}: {e}")


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        # Reader closed early (e.g. piped to `head`); exit quietly.
        try:
            sys.stdout.close()
        except Exception:
            pass
        sys.exit(0)
