#!/usr/bin/env python3
"""
udssim — a behavioral UDS module simulator for the virtual bench.

Runs on a SocketCAN interface (e.g. vcan0) and answers UDS (ISO 14229) requests
as a chosen module (ECM/BCM/RFHub/Cluster). SOFTWARE-IN-THE-LOOP only — it does
NOT run real firmware and is not on a real vehicle. Fidelity options:

  --keyfn FILE     python file with `def key(seed: bytes) -> bytes` (the REAL
                   seed->key, e.g. recovered via the `emulate` tool). The sim then
                   only accepts a correct key — so your tester's key code is tested.
  --max-attempts N lock out after N bad keys (NRC 0x36), like a real ECU.
  --p2 MS          delay before every response (P2 server timing).
  --pending-ms MS  for slow services, send NRC 0x78 (responsePending) then the
                   real reply after MS — tests your pending/timeout handling.
  --stmin MS       ISO-TP flow-control STmin advertised to the tester.
  --did KEY=HEX    seed a DID (e.g. --did F190=31433344...) from real file data.
  --vin VIN        shorthand for --did F190=<ascii VIN>.

    udssim.py --module rfhub --channel vcan0 --keyfn keyfn.py --max-attempts 3 --p2 30
"""

import argparse
import json
import os
import sys
import time

PRESETS = {
    "ecm": (0x7E0, 0x7E8),
    "tcm": (0x7E1, 0x7E9),
    "bcm": (0x720, 0x728),
    "rfhub": (0x751, 0x759),
    "cluster": (0x760, 0x768),
}

PENDING_SERVICES = {0x27, 0x31, 0x34, 0x35, 0x36, 0x2E}


def emit(o):
    sys.stdout.write(json.dumps(o) + "\n")
    sys.stdout.flush()


def build_dids(args):
    dids = {}
    if args.vin:
        dids[0xF190] = args.vin.encode("latin1")[:17]
    dids[0xF18C] = (args.module.upper() + "-SIM").encode("latin1")
    for spec in args.did or []:
        if "=" not in spec:
            continue
        k, v = spec.split("=", 1)
        try:
            dids[int(k, 16)] = bytes.fromhex(v)
        except ValueError:
            dids[int(k, 16)] = v.encode("latin1")
    return dids


def load_keyfn(path):
    if not path:
        return None
    import importlib.util
    spec = importlib.util.spec_from_file_location("keyfn", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "key"):
        raise RuntimeError(f"{path} has no `key(seed: bytes) -> bytes` function")
    return mod.key


def handle(req, dids, state, cfg):
    if not req:
        return None
    sid = req[0]
    if sid == 0x3E:
        return bytes([0x7E, req[1] if len(req) > 1 else 0x00])
    if sid == 0x10:
        sub = req[1] if len(req) > 1 else 0x01
        return bytes([0x50, sub, 0x00, 0x32, 0x01, 0xF4])
    if sid == 0x11:
        return bytes([0x51, req[1] if len(req) > 1 else 0x01])
    if sid == 0x22 and len(req) >= 3:
        did = (req[1] << 8) | req[2]
        if did in dids:
            return bytes([0x62, req[1], req[2]]) + dids[did]
        return bytes([0x7F, 0x22, 0x31])
    if sid == 0x27 and len(req) >= 2:
        sub = req[1]
        if sub % 2 == 1:  # requestSeed
            if state.get("locked"):
                return bytes([0x7F, 0x27, 0x37])  # requiredTimeDelayNotExpired
            seed = bytes.fromhex(cfg["seed_fixed"]) if cfg["seed_fixed"] else os.urandom(4)
            state["seed"] = seed
            return bytes([0x67, sub]) + seed
        # sendKey
        key = req[2:]
        keyfn = cfg["keyfn"]
        if keyfn is None:
            return bytes([0x67, sub])  # no algorithm loaded → accept (demo)
        try:
            expected = keyfn(state.get("seed", b""))
        except Exception as e:
            return bytes([0x7F, 0x27, 0x22])  # conditionsNotCorrect
        if bytes(key) == bytes(expected):
            state["attempts"] = 0
            return bytes([0x67, sub])
        state["attempts"] = state.get("attempts", 0) + 1
        if state["attempts"] >= cfg["max_attempts"]:
            state["locked"] = True
            return bytes([0x7F, 0x27, 0x36])  # exceedNumberOfAttempts
        return bytes([0x7F, 0x27, 0x35])  # invalidKey
    if sid == 0x19:
        return bytes([0x59, req[1] if len(req) > 1 else 0x01, 0xFF, 0x00, 0x00])
    if sid == 0x14:
        return bytes([0x54])
    if sid == 0x2E and len(req) >= 3:  # WriteDataByIdentifier (sim accepts + stores)
        dids[(req[1] << 8) | req[2]] = bytes(req[3:])
        return bytes([0x6E, req[1], req[2]])
    return bytes([0x7F, sid, 0x11])


def main():
    ap = argparse.ArgumentParser(prog="udssim")
    ap.add_argument("--module", default="ecm", choices=list(PRESETS.keys()))
    ap.add_argument("--channel", default="vcan0")
    ap.add_argument("--rxid", type=lambda x: int(x, 0), default=None)
    ap.add_argument("--txid", type=lambda x: int(x, 0), default=None)
    ap.add_argument("--vin", default=None)
    ap.add_argument("--did", action="append", default=[])
    ap.add_argument("--keyfn", default=None)
    ap.add_argument("--max-attempts", type=int, default=3, dest="max_attempts")
    ap.add_argument("--p2", type=int, default=0, help="response delay ms")
    ap.add_argument("--pending-ms", type=int, default=0, dest="pending_ms")
    ap.add_argument("--stmin", type=int, default=0, help="ISO-TP STmin ms")
    ap.add_argument("--seed-fixed", default=None, dest="seed_fixed")
    args = ap.parse_args()

    try:
        import can
        import isotp
    except ImportError as e:
        emit({"type": "error", "message": f"missing dependency: {e}. Run: pip install python-can can-isotp"})
        return

    try:
        keyfn = load_keyfn(args.keyfn)
    except Exception as e:
        emit({"type": "error", "message": f"keyfn load failed: {e}"})
        return

    rxid, txid = PRESETS[args.module]
    if args.rxid is not None:
        rxid = args.rxid
    if args.txid is not None:
        txid = args.txid

    try:
        bus = can.interface.Bus(channel=args.channel, interface="socketcan")
    except Exception as e:
        emit({"type": "error", "message": f"cannot open {args.channel}: {e}. Bring up vcan first."})
        return

    addr = isotp.Address(isotp.AddressingMode.Normal_11bits, rxid=rxid, txid=txid)
    params = {}
    if args.stmin:
        params["stmin"] = args.stmin
    stack = isotp.CanStack(bus, address=addr, params=params or None)
    dids = build_dids(args)
    state = {}
    cfg = {"keyfn": keyfn, "max_attempts": args.max_attempts, "seed_fixed": args.seed_fixed}
    emit({"type": "ready", "module": args.module, "channel": args.channel, "rxid": hex(rxid), "txid": hex(txid),
          "key_validation": keyfn is not None, "dids": [hex(k) for k in dids]})

    while True:
        stack.process()
        if stack.available():
            req = bytes(stack.recv())
            sid = req[0] if req else None
            resp = handle(req, dids, state, cfg)
            if resp is not None:
                if args.pending_ms and sid in PENDING_SERVICES and resp[0] != 0x7F:
                    stack.send(bytes([0x7F, sid, 0x78]))
                    while stack.transmitting():
                        stack.process()
                        time.sleep(0.001)
                    time.sleep(args.pending_ms / 1000.0)
                if args.p2:
                    time.sleep(args.p2 / 1000.0)
                stack.send(resp)
                emit({"type": "txn", "req": req.hex(), "resp": resp.hex()})
        time.sleep(0.003)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        emit({"type": "error", "message": f"{type(e).__name__}: {e}"})
