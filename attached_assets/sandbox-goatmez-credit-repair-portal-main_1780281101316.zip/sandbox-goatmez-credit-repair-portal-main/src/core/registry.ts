import type { ToolDef } from "./types.ts";
import type { OpenAITool } from "./model.ts";
import { ALL_TOOLS } from "../tools/index.ts";

export const TOOL_REGISTRY: Record<string, ToolDef> = Object.fromEntries(
  ALL_TOOLS.map(t => [t.name, t])
);

/** Tool definitions in the OpenAI Chat-Completions shape OpenRouter expects. */
export function getOpenAITools(): OpenAITool[] {
  return ALL_TOOLS.map(t => ({
    type: "function",
    function: {
      name: t.name,
      description: t.description,
      parameters: t.inputSchema,
    },
  }));
}
