/**
 * OpenRouter chat client (OpenAI Chat-Completions compatible, streaming).
 *
 * Dependency-free `fetch` implementation. Adds, over a naive client:
 *   - env-driven model + max_tokens
 *   - automatic fallback across `RE_AGENT_FALLBACK_MODELS`
 *   - retry-with-backoff on transient (5xx / network) failures
 *   - usage capture (prompt/completion tokens) from the final stream chunk
 *   - AbortSignal support (Ctrl-C cancels the in-flight request)
 */

import { config } from "./config.ts";

export type OpenAIToolCall = {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
};

export type OpenAIMessage =
  | { role: "system"; content: string }
  | { role: "user"; content: string }
  | { role: "assistant"; content: string | null; tool_calls?: OpenAIToolCall[] }
  | { role: "tool"; tool_call_id: string; content: string };

export type OpenAITool = {
  type: "function";
  function: {
    name: string;
    description?: string;
    parameters?: Record<string, unknown>;
  };
};

export type Usage = { prompt: number; completion: number };

export type ChatResult = {
  content: string;
  toolCalls: OpenAIToolCall[];
  finishReason: string | null;
  model: string;
  usage: Usage | null;
};

export class ModelAuthError extends Error {
  constructor(msg: string) {
    super(msg);
    this.name = "ModelAuthError";
  }
}

type StreamParams = {
  messages: OpenAIMessage[];
  tools?: OpenAITool[];
  onText?: (delta: string) => void;
  signal?: AbortSignal;
};

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

/** Stream a completion, trying the primary model then each fallback, retrying transient errors. */
export async function chat(params: StreamParams): Promise<ChatResult> {
  if (!config.apiKey) {
    throw new ModelAuthError(
      "OPENROUTER_API_KEY is not set. Put it in your environment or a .env file (see .env.example)."
    );
  }

  const models = [config.model, ...config.fallbackModels];
  let lastErr: unknown;

  for (const model of models) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await streamOnce(model, params);
      } catch (err) {
        lastErr = err;
        if (err instanceof ModelAuthError) throw err; // never retry auth failures
        if (params.signal?.aborted) throw err;
        const transient = err instanceof TransientError;
        if (!transient) break; // non-transient: move to next fallback model
        await sleep(500 * 2 ** attempt); // 0.5s, 1s, 2s
      }
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error(String(lastErr));
}

class TransientError extends Error {}

async function streamOnce(
  model: string,
  params: StreamParams
): Promise<ChatResult> {
  const body: Record<string, unknown> = {
    model,
    max_tokens: config.maxTokens,
    stream: true,
    stream_options: { include_usage: true },
    messages: params.messages,
  };
  if (params.tools && params.tools.length > 0) {
    body.tools = params.tools;
    body.tool_choice = "auto";
    body.parallel_tool_calls = false;
  }

  let response: Response;
  try {
    response = await fetch(`${config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${config.apiKey}`,
        "HTTP-Referer": config.referer,
        "X-Title": config.title,
      },
      body: JSON.stringify(body),
      signal: params.signal,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new TransientError(`network error reaching OpenRouter: ${msg}`);
  }

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    if (response.status === 401 || response.status === 403) {
      throw new ModelAuthError(
        `OpenRouter auth failed (${response.status}). Check OPENROUTER_API_KEY.`
      );
    }
    if (response.status === 429 || response.status >= 500) {
      throw new TransientError(
        `OpenRouter ${response.status}: ${text.slice(0, 300)}`
      );
    }
    throw new Error(
      `OpenRouter ${response.status} ${response.statusText}: ${text.slice(0, 500)}`
    );
  }
  if (!response.body) throw new TransientError("empty response body");

  let content = "";
  let finishReason: string | null = null;
  let usage: Usage | null = null;
  const toolByIndex = new Map<
    number,
    { id: string; name: string; arguments: string }
  >();

  const handle = (data: string) => {
    if (data === "[DONE]") return;
    let p: any;
    try {
      p = JSON.parse(data);
    } catch {
      return;
    }
    if (p.error?.message)
      throw new Error(`OpenRouter stream error: ${p.error.message}`);
    if (p.usage) {
      usage = {
        prompt: p.usage.prompt_tokens ?? 0,
        completion: p.usage.completion_tokens ?? 0,
      };
    }
    const choice = p.choices?.[0];
    if (!choice) return;
    const delta = choice.delta ?? {};
    if (typeof delta.content === "string" && delta.content.length > 0) {
      content += delta.content;
      params.onText?.(delta.content);
    }
    if (Array.isArray(delta.tool_calls)) {
      for (const tc of delta.tool_calls) {
        const idx = tc.index ?? 0;
        const acc = toolByIndex.get(idx) ?? { id: "", name: "", arguments: "" };
        if (tc.id) acc.id = tc.id;
        if (tc.function?.name) acc.name = tc.function.name;
        if (tc.function?.arguments) acc.arguments += tc.function.arguments;
        toolByIndex.set(idx, acc);
      }
    }
    if (choice.finish_reason) finishReason = choice.finish_reason;
  };

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const drain = (line: string) => {
    const t = line.trim();
    if (!t || t.startsWith(":")) return;
    if (t.startsWith("data:")) handle(t.slice(5).trim());
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) drain(line);
  }
  if (buffer.length > 0) drain(buffer);

  const toolCalls: OpenAIToolCall[] = [...toolByIndex.keys()]
    .sort((a, b) => a - b)
    .map(i => toolByIndex.get(i)!)
    .filter(t => t.name.length > 0)
    .map(t => ({
      id: t.id || `call_${Math.random().toString(36).slice(2, 12)}`,
      type: "function" as const,
      function: { name: t.name, arguments: t.arguments || "{}" },
    }));

  return { content, toolCalls, finishReason, model, usage };
}
