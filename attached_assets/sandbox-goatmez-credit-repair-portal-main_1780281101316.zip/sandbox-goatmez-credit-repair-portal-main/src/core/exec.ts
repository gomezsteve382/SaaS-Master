import { spawn } from "node:child_process";
import { config } from "./config.ts";

export type ExecOpts = {
  timeoutMs?: number;
  maxBytes?: number;
  cwd?: string;
  /** Optional data piped to stdin. */
  input?: string;
};

export type ExecResult = {
  code: number | null;
  stdout: string;
  stderr: string;
  timedOut: boolean;
  truncated: boolean;
};

/**
 * Run a subprocess with an argv array (no shell parsing of the program/args),
 * a wall-clock timeout, and an output cap. The arg-array form is for
 * correctness — it isn't a security boundary, and `run_shell` deliberately
 * bypasses it. On timeout the process tree is SIGKILLed.
 */
export function execTool(
  cmd: string,
  args: string[],
  opts: ExecOpts = {}
): Promise<ExecResult> {
  const timeoutMs = opts.timeoutMs ?? config.execTimeoutMs;
  const maxBytes = opts.maxBytes ?? config.maxOutputBytes;
  return new Promise(resolveP => {
    let stdout = "";
    let stderr = "";
    let truncated = false;
    let timedOut = false;

    const child = spawn(cmd, args, { cwd: opts.cwd, env: process.env });

    const append = (which: "o" | "e", s: string) => {
      if (which === "o") {
        if (stdout.length < maxBytes) stdout += s;
        else truncated = true;
      } else {
        if (stderr.length < maxBytes) stderr += s;
        else truncated = true;
      }
    };
    child.stdout?.on("data", (b: Buffer) => append("o", b.toString("utf8")));
    child.stderr?.on("data", (b: Buffer) => append("e", b.toString("utf8")));

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, timeoutMs);

    child.on("error", err => {
      clearTimeout(timer);
      resolveP({
        code: null,
        stdout,
        stderr: `${stderr}\n[spawn error] ${err.message}`,
        timedOut,
        truncated,
      });
    });

    child.on("close", code => {
      clearTimeout(timer);
      resolveP({
        code,
        stdout: stdout.slice(0, maxBytes),
        stderr: stderr.slice(0, maxBytes),
        timedOut,
        truncated,
      });
    });

    if (opts.input != null) {
      child.stdin?.write(opts.input);
      child.stdin?.end();
    }
  });
}

/** True if `cmd` is on PATH. */
export async function which(cmd: string): Promise<boolean> {
  const r = await execTool("sh", ["-c", `command -v "${cmd}"`], {
    timeoutMs: 5000,
  });
  return r.code === 0 && r.stdout.trim().length > 0;
}

/** Convenience: format an ExecResult into a single text blob for the model. */
export function execText(r: ExecResult): string {
  const parts: string[] = [];
  if (r.stdout.trim()) parts.push(r.stdout.trimEnd());
  if (r.stderr.trim()) parts.push(`[stderr]\n${r.stderr.trimEnd()}`);
  if (r.timedOut) parts.push("[timed out]");
  if (r.truncated) parts.push("[output truncated]");
  if (parts.length === 0) parts.push("(no output)");
  return parts.join("\n");
}
