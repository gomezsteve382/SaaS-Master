import { mkdir, readFile, writeFile, readdir, unlink } from "node:fs/promises";
import { join } from "node:path";
import { config } from "./config.ts";
import type { OpenAIMessage } from "./model.ts";

export type StoredSession = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: OpenAIMessage[];
};

export type SessionSummary = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: number;
};

const DIR = config.sessionsDir;
const safe = (id: string) => id.replace(/[^\w-]/g, "").slice(0, 80);
const file = (id: string) => join(DIR, `${safe(id)}.json`);

/** Persist a session transcript (best-effort; never throws). */
export async function saveSession(s: StoredSession): Promise<void> {
  try {
    await mkdir(DIR, { recursive: true });
    await writeFile(file(s.id), JSON.stringify(s));
  } catch {
    /* persistence is best-effort */
  }
}

export async function loadSession(id: string): Promise<StoredSession | null> {
  try {
    return JSON.parse(await readFile(file(id), "utf8")) as StoredSession;
  } catch {
    return null;
  }
}

export async function deleteSession(id: string): Promise<void> {
  try {
    await unlink(file(id));
  } catch {
    /* already gone */
  }
}

/** List saved sessions, newest first. */
export async function listSessions(): Promise<SessionSummary[]> {
  let names: string[] = [];
  try {
    names = (await readdir(DIR)).filter(n => n.endsWith(".json"));
  } catch {
    return [];
  }
  const out: SessionSummary[] = [];
  for (const n of names) {
    try {
      const s = JSON.parse(
        await readFile(join(DIR, n), "utf8")
      ) as StoredSession;
      out.push({
        id: s.id,
        title: s.title,
        createdAt: s.createdAt,
        updatedAt: s.updatedAt,
        messages: s.messages.length,
      });
    } catch {
      /* skip corrupt */
    }
  }
  return out.sort((a, b) => b.updatedAt - a.updatedAt);
}
