/**
 * Rough OpenRouter pricing ($ per 1M tokens, input/output) for the cumulative
 * cost readout. Approximate — override exactly with RE_AGENT_PRICE_IN /
 * RE_AGENT_PRICE_OUT (USD per 1M tokens) for your actual model/rate.
 */
const PRICING: Record<string, { in: number; out: number }> = {
  "anthropic/claude-opus-4": { in: 15, out: 75 },
  "anthropic/claude-sonnet-4.5": { in: 3, out: 15 },
  "anthropic/claude-sonnet-4": { in: 3, out: 15 },
  "anthropic/claude-haiku-4.5": { in: 1, out: 5 },
  "openai/gpt-4.1-mini": { in: 0.4, out: 1.6 },
  "openai/gpt-4.1": { in: 2, out: 8 },
  "openai/gpt-4o-mini": { in: 0.15, out: 0.6 },
};

export function priceFor(model: string): { in: number; out: number } | null {
  const envIn = Number(process.env.RE_AGENT_PRICE_IN);
  const envOut = Number(process.env.RE_AGENT_PRICE_OUT);
  if (Number.isFinite(envIn) && Number.isFinite(envOut))
    return { in: envIn, out: envOut };
  for (const k of Object.keys(PRICING))
    if (model.startsWith(k)) return PRICING[k];
  return null;
}

/** Cost in USD for a turn, or null if the model's price is unknown. */
export function costUsd(
  model: string,
  promptTok: number,
  completionTok: number
): number | null {
  const p = priceFor(model);
  if (!p) return null;
  return (promptTok * p.in + completionTok * p.out) / 1_000_000;
}
