import { chat, ModelAuthError, type OpenAIMessage } from "./model.ts";
import { config } from "./config.ts";
import { TOOL_REGISTRY, getOpenAITools } from "./registry.ts";
import { recordHistory } from "./history.ts";
import { buildSystemPrompt } from "./prompt.ts";
import { costUsd } from "./cost.ts";
import type { ToolCtx } from "./types.ts";

export type AgentEvent =
  | { type: "tool_start"; name: string; summary: string }
  | { type: "tool_end"; name: string; ok: boolean; ms: number }
  | { type: "status"; line: string }
  | {
      type: "usage";
      model: string;
      prompt: number;
      completion: number;
      costUsd: number | null;
      totalPrompt: number;
      totalCompletion: number;
      totalCostUsd: number | null;
    };

export type AgentHandlers = {
  /** Live assistant text deltas. */
  onText?: (delta: string) => void;
  /** Structural events (tool runs, status lines, token usage). */
  onEvent?: (ev: AgentEvent) => void;
};

function parseArgs(raw: string): Record<string, unknown> {
  try {
    const v = JSON.parse(raw || "{}");
    return v && typeof v === "object" ? v : {};
  } catch {
    return {};
  }
}

function truncate(value: unknown): string {
  const s = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  if (s.length <= config.maxToolResultChars) return s;
  return (
    s.slice(0, config.maxToolResultChars) +
    `\n... (truncated; ${s.length} chars total)`
  );
}

/**
 * Stateful agent. Holds the conversation, runs the tool-calling loop, and
 * executes every requested tool immediately (no confirmation). Text streams
 * via `handlers.onText`; tool/usage events via `handlers.onEvent`.
 */
export class Agent {
  private messages: OpenAIMessage[];
  private totalPrompt = 0;
  private totalCompletion = 0;
  private totalCost = 0;
  private costKnown = true;

  constructor(private cwd: string = process.cwd()) {
    this.messages = [{ role: "system", content: buildSystemPrompt() }];
  }

  reset(): void {
    this.messages = [{ role: "system", content: buildSystemPrompt() }];
  }

  /** Switch the active project directory all tools resolve paths against. */
  setCwd(dir: string): void {
    this.cwd = dir;
  }

  get workdir(): string {
    return this.cwd;
  }

  get transcript(): readonly OpenAIMessage[] {
    return this.messages;
  }

  /** Conversation without the (regenerated) system prompt — for persistence. */
  get savedMessages(): OpenAIMessage[] {
    return this.messages.slice(1);
  }

  /** Restore a saved conversation under a fresh system prompt. */
  restore(msgs: OpenAIMessage[]): void {
    this.messages = [{ role: "system", content: buildSystemPrompt() }, ...msgs];
  }

  /** First user message (used as a session title). */
  get firstUserText(): string {
    const u = this.messages.find(m => m.role === "user");
    return u && typeof u.content === "string" ? u.content : "";
  }

  async send(
    userText: string,
    handlers: AgentHandlers = {},
    signal?: AbortSignal
  ): Promise<void> {
    this.messages.push({ role: "user", content: userText });

    const tools = getOpenAITools();
    const ctx: ToolCtx = {
      cwd: this.cwd,
      log: line => handlers.onEvent?.({ type: "status", line }),
      record: entry => void recordHistory(entry),
    };

    for (let iter = 0; iter < config.maxIterations; iter++) {
      let result;
      try {
        result = await chat({
          messages: this.messages,
          tools,
          onText: handlers.onText,
          signal,
        });
      } catch (err) {
        if (err instanceof ModelAuthError) throw err;
        const msg = err instanceof Error ? err.message : String(err);
        this.messages.push({
          role: "assistant",
          content: `Error reaching the model: ${msg}`,
        });
        throw new Error(msg);
      }

      if (result.usage) {
        const turnCost = costUsd(
          result.model,
          result.usage.prompt,
          result.usage.completion
        );
        this.totalPrompt += result.usage.prompt;
        this.totalCompletion += result.usage.completion;
        if (turnCost == null) this.costKnown = false;
        else this.totalCost += turnCost;
        handlers.onEvent?.({
          type: "usage",
          model: result.model,
          prompt: result.usage.prompt,
          completion: result.usage.completion,
          costUsd: turnCost,
          totalPrompt: this.totalPrompt,
          totalCompletion: this.totalCompletion,
          totalCostUsd: this.costKnown ? this.totalCost : null,
        });
      }

      this.messages.push({
        role: "assistant",
        content: result.content || null,
        ...(result.toolCalls.length > 0
          ? { tool_calls: result.toolCalls }
          : {}),
      });

      if (result.toolCalls.length === 0) return; // natural end of turn

      for (const tc of result.toolCalls) {
        const name = tc.function.name;
        const tool = TOOL_REGISTRY[name];
        const args = parseArgs(tc.function.arguments);

        if (!tool) {
          this.pushTool(tc.id, {
            error: "UNKNOWN_TOOL",
            message: `No tool named ${name}.`,
          });
          continue;
        }

        const summary = tool.renderSummary ? safeSummary(tool, args) : name;
        handlers.onEvent?.({ type: "tool_start", name, summary });
        const started = Date.now();

        const parsed = tool.zodSchema.safeParse(args);
        if (!parsed.success) {
          this.pushTool(tc.id, {
            error: "INVALID_ARGS",
            message: parsed.error.message,
            issues: parsed.error.issues,
          });
          handlers.onEvent?.({
            type: "tool_end",
            name,
            ok: false,
            ms: Date.now() - started,
          });
          continue;
        }

        let ok = true;
        try {
          const res = await tool.handler(ctx, parsed.data);
          if (res.ok) {
            this.pushToolText(tc.id, truncate(res.data));
          } else {
            ok = false;
            this.pushTool(tc.id, {
              error: res.code,
              message: res.message,
              details: res.details,
            });
          }
          ctx.record({ tool: name, args: parsed.data, ok });
        } catch (err) {
          ok = false;
          const msg = err instanceof Error ? err.message : String(err);
          this.pushTool(tc.id, { error: "INTERNAL_ERROR", message: msg });
          ctx.record({ tool: name, args: parsed.data, ok: false, error: msg });
        }
        handlers.onEvent?.({
          type: "tool_end",
          name,
          ok,
          ms: Date.now() - started,
        });
      }
    }

    this.messages.push({
      role: "assistant",
      content: `(stopped after ${config.maxIterations} tool iterations — ask me to continue if there's more to do.)`,
    });
  }

  private pushTool(id: string, obj: Record<string, unknown>): void {
    this.messages.push({
      role: "tool",
      tool_call_id: id,
      content: JSON.stringify(obj),
    });
  }
  private pushToolText(id: string, text: string): void {
    this.messages.push({ role: "tool", tool_call_id: id, content: text });
  }
}

function safeSummary(
  tool: { renderSummary?: (a: any) => string },
  args: unknown
): string {
  try {
    return tool.renderSummary!(args) ?? "";
  } catch {
    return "";
  }
}
