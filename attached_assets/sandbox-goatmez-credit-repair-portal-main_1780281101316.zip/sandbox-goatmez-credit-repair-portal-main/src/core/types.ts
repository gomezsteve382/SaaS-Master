import type { z } from "zod";

/** Context handed to every tool handler. No permission/jail gating by design. */
export type ToolCtx = {
  /** Working directory the agent was launched from (used to resolve relative paths). */
  cwd: string;
  /** Emit a status line to the UI, e.g. "running objdump -d ...". */
  log: (line: string) => void;
  /** Append a non-blocking record to the session history log. */
  record: (entry: Record<string, unknown>) => void;
};

export type ToolResult =
  | { ok: true; data: unknown }
  | { ok: false; code: string; message: string; details?: unknown };

export type ToolDef<A = any> = {
  name: string;
  description: string;
  /** JSON Schema advertised to the model (OpenAI function-tool `parameters`). */
  inputSchema: Record<string, unknown>;
  /** Runtime validation of the model-supplied arguments. */
  zodSchema: z.ZodType<A>;
  /** External binaries this tool shells out to; surfaced if any are missing. */
  requires?: string[];
  /** Short human summary of a call, shown in the transcript. */
  renderSummary?: (args: A) => string;
  handler: (ctx: ToolCtx, args: A) => Promise<ToolResult>;
};
