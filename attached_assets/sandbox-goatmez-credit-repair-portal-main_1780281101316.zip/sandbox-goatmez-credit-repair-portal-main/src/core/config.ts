import "dotenv/config";
import { homedir } from "node:os";
import { resolve } from "node:path";

function num(v: string | undefined, d: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : d;
}

/**
 * All configuration is env-driven (see .env.example). Sensible defaults are
 * chosen for an isolated analysis sandbox: a capable-but-cheaper default model,
 * generous timeouts, and large output caps.
 */
export const config = {
  apiKey: process.env.OPENROUTER_API_KEY ?? "",
  /** OpenRouter model slug. Browse https://openrouter.ai/models */
  model: process.env.RE_AGENT_MODEL || "anthropic/claude-sonnet-4.5",
  /** Comma-separated fallbacks tried (in order) if the primary errors. */
  fallbackModels: (process.env.RE_AGENT_FALLBACK_MODELS || "")
    .split(",")
    .map(s => s.trim())
    .filter(Boolean),
  maxTokens: num(process.env.RE_AGENT_MAX_TOKENS, 8000),
  baseUrl: (
    process.env.OPENROUTER_BASE_URL || "https://openrouter.ai/api/v1"
  ).replace(/\/+$/, ""),
  referer: process.env.OPENROUTER_REFERER || "https://github.com/re-agent",
  title: process.env.OPENROUTER_TITLE || "RE-Agent",
  /** Hard stop on agent loop iterations per user turn. */
  maxIterations: num(process.env.RE_AGENT_MAX_ITERATIONS, 30),
  /** Per-tool subprocess timeout (ms). A hung tool can't freeze the agent. */
  execTimeoutMs: num(process.env.RE_AGENT_EXEC_TIMEOUT_MS, 120_000),
  /** Cap on captured stdout/stderr per command (bytes) so huge dumps don't blow context. */
  maxOutputBytes: num(process.env.RE_AGENT_MAX_OUTPUT_BYTES, 200_000),
  /** Cap on a single tool result fed back to the model (chars). */
  maxToolResultChars: num(process.env.RE_AGENT_MAX_TOOL_RESULT, 24_000),
  /** Passive JSONL history log; never blocks. */
  historyFile:
    process.env.RE_AGENT_HISTORY ||
    resolve(homedir(), ".re-agent", "history.jsonl"),
  /** Directory where bundled jars (ffdec, cfr) were installed by bootstrap.sh. */
  toolsDir: process.env.RE_TOOLS_DIR || "/opt/re-tools",
  /** Ghidra install dir (contains support/analyzeHeadless). */
  ghidraDir: process.env.GHIDRA_DIR || "/opt/re-tools/ghidra",
  /** Root dir scanned for switchable projects in the UI (e.g. where SRT Lab lives). */
  projectsRoot:
    process.env.RE_AGENT_PROJECTS_ROOT || process.env.HOME || process.cwd(),
  /** Where conversation transcripts are persisted so they survive restarts. */
  sessionsDir:
    process.env.RE_AGENT_SESSIONS ||
    resolve(homedir(), ".re-agent", "sessions"),
};

export type Config = typeof config;
