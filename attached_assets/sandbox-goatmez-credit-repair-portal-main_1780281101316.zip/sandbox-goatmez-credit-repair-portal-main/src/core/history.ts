import { appendFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";
import { config } from "./config.ts";

let dirReady = false;

/** Append a JSONL record to the history log. Best-effort: never throws. */
export async function recordHistory(
  entry: Record<string, unknown>
): Promise<void> {
  try {
    if (!dirReady) {
      await mkdir(dirname(config.historyFile), { recursive: true });
      dirReady = true;
    }
    await appendFile(
      config.historyFile,
      JSON.stringify({ ts: new Date().toISOString(), ...entry }) + "\n"
    );
  } catch {
    // history is purely informational; swallow errors
  }
}
