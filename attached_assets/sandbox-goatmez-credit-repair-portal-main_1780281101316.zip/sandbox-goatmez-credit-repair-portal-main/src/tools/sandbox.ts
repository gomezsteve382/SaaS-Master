import { z } from "zod";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { resolvePath } from "./shared.ts";

export const writeFileTool: ToolDef = {
  name: "write_file",
  description:
    "Write a text file (creating parent directories), for authoring code/modules into a workspace before building and running them. Overwrites if it exists.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      path: {
        type: "string",
        description: "Destination path (absolute or relative to cwd).",
      },
      content: { type: "string", description: "Full file contents." },
    },
    required: ["path", "content"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string(), content: z.string() }),
  renderSummary: a => `write_file ${a.path} (${a.content.length}b)`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    await mkdir(dirname(path), { recursive: true });
    await writeFile(path, a.content);
    ctx.log(`wrote ${path}`);
    return { ok: true, data: { path, bytes: a.content.length } };
  },
};

export const sandboxRunTool: ToolDef = {
  name: "sandbox_run",
  description:
    "Run a command inside an isolated TEST ENVIRONMENT: a chosen working directory, a wall-clock timeout, a memory cap (ulimit), and optional network isolation. Use this to build/run/debug a module you've written and capture its output — the safe way to actually execute work-in-progress code without affecting the host.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      command: {
        type: "string",
        description: "Shell command to run inside the sandbox.",
      },
      workdir: {
        type: "string",
        description: "Working directory (created if missing; default cwd).",
      },
      timeout_ms: {
        type: "integer",
        description: "Wall-clock timeout in ms (default 60000).",
        default: 60000,
      },
      mem_mb: {
        type: "integer",
        description: "Address-space cap in MB via ulimit -v (default 1024).",
        default: 1024,
      },
      network: {
        type: "boolean",
        description:
          "Allow network (default true). false isolates the network namespace if possible.",
        default: true,
      },
    },
    required: ["command"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    command: z.string().min(1),
    workdir: z.string().optional(),
    timeout_ms: z.number().int().min(100).max(600_000).optional(),
    mem_mb: z.number().int().min(16).max(32768).optional(),
    network: z.boolean().optional(),
  }),
  renderSummary: a => `sandbox_run ${a.command.slice(0, 60)}`,
  async handler(ctx, a) {
    const workdir = resolvePath(ctx.cwd, a.workdir ?? ".");
    await mkdir(workdir, { recursive: true });
    const memKb = (a.mem_mb ?? 1024) * 1024;
    // ulimit caps address space; cd sets the workspace.
    const inner = `ulimit -v ${memKb} 2>/dev/null; cd ${JSON.stringify(workdir)} && ( ${a.command} )`;
    let cmd = "sh";
    let args = ["-c", inner];
    let isolated = false;
    if (a.network === false && (await which("unshare"))) {
      // Try to drop the network namespace (best-effort; needs privileges).
      cmd = "unshare";
      args = ["-rn", "sh", "-c", inner];
      isolated = true;
    }
    ctx.log(
      `sandbox_run${a.network === false ? " (no-net)" : ""}: ${a.command.slice(0, 80)}`
    );
    const r = await execTool(cmd, args, { timeoutMs: a.timeout_ms ?? 60_000 });
    if (
      isolated &&
      r.code !== 0 &&
      /unshare|Operation not permitted/i.test(r.stderr)
    ) {
      // Network isolation unavailable here — re-run without it, note that.
      const r2 = await execTool("sh", ["-c", inner], {
        timeoutMs: a.timeout_ms ?? 60_000,
      });
      return {
        ok: true,
        data: {
          workdir,
          network_isolated: false,
          note: "network isolation unavailable (needs privileges); ran without it",
          exit_code: r2.code,
          timed_out: r2.timedOut,
          output: execText(r2),
        },
      };
    }
    return {
      ok: true,
      data: {
        workdir,
        network_isolated: isolated,
        exit_code: r.code,
        timed_out: r.timedOut,
        output: execText(r),
      },
    };
  },
};
