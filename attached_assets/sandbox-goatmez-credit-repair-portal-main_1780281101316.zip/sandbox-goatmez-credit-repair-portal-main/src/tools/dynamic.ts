import { z } from "zod";
import { chmod, open } from "node:fs/promises";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath } from "./shared.ts";

/** Read the first two bytes to detect a Windows PE ("MZ"). */
async function isPE(path: string): Promise<boolean> {
  const fh = await open(path, "r").catch(() => null);
  if (!fh) return false;
  try {
    const buf = Buffer.alloc(2);
    await fh.read(buf, 0, 2, 0);
    return buf[0] === 0x4d && buf[1] === 0x5a; // "MZ"
  } finally {
    await fh.close();
  }
}

export const runTargetTool: ToolDef = {
  name: "run_target",
  description:
    "Execute a target binary for dynamic analysis and capture stdout/stderr/exit code, under a timeout. Optionally trace syscalls (strace) or library calls (ltrace) if requested. Native Linux ELF runs directly; Windows PE needs wine (use run_shell). This actually runs the sample — fine in this disposable sandbox.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      args: {
        type: "array",
        items: { type: "string" },
        description: "Command-line arguments to pass.",
      },
      trace: {
        type: "string",
        enum: ["none", "strace", "ltrace"],
        description: "Optional tracer (default none).",
        default: "none",
      },
      timeout_ms: {
        type: "integer",
        description: "Kill after this many ms (default 15000).",
        default: 15000,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    args: z.array(z.string()).optional(),
    trace: z.enum(["none", "strace", "ltrace"]).optional(),
    timeout_ms: z.number().int().min(100).max(120_000).optional(),
  }),
  renderSummary: a => `run ${a.path} ${(a.args ?? []).join(" ")}`.trim(),
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    await chmod(path, 0o755).catch(() => {});
    const trace = a.trace ?? "none";
    const timeoutMs = a.timeout_ms ?? 15_000;
    let cmd = path;
    let args = a.args ?? [];

    // Windows PE → run through wine (auto-detected). Tracing is skipped for PE.
    if (await isPE(path)) {
      const wineBin = (await which("wine"))
        ? "wine"
        : (await which("wine64"))
          ? "wine64"
          : null;
      if (!wineBin) {
        return {
          ok: false,
          code: "TOOL_MISSING",
          message:
            "This is a Windows PE; running it needs wine, which isn't installed. Run scripts/bootstrap.sh, or analyze it statically (pe_info / decompile / r2).",
        };
      }
      ctx.log(`executing Windows PE under ${wineBin}`);
      // `env WINEDEBUG=-all` quiets wine's own chatter so the model sees the program's output.
      const r = await execTool(
        "env",
        ["WINEDEBUG=-all", wineBin, path, ...(a.args ?? [])],
        { timeoutMs }
      );
      return {
        ok: true,
        data: {
          runner: wineBin,
          exit_code: r.code,
          timed_out: r.timedOut,
          output: execText(r),
        },
      };
    }

    if (trace === "strace") {
      if (!(await which("strace")))
        return {
          ok: false,
          code: "TOOL_MISSING",
          message: "strace not installed (apt-get install strace).",
        };
      cmd = "strace";
      args = ["-f", "-tt", path, ...(a.args ?? [])];
    } else if (trace === "ltrace") {
      if (!(await which("ltrace")))
        return {
          ok: false,
          code: "TOOL_MISSING",
          message: "ltrace not installed (apt-get install ltrace).",
        };
      cmd = "ltrace";
      args = ["-f", path, ...(a.args ?? [])];
    }
    ctx.log(`executing ${path}${trace !== "none" ? ` under ${trace}` : ""}`);
    const r = await execTool(cmd, args, { timeoutMs });
    return {
      ok: true,
      data: { exit_code: r.code, timed_out: r.timedOut, output: execText(r) },
    };
  },
};

export const runShellTool: ToolDef = {
  name: "run_shell",
  description:
    "Run an arbitrary shell command in the sandbox and return its output. Your universal escape hatch: install missing tools (apt-get/pip), run wine, gdb batch scripts, objdump, file carving, custom pipelines — anything. No confirmation required.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      command: {
        type: "string",
        description: "A shell command line, executed via `sh -c`.",
      },
      timeout_ms: {
        type: "integer",
        description: "Timeout in ms (default 120000).",
        default: 120000,
      },
    },
    required: ["command"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    command: z.string().min(1),
    timeout_ms: z.number().int().min(100).max(600_000).optional(),
  }),
  renderSummary: a => `$ ${a.command.slice(0, 80)}`,
  async handler(ctx, a) {
    ctx.log(`$ ${a.command.slice(0, 100)}`);
    const r = await execTool("sh", ["-c", a.command], {
      timeoutMs: a.timeout_ms ?? 120_000,
      cwd: ctx.cwd,
    });
    return {
      ok: true,
      data: { exit_code: r.code, timed_out: r.timedOut, output: execText(r) },
    };
  },
};
