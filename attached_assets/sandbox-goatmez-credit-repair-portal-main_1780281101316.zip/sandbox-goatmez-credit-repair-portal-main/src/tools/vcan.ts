import { z } from "zod";
import { execTool, execText } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";

/**
 * Manage a virtual CAN bus (vcan) — a software CAN interface with no hardware,
 * so CAN/UDS code can be exercised on the bench. Needs root / CAP_NET_ADMIN and
 * the `vcan` kernel module (works on a normal VM; may be unavailable in a
 * locked container).
 */
export const vcanTool: ToolDef = {
  name: "vcan",
  description:
    "Spin up / tear down a virtual CAN bus (vcan) so you can test CAN/UDS modules without hardware. action='up' loads the module and brings up the interface; 'down' removes it; 'status' shows vcan interfaces. Then target it with can_send / can_replay / can_monitor (channel=vcan0). Needs root/CAP_NET_ADMIN.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      action: { type: "string", enum: ["up", "down", "status"], default: "up" },
      name: {
        type: "string",
        description: "Interface name (default vcan0).",
        default: "vcan0",
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    action: z.enum(["up", "down", "status"]).optional(),
    name: z
      .string()
      .regex(/^[a-zA-Z0-9_]+$/)
      .optional(),
  }),
  renderSummary: a => `vcan ${a.action ?? "up"} ${a.name ?? "vcan0"}`,
  async handler(ctx, a) {
    const name = a.name ?? "vcan0";
    const action = a.action ?? "up";
    const SUDO = process.getuid && process.getuid() === 0 ? "" : "sudo ";
    let script: string;
    if (action === "up") {
      script = `${SUDO}modprobe vcan 2>&1; ${SUDO}ip link add dev ${name} type vcan 2>&1; ${SUDO}ip link set up ${name} 2>&1; echo '---'; ip -br link show ${name} 2>&1`;
    } else if (action === "down") {
      script = `${SUDO}ip link set down ${name} 2>&1; ${SUDO}ip link delete ${name} 2>&1; echo "removed ${name}"`;
    } else {
      script = `ip -details -br link show type vcan 2>&1 || echo 'no vcan interfaces (module not loaded)'`;
    }
    ctx.log(`vcan ${action} ${name}`);
    const r = await execTool("sh", ["-c", script], { timeoutMs: 20_000 });
    const out = execText(r);
    const ok =
      action === "status" ||
      !/not permitted|not found|RTNETLINK|Cannot find|No such/i.test(out) ||
      /UP|UNKNOWN/.test(out);
    return {
      ok: true,
      data: {
        action,
        interface: name,
        result: out,
        usable: ok,
        hint: !ok
          ? "vcan couldn't be set up here (needs root + the vcan kernel module). On your VM run as root; in a locked container it may be unavailable."
          : action === "up"
            ? `vcan is up. Now point can_send/can_replay/can_monitor at channel='${name}', and run your UDS module against it.`
            : undefined,
      },
    };
  },
};
