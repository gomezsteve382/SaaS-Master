import { z } from "zod";
import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { resolvePath } from "./shared.ts";

async function has(dir: string, name: string): Promise<boolean> {
  try {
    await readFile(join(dir, name));
    return true;
  } catch {
    return false;
  }
}

/** Detect the project type and the command for a build/test/install action. */
async function detect(
  dir: string,
  action: "test" | "build" | "install"
): Promise<{ cmd: string; kind: string } | null> {
  if (await has(dir, "package.json")) {
    let scripts: Record<string, string> = {};
    try {
      scripts =
        JSON.parse(await readFile(join(dir, "package.json"), "utf8")).scripts ??
        {};
    } catch {
      /* ignore */
    }
    const pm = (await has(dir, "pnpm-lock.yaml"))
      ? "pnpm"
      : (await has(dir, "yarn.lock"))
        ? "yarn"
        : "npm";
    if (action === "install")
      return { cmd: `${pm} install`, kind: `node/${pm}` };
    if (scripts[action])
      return { cmd: `${pm} run ${action}`, kind: `node/${pm}` };
    if (action === "test") return { cmd: `${pm} test`, kind: `node/${pm}` };
    if (action === "build")
      return { cmd: `${pm} run build`, kind: `node/${pm}` };
  }
  if (
    (await has(dir, "pyproject.toml")) ||
    (await has(dir, "requirements.txt")) ||
    (await has(dir, "setup.py"))
  ) {
    if (action === "install") {
      if (await has(dir, "requirements.txt"))
        return { cmd: "pip install -r requirements.txt", kind: "python" };
      return { cmd: "pip install -e .", kind: "python" };
    }
    if (action === "test")
      return {
        cmd: (await which("pytest")) ? "pytest -q" : "python3 -m pytest -q",
        kind: "python",
      };
    if (action === "build") return { cmd: "python3 -m build", kind: "python" };
  }
  if (await has(dir, "Cargo.toml"))
    return {
      cmd: `cargo ${action === "install" ? "fetch" : action}`,
      kind: "rust",
    };
  if (await has(dir, "go.mod")) {
    if (action === "test") return { cmd: "go test ./...", kind: "go" };
    if (action === "build") return { cmd: "go build ./...", kind: "go" };
    if (action === "install") return { cmd: "go mod download", kind: "go" };
  }
  if (await has(dir, "Makefile"))
    return { cmd: `make ${action}`, kind: "make" };
  return null;
}

export const runTestsTool: ToolDef = {
  name: "run_tests",
  description:
    "Auto-detect the project's toolchain (pnpm/npm/yarn, python+pytest, cargo, go, make) and run its test / build / install command — capturing output for the debug loop. Pass an explicit `command` to override detection. Run from the active project (or set `path`).",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      action: {
        type: "string",
        enum: ["test", "build", "install"],
        description: "What to run (default test).",
        default: "test",
      },
      path: {
        type: "string",
        description: "Project directory (default the active project / cwd).",
      },
      command: {
        type: "string",
        description: "Explicit command to run instead of auto-detecting.",
      },
      timeout_ms: {
        type: "integer",
        description: "Timeout in ms (default 300000).",
        default: 300000,
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    action: z.enum(["test", "build", "install"]).optional(),
    path: z.string().optional(),
    command: z.string().optional(),
    timeout_ms: z.number().int().min(1000).max(900_000).optional(),
  }),
  renderSummary: a =>
    `run_tests ${a.action ?? "test"}${a.command ? ` (${a.command.slice(0, 40)})` : ""}`,
  async handler(ctx, a) {
    const dir = resolvePath(ctx.cwd, a.path ?? ".");
    const action = a.action ?? "test";
    let command = a.command;
    let kind = "explicit";
    if (!command) {
      const det = await detect(dir, action);
      if (!det) {
        let listing = "";
        try {
          listing = (await readdir(dir)).slice(0, 40).join(", ");
        } catch {
          /* ignore */
        }
        return {
          ok: false,
          code: "NO_PROFILE",
          message: `Couldn't detect a ${action} command in ${dir}. Pass an explicit 'command'. Dir contains: ${listing}`,
        };
      }
      command = det.cmd;
      kind = det.kind;
    }
    ctx.log(`${action} (${kind}): ${command}`);
    const r = await execTool(
      "sh",
      ["-c", `cd ${JSON.stringify(dir)} && ( ${command} )`],
      { timeoutMs: a.timeout_ms ?? 300_000 }
    );
    return {
      ok: true,
      data: {
        action,
        project_kind: kind,
        command,
        exit_code: r.code,
        passed: r.code === 0,
        timed_out: r.timedOut,
        output: execText(r),
      },
    };
  },
};
