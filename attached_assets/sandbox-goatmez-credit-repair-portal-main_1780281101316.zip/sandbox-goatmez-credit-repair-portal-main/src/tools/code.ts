import { z } from "zod";
import { execTool, execText } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, requireBins, resolvePath, runRekit } from "./shared.ts";

export const disassembleTool: ToolDef = {
  name: "disassemble",
  description:
    "Disassemble a raw byte range with capstone. Good for shellcode, a specific function body, or an entrypoint. Specify file offset, size, architecture and bitness. For symbol-aware disassembly of a whole function, prefer `decompile` or `r2`.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      offset: {
        type: "integer",
        description: "File offset to start at (default 0).",
        default: 0,
      },
      size: {
        type: "integer",
        description: "Bytes to disassemble (default 256, max 65536).",
        default: 256,
      },
      arch: {
        type: "string",
        enum: ["x86", "arm", "mips"],
        description: "CPU architecture (default x86).",
        default: "x86",
      },
      bits: {
        type: "integer",
        enum: [16, 32, 64],
        description: "Bitness (default 64).",
        default: 64,
      },
      base: {
        type: "integer",
        description:
          "Virtual base address for shown addresses (default = offset).",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    offset: z.number().int().min(0).optional(),
    size: z.number().int().min(1).max(65536).optional(),
    arch: z.enum(["x86", "arm", "mips"]).optional(),
    bits: z.union([z.literal(16), z.literal(32), z.literal(64)]).optional(),
    base: z.number().int().min(0).optional(),
  }),
  renderSummary: a =>
    `disasm ${a.path} @${a.offset ?? 0} (${a.arch ?? "x86"}/${a.bits ?? 64})`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("disassembling (capstone)");
    return runRekit("disasm", [
      path,
      "--offset",
      String(a.offset ?? 0),
      "--size",
      String(a.size ?? 256),
      "--arch",
      a.arch ?? "x86",
      "--bits",
      String(a.bits ?? 64),
      "--base",
      String(a.base ?? 0),
    ]);
  },
};

export const decompileTool: ToolDef = {
  name: "decompile",
  description:
    "Decompile a function to pseudo-C using radare2 (analysis + `pdc`). Target a symbol name (e.g. `main`, `sym.imp.strcmp`), an address (e.g. `0x401000`), or `entry0`. Runs full auto-analysis first, so it may be slow on large binaries.",
  requires: ["r2"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      target: {
        type: "string",
        description: "Function symbol or address (default: main).",
        default: "main",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string(), target: z.string().optional() }),
  renderSummary: a => `decompile ${a.path} @ ${a.target ?? "main"}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("r2"));
    if (e) return e;
    const target = a.target ?? "main";
    ctx.log(`decompiling ${target} (radare2)`);
    // Try the target as given; if radare2 can't resolve a bare name, retry as sym.<name>.
    // aaa = analyze all; pdc = pseudo-decompile; pdf = annotated disassembly fallback.
    const script = `aaa; pdc @ ${target}; echo ----DISASM----; pdf @ ${target}`;
    let r = await execTool(
      "r2",
      ["-2", "-q", "-e", "scr.color=0", "-c", script, path],
      { timeoutMs: 240_000 }
    );
    const thin = r.stdout.replace(/-+DISASM-+/g, "").trim().length < 8;
    if (thin && !/^(sym\.|0x)/.test(target)) {
      const alt = `aaa; pdc @ sym.${target}; echo ----DISASM----; pdf @ sym.${target}`;
      const r2try = await execTool(
        "r2",
        ["-2", "-q", "-e", "scr.color=0", "-c", alt, path],
        { timeoutMs: 240_000 }
      );
      if (r2try.stdout.trim().length > r.stdout.trim().length) r = r2try;
    }
    return { ok: true, data: execText(r) };
  },
};

export const r2Tool: ToolDef = {
  name: "r2",
  description:
    "Run arbitrary radare2 commands against a binary and return their output — the full power of radare2. Commands are separated by ';'. Examples: 'aaa; afl' (list functions after analysis), 'iI' (binary info), 'ii' (imports), 'iE' (exports), 'izz' (all strings), 'pdf @ main' (disasm function), 'axt sym.imp.strcmp' (xrefs), 'iz~http' (data strings matching http). Analysis commands like 'aaa' must precede commands that need it.",
  requires: ["r2"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      commands: {
        type: "string",
        description:
          "Radare2 command(s), ';'-separated. Run 'aaa' first if you need function analysis.",
      },
    },
    required: ["path", "commands"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string(), commands: z.string().min(1) }),
  renderSummary: a => `r2 -c "${a.commands.slice(0, 60)}" ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("r2"));
    if (e) return e;
    ctx.log(`r2: ${a.commands.slice(0, 80)}`);
    // scr.color=0 keeps output clean (no ANSI escapes) for the model to read.
    const r = await execTool(
      "r2",
      ["-2", "-q", "-e", "scr.color=0", "-c", a.commands, path],
      { timeoutMs: 240_000 }
    );
    return { ok: true, data: execText(r) };
  },
};
