import { z } from "zod";
import type { ToolDef, ToolResult } from "../core/types.ts";
import { ensureFile, resolvePath, runPy, runRekit } from "./shared.ts";

/**
 * Curated FCA/Stellantis module reverse-engineering reference. This is an
 * advisor (no dump required): it suggests Ghidra processor ids to try and
 * points at where the immobilizer secret / key table / red-black flag tend to
 * live, plus the recommended RE-Agent workflow. Hedged on purpose — confirm the
 * MCU with `load_firmware` before trusting any specific guess.
 */
const MODULES: Record<
  string,
  {
    aka: string;
    role: string;
    mcu_candidates: string[];
    look_for: string[];
    notes: string[];
  }
> = {
  rfhub: {
    aka: "RF Hub Module (RFHM), Wireless Control Module",
    role: "Keyless entry + immobilizer. Stores the immobilizer secret/PIN and the table of authorized key transponder IDs; runs the challenge-response with the key.",
    mcu_candidates: [
      "Renesas RH850/V850 — try Ghidra 'V850:LE:32:default'",
      "Renesas RL78 — Ghidra has no stock RL78 module; identify via load_firmware and consider an add-on SLEIGH module",
      "NXP/Freescale S12/MagniV (HCS12) — try 'HCS12:BE:16:default'",
      "ARM Cortex-M — try 'ARM:LE:32:Cortex'",
    ],
    look_for: [
      "UDS SecurityAccess service 0x27 (seed/key) handler",
      "Immobilizer secret / SKIM PIN storage (often near a CRC/checksummed config block)",
      "Key transponder-ID table (repeated fixed-size records)",
      "Red(master)/black(valet) per-key flag — usually one byte in each key record",
    ],
    notes: [
      "Transponder gen varies by year: older Hitag2/ID46, newer SRT uses encrypted 4A/HITAG-AES (used keys often can't be reused without unlock/renew).",
      "The power-limit that the black/valet key triggers lives in the PCM, not the RFHub — diff the PCM too if chasing the red-key power unlock.",
    ],
  },
  sgw: {
    aka: "Security Gateway Module (SGW)",
    role: "Gatekeeps diagnostic writes over OBD (2018+). You typically need an SGW bypass/auth to program keys via OBD.",
    mcu_candidates: [
      "ARM Cortex-M — try 'ARM:LE:32:Cortex'",
      "Renesas RH850 — try 'V850:LE:32:default'",
    ],
    look_for: [
      "UDS routing/auth logic",
      "Allow/deny lists for diagnostic IDs",
      "Challenge handling for tester unlock",
    ],
    notes: [
      "Keep the SGW intact for hardening; bench/unplug only for authorized work on your own car.",
    ],
  },
  pcm: {
    aka: "Powertrain Control Module (PCM/ECM)",
    role: "Engine control + holds the Valet/black-key power limit and its own immobilizer link to the RFHub.",
    mcu_candidates: [
      "NXP/Freescale PowerPC MPC5xxx — try 'PowerPC:BE:32:default'",
      "Infineon TriCore — try 'tricore:LE:32:default'",
    ],
    look_for: [
      "Valet/power-limit logic tied to key type",
      "Immobilizer handshake with the RFHub",
      "Calibration/checksum blocks",
    ],
    notes: [
      "This is where the red-vs-black HORSEPOWER difference is enforced.",
    ],
  },
};

export const fcaProfileTool: ToolDef = {
  name: "fca_profile",
  description:
    "Advisor for reverse-engineering FCA/Stellantis modules (no dump needed). Given a module (rfhub, sgw, pcm), returns candidate MCUs + Ghidra processor ids to try, where the immobilizer secret/key-table/red-black flag typically live, and the recommended RE-Agent workflow. Confirm the actual MCU with load_firmware before trusting specifics.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      module: {
        type: "string",
        enum: ["rfhub", "sgw", "pcm"],
        description: "Which module (default rfhub).",
        default: "rfhub",
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({ module: z.enum(["rfhub", "sgw", "pcm"]).optional() }),
  renderSummary: a => `fca_profile ${a.module ?? "rfhub"}`,
  async handler(_ctx, a) {
    const key = a.module ?? "rfhub";
    const prof = MODULES[key];
    return {
      ok: true,
      data: {
        module: key,
        ...prof,
        workflow: [
          "load_firmware <dump>  → confirm MCU + base address",
          "ghidra_decompile <dump> processor=<id> base=<addr>  → find 0x27/secret/key-table code",
          "find_crypto <dump>  → locate the immobilizer challenge crypto",
          "emulate  → run the seed→key / auth routine to understand it",
          "keytable_diff <before> <after>  → after programming a key, see exactly which bytes (the key slot + red/black flag) changed",
        ],
        scope:
          "Owner/right-to-repair on a vehicle you own. Confirm transponder generation and SGW presence for your year before buying a used key.",
      },
    };
  },
};

const unwrap = (r: ToolResult): unknown =>
  r.ok ? r.data : { error: r.message, code: r.code };

export const ecuReportTool: ToolDef = {
  name: "ecu_report",
  description:
    "One-shot ECU/firmware triage report: identifies the dump, reconstructs its memory map + MCU fingerprint, scans for crypto constants, locates & labels the key-record table, and attaches the FCA module profile + recommended next steps — all in a single annotated summary. Fast static pass (does not run the slow Ghidra decompiler; it tells you what to run next).",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Firmware/module dump to triage." },
      module: {
        type: "string",
        enum: ["rfhub", "sgw", "pcm"],
        description: "FCA module type for the profile (default rfhub).",
        default: "rfhub",
      },
      base: {
        type: "string",
        description:
          "Load address for a raw .bin, e.g. '0x80000000' (optional).",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    module: z.enum(["rfhub", "sgw", "pcm"]).optional(),
    base: z.string().optional(),
  }),
  renderSummary: a => `ecu_report ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const mod = a.module ?? "rfhub";
    const profile = MODULES[mod] ?? MODULES.rfhub;

    ctx.log("identifying");
    const identity = unwrap(await runRekit("identify", [path]));
    ctx.log("reconstructing memory map");
    const fwArgs = ["loadfw", path];
    if (a.base) fwArgs.push("--base", a.base);
    const firmware = unwrap(await runPy("autokit.py", fwArgs));
    ctx.log("scanning for crypto constants");
    const crypto = unwrap(await runPy("autokit.py", ["findcrypto", path]));
    ctx.log("locating + labeling key table");
    const keyTable = unwrap(await runPy("autokit.py", ["keyrecord", path]));

    const fingerprints = (firmware as any)?.mcu_fingerprints ?? [];
    const suggestedProc = profile.mcu_candidates[0];

    return {
      ok: true,
      data: {
        module: mod,
        identity,
        firmware,
        crypto_constants: crypto,
        key_table: keyTable,
        fca_profile: {
          aka: profile.aka,
          role: profile.role,
          mcu_candidates: profile.mcu_candidates,
          look_for: profile.look_for,
          notes: profile.notes,
        },
        next_steps: [
          `ghidra_decompile ${a.path} processor=<id> ${a.base ? `base=${a.base}` : "(auto for PE/ELF)"} — try: ${suggestedProc}`,
          "find the SecurityAccess (0x27) / immobilizer routine in the decompilation; emulate it to recover the seed→key",
          "program/erase a key with your tool, dump again, then: keytable_diff <before> <after> to confirm the key slot + red/black flag",
          fingerprints.length
            ? `MCU fingerprints found: ${fingerprints.join(", ")}`
            : "No MCU markers in strings — confirm the core from the reset vector / datasheet.",
        ],
        note: "Static triage summary. Ghidra decompilation is intentionally not auto-run here (slow) — kick it off with the suggested processor when ready.",
      },
    };
  },
};

export const checksumScanTool: ToolDef = {
  name: "checksum_scan",
  description:
    "Identify checksum/CRC regions in an ECU dump (read-only): reports whole-image sums (sum8/16/32, xor, CRC16-CCITT, CRC32) and finds STORED values that actually verify the bytes before them — i.e. locates+identifies the real checksums, for verifying or repairing your own dump.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `checksum_scan ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("scanning for checksum/CRC regions");
    return runPy("autokit.py", ["checksum", path]);
  },
};

export const eepromMapTool: ToolDef = {
  name: "eeprom_map",
  description:
    "Label common EEPROM structures in a dump (read-only): VIN candidates, ASCII strings (part numbers/dates), and mirrored/redundant 16-byte blocks (often duplicated odometer/config copies). Pairs with keyrecord (key table) and find_crypto (secrets).",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `eeprom_map ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("labeling EEPROM structures");
    return runPy("autokit.py", ["eepmap", path]);
  },
};

export const keyrecordTool: ToolDef = {
  name: "keyrecord",
  description:
    "Annotate a module dump: locate the likely key-record table (a run of equal-size slots; empty = all 0xFF/0x00) and label the fields — which byte ranges vary across populated slots (likely the transponder ID) vs. stay constant (candidate type / red-master vs black-valet flag / padding). Pass record_size if you already know the slot width. Confirm findings with keytable_diff.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Module/RFHub dump to analyze." },
      record_size: {
        type: "integer",
        description: "Slot width in bytes if known (else auto-tries 8..64).",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    record_size: z.number().int().min(4).max(256).optional(),
  }),
  renderSummary: a => `keyrecord ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("locating + labeling key-record table");
    const args = ["keyrecord", path];
    if (a.record_size) args.push("--record-size", String(a.record_size));
    return runPy("autokit.py", args);
  },
};

export const keytableDiffTool: ToolDef = {
  name: "keytable_diff",
  description:
    "Diff two module dumps (e.g. an RFHub before vs after adding/removing a key) and report the changed byte regions with before/after hex, largest first. Pinpoints the key-slot / transponder-ID table / 'security bytes' and the red(master)-vs-black(valet) flag that changed — the cleanest way to learn the on-flash key format on your own car.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      before: { type: "string", description: "Dump taken before the change." },
      after: { type: "string", description: "Dump taken after the change." },
      gap: {
        type: "integer",
        description:
          "Merge changed bytes separated by <= this many unchanged bytes (default 4).",
        default: 4,
      },
    },
    required: ["before", "after"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    before: z.string(),
    after: z.string(),
    gap: z.number().int().min(0).max(64).optional(),
  }),
  renderSummary: a => `keytable_diff ${a.before} ↔ ${a.after}`,
  async handler(ctx, a) {
    const pa = resolvePath(ctx.cwd, a.before);
    const pb = resolvePath(ctx.cwd, a.after);
    const e = (await ensureFile(pa)) ?? (await ensureFile(pb));
    if (e) return e;
    ctx.log("diffing dumps for changed key slot / security bytes");
    return runPy("autokit.py", [
      "keydiff",
      pa,
      pb,
      "--gap",
      String(a.gap ?? 4),
    ]);
  },
};
