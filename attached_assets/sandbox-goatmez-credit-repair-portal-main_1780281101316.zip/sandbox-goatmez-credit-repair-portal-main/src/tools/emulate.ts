import { z } from "zod";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath, runPy } from "./shared.ts";

export const emulateTool: ToolDef = {
  name: "emulate",
  description:
    "Emulate a routine with Unicorn Engine to see EXACTLY what it computes — load a code region, set registers/arguments, run it, and read back the resulting registers and memory. The way to derive a UDS seed→key algorithm: load the key routine, set the seed in the argument register, run, read the key out. Supports x86 (16/32/64), arm (32), arm64, mips (32).",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      arch: {
        type: "string",
        enum: ["x86", "arm", "arm64", "mips"],
        default: "x86",
      },
      bits: { type: "integer", enum: [16, 32, 64], default: 64 },
      base: {
        type: "string",
        description: "Virtual load address of the code, e.g. '0x400000'.",
        default: "0x400000",
      },
      offset: {
        type: "integer",
        description: "File offset of the code region to load (default 0).",
        default: 0,
      },
      size: {
        type: "integer",
        description: "Bytes of code to load (default 0x4000).",
        default: 16384,
      },
      start: {
        type: "string",
        description: "Address to begin execution (default = base).",
      },
      stop: {
        type: "string",
        description: "Address to stop at (e.g. the function's RET). Optional.",
      },
      steps: {
        type: "integer",
        description: "Max instructions to execute (default 200000).",
        default: 200000,
      },
      regs: {
        type: "array",
        items: { type: "string" },
        description:
          "Initial registers as 'name=value', e.g. ['rdi=0xA1B2C3D4','rsi=0']. Use the seed register here.",
      },
      dump: {
        type: "string",
        description:
          "Memory range to read after the run, 'addr:len', e.g. '0x401000:64'.",
      },
      trace: {
        type: "boolean",
        description: "Record the first 256 executed instruction addresses.",
        default: false,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    arch: z.enum(["x86", "arm", "arm64", "mips"]).optional(),
    bits: z.union([z.literal(16), z.literal(32), z.literal(64)]).optional(),
    base: z.string().optional(),
    offset: z.number().int().min(0).optional(),
    size: z.number().int().min(1).optional(),
    start: z.string().optional(),
    stop: z.string().optional(),
    steps: z.number().int().min(1).max(50_000_000).optional(),
    regs: z.array(z.string()).optional(),
    dump: z.string().optional(),
    trace: z.boolean().optional(),
  }),
  renderSummary: a =>
    `emulate ${a.path} (${a.arch ?? "x86"}/${a.bits ?? 64}) @ ${a.start ?? a.base ?? "base"}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("emulating (Unicorn)");
    const args = [
      "--file",
      path,
      "--arch",
      a.arch ?? "x86",
      "--bits",
      String(a.bits ?? 64),
      "--base",
      a.base ?? "0x400000",
      "--offset",
      String(a.offset ?? 0),
      "--size",
      String(a.size ?? 16384),
      "--steps",
      String(a.steps ?? 200000),
    ];
    if (a.start) args.push("--start", a.start);
    if (a.stop) args.push("--stop", a.stop);
    if (a.dump) args.push("--dump", a.dump);
    if (a.trace) args.push("--trace");
    for (const r of a.regs ?? []) args.push("--reg", r);
    return runPy("emulate.py", args);
  },
};
