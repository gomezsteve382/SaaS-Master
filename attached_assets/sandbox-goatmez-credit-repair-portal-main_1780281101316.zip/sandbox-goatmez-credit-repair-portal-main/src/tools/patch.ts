import { z } from "zod";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath, runPy } from "./shared.ts";

export const patchBytesTool: ToolDef = {
  name: "patch_bytes",
  description:
    "Edit a dump: write hex bytes at an offset (a binary editor for your own dumps). Use to program a key into a slot, set the red(master)/black(valet) flag, or change a VIN/config field — locate the offset first with keyrecord/eeprom_map/hexdump. Writes to `out` (or overwrites in place). If the region is checksum-covered, run fix_checksum after.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Dump to edit." },
      offset: {
        type: "string",
        description: "Byte offset to write at, e.g. '0x3A40'.",
      },
      hex: {
        type: "string",
        description: "Hex bytes to write, e.g. '0011223344556677'.",
      },
      out: {
        type: "string",
        description:
          "Output path (default: overwrite the input). Use a new name to keep the original.",
      },
    },
    required: ["path", "offset", "hex"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    offset: z.string(),
    hex: z.string().regex(/^([0-9A-Fa-f]{2})+$/, "even number of hex digits"),
    out: z.string().optional(),
  }),
  renderSummary: a => `patch_bytes ${a.path} @${a.offset}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const args = ["patch", path, "--offset", a.offset, "--hex", a.hex];
    if (a.out) args.push("--out", resolvePath(ctx.cwd, a.out));
    ctx.log(`patching ${a.hex.length / 2} bytes @ ${a.offset}`);
    return runPy("autokit.py", args);
  },
};

export const fixChecksumTool: ToolDef = {
  name: "fix_checksum",
  description:
    "Recalculate and write a stored checksum after you've edited a dump — so the module will accept it. Pass the offset + algorithm from checksum_scan (CRC32(LE), sum32(LE), sum16(LE), or CRC16-CCITT). Run checksum_scan first to locate the checksum, edit with patch_bytes, then fix_checksum, then checksum_scan again to confirm it verifies.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: {
        type: "string",
        description: "Edited dump whose checksum needs fixing.",
      },
      offset: {
        type: "string",
        description: "Checksum offset (from checksum_scan), e.g. '0x400'.",
      },
      algorithm: {
        type: "string",
        enum: ["CRC32(LE)", "sum32(LE)", "sum16(LE)", "CRC16-CCITT"],
        description: "Algorithm reported by checksum_scan.",
      },
      out: {
        type: "string",
        description: "Output path (default: overwrite the input).",
      },
    },
    required: ["path", "offset", "algorithm"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    offset: z.string(),
    algorithm: z.enum(["CRC32(LE)", "sum32(LE)", "sum16(LE)", "CRC16-CCITT"]),
    out: z.string().optional(),
  }),
  renderSummary: a => `fix_checksum ${a.path} @${a.offset}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const args = [
      "fixck",
      path,
      "--offset",
      a.offset,
      "--algorithm",
      a.algorithm,
    ];
    if (a.out) args.push("--out", resolvePath(ctx.cwd, a.out));
    ctx.log(`recomputing ${a.algorithm} @ ${a.offset}`);
    return runPy("autokit.py", args);
  },
};
