import { z } from "zod";
import { readFile } from "node:fs/promises";
import { execTool, execText } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, requireBins, resolvePath, runRekit } from "./shared.ts";

export const identifyTool: ToolDef = {
  name: "identify",
  description:
    "Identify a file: format (PE/ELF/Mach-O/SWF/JVM/DEX/ZIP), size, MD5/SHA1/SHA256, magic bytes and overall entropy. Always run this first.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: {
        type: "string",
        description: "Path to the file (absolute or relative).",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `identify ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log(`identifying ${path}`);
    return runRekit("identify", [path]);
  },
};

export const listStringsTool: ToolDef = {
  name: "list_strings",
  description:
    "Extract printable strings from a file (like `strings`). Supports min length, ASCII+UTF-16LE, and a substring/regex filter to hunt for URLs, paths, keys, commands, etc.",
  requires: ["strings"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      min_len: {
        type: "integer",
        description: "Minimum string length (default 5).",
        default: 5,
      },
      filter: {
        type: "string",
        description:
          "Optional case-insensitive regex; only matching strings are returned.",
      },
      max: {
        type: "integer",
        description: "Max strings to return (default 400).",
        default: 400,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    min_len: z.number().int().min(1).max(64).optional(),
    filter: z.string().optional(),
    max: z.number().int().min(1).max(5000).optional(),
  }),
  renderSummary: a => `strings ${a.path}${a.filter ? ` ~ /${a.filter}/` : ""}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("strings"));
    if (e) return e;
    const min = a.min_len ?? 5;
    // -el covers UTF-16LE (wide) strings common in Windows PEs; combine with ASCII.
    ctx.log(`extracting strings (min ${min})`);
    const ascii = await execTool("strings", ["-a", "-n", String(min), path]);
    const wide = await execTool("strings", [
      "-a",
      "-e",
      "l",
      "-n",
      String(min),
      path,
    ]);
    let lines = [...ascii.stdout.split("\n"), ...wide.stdout.split("\n")]
      .map(s => s.trimEnd())
      .filter(Boolean);
    if (a.filter) {
      let re: RegExp;
      try {
        re = new RegExp(a.filter, "i");
      } catch {
        return {
          ok: false,
          code: "BAD_REGEX",
          message: `Invalid filter regex: ${a.filter}`,
        };
      }
      lines = lines.filter(l => re.test(l));
    }
    const max = a.max ?? 400;
    return {
      ok: true,
      data: {
        count: lines.length,
        shown: Math.min(lines.length, max),
        strings: lines.slice(0, max),
      },
    };
  },
};

export const hexdumpTool: ToolDef = {
  name: "hexdump",
  description:
    "Hex + ASCII dump of a byte range of a file. Use for headers, magic, and inspecting raw regions.",
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      offset: {
        type: "integer",
        description: "Start offset in bytes (default 0).",
        default: 0,
      },
      length: {
        type: "integer",
        description: "Number of bytes (default 256, max 8192).",
        default: 256,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    offset: z.number().int().min(0).optional(),
    length: z.number().int().min(1).max(8192).optional(),
  }),
  renderSummary: a => `hexdump ${a.path} @${a.offset ?? 0}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const offset = a.offset ?? 0;
    const length = a.length ?? 256;
    const fd = await readFile(path);
    const slice = fd.subarray(offset, offset + length);
    const lines: string[] = [];
    for (let i = 0; i < slice.length; i += 16) {
      const chunk = slice.subarray(i, i + 16);
      const hex = [...chunk]
        .map(b => b.toString(16).padStart(2, "0"))
        .join(" ");
      const ascii = [...chunk]
        .map(b => (b >= 0x20 && b < 0x7f ? String.fromCharCode(b) : "."))
        .join("");
      lines.push(
        `${(offset + i).toString(16).padStart(8, "0")}  ${hex.padEnd(47)}  |${ascii}|`
      );
    }
    return {
      ok: true,
      data: {
        offset,
        length: slice.length,
        dump: lines.join("\n") || "(empty range)",
      },
    };
  },
};

export const binaryMetadataTool: ToolDef = {
  name: "binary_metadata",
  description:
    "Universal native-binary metadata via LIEF: format, architecture, entrypoint, linked libraries, sections with per-section entropy, and a packed/encrypted hint. Works for PE, ELF and Mach-O.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `metadata ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("parsing with LIEF");
    return runRekit("meta", [path]);
  },
};

export const peInfoTool: ToolDef = {
  name: "pe_info",
  description:
    "Deep Windows PE (.exe/.dll) analysis via pefile: headers, sections+entropy, full import table, exports, and a flagged list of SUSPICIOUS imports (process injection, networking, crypto, anti-debug). Key for malware screening.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `pe_info ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("parsing PE (pefile)");
    return runRekit("pe", [path]);
  },
};

export const elfInfoTool: ToolDef = {
  name: "elf_info",
  description:
    "Deep Linux ELF analysis via pyelftools: ELF class/type/machine, entrypoint, sections, NEEDED shared libraries and RUNPATH/RPATH.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `elf_info ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("parsing ELF (pyelftools)");
    return runRekit("elf", [path]);
  },
};

export const symbolsTool: ToolDef = {
  name: "symbols",
  description:
    "List symbols (functions, globals, imports) via rabin2 (radare2). Falls back to nm for ELF.",
  requires: ["rabin2"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      imports_only: {
        type: "boolean",
        description: "Only show imported symbols.",
        default: false,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    imports_only: z.boolean().optional(),
  }),
  renderSummary: a => `symbols ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("rabin2"));
    if (e) return e;
    ctx.log("listing symbols (rabin2)");
    const flag = a.imports_only ? "-i" : "-s";
    const r = await execTool("rabin2", [flag, path]);
    return { ok: true, data: execText(r) };
  },
};

export const entropyTool: ToolDef = {
  name: "entropy",
  description:
    "Shannon entropy of a file, overall and per block. High/flat entropy (>7.2) across a region indicates packing, compression or encryption — useful to locate hidden payloads.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      block: {
        type: "integer",
        description: "Block size in bytes (default 4096).",
        default: 4096,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    block: z
      .number()
      .int()
      .min(64)
      .max(1 << 20)
      .optional(),
  }),
  renderSummary: a => `entropy ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("computing entropy");
    return runRekit("entropy", [path, "--block", String(a.block ?? 4096)]);
  },
};

// Patterns that commonly indicate embedded secrets/keys in a binary.
const SECRET_PATTERNS: Array<{ name: string; re: RegExp }> = [
  {
    name: "PEM block",
    re: /-----BEGIN [A-Z ]+-----[\s\S]*?-----END [A-Z ]+-----/g,
  },
  { name: "SSH private key", re: /-----BEGIN OPENSSH PRIVATE KEY-----/g },
  { name: "AWS access key id", re: /AKIA[0-9A-Z]{16}/g },
  { name: "Google API key", re: /AIza[0-9A-Za-z\-_]{35}/g },
  { name: "Slack token", re: /xox[baprs]-[0-9A-Za-z-]{10,48}/g },
  { name: "GitHub token", re: /gh[pousr]_[0-9A-Za-z]{36,}/g },
  {
    name: "JWT",
    re: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,
  },
  {
    name: "Generic API key assignment",
    re: /(?:api[_-]?key|secret|password|passwd|token)["'\s:=]{1,4}[A-Za-z0-9\/+=_\-]{12,}/gi,
  },
  { name: "Bearer token", re: /[Bb]earer\s+[A-Za-z0-9\-._~+/]{16,}/g },
  {
    name: "Hex key (32/64 hex)",
    re: /\b(?:[0-9a-fA-F]{32}|[0-9a-fA-F]{64})\b/g,
  },
  {
    name: "Connection string",
    re: /(?:mongodb|postgres(?:ql)?|mysql|redis|amqp|jdbc):\/\/[^\s"']{6,}/gi,
  },
  {
    name: "Private IPv4",
    re: /\b(?:10|192\.168|172\.(?:1[6-9]|2\d|3[01]))(?:\.\d{1,3}){2,3}\b/g,
  },
];

export const findSecretsTool: ToolDef = {
  name: "find_secrets",
  description:
    "Scan a file for embedded secrets and keys: PEM/SSH private keys, JWTs, AWS/Google/Slack/GitHub tokens, generic api_key/password/secret assignments, bearer tokens, 32/64-char hex keys, DB connection strings and private IPs. Reads both ASCII and UTF-16 text.",
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `find_secrets ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("hunting for embedded keys/secrets");
    const buf = await readFile(path);
    // Decode as latin1 (1:1 byte->char) for ASCII, and strip NULs to catch UTF-16LE text.
    const ascii = buf.toString("latin1");
    const widized = buf.toString("latin1").replace(/\x00/g, "");
    const findings: Array<{ type: string; match: string; encoding: string }> =
      [];
    const seen = new Set<string>();
    for (const { name, re } of SECRET_PATTERNS) {
      for (const [text, enc] of [
        [ascii, "ascii"],
        [widized, "utf16/packed"],
      ] as const) {
        for (const m of text.matchAll(re)) {
          const val = m[0].slice(0, 400);
          const key = name + "|" + val;
          if (seen.has(key)) continue;
          seen.add(key);
          findings.push({ type: name, match: val, encoding: enc });
          if (findings.length >= 300) break;
        }
      }
    }
    return {
      ok: true,
      data: {
        path,
        finding_count: findings.length,
        note:
          findings.length === 0
            ? "No high-confidence secrets matched. Try list_strings with a custom filter."
            : undefined,
        findings,
      },
    };
  },
};
