import { z } from "zod";
import { spawn } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import type { ToolDef } from "../core/types.ts";

const here = dirname(fileURLToPath(import.meta.url));
const UDSSIM = join(here, "..", "py", "udssim.py");

type Sim = {
  module: string;
  channel: string;
  pid: number;
  startedAt: number;
  log: string[];
};
const sims = new Map<string, Sim>();

export const udsSimTool: ToolDef = {
  name: "uds_sim",
  description:
    "Run a behavioral UDS module simulator on the virtual bench (vcan): a software model of an ECM/BCM/RFHub/Cluster that answers UDS requests (session, ReadDataByIdentifier, SecurityAccess seed/key, ECUReset, ReadDTC) on a SocketCAN interface. For software-in-the-loop testing of your own tester/module code off-car — it does NOT run real firmware. actions: start (module + channel [+ vin]), stop, list. Needs vcan up + python-can/can-isotp.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      action: {
        type: "string",
        enum: ["start", "stop", "list"],
        default: "start",
      },
      module: {
        type: "string",
        enum: ["ecm", "tcm", "bcm", "rfhub", "cluster"],
        description: "Which module to simulate (default ecm).",
      },
      channel: {
        type: "string",
        description: "SocketCAN interface (default vcan0).",
        default: "vcan0",
      },
      vin: {
        type: "string",
        description: "Optional VIN to serve on DID 0xF190.",
      },
      keyfn: {
        type: "string",
        description:
          "Path to a python file with `def key(seed: bytes) -> bytes` (the REAL seed→key). With it set, the sim only accepts a correct key — so your key code is truly validated.",
      },
      max_attempts: {
        type: "integer",
        description: "Lock out after N bad keys (default 3).",
      },
      p2_ms: {
        type: "integer",
        description: "Response delay ms (P2 server timing).",
      },
      pending_ms: {
        type: "integer",
        description:
          "For slow services, send 0x78 then the real reply after this many ms.",
      },
      stmin_ms: {
        type: "integer",
        description: "ISO-TP STmin advertised to the tester.",
      },
      dids: {
        type: "array",
        items: { type: "string" },
        description: "DID seeds as 'F190=<hex>' (e.g. from a real dump).",
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    action: z.enum(["start", "stop", "list"]).optional(),
    module: z.enum(["ecm", "tcm", "bcm", "rfhub", "cluster"]).optional(),
    channel: z.string().optional(),
    vin: z.string().optional(),
    keyfn: z.string().optional(),
    max_attempts: z.number().int().min(1).max(255).optional(),
    p2_ms: z.number().int().min(0).max(10000).optional(),
    pending_ms: z.number().int().min(0).max(10000).optional(),
    stmin_ms: z.number().int().min(0).max(127).optional(),
    dids: z.array(z.string()).optional(),
  }),
  renderSummary: a => `uds_sim ${a.action ?? "start"} ${a.module ?? ""}`.trim(),
  async handler(ctx, a) {
    const action = a.action ?? "start";

    if (action === "list") {
      return {
        ok: true,
        data: {
          running: [...sims.values()].map(s => ({
            module: s.module,
            channel: s.channel,
            pid: s.pid,
            uptime_s: Math.round((Date.now() - s.startedAt) / 1000),
          })),
        },
      };
    }

    const module = a.module ?? "ecm";

    if (action === "stop") {
      const s = sims.get(module);
      if (!s)
        return {
          ok: true,
          data: { module, stopped: false, note: "not running" },
        };
      try {
        process.kill(s.pid, "SIGTERM");
      } catch {
        /* gone */
      }
      sims.delete(module);
      return { ok: true, data: { module, stopped: true } };
    }

    // start
    if (sims.has(module))
      return {
        ok: false,
        code: "ALREADY_RUNNING",
        message: `${module} sim already running. Stop it first.`,
      };
    const channel = a.channel ?? "vcan0";
    const args = [UDSSIM, "--module", module, "--channel", channel];
    if (a.vin) args.push("--vin", a.vin);
    if (a.keyfn) args.push("--keyfn", a.keyfn);
    if (a.max_attempts != null)
      args.push("--max-attempts", String(a.max_attempts));
    if (a.p2_ms != null) args.push("--p2", String(a.p2_ms));
    if (a.pending_ms != null) args.push("--pending-ms", String(a.pending_ms));
    if (a.stmin_ms != null) args.push("--stmin", String(a.stmin_ms));
    for (const d of a.dids ?? []) args.push("--did", d);
    ctx.log(`starting ${module} sim on ${channel}`);
    const child = spawn("python3", args, {
      detached: false,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const log: string[] = [];
    const cap = (b: Buffer) => {
      if (log.join("").length < 4000) log.push(b.toString("utf8"));
    };
    child.stdout?.on("data", cap);
    child.stderr?.on("data", cap);
    sims.set(module, {
      module,
      channel,
      pid: child.pid!,
      startedAt: Date.now(),
      log,
    });

    await new Promise(r => setTimeout(r, 1200)); // capture the ready/error line
    const first = log.join("").trim().split("\n")[0] || "";
    if (/error/i.test(first)) {
      sims.delete(module);
      return { ok: false, code: "SIM_FAILED", message: first };
    }
    return {
      ok: true,
      data: {
        module,
        channel,
        pid: child.pid,
        status: first || "started",
        note: "Now drive it with can_send / your tester against the module's UDS IDs, and watch it on the bench.",
      },
    };
  },
};
