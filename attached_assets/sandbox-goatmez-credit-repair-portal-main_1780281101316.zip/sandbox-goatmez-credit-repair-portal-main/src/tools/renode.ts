import { z } from "zod";
import { mkdir, writeFile } from "node:fs/promises";
import { join, basename } from "node:path";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath } from "./shared.ts";

const repl = (
  cpu: string,
  fb: string,
  fs: string,
  rb: string,
  rs: string
) => `// Renode platform — auto-generated starter. Tune peripherals to your MCU.
cpu: CPU.CortexM @ sysbus
    cpuType: "${cpu}"
    nvic: nvic

nvic: IRQControllers.NVIC @ sysbus 0xE000E000
    -> cpu@0

flash: Memory.MappedMemory @ sysbus ${fb}
    size: ${fs}

sram: Memory.MappedMemory @ sysbus ${rb}
    size: ${rs}

// A catch-all so unmapped peripheral reads/writes don't fault while you map the real ones.
peripherals: Memory.MappedMemory @ sysbus 0x40000000
    size: 0x10000000
`;

const resc = (
  name: string,
  fw: string,
  fb: string
) => `# Renode script — auto-generated. Run:  renode ${name}.resc
mach create "${name}"
machine LoadPlatformDescription @${name}.repl

# Load the firmware into flash. On Cortex-M, reset reads SP=word[0], PC=word[1].
sysbus LoadBinary @${fw} ${fb}
cpu VectorTableOffset ${fb}

# Helpful while bringing it up:
#   (machine) sysbus LogAllPeripheralsAccess true   # find which peripherals it touches
#   (machine) cpu LogFunctionNames true
showAnalyzer sysbus.usart1   # if/when you add a UART
start
`;

export const renodeScaffoldTool: ToolDef = {
  name: "renode_scaffold",
  description:
    "Generate a Renode starter (.repl platform + .resc run script) to attempt full firmware re-hosting of an ARM Cortex-M module dump — the closest thing to actually BOOTING a dump. Sets up CPU/flash/SRAM/NVIC and loads the firmware at the flash base. You then iteratively stub the peripherals it touches. (Works for Cortex-M; TriCore/RH850/PowerPC aren't supported by Renode.)",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Firmware dump (.bin) to load." },
      name: {
        type: "string",
        description: "Machine/file name (default from the dump).",
      },
      cpu: {
        type: "string",
        description:
          "Cortex-M core, e.g. 'cortex-m3','cortex-m4','cortex-m7' (default cortex-m4).",
        default: "cortex-m4",
      },
      flash_base: {
        type: "string",
        description: "Flash base address (default 0x08000000).",
        default: "0x08000000",
      },
      flash_size: {
        type: "string",
        description: "Flash size (default 0x100000).",
        default: "0x100000",
      },
      ram_base: {
        type: "string",
        description: "SRAM base (default 0x20000000).",
        default: "0x20000000",
      },
      ram_size: {
        type: "string",
        description: "SRAM size (default 0x40000).",
        default: "0x40000",
      },
      out_dir: {
        type: "string",
        description: "Output directory (default ./renode).",
        default: "renode",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    name: z.string().optional(),
    cpu: z.string().optional(),
    flash_base: z.string().optional(),
    flash_size: z.string().optional(),
    ram_base: z.string().optional(),
    ram_size: z.string().optional(),
    out_dir: z.string().optional(),
  }),
  renderSummary: a => `renode_scaffold ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const name =
      (a.name ?? basename(path).replace(/\.[^.]+$/, "")).replace(
        /[^\w-]/g,
        "_"
      ) || "ecu";
    const cpu = a.cpu ?? "cortex-m4";
    const fb = a.flash_base ?? "0x08000000";
    const dir = resolvePath(ctx.cwd, a.out_dir ?? "renode");
    await mkdir(dir, { recursive: true });
    const replPath = join(dir, `${name}.repl`);
    const rescPath = join(dir, `${name}.resc`);
    await writeFile(
      replPath,
      repl(
        cpu,
        fb,
        a.flash_size ?? "0x100000",
        a.ram_base ?? "0x20000000",
        a.ram_size ?? "0x40000"
      )
    );
    await writeFile(rescPath, resc(name, path, fb));
    ctx.log(`scaffolded Renode platform for ${cpu}`);
    return {
      ok: true,
      data: {
        platform: replPath,
        script: rescPath,
        cpu,
        run: `renode ${rescPath}`,
        next_steps: [
          "Install Renode (https://renode.io) on your bench machine.",
          `Run: renode ${name}.resc  — it loads the dump and starts the core.`,
          "In Renode: `sysbus LogAllPeripheralsAccess true` to see which peripherals the firmware touches, then add/stub them in the .repl (UART, CAN, timers, watchdog).",
          "Iterate until it runs past init. This is per-module effort — Renode is a re-hosting toolkit, not a one-click boot.",
        ],
        note: "Cortex-M only. For TriCore/RH850/PowerPC ECUs, stick to behavioral sims (sim_from_dump) + routine emulation (emulate/make_keyfn).",
      },
    };
  },
};
