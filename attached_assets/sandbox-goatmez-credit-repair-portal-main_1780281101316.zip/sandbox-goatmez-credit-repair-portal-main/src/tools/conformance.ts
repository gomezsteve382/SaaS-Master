import { z } from "zod";
import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { resolvePath } from "./shared.ts";

const here = dirname(fileURLToPath(import.meta.url));
const UDSSIM = join(here, "..", "py", "udssim.py");

const idsFromCandump = (text: string): Set<string> => {
  const ids = new Set<string>();
  for (const line of text.split("\n")) {
    const m = line.match(/\)\s+\S+\s+([0-9A-Fa-f]+)#/);
    if (m) ids.add(m[1].toUpperCase());
  }
  return ids;
};

export const udsConformanceTool: ToolDef = {
  name: "uds_conformance",
  description:
    "Run YOUR real UDS test/tester code against the virtual bench and report pass/fail. Brings up vcan, starts the requested module sims, captures all CAN traffic while your `test_command` runs, then reports exit status, the request/response frames seen, and (if a real-bench `baseline` candump log is given) which arbitration IDs differ. The end-to-end 'does my UDS code actually work' check — off-car.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      test_command: {
        type: "string",
        description:
          "Your test command, e.g. 'pytest tests/test_uds.py' or 'python tester.py' (it should target the channel).",
      },
      modules: {
        type: "array",
        items: {
          type: "string",
          enum: ["ecm", "tcm", "bcm", "rfhub", "cluster"],
        },
        description: "Module sims to start (default ['ecm']).",
      },
      channel: {
        type: "string",
        description: "SocketCAN interface (default vcan0).",
        default: "vcan0",
      },
      workdir: {
        type: "string",
        description:
          "Directory to run the test in (default active project / cwd).",
      },
      vin: { type: "string", description: "VIN to serve (DID 0xF190)." },
      keyfn: {
        type: "string",
        description:
          "Path to the real seed→key python file so security access is truly validated.",
      },
      baseline: {
        type: "string",
        description:
          "Path to a candump -L log from the real bench to diff arbitration IDs against.",
      },
      timeout_ms: {
        type: "integer",
        description: "Max runtime for the test (default 120000).",
        default: 120000,
      },
    },
    required: ["test_command"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    test_command: z.string().min(1),
    modules: z
      .array(z.enum(["ecm", "tcm", "bcm", "rfhub", "cluster"]))
      .optional(),
    channel: z.string().optional(),
    workdir: z.string().optional(),
    vin: z.string().optional(),
    keyfn: z.string().optional(),
    baseline: z.string().optional(),
    timeout_ms: z.number().int().min(1000).max(900_000).optional(),
  }),
  renderSummary: a => `uds_conformance "${a.test_command.slice(0, 40)}"`,
  async handler(ctx, a) {
    const channel = a.channel ?? "vcan0";
    const modules = a.modules?.length ? a.modules : ["ecm"];
    const workdir = resolvePath(ctx.cwd, a.workdir ?? ".");

    if (!(await which("candump"))) {
      return {
        ok: false,
        code: "TOOL_MISSING",
        message:
          "can-utils (candump) not installed. Run scripts/bootstrap.sh on the bench VM.",
      };
    }

    // 1. bring up vcan
    const SUDO = process.getuid && process.getuid() === 0 ? "" : "sudo ";
    ctx.log(`bringing up ${channel}`);
    await execTool(
      "sh",
      [
        "-c",
        `${SUDO}modprobe vcan 2>/dev/null; ${SUDO}ip link add dev ${channel} type vcan 2>/dev/null; ${SUDO}ip link set up ${channel} 2>/dev/null; true`,
      ],
      { timeoutMs: 15_000 }
    );

    // 2. start candump capture
    let capture = "";
    const cap = spawn("candump", ["-L", channel]);
    cap.stdout?.on("data", (b: Buffer) => {
      if (capture.length < 200_000) capture += b.toString("utf8");
    });

    // 3. start module sims
    const simProcs: Array<{ module: string; pid: number; log: string[] }> = [];
    for (const mod of modules) {
      const args = [UDSSIM, "--module", mod, "--channel", channel];
      if (a.vin) args.push("--vin", a.vin);
      if (a.keyfn) args.push("--keyfn", a.keyfn);
      ctx.log(`starting ${mod} sim`);
      const p = spawn("python3", args, { stdio: ["ignore", "pipe", "pipe"] });
      const log: string[] = [];
      const c = (b: Buffer) => log.length < 50 && log.push(b.toString("utf8"));
      p.stdout?.on("data", c);
      p.stderr?.on("data", c);
      simProcs.push({ module: mod, pid: p.pid!, log });
    }
    await new Promise(r => setTimeout(r, 1500)); // let sims bind

    const simErrors = simProcs
      .filter(s => /error/i.test(s.log.join("")))
      .map(s => ({
        module: s.module,
        error: s.log.join("").trim().split("\n")[0],
      }));

    // 4. run the user's test
    ctx.log(`running test: ${a.test_command}`);
    const run = await execTool(
      "sh",
      ["-c", `cd ${JSON.stringify(workdir)} && ( ${a.test_command} )`],
      { timeoutMs: a.timeout_ms ?? 120_000 }
    );

    // 5. tear down
    for (const s of simProcs) {
      try {
        process.kill(s.pid, "SIGTERM");
      } catch {
        /* gone */
      }
    }
    try {
      cap.kill("SIGKILL");
    } catch {
      /* gone */
    }

    // 6. analyze captured traffic
    const testIds = idsFromCandump(capture);
    const frameCount = capture.split("\n").filter(l => l.includes("#")).length;
    let baselineDiff: unknown;
    if (a.baseline) {
      const bl = await readFile(resolvePath(ctx.cwd, a.baseline), "utf8").catch(
        () => ""
      );
      if (bl) {
        const blIds = idsFromCandump(bl);
        baselineDiff = {
          only_in_test: [...testIds].filter(i => !blIds.has(i)),
          only_in_baseline: [...blIds].filter(i => !testIds.has(i)),
          shared: [...testIds].filter(i => blIds.has(i)).length,
        };
      }
    }

    return {
      ok: true,
      data: {
        passed: run.code === 0 && simErrors.length === 0,
        test_exit_code: run.code,
        timed_out: run.timedOut,
        modules_started: modules,
        sim_errors: simErrors.length ? simErrors : undefined,
        frames_seen: frameCount,
        arbitration_ids: [...testIds].sort(),
        baseline_diff: baselineDiff,
        test_output: execText(run).slice(-4000),
        note: simErrors.length
          ? "A module sim failed to start (see sim_errors) — likely vcan/can-isotp missing. Run bootstrap on the bench VM."
          : "Validates your UDS protocol + logic against the sim. Timing/real-ECU behavior still needs the real bench; use `baseline` to diff IDs against a real capture.",
      },
    };
  },
};
