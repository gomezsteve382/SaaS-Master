import { z } from "zod";
import { readFile, writeFile, readdir } from "node:fs/promises";
import { join, relative } from "node:path";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath } from "./shared.ts";

const IGNORE = new Set([
  "node_modules",
  ".git",
  "dist",
  ".next",
  "build",
  "__pycache__",
  ".venv",
  "venv",
]);

export const readFileTool: ToolDef = {
  name: "read_file",
  description:
    "Read a text file, returned with line numbers (so you can edit precisely). Optionally read a slice with offset/limit (1-based line numbers).",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      offset: {
        type: "integer",
        description: "First line to read (1-based, default 1).",
      },
      limit: {
        type: "integer",
        description: "Max lines to read (default 600).",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    offset: z.number().int().min(1).optional(),
    limit: z.number().int().min(1).max(5000).optional(),
  }),
  renderSummary: a => `read_file ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const text = await readFile(path, "utf8");
    const lines = text.split("\n");
    const start = (a.offset ?? 1) - 1;
    const end = Math.min(lines.length, start + (a.limit ?? 600));
    const slice = lines
      .slice(start, end)
      .map((l, i) => `${start + i + 1}\t${l}`)
      .join("\n");
    ctx.log(`read ${path}`);
    return {
      ok: true,
      data: {
        path,
        total_lines: lines.length,
        shown: `${start + 1}-${end}`,
        content: slice,
      },
    };
  },
};

export const editFileTool: ToolDef = {
  name: "edit_file",
  description:
    "Edit a file by exact string replacement. `old_string` must appear exactly once (include surrounding context to make it unique) unless replace_all is true. Fails if not found or ambiguous — read_file first.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      old_string: {
        type: "string",
        description:
          "Exact text to replace (with enough context to be unique).",
      },
      new_string: { type: "string", description: "Replacement text." },
      replace_all: {
        type: "boolean",
        description: "Replace every occurrence (default false).",
        default: false,
      },
    },
    required: ["path", "old_string", "new_string"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    old_string: z.string(),
    new_string: z.string(),
    replace_all: z.boolean().optional(),
  }),
  renderSummary: a => `edit_file ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const text = await readFile(path, "utf8");
    const count = text.split(a.old_string).length - 1;
    if (count === 0)
      return {
        ok: false,
        code: "NOT_FOUND",
        message: "old_string not found in file.",
      };
    if (count > 1 && !a.replace_all) {
      return {
        ok: false,
        code: "AMBIGUOUS",
        message: `old_string occurs ${count}× — add context to make it unique, or set replace_all.`,
      };
    }
    const updated = a.replace_all
      ? text.split(a.old_string).join(a.new_string)
      : text.replace(a.old_string, a.new_string);
    await writeFile(path, updated);
    ctx.log(`edited ${path} (${count} replacement${count > 1 ? "s" : ""})`);
    return {
      ok: true,
      data: { path, replacements: a.replace_all ? count : 1 },
    };
  },
};

export const listDirTool: ToolDef = {
  name: "list_dir",
  description:
    "List a directory tree (skips node_modules/.git/dist/etc.). Use to explore a codebase before editing.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Directory (default cwd)." },
      depth: {
        type: "integer",
        description: "Max depth (default 3).",
        default: 3,
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string().optional(),
    depth: z.number().int().min(1).max(8).optional(),
  }),
  renderSummary: a => `list_dir ${a.path ?? "."}`,
  async handler(ctx, a) {
    const root = resolvePath(ctx.cwd, a.path ?? ".");
    const maxDepth = a.depth ?? 3;
    const out: string[] = [];
    let count = 0;
    async function walk(dir: string, depth: number): Promise<void> {
      if (depth > maxDepth || count > 4000) return;
      let entries;
      try {
        entries = await readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const ent of entries.sort((x, y) => x.name.localeCompare(y.name))) {
        if (IGNORE.has(ent.name) || ent.name.startsWith(".")) continue;
        const full = join(dir, ent.name);
        count++;
        out.push(
          `${"  ".repeat(depth)}${ent.isDirectory() ? "📁" : "  "}${relative(root, full)}`
        );
        if (ent.isDirectory()) await walk(full, depth + 1);
      }
    }
    ctx.log(`listing ${root}`);
    await walk(root, 0);
    return {
      ok: true,
      data: { root, entries: count, tree: out.join("\n") || "(empty)" },
    };
  },
};

export const searchCodeTool: ToolDef = {
  name: "search_code",
  description:
    "Search a directory tree for a regex/string (ripgrep if available, else grep). Returns matching file:line:text. Use to find symbols/usages across the codebase.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      pattern: {
        type: "string",
        description: "Regex or literal to search for.",
      },
      path: {
        type: "string",
        description: "Directory or file to search (default cwd).",
      },
      glob: {
        type: "string",
        description: "Optional file glob filter, e.g. '*.ts'.",
      },
      max: {
        type: "integer",
        description: "Max matching lines (default 200).",
        default: 200,
      },
    },
    required: ["pattern"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    pattern: z.string().min(1),
    path: z.string().optional(),
    glob: z.string().optional(),
    max: z.number().int().min(1).max(2000).optional(),
  }),
  renderSummary: a => `search_code /${a.pattern.slice(0, 40)}/`,
  async handler(ctx, a) {
    const where = resolvePath(ctx.cwd, a.path ?? ".");
    const max = a.max ?? 200;
    ctx.log(`searching for /${a.pattern.slice(0, 60)}/`);
    let r;
    if (await which("rg")) {
      const args = [
        "-n",
        "--no-heading",
        "-m",
        String(max),
        "--max-columns",
        "300",
      ];
      if (a.glob) args.push("-g", a.glob);
      args.push(a.pattern, where);
      r = await execTool("rg", args, { timeoutMs: 60_000 });
    } else {
      const args = [
        "-rEn",
        "--exclude-dir=node_modules",
        "--exclude-dir=.git",
        a.pattern,
        where,
      ];
      if (a.glob) args.splice(1, 0, `--include=${a.glob}`);
      r = await execTool("grep", args, { timeoutMs: 60_000 });
    }
    const lines = r.stdout.split("\n").filter(Boolean).slice(0, max);
    return {
      ok: true,
      data: {
        matches: lines.length,
        results: lines.join("\n") || "(no matches)",
      },
    };
  },
};
