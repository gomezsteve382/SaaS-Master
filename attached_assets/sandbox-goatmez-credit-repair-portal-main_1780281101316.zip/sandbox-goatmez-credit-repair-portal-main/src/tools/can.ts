import { z } from "zod";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, requireBins, resolvePath, runPy } from "./shared.ts";

export const dbcInfoTool: ToolDef = {
  name: "dbc_info",
  description:
    "List the messages and signals defined in a CAN database (.dbc) — IDs, signal bit layout, scale/offset/unit. Use it to understand what each CAN frame on the bus means.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path to a .dbc file." },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `dbc_info ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("parsing CAN database");
    return runPy("cankit.py", ["dbc-info", "--dbc", path]);
  },
};

export const dbcDecodeTool: ToolDef = {
  name: "dbc_decode",
  description:
    "Decode a raw CAN frame into physical signal values using a .dbc database. Give the arbitration id and the data bytes (hex).",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path to a .dbc file." },
      id: { type: "string", description: "CAN arbitration id, e.g. '0x3D0'." },
      data: {
        type: "string",
        description: "Frame data bytes as hex, e.g. '0011223344556677'.",
      },
    },
    required: ["path", "id", "data"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string(), id: z.string(), data: z.string() }),
  renderSummary: a => `dbc_decode ${a.id}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("decoding CAN frame");
    return runPy("cankit.py", [
      "dbc-decode",
      "--dbc",
      path,
      "--id",
      a.id,
      "--data",
      a.data,
    ]);
  },
};

export const udsReferenceTool: ToolDef = {
  name: "uds_reference",
  description:
    "Look up UDS (ISO 14229) diagnostic service IDs and negative-response codes. Call with no args for the full table, or pass a service/nrc byte to decode it (e.g. service=0x27 SecurityAccess, nrc=0x35 invalidKey).",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      service: { type: "string", description: "Service id byte, e.g. '0x27'." },
      nrc: {
        type: "string",
        description: "Negative-response code byte, e.g. '0x35'.",
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    service: z.string().optional(),
    nrc: z.string().optional(),
  }),
  renderSummary: () => "uds_reference",
  async handler(ctx, a) {
    const args = ["uds-ref"];
    if (a.service) args.push("--service", a.service);
    if (a.nrc) args.push("--nrc", a.nrc);
    ctx.log("UDS reference");
    return runPy("cankit.py", args);
  },
};

export const canMonitorTool: ToolDef = {
  name: "can_monitor",
  description:
    "Sniff live CAN traffic from a SocketCAN interface using candump (requires can-utils and a real/virtual CAN interface — works when run on hardware or with a vcan setup, not in a bare sandbox). Captures a bounded number of frames.",
  requires: ["candump"],
  inputSchema: {
    type: "object",
    properties: {
      channel: {
        type: "string",
        description: "SocketCAN interface, e.g. 'can0' or 'vcan0'.",
        default: "can0",
      },
      count: {
        type: "integer",
        description: "Number of frames to capture (default 50).",
        default: 50,
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    channel: z.string().optional(),
    count: z.number().int().min(1).max(5000).optional(),
  }),
  renderSummary: a => `can_monitor ${a.channel ?? "can0"}`,
  async handler(ctx, a) {
    const miss = await requireBins("candump");
    if (miss) return miss;
    const channel = a.channel ?? "can0";
    const count = a.count ?? 50;
    ctx.log(`capturing ${count} frames on ${channel}`);
    const r = await execTool("candump", ["-n", String(count), channel], {
      timeoutMs: 30_000,
    });
    return { ok: true, data: execText(r) };
  },
};

export const canSendTool: ToolDef = {
  name: "can_send",
  description:
    "Transmit a single CAN frame on a SocketCAN interface (cansend) — for BENCH/bench-harness testing on your own rig (use a vcan0 virtual bus or an isolated bench setup, never a vehicle in motion). Lets you test whether a crafted frame is accepted, to validate hardening.",
  requires: ["cansend"],
  inputSchema: {
    type: "object",
    properties: {
      channel: {
        type: "string",
        description: "SocketCAN interface, e.g. 'vcan0' or 'can0'.",
        default: "vcan0",
      },
      id: {
        type: "string",
        description: "Arbitration id in hex (no 0x), e.g. '3D0'.",
      },
      data: {
        type: "string",
        description: "Up to 8 data bytes as hex, e.g. 'DEADBEEF00'.",
      },
    },
    required: ["id", "data"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    channel: z.string().optional(),
    id: z.string().regex(/^[0-9A-Fa-f]{1,8}$/, "hex id, no 0x"),
    data: z.string().regex(/^([0-9A-Fa-f]{2}){0,8}$/, "0-8 hex bytes"),
  }),
  renderSummary: a => `can_send ${a.channel ?? "vcan0"} ${a.id}#${a.data}`,
  async handler(ctx, a) {
    const miss = await requireBins("cansend");
    if (miss) return miss;
    const channel = a.channel ?? "vcan0";
    const frame = `${a.id}#${a.data}`;
    ctx.log(`cansend ${channel} ${frame}`);
    const r = await execTool("cansend", [channel, frame], {
      timeoutMs: 10_000,
    });
    return {
      ok: true,
      data: { sent: frame, channel, result: execText(r) || "(frame sent)" },
    };
  },
};

export const canReplayTool: ToolDef = {
  name: "can_replay",
  description:
    "Replay a recorded candump log file onto a SocketCAN interface (canplayer) — for reproducing a captured sequence on a BENCH/virtual bus to study and test it. Optionally loop. Bench/authorized testing only.",
  requires: ["canplayer"],
  inputSchema: {
    type: "object",
    properties: {
      logfile: { type: "string", description: "Path to a candump log file." },
      channel: {
        type: "string",
        description: "Target interface (default vcan0).",
        default: "vcan0",
      },
      loops: {
        type: "integer",
        description: "Times to replay (default 1).",
        default: 1,
      },
    },
    required: ["logfile"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    logfile: z.string(),
    channel: z.string().optional(),
    loops: z.number().int().min(1).max(1000).optional(),
  }),
  renderSummary: a => `can_replay ${a.logfile}`,
  async handler(ctx, a) {
    const log = resolvePath(ctx.cwd, a.logfile);
    const e = (await ensureFile(log)) ?? (await requireBins("canplayer"));
    if (e) return e;
    const channel = a.channel ?? "vcan0";
    ctx.log(`canplayer → ${channel}`);
    // `channel=orig` remaps frames recorded on any interface onto the target.
    const r = await execTool(
      "canplayer",
      ["-I", log, "-l", String(a.loops ?? 1), `${channel}=can0`],
      {
        timeoutMs: 60_000,
      }
    );
    return {
      ok: true,
      data: { logfile: log, channel, result: execText(r) || "(replayed)" },
    };
  },
};
