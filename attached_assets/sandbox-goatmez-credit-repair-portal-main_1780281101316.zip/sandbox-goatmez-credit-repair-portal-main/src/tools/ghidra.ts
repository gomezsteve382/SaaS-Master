import { z } from "zod";
import { mkdtemp, readFile, access } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { config } from "../core/config.ts";
import { execTool, execText } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath } from "./shared.ts";

const here = dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = resolve(here, "..", "..");
const GHIDRA_SCRIPTS = join(REPO_ROOT, "scripts", "ghidra");

async function exists(p: string): Promise<boolean> {
  try {
    await access(p);
    return true;
  } catch {
    return false;
  }
}

export const ghidraDecompileTool: ToolDef = {
  name: "ghidra_decompile",
  description:
    "Decompile to C with Ghidra headless — the heavyweight decompiler that handles automotive/embedded CPUs radare2 can't: Infineon TriCore, PowerPC (MPC5xxx), V850, SuperH, AVR, ARM, AArch64, MIPS, x86. Runs full auto-analysis then decompiles. Decompile one function (by name/address) or the whole program. For raw firmware, supply `processor` (a Ghidra language id) and `base`.",
  requires: ["java"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      target: {
        type: "string",
        description:
          "Function name or address to decompile. Omit to decompile the whole program (capped).",
      },
      processor: {
        type: "string",
        description:
          "Ghidra language id for raw/embedded images, e.g. 'tricore:LE:32:default', 'PowerPC:BE:32:default', 'V850:LE:32:default', 'SuperH:LE:32:default', 'ARM:LE:32:v8'. Omit for PE/ELF (auto-detected).",
      },
      base: {
        type: "string",
        description: "Image base address for raw firmware, e.g. '0x80000000'.",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    target: z.string().optional(),
    processor: z.string().optional(),
    base: z.string().optional(),
  }),
  renderSummary: a =>
    `ghidra_decompile ${a.path}${a.target ? ` @ ${a.target}` : " (all)"}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const headless = join(config.ghidraDir, "support", "analyzeHeadless");
    if (!(await exists(headless))) {
      return {
        ok: false,
        code: "TOOL_MISSING",
        message: `Ghidra not found at ${config.ghidraDir}. Run scripts/bootstrap.sh (or set GHIDRA_DIR).`,
      };
    }

    const projDir = await mkdtemp(join(tmpdir(), "ghidra-"));
    const outFile = join(projDir, "decomp.txt");
    const args = [projDir, "reproj", "-import", path];
    if (a.processor) args.push("-processor", a.processor);
    if (a.base)
      args.push("-loader", "BinaryLoader", "-loader-baseAddr", a.base);
    args.push(
      "-scriptPath",
      GHIDRA_SCRIPTS,
      "-postScript",
      "DecompileToFile.py",
      outFile
    );
    if (a.target) args.push(a.target);
    args.push("-deleteProject");

    ctx.log("running Ghidra headless analysis (this can take a while)");
    const r = await execTool(headless, args, { timeoutMs: 480_000 });
    const decomp = await readFile(outFile, "utf8").catch(() => "");
    if (!decomp.trim()) {
      return {
        ok: false,
        code: "GHIDRA_NO_OUTPUT",
        message: `Ghidra produced no decompilation${a.target ? ` for '${a.target}'` : ""}. Log tail:\n${execText(r).slice(-1500)}`,
      };
    }
    return {
      ok: true,
      data: { target: a.target ?? "(whole program)", source: decomp },
    };
  },
};
