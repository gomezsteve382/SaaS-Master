import type { ToolDef } from "../core/types.ts";
import {
  identifyTool,
  listStringsTool,
  hexdumpTool,
  binaryMetadataTool,
  peInfoTool,
  elfInfoTool,
  symbolsTool,
  entropyTool,
  findSecretsTool,
} from "./static.ts";
import { disassembleTool, decompileTool, r2Tool } from "./code.ts";
import {
  swfTool,
  jvmDecompileTool,
  dotnetDisasmTool,
  deobfuscateJsTool,
} from "./formats.ts";
import { yaraScanTool, carveTool } from "./malware.ts";
import { runTargetTool, runShellTool } from "./dynamic.ts";
import { writeFileTool, sandboxRunTool } from "./sandbox.ts";
import {
  readFileTool,
  editFileTool,
  listDirTool,
  searchCodeTool,
} from "./coding.ts";
import { runTestsTool } from "./build.ts";
import { sandboxPreviewTool } from "./preview.ts";
import { vcanTool } from "./vcan.ts";
import { udsSimTool } from "./sim.ts";
import { simFromDumpTool } from "./simfromdump.ts";
import { renodeScaffoldTool } from "./renode.ts";
import { moduleMarriageTool } from "./marriage.ts";
import { patchBytesTool, fixChecksumTool } from "./patch.ts";
import { udsConformanceTool } from "./conformance.ts";
import { makeKeyfnTool } from "./keyfn.ts";
import {
  loadFirmwareTool,
  findCryptoTool,
  findMapsTool,
  parseA2lTool,
} from "./firmware.ts";
import { emulateTool } from "./emulate.ts";
import { ghidraDecompileTool } from "./ghidra.ts";
import {
  dbcInfoTool,
  dbcDecodeTool,
  udsReferenceTool,
  canMonitorTool,
  canSendTool,
  canReplayTool,
} from "./can.ts";
import { diffFirmwareTool } from "./diff.ts";
import {
  fcaProfileTool,
  keytableDiffTool,
  keyrecordTool,
  ecuReportTool,
  checksumScanTool,
  eepromMapTool,
} from "./fca.ts";

/** Every tool the agent can call. Order is stable for predictable prompts. */
export const ALL_TOOLS: ToolDef[] = [
  // Triage / static
  identifyTool,
  binaryMetadataTool,
  listStringsTool,
  hexdumpTool,
  entropyTool,
  findSecretsTool,
  symbolsTool,
  // Native deep-dive
  peInfoTool,
  elfInfoTool,
  disassembleTool,
  decompileTool,
  r2Tool,
  // Format-specific
  swfTool,
  jvmDecompileTool,
  dotnetDisasmTool,
  deobfuscateJsTool,
  // Malware screening
  yaraScanTool,
  carveTool,
  // Automotive / embedded firmware
  loadFirmwareTool,
  ghidraDecompileTool,
  findCryptoTool,
  findMapsTool,
  parseA2lTool,
  emulateTool,
  diffFirmwareTool,
  fcaProfileTool,
  ecuReportTool,
  keyrecordTool,
  keytableDiffTool,
  checksumScanTool,
  eepromMapTool,
  moduleMarriageTool,
  patchBytesTool,
  fixChecksumTool,
  // CAN / diagnostics
  dbcInfoTool,
  dbcDecodeTool,
  udsReferenceTool,
  canMonitorTool,
  canSendTool,
  canReplayTool,
  // Coding agent (read/edit/navigate a codebase)
  listDirTool,
  readFileTool,
  searchCodeTool,
  editFileTool,
  // Dev / test environment
  writeFileTool,
  sandboxRunTool,
  runTestsTool,
  sandboxPreviewTool,
  vcanTool,
  udsSimTool,
  simFromDumpTool,
  makeKeyfnTool,
  udsConformanceTool,
  renodeScaffoldTool,
  // Dynamic
  runTargetTool,
  runShellTool,
];
