import { z } from "zod";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath, runPy } from "./shared.ts";

export const makeKeyfnTool: ToolDef = {
  name: "make_keyfn",
  description:
    "Auto-generate a seed→key harness (keyfn.py) from a firmware routine by emulating it (Unicorn). Point it at the SecurityAccess key function (offset/start/stop/registers — found via ghidra_decompile / disassemble / find_crypto). The generated keyfn.py runs the REAL routine for any seed; load it into uds_sim/uds_conformance via --keyfn so the bench validates your tester's key code against the actual algorithm. Verifies with one sample seed.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: {
        type: "string",
        description: "Firmware/dump containing the key routine.",
      },
      arch: {
        type: "string",
        enum: ["x86", "arm", "arm64", "mips"],
        default: "x86",
      },
      bits: { type: "integer", enum: [16, 32, 64], default: 64 },
      base: {
        type: "string",
        description:
          "Virtual load address of the loaded code, e.g. '0x80000000'.",
        default: "0x400000",
      },
      offset: {
        type: "integer",
        description: "File offset of the code region to load (default 0).",
        default: 0,
      },
      size: {
        type: "integer",
        description: "Bytes of code to load (default 512).",
        default: 512,
      },
      start: {
        type: "string",
        description: "Address to begin execution (the key routine entry).",
      },
      stop: {
        type: "string",
        description:
          "Address to stop at (the routine's RET / after the key is computed).",
      },
      seed_reg: {
        type: "string",
        description:
          "Register the seed is passed in, e.g. 'edi','r0','x0','a0'.",
      },
      key_reg: {
        type: "string",
        description:
          "Register the key is returned in, e.g. 'eax','r0','x0','v0'.",
      },
      keylen: {
        type: "integer",
        description: "Key length in bytes (default 4).",
        default: 4,
      },
      endian: { type: "string", enum: ["little", "big"], default: "little" },
      out: {
        type: "string",
        description: "Output path for keyfn.py (default ./keyfn.py).",
        default: "keyfn.py",
      },
    },
    required: ["path", "start", "stop", "seed_reg", "key_reg"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    arch: z.enum(["x86", "arm", "arm64", "mips"]).optional(),
    bits: z.union([z.literal(16), z.literal(32), z.literal(64)]).optional(),
    base: z.string().optional(),
    offset: z.number().int().min(0).optional(),
    size: z.number().int().min(1).optional(),
    start: z.string(),
    stop: z.string(),
    seed_reg: z.string(),
    key_reg: z.string(),
    keylen: z.number().int().min(1).max(64).optional(),
    endian: z.enum(["little", "big"]).optional(),
    out: z.string().optional(),
  }),
  renderSummary: a => `make_keyfn ${a.path} → ${a.out ?? "keyfn.py"}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const out = resolvePath(ctx.cwd, a.out ?? "keyfn.py");
    ctx.log("emulating the key routine → generating keyfn.py");
    const args = [
      "--file",
      path,
      "--arch",
      a.arch ?? "x86",
      "--bits",
      String(a.bits ?? 64),
      "--base",
      a.base ?? "0x400000",
      "--offset",
      String(a.offset ?? 0),
      "--size",
      String(a.size ?? 512),
      "--start",
      a.start,
      "--stop",
      a.stop,
      "--seed-reg",
      a.seed_reg,
      "--key-reg",
      a.key_reg,
      "--keylen",
      String(a.keylen ?? 4),
      "--endian",
      a.endian ?? "little",
      "--out",
      out,
    ];
    return runPy("makekeyfn.py", args);
  },
};
