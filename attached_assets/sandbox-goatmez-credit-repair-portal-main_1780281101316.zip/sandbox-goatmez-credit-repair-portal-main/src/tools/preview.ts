import { z } from "zod";
import { spawn } from "node:child_process";
import { execTool } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { resolvePath } from "./shared.ts";

type Preview = {
  port: number;
  command: string;
  workdir: string;
  pid: number;
  startedAt: number;
  log: string[];
};

/** Live preview servers, keyed by port. Survive across tool calls. */
const previews = new Map<number, Preview>();
const HOST = process.env.PREVIEW_HOST || "localhost";

async function probe(port: number): Promise<string> {
  const r = await execTool(
    "sh",
    ["-c", `curl -sS -o /dev/null -w '%{http_code}' http://localhost:${port}/`],
    { timeoutMs: 4000 }
  );
  const code = r.stdout.trim();
  return code && code !== "000"
    ? `responding (HTTP ${code})`
    : "not responding yet";
}

export const sandboxPreviewTool: ToolDef = {
  name: "sandbox_preview",
  description:
    "Boot a long-running dev server / app in the sandbox and get a preview URL — to visually test a UI/app off-car before deploying. actions: 'start' (give command + port, e.g. 'pnpm dev' on 5180), 'stop', 'status', 'list'. The server keeps running across turns until stopped.",
  requires: [],
  inputSchema: {
    type: "object",
    properties: {
      action: {
        type: "string",
        enum: ["start", "stop", "status", "list"],
        default: "start",
      },
      command: {
        type: "string",
        description:
          "Command to launch the server (for 'start'). PORT env is set for you.",
      },
      port: {
        type: "integer",
        description: "Port the server listens on (for start/stop/status).",
      },
      workdir: {
        type: "string",
        description: "Working directory (default active project / cwd).",
      },
    },
    additionalProperties: false,
  },
  zodSchema: z.object({
    action: z.enum(["start", "stop", "status", "list"]).optional(),
    command: z.string().optional(),
    port: z.number().int().min(1).max(65535).optional(),
    workdir: z.string().optional(),
  }),
  renderSummary: a =>
    `preview ${a.action ?? "start"}${a.port ? ` :${a.port}` : ""}`,
  async handler(ctx, a) {
    const action = a.action ?? "start";

    if (action === "list") {
      const items = [...previews.values()].map(p => ({
        url: `http://${HOST}:${p.port}`,
        command: p.command,
        pid: p.pid,
        uptime_s: Math.round((Date.now() - p.startedAt) / 1000),
      }));
      return { ok: true, data: { count: items.length, previews: items } };
    }

    if (action === "status") {
      if (!a.port)
        return {
          ok: false,
          code: "BAD_ARGS",
          message: "port is required for status.",
        };
      const p = previews.get(a.port);
      if (!p) return { ok: true, data: { port: a.port, running: false } };
      return {
        ok: true,
        data: {
          url: `http://${HOST}:${p.port}`,
          command: p.command,
          pid: p.pid,
          uptime_s: Math.round((Date.now() - p.startedAt) / 1000),
          health: await probe(p.port),
          recent_log: p.log.slice(-30).join(""),
        },
      };
    }

    if (action === "stop") {
      if (!a.port)
        return {
          ok: false,
          code: "BAD_ARGS",
          message: "port is required for stop.",
        };
      const p = previews.get(a.port);
      if (!p)
        return {
          ok: true,
          data: {
            port: a.port,
            stopped: false,
            note: "no preview on that port",
          },
        };
      try {
        process.kill(-p.pid, "SIGTERM"); // kill the detached process group
      } catch {
        try {
          process.kill(p.pid, "SIGTERM");
        } catch {
          /* already gone */
        }
      }
      previews.delete(a.port);
      ctx.log(`stopped preview on :${a.port}`);
      return { ok: true, data: { port: a.port, stopped: true } };
    }

    // start
    if (!a.command || !a.port)
      return {
        ok: false,
        code: "BAD_ARGS",
        message: "command and port are required to start a preview.",
      };
    if (previews.has(a.port))
      return {
        ok: false,
        code: "PORT_BUSY",
        message: `A preview is already running on :${a.port}. Stop it first.`,
      };
    const workdir = resolvePath(ctx.cwd, a.workdir ?? ".");
    ctx.log(`starting preview: ${a.command} on :${a.port}`);
    const child = spawn(
      "sh",
      ["-c", `cd ${JSON.stringify(workdir)} && exec ${a.command}`],
      {
        detached: true,
        env: { ...process.env, PORT: String(a.port), HOST: "0.0.0.0" },
        stdio: ["ignore", "pipe", "pipe"],
      }
    );
    const log: string[] = [];
    const cap = (b: Buffer) => {
      if (log.join("").length < 8000) log.push(b.toString("utf8"));
    };
    child.stdout?.on("data", cap);
    child.stderr?.on("data", cap);
    child.unref();
    const rec: Preview = {
      port: a.port,
      command: a.command,
      workdir,
      pid: child.pid!,
      startedAt: Date.now(),
      log,
    };
    previews.set(a.port, rec);

    await new Promise(r => setTimeout(r, 2500)); // give it a moment to bind
    const health = await probe(a.port);
    return {
      ok: true,
      data: {
        url: `http://${HOST}:${a.port}`,
        pid: child.pid,
        command: a.command,
        workdir,
        health,
        startup_log: log.join("").slice(0, 2000),
        note: health.startsWith("not")
          ? "Server may still be starting, or it binds a different port — check status again, or read startup_log."
          : undefined,
      },
    };
  },
};
