import { resolve, isAbsolute, dirname, join } from "node:path";
import { stat } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolResult } from "../core/types.ts";

const here = dirname(fileURLToPath(import.meta.url));
/** Directory holding the Python analysis bridges. */
export const PY_DIR = join(here, "..", "py");
/** Absolute path to the core Python analysis bridge. */
export const REKIT = join(PY_DIR, "rekit.py");

export function resolvePath(cwd: string, p: string): string {
  return isAbsolute(p) ? p : resolve(cwd, p);
}

/** Return an error ToolResult if `path` isn't an existing regular file, else null. */
export async function ensureFile(path: string): Promise<ToolResult | null> {
  try {
    const s = await stat(path);
    if (!s.isFile())
      return {
        ok: false,
        code: "NOT_A_FILE",
        message: `${path} is not a regular file.`,
      };
    return null;
  } catch {
    return { ok: false, code: "NOT_FOUND", message: `File not found: ${path}` };
  }
}

/** Return an error ToolResult if any required binary is missing, else null. */
export async function requireBins(
  ...bins: string[]
): Promise<ToolResult | null> {
  for (const b of bins) {
    if (!(await which(b))) {
      return {
        ok: false,
        code: "TOOL_MISSING",
        message: `Required tool '${b}' is not installed. Run scripts/bootstrap.sh to provision the RE toolchain.`,
      };
    }
  }
  return null;
}

/** Invoke any Python bridge script (in src/py) and parse its trailing JSON line. */
export async function runPy(
  script: string,
  args: string[]
): Promise<ToolResult> {
  const r = await execTool("python3", [join(PY_DIR, script), ...args]);
  const lastLine = r.stdout.trim().split("\n").pop() ?? "";
  if (lastLine) {
    try {
      const obj = JSON.parse(lastLine);
      if (obj && typeof obj === "object" && "error" in obj) {
        return {
          ok: false,
          code: "ANALYSIS_ERROR",
          message: String((obj as any).error),
        };
      }
      return { ok: true, data: obj };
    } catch {
      // fall through to raw text
    }
  }
  if (r.code !== 0 || !r.stdout.trim()) {
    return { ok: false, code: "BRIDGE_ERROR", message: execText(r) };
  }
  return { ok: true, data: execText(r) };
}

/** Invoke a rekit.py subcommand and parse its trailing JSON line. */
export async function runRekit(
  sub: string,
  args: string[]
): Promise<ToolResult> {
  const r = await execTool("python3", [REKIT, sub, ...args]);
  const lastLine = r.stdout.trim().split("\n").pop() ?? "";
  if (lastLine) {
    try {
      const obj = JSON.parse(lastLine);
      if (obj && typeof obj === "object" && "error" in obj) {
        return {
          ok: false,
          code: "ANALYSIS_ERROR",
          message: String((obj as any).error),
        };
      }
      return { ok: true, data: obj };
    } catch {
      // fall through to raw text
    }
  }
  if (r.code !== 0 || !r.stdout.trim()) {
    return { ok: false, code: "BRIDGE_ERROR", message: execText(r) };
  }
  return { ok: true, data: execText(r) };
}
