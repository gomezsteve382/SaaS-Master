import { z } from "zod";
import { execTool, execText } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, requireBins, resolvePath } from "./shared.ts";

export const diffFirmwareTool: ToolDef = {
  name: "diff_firmware",
  description:
    "Compare two binaries/firmware images with radiff2 (radare2). mode='bytes' shows changed byte ranges (great for spotting calibration tweaks between two ECU dumps); mode='code' does function-level diffing after analysis (what changed between firmware versions).",
  requires: ["radiff2"],
  inputSchema: {
    type: "object",
    properties: {
      a: { type: "string", description: "First file (e.g. stock dump)." },
      b: { type: "string", description: "Second file (e.g. modified dump)." },
      mode: {
        type: "string",
        enum: ["bytes", "code"],
        description: "Diff mode (default bytes).",
        default: "bytes",
      },
    },
    required: ["a", "b"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    a: z.string(),
    b: z.string(),
    mode: z.enum(["bytes", "code"]).optional(),
  }),
  renderSummary: a => `diff_firmware ${a.a} ↔ ${a.b}`,
  async handler(ctx, a) {
    const pa = resolvePath(ctx.cwd, a.a);
    const pb = resolvePath(ctx.cwd, a.b);
    const e =
      (await ensureFile(pa)) ??
      (await ensureFile(pb)) ??
      (await requireBins("radiff2"));
    if (e) return e;
    const mode = a.mode ?? "bytes";
    ctx.log(`diffing (${mode})`);
    // -C = code diff (needs analysis), default = byte/delta diff.
    const args = mode === "code" ? ["-C", pa, pb] : [pa, pb];
    const r = await execTool("radiff2", args, { timeoutMs: 240_000 });
    return { ok: true, data: execText(r) };
  },
};
