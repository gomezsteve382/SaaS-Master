import { z } from "zod";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, resolvePath, runPy } from "./shared.ts";

export const loadFirmwareTool: ToolDef = {
  name: "load_firmware",
  description:
    "Ingest a firmware image (Intel HEX, Motorola S-record, or raw .bin) and reconstruct its memory map: segments + load addresses, execution start, reset-vector candidates, and ECU MCU/supplier fingerprints (Infineon TriCore, Renesas RH850, NXP PowerPC MPC5xxx, Bosch/Continental/Denso, EDC17/MED17, etc.). For raw .bin, pass `base` (the real load address) so later disassembly lands correctly.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      base: {
        type: "string",
        description:
          "Load address for a raw .bin, e.g. '0x80000000' (ignored for HEX/SREC).",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string(), base: z.string().optional() }),
  renderSummary: a => `load_firmware ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("reconstructing firmware memory map");
    const args = ["loadfw", path];
    if (a.base) args.push("--base", a.base);
    return runPy("autokit.py", args);
  },
};

export const findCryptoTool: ToolDef = {
  name: "find_crypto",
  description:
    "Scan a binary/firmware for cryptographic constants: AES S-box / inverse S-box / Rcon, SHA-1/SHA-256 init & round constants, MD5 sine table, and CRC-32/CRC-CCITT polynomials. Pinpoints crypto routines (secure boot, seed-key, checksum) so you can disassemble/emulate around them.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `find_crypto ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("scanning for crypto constants");
    return runPy("autokit.py", ["findcrypto", path]);
  },
};

export const findMapsTool: ToolDef = {
  name: "find_maps",
  description:
    "Heuristically locate calibration map axes (the tuning tables) in an ECU image by finding runs of monotonically increasing values (u8/u16 LE+BE) — these are axis breakpoints; the 2D/3D table usually sits adjacent. Cross-reference with parse_a2l addresses.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      min_len: {
        type: "integer",
        description: "Minimum run length to count as an axis (default 8).",
        default: 8,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    min_len: z.number().int().min(4).max(256).optional(),
  }),
  renderSummary: a => `find_maps ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("hunting calibration map axes");
    return runPy("autokit.py", [
      "maps",
      path,
      "--min-len",
      String(a.min_len ?? 8),
    ]);
  },
};

export const parseA2lTool: ToolDef = {
  name: "parse_a2l",
  description:
    "Parse an A2L (ASAP2) calibration-definition file: extract CHARACTERISTIC (maps/curves/values) and MEASUREMENT objects with their ECU addresses and descriptions. This is the key that names every map/secret in the firmware.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `parse_a2l ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    ctx.log("parsing A2L calibration definitions");
    return runPy("autokit.py", ["a2l", path]);
  },
};
