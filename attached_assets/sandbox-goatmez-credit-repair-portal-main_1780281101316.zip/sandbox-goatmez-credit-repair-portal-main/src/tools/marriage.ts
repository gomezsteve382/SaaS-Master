import { z } from "zod";
import type { ToolDef, ToolResult } from "../core/types.ts";
import { ensureFile, resolvePath, runPy } from "./shared.ts";

const data = (r: ToolResult): any => (r.ok ? r.data : { error: r.message });

export const moduleMarriageTool: ToolDef = {
  name: "module_marriage_check",
  description:
    "Cross-check a SET of programmed module dumps (e.g. PCM + RFHub + BCM) to see if they're consistently married: validates each dump's checksum, confirms the VIN matches across ALL of them, and finds shared immobilizer-secret bytes common to every dump. This is the strongest OFF-CAR signal that modules will be accepted as a set — but it is NECESSARY, NOT SUFFICIENT: the live multi-module handshake, timing, and hardware still decide if the car starts. It does NOT output 'car runs'.",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      dumps: {
        type: "array",
        items: { type: "string" },
        description:
          "Paths to the module dumps to cross-check (2+ recommended, e.g. PCM, RFHub, BCM).",
      },
    },
    required: ["dumps"],
    additionalProperties: false,
  },
  zodSchema: z.object({ dumps: z.array(z.string()).min(1) }),
  renderSummary: a => `module_marriage_check (${a.dumps.length} dumps)`,
  async handler(ctx, a) {
    const paths: string[] = [];
    for (const d of a.dumps) {
      const p = resolvePath(ctx.cwd, d);
      const e = await ensureFile(p);
      if (e) return e;
      paths.push(p);
    }

    // 1. Per-dump validity (checksum).
    ctx.log("validating each dump's checksums");
    const validity: Record<string, unknown> = {};
    for (const p of paths) {
      const cs = data(await runPy("autokit.py", ["checksum", p]));
      validity[p] = {
        verified_checksums: cs?.verified_checksums?.length ?? 0,
        ok: (cs?.verified_checksums?.length ?? 0) > 0,
      };
    }

    // 2. Cross-module VIN + shared-secret check.
    ctx.log("cross-checking VIN + shared secret across the set");
    const x = data(await runPy("autokit.py", ["xcheck", ...paths]));

    const allChecksumsOk = Object.values(validity).every((v: any) => v.ok);
    const consistent = x?.cross_module_consistency === "consistent";
    const vinPer: Record<string, string | null> = x?.vin_per_dump ?? {};

    // ---- Per-module "what needs to be matched" guidance ----
    // Majority VIN = the reference the others should agree with.
    const counts: Record<string, number> = {};
    for (const v of Object.values(vinPer))
      if (v) counts[v] = (counts[v] ?? 0) + 1;
    const refVin =
      Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

    const fixes: Array<{ dump: string; problem: string; action: string }> = [];
    for (const p of paths) {
      const label = p.split("/").pop() ?? p;
      if (!(validity[p] as any)?.ok) {
        fixes.push({
          dump: label,
          problem: "invalid/!verified checksum",
          action:
            "recalculate & fix this module's checksum before pairing (checksum_scan to locate it)",
        });
      }
      const v = vinPer[p];
      if (!v) {
        fixes.push({
          dump: label,
          problem: "no VIN found",
          action:
            "confirm the VIN region was written correctly (eeprom_map) — it may be missing or relocated",
        });
      } else if (refVin && v !== refVin) {
        fixes.push({
          dump: label,
          problem: `VIN is ${v}, others are ${refVin}`,
          action: `reprogram this module's VIN to ${refVin} so it matches the set`,
        });
      }
    }
    if (paths.length >= 2 && !x?.shared_secret_found) {
      fixes.push({
        dump: "(set)",
        problem: "no shared immobilizer secret across all dumps",
        action:
          "the modules aren't synced — re-run your SKIM/PIN sync so they share the secret (or the secret is encrypted/relocated and needs locating via ghidra_decompile/find_crypto)",
      });
    }

    const ok = consistent && allChecksumsOk && fixes.length === 0;

    return {
      ok: true,
      data: {
        dumps: paths,
        match_status: ok ? "MATCHED ✓" : "MISMATCH ✗",
        per_dump_validity: validity,
        all_checksums_valid: allChecksumsOk,
        vin_per_dump: vinPer,
        reference_vin: refVin,
        vin_match: x?.vin_match,
        shared_secret_found: x?.shared_secret_found,
        shared_secret_candidates: x?.shared_secret_candidates,
        cross_module_consistency: x?.cross_module_consistency,
        // What needs fixing, per module — empty when everything matches.
        to_fix: fixes,
        verdict: ok
          ? "MATCHED: all dumps valid + same VIN + shared secret. Necessary conditions met — now do the real-car/bench start test."
          : `MISMATCH — ${fixes.length} thing(s) to fix before these will pair (see to_fix). The car would reject the set as-is.`,
        important:
          "This checks dump validity + cross-module consistency only. It does NOT prove the car starts — the live PCM↔RFHub↔BCM handshake, ECU timing/self-tests, whether the write physically stuck, and hardware (transponder/SGW/sensors) are only testable on the real bench/vehicle.",
      },
    };
  },
};
