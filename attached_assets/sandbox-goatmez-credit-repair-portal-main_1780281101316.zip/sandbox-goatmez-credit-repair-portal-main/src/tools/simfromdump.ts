import { z } from "zod";
import type { ToolDef, ToolResult } from "../core/types.ts";
import { ensureFile, resolvePath, runPy } from "./shared.ts";
import { udsSimTool } from "./sim.ts";

const data = (r: ToolResult): any => (r.ok ? r.data : null);

export const simFromDumpTool: ToolDef = {
  name: "sim_from_dump",
  description:
    "Spin up a module simulator CONFIGURED FROM A REAL DUMP. Extracts the VIN (and key-table layout) from the dump, optionally generates the real seed→key from the dump's SecurityAccess routine (give its start/stop/registers), then launches a uds_sim that serves the dump's real data + real key algorithm on vcan. The turnkey 'use the simulator with a real binary' path. (It models behavior from the dump — it does not boot the firmware.)",
  requires: ["python3"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string", description: "The real firmware/EEPROM dump." },
      module: {
        type: "string",
        enum: ["ecm", "tcm", "bcm", "rfhub", "cluster"],
        description: "Module to simulate (default rfhub).",
        default: "rfhub",
      },
      channel: {
        type: "string",
        description: "SocketCAN interface (default vcan0).",
        default: "vcan0",
      },
      keyfn: {
        type: "string",
        description:
          "Path to an existing keyfn.py to use for seed→key (skip generation).",
      },
      // Optional: generate the real seed→key from the dump's routine (like make_keyfn).
      key_start: {
        type: "string",
        description: "Seed→key routine entry address (to auto-generate keyfn).",
      },
      key_stop: {
        type: "string",
        description: "Address to stop at (routine RET).",
      },
      seed_reg: {
        type: "string",
        description: "Register the seed is passed in (e.g. 'edi','r0').",
      },
      key_reg: {
        type: "string",
        description: "Register the key is returned in (e.g. 'eax','r0').",
      },
      key_arch: {
        type: "string",
        enum: ["x86", "arm", "arm64", "mips"],
        default: "arm",
      },
      key_bits: { type: "integer", enum: [16, 32, 64], default: 32 },
      key_base: {
        type: "string",
        description: "Load base for the routine (default 0x0).",
        default: "0x0",
      },
      keylen: {
        type: "integer",
        description: "Key length in bytes (default 4).",
        default: 4,
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    module: z.enum(["ecm", "tcm", "bcm", "rfhub", "cluster"]).optional(),
    channel: z.string().optional(),
    keyfn: z.string().optional(),
    key_start: z.string().optional(),
    key_stop: z.string().optional(),
    seed_reg: z.string().optional(),
    key_reg: z.string().optional(),
    key_arch: z.enum(["x86", "arm", "arm64", "mips"]).optional(),
    key_bits: z.union([z.literal(16), z.literal(32), z.literal(64)]).optional(),
    key_base: z.string().optional(),
    keylen: z.number().int().min(1).max(64).optional(),
  }),
  renderSummary: a => `sim_from_dump ${a.path} (${a.module ?? "rfhub"})`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const module = a.module ?? "rfhub";
    const channel = a.channel ?? "vcan0";

    // 1. Extract real data from the dump.
    ctx.log("extracting VIN / structures from the dump");
    const eep = data(await runPy("autokit.py", ["eepmap", path]));
    const vin = eep?.vin_candidates?.[0]?.vin as string | undefined;
    const keyTable = data(await runPy("autokit.py", ["keyrecord", path]));

    // 2. Resolve a keyfn (use provided, or generate from the dump's routine).
    let keyfnPath = a.keyfn ? resolvePath(ctx.cwd, a.keyfn) : undefined;
    let keyfnInfo: unknown;
    if (!keyfnPath && a.key_start && a.key_stop && a.seed_reg && a.key_reg) {
      const out = resolvePath(ctx.cwd, `keyfn_${module}.py`);
      ctx.log("generating real seed→key (emulating the dump routine)");
      const gen = await runPy("makekeyfn.py", [
        "--file",
        path,
        "--arch",
        a.key_arch ?? "arm",
        "--bits",
        String(a.key_bits ?? 32),
        "--base",
        a.key_base ?? "0x0",
        "--offset",
        "0",
        "--size",
        String(0x4000),
        "--start",
        a.key_start,
        "--stop",
        a.key_stop,
        "--seed-reg",
        a.seed_reg,
        "--key-reg",
        a.key_reg,
        "--keylen",
        String(a.keylen ?? 4),
        "--out",
        out,
      ]);
      keyfnInfo = data(gen) ?? gen;
      if (gen.ok && (gen.data as any)?.ok) keyfnPath = out;
    }

    // 3. Launch a uds_sim configured from the dump.
    ctx.log(`launching ${module} sim from dump on ${channel}`);
    const simArgs: Record<string, unknown> = {
      action: "start",
      module,
      channel,
    };
    if (vin) simArgs.vin = vin;
    if (keyfnPath) simArgs.keyfn = keyfnPath;
    const sim = await udsSimTool.handler(ctx, simArgs as never);

    return {
      ok: true,
      data: {
        module,
        channel,
        extracted: {
          vin: vin ?? "(none found)",
          key_table: keyTable?.best_guess ?? keyTable?.note,
        },
        keyfn:
          keyfnPath ??
          "(none — pass keyfn or the routine's key_start/key_stop/seed_reg/key_reg to validate the real algorithm)",
        keyfn_gen: keyfnInfo,
        sim: sim.ok ? sim.data : { error: sim.message, code: sim.code },
        note:
          "Sim now serves the dump's real VIN" +
          (keyfnPath ? " and validates the real seed→key" : "") +
          ". It models behavior from the dump; it does not execute the firmware.",
      },
    };
  },
};
