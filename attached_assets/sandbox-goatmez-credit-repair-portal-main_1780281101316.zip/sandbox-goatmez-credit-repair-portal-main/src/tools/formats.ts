import { z } from "zod";
import { mkdtemp, readFile, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { config } from "../core/config.ts";
import { execTool, execText, which } from "../core/exec.ts";
import type { ToolDef } from "../core/types.ts";
import { ensureFile, requireBins, resolvePath } from "./shared.ts";

const FFDEC = join(config.toolsDir, "ffdec", "ffdec.jar");
const CFR = join(config.toolsDir, "cfr.jar");

async function listFilesRec(dir: string): Promise<string[]> {
  const out: string[] = [];
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const ent of entries) {
    const full = join(dir, ent.name);
    if (ent.isDirectory()) out.push(...(await listFilesRec(full)));
    else out.push(full);
  }
  return out;
}

export const swfTool: ToolDef = {
  name: "swf",
  description:
    "Analyze an Adobe Flash .swf with JPEXS ffdec. action='tags' dumps the SWF structure/tag list; action='decompile' extracts and decompiles all ActionScript to source.",
  requires: ["java"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      action: {
        type: "string",
        enum: ["tags", "decompile"],
        description: "Default 'decompile'.",
        default: "decompile",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({
    path: z.string(),
    action: z.enum(["tags", "decompile"]).optional(),
  }),
  renderSummary: a => `swf ${a.action ?? "decompile"} ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("java"));
    if (e) return e;
    if (!(await fileExists(FFDEC))) {
      return {
        ok: false,
        code: "TOOL_MISSING",
        message: `ffdec.jar not found at ${FFDEC}. Run scripts/bootstrap.sh.`,
      };
    }
    const action = a.action ?? "decompile";
    if (action === "tags") {
      ctx.log("dumping SWF tags (ffdec)");
      const r = await execTool("java", ["-jar", FFDEC, "-dumpSWF", path], {
        timeoutMs: 180_000,
      });
      return { ok: true, data: execText(r) };
    }
    ctx.log("decompiling ActionScript (ffdec)");
    const dir = await mkdtemp(join(tmpdir(), "swf-"));
    const r = await execTool(
      "java",
      ["-jar", FFDEC, "-export", "script", dir, path],
      { timeoutMs: 240_000 }
    );
    const files = (await listFilesRec(dir)).filter(f => f.endsWith(".as"));
    if (files.length === 0) {
      return { ok: true, data: `No ActionScript extracted.\n${execText(r)}` };
    }
    const chunks: string[] = [];
    let total = 0;
    for (const f of files.sort()) {
      const src = await readFile(f, "utf8").catch(() => "");
      const rel = f.slice(dir.length + 1);
      const block = `// ===== ${rel} =====\n${src}\n`;
      total += block.length;
      chunks.push(block);
      if (total > config.maxToolResultChars) {
        chunks.push(
          `// ... (${files.length - chunks.length} more .as files truncated)`
        );
        break;
      }
    }
    return {
      ok: true,
      data: { classes: files.length, source: chunks.join("\n") },
    };
  },
};

export const jvmDecompileTool: ToolDef = {
  name: "jvm_decompile",
  description:
    "Decompile Java bytecode (.class or .jar) to readable Java source using CFR. For a jar, pass `only` to filter classes by a substring (e.g. a package name) and avoid huge output.",
  requires: ["java"],
  inputSchema: {
    type: "object",
    properties: {
      path: { type: "string" },
      only: {
        type: "string",
        description:
          "Optional substring; only decompile classes whose name contains it.",
      },
    },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string(), only: z.string().optional() }),
  renderSummary: a => `jvm_decompile ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("java"));
    if (e) return e;
    if (!(await fileExists(CFR))) {
      return {
        ok: false,
        code: "TOOL_MISSING",
        message: `cfr.jar not found at ${CFR}. Run scripts/bootstrap.sh.`,
      };
    }
    ctx.log("decompiling JVM bytecode (CFR)");
    const args = ["-jar", CFR, path];
    if (a.only) args.push("--jarfilter", `.*${a.only}.*`);
    const r = await execTool("java", args, { timeoutMs: 240_000 });
    return { ok: true, data: execText(r) };
  },
};

export const dotnetDisasmTool: ToolDef = {
  name: "dotnet_disasm",
  description:
    "Disassemble a .NET assembly (.exe/.dll) to CIL/IL with metadata using monodis.",
  requires: ["monodis"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `dotnet_disasm ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = (await ensureFile(path)) ?? (await requireBins("monodis"));
    if (e) return e;
    ctx.log("disassembling .NET (monodis)");
    const r = await execTool("monodis", [path], { timeoutMs: 120_000 });
    return { ok: true, data: execText(r) };
  },
};

export const deobfuscateJsTool: ToolDef = {
  name: "deobfuscate_js",
  description:
    "Beautify/format minified or obfuscated JavaScript (via prettier) so it can be read. Reveals structure; does not undo logic-level obfuscation, but makes packed one-liners legible.",
  requires: ["prettier"],
  inputSchema: {
    type: "object",
    properties: { path: { type: "string" } },
    required: ["path"],
    additionalProperties: false,
  },
  zodSchema: z.object({ path: z.string() }),
  renderSummary: a => `deobfuscate_js ${a.path}`,
  async handler(ctx, a) {
    const path = resolvePath(ctx.cwd, a.path);
    const e = await ensureFile(path);
    if (e) return e;
    const havePrettier =
      (await which("prettier")) ||
      (await fileExists("node_modules/.bin/prettier"));
    if (!havePrettier)
      return {
        ok: false,
        code: "TOOL_MISSING",
        message: "prettier not found. Run `pnpm install`.",
      };
    ctx.log("beautifying JavaScript (prettier)");
    const bin = (await which("prettier"))
      ? "prettier"
      : "node_modules/.bin/prettier";
    const r = await execTool(bin, ["--parser", "babel", path], {
      timeoutMs: 60_000,
    });
    if (r.code !== 0 && !r.stdout.trim()) {
      // Fallback: naive brace/semicolon line-breaking when prettier rejects the syntax.
      const src = await readFile(path, "utf8");
      const naive = src.replace(/([;{}])/g, "$1\n");
      return { ok: true, data: { formatter: "naive-fallback", code: naive } };
    }
    return { ok: true, data: { formatter: "prettier", code: execText(r) } };
  },
};

async function fileExists(p: string): Promise<boolean> {
  try {
    await readFile(p);
    return true;
  } catch {
    return false;
  }
}
