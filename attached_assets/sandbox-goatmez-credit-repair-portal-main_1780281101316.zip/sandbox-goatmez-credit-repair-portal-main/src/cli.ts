#!/usr/bin/env -S npx tsx
import readline from "node:readline";
import { stdin, stdout } from "node:process";
import { Agent, type AgentEvent } from "./core/agent.ts";
import { ALL_TOOLS } from "./tools/index.ts";
import { which } from "./core/exec.ts";
import { config } from "./core/config.ts";
import { ModelAuthError } from "./core/model.ts";

const C = {
  dim: (s: string) => `\x1b[2m${s}\x1b[0m`,
  bold: (s: string) => `\x1b[1m${s}\x1b[0m`,
  cyan: (s: string) => `\x1b[36m${s}\x1b[0m`,
  green: (s: string) => `\x1b[32m${s}\x1b[0m`,
  red: (s: string) => `\x1b[31m${s}\x1b[0m`,
  yellow: (s: string) => `\x1b[33m${s}\x1b[0m`,
};

function eventLine(ev: AgentEvent): void {
  switch (ev.type) {
    case "tool_start":
      stdout.write(C.dim(`  ⚙ ${ev.summary}\n`));
      break;
    case "tool_end":
      stdout.write(C.dim(`  ${ev.ok ? "✓" : "✗"} ${ev.name} ${ev.ms}ms\n`));
      break;
    case "status":
      stdout.write(C.dim(`    … ${ev.line}\n`));
      break;
    case "usage":
      stdout.write(
        C.dim(`  [${ev.model}: ${ev.prompt}+${ev.completion} tok]\n`)
      );
      break;
  }
}

async function checkTools(): Promise<void> {
  const bins = new Set<string>();
  for (const t of ALL_TOOLS) for (const b of t.requires ?? []) bins.add(b);
  bins.add("r2");
  bins.add("rabin2");
  bins.add("radiff2");
  bins.add("strace");
  bins.add("ltrace");
  bins.add("wine");
  bins.add("candump");
  stdout.write(C.bold("\nRE-Agent toolchain:\n"));
  for (const b of [...bins].sort()) {
    const ok = await which(b);
    stdout.write(`  ${ok ? C.green("✓") : C.red("✗")} ${b}\n`);
  }
  stdout.write(
    C.dim("\n  Missing tools? Run: pnpm bootstrap  (scripts/bootstrap.sh)\n\n")
  );
}

async function runTurn(agent: Agent, text: string): Promise<void> {
  const ac = new AbortController();
  const onSigint = () => ac.abort();
  process.on("SIGINT", onSigint);
  try {
    await agent.send(
      text,
      { onText: d => stdout.write(d), onEvent: eventLine },
      ac.signal
    );
    stdout.write("\n");
  } catch (err) {
    if (err instanceof ModelAuthError) {
      stdout.write(C.red(`\n${err.message}\n`));
    } else if (ac.signal.aborted) {
      stdout.write(C.yellow("\n[aborted]\n"));
    } else {
      stdout.write(
        C.red(`\nError: ${err instanceof Error ? err.message : String(err)}\n`)
      );
    }
  } finally {
    process.off("SIGINT", onSigint);
  }
}

const HELP = `
${C.bold("RE-Agent")} — reverse-engineering assistant

Commands (in the REPL):
  /tools        show RE toolchain availability
  /reset        clear the conversation
  /model        show the active model
  /help         this help
  /exit, /quit  leave

Just type a request, e.g.:
  analyze ./suspicious.exe and tell me if it's malware
  decompile main in ./crackme and explain the license check
  pull every embedded key/secret out of ./firmware.bin
`;

async function repl(agent: Agent): Promise<void> {
  stdout.write(HELP);
  stdout.write(
    C.dim(
      `model: ${config.model}${config.apiKey ? "" : "  (no OPENROUTER_API_KEY set!)"}\n\n`
    )
  );
  const rl = readline.createInterface({
    input: stdin,
    output: stdout,
    prompt: C.cyan("re» "),
  });
  rl.prompt();
  rl.on("line", async line => {
    const text = line.trim();
    if (!text) return rl.prompt();
    if (text === "/exit" || text === "/quit") return rl.close();
    if (text === "/help") {
      stdout.write(HELP);
      return rl.prompt();
    }
    if (text === "/tools") {
      await checkTools();
      return rl.prompt();
    }
    if (text === "/reset") {
      agent.reset();
      stdout.write(C.dim("(conversation cleared)\n"));
      return rl.prompt();
    }
    if (text === "/model") {
      stdout.write(
        C.dim(
          `model: ${config.model}; fallbacks: ${config.fallbackModels.join(", ") || "none"}\n`
        )
      );
      return rl.prompt();
    }
    rl.pause();
    await runTurn(agent, text);
    rl.resume();
    rl.prompt();
  });
  rl.on("close", () => {
    stdout.write(C.dim("\nbye.\n"));
    process.exit(0);
  });
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args[0] === "--check-tools" || args[0] === "tools") {
    await checkTools();
    return;
  }
  if (args[0] === "--help" || args[0] === "-h") {
    stdout.write(HELP);
    return;
  }
  const agent = new Agent(process.cwd());
  if (args.length > 0) {
    // One-shot: treat the args as a single request.
    await runTurn(agent, args.join(" "));
    return;
  }
  await repl(agent);
}

main().catch(err => {
  stdout.write(
    C.red(`fatal: ${err instanceof Error ? err.message : String(err)}\n`)
  );
  process.exit(1);
});
