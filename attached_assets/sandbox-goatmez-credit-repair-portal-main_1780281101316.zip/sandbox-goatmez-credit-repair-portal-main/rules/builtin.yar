/*
 * RE-Agent built-in heuristic YARA rules.
 * These are lightweight TRIAGE heuristics, not authoritative AV signatures.
 * A hit means "worth a closer look," not "definitely malicious."
 */

rule Suspicious_Windows_API_Combo
{
    meta:
        description = "PE imports a combination of APIs commonly used for code injection"
        severity = "medium"
    strings:
        $valloc   = "VirtualAlloc" ascii wide
        $vprotect = "VirtualProtect" ascii wide
        $wpm      = "WriteProcessMemory" ascii wide
        $crt      = "CreateRemoteThread" ascii wide
        $getproc  = "GetProcAddress" ascii wide
        $loadlib  = "LoadLibrary" ascii wide
    condition:
        3 of them
}

rule AntiDebug_Indicators
{
    meta:
        description = "Anti-debugging / anti-analysis API references"
        severity = "low"
    strings:
        $a = "IsDebuggerPresent" ascii wide
        $b = "CheckRemoteDebuggerPresent" ascii wide
        $c = "NtQueryInformationProcess" ascii wide
        $d = "OutputDebugString" ascii wide
        $e = "QueryPerformanceCounter" ascii wide
    condition:
        2 of them
}

rule Networking_Capability
{
    meta:
        description = "Network / download capability"
        severity = "low"
    strings:
        $a = "URLDownloadToFile" ascii wide
        $b = "InternetOpen" ascii wide
        $c = "WinHttp" ascii wide
        $d = "socket" ascii wide
        $e = "WSAStartup" ascii wide
        $f = "ws2_32.dll" ascii wide nocase
    condition:
        2 of them
}

rule Embedded_PE_In_File
{
    meta:
        description = "An MZ/PE header found embedded past the start of the file (dropper/packed payload)"
        severity = "medium"
    strings:
        $mz = { 4D 5A }
    condition:
        // an MZ that is NOT at offset 0
        $mz in (1..filesize)
}

rule Known_Packer_Section_Names
{
    meta:
        description = "Section names associated with common packers"
        severity = "medium"
    strings:
        $upx0 = "UPX0" ascii
        $upx1 = "UPX1" ascii
        $aspack = ".aspack" ascii
        $themida = ".themida" ascii
        $petite = ".petite" ascii
        $mpress = ".MPRESS" ascii nocase
    condition:
        any of them
}

rule Shell_And_Persistence_Strings
{
    meta:
        description = "Command execution / persistence indicators"
        severity = "low"
    strings:
        $a = "cmd.exe /c" ascii wide nocase
        $b = "powershell" ascii wide nocase
        $c = "schtasks" ascii wide nocase
        $d = "CurrentVersion\\Run" ascii wide nocase
        $e = "/bin/sh" ascii
        $f = "system(" ascii
    condition:
        2 of them
}
