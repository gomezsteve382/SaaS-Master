# RE-Agent

An autonomous **reverse-engineering software agent** with a web UI. An LLM (via
OpenRouter, your key) drives **80+ real tools** to crack open binaries, screen
for malware, analyze automotive/ECU firmware, write & test code, and run a full
**off-car virtual CAN/UDS bench** — then chats with you about any of it.

> Light, Pixar-style UI · Chat + Bench views · autonomous-on-upload · live tool
> timeline · persistent history · project switcher · runs on your OpenRouter key.

---

## Quick start

```bash
bash scripts/bootstrap.sh        # toolchain: radare2, Ghidra, capstone/lief, unicorn,
                                 #            yara, binwalk, can-utils, can-isotp, wine, JDK…
pnpm install
cp .env.example .env             # set OPENROUTER_API_KEY (a fresh key)
pnpm build && pnpm start         # → http://localhost:5173   (dev: pnpm dev)
```

Drop a file in the UI and it auto-rips it apart; or `pnpm agent "analyze ./x.exe"` for the CLI.

### Key env vars
| var | purpose |
|---|---|
| `OPENROUTER_API_KEY` | required — your OpenRouter key |
| `RE_AGENT_MODEL` | model slug (default `anthropic/claude-sonnet-4.5`) |
| `RE_AGENT_PROJECTS_ROOT` | dir scanned for the Projects switcher (e.g. where SRT Lab lives) |
| `RE_AGENT_SESSIONS` | where chat history is persisted |
| `RE_AGENT_PRICE_IN` / `_OUT` | USD per 1M tokens, to make the cost readout exact |
| `GHIDRA_DIR` | Ghidra install dir (default `/opt/re-tools/ghidra`) |

---

## What it can do

**Reverse engineering** — identify, strings, hexdump, entropy, symbols, find_secrets;
PE/ELF deep-dives; disassemble (capstone), decompile (radare2), arbitrary `r2`;
**Ghidra** decompile incl. embedded CPUs (TriCore, PowerPC, V850, SuperH, AVR, ARM,
MIPS); SWF (ffdec), JVM (CFR), .NET (monodis), obfuscated JS.

**Malware screening** — yara_scan (built-in heuristics + your rules), carve (binwalk),
entropy/packer detection, suspicious-import + IOC reporting.

**Automotive / ECU firmware** — load_firmware (HEX/SREC/raw → memory map + MCU
fingerprint), ecu_report, find_crypto, emulate (Unicorn), diff_firmware, find_maps,
parse_a2l, keyrecord, keytable_diff, checksum_scan, eeprom_map, fca_profile;
CAN/diagnostics: dbc_info/decode, uds_reference, can_monitor/send/replay.

**Virtual bench (test off-car)** — vcan + one-click **Boot virtual bench**; uds_sim
(behavioral ECM/BCM/RFHub/cluster); **sim_from_dump** (configure a sim from a real
dump's VIN + seed→key); **make_keyfn** (emulate the real seed→key → keyfn.py);
**uds_conformance** (run YOUR UDS code → pass/fail + baseline diff); renode_scaffold
(ARM Cortex-M re-hosting starter).

**Coding agent** — list_dir, read_file, search_code, edit_file, write_file, run_tests
(pnpm/npm/python/cargo/go/make), sandbox_run, sandbox_preview, run_target, run_shell.

**Platform** — persistent History, Projects switcher, Chat↔Bench, cumulative cost
readout, reproducible `bootstrap.sh`.

---

## Honest scope / limits

- The bench **models** module behavior (seeded from real dumps) and emulates real
  *routines* (seed→key, checksums). It does **not boot real firmware** — full
  re-hosting of TriCore/RH850/PowerPC ECUs isn't feasible; ARM Cortex-M can be
  attempted via `renode_scaffold` (per-module effort).
- Live CAN/bench features need `vcan` + `can-utils` + `can-isotp` (a real Linux VM).
- This is an **analysis & test** platform. It intentionally does **not** include
  immobilizer-defeat, key-cloning, or ECU flash-writing — keep that to your bench
  hardware and authorized work on vehicles you own.

## UI previews

`previews/chat.html` and `previews/bench.html` are standalone snapshots (open in a
browser). Regenerate with `node scripts/gen-previews.mjs`.
