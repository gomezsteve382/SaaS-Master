import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const root = dirname(fileURLToPath(import.meta.url));

// The React app lives in web/. Build output goes to web/dist, which the
// production Express server (server/index.ts) serves statically.
export default defineConfig({
  root: resolve(root, "web"),
  plugins: [react()],
  build: {
    outDir: resolve(root, "web", "dist"),
    emptyOutDir: true,
  },
});
