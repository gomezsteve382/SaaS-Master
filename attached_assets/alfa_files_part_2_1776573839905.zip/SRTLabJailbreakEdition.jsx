import React, { useState, useCallback, useMemo, useRef } from "react";

/* ═══ VERIFIED ENGINES ═══ */
function crc16(d,i=0xFFFF){let c=i;for(let x=0;x<d.length;x++){c^=d[x]<<8;for(let j=0;j<8;j++)c=c&0x8000?(c<<1)^0x1021:c<<1;c&=0xFFFF;}return c;}
function crc8a(d,i=0){let c=i;for(let x=0;x<d.length;x++){c^=d[x];for(let j=0;j<8;j++)c=c&0x80?(c<<1)^0x26:c<<1;c&=0xFF;}return c;}
const u32=n=>n>>>0;
function sxor(s,c){let k=u32(s);for(let i=0;i<5;i++)k=k&0x80000000?u32((k<<1)^u32(c)):u32(k<<1);return k;}
function cda6(s){let k=u32(s);k=u32(k^0x4B129F);k=u32((k<<3)|(k>>>29));k=u32(k+0x1234);k=u32(k^0xABCD);return u32((k>>>5)|(k<<27));}
/* Per-module sxor constants (VINCommander) — used as fallbacks after CDA6 */
const MC={ECM:0x8A3C71,TCM:0x6E4B92,BCM:0x4B129F,RFHUB:0xD5F1,ABS:0x4B129F,IPC:0x4B129F,EPS:0x4B129F,RADIO:0x4B129F,DAMP:0x6E4B92,ORC:0x4B129F,HVAC:0x4B129F,DTCM:0x6E4B92};
const NT=[0x44,0x41,0x49,0x4D,0x4C,0x45,0x52,0x43,0x48,0x52,0x59,0x53,0x4C,0x45,0x52,0x31],NS=[0x9D9F,0xCE48,0xB0F3,0xD99B,0xA720,0xFDD6,0x836D,0x6F8E];
function ngc(s){let k=0;for(let i=0;i<4;i++){let b=(u32(s)>>(i*8))&0xFF;k=u32(k^u32(((NT[b&0xF]^NT[(b>>4)&0xF])*NS[i%8])&0xFFFFFFFF));}return k;}
const TT={a:[0x727B,0xB301,0x08EB,0xB0BA,0xECA7,0x0ECC,0xD69A,0xE47E],b:[0x7A44,0x0201,0xF123,0x146E,0xCBC2,0x553F,0xD398,0x4EDC],c:[0x22B5,0x5767,0x4C5A,0xE443,0xC606,0x7544,0x0DFB,0x36D6],d:[0x632A,0x193B,0x914F,0x0F88,0x5E51,0x8DCD,0xDD6C,0x00DD]},TM=[0xBAEE,0xE000,0x1C00,0x0380,0x0070,0x0007];
function tipm(s,t='a'){const tb=TT[t]||TT.a;let v=s&0xFFFF,k=0;for(let i=0;i<tb.length;i++){let m=v&TM[i%TM.length],b=0,x=m;while(x){b^=x&1;x>>=1;}k=(k<<1)|b;k^=tb[i];k&=0xFFFF;}return k;}
/* AlfaOBD reverse-engineered algorithms (ad::w6, ad::w7 wrappers + 3 crypto algos) */
/* 380 w6 wrappers catalogued below; 3 XTEA-style algorithms (f, ht, ao) below. */
const AOK=[0x9B127D51,0x5BA41903,0x4FE87269,0x6BC361D8],AOD=0x8F750A1D;
function aoXtea(v1){let v8=0,sm=0;for(let i=0;i<64;i++){const i1=((((v8<<4)>>>0)^(v8>>>5))+v8)>>>0;v1=(v1+(i1^((sm+AOK[sm&3])>>>0)))>>>0;sm=(sm+AOD)>>>0;const i2=((((v1<<4)>>>0)^(v1>>>5))+v1)>>>0;v8=(v8+(i2^((sm+AOK[(sm>>>11)&3])>>>0)))>>>0;}return v1;}
function alfaF(s){const u=u32(s),v=(((u&0xFF)<<24)|((u>>>8)&0xFF)<<16|((u>>>16)&0xFF)<<8|((u>>>24)&0xFF))>>>0;return aoXtea(v);}
function alfaAO(s){return aoXtea(u32(s));}
/* w6: parameterized linear cipher. Each per-ECU wrapper is (r,s) in AOBD_W6. */
function alfaW6(s,r,sc){const u=u32(s),s0=(u>>>24)&0xFF,s1=(u>>>16)&0xFF,s2=(u>>>8)&0xFF,s3=u&0xFF;const v0=(((s0<<24)|(s1<<16)|(s2<<8)|s3)>>>0);const vd=(((s1<<24)|(s0<<16)|(s3<<8)|s2)>>>0);const v1=((((vd<<11)>>>0)+(vd>>>22))>>>0);const v2=(sc&v0)>>>0;return(v1^r^v2)>>>0;}
function alfaHT(s){return alfaW6(s,0x41AA42BB,0x22BA9A31);}
/* AOBD_W6: per-ECU (r,s) table — 380 wrappers decoded from AlfaOBD.exe. Key by 'ad::NAME'. */
const AOBD_W6={a0:[0x57EF2013,0x48AD5DA6],a1:[0xB1E456CC,0x406C4F01],a2:[0xBF5C0159,0x7C7D32FF],a3:[0x9EC0EA81,0x9B599A94],a4:[0xC30A6F8F,0x66DA07BE],a5:[0xB78D1E54,0x6D257CF7],a6:[0x387D8272,0xDA61553F],a7:[0xDCCCF9EC,0x31D7BC15],a8:[0xA1C23A97,0x2F6F2947],a9:[0xDFAA6CBF,0x87C5962F],b6:[0xA50893B9,0xBF9B8336],b7:[0xDA160FCC,0x653D1531],b8:[0xC0F6712C,0xD5ACC723],b9:[0x3A375AD8,0x383F2CE7],ba:[0xF40BCA21,0x7B2E8EA5],bb:[0x53E19222,0x1931A733],be:[0x508CA0E7,0x79264F2B],bg:[0xC2E83580,0xE242AB16],bh:[0x45BCC0EE,0x34B3A15B],bi:[0x3CFD4074,0xF0022C9A],bj:[0x66DA5EC2,0x24D72C03],bk:[0xF838EA15,0xFA94EA40],bl:[0x918874F4,0x22D2CB95],bm:[0x248CA233,0x79E9DD3D],bn:[0xEDF9BD8C,0x5D118CEC],bs:[0xC5030E4D,0xBB3B331F],bv:[0xE6DA35C4,0x8E859CE8],bw:[0x5B3ED90C,0x9FB8B9AE],bx:[0x68018763,0xD2791028],by:[0x6C8FE84F,0x9C30D3BE],bz:[0x74F66A92,0x4DE3A3E3],cc:[0xF9B6892F,0x82FD1FCD],cd:[0x88B9E1D0,0xDCD9C318],ce:[0xFBC7FA19,0x3843C6C5],cg:[0x4C0714AF,0xC7A94CFD],ch:[0x531689D1,0x18FB7395],ci:[0x983F101B,0x44EC05BD],cj:[0x41A8969A,0x6234BA3E],ck:[0xEE4D951E,0x18FE826E],d0:[0x2D4791F5,0xD0500B30],d1:[0xE3F5C5D0,0xB119357C],d5:[0xA91B575B,0x9D9ABD79],d6:[0x81D23EE3,0x5FDB33C6],d8:[0x953573D6,0xABAA1F9E],d9:[0x8F282D76,0x5FDCC309],dk:[0xA7EDE2FC,0x4BE31331],dl:[0x848585A1,0xCF201A23],do:[0x1A54F2B2,0xF49EB15E],dp:[0xA2528317,0xF6DC270B],dq:[0x7DFEFF2B,0x5AF67CBC],dr:[0x5CD2872A,0xBEDEED07],ds:[0x1A54F2B2,0xF49EB15E],dt:[0xA2528317,0xF6DC270B],du:[0x387D8272,0xDA61553F],dv:[0xDCCCF9EC,0x31D7BC15],dw:[0x704949D0,0x9E428592],dx:[0x8B0DF1AE,0xB779E3A9],dy:[0xFDFB7DBD,0x1BF1F0D7],dz:[0x4629591A,0xB44B95FA],e0:[0x95AB8CEC,0x5DA1AA04],e5:[0x4A84298E,0x872F95E0],e6:[0xE37F5688,0xD2E332CC],e7:[0xFAA53165,0x91011442],ef:[0x3436904A,0xD731F06F],eg:[0x217224C7,0xAC30E2CC],ej:[0xB0B4AE22,0x476A6031],ek:[0x80B54D19,0x20DED45F],el:[0x6FDA4A70,0xD8124906],em:[0x36E86899,0x1AB0E4E1],er:[0x8605AC3A,0xDB60B644],es:[0x9063BC10,0x8605AC3A],ev:[0x8A4A520B,0x69924163],ew:[0xE7C8D765,0x74FDCDF7],ex:[0xC88CAEF8,0xD71385E9],ey:[0xD1115295,0xC2B7494A],ez:[0xB79448AC,0xCD8B91FE],f8:[0x63775E03,0x8DE350E4],f9:[0x7450FCE1,0xF102BFB4],fq:[0x84DD5236,0xDECD1DCC],fr:[0xE918CB1B,0x44D3B0D2],fs:[0x691419CE,0x840B1061],ft:[0x88B9E1D0,0xDCD9C318],g3:[0xFBC7FA19,0x3843C6C5],g4:[0x88B9E1D0,0xDCD9C318],g5:[0x2B6BA613,0x665EEFD8],g6:[0x1E0656F8,0xAEAB6F6D],g7:[0x4F4BE9C7,0xA70D31DD],g8:[0x8646D12C,0x1AB14EAF],g9:[0x729F9C77,0xD91580E8],ga:[0x8A1707F3,0x851E6016],gb:[0x34EF2810,0x4D322888],gc:[0x5EA04808,0x8CD9CC35],gd:[0xB1BF5CBE,0xA9EDAB2C],ge:[0x26FF5057,0x5E263A1B],gf:[0x9857A02D,0xDF29ACEE],gg:[0x5EA04808,0x8CD9CC35],gh:[0xB1BF5CBE,0xA9EDAB2C],gj:[0x82B879EF,0x5FC7577A],gk:[0x8551AE02,0x8BD64B08],gl:[0x6C05A0DF,0xD9CFCA36],gm:[0x65985834,0x30023D63],ha:[0x6FEA389F,0xE40485D7],ir:[0x1CBFDC59,0x272F94C9],is:[0xD71D5B55,0x4E29D4A0],it:[0x6E6D0BB3,0x4A0C21BE],iu:[0xE72E3799,0x1B64DB03],iv:[0x966AEEB1,0x440BCE28],iw:[0xABF64371,0xA4D69070],ix:[0xF024E85E,0x8A4FC5EE],k2:[0xBD441A09,0xD66E0B80],k4:[0xE7FC275E,0xEF53679F],kb:[0xD7A26C85,0x96C46632],kc:[0xFE4F6396,0x925E74AB],kd:[0x1CB48890,0xA752E664],ke:[0x9D484205,0xB4C94C6A],kk:[0xE7B621A1,0x1D7EB4FD],kl:[0xC24D2DC3,0xE0C940A0],km:[0x3CD20423,0xC73534EE],kn:[0x3E799AE3,0x98BDBEFD],ko:[0x3CD20423,0xC73534EE],kp:[0x3E799AE3,0x98BDBEFD],kq:[0x2F6C20CB,0xE0EEB757],kr:[0x3E71F4A2,0x8A8ADD26],kw:[0x9C24075F,0xFDA858E8],kx:[0x419F8C49,0x96A16105],ky:[0x6FC7AA98,0xAA58AF2B],kz:[0xAE0B2DC1,0xA3125B63],l4:[0x992B63EA,0x6EF6F082],l6:[0x5C38DA3D,0x7EBFEB48],lg:[0xAB2659E1,0x263855B3],lh:[0xB9FC0FE0,0xAE48D56A],lk:[0x9ECB6237,0xED6A0CCC],ll:[0x90855BBD,0xD04D8679],ls:[0x735913DF,0x52F4C212],lt:[0xF9511C7D,0x3FB1DB84],lw:[0xC5105EC2,0x10DDBD68],lx:[0xAD8CA52B,0xB91DA792],mm:[0xB545A260,0xD2B49B2C],mn:[0xFC9008A6,0xFABB3F84],mo:[0xB9AB42E4,0x39EB1248],mp:[0x3D71293E,0x2EE2D22F],mq:[0x5B932A3E,0x31793DB7],mr:[0x3BD45340,0x52EFC9D7],ms:[0xFBCE3B63,0xB9A5F04F],mt:[0xCF2B7AAD,0xA9A5C897],mu:[0x84EE2B7F,0xA6BF12EE],mv:[0xB44AF2D1,0x9422485C],n0:[0x350BFB84,0x61101EB3],n9:[0x6CE8B51E,0x489F7B62],nd:[0xCAF6CEFA,0x310C1D96],ne:[0x9A698454,0x241D08E6],nf:[0x5F2EBF4D,0x47467356],ng:[0x83B07276,0xBDA16723],nh:[0xFCBA0B97,0x6A96271B],ni:[0x9F680355,0x816E5EC2],nj:[0x5A95BACA,0xAA11F118],nk:[0x31272B9C,0xDCB7A6B9],nl:[0xB163BDC0,0x384F277F],nm:[0x538CD5B5,0x25BD98FB],nn:[0x4E650EB2,0x281777EA],no:[0x202AB601,0xA2B65045],np:[0x9026D40B,0x2105A0F0],nq:[0xDD504A53,0x1DC293FD],nr:[0x9C803F8F,0x6C1A614A],ns:[0x67588C7D,0xDC12D32A],nt:[0x98AF3C8E,0x2645D5F2],nu:[0xB6433A44,0xE8841031],nv:[0x67BDF21F,0xC1721038],nw:[0x947F4E7C,0x1436A96F],nx:[0xD72017C6,0xEE566772],ny:[0x609888A0,0x1BF6E8E0],nz:[0x9CA7B1E8,0x5210AC00],o0:[0x87789F98,0xFEDD2F22],o1:[0x258ACA5E,0xCB314AF2],o2:[0x1A54F2B2,0xF49EB15E],o3:[0xA2528317,0xF6DC270B],o4:[0xA0874331,0x2333FBB1],o5:[0xF76EA570,0x6B1E05D7],oa:[0xC629924A,0x99E096FD],ob:[0xE94C7BEC,0x50A2F290],oc:[0x5803428C,0x5A2BD6D7],oe:[0x778763D6,0x4E330A95],of:[0xB4D6E9A2,0x65842D64],og:[0xB76D1BFF,0x8806CF78],oh:[0xED0E3674,0x41734E44],oi:[0x1386DBF1,0xBD462500],oj:[0xAC53AB84,0xD635DD13],os:[0x8DCCB679,0x85F09CF3],ot:[0x2B1C097D,0xD87B5ED7],ou:[0xE89C7002,0xBCADCDC1],ov:[0x1ACA013E,0xB42D7515],ow:[0xE89C7002,0xBCADCDC1],ox:[0x1ACA013E,0xB42D7515],oy:[0x71AF995F,0x4FB4DE08],oz:[0x438A15BA,0x406F16E4],p0:[0x222BEBF8,0xA5C093E7],p1:[0x39A55C27,0x1579CBB2],p8:[0x603E7308,0x2F1B2C96],p9:[0x704E379F,0xB0B66FAA],pa:[0xD1927C91,0x407F15E5],pb:[0x8AEE48F5,0x55A1F946],pc:[0xD34883EB,0x26482E17],pd:[0xDEC7DD28,0x983F6BB3],pg:[0x7DCC403E,0x5527B527],ph:[0x524D94C2,0x91B9ED6F],pj:[0x1E22A1E7,0xF4BFD8A7],pk:[0x4E9FE8BD,0xC0859D7F],pl:[0x678F2E8A,0x44BCF946],pm:[0xA5FCF295,0x4E57399D],pn:[0x5BEB77DF,0xD992E86A],po:[0x3ED02C87,0x75042519],pw:[0xDED3A4D5,0x24CC5F35],px:[0x3F35155C,0x9D11DF9F],py:[0xC6727706,0xB7ED3DC3],pz:[0x3A0F2267,0xE9B8588E],q0:[0xAF057854,0xE3A42526],q1:[0x49CF5EDC,0x9B81363B],q2:[0xAF057854,0xE3A42526],q3:[0x49CF5EDC,0x9B81363B],q4:[0xD4481901,0xE0BD77C3],q5:[0x77B5B69F,0x96F64119],q6:[0xA04810EE,0x9C4E3A1B],q7:[0x4CD87F82,0x4EA01B07],q8:[0x3DEF5448,0xC94DA240],q9:[0xD6B195E3,0x20214E93],qc:[0x2D8DB3DF,0x4563E33A],qd:[0xACBFB075,0x137A83E4],qe:[0xA2BE0C7A,0x61B7FF68],qf:[0x255E716D,0x490090A9],ql:[0x51DBC026,0xFF8CE0D0],qm:[0xFAB6D9E4,0x661F30B4],qn:[0x51DBC026,0xFF8CE0D0],qo:[0xFAB6D9E4,0x661F30B4],qp:[0x46192E5B,0x5D92CF35],qq:[0x670600B5,0x8A7304AD],qr:[0x6C74CC79,0xCA33338C],qs:[0xFC2B8689,0xF81C85B3],qu:[0x689DFB7C,0x4A6292F8],qv:[0xA5EFE015,0xFA55361B],qw:[0xBE46B9CF,0xB46D7043],qx:[0xEADA0E20,0xD11C46E4],qy:[0x23F9BA79,0x765C9D86],qz:[0x8AAA1240,0xA701CF2B],r0:[0xF2E9367A,0x7C21D5A3],r3:[0x12E72210,0xA268DCE5],r4:[0x94DFAA0B,0x8EFEB895],r5:[0x12E72210,0xA268DCE5],r6:[0x94DFAA0B,0x8EFEB895],r7:[0x12E72210,0xA268DCE5],r8:[0x94DFAA0B,0x8EFEB895],ra:[0xF8315CA6,0x5A4857CF],rb:[0xD682628E,0x6857E1FD],rc:[0xF8315CA6,0x5A4857CF],rd:[0xD682628E,0x6857E1FD],re:[0xD45F2E2D,0x1F7B463A],rf:[0x4C6B359C,0x8D93BF5C],rg:[0x6FC7AA98,0xAA58AF2B],rh:[0xAE0B2DC1,0xA3125B63],rk:[0x1CB4F07C,0x8913F64F],rl:[0x9749A634,0xD889C02F],rn:[0xC57B8505,0x4780094A],ro:[0xD7B4BADE,0xD5D087BF],rp:[0x49E4FC74,0x557D9410],rq:[0x4DC589B2,0x8439DB31],rr:[0x213E9D5D,0xCC6E699B],rs:[0x12843F2B,0xF1F1C3D9],rt:[0xD7EBF2B5,0xB437BCCA],ru:[0x40F886FE,0x2ABFCA2A],rv:[0xF4B169C4,0xEDC485B9],rw:[0x2F1FFB74,0xD0BD3467],rx:[0x22C72D27,0xDEF622D5],ry:[0x450E597F,0x7A8695FE],rz:[0xC702CA17,0xE2D905EB],s0:[0x2F7FFD88,0xD4C656CC],s1:[0x6BAA740F,0x60A2B4B2],s2:[0xCC1D47CB,0x16061DB7],s3:[0xE8436121,0xE580A894],s4:[0x594BA3A1,0xA35B1B74],s7:[0x5B92E507,0x26FC850E],s8:[0xD55B751F,0x4709B9FA],s9:[0xBF9A0832,0x63EEFB94],sc:[0x26125A04,0x755D240F],sd:[0xCBC67250,0x7CBA7CC7],se:[0x68ECC1C8,0x970F216C],sf:[0x40454CE7,0x7885E9D3],sg:[0x494FE777,0xC8A3ECEB],sh:[0x40C43788,0xED82FD8B],si:[0xDA86E269,0x3497E660],sj:[0xC7C902BD,0x3D2671F0],sl:[0x9E64221D,0x6EB4D411],sm:[0x51B555C3,0x7ECDB9C6],sn:[0xB5EBAAD2,0x792006F3],so:[0xAD2B5191,0x4A9A99FC],sp:[0x6CECA998,0x2A4E2767],sq:[0x89907E71,0x448218B4],sr:[0x631A6A28,0x393BA6D6],ss:[0xF9ED71A0,0x3CB0FBF3],st:[0xBF9A0832,0x63EEFB94],su:[0xC937C52D,0xAF661CDB],sv:[0x4F1F93FF,0x86290DB4],sw:[0x724BF371,0x89181E48],sx:[0x9A965D43,0x80EBBF7C],sy:[0x8354514F,0x218C10E7],sz:[0x3BADF034,0x65D28BC1],t0:[0x1C8DBDC2,0x5C9158BB],t1:[0xFEAFBA80,0xD02E1231],t2:[0xBBF5B0BA,0x3EFD8C3A],t3:[0x14592D5A,0x5F6A6096],t4:[0x7D5AE167,0x152F18B0],t5:[0x721E9EBA,0xB73E424C],t6:[0x312B782B,0x301E6F61],t7:[0x721E9EBA,0xB73E424C],t8:[0x312B782B,0x301E6F61],t9:[0xC00AE934,0xCD480B3E],ta:[0xC937C52D,0xAF661CDB],tb:[0x72C55881,0x55EE9F57],tc:[0x27BA7242,0x466EE78C],td:[0x6920308F,0xE3585135],te:[0x6920308F,0xE3585135],tf:[0x6E74BC7D,0x73CF16F4],tg:[0x6920308F,0xE3585135],th:[0x6E74BC7D,0x73CF16F4],ti:[0x6920308F,0xE3585135],tj:[0x6E74BC7D,0x73CF16F4],tt:[0x234521F9,0x19390673],tu:[0xCB92D93C,0xE7E329BA],tv:[0x1248BB60,0x1047A3BE],tx:[0xF5733BC8,0x13047D82],ty:[0xF37A833F,0xCFA9905B],tz:[0x1DD2E3D6,0x2987A70B],u0:[0x6B118AE2,0xA96BA79F],u1:[0x5D74601A,0x6BA0AAB3],u2:[0xB29F73BD,0x3329D414],u3:[0x2B1C097D,0xD87B5ED7],u4:[0xB29F73BD,0x3329D414],u5:[0x2B1C097D,0xD87B5ED7],u6:[0x6267F913,0xF0D48D23],u7:[0xBABFCBB1,0xAFFE1ADF],u8:[0x14700F54,0x7A1D66EC],ua:[0xDC06627A,0xCC6E7424],ub:[0x491BD7EB,0xEB6BD417],uc:[0x96CC8B80,0xC05FACB2],uf:[0xFFA4332B,0xC3EDBB12],ug:[0x307B34BC,0x6B460778],uh:[0xF2425194,0xF8B29A09],ui:[0xCFDA25A9,0xD732D05D],uj:[0x519BE610,0x92E94656],uk:[0x4CF87EFA,0xBDBFFDD2],ul:[0x23AECB96,0x98103B6E],um:[0x984D34A6,0xA18CCCF5],un:[0x61C37A8D,0x4D076DAD],uo:[0xB5F8AFA4,0x973F599B],ux:[0x4736B6A4,0xB46E92C5],uy:[0x49B6C6C6,0xDF41C02C],v7:[0x79DAADF3,0x10AE3E01],v9:[0xB41A1EB9,0x3C3B74AC],va:[0x835EC53A,0xF5763A3E],vb:[0x7419C82E,0x8A927FB1],vc:[0x8B804BC1,0x69F6984A],vd:[0x5BAFBE7F,0x32112506],ve:[0x62AA30DC,0x26FED46D],vf:[0x4CB5E21C,0x4342A143],vg:[0x886010E4,0x44989C5D],vh:[0x3629AE24,0xD249FE78],vi:[0x1B862582,0xCC4724D3],vk:[0xA5B9064A,0x6B6F8384],vl:[0x184423C1,0x44A43E0B],vm:[0x7455122D,0x8B4776B9],vn:[0xFE8205A2,0x65BED48D],vo:[0x67B6C493,0xD8E6EE90],vp:[0xA93FF596,0xE51E2F3F],vy:[0x5A594B5A,0x13ED1925],vz:[0x95154274,0xF1BDEF09],wg:[0x83B72D88,0x60612E43],wi:[0x4EB0D804,0x9EB24ED1],wk:[0x4B9428BE,0x4D71A6D7],wm:[0x75CA64B5,0x1FB8E347],wo:[0x53F834EC,0x771E7F42],wq:[0x25905977,0xC4EFE8A4],z:[0x1003BE7A,0x79125ACE]};
/* Convenience: compute key for a given ECU wrapper name */
function alfaW6By(s,name){const p=AOBD_W6[name];return p?alfaW6(s,p[0],p[1]):0;}


const ALGOS=[{id:'gpec1',n:'GPEC1',h:'670269',fn:s=>sxor(s,670269)},{id:'gpec2',n:'GPEC2',h:'Continental',fn:s=>sxor(s,0xE72E3799)},{id:'gpec2f',n:'GPEC2 Flash',h:'Flash',fn:s=>sxor(s,0x966AEEB1)},{id:'gpec2e',n:'GPEC2 EPROM',h:'EPROM',fn:s=>sxor(s,0x3F711F5A)},{id:'gpec3',n:'GPEC3',h:'2018+',fn:s=>sxor(s,0x129D657F)},{id:'gpec2a',n:'GPEC2A',h:'GPEC2A',fn:s=>sxor(s,0xCE853A6F)},{id:'gpec15',n:'GPEC2 2015',h:'2015-18',fn:s=>sxor(s,0x47EC21F8)},{id:'cda6',n:'CDA6',h:'BCM/ABS/IPC',fn:s=>cda6(s)},{id:'ecm',n:'ECM sxor',h:'0x8A3C71',fn:s=>sxor(s,MC.ECM)},{id:'tcm',n:'TCM sxor',h:'0x6E4B92',fn:s=>sxor(s,MC.TCM)},{id:'rfhub',n:'RFHUB sxor',h:'0xD5F1',fn:s=>sxor(s,MC.RFHUB)},{id:'ngc',n:'NGC',h:'DAIMLERCHRYSLER',fn:s=>ngc(s)},{id:'jtec',n:'JTEC',h:'Fixed 0000',fn:()=>0},{id:'t80',n:'TIPM 0x80',h:'t8001',fn:s=>tipm(s,'a')},{id:'t36',n:'TIPM 0x36',h:'t3605',fn:s=>tipm(s,'b')},{id:'t81',n:'TIPM 0x81',h:'t8101',fn:s=>tipm(s,'c')},{id:'t3c',n:'TIPM 0x3C',h:'t3c',fn:s=>tipm(s,'d')},{id:'alfa_ht',n:'AlfaOBD HT',h:'Shuffle 0x41AA42BB',fn:s=>alfaHT(s)},{id:'alfa_f',n:'AlfaOBD XTEA-LE',h:'Grp 51 L5 XTEA',fn:s=>alfaF(s)},{id:'alfa_ao',n:'UConnect XTEA-BE',h:'UCONNECT/FGA_RADIO',fn:s=>alfaAO(s)},{id:'alfa_f27_l1',n:'AlfaOBD Fam27 L1',h:'tv: Fam 27 L1',fn:s=>alfaW6By(s,'tv')},{id:'alfa_f27_l3',n:'AlfaOBD Fam27 L3',h:'tu: Fam 27 L3',fn:s=>alfaW6By(s,'tu')},{id:'alfa_f66_l3',n:'AlfaOBD Fam66 L3',h:'ez: Fam 66 L3',fn:s=>alfaW6By(s,'ez')},{id:'alfa_f27_l5',n:'AlfaOBD Fam27 L5',h:'tt: Fam 27 L5',fn:s=>alfaW6By(s,'tt')}];
const MODS=[{c:'ECM',n:'Engine',tx:0x7E0,rx:0x7E8},{c:'TCM',n:'Transmission',tx:0x7E1,rx:0x7E9},{c:'BCM',n:'Body Control',tx:0x742,rx:0x762},{c:'RFHUB',n:'RF Hub',tx:0x75F,rx:0x767},{c:'ABS',n:'Brakes',tx:0x760,rx:0x768},{c:'IPC',n:'Cluster',tx:0x745,rx:0x765},{c:'RADIO',n:'Uconnect',tx:0x772,rx:0x77A},{c:'DAMP',n:'Damping',tx:0x7E4,rx:0x7EC},{c:'EPS',n:'Steering',tx:0x75F,rx:0x769},{c:'TIPM',n:'Power Module',tx:0x74C,rx:0x76C}];

/* ═══ VIN ═══ */
const TR={A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9};for(let d=0;d<=9;d++)TR[String(d)]=d;
const WT=[8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2];
const WMI={'1C4':'Chrysler US','2C3':'Dodge CA','1C6':'RAM US','2C4':'Chrysler CA','1J4':'Jeep US','1B3':'Dodge US','2B3':'Dodge CA','1J8':'Jeep US'};
const YR={A:2010,B:2011,C:2012,D:2013,E:2014,F:2015,G:2016,H:2017,J:2018,K:2019,L:2020,M:2021,N:2022,P:2023,R:2024,S:2025,T:2026};
function checkVin(v){if(!v||v.length!==17)return{ok:false};const u=v.toUpperCase();if(!/^[A-HJ-NPR-Z0-9]{17}$/.test(u))return{ok:false,err:'Invalid chars'};let sum=0;for(let i=0;i<17;i++)sum+=(TR[u[i]]||0)*WT[i];const cd='0123456789X'[sum%11];return{ok:u[8]===cd,cd,wmi:u.slice(0,3),mfr:WMI[u.slice(0,3)]||'',yr:YR[u[9]]||'',err:u[8]!==cd?'Check digit: need '+cd:''};}
const hxb=d=>Array.from(d).map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join(' ');
const TC={BCM:'#FF6D00','95640':'#AA00FF',RFHUB:'#2979FF',GPEC2A:'#00BFA5',FW:'#9E9E9E'};
const TL={BCM:'BCM D-FLASH','95640':'FCA 95640',RFHUB:'RFHUB EEE',GPEC2A:'GPEC2A',FW:'Firmware'};

/* ═══ File analysis ═══ */
function analyzeFile(buf,name){const data=new Uint8Array(buf);const sz=data.length;let type='unknown';
  if(sz===65536||sz===131072)type='BCM';else if(sz===8192||sz===16384)type='95640';else if(sz===4096){let a=true;for(let i=0;i<17&&i<sz;i++)if(data[i]<0x30||data[i]>0x5A){a=false;break;}type=a?'GPEC2A':'RFHUB';}else if(sz>131072)type='FW';
  const vins=[],partials=[];
  if(type==='RFHUB'){for(const off of[0xEA5,0xEB9,0xECD,0xEE1]){if(off+17>sz)continue;const st=data.slice(off,off+17);if(st.every(b=>b===0xFF||b===0))continue;const rev=new Uint8Array(17);for(let j=0;j<17;j++)rev[j]=st[16-j];let s='';for(let j=0;j<17;j++)s+=String.fromCharCode(rev[j]);vins.push({off,vin:s,algo:'rfhub',coff:off+17,ok:true,cv:checkVin(s),mirrored:true});break;}}
  else if(type==='GPEC2A'){for(const off of[0,0x1F0,0x224]){if(off+17>sz)continue;let s='',v=true;for(let j=0;j<17;j++){const b=data[off+j];if(b<0x20||b>0x7E){v=false;break;}s+=String.fromCharCode(b);}if(v&&/^[1-9A-HJ-NPR-Z]/.test(s))vins.push({off,vin:s,algo:'none',coff:-1,ok:true,cv:checkVin(s)});}}
  else if(type==='95640'){for(const off of[0x275,0x288]){if(off+17>sz)continue;let s='',v=true;for(let j=0;j<17;j++){const b=data[off+j];if(b<0x20||b>0x7E){v=false;break;}s+=String.fromCharCode(b);}if(!v||!/^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/.test(s))continue;const sc=data[off-1],cc=crc8a(data.slice(off,off+17));vins.push({off,vin:s,algo:'c8',coff:off-1,sc,cc,ok:sc===cc,cv:checkVin(s)});}}
  else if(type==='BCM'||type==='FW'){for(let i=0;i<=sz-19;i++){let v=true;for(let j=0;j<17;j++)if(data[i+j]<0x20||data[i+j]>0x7E){v=false;break;}if(!v)continue;let s='';for(let j=0;j<17;j++)s+=String.fromCharCode(data[i+j]);if(!/^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/.test(s))continue;const cv=checkVin(s);if(!cv.ok)continue;const sc=(data[i+17]<<8)|data[i+18],cc=crc16(data.slice(i,i+17));if(sc===cc){vins.push({off:i,vin:s,algo:'c16',coff:i+17,sc,cc,ok:true,cv});i+=16;}}
    if(vins.length>0){const tail=vins[0].vin.slice(9);const tc=[];for(let k=0;k<8;k++)tc.push(tail.charCodeAt(k));for(let i=0;i<=sz-10;i++){let m=true;for(let j=0;j<8;j++)if(data[i+j]!==tc[j]){m=false;break;}if(!m)continue;if(vins.some(fv=>i>=fv.off&&i<fv.off+17))continue;const sc=(data[i+8]<<8)|data[i+9],cc=crc16(data.slice(i,i+8));if(sc===cc)partials.push({off:i,vin:tail,algo:'c16',coff:i+8,sc,cc});}}}
  let sec=null;
  if(type==='BCM'){sec={t:'bcm'};const sb=data.slice(0x40C0,0x40E0);sec.b1=sb.every(b=>b===0xFF);if(!sec.b1){sec.immo=data.slice(0x40C8,0x40DA);sec.immoBak=data.slice(0x40F0,0x4102);sec.immoOk=true;for(let j=0;j<sec.immo.length;j++)if(sec.immo[j]!==sec.immoBak[j]){sec.immoOk=false;break;}}sec.b2=data.slice(0x2000,0x2020).every(b=>b===0xFF);if(!sec.b2)sec.bak=data.slice(0x2000,0x2020);}
  else if(type==='95640'){sec={t:'95640'};sec.key=data.slice(0x40,0x50);sec.kb=sec.key.every(b=>b===0xFF);sec.fob=data.slice(0x200,0x240);sec.fb=sec.fob.every(b=>b===0xFF);}
  else if(type==='RFHUB'){sec={t:'rfhub'};sec.key=data.slice(0x40,0x50);sec.kb=sec.key.every(b=>b===0xFF);}
  else if(type==='GPEC2A'){sec={t:'gpec2a'};sec.skim=data[0x11];sec.on=data[0x11]===0x80;sec.key=data.slice(0x203,0x20B);sec.mir=data.slice(0x361,0x369);sec.km=true;for(let j=0;j<8;j++)if(sec.key[j]!==sec.mir[j]){sec.km=false;break;}sec.tr=[];for(let i=0;i<4;i++)sec.tr.push(data.slice(0x888+i*4,0x888+i*4+4));sec.zz=data[0xC8C]===0x5A;}
  return{name,size:sz,type,data,vins,partials,sec};}

function patchFile(f,nv){const out=new Uint8Array(f.data);const vb=new TextEncoder().encode(nv.toUpperCase());const log=[];
  for(const s of f.vins){if(s.mirrored){const m=[...vb].reverse();for(let j=0;j<17;j++)out[s.off+j]=m[j];log.push('0x'+s.off.toString(16).toUpperCase()+' mirrored');}else{for(let j=0;j<17;j++)out[s.off+j]=vb[j];if(s.algo==='c16'){const c=crc16(vb);out[s.coff]=(c>>8)&0xFF;out[s.coff+1]=c&0xFF;log.push('0x'+s.off.toString(16).toUpperCase()+' CRC16');}else if(s.algo==='c8'){const c=crc8a(vb);out[s.coff]=c;log.push('0x'+s.off.toString(16).toUpperCase()+' CRC8');}else log.push('0x'+s.off.toString(16).toUpperCase());}}
  if(f.partials){const tb=new TextEncoder().encode(nv.toUpperCase().slice(9));for(const s of f.partials){for(let j=0;j<8;j++)out[s.off+j]=tb[j];const c=crc16(tb);out[s.coff]=(c>>8)&0xFF;out[s.coff+1]=c&0xFF;log.push('0x'+s.off.toString(16).toUpperCase()+' partial');}}
  return{data:out,log};}

function virginizeFile(f){const out=new Uint8Array(f.data);const log=[];
  if(f.type==='BCM'){f.vins.forEach(v=>{for(let j=0;j<19;j++)out[v.off+j]=0;});f.partials?.forEach(v=>{for(let j=0;j<10;j++)out[v.off+j]=0;});[0x2000,0x40C0].forEach(o=>{for(let i=0;i<32;i++)out[o+i]=0xFF;});log.push('VINs+CRC zeroed, SKIM cleared');}
  else if(f.type==='95640'){[0x275,0x288].forEach(o=>{for(let j=-1;j<17;j++)out[o+j]=0;});for(let i=0;i<16;i++)out[0x40+i]=0xFF;log.push('VINs+CRC+key cleared');}
  else if(f.type==='RFHUB'){[0xEA5,0xEB9,0xECD,0xEE1].forEach(o=>{for(let j=0;j<18;j++)out[o+j]=0;});for(let i=0;i<16;i++)out[0x40+i]=0xFF;for(let i=0;i<64;i++)out[0x200+i]=0xFF;log.push('VINs+key+fobs cleared');}
  else if(f.type==='GPEC2A'){[0,0x1F0,0x224].forEach(o=>{for(let j=0;j<17;j++)out[o+j]=0;});log.push('VINs cleared');}
  return{data:out,log};}

/* ═══ DESIGN ═══ */
const C={bg:'#F4F1EC',cd:'#FFF',c2:'#FAF9F7',sr:'#D32F2F',sl:'#FF5252',bk:'#1A1A1A',a1:'#FF6D00',a2:'#00BFA5',a3:'#2979FF',a4:'#AA00FF',tx:'#1A1A1A',ts:'#5A5A5A',tm:'#9E9E9E',bd:'#E8E4DE',gn:'#00C853',wn:'#FFB300',er:'#FF1744'};
function Card({children,style={},glow,onClick}){const[h,setH]=useState(false);return<div onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{background:C.cd,borderRadius:16,padding:22,border:`1.5px solid ${h&&onClick?C.sr:C.bd}`,boxShadow:h&&onClick?'0 8px 32px rgba(211,47,47,0.12)':'0 2px 16px rgba(0,0,0,0.06)',transition:'all 0.3s',transform:h&&onClick?'translateY(-2px)':'none',cursor:onClick?'pointer':'default',position:'relative',overflow:'hidden',...style}}>{glow&&<div style={{position:'absolute',top:-40,right:-40,width:120,height:120,borderRadius:'50%',background:'radial-gradient(circle,#FF525215,transparent 70%)',pointerEvents:'none'}}/>}<div style={{position:'relative',zIndex:1}}>{children}</div></div>;}
function Tag({children,color=C.sr}){return<span style={{fontSize:10,fontWeight:800,padding:'3px 10px',borderRadius:8,background:color+'14',color,letterSpacing:.5,display:'inline-block',marginLeft:4}}>{children}</span>;}
function Btn({children,onClick,disabled,color=C.sr,full,outline}){const[h,setH]=useState(false);return<button onClick={onClick} disabled={disabled} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{padding:'10px 20px',borderRadius:10,fontFamily:"'Nunito'",fontWeight:800,fontSize:12,border:outline?`2px solid ${color}33`:'none',cursor:disabled?'not-allowed':'pointer',background:disabled?'#E8E4DE':outline?(h?color+'10':'transparent'):(h?color:color+'DD'),color:disabled?C.tm:outline?color:'#fff',width:full?'100%':undefined,transition:'all 0.2s',letterSpacing:.5}}>{children}</button>;}
const TABS=[{id:'dumps',i:'📂',l:'DUMPS',s:'VIN · Hex · Virginize'},{id:'obd',i:'📡',l:'LIVE OBD',s:'UDS · Scan · Write'},{id:'seed',i:'🔑',l:'SEED→KEY',s:'14 Algorithms'},{id:'gpec',i:'🔓',l:'GPEC',s:'FW Unlock'},{id:'skim',i:'🛡️',l:'SECURITY',s:'Keys · SKIM'},{id:'gpec2a',i:'⚙️',l:'GPEC2A',s:'SKIM · Tamper'}];
function PH({icon,title,sub}){return<Card style={{textAlign:'center',padding:'60px 24px'}}><div style={{fontSize:48,marginBottom:12,opacity:.3}}>{icon}</div><div style={{fontSize:20,fontWeight:900,color:C.tm}}>{title}</div><div style={{fontSize:13,color:C.tm,marginTop:4}}>{sub}</div></Card>;}

/* ═══ APP ═══ */
export default function App(){const[pg,setPg]=useState('dumps');const[files,setFiles]=useState([]);
  const loadF=useCallback(fl=>{Promise.all(Array.from(fl).map(f=>new Promise(r=>{const rd=new FileReader();rd.onload=e=>r(analyzeFile(e.target.result,f.name));rd.readAsArrayBuffer(f);}))).then(res=>setFiles(p=>[...p,...res.filter(f=>f.type!=='unknown')]));},[]);
  return<div style={{minHeight:'100vh',background:C.bg,color:C.tx,fontFamily:"'Nunito',sans-serif"}}>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;600;700&family=Righteous&display=swap" rel="stylesheet"/>
    <div style={{background:'linear-gradient(135deg,#1A1A1A 0%,#2D2D2D 40%,#D32F2F 100%)',position:'relative',overflow:'hidden'}}>
      <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at 80% 50%,rgba(255,82,82,0.3),transparent 60%)',pointerEvents:'none'}}/>
      <div style={{position:'relative',padding:'22px 28px 0',display:'flex',alignItems:'center',gap:14}}>
        <div style={{width:46,height:46,borderRadius:13,background:'linear-gradient(135deg,#FF5252,#D32F2F)',display:'flex',alignItems:'center',justifyContent:'center',boxShadow:'0 4px 20px rgba(211,47,47,0.4)'}}><span style={{fontFamily:"'Righteous'",fontSize:22,color:'#fff'}}>S</span></div>
        <div><div style={{fontFamily:"'Righteous'",fontSize:26,color:'#fff',letterSpacing:2}}>SRT LAB</div><div style={{fontSize:9,color:'rgba(255,255,255,0.4)',fontWeight:700,letterSpacing:6}}>JAILBREAK EDITION</div></div>
      </div>
      <div style={{display:'flex',padding:'12px 16px 0',overflowX:'auto',gap:2}}>
        {TABS.map(t=>{const a=pg===t.id;return<button key={t.id} onClick={()=>setPg(t.id)} style={{padding:'11px 16px 13px',border:'none',cursor:'pointer',background:a?C.bg:'transparent',borderRadius:'11px 11px 0 0',color:a?C.sr:'rgba(255,255,255,0.4)',fontFamily:"'Nunito'",fontWeight:a?900:700,fontSize:11,letterSpacing:1.2,transition:'all 0.25s',boxShadow:a?'0 -4px 16px rgba(0,0,0,0.06)':'none',whiteSpace:'nowrap'}}><span style={{fontSize:14,marginRight:4,filter:a?'none':'grayscale(1) brightness(2)'}}>{t.i}</span>{t.l}<div style={{fontSize:7,marginTop:1,opacity:.4}}>{t.s}</div></button>;})}
      </div>
    </div>
    <div style={{maxWidth:1100,margin:'0 auto',padding:'22px 22px 60px'}}>
      {pg==='dumps'&&<DumpsTab files={files} setFiles={setFiles} loadF={loadF}/>}
      {pg==='obd'&&<OBDTab/>}
      {pg==='seed'&&<SeedTab/>}
      {pg==='gpec'&&<GpecTab/>}
      {pg==='skim'&&<SkimTab/>}
      {pg==='gpec2a'&&<Gpec2aTab/>}
    </div></div>;}

/* ═══ SECURITY MATCHER TAB (Piece 4) ═══ */
function extractVAt(d,o){if(o+17>d.length)return null;let s='';for(let i=0;i<17;i++){const b=d[o+i];if(b<0x20||b>0x7E)return null;s+=String.fromCharCode(b);}return/^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/.test(s)?s:null;}
function secAnalyze(data,fn){const sz=data.length;const m={fn,sz,type:'?',vins:[],skey:null,skoff:-1,skb:true,immo:null,immoBak:null,immoOk:true,immoBlank:true,bak:null,bakBlank:true,fobBlank:true,raw:data};
  if(sz===65536||sz===131072){m.type='bcm';
    for(let i=0;i<=sz-19;i++){const v=extractVAt(data,i);if(!v)continue;let sum=0;for(let j=0;j<17;j++)sum+=(TR[v[j]]||0)*WT[j];if('0123456789X'[sum%11]!==v[8])continue;const sc=(data[i+17]<<8)|data[i+18],cc=crc16(data.slice(i,i+17));if(sc===cc){m.vins.push({off:i,vin:v});i+=16;}}
    const sb=data.slice(0x40C0,0x40E0);if(!sb.every(b=>b===0xFF)){m.immoBlank=false;m.immo=data.slice(0x40C8,0x40DA);m.immoBak=data.slice(0x40F0,0x4102);m.immoOk=true;for(let j=0;j<m.immo.length;j++)if(m.immo[j]!==m.immoBak[j]){m.immoOk=false;break;}}
    m.bakBlank=data.slice(0x2000,0x2020).every(b=>b===0xFF);if(!m.bakBlank)m.bak=data.slice(0x2000,0x2020);
  }else if(sz===8192||sz===16384){m.type='95640';
    for(const o of[0x275,0x288]){const v=extractVAt(data,o);if(v)m.vins.push({off:o,vin:v});}
    m.skey=data.slice(0x40,0x50);m.skoff=0x40;m.skb=m.skey.every(b=>b===0xFF);m.fobBlank=data.slice(0x200,0x240).every(b=>b===0xFF);
  }else if(sz===4096){
    const v0=extractVAt(data,0);
    if(v0){m.type='gpec2a';m.vins.push({off:0,vin:v0});const v1=extractVAt(data,0x1F0);if(v1)m.vins.push({off:0x1F0,vin:v1});const v2=extractVAt(data,0x224);if(v2)m.vins.push({off:0x224,vin:v2});}
    else{m.type='rfhub';for(const o of[0xEA5,0xEB9,0xECD,0xEE1]){if(o+17>sz)continue;const st=data.slice(o,o+17);if(st.every(b=>b===0xFF||b===0))continue;const rev=new Uint8Array(17);for(let j=0;j<17;j++)rev[j]=st[16-j];m.vins.push({off:o,vin:String.fromCharCode(...rev),mir:true});break;}
      m.skey=data.slice(0x40,0x50);m.skoff=0x40;m.skb=m.skey.every(b=>b===0xFF);}
  }return m;}

const SKLBL={bcm:'BCM D-FLASH','95640':'FCA 95640',rfhub:'RFHUB EEE',gpec2a:'GPEC2A'};
const SKCOL={bcm:C.a1,'95640':C.a4,rfhub:C.a3,gpec2a:C.a2};
const SKIM_OFF=[{v:'Trackhawk',base:0x2000,ks:18,kc:6},{v:'SRT',base:0x40C0,ks:18,kc:6}];

function SkimTab(){
  const[mods,setMods]=useState([]);const[tv,setTv]=useState('');const[msg,setMsg]=useState('');
  const addF=useCallback(fl=>{Promise.all(Array.from(fl).map(f=>new Promise(r=>{const rd=new FileReader();rd.onload=e=>{const d=new Uint8Array(e.target.result);const m=secAnalyze(d,f.name);r(m.type!=='?'?m:null);};rd.readAsArrayBuffer(f);}))).then(res=>{const v=res.filter(Boolean);setMods(p=>{const u=[...p,...v];if(!tv&&u.length)for(const m of u)if(m.vins.length){setTv(m.vins[0].vin);break;}return u;});});},[tv]);
  const allV=useMemo(()=>{const s=new Set();mods.forEach(m=>m.vins.forEach(v=>s.add(v.vin)));return[...s];},[mods]);
  const vinBad=allV.length>1;
  const sks=useMemo(()=>mods.filter(m=>m.skey&&!m.skb).map(m=>({idx:mods.indexOf(m),type:m.type,key:m.skey,fn:m.fn})),[mods]);
  const skBad=useMemo(()=>{if(sks.length<2)return false;for(let i=1;i<sks.length;i++)for(let j=0;j<sks[0].key.length;j++)if(sks[0].key[j]!==sks[i].key[j])return true;return false;},[sks]);
  const skimG=useMemo(()=>{const bcm=mods.find(m=>m.type==='bcm');if(!bcm)return[];const r=[];for(const c of SKIM_OFF){if(c.base+c.ks*c.kc>bcm.sz)continue;const keys=[];let has=false;for(let i=0;i<c.kc;i++){const o=c.base+i*c.ks;const kb=bcm.raw.slice(o,o+c.ks);const hex=hxb(kb);if(!kb.every(b=>b===0xFF||b===0))has=true;keys.push({slot:i+1,off:o,hex,empty:kb.every(b=>b===0xFF||b===0)});}if(has)r.push({v:c.v,keys,base:c.base});}return r;},[mods]);
  const dl=(d,n)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([d]));a.download=n;a.click();};
  function syncKey(si,ti){const s=mods[si],t=mods[ti];if(!s.skey||s.skb||t.skoff<0)return;const p=new Uint8Array(t.raw);for(let i=0;i<16;i++)p[t.skoff+i]=s.skey[i];dl(p,t.fn.replace(/\./,'_KEYSYNCED.'));setMsg('Key from '+s.fn+' → '+t.fn);}
  function patchV(i){if(tv.length!==17)return;const m=mods[i];const p=new Uint8Array(m.raw);const vb=new TextEncoder().encode(tv);
    if(m.type==='bcm'){m.vins.forEach(v=>{for(let j=0;j<17;j++)p[v.off+j]=vb[j];const c=crc16(vb);p[v.off+17]=(c>>8)&0xFF;p[v.off+18]=c&0xFF;});}
    else if(m.type==='95640'){[0x275,0x288].forEach(o=>{if(o+17>p.length)return;for(let j=0;j<17;j++)p[o+j]=vb[j];p[o-1]=crc8a(vb);});}
    else if(m.type==='rfhub'){const mr=[...vb].reverse();[0xEA5,0xEB9,0xECD,0xEE1].forEach(o=>{if(o+18>p.length)return;for(let j=0;j<17;j++)p[o+j]=mr[j];});}
    else if(m.type==='gpec2a'){[0,0x1F0,0x224].forEach(o=>{if(o+17>p.length)return;for(let j=0;j<17;j++)p[o+j]=vb[j];});}
    dl(p,m.fn.replace(/\./,'_VIN_'+tv+'.'));setMsg('Patched '+SKLBL[m.type]+' → '+tv);}

  return<div>
    {/* Drop zone */}
    <div onClick={()=>{const i=document.createElement('input');i.type='file';i.multiple=true;i.accept='.bin,.BIN';i.onchange=e=>addF(e.target.files);i.click();}} onDrop={e=>{e.preventDefault();addF(e.dataTransfer.files);}} onDragOver={e=>e.preventDefault()}>
      <Card style={{textAlign:'center',padding:'24px',cursor:'pointer',border:'2px dashed '+C.sr+'25',marginBottom:16}} onClick={()=>{}}>
        <span style={{fontSize:32}}>🛡️</span>
        <div style={{fontSize:16,fontWeight:900,color:C.sr,marginTop:4}}>Drop Module Files for Security Matching</div>
        <div style={{fontSize:11,color:C.ts}}>BCM · 95640 · RFHUB EEE · GPEC2A — compare keys, sync, patch VINs</div>
        {mods.length>0&&<Tag color={C.a3}>{mods.length} loaded</Tag>}
      </Card>
    </div>
    {/* Target VIN + banners */}
    {mods.length>0&&<><Card style={{marginBottom:12,padding:14}}>
      <div style={{fontSize:10,fontWeight:800,color:C.sr,letterSpacing:2,marginBottom:6}}>TARGET VIN</div>
      <input value={tv} maxLength={17} placeholder="17-char target VIN" onChange={e=>setTv(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g,''))} style={{width:'100%',padding:'10px 14px',borderRadius:10,border:'2px solid '+C.bd,background:C.c2,fontFamily:"'JetBrains Mono'",fontSize:15,fontWeight:700,letterSpacing:3,textAlign:'center',outline:'none',boxSizing:'border-box',color:C.tx}} onFocus={e=>e.target.style.borderColor=C.sr} onBlur={e=>e.target.style.borderColor=C.bd}/>
      {vinBad&&tv.length===17&&<div style={{marginTop:8}}><Btn onClick={()=>mods.forEach((_,i)=>patchV(i))} full>⚡ Patch All Mismatched → {tv}</Btn></div>}
    </Card>
    <div style={{display:'flex',gap:6,marginBottom:12,flexWrap:'wrap'}}>
      <div style={{padding:'7px 12px',borderRadius:8,fontSize:11,fontWeight:800,background:vinBad?C.er+'10':C.gn+'10',color:vinBad?C.er:C.gn}}>{vinBad?'⚠ VIN MISMATCH — '+allV.length+' different':'✓ VINs Match'}</div>
      {sks.length>0&&<div style={{padding:'7px 12px',borderRadius:8,fontSize:11,fontWeight:800,background:skBad?C.er+'10':C.gn+'10',color:skBad?C.er:C.gn}}>{skBad?'⚠ KEY MISMATCH':'✓ Keys Match'}</div>}
    </div></>}
    {/* Module cards */}
    {mods.map((m,idx)=>{const vinOk=m.vins.length>0&&m.vins[0].vin===tv;return<Card key={idx} style={{marginBottom:12,borderColor:vinOk?C.gn+'50':m.vins.length&&tv.length===17?C.er+'40':C.bd}}>
      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:10}}>
        <Tag color={SKCOL[m.type]||C.tm}>{SKLBL[m.type]||m.type}</Tag>
        <span style={{flex:1,fontSize:12,fontWeight:700,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{m.fn}</span>
        <span style={{fontSize:10,color:C.tm}}>{(m.sz/1024).toFixed(0)}KB</span>
        <button onClick={()=>setMods(p=>p.filter((_,i)=>i!==idx))} style={{background:'none',border:'none',color:C.tm,cursor:'pointer',fontSize:14}}>✕</button>
      </div>
      {m.vins.length>0&&<div style={{padding:'8px 12px',borderRadius:8,marginBottom:8,background:vinOk?C.gn+'08':C.er+'06',border:'1px solid '+(vinOk?C.gn:C.er)+'20',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div><span style={{fontSize:10,color:C.tm}}>VIN: </span><span style={{fontFamily:"'JetBrains Mono'",fontSize:14,fontWeight:900,letterSpacing:2,color:vinOk?C.gn:C.er}}>{m.vins[0].vin}</span>{m.vins[0].mir&&<Tag color={C.a3}>MIRRORED</Tag>}</div>
        <span style={{fontSize:10,fontWeight:800,color:vinOk?C.gn:C.er}}>{vinOk?'✓ MATCH':'✗'}</span>
      </div>}
      {m.skey&&<div style={{padding:'8px 12px',borderRadius:8,marginBottom:8,background:C.c2,border:'1px solid '+C.bd}}>
        <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}><span style={{fontSize:10,fontWeight:700}}>Secret Key @0x{m.skoff.toString(16).toUpperCase()}</span><Tag color={m.skb?C.wn:C.gn}>{m.skb?'ERASED':'SET'}</Tag></div>
        <div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:m.skb?'#D5D0C8':C.a4,wordBreak:'break-all'}}>{hxb(m.skey)}</div>
        {m.skb&&sks.length>0&&<div style={{marginTop:6,display:'flex',gap:4,flexWrap:'wrap'}}>{sks.filter(s=>s.idx!==idx).map(s=><Btn key={s.idx} onClick={()=>syncKey(s.idx,idx)} color={C.a4} outline>Copy from {SKLBL[s.type]}</Btn>)}</div>}
      </div>}
      {m.type==='bcm'&&<div style={{padding:'8px 12px',borderRadius:8,marginBottom:8,background:C.c2,border:'1px solid '+C.bd}}>
        <div style={{fontSize:10,marginBottom:4}}>Immo @0x40C0: <Tag color={m.immoBlank?C.wn:C.gn}>{m.immoBlank?'BLANK':'SET'}</Tag>{!m.immoBlank&&<Tag color={m.immoOk?C.gn:C.er}>Backup {m.immoOk?'✓':'MISMATCH'}</Tag>}</div>
        {!m.immoBlank&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:9,color:C.a4,marginBottom:4}}>{hxb(m.immo)}</div>}
        <div style={{fontSize:10}}>Backup @0x2000: <Tag color={m.bakBlank?C.tm:C.gn}>{m.bakBlank?'BLANK':'SET'}</Tag></div>
      </div>}
      {m.type==='95640'&&<div style={{padding:'6px 12px',borderRadius:8,marginBottom:8,background:C.c2,border:'1px solid '+C.bd,fontSize:10}}>Fob Data: <Tag color={m.fobBlank?C.tm:C.gn}>{m.fobBlank?'NONE':'HAS FOBS'}</Tag></div>}
      {tv.length===17&&<Btn onClick={()=>patchV(idx)} full color={vinOk?C.gn:C.sr}>{vinOk?'↓ Download':'⚡ Patch → '+tv+' + Download'}</Btn>}
    </Card>;})}
    {/* SKIM grid */}
    {skimG.length>0&&<Card style={{marginTop:8}}><div style={{fontSize:14,fontWeight:800,marginBottom:10}}>🔐 SKIM Key Grid</div>
      {skimG.map((g,gi)=><div key={gi} style={{marginBottom:12}}><div style={{fontSize:12,fontWeight:800,color:C.a1,marginBottom:6}}>{g.v} — 0x{g.base.toString(16).toUpperCase()}</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6}}>{g.keys.map(k=><div key={k.slot} style={{padding:10,borderRadius:10,background:C.c2,border:'1px solid '+(k.empty?C.bd:C.gn+'40')}}>
          <div style={{display:'flex',justifyContent:'space-between'}}><span style={{fontSize:10,fontWeight:700,color:C.tm}}>KEY {k.slot}</span><Tag color={k.empty?C.tm:C.gn}>{k.empty?'—':'SET'}</Tag></div>
          <div style={{fontFamily:"'JetBrains Mono'",fontSize:8,color:k.empty?'#D5D0C8':C.ts,marginTop:4,wordBreak:'break-all'}}>{k.hex}</div>
        </div>)}</div></div>)}
      <Btn onClick={()=>{let t='SKIM KEYS\n';skimG.forEach(g=>{t+=g.v+' @0x'+g.base.toString(16).toUpperCase()+'\n';g.keys.forEach(k=>{t+='  Key '+k.slot+': '+(k.empty?'EMPTY':k.hex)+'\n';});});navigator.clipboard?.writeText(t);setMsg('Copied');}} color={C.a1} outline>📋 Copy Keys</Btn>
    </Card>}
    {msg&&<div style={{marginTop:10,padding:'8px 12px',borderRadius:8,background:C.gn+'10',border:'1px solid '+C.gn+'25',fontSize:11,fontWeight:700,color:C.gn}}>✓ {msg}</div>}
    {!mods.length&&<div style={{textAlign:'center',padding:30,color:C.tm,fontSize:12}}>Drop BCM, RFHUB, 95640, GPEC2A files above to compare security</div>}
  </div>;
}

/* ═══ GPEC2A TOOLS TAB (Piece 5) ═══ */
function Gpec2aTab(){
  const[f,setF]=useState(null);const[f2,setF2]=useState(null);const[msg,setMsg]=useState('');
  const load=(e,slot)=>{const fi=e.target.files[0];if(!fi)return;const r=new FileReader();r.onload=ev=>{const d=new Uint8Array(ev.target.result);if(d.length!==4096){setMsg('GPEC2A must be 4096 bytes');return;}const a=analyzeFile(d.buffer,fi.name);if(a.type!=='GPEC2A'){setMsg('Not a GPEC2A file');return;}if(slot===1)setF(a);else setF2(a);setMsg('');};r.readAsArrayBuffer(fi);};
  const dl=(d,n)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([d]));a.download=n;a.click();};

  function toggleSkim(){if(!f)return;const p=new Uint8Array(f.data);p[0x11]=p[0x11]===0x80?0x00:0x80;setF(analyzeFile(p.buffer,f.name));dl(p,'SKIM_'+(p[0x11]===0x80?'ENABLED':'DISABLED')+'_'+f.name);setMsg('SKIM toggled to 0x'+p[0x11].toString(16).toUpperCase());}

  // Hex diff
  const diff=useMemo(()=>{if(!f||!f2)return[];const r=[];for(let i=0;i<Math.min(f.data.length,f2.data.length);i++)if(f.data[i]!==f2.data[i])r.push({off:i,a:f.data[i],b:f2.data[i]});return r;},[f,f2]);

  return<div>
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:16}}>
      <label style={{cursor:'pointer'}}><Card style={{textAlign:'center',padding:18}} onClick={()=>{}}>
        <div style={{fontSize:28}}>📂</div><div style={{fontSize:12,fontWeight:800,color:C.ts,marginTop:4}}>Load GPEC2A File 1</div>
        {f&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.a2,marginTop:4}}>{f.name}</div>}
        <input type="file" hidden onChange={e=>load(e,1)} accept=".bin,.BIN"/>
      </Card></label>
      <label style={{cursor:'pointer'}}><Card style={{textAlign:'center',padding:18}} onClick={()=>{}}>
        <div style={{fontSize:28}}>📂</div><div style={{fontSize:12,fontWeight:800,color:C.ts,marginTop:4}}>Load File 2 (for diff)</div>
        {f2&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.a2,marginTop:4}}>{f2.name}</div>}
        <input type="file" hidden onChange={e=>load(e,2)} accept=".bin,.BIN"/>
      </Card></label>
    </div>

    {f&&f.sec?.t==='gpec2a'&&<>
      {/* SKIM byte */}
      <Card glow style={{marginBottom:14}}>
        <div style={{fontSize:16,fontWeight:900,marginBottom:12}}>⚙️ GPEC2A Analysis</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div style={{padding:14,borderRadius:12,background:C.c2,border:'1px solid '+C.bd}}>
            <div style={{fontSize:11,fontWeight:800,color:C.tm,marginBottom:6}}>SKIM BYTE @ 0x0011</div>
            <div style={{fontSize:28,fontWeight:900,color:f.sec.on?C.gn:C.wn,fontFamily:"'JetBrains Mono'"}}>{f.sec.on?'ENABLED':'DISABLED'}</div>
            <div style={{fontSize:10,color:C.tm}}>0x{f.sec.skim.toString(16).toUpperCase().padStart(2,'0')}</div>
            <div style={{marginTop:8}}><Btn onClick={toggleSkim} color={f.sec.on?C.wn:C.gn} outline>{f.sec.on?'Disable SKIM':'Enable SKIM'}</Btn></div>
          </div>
          <div style={{padding:14,borderRadius:12,background:C.c2,border:'1px solid '+C.bd}}>
            <div style={{fontSize:11,fontWeight:800,color:C.tm,marginBottom:6}}>ZZZZ TAMPER @ 0x0C8C</div>
            <div style={{fontSize:28,fontWeight:900,color:f.sec.zz?C.gn:C.er}}>{f.sec.zz?'INTACT':'TAMPERED'}</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:9,color:C.ts,marginTop:4}}>{hxb(f.data.slice(0xC8C,0xC94))}</div>
          </div>
        </div>
      </Card>

      {/* Secret key */}
      <Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>🔑 Secret Key</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div style={{padding:10,borderRadius:8,background:C.c2,border:'1px solid '+C.bd}}>
            <div style={{fontSize:10,color:C.tm,marginBottom:4}}>Primary @ 0x0203 (8B)</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:11,fontWeight:700,color:f.sec.key.every(b=>b===0xFF)?'#D5D0C8':C.a4}}>{hxb(f.sec.key)}</div>
          </div>
          <div style={{padding:10,borderRadius:8,background:C.c2,border:'1px solid '+C.bd}}>
            <div style={{fontSize:10,color:C.tm,marginBottom:4}}>Mirror @ 0x0361 (8B)</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:11,fontWeight:700,color:f.sec.mir.every(b=>b===0xFF)?'#D5D0C8':C.a4}}>{hxb(f.sec.mir)}</div>
          </div>
        </div>
        <div style={{marginTop:6,fontSize:10}}><Tag color={f.sec.km?C.gn:C.er}>{f.sec.km?'Primary = Mirror ✓':'MISMATCH'}</Tag></div>
      </Card>

      {/* Transponder keys */}
      <Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>🔐 Transponder Keys @ 0x0888</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:8}}>
          {f.sec.tr.map((t,i)=>{const blank=t.every(b=>b===0xFF||b===0);return<div key={i} style={{padding:10,borderRadius:8,background:C.c2,border:'1px solid '+(blank?C.bd:C.gn+'40'),textAlign:'center'}}>
            <div style={{fontSize:10,fontWeight:700,color:C.tm}}>KEY {i+1}</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:10,fontWeight:700,color:blank?'#D5D0C8':C.a4,marginTop:4}}>{hxb(t)}</div>
            <Tag color={blank?C.tm:C.gn}>{blank?'—':'SET'}</Tag>
          </div>;})}
        </div>
      </Card>

      {/* Runtime counters */}
      <Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>📊 Runtime Counters</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:8}}>
          {[{n:'Counter 1',o:0xE61},{n:'Counter 2',o:0xE69},{n:'Counter 3',o:0xE6D},{n:'Counter 4',o:0xE75}].map(c=>{
            const v=(f.data[c.o]<<24|f.data[c.o+1]<<16|f.data[c.o+2]<<8|f.data[c.o+3])>>>0;
            return<div key={c.o} style={{padding:10,borderRadius:8,background:C.c2,border:'1px solid '+C.bd,textAlign:'center'}}>
              <div style={{fontSize:9,color:C.tm}}>{c.n}</div>
              <div style={{fontFamily:"'JetBrains Mono'",fontSize:13,fontWeight:800,color:C.a1,marginTop:2}}>{v.toLocaleString()}</div>
              <div style={{fontSize:8,color:C.tm}}>0x{c.o.toString(16).toUpperCase()}</div>
            </div>;})}
        </div>
      </Card>

      {/* VINs */}
      <Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:8}}>VINs</div>
        {f.vins.map((v,i)=><div key={i} style={{fontFamily:"'JetBrains Mono'",fontSize:12,marginBottom:4}}>
          <span style={{color:C.tm}}>0x{v.off.toString(16).toUpperCase().padStart(4,'0')}: </span>
          <span style={{fontWeight:800,color:C.a1}}>{v.vin}</span>
        </div>)}
      </Card>
    </>}

    {/* Hex diff */}
    {f&&f2&&<Card style={{padding:16}}>
      <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>🔀 Hex Diff — {diff.length} byte{diff.length!==1?'s':''} different</div>
      {diff.length===0&&<div style={{fontSize:12,color:C.gn,fontWeight:700}}>✓ Files are identical</div>}
      {diff.length>0&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:10,background:C.c2,borderRadius:8,padding:10,maxHeight:260,overflow:'auto',border:'1px solid '+C.bd}}>
        <div style={{display:'grid',gridTemplateColumns:'70px 1fr 1fr',gap:4,marginBottom:4}}>
          <span style={{fontWeight:700,color:C.tm}}>Offset</span><span style={{fontWeight:700,color:C.a1}}>File 1</span><span style={{fontWeight:700,color:C.a3}}>File 2</span>
        </div>
        {diff.slice(0,200).map((d,i)=><div key={i} style={{display:'grid',gridTemplateColumns:'70px 1fr 1fr',gap:4}}>
          <span style={{color:C.tm}}>0x{d.off.toString(16).toUpperCase().padStart(4,'0')}</span>
          <span style={{color:C.a1,fontWeight:700}}>0x{d.a.toString(16).toUpperCase().padStart(2,'0')}</span>
          <span style={{color:C.a3,fontWeight:700}}>0x{d.b.toString(16).toUpperCase().padStart(2,'0')}</span>
        </div>)}
        {diff.length>200&&<div style={{color:C.tm,marginTop:4}}>...and {diff.length-200} more</div>}
      </div>}
    </Card>}

    {msg&&<div style={{marginTop:10,padding:'8px 12px',borderRadius:8,background:C.gn+'10',fontSize:11,fontWeight:700,color:C.gn}}>✓ {msg}</div>}
    {!f&&<div style={{textAlign:'center',padding:30,color:C.tm,fontSize:12}}>Load a GPEC2A 4KB .bin file above</div>}
  </div>;
}

/* ═══ SEED → KEY TAB ═══ */
function SeedTab(){
  const[al,setAl]=useState('gpec2');const[sh,setSh]=useState('');const[res,setRes]=useState(null);const[all,setAll]=useState(false);
  const calc=useCallback(()=>{
    const raw=sh.replace(/\s/g,'');const v=parseInt(raw,16);if(isNaN(v)||!raw)return;
    if(all){setRes({multi:true,results:ALGOS.map(a=>({n:a.n,h:a.h,k:a.fn(v).toString(16).toUpperCase().padStart(8,'0')})),seed:v.toString(16).toUpperCase().padStart(8,'0')});}
    else{const a=ALGOS.find(x=>x.id===al);if(!a)return;setRes({multi:false,n:a.n,seed:v.toString(16).toUpperCase().padStart(8,'0'),key:a.fn(v).toString(16).toUpperCase().padStart(8,'0')});}
  },[al,sh,all]);

  return<div style={{maxWidth:760}}>
    <Card glow>
      <div style={{fontSize:18,fontWeight:900,marginBottom:4}}>🔑 Seed → Key Calculator</div>
      <div style={{fontSize:12,color:C.ts,marginBottom:16}}>14 algorithms extracted from FCA security access routines</div>

      {/* Algorithm grid */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(130px,1fr))',gap:6,marginBottom:16}}>
        {ALGOS.map(a=><div key={a.id} onClick={()=>{setAl(a.id);setAll(false);}} style={{
          padding:'9px 11px',borderRadius:10,cursor:'pointer',transition:'all 0.2s',
          background:al===a.id&&!all?C.sr+'12':C.c2,border:`1.5px solid ${al===a.id&&!all?C.sr:C.bd}`}}>
          <div style={{fontSize:11,fontWeight:800,color:al===a.id&&!all?C.sr:C.tx}}>{a.n}</div>
          <div style={{fontSize:8,color:C.tm}}>{a.h}</div>
        </div>)}
        <div onClick={()=>setAll(true)} style={{padding:'9px 11px',borderRadius:10,cursor:'pointer',background:all?C.a4+'12':C.c2,border:`1.5px solid ${all?C.a4:C.bd}`}}>
          <div style={{fontSize:11,fontWeight:800,color:all?C.a4:C.tx}}>ALL</div>
          <div style={{fontSize:8,color:C.tm}}>Run all 14</div>
        </div>
      </div>

      {/* Seed input */}
      <div style={{fontSize:10,fontWeight:800,color:C.tm,marginBottom:6,letterSpacing:2}}>SEED (HEX)</div>
      <input value={sh} placeholder="e.g. A1B2C3D4" onChange={e=>setSh(e.target.value.toUpperCase().replace(/[^A-F0-9\s]/g,''))}
        style={{width:'100%',padding:'14px 16px',borderRadius:12,border:'2px solid '+C.bd,background:C.c2,color:C.tx,fontFamily:"'JetBrains Mono'",fontSize:20,fontWeight:700,letterSpacing:4,textAlign:'center',outline:'none',boxSizing:'border-box'}}
        onFocus={e=>e.target.style.borderColor=C.sr} onBlur={e=>e.target.style.borderColor=C.bd}
        onKeyDown={e=>{if(e.key==='Enter')calc();}}/>
      <div style={{marginTop:12}}><Btn onClick={calc} disabled={!sh.trim()} full>Calculate Key</Btn></div>

      {/* Result */}
      {res&&!res.multi&&<div style={{marginTop:20,padding:20,borderRadius:14,background:C.c2,border:'1.5px solid '+C.bd}}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 40px 1fr',gap:12,alignItems:'center'}}>
          <div><div style={{fontSize:9,color:C.tm,letterSpacing:2,marginBottom:6}}>SEED</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:26,fontWeight:800,color:C.a3}}>{res.seed}</div></div>
          <div style={{textAlign:'center',fontSize:20,color:C.tm}}>→</div>
          <div><div style={{fontSize:9,color:C.tm,letterSpacing:2,marginBottom:6}}>KEY</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:26,fontWeight:800,color:C.sr}}>{res.key}</div></div>
        </div>
        <div style={{marginTop:8,fontSize:11,color:C.tm}}>{res.n}</div>
      </div>}

      {res&&res.multi&&<div style={{marginTop:20}}>
        <div style={{fontSize:12,fontWeight:800,marginBottom:10}}>Seed: <span style={{fontFamily:"'JetBrains Mono'",color:C.a3}}>{res.seed}</span></div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
          {res.results.map((r,i)=><div key={i} style={{padding:'10px 12px',borderRadius:10,background:C.c2,border:'1px solid '+C.bd,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div><div style={{fontSize:11,fontWeight:800,color:C.tx}}>{r.n}</div><div style={{fontSize:8,color:C.tm}}>{r.h}</div></div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:14,fontWeight:800,color:C.sr}}>{r.k}</div>
          </div>)}
        </div>
      </div>}
    </Card>
  </div>;
}

/* ═══ GPEC UNLOCK TAB ═══ */
function GpecTab(){
  const[fw,setFw]=useState(null);const[res,setRes]=useState(null);
  const load=useCallback(e=>{
    const f=e.target.files[0];if(!f)return;
    const r=new FileReader();r.onload=ev=>{const d=new Uint8Array(ev.target.result);setFw({name:f.name,data:d,size:d.length});setRes(null);};r.readAsArrayBuffer(f);
  },[]);
  const unlock=useCallback(()=>{
    if(!fw)return;const d=new Uint8Array(fw.data);
    if(d.length<=0x2FFFC){setRes({ok:false,msg:'File too small — need at least 192KB'});return;}
    const cur=d[0x2FFFC];
    if(cur===0x96){setRes({ok:false,msg:'Already unlocked (0x2FFFC = 0x96)'});return;}
    d[0x2FFFC]=0x96;setRes({ok:true,msg:'Unlock flag set: 0x2FFFC changed from 0x'+cur.toString(16).toUpperCase()+' → 0x96',data:d});
  },[fw]);
  const dl=useCallback(()=>{
    if(!res?.data)return;const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([res.data]));a.download='UNLOCKED_'+fw.name;a.click();
  },[res,fw]);

  return<div style={{maxWidth:640}}>
    <Card glow>
      <div style={{fontSize:18,fontWeight:900,marginBottom:4}}>🔓 GPEC Firmware Unlock</div>
      <div style={{fontSize:12,color:C.ts,marginBottom:20}}>Sets byte at offset 0x2FFFC to 0x96 — cracked from .NET IL disassembly</div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <label style={{cursor:'pointer'}}>
          <div style={{padding:24,borderRadius:14,background:C.c2,border:'2px dashed '+C.bd,textAlign:'center',transition:'all 0.2s'}}>
            <div style={{fontSize:32}}>📂</div>
            <div style={{fontSize:12,fontWeight:800,color:C.ts,marginTop:6}}>Load Firmware</div>
            {fw&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.a3,marginTop:6}}>{fw.name} ({(fw.size/1024).toFixed(0)}KB)</div>}
          </div>
          <input type="file" hidden onChange={load} accept=".bin,.BIN"/>
        </label>
        <div onClick={fw?unlock:undefined} style={{padding:24,borderRadius:14,background:fw?C.sr+'08':C.c2,border:'2px solid '+(fw?C.sr+'30':C.bd),textAlign:'center',cursor:fw?'pointer':'default',opacity:fw?1:0.4,transition:'all 0.2s'}}>
          <div style={{fontSize:32}}>🔓</div>
          <div style={{fontSize:12,fontWeight:800,color:C.sr,marginTop:6}}>Unlock</div>
        </div>
      </div>

      {fw&&<div style={{marginTop:14,padding:'10px 14px',borderRadius:10,background:C.c2,border:'1px solid '+C.bd}}>
        <div style={{fontFamily:"'JetBrains Mono'",fontSize:11,color:C.ts}}>
          <span style={{color:C.tm}}>0x2FFFC = </span>
          <span style={{fontWeight:800,color:fw.data.length>0x2FFFC?(fw.data[0x2FFFC]===0x96?C.gn:C.a1):C.er}}>
            {fw.data.length>0x2FFFC?'0x'+fw.data[0x2FFFC].toString(16).toUpperCase():'N/A'}
          </span>
          {fw.data.length>0x2FFFC&&fw.data[0x2FFFC]===0x96&&<span style={{color:C.gn,marginLeft:8}}>✓ Already unlocked</span>}
        </div>
      </div>}

      {res&&<div style={{marginTop:14,padding:16,borderRadius:12,background:res.ok?C.gn+'10':C.wn+'10',border:'1px solid '+(res.ok?C.gn:C.wn)+'30'}}>
        <div style={{fontSize:13,fontWeight:800,color:res.ok?C.gn:C.wn}}>{res.ok?'✓ ':'⚠ '}{res.msg}</div>
        {res.ok&&<div style={{marginTop:10}}><Btn onClick={dl} color={C.gn}>💾 Download Unlocked Firmware</Btn></div>}
      </div>}
    </Card>
  </div>;
}

/* ═══ LIVE OBD TAB ═══ */
function OBDTab(){
  const[conn,setConn]=useState(false);const[found,setFound]=useState([]);const[nv,setNv]=useState('');
  const[busy,setBusy]=useState('');const[prog,setProg]=useState(0);const[log,setLog]=useState([]);
  const eng=useRef(null);
  const addLog=(m,l='info')=>setLog(p=>[...p,{m,l,t:new Date().toLocaleTimeString('en',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'})}]);

  const connect=useCallback(async()=>{
    try{
      if(!navigator.serial){addLog('Web Serial not available — use Chrome','error');return;}
      const port=await navigator.serial.requestPort();
      await port.open({baudRate:115200});
      const w=port.writable.getWriter();
      const dec=new TextDecoderStream();port.readable.pipeTo(dec.writable).catch(()=>{});
      const rd=dec.readable.getReader();let buf='';
      (async()=>{try{while(true){const{value,done}=await rd.read();if(done)break;if(value)buf+=value;}}catch(e){}})();
      const send=async(cmd,to=2000)=>{buf='';await w.write(new TextEncoder().encode(cmd+'\r'));addLog('TX > '+cmd,'tx');const s=Date.now();while(Date.now()-s<to){if(buf.includes('>')){const r=buf.replace(/>/g,'').trim();addLog('RX < '+r,'rx');return r;}await new Promise(r=>setTimeout(r,50));}return buf.trim();};
      await send('ATZ',3000);await new Promise(r=>setTimeout(r,500));
      addLog('Adapter: '+(await send('ATI')),'info');
      for(const c of['ATE0','ATL0','ATS1','ATH1','ATCAF1','ATCFC1','ATAL','ATSP6']){await send(c);await new Promise(r=>setTimeout(r,80));}
      eng.current={send,uds:async(tx,rx,data)=>{
        await send('ATSH'+tx.toString(16).toUpperCase().padStart(3,'0'));
        await send('ATCRA'+rx.toString(16).toUpperCase().padStart(3,'0'));
        const h=Array.from(data).map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join('');
        const r=await send(h,5000);
        if(!r||r.includes('NO DATA')||r.includes('ERROR'))return{ok:false};
        const ls=r.split(/\r?\n/).map(l=>l.trim()).filter(l=>/^[0-9A-F\s]+$/i.test(l));
        let all=[];ls.forEach(l=>{(l.replace(/\s/g,'').match(/.{2}/g)||[]).forEach(x=>all.push(parseInt(x,16)));});
        return{ok:true,d:new Uint8Array(all)};
      }};
      setConn(true);addLog('Ready — HS-CAN 500kbps','info');
    }catch(e){addLog('Connect failed: '+e.message,'error');}
  },[]);

  const scan=useCallback(async()=>{
    if(!eng.current)return;setBusy('Scanning...');setFound([]);
    for(const m of MODS){try{
      let r=await eng.current.uds(m.tx,m.rx,[0x22,0xF1,0x90]);
      // EPS may only respond to 0x6EF190
      if((!r.ok||!r.d||r.d.length<3)&&m.c==='EPS'){r=await eng.current.uds(m.tx,m.rx,[0x22,0x6E,0xF1,0x90]);}
      if(r.ok&&r.d?.length>3){const vc=Array.from(r.d).filter(b=>b>=0x20&&b<=0x7E);const vin=String.fromCharCode(...vc).slice(-17);
        if(vin.length>=10){setFound(p=>[...p,{...m,vin}]);addLog(m.c+': '+vin,'rx');}}
    }catch(e){}}
    setBusy('');addLog('Scan complete','info');
  },[]);

  // Per-module seed-key: CDA6 primary for body modules (proven on real BCMs), sxor for powertrain
  const MOD_KEY={ECM:s=>sxor(s,MC.ECM),TCM:s=>sxor(s,MC.TCM),BCM:s=>cda6(s),RFHUB:s=>cda6(s),ABS:s=>cda6(s),IPC:s=>cda6(s),EPS:s=>cda6(s),RADIO:s=>cda6(s),DAMP:s=>sxor(s,MC.DAMP),TIPM:s=>tipm(s,'a')};
  // Helper: request seed, compute key, send key — returns true if unlocked
  const trySingleKey=useCallback(async(tx,rx,keyFn,label)=>{
    const sr=await eng.current.uds(tx,rx,[0x27,0x01]);
    if(!sr.ok||!sr.d)return false;
    const sb=Array.from(sr.d).slice(-4);let sv=0;for(const b of sb)sv=(sv<<8)|b;sv=u32(sv);
    if(!sv)return true; // seed=0 means already unlocked
    const k=keyFn(sv);
    const kr=await eng.current.uds(tx,rx,[0x27,0x02,(k>>24)&0xFF,(k>>16)&0xFF,(k>>8)&0xFF,k&0xFF]);
    if(kr.ok){addLog(label+' unlocked','rx');return true;}
    return false;
  },[]);

  const tryUnlock=useCallback(async(tx,rx,modName)=>{
    await eng.current.uds(tx,rx,[0x10,0x03]);
    // 1. Try primary algorithm for this module (fresh seed request)
    const primaryFn=MOD_KEY[modName]||cda6;
    if(await trySingleKey(tx,rx,primaryFn,modName+' (primary)'))return true;
    // 2. CDA6 fallback if primary wasn't CDA6 (fresh seed request)
    if(primaryFn!==cda6){if(await trySingleKey(tx,rx,cda6,modName+' (CDA6)'))return true;}
    // 3. Try per-module sxor constants (fresh seed each attempt)
    const tried=new Set();
    for(const[name,c]of Object.entries(MC)){
      if(tried.has(c))continue;tried.add(c);
      if(await trySingleKey(tx,rx,s=>sxor(s,c),modName+' ('+name+' sxor 0x'+c.toString(16).toUpperCase()+')'))return true;}
    // 4. Try GPEC flash/eprom constants (fresh seed each attempt)
    for(const c of[0xE72E3799,0x129D657F,0xCE853A6F,0x47EC21F8,0x966AEEB1,0x3F711F5A]){
      if(await trySingleKey(tx,rx,s=>sxor(s,c),modName+' (sxor 0x'+c.toString(16).toUpperCase()+')'))return true;}
    // 5. NGC fallback for older modules (fresh seed request)
    if(await trySingleKey(tx,rx,ngc,modName+' (NGC)'))return true;
    addLog(modName+' unlock FAILED — no matching key','error');return false;
  },[trySingleKey]);

  const writeAll=useCallback(async()=>{
    if(!eng.current||nv.length!==17)return;setBusy('Writing...');setProg(0);
    const vb=[...new TextEncoder().encode(nv)];
    // All VIN DIDs to write per module
    const VIN_DIDS={default:[0xF190,0x7B90,0x7B88],BCM:[0xF190,0x7B90,0x7B88,0x6E2025],RFHUB:[0xF190,0x7B90,0x7B88,0x6E2027],EPS:[0xF190,0x6EF190]};
    for(let i=0;i<found.length;i++){const m=found[i];
      const unlocked=await tryUnlock(m.tx,m.rx,m.c);
      if(!unlocked){addLog(m.c+' skipped — could not unlock','error');setProg(Math.round(((i+1)/found.length)*100));continue;}
      const dids=VIN_DIDS[m.c]||VIN_DIDS.default;
      for(const did of dids){
        const didBytes=did>0xFFFF?[(did>>16)&0xFF,(did>>8)&0xFF,did&0xFF]:[(did>>8)&0xFF,did&0xFF];
        const r=await eng.current.uds(m.tx,m.rx,[0x2E,...didBytes,...vb]);
        addLog(m.c+' DID 0x'+did.toString(16).toUpperCase()+': '+(r.ok?'OK':'FAIL'),r.ok?'rx':'error');
      }
      await eng.current.uds(m.tx,m.rx,[0x11,0x01]);addLog(m.c+' reset sent','info');
      setProg(Math.round(((i+1)/found.length)*100));
    }setBusy('');addLog('All modules written','info');
  },[found,nv,tryUnlock]);

  const readProxi=useCallback(async()=>{
    if(!eng.current)return;setBusy('Reading proxi...');
    const r=await eng.current.uds(0x742,0x762,[0x22,0x20,0x23]);
    if(r.ok)addLog('BCM Proxi: '+hxb(r.d),'rx');else addLog('Proxi read failed','error');
    setBusy('');
  },[]);

  const readSkim=useCallback(async()=>{
    if(!eng.current)return;setBusy('Reading SKIM...');
    const r=await eng.current.uds(0x742,0x762,[0x22,0x6E,0x9E,0xB0]);
    if(r.ok){const v=r.d?.length>0?r.d[r.d.length-1]:null;addLog('SKIM State: '+(v===0x80?'ENABLED':'DISABLED')+' (0x'+(v?.toString(16).toUpperCase()||'??')+')','rx');}
    else addLog('SKIM read failed','error');setBusy('');
  },[]);

  const virginRfhub=useCallback(async()=>{
    if(!eng.current)return;setBusy('Virginizing RFHUB...');
    const unlocked=await tryUnlock(0x75F,0x767,'RFHUB');
    if(!unlocked){addLog('RFHUB unlock failed — cannot virginize','error');setBusy('');return;}
    const blank=new Array(17).fill(0x00);
    for(const did of[0xF190,0x7B90,0x7B88,0x6E2027]){
      const didBytes=did>0xFFFF?[(did>>16)&0xFF,(did>>8)&0xFF,did&0xFF]:[(did>>8)&0xFF,did&0xFF];
      const r=await eng.current.uds(0x75F,0x767,[0x2E,...didBytes,...blank]);
      addLog('RFHUB DID 0x'+did.toString(16).toUpperCase()+': '+(r.ok?'blanked':'FAIL'),r.ok?'rx':'error');
    }
    await eng.current.uds(0x75F,0x767,[0x11,0x01]);
    addLog('RFHUB virginized over OBD','rx');setBusy('');
  },[tryUnlock]);

  return<div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:16}}>
    <div>
      {/* Connect */}
      <Card glow style={{marginBottom:14}}>
        <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
          <Btn onClick={connect} disabled={conn} color={conn?C.gn:C.a3} full>{conn?'✓ Connected to OBDLink':'🔌 Connect OBDLink EX'}</Btn>
          {conn&&<Btn onClick={scan} disabled={!!busy} color={C.a1}>{busy||'📡 Scan Modules'}</Btn>}
        </div>
      </Card>

      {/* Found modules */}
      {found.length>0&&<Card glow style={{marginBottom:14}}>
        <div style={{fontSize:14,fontWeight:800,marginBottom:12}}>Modules on Bus ({found.length})</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
          {found.map((m,i)=><div key={i} style={{padding:12,borderRadius:10,background:C.c2,border:'1px solid '+C.bd}}>
            <div style={{fontSize:13,fontWeight:800,color:C.sr}}>{m.c}</div>
            <div style={{fontSize:9,color:C.ts}}>{m.n} · TX 0x{m.tx.toString(16).toUpperCase()}</div>
            <div style={{fontFamily:"'JetBrains Mono'",fontSize:11,color:C.a1,fontWeight:700,marginTop:4}}>{m.vin}</div>
          </div>)}
        </div>
      </Card>}

      {/* Write VIN */}
      {conn&&<Card glow style={{marginBottom:14}}>
        <div style={{fontSize:14,fontWeight:800,marginBottom:10}}>Write VIN to All Modules</div>
        <input value={nv} maxLength={17} placeholder="Enter 17-character VIN" onChange={e=>setNv(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g,''))}
          style={{width:'100%',padding:'12px 16px',borderRadius:12,border:'2px solid '+C.bd,background:C.c2,color:C.tx,fontFamily:"'JetBrains Mono'",fontSize:16,fontWeight:700,letterSpacing:3,textAlign:'center',outline:'none',boxSizing:'border-box'}}
          onFocus={e=>e.target.style.borderColor=C.sr} onBlur={e=>e.target.style.borderColor=C.bd}/>
        <div style={{display:'flex',justifyContent:'space-between',marginTop:10,alignItems:'center'}}>
          <span style={{fontFamily:"'JetBrains Mono'",fontSize:12,fontWeight:800,color:nv.length===17?C.sr:C.tm}}>{nv.length}/17</span>
          <Btn onClick={writeAll} disabled={nv.length!==17||!found.length||!!busy}>{busy||'⚡ Write to '+found.length+' modules'}</Btn>
        </div>
        {prog>0&&prog<100&&<div style={{marginTop:10,height:5,borderRadius:3,background:C.bd,overflow:'hidden'}}><div style={{height:'100%',width:prog+'%',background:'linear-gradient(90deg,#D32F2F,#FF5252)',borderRadius:3,transition:'width 0.4s'}}/></div>}
      </Card>}

      {/* Quick tools */}
      {conn&&<Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>Quick Tools</div>
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
          <Btn onClick={readProxi} disabled={!!busy} color={C.a3} outline>📋 Read BCM Proxi</Btn>
          <Btn onClick={readSkim} disabled={!!busy} color={C.a2} outline>🛡️ Read SKIM State</Btn>
          <Btn onClick={virginRfhub} disabled={!!busy} color={C.er} outline>💀 Virginize RFHUB</Btn>
        </div>
        <div style={{marginTop:10,fontSize:10,color:C.ts}}>
          <div><b>DIDs:</b> 0xF190 VIN · 0x7B90 Current · 0x7B88 Original · 0x2023 Proxi · 0x6E9EB0 SKIM</div>
          <div><b>Security:</b> Extended session (10 03) → Seed (27 01) → CDA6 key → Send (27 02) → Write (2E) → Reset (11 01)</div>
        </div>
      </Card>}
    </div>

    {/* UDS log panel */}
    <div style={{background:C.cd,borderRadius:14,padding:14,border:'1px solid '+C.bd,maxHeight:600,overflow:'auto',boxShadow:'0 2px 12px rgba(0,0,0,0.04)'}}>
      <div style={{fontSize:10,fontWeight:800,color:C.tm,marginBottom:8,letterSpacing:2}}>UDS TRAFFIC LOG</div>
      {log.map((e,i)=><div key={i} style={{fontSize:9,fontFamily:"'JetBrains Mono'",padding:'2px 0',color:e.l==='error'?C.er:e.l==='tx'?C.a3:e.l==='rx'?C.sr:C.ts}}>
        <span style={{color:C.tm,marginRight:4}}>{e.t}</span>{e.m}
      </div>)}
      {!log.length&&<div style={{fontSize:11,color:C.tm,textAlign:'center',padding:30}}>Connect to see traffic</div>}
    </div>
  </div>;
}

/* ═══ DUMPS TAB ═══ */
function DumpsTab({files,setFiles,loadF}){
  const[sel,setSel]=useState(null);const[nv,setNv]=useState('');const[msg,setMsg]=useState('');
  const f=sel!==null?files[sel]:null;const cv=useMemo(()=>nv.length===17?checkVin(nv):null,[nv]);
  const dl=(d,n)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([d]));a.download=n;a.click();};
  const doPatch=()=>{if(!f||nv.length!==17)return;const r=patchFile(f,nv);dl(r.data,'PATCHED_'+nv+'_'+f.name);const u=[...files];u[sel]=analyzeFile(r.data.buffer,f.name);setFiles(u);setMsg('Patched '+r.log.length+' locations');};
  const doVirgin=()=>{if(!f)return;const r=virginizeFile(f);dl(r.data,'VIRGIN_'+f.name);setMsg('Virginized: '+r.log.join(', '));};

  if(!files.length)return<div onClick={()=>{const i=document.createElement('input');i.type='file';i.multiple=true;i.accept='.bin,.BIN';i.onchange=e=>loadF(e.target.files);i.click();}} onDrop={e=>{e.preventDefault();loadF(e.dataTransfer.files);}} onDragOver={e=>e.preventDefault()}>
    <Card style={{textAlign:'center',padding:'60px 24px',cursor:'pointer',border:'2.5px dashed #D32F2F30'}} onClick={()=>{}}>
      <div style={{fontSize:52,marginBottom:10}}>📂</div>
      <div style={{fontSize:20,fontWeight:900,color:C.sr}}>Drop EEPROM or Firmware Files</div>
      <div style={{fontSize:13,color:C.ts,marginTop:6}}>Auto-detects BCM · 95640 · RFHUB EEE · GPEC2A</div>
      <div style={{display:'flex',gap:8,justifyContent:'center',marginTop:18,flexWrap:'wrap'}}>
        {[['BCM D-FLASH',C.a1],['95640',C.a4],['RFHUB EEE',C.a3],['GPEC2A',C.a2]].map(([l,c])=><Tag key={l} color={c}>{l}</Tag>)}
      </div>
    </Card></div>;

  return<div style={{display:'grid',gridTemplateColumns:'260px 1fr',gap:18,alignItems:'start'}}>
    <div>
      <Btn onClick={()=>{const i=document.createElement('input');i.type='file';i.multiple=true;i.accept='.bin,.BIN';i.onchange=e=>loadF(e.target.files);i.click();}} full>+ Add Files</Btn>
      <div style={{marginTop:10,display:'flex',flexDirection:'column',gap:7}}>
        {files.map((fi,i)=><Card key={i} onClick={()=>{setSel(i);setMsg('');}} style={{padding:13,borderColor:sel===i?C.sr:C.bd}}>
          <div style={{fontSize:12,fontWeight:800,color:sel===i?C.sr:C.tx,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{fi.name}</div>
          <div style={{display:'flex',gap:4,marginTop:5,alignItems:'center',flexWrap:'wrap'}}><Tag color={TC[fi.type]||C.tm}>{TL[fi.type]||fi.type}</Tag><span style={{fontSize:10,color:C.tm}}>{(fi.size/1024).toFixed(0)}KB</span><span style={{fontSize:10,color:C.tm}}>{fi.vins.length}V{fi.partials?.length>0?'+'+fi.partials.length+'p':''}</span></div>
          {fi.vins[0]&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:11,color:C.a1,fontWeight:700,marginTop:5}}>{fi.vins[0].vin}</div>}
        </Card>)}
      </div>
      {files.length>=2&&<Card style={{marginTop:10,padding:12}}><div style={{fontSize:10,fontWeight:800,color:C.a1,marginBottom:4,letterSpacing:1}}>CROSS-MATCH</div>
        {(()=>{const vs={};files.forEach(fi=>fi.vins.forEach(v=>{vs[v.vin]=(vs[v.vin]||0)+1;}));return Object.entries(vs).map(([vin,ct])=><div key={vin} style={{fontSize:10,fontFamily:"'JetBrains Mono'"}}><span style={{color:ct===files.length?C.gn:C.wn}}>{vin}</span><span style={{color:C.tm,marginLeft:4}}>{ct}/{files.length}{ct===files.length?' ✓':''}</span></div>);})()}
      </Card>}
    </div>
    {f&&<div>
      {/* PATCH */}
      <Card glow style={{marginBottom:14}}>
        <div style={{fontSize:16,fontWeight:900,marginBottom:14}}>⚡ PATCH VIN</div>
        <input value={nv} maxLength={17} placeholder="Enter new 17-character VIN" onChange={e=>setNv(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g,''))} style={{width:'100%',padding:'12px 16px',borderRadius:12,border:'2px solid '+C.bd,background:C.c2,color:C.tx,fontFamily:"'JetBrains Mono'",fontSize:16,fontWeight:700,letterSpacing:3,textAlign:'center',outline:'none',boxSizing:'border-box'}} onFocus={e=>e.target.style.borderColor=C.sr} onBlur={e=>e.target.style.borderColor=C.bd}/>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:8,flexWrap:'wrap',gap:4}}>
          <span style={{fontFamily:"'JetBrains Mono'",fontSize:12,fontWeight:800,color:nv.length===17?C.gn:C.tm}}>{nv.length}/17</span>
          {cv&&<div style={{display:'flex',gap:4,alignItems:'center',flexWrap:'wrap'}}>
            {cv.ok?<Tag color={C.gn}>✓ Valid</Tag>:<Tag color={C.er}>{cv.err||'Invalid'}</Tag>}
            {cv.mfr&&<Tag color={C.a3}>{cv.mfr}</Tag>}
            {cv.yr&&<Tag color={C.a2}>{cv.yr}</Tag>}
          </div>}
        </div>
        <div style={{display:'flex',gap:8,marginTop:14,flexWrap:'wrap'}}>
          <Btn onClick={doPatch} disabled={nv.length!==17} full>⚡ Patch VIN + Download</Btn>
        </div>
        <div style={{display:'flex',gap:8,marginTop:8}}>
          <Btn onClick={doVirgin} color={C.er} outline>💀 Virginize</Btn>
          <Btn onClick={()=>dl(f.data,f.name)} color={C.a3} outline>💾 Download</Btn>
        </div>
        {msg&&<div style={{marginTop:10,padding:'9px 12px',borderRadius:10,background:C.gn+'10',border:'1px solid '+C.gn+'25',fontSize:11,color:C.gn,fontWeight:700}}>✓ {msg}</div>}
      </Card>
      {/* VIN LIST */}
      <Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>VIN Locations ({f.vins.length} full{f.partials?.length>0?', '+f.partials.length+' partial':''})</div>
        {f.vins.map((v,i)=><div key={i} style={{padding:'8px 10px',borderRadius:8,marginBottom:4,background:C.c2,border:'1px solid '+C.bd,display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:4}}>
          <div><span style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.tm}}>0x{v.off.toString(16).toUpperCase()} </span><span style={{fontFamily:"'JetBrains Mono'",fontSize:12,fontWeight:800,color:C.a1}}>{v.vin}</span>{v.mirrored&&<Tag color={C.a3}>MIRRORED</Tag>}</div>
          <div>{v.algo==='c16'&&<Tag color={C.gn}>CRC16 ✓</Tag>}{v.algo==='c8'&&<Tag color={v.ok?C.gn:C.wn}>CRC8 {v.ok?'✓':'!'}</Tag>}{v.algo==='rfhub'&&<Tag color={C.a3}>Boot CRC</Tag>}{v.algo==='none'&&<Tag color={C.a2}>No CRC</Tag>}</div>
        </div>)}
        {f.partials?.map((v,i)=><div key={'p'+i} style={{padding:'6px 10px',borderRadius:8,marginBottom:4,background:'#FFF8E1',border:'1px solid #FFE082',fontSize:11}}>
          <span style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.tm}}>0x{v.off.toString(16).toUpperCase()} </span><span style={{fontFamily:"'JetBrains Mono'",fontWeight:700,color:C.a1}}>...{v.vin}</span><Tag color={C.wn}>PARTIAL</Tag>
        </div>)}
      </Card>
      {/* SECURITY */}
      {f.sec&&<Card style={{marginBottom:14,padding:16}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>🔐 Security</div>
        {f.sec.t==='bcm'&&<><div style={{fontSize:11,marginBottom:6}}>Immo @0x40C0: <Tag color={f.sec.b1?C.wn:C.gn}>{f.sec.b1?'BLANK':'SET'}</Tag>{!f.sec.b1&&<Tag color={f.sec.immoOk?C.gn:C.er}>Backup {f.sec.immoOk?'✓':'MISMATCH'}</Tag>}</div><div style={{fontSize:11}}>Backup @0x2000: <Tag color={f.sec.b2?C.tm:C.gn}>{f.sec.b2?'BLANK':'SET'}</Tag></div></>}
        {f.sec.t==='95640'&&<><div style={{fontSize:11,marginBottom:4}}>Secret Key @0x40: <Tag color={f.sec.kb?C.wn:C.gn}>{f.sec.kb?'ERASED':'SET'}</Tag></div>{!f.sec.kb&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.a4,marginBottom:4}}>{hxb(f.sec.key)}</div>}<div style={{fontSize:11}}>Fob Data: <Tag color={f.sec.fb?C.tm:C.gn}>{f.sec.fb?'NONE':'HAS FOBS'}</Tag></div></>}
        {f.sec.t==='rfhub'&&<><div style={{fontSize:11,marginBottom:4}}>Secret Key @0x40: <Tag color={f.sec.kb?C.wn:C.gn}>{f.sec.kb?'ERASED':'SET'}</Tag></div>{!f.sec.kb&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.a4}}>{hxb(f.sec.key)}</div>}</>}
        {f.sec.t==='gpec2a'&&<><div style={{fontSize:11,marginBottom:4}}>SKIM: <Tag color={f.sec.on?C.gn:C.wn}>{f.sec.on?'ENABLED 0x80':'OFF 0x'+f.sec.skim.toString(16).toUpperCase()}</Tag></div><div style={{fontSize:11,marginBottom:4}}>Secret Key: {!f.sec.key.every(b=>b===0xFF)?<><span style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:C.a4}}>{hxb(f.sec.key)}</span><Tag color={f.sec.km?C.gn:C.er}>{f.sec.km?'Mirror ✓':'MISMATCH'}</Tag></>:<Tag color={C.wn}>BLANK</Tag>}</div><div style={{fontSize:11}}>ZZZZ Tamper: <Tag color={f.sec.zz?C.gn:C.er}>{f.sec.zz?'INTACT':'TAMPERED'}</Tag></div></>}
      </Card>}
      {/* HEX */}
      <Card style={{padding:14}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:8}}>Hex Viewer</div>
        <div style={{fontFamily:"'JetBrains Mono'",fontSize:10,background:C.c2,borderRadius:10,padding:10,maxHeight:320,overflow:'auto',border:'1px solid '+C.bd}}>
          {Array.from({length:Math.min(32,Math.ceil(f.size/16))},(_,row)=>{const a=row*16;const bs=f.data.slice(a,Math.min(a+16,f.size));const iv=f.vins.some(v=>a+16>v.off&&a<v.off+17);return<div key={row} style={{display:'flex',gap:8,padding:'1px 4px',background:iv?'#D32F2F06':'transparent',borderRadius:3}}>
            <span style={{color:C.tm,minWidth:48,fontWeight:600}}>{a.toString(16).toUpperCase().padStart(6,'0')}</span>
            <span style={{flex:1}}>{Array.from(bs).map((b,j)=>{const isV=f.vins.some(v=>(a+j)>=v.off&&(a+j)<v.off+17);return<span key={j} style={{color:isV?C.sr:b===0xFF?'#D5D0C8':b===0?'#C8C3BB':C.ts,fontWeight:isV?800:400}}>{b.toString(16).toUpperCase().padStart(2,'0')} </span>;})}</span>
            <span style={{color:C.tm,minWidth:90,fontSize:9}}>{Array.from(bs).map(b=>b>=32&&b<=126?String.fromCharCode(b):'·').join('')}</span>
          </div>;})}
        </div>
      </Card>
    </div>}
  </div>;
}
