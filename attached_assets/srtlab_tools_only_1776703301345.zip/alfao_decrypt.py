"""
AlfaOBD database decryption tool.

alfao_bd.db is encrypted with a fixed 4096-byte XOR keystream applied per SQLite page.
This tool decrypts the database using the keystream derived from known SQLite
structural plaintext (file header, zero-filled regions, B-tree page structure).

USAGE:
    # Decrypt your licensed copy of alfao_bd.db
    python alfao_decrypt.py alfao_bd.db decrypted.db
    
    # Extract all readable text (works even if SQLite can't open — useful as a fallback)
    python alfao_decrypt.py alfao_bd.db --extract-text output.txt

NOTES:
    - Decryption is ~99.5% complete. The SQLite header and all data pages decrypt 
      correctly, but a few bytes in the interior B-tree page indices may still be 
      corrupted, preventing a clean sqlite3 open.
    - Text extraction works well regardless — you can grep the output for ECU names,
      CAN IDs, table definitions, parameter names, etc.
    - Place alfao_keystream.bin in the same directory as this script.
"""
import sys
import os
import argparse

PAGE_SIZE = 4096


def load_keystream():
    here = os.path.dirname(os.path.abspath(__file__))
    ks_path = os.path.join(here, 'alfao_keystream.bin')
    if not os.path.isfile(ks_path):
        raise FileNotFoundError(f'alfao_keystream.bin not found at {ks_path}')
    with open(ks_path, 'rb') as f:
        ks = f.read()
    if len(ks) != PAGE_SIZE:
        raise ValueError(f'keystream wrong size: {len(ks)} (expected {PAGE_SIZE})')
    return ks


def decrypt(input_path, output_path):
    keystream = load_keystream()
    with open(input_path, 'rb') as f:
        data = f.read()
    if len(data) % PAGE_SIZE != 0:
        print(f'Warning: input size {len(data)} is not a multiple of {PAGE_SIZE}')
    
    with open(output_path, 'wb') as f:
        for p in range(0, len(data), PAGE_SIZE):
            page = bytes(data[p+i] ^ keystream[i] for i in range(min(PAGE_SIZE, len(data) - p)))
            f.write(page)
    print(f'Decrypted {len(data):,} bytes to {output_path}')


def extract_text(input_path, output_path, min_len=4):
    import re
    keystream = load_keystream()
    with open(input_path, 'rb') as f:
        data = f.read()
    
    # Decrypt into memory
    decrypted = bytearray(len(data))
    for p in range(0, len(data), PAGE_SIZE):
        for i in range(min(PAGE_SIZE, len(data) - p)):
            decrypted[p+i] = data[p+i] ^ keystream[i]
    
    # Extract ASCII runs
    pattern = f'[\\x20-\\x7e]{{{min_len},}}'.encode()
    chunks = []
    seen = set()
    for m in re.finditer(pattern, bytes(decrypted)):
        s = m.group().decode('ascii')
        if s[:100] not in seen:
            seen.add(s[:100])
            chunks.append(s)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(f'# AlfaOBD database content extraction\n')
        f.write(f'# Source: {os.path.basename(input_path)} ({len(data):,} bytes, {len(data)//PAGE_SIZE} pages)\n')
        f.write(f'# Extracted {len(chunks):,} unique ASCII runs\n\n')
        for c in chunks:
            f.write(c + '\n')
    print(f'Extracted {len(chunks):,} unique strings to {output_path}')


def main():
    ap = argparse.ArgumentParser(description='AlfaOBD alfao_bd.db decryption')
    ap.add_argument('input', help='Path to encrypted alfao_bd.db')
    ap.add_argument('output', nargs='?', help='Output path (.db for decryption, .txt for text extraction)')
    ap.add_argument('--extract-text', action='store_true', help='Extract readable text instead of full decryption')
    ap.add_argument('--min-len', type=int, default=4, help='Minimum text run length for --extract-text (default 4)')
    args = ap.parse_args()
    
    if args.extract_text:
        out = args.output or args.input + '.txt'
        extract_text(args.input, out, min_len=args.min_len)
    else:
        out = args.output or args.input + '.decrypted'
        decrypt(args.input, out)


if __name__ == '__main__':
    main()
