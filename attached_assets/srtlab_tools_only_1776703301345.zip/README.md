# SRT Lab — Complete Toolkit

A Python-based FCA/Stellantis diagnostic and VIN programming toolkit for salvage/rebuild dealership work. All modules reverse-engineered from Chrysler's official J2534 Flash Application, the AlfaOBD database (decrypted from a licensed copy), and the Replit-hosted SRT Lab source.

Works over OBD-II via J2534 (tested with Autel MaxiFlash Elite).

---

## Quick Start

```bash
# 1. Install Python dependencies
pip install -r requirements.txt

# 2. See what modules you can work with
python srtlab_ecm_vin_write.py --list

# 3. Scan a module (read-only, safe)
python srtlab_module_scan.py --module huntsville_bcm

# 4. Write a VIN (single module at a time)
python srtlab_ecm_vin_write.py --module cummins_849 --vin 3C7WRTCL5KG564882 --scan-first
```

---

## File Map

### Core Python tools

| File | Purpose |
|---|---|
| `srtlab_unlock_catalog.py` | Universal unlock dispatcher — 81 FCA modules, 14 native Python ports + 67 DLL emulation |
| `srtlab_canflash_algos.py` | 14 hand-reverse-engineered unlock algorithms (112 pinned test vectors, byte-exact) |
| `srtlab_module_scan.py` | Read-only UDS scanner for any of the 81 modules; supplier ID, DID probing, unlock verification |
| `srtlab_ecm_vin_write.py` | Single-module VIN writer with full UDS flow (session → seed → key → write F190 → reset → verify) |
| `srtlab_did_decode.py` | DID lookup tool — translates raw bytes to human descriptions using the AlfaOBD database |
| `srtlab_orc_clear.py` | Crash-data clearing for airbag modules (ORC/OCM) before VIN write |
| `srtlab_uds_errors.py` | UDS NRC decoder + context-aware diagnosis (readable error messages) |
| `srtlab_seedkey_capture.py` | Capture & analyze seed/key pairs — identify unknown algorithms |
| `srtlab_algos.py` | 18 algorithms ported from the Replit source (XTEA SGW, module unlocks, routines) |
| `srtlab_crc.py` | 7 verified CRC primitives |
| `srtlab_parsemodule.py` | Field-map parser for BCM/RFHUB/GPEC2A/95640 EEPROMs |
| `srtlab_patch_vin.py` | Offline binary VIN patcher with integrity enforcement |
| `srtlab_crossvalidate.py` | Cross-module sync rule validator |

### Data files

| File | Description |
|---|---|
| `canflash_unlocks/` | 81 FCA unlock DLLs from Chrysler J2534 Flash Application (3.2 MB total) |
| `alfao_bd_extracted.txt` | 23 MB plaintext dump of AlfaOBD database — 710K unique strings, all ECU definitions, DIDs, multi-language descriptions |
| `alfao_bd_decrypted.db` | 68 MB decrypted SQLite database (data pages fully readable) |
| `alfao_keystream.bin` | 4 KB XOR keystream for decrypting future AlfaOBD database updates |
| `alfaobd_dids.json` | 178 structured DID entries with bit positions and value enumerations |
| `alfaobd_dids.txt` | 243 raw DID entries (superset) |
| `alfaobd_ecu_types.txt` | 506 ECU type names from AlfaOBD's internal catalog |
| `alfaobd_modules.txt` | Categorized module/signal name index |
| `alfao_decrypt.py` | Standalone decryption tool for AlfaOBD databases |
| `canflash_seedkey.py` | Additional seed-key dispatcher (supplementary) |
| `canflash_uds.py` | UDS service primitives (supplementary) |

### UI + reference

| File | Description |
|---|---|
| `SRTLabJailbreakEdition.jsx` | Existing React UI (133 KB) |
| `CLAUDE.md` | Project notes |
| `alfao_README.md` | AlfaOBD recovery documentation |

---

## Module Coverage (81 total)

### Powertrain (16)
- **Engine/PCM (7)**: `ngc_engine`, `venom_pcm`, `gpec`, `cummins_849`, `edc16c2`, `edc16cp31`, `edc16u31`
- **Transmission (5)**: `ngc_transmission`, `ngc4_trans`, `aisin_tcm`, `egs52`, `cvt`
- **Integrated (2)**: `dcx_ptcm`, `ptim_lx`
- **AWD (2)**: `awd_pm_mk`, `borg_awd`

### Body (33)
- **BCM (3)**: `huntsville_bcm`, `wcm`, `lear_wcm`
- **FCM/Front (4)**: `yazaki_fcm`, `huntsville_fcm`, `huntsville_fdcm`, `fdcm`
- **TIPM (1)**: `motorola_tipm7`
- **Doors/Windows (13)**: all Bosch variants (DDM/PDM/mDDM/mPDM/mwDDM/mwPDM/CDM), Temic, generic, EWM
- **HVAC (4)**: `hvac`, `delphi_hvac`, `trw_hvac`, `trw_hvac_2`
- **Comfort (7)**: sunroof, parktronics, memory seat, power liftgate, electric ops/seat, left/right seat
- **Lighting (1)**: `hidt`

### Safety (13)
- **Brakes (6)**: `abs`, `bosch_abs`, `teves_abs`, `trw_abs`, `ahbm`, `asbs`
- **Airbag (4)**: `bosch_orc`, `trw_orc`, `ocm`, `trw_ocm`
- **Steering (3)**: `sas`, `trw_sas`, `valeo_scm`

### Cluster/Infotainment (15)
- **Cluster (1)**: `may_scofield_itm`
- **Radio/Head (4)**: `huntsville_radio`, `alpine_radio`, `alpine_rak`, `mitsubishi_rar`
- **Radio/Amp (4)**: `alpine_amp`, `harman_amp`, `kicker_amp`, `visteon_amp`
- **Handsfree (2)**: `hfm`, `peiker_hfm`
- **Sat Radio (1)**: `delphi_sdar`
- **Video (2)**: `mitsubishi_ves`, `mitsubishi_ves3`
- **Center Console Nav (3)**: `HB_ccn`, `LX_ccn`, `nippon_ccn`

### Other
- **ACC (1)**: `hella_acc`
- **CMTC (1)**: `cmtc`

---

## Workflow Examples

### Scan a module before writing
```bash
# Standard scan (read-only, safe, no key attempts used)
python srtlab_module_scan.py --module gpec

# Scan AND verify the unlock algorithm works (uses 1 key attempt)
python srtlab_module_scan.py --module gpec --test-unlock

# Find a BCM on unknown CAN address
python srtlab_module_scan.py --scan-all-bcms
```

### Write a VIN to a module

```bash
# Simple: pick the module, provide the VIN
python srtlab_ecm_vin_write.py --module huntsville_radio --vin 1C4RJFN92JC337221

# With pre-flight scan and auto-detect of VIN DID
python srtlab_ecm_vin_write.py --module alpine_radio --vin 1C4RJFN92JC337221 --scan-first

# Override session (e.g. airbag modules need programming session 0x02)
python srtlab_ecm_vin_write.py --module bosch_orc --vin <VIN> --session 0x02

# Override DID (if scanner found VIN in non-standard location)
python srtlab_ecm_vin_write.py --module alpine_radio --vin <VIN> --vin-did 0xF1C0

# Dry run (no hardware contact)
python srtlab_ecm_vin_write.py --module cummins_849 --vin <VIN> --dry-run
```

### Airbag module swap (ORC/OCM)

Before writing a VIN to a donor airbag module, its stored crash/deployment data must
be cleared. Otherwise the module rejects the write with NRC 0x22.

```bash
# 1. List supported ORC modules
python srtlab_orc_clear.py --list

# 2. Dry-run to preview the sequence (no hardware contact)
python srtlab_orc_clear.py --module bosch_orc --dry-run

# 3. Actually clear (connects via J2534, runs seed/key + routine 0xDF01)
python srtlab_orc_clear.py --module bosch_orc

# 4. Now write the VIN normally
python srtlab_ecm_vin_write.py --module bosch_orc --vin 1C4RJFN92JC337221 --session 0x02
```

If the first clear routine (0xDF01) doesn't work, the tool falls back through the
supplier's alternate routine IDs (0xDF02, 0x0203, 0x0201, 0xFF01) automatically.

**Safety note:** Clearing crash data does NOT make a physically damaged module safe.
Inspect the module case and test squib driver outputs before reinstalling. See the
docstring at the top of `srtlab_orc_clear.py` for the full checklist.

### Diagnose a failing command

When something fails with an NRC, the built-in NRC table in each tool gives you the
standard name. For context-aware advice, use the error tool directly:

```bash
# Single NRC lookup
python srtlab_uds_errors.py --nrc 0x22

# Decode a full negative response
python srtlab_uds_errors.py --decode "7F 2E 22"

# Context-aware diagnosis (tells you what to try next)
python srtlab_uds_errors.py --decode "7F 2E 22" --module bosch_orc
# Output:
#   NRC 0x22 (ConditionsNotCorrect) on service 0x2E (WriteDataByIdentifier)
#
#   Condition: Module not ready to accept WriteDataByIdentifier.
#   For bosch_orc this almost always means stored crash data blocks a write.
#   Fix: python srtlab_orc_clear.py --module bosch_orc

# Full reference
python srtlab_uds_errors.py --all-nrcs
python srtlab_uds_errors.py --all-services
```

### Capture & identify unknown seed/key algorithms

For modules not covered by the built-in catalog (post-2014 Hellcat ORC, GPEC2A,
Cummins 2019+, etc.), you can capture real seed/key pairs from a legitimate
diagnostic session and check if any known algorithm matches — or whether it's a
simple transform of one.

```bash
# Actively request a seed from a module (no key attempt — safe)
python srtlab_seedkey_capture.py --capture --tx 0x7E0 --rx 0x7E8 \
    --out captures/cummins_2019.json --module-hint "2019 Ram 3500 Cummins"

# Analyze captured pairs against all 81 catalog algorithms
python srtlab_seedkey_capture.py --analyse captures/cummins_2019.json

# Output will show:
#   ✓ MATCHES: cummins_849     (if it's a known algorithm)
#   ✓ Trivial transforms: byte-reversed, XOR 0xDEADBEEF, etc.  (if it's a variant)
#   ✗ Not a trivial transformation either — likely a new algorithm
#     (capture more pairs to constrain the function)
```

### Decode DIDs with AlfaOBD data

```bash
# Search by keyword
python srtlab_did_decode.py --search "rear camera"
python srtlab_did_decode.py --search nav

# Browse scope
python srtlab_did_decode.py --scope "VehConfig 1"
python srtlab_did_decode.py --scope "ECUConfig 3"

# Decode a specific value
python srtlab_did_decode.py --did 01225 --byte 1 --value 1
# → "Auto Highbeam: Yes"

# Dump everything
python srtlab_did_decode.py --all
```

### Use algorithms directly in your code

```python
from srtlab_unlock_catalog import unlock, MODULE_INFO

# Compute unlock key for any of 81 modules
seed = 0xDEADBEEF
key = unlock('cummins_849', seed)     # native Python, byte-exact
key = unlock('huntsville_bcm', seed)  # via DLL emulation, byte-exact
key = unlock('alpine_radio', seed)    # native

# Look up module metadata
info = MODULE_INFO['gpec']
# {'category': 'powertrain.engine', 'tx': 0x7E0, 'rx': 0x7E8, 'label': 'GPEC ECM (Continental)'}
```

---

## J2534 Hardware

### Autel setup (IM608 + MaxiFlash Elite J2534 box)

1. Install Autel's PC Suite (includes MFBT432.dll driver)
2. Connect the Elite box to your Windows PC via USB (NOT to the tablet)
3. Pass `--dll` path to the tools:

```bash
python srtlab_module_scan.py --module huntsville_bcm \
  --dll "C:\Program Files (x86)\Autel\MaxiSys\Maxi PC Suit\MFBT432.dll"
```

The tools auto-detect the Autel DLL at common install paths, so you usually don't need to specify it.

### Other J2534 devices

Any J2534-compliant device works. Pass `--dll` to point at its DLL:
- DrewTech OpenPort: `op20pt32.dll`
- Autel variants: `MFBT432.dll`, `JVCI432.dll`, `LVCI432.dll`, `JVCIPLUS432.dll`

---

## Safety Notes

- **Airbag modules**: Crash data must be cleared before VIN write. Some ORCs need session 0x02 (programming) instead of 0x03 (extended). Hellcat/Scat Pack 2015+ ORCs may use algorithms not in this toolset — use `--test-unlock` to verify.
- **Key attempts**: Modules typically lock after 3 wrong keys. Run `--test-unlock` conservatively. If locked, key-cycle the ignition.
- **2018+ vehicles with SGW**: Must unlock the Secure Gateway (XTEA, in `srtlab_algos.py`) before accessing modules in-car. Bench work bypasses this.
- **Cummins 2014+**: May accept the 849 algorithm but refuse to boot after VIN change without a fresh flash. Test on a spare first.

---

## What's Not Covered

This toolkit covers modules in the 2007 canflash release (most FCA through ~2014). Modules NOT covered by built-in unlock algorithms:
- **Hellcat/Scat Pack ORC** (2015+) — newer Bosch hardware, algorithm possibly different
- **GPEC2A** (2015+) — may work with existing `gpec` but not verified
- **UConnect 5** (2021+) — Aptiv Android-based, different architecture
- **2020+ Giulia/Stelvio modules** — Alfa Romeo-specific

For these, next steps would be:
1. Capture real seed/key pairs from a legitimate wiTECH session
2. Reverse-engineer Autel IM608's diagnostic DLLs
3. Intercept the unlock routine at runtime

### Recently added

- **Crash-data clear for airbag modules** (`srtlab_orc_clear.py`) — Supports Bosch,
  TRW, and generic OCM variants with supplier-aware routine fallbacks. Integrates
  with the VIN writer via automatic pre-flight warnings when targeting airbag
  modules.

---

## Credits / Sources

- **Chrysler J2534 Flash Application** — source of all 81 per-module unlock DLLs
- **AlfaOBD licensed copy** — source of DID definitions and ECU metadata (decrypted from licensed user's own data)
- **Replit SRT Lab source** — foundation of 18 algorithms and CRC primitives
- **Autel PassThru SDK** — J2534 DLL (MFBT432.dll for MaxiFlash Elite)

---

## License / Use

For personal and dealership use only. Tools operate on data from hardware you own and licenses you hold. Intended for legitimate salvage rebuild, diagnostic, and module replacement work.

