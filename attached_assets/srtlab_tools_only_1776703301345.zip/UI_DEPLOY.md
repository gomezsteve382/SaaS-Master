# Deploying the SRT Lab UI

The UI file is `SRTLabJailbreakEdition.jsx` — a React component (~1390 lines).
It uses the **Web Serial API** to talk to an OBDLink/ELM327 adapter, so it has
three hard requirements the browser enforces:

1. **Chrome or Edge 89+ on desktop.** No Firefox, no Safari, no mobile.
2. **Page loaded via `https://` or `http://localhost`.** Web Serial is blocked
   on `file://` and on plain HTTP served over the network.
3. **USB adapter.** Bluetooth SPP ports are invisible to Web Serial on Windows.

If you see `Failed to open serial port` or `Web Serial not available`, it's
always one of these three, not an issue in the code.

---

## Option A — Quick local run (Vite)

Best for iterating or just wanting to see the UI quickly.

```bash
# One-time setup
npm create vite@latest srtlab -- --template react
cd srtlab
npm install

# Copy the JSX into src/App.jsx
cp ../SRTLabJailbreakEdition.jsx src/App.jsx

# Run the dev server
npm run dev
```

Vite will print a URL like `http://localhost:5173/`. Open that in Chrome.
Web Serial works because `localhost` counts as a secure context.

---

## Option B — Deploy behind HTTPS for remote use

If you want to run this on a tablet or a shop computer without Node:

1. Build once with Vite: `npm run build` — produces `dist/` folder with static files.
2. Serve `dist/` behind HTTPS. Easiest options:
   - Upload to Netlify/Vercel/Cloudflare Pages (all free, all give you HTTPS)
   - Run `python3 -m http.server` on a machine with a self-signed cert

The `serve_ui.py` script in this folder serves the working directory on
`http://localhost:8000` with no-cache headers, which is fine for development
but assumes you've already built the app.

---

## Common Web Serial errors and what they mean

| Error | Cause | Fix |
|---|---|---|
| `Failed to open serial port` | Port busy in another app/tab | Close other Chrome tabs, ScanTool, Arduino IDE, TeraTerm |
| `Failed to open serial port` | Wrong driver | Install FTDI/CP210x/CH340 driver for your adapter chipset |
| `Failed to open serial port` | Page on `file://` | Serve via Vite or `python serve_ui.py` on localhost |
| `The device has been lost` | Unplugged between pick and open | Reconnect and retry |
| `No port selected by the user` | User hit Cancel in the picker | Click Connect again, pick the right port |
| `Web Serial not available` | Firefox or old browser | Use Chrome or Edge 89+ |
| `Access denied` on Linux | User not in `dialout` group | `sudo usermod -aG dialout $USER` then log out/in |
| `NotFoundError` on Bluetooth | Windows blocks BT SPP for Web Serial | Use USB adapter instead |

---

## Hardware compatibility

**Known good:**
- OBDLink EX (USB) — FTDI chipset, 500kbps HS-CAN
- OBDLink MX+ (USB mode) — switch to USB cable; BT mode won't work on Web Serial
- Generic ELM327 v1.5+ USB clones — most work, some have 9600 baud default
- STN1170/STN2120-based adapters — full feature support

**Not supported:**
- Bluetooth ELM327 on Windows (no Web Serial BT-SPP)
- WiFi ELM327 (no serial transport at all)
- Autel MaxiFlash — that's a J2534 device, use the Python tools instead
