# AlfaOBD Recovery + DID Decoder Tools

## Files

| File | Purpose |
|---|---|
| `alfao_decrypt.py` | Decrypts `alfao_bd.db` using the recovered XOR keystream |
| `alfao_keystream.bin` | 4KB keystream (1024-byte period × 4) |
| `alfao_bd_decrypted.db` | Decrypted database (readable as data; SQLite open has minor schema issue) |
| `alfao_bd_extracted.txt` | 23MB plaintext dump — searchable, 710K unique strings |
| `alfaobd_dids.txt` | 243 DID definitions (raw extracted) |
| `alfaobd_dids.json` | 178 structured DID entries (parsed, ready for lookup) |
| `alfaobd_ecu_types.txt` | 506 ECU types from AlfaOBD's internal catalog |
| `alfaobd_modules.txt` | Categorized module/signal names |
| `srtlab_did_decode.py` | CLI tool for DID lookup and decoding |

## Using the DID decoder

```bash
# Search for DIDs by description
python srtlab_did_decode.py --search "rear camera"
python srtlab_did_decode.py --search "max gear"
python srtlab_did_decode.py --search "hand drive"

# Browse a whole scope
python srtlab_did_decode.py --scope "VehConfig 1"
python srtlab_did_decode.py --scope "ECUConfig 3"

# List available scopes
python srtlab_did_decode.py --scopes

# Look up a specific DID entry
python srtlab_did_decode.py --did 01225
python srtlab_did_decode.py --did 01225 --byte 1 --value 1
# → "Auto Highbeam: Yes"

# Dump everything
python srtlab_did_decode.py --all
```

## Practical workflow: donor BCM swap

Say you're transplanting a BCM from a base trim donor into a premium-trim Ram and
some features don't work afterward (e.g. rear camera gone):

```bash
# 1. Scan the module — reads standard DIDs
python srtlab_module_scan.py --module huntsville_bcm

# 2. Look up what feature bits are in which DID
python srtlab_did_decode.py --scope "VehConfig 1"
python srtlab_did_decode.py --search "camera"
# → You find "Rear View Camera" is VehConfig 1, byte 4, bit 0

# 3. Read the current VehConfig 1 byte from the BCM
# 4. If bit 4:0 is 0, flip it to 1 and write back
```

## What's in the database

**2,100+ unique ECU type names** covering:
- FCA/Chrysler modules (pre-2014 through 2024+)
- Year-specific variants: `BODY_CHRYSLER77MY2016`, `MY2019`, `MY2020` — post-canflash coverage
- `CUMMINS_DIESEL_2019` — the newer Cummins generation
- `GIULIA_DIESEL_EDC17C69` — Giulia platform
- `SGW_PN`, `SGW_FGA` — Secure Gateway variants (2018+)
- `UCONNECT`, `UCONNECT_CMN` — modern Uconnect
- Car-specific ORC variants: `DART_ORC`, `COMPASS_ORC`, etc.

**178 structured config DIDs** spanning 12 scopes:
- VehConfig 1-8 (vehicle-level features)
- ECUConfig 3-4 (ECU feature configuration)
- Parktronics

**Diagnostic descriptions in 13 languages**: EN, DE, CZ, ES, IT, FR, HU, RU, PO, PL, CN, TR, GR

## How the decryption works (for reference)

- `alfao_bd.db` is a SQLite database XORed with a fixed 1024-byte keystream,
  applied 4 times per 4KB page
- AlfaOBD.exe is a Delphi wrapper around an embedded .NET assembly (`AlfaOBD_PC`)
- The real crypto routine is in the .NET IL — decompiling with ILSpy/dnSpy would
  reveal the exact keystream-generation algorithm
- Recovery method: known-plaintext attack using SQLite page structure + statistical
  analysis across the 16,656 pages + periodicity detection
- ~99% of keystream bytes recovered. Residual errors prevent a clean sqlite3 open
  but don't affect content extraction.

## Future work

When AlfaOBD releases new database versions (typical update cadence ~6 months),
run the same `alfao_decrypt.py` on the new file — the keystream is expected to
remain the same across versions.
