# SRT Lab v2 — Deployment Instructions (FINAL)

## Verified against SINCRO — byte-perfect match

This build was tested end-to-end against SINCRO's output on a known-good pairing
(22 Charger Redeye BCM + 2020 Charger 6.2 RFH, VIN 2C3CDXCT1HH652640). The engine
produces a **byte-identical** output to SINCRO's "hermanado" file. The ZO BCM (VIN
2C3CDXGJ3KH728648) fix is included in `ZO_BCM_V4_FINAL.bin` ready to flash.

## Files

1. **`SRTLabJailbreakEdition_v2.jsx`** — 199 KB, 2344 lines, single-file React
   drop-in replacement for your current `SRTLabJailbreakEdition.jsx`
2. **`vehicles/*.png`** — 5 vehicle images (charger, challenger, durango,
   trackhawk, trx) to be uploaded into `public/vehicles/`
3. **`ZO_BCM_V4_FINAL.bin`** — 65 KB — the ZO BCM with VIN 2C3CDXGJ3KH728648
   written to all 4 full slots + 2 short-VIN records, PLUS correct SEC16 pairing
   (split records + mirror 1 in inactive bank with valid CRC-16/CCITT)

## Replit paste sequence

1. Replace `SRTLabJailbreakEdition.jsx` with the contents of
   `SRTLabJailbreakEdition_v2.jsx`
2. Create folder `public/vehicles/` (if it doesn't exist)
3. Upload the 5 PNG images into `public/vehicles/` (exactly `charger.png`,
   `challenger.png`, `durango.png`, `trackhawk.png`, `trx.png` — lowercase)
4. Restart the Vite/Replit dev server

## What changed (structural)

### Before
- Top scrolling tab strip with 6 tabs (Dumps · OBD · Seed · GPEC · Security · GPEC2A)
- One UI regardless of vehicle

### After
- **Landing page**: 5 vehicle picture cards with staggered float animation
- **Per-vehicle workspace**: opens on card tap, header tinted with vehicle accent
- **4 tabs per vehicle**: Dumps · Live OBD · Skim · Info

## Security sync (the thing that was broken)

The DUMPS tab's "SYNC ALL MODULES" button now writes SEC16 to **three verified
targets** in the BCM for Gen2 family (68396561, 68525720, 68463847, etc.):

1. **Split records** at 0x81A0 / 0x81C0 / 0x81E0 in bank 2 (persistent):
   7-byte prefix + separator `04 04 00 14` + 9-byte suffix
2. **Mirror 1** (record with slot type 0xEB size 0x18) in the **inactive bank**:
   full 16-byte contiguous SEC16 + trailer 0x8F + FF FF + 2-byte CRC + 0xEB 0x00
3. **Mirror 2** (record with slot type 0xCA size 0x28) in the **inactive bank**:
   same payload structure

**Inactive bank is determined by comparing FEE1000 sequence numbers**
(higher seq = active, so lower = inactive — that's where mirrors live, staged
for the next bank rotation).

**CRC formula** (verified against SINCRO's output):
- CRC-16/CCITT (polynomial 0x1021, init 0xFFFF)
- Input: 20 bytes = `[idx(1)] + [SEC16(16)] + [trailer(0x8F)] + [0xFF][0xFF]`
- Stored big-endian at record offset +28

**Pairing rule** (verified):
- BCM SEC16 = reverse bytes of RFH SEC16 (entire 16-byte block)
- PCM SEC6 = first 6 bytes of RFH SEC16 (written at `FF FF FF AA` marker + 4)

## PCM support (GPEC2A + GPEC5)

The PCM parser now handles:
- **4KB GPEC2A** with `FF FF FF AA` marker (older Hellcats)
- **8KB GPEC5** with same marker or fallback `FF FF FF FF` marker
- **4 VIN slots** at offsets 0x0000, 0x01F0, 0x0224, 0x0CE0 (not 0x0223 as
  previously — confirmed against SINCRO-paired 8KB PCM)
- Current vs Original VIN tracking (SINCRO shows both separately)
- IMMO SANO / DAMAGED detection
- OS, PN, Serial string extraction

## Known limits (same as before)

- **TRX** still in catalog but sync engine hasn't been verified against a real
  TRX dump — engine will attempt Gen2 algorithm and may succeed, but blocked
  upload detection relies on part-number match
- **Trackhawk** uses a different SEC16 storage (not mirror+split format) —
  TRX/Hawk tab keeps VIN-only sync, SEC16 sync is bypassed
- **Gen1 RFH (R7F701044)** parsing is stubbed — format not yet reverse engineered
- **24C32 RFH EEPROM** parsing includes PIN extraction stub (3-byte hex → decimal)
  but offsets are best-guess until a real paired dump is validated
- **BCM families older than 68277389**: no SEC16 storage found in flash — VIN-only

## Test plan for ZO job

The ZO BCM (VIN 2C3CDXGJ3KH728648) is ready to flash. Try this sequence:

1. Flash `ZO_BCM_V4_FINAL.bin` to the ZO BCM module via your UPA / MultiProg
2. Try programming keys via Autel IM608
3. If Autel gives a non-77777 PIN — the sync worked, proceed with key programming
4. If Autel still shows 77777 — the BCM firmware may require **both** mirrors
   present. Next step would be to pull a fresh virgin BCM donor, pair it with
   the ZO RFH, then transplant the VIN

## Algorithm validation

Ran test: apply verified algorithm to `22CHARGER_REDEYE_6_2_797BCM_DFLASH_VIRGIN.bin`
with paired RFH `20CHRGR6_2RFHUBFILE_EEE_OG_CRC2C3CDXCT1HH652640.bin` →
produces byte-identical output to SINCRO's `BCM_HERMANADO_...`.

Expected SEC16 for 22 Redeye: `DA69698916EC45ABC143D97ED71580AB` ✓
Expected SEC16 for ZO: `510C0C33B06D87DC3C30B65CA9BBBACB` ✓

## If anything breaks

- Vehicle images missing: check `public/vehicles/*.png` with exact lowercase names
- "engParseBcm is not defined": paste got truncated — verify 199 KB / 2344 lines
- Sync button disabled: make sure VIN is 17 chars and all uploads are compatible
  with the selected vehicle
