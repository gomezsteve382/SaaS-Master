// ═══════════════════════════════════════════════════════════════
// TwinTab.jsx — TWO FIXES
// ═══════════════════════════════════════════════════════════════

// ━━━ FIX 1: RFHUB VIN checksum magic auto-detection ━━━
// 
// CHANGE the import at top of file (line 4):
//   OLD: import { rfhSec16Cs } from "../lib/crc.js";
//   NEW: import { rfhSec16Cs, rfhGen2DetectMagic } from "../lib/crc.js";

// CHANGE line 147:
//   OLD: const RFH_VIN_CS_MAGIC  = 0x87;   // empirically determined: CS = XOR(17 raw bytes) ^ 0x87
//   NEW: // Magic auto-detected per file — see parseRfhGen2()

// CHANGE the rfhVinCs function (lines 148-151):
//   OLD:
//     function rfhVinCs(raw17) {
//       const xr = Array.from(raw17).reduce((a, b) => a ^ b, 0);
//       return xr ^ RFH_VIN_CS_MAGIC;
//     }
//
//   NEW:
//     let _rfhVinMagic = 0xDB; // default for newer Gen2; auto-detected in parseRfhGen2
//     function rfhVinCs(raw17) {
//       const xr = Array.from(raw17).reduce((a, b) => a ^ b, 0);
//       return xr ^ _rfhVinMagic;
//     }

// CHANGE in parseRfhGen2 function — ADD magic detection after reading first VIN slot.
// After the line that creates `const vins = RFH_VIN_OFFSETS.map(...)` (around line 155-163),
// ADD these lines right after the vins map block:
//
//     // Auto-detect VIN CS magic from first slot that has a stored checksum
//     const firstSlot = vins.find(v => v.csStored !== 0x00 && v.csStored !== 0xFF);
//     if (firstSlot) {
//       _rfhVinMagic = rfhGen2DetectMagic(firstSlot.rawStored, firstSlot.csStored);
//       // Re-validate all slots with correct magic
//       for (const v of vins) {
//         v.csCalc = rfhVinCs(v.rawStored);
//         v.csOk = v.csStored === v.csCalc;
//       }
//     }


// ━━━ FIX 2: BCM partial VIN tails not updated during BCM→RFH apply ━━━
//
// The issue: when applying RFH→BCM, the partial VIN tails at 0x4098/0x40B0
// are correctly updated (lines 109-115 in applyBcmFromRfh). BUT the issue
// seen in the screenshot is that the tails show the OLD VIN from the virgin
// BCM file. The code at lines 109-115 IS writing them — let me verify the
// tail extraction is correct.
//
// Line 110: const tail8 = enc.slice(9); // last 8 chars of 17-char VIN
//
// VIN "2C3CDXCT1HH652640" → chars at index 9-16 = "HH652640" ✓
// But the screenshot shows "LH237142" which is from the OLD VIN "2C3CDXL97LH237142"
//
// This means the twinned BCM file you uploaded was created BEFORE the partial
// VIN fix was added, or the fix isn't being applied. The code looks correct.
// 
// To be safe, verify the partial write is using the RIGHT VIN source.
// In applyBcmFromRfh, line 89: const vin = rfhInfo.vins[0].vin;
// That should be the RFHUB's VIN. Confirm rfhInfo.vins[0].vin is the correct VIN.
//
// If the tails are STILL not updating, the issue might be that the offsets
// are wrong for this specific BCM variant. Let me add a verification:
//
// AFTER the partial VIN write loop (after line 115), ADD:
//
//     // Verify partial tails were written correctly
//     for (const off of BCM_VIN_PARTIAL) {
//       const written = Array.from(out.slice(off, off + 8)).map(b => String.fromCharCode(b)).join("");
//       console.log(`[TWIN] Partial VIN @ 0x${off.toString(16)}: "${written}"`);
//     }

// ═══════════════════════════════════════════════════════════════
// COMPLETE REPLACEMENT BLOCKS — copy-paste ready
// ═══════════════════════════════════════════════════════════════

// === BLOCK 1: Replace lines 4 ===
// import { rfhSec16Cs, rfhGen2DetectMagic } from "../lib/crc.js";

// === BLOCK 2: Replace lines 147-151 ===
/*
let _rfhVinMagic = 0xDB; // auto-detected per file in parseRfhGen2
function rfhVinCs(raw17) {
  const xr = Array.from(raw17).reduce((a, b) => a ^ b, 0);
  return xr ^ _rfhVinMagic;
}
*/

// === BLOCK 3: Insert after the `const vins = RFH_VIN_OFFSETS.map(...)` block in parseRfhGen2 ===
/*
  // Auto-detect VIN CS magic from first valid slot
  const validSlot = vins.find(v => v.csStored !== 0x00 && v.csStored !== 0xFF);
  if (validSlot) {
    const xorAll = Array.from(validSlot.rawStored).reduce((a, b) => a ^ b, 0);
    _rfhVinMagic = validSlot.csStored ^ xorAll;
    // Re-validate with correct magic
    for (const v of vins) {
      v.csCalc = rfhVinCs(v.rawStored);
      v.csOk = v.csStored === v.csCalc;
    }
  }
*/
