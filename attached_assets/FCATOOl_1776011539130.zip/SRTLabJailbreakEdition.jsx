import { useState, useCallback, useRef, useEffect, useMemo } from "react";

// ── Compact Engines ──
function crc16(d,i=0xFFFF){let c=i;for(let x=0;x<d.length;x++){c^=d[x]<<8;for(let j=0;j<8;j++)c=c&0x8000?(c<<1)^0x1021:c<<1;c&=0xFFFF;}return c;}
function crc8a(d,i=0){let c=i;for(let x=0;x<d.length;x++){c^=d[x];for(let j=0;j<8;j++)c=c&0x80?(c<<1)^0x26:c<<1;c&=0xFF;}return c;}
function crc8r(d,i=0x54){let c=i;for(let x=0;x<d.length;x++){c^=d[x];for(let j=0;j<8;j++)c=c&0x01?(c>>1)^0xA0:c>>1;c&=0xFF;}return c;}
const u32=n=>n>>>0;
function sxor(s,c){let k=u32(s);for(let i=0;i<5;i++){if(k&0x80000000)k=u32((k<<1)^u32(c));else k=u32(k<<1);}return k;}
function cda6(s){let k=u32(s);k=u32(k^0x4B129F);k=u32((k<<3)|(k>>>29));k=u32(k+0x1234);k=u32(k^0xABCD);k=u32((k>>>5)|(k<<27));return k;}
const NT=[0x44,0x41,0x49,0x4D,0x4C,0x45,0x52,0x43,0x48,0x52,0x59,0x53,0x4C,0x45,0x52,0x31],NS=[0x9D9F,0xCE48,0xB0F3,0xD99B,0xA720,0xFDD6,0x836D,0x6F8E];
function ngc(s){let k=0;for(let i=0;i<4;i++){let b=(u32(s)>>(i*8))&0xFF;k=u32(k^u32(((NT[b&0xF]^NT[(b>>4)&0xF])*NS[i%8])&0xFFFFFFFF));}return k;}
const TT={t8001:[0x727B,0xB301,0x08EB,0xB0BA,0xECA7,0x0ECC,0xD69A,0xE47E],t3605:[0x7A44,0x0201,0xF123,0x146E,0xCBC2,0x553F,0xD398,0x4EDC],t8101:[0x22B5,0x5767,0x4C5A,0xE443,0xC606,0x7544,0x0DFB,0x36D6],t3c:[0x632A,0x193B,0x914F,0x0F88,0x5E51,0x8DCD,0xDD6C,0x00DD]},TM=[0xBAEE,0xE000,0x1C00,0x0380,0x0070,0x0007];
function tipm(s,t='t8001'){const tb=TT[t]||TT.t8001;let v=s&0xFFFF,k=0;for(let i=0;i<tb.length;i++){let m=v&TM[i%TM.length],b=0,x=m;while(x){b^=x&1;x>>=1;}k=(k<<1)|b;k^=tb[i];k&=0xFFFF;}return k;}
const ALGOS=[{id:'gpec1',n:'GPEC1',h:'KEY=670269',fn:s=>sxor(s,670269)},{id:'gpec2',n:'GPEC2',h:'Continental ECM',fn:s=>sxor(s,0xE72E3799)},{id:'gpec2f',n:'GPEC2 Flash',h:'Flash mode',fn:s=>sxor(s,0x966AEEB1)},{id:'gpec2e',n:'GPEC2 EPROM',h:'EPROM access',fn:s=>sxor(s,0x3F711F5A)},{id:'gpec3',n:'GPEC3',h:'2018+ ECM',fn:s=>sxor(s,0x129D657F)},{id:'gpec2a',n:'GPEC2A',h:'GPEC2A',fn:s=>sxor(s,0xCE853A6F)},{id:'gpec15',n:'GPEC2 2015',h:'2015-2018',fn:s=>sxor(s,0x47EC21F8)},{id:'ngc',n:'NGC',h:'DAIMLERCHRYSLER',fn:s=>ngc(s)},{id:'jtec',n:'JTEC',h:'Fixed 0000',fn:()=>0},{id:'cda6',n:'CDA6 L1',h:'BCM ABS IPC',fn:s=>cda6(s)},{id:'t80',n:'TIPM 0x80',h:'t8001',fn:s=>tipm(s,'t8001')},{id:'t36',n:'TIPM 0x36',h:'t3605',fn:s=>tipm(s,'t3605')},{id:'t81',n:'TIPM 0x81',h:'t8101',fn:s=>tipm(s,'t8101')},{id:'t3c',n:'TIPM 0x3C',h:'t3c',fn:s=>tipm(s,'t3c')}];
function findVINs(d){const r=[];for(let i=0;i<d.length-16;i++){let ok=true;for(let j=0;j<17;j++){const b=d[i+j];if(!((b>=0x30&&b<=0x39)||(b>=0x41&&b<=0x5A&&b!==0x49&&b!==0x4F&&b!==0x51))){ok=false;break;}}if(ok)r.push({off:i,vin:String.fromCharCode(...d.slice(i,i+17)),rev:false});if(!ok){const v=[...d.slice(i,i+17)].reverse();let ok2=true;for(let j=0;j<17;j++){const b=v[j];if(!((b>=0x30&&b<=0x39)||(b>=0x41&&b<=0x5A&&b!==0x49&&b!==0x4F&&b!==0x51))){ok2=false;break;}}if(ok2)r.push({off:i,vin:String.fromCharCode(...v),rev:true});}}const s=new Set();return r.filter(v=>{const k=v.off+v.vin;if(s.has(k))return false;s.add(k);return true;});}
function fmtType(d){const s=d.length;if(s>=65536&&s<=131072)return'BCM';if(s===8192)return'95640';if(s===4096)return'4KB';if(s>131072)return'FW';return'??';}

// ── SKIM / Secret Key / Virginizer ──
const SKIM_OFF={Trackhawk:{base:0x2000,ks:18,kc:6},SRT:{base:0x40C0,ks:18,kc:6}};
function extractKeys(d){const r=[];for(const[v,c]of Object.entries(SKIM_OFF)){if(c.base+c.ks*c.kc>d.length)continue;const keys=[];let has=false;for(let i=0;i<c.kc;i++){const o=c.base+i*c.ks;const kb=d.slice(o,o+c.ks);const hex=Array.from(kb).map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join(' ');const empty=kb.every(b=>b===0xFF||b===0);if(!empty)has=true;keys.push({slot:i+1,off:o,hex,empty});}if(has)r.push({variant:v,keys,base:c.base});}return r;}
function findSecret(d){for(let i=0;i<d.length-14;i++)if(d[i]===0xC6&&d[i+1]===0x11&&d[i+2]===0x19)return{found:true,off:i,hex:Array.from(d.slice(i,i+14)).map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join(' ')};return{found:false};}
function virginize(f){const d=new Uint8Array(f.data);const ch=[];f.vins.forEach(v=>{for(let i=0;i<17;i++)d[v.off+i]=0xFF;ch.push(`VIN zeroed @0x${v.off.toString(16).toUpperCase()}`);});if(f.type==='BCM')[0x2000,0x40C0].forEach(o=>{if(o+32<d.length){for(let i=0;i<32;i++)d[o+i]=0xFF;ch.push(`SKIM @0x${o.toString(16).toUpperCase()}`);}});if(f.type==='BCM')f.vins.forEach(v=>{const c=crc16(d.slice(v.off,v.off+17));d[v.off+17]=(c>>8)&0xFF;d[v.off+18]=c&0xFF;ch.push('CRC-16 recalc');});if(f.type==='95640')f.vins.forEach(v=>{d[v.off-1]=crc8a(d.slice(v.off,v.off+17));ch.push('CRC-8 recalc');});return{data:d,changes:ch};}

// ── Databases from VILLAIN ──
const SUPPLIERS={'B4':'Becker','B5':'Blaupunkt','B7':'Bosch','C4':'Continental','C6':'Denso','C7':'Delphi','C8':'Hella','D5':'TRW','D6':'ZF','E2':'Valeo','E4':'Magna','F1':'Aisin','F3':'Getrag','04':'DCA','05':'DCS','06':'DCX','07':'MMC'};
const VLINES={'CS':'Town&Country','CT':'300/Magnum','DR':'RAM 1500','HB':'Durango','JC':'Journey','JK':'Wrangler JK','JL':'Wrangler JL','KL':'Cherokee','LC':'Challenger','LD':'Charger','MK':'Compass','RT':'Caravan','WD':'Grand Cherokee','WK':'Grand Cherokee WK2','ZB':'Viper','LA':'Dart'};
const COUNTRIES={'08':'USA','10':'Canada','15':'England','09':'Japan','0E':'Germany','03':'France','16':'Italy','11':'Spain','06':'Australia','07':'Mexico','04':'China','0A':'India'};
const MODS=[{c:'ECM',n:'Engine Control',tx:0x7E0,rx:0x7E8},{c:'TCM',n:'Transmission',tx:0x7E1,rx:0x7E9},{c:'BCM',n:'Body Control',tx:0x742,rx:0x762},{c:'RFHUB',n:'RF Hub / WCM',tx:0x75F,rx:0x767},{c:'ABS',n:'Brakes / ESC',tx:0x760,rx:0x768},{c:'IPC',n:'Cluster',tx:0x745,rx:0x765},{c:'RADIO',n:'Uconnect',tx:0x772,rx:0x77A},{c:'DAMP',n:'Active Dampening',tx:0x7E4,rx:0x7EC},{c:'EPS',n:'Power Steering',tx:0x75F,rx:0x767},{c:'TIPM',n:'Power Distro',tx:0x74C,rx:0x76C}];

// ── UI Components ──
function Particles(){return<><style>{`@keyframes float1{0%,100%{transform:translate(0,0)}50%{transform:translate(30px,-20px)}}@keyframes float2{0%,100%{transform:translate(0,0)}50%{transform:translate(-20px,30px)}}@keyframes float3{0%,100%{transform:translate(0,0)}50%{transform:translate(15px,25px)}}@keyframes pulse2{0%,100%{opacity:0.3;transform:scale(1)}50%{opacity:0.7;transform:scale(1.2)}}`}</style><div style={{position:'fixed',inset:0,pointerEvents:'none',zIndex:0,overflow:'hidden'}}>{[...Array(12)].map((_,i)=><div key={i} style={{position:'absolute',width:4+Math.random()*6,height:4+Math.random()*6,borderRadius:'50%',background:`rgba(255,${50+Math.random()*40},${40+Math.random()*30},${0.08+Math.random()*0.15})`,boxShadow:`0 0 ${6+Math.random()*10}px rgba(255,60,50,${0.1+Math.random()*0.1})`,left:`${5+Math.random()*90}%`,top:`${5+Math.random()*90}%`,animation:`float${(i%3)+1} ${8+Math.random()*12}s ease-in-out infinite,pulse2 ${4+Math.random()*6}s ease-in-out infinite`,animationDelay:`${Math.random()*5}s`}}/>)}</div></>}

function G({children,glow,accent='rgba(255,60,60,0.08)',style={},onClick,hover}){const[hov,setHov]=useState(false);return(<div onClick={onClick} onMouseEnter={hover?()=>setHov(true):undefined} onMouseLeave={hover?()=>setHov(false):undefined} style={{padding:18,borderRadius:14,background:'linear-gradient(145deg,rgba(28,28,40,0.85),rgba(20,20,30,0.95))',border:`1px solid ${hov?'rgba(255,80,60,0.2)':'rgba(255,255,255,0.06)'}`,backdropFilter:'blur(16px)',boxShadow:glow?`0 4px 30px rgba(0,0,0,0.3),0 0 30px ${accent},inset 0 1px 0 rgba(255,255,255,0.06)`:'0 4px 24px rgba(0,0,0,0.3),inset 0 1px 0 rgba(255,255,255,0.04)',transition:'all 0.3s cubic-bezier(0.34,1.56,0.64,1)',transform:hov?'translateY(-2px)':'none',cursor:onClick?'pointer':'default',position:'relative',overflow:'hidden',...style}}>{glow&&<div style={{position:'absolute',top:-30,right:-30,width:100,height:100,borderRadius:'50%',background:`radial-gradient(circle,${accent},transparent 70%)`,pointerEvents:'none',opacity:0.5}}/>}<div style={{position:'relative',zIndex:1}}>{children}</div></div>);}

function Glow({children,color='#ff3333',size=28,delay=0}){const[v,setV]=useState(false);useEffect(()=>{const t=setTimeout(()=>setV(true),delay);return()=>clearTimeout(t);},[delay]);return<span style={{fontFamily:"'JetBrains Mono'",fontSize:size,fontWeight:800,letterSpacing:4,color,textShadow:`0 0 20px ${color}66,0 0 40px ${color}33`,opacity:v?1:0,transform:v?'translateY(0) scale(1)':'translateY(8px) scale(0.95)',transition:'all 0.6s cubic-bezier(0.34,1.56,0.64,1)',display:'inline-block'}}>{children}</span>;}

function Btn({children,onClick,disabled,color='#ff3333',full}){const[h,setH]=useState(false);return<button onClick={onClick} disabled={disabled} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{padding:'8px 18px',borderRadius:8,border:`1px solid ${disabled?'rgba(255,255,255,0.03)':color+'44'}`,background:disabled?'rgba(255,255,255,0.02)':h?color+'22':color+'10',color:disabled?'#333':color,cursor:disabled?'not-allowed':'pointer',fontFamily:"'Outfit'",fontWeight:700,fontSize:12,width:full?'100%':undefined,transition:'all 0.2s',transform:h&&!disabled?'translateY(-1px)':'none',boxShadow:h&&!disabled?`0 4px 16px ${color}22`:'none',letterSpacing:0.5}}>{children}</button>;}

function Rev({children,delay=0}){const[v,setV]=useState(false);useEffect(()=>{const t=setTimeout(()=>setV(true),delay);return()=>clearTimeout(t);},[delay]);return<div style={{opacity:v?1:0,transform:v?'translateY(0)':'translateY(16px)',transition:`all 0.45s cubic-bezier(0.34,1.56,0.64,1) ${delay}ms`}}>{children}</div>;}

function Tag({children,color}){return<span style={{fontSize:9,fontWeight:700,padding:'2px 7px',borderRadius:4,background:color+'18',color,fontFamily:"'JetBrains Mono'",letterSpacing:0.5}}>{children}</span>;}

// ═════════════════════════════════════════════════════════════
const PAGES=[
  {id:'files',icon:'📂',l:'DUMPS',s:'Patch VINs'},
  {id:'live',icon:'📡',l:'LIVE OBD',s:'Read/write modules'},
  {id:'seed',icon:'🔑',l:'SEED→KEY',s:'Security calc'},
  {id:'gpec',icon:'🔓',l:'GPEC',s:'Unlock firmware'},
  {id:'skim',icon:'🛡️',l:'SKIM/IMMO',s:'Keys & secrets'},
  {id:'intel',icon:'🧠',l:'ECU INTEL',s:'Databases'},
  {id:'sri',icon:'📊',l:'SRI / TOOLS',s:'Mileage & utils'},
];

export default function App(){
  const[pg,setPg]=useState('files');
  const[files,setFiles]=useState([]);
  const[conn,setConn]=useState(false);
  const[log,setLog]=useState([]);
  const addLog=useCallback((m,l='info')=>setLog(p=>[{m,l,t:new Date().toLocaleTimeString('en-US',{hour12:false})},...p].slice(0,300)),[]);
  const loadF=useCallback(fl=>{Promise.all(Array.from(fl).map(f=>new Promise(r=>{const rd=new FileReader();rd.onload=e=>{const d=new Uint8Array(e.target.result);r({name:f.name,data:d,size:d.length,type:fmtType(d),vins:findVINs(d)});};rd.readAsArrayBuffer(f);}))).then(ld=>setFiles(p=>[...p,...ld]));},[]);

  return(
    <div style={{minHeight:'100vh',background:'linear-gradient(160deg,#0c0c14 0%,#111118 50%,#0e0e16 100%)',color:'#ddd',fontFamily:"'Outfit',sans-serif",position:'relative',overflow:'hidden'}}>
      <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&family=Bebas+Neue&display=swap" rel="stylesheet"/>
      <Particles/>
      <div style={{position:'fixed',inset:0,background:'radial-gradient(ellipse at 15% 15%,rgba(255,50,50,0.05) 0%,transparent 50%),radial-gradient(ellipse at 85% 85%,rgba(0,140,255,0.04) 0%,transparent 50%),radial-gradient(ellipse at 50% 40%,rgba(255,120,0,0.025) 0%,transparent 55%)',pointerEvents:'none',zIndex:0}}/>

      {/* HEADER */}
      <div style={{position:'relative',zIndex:10,borderBottom:'1px solid rgba(255,255,255,0.04)',background:'linear-gradient(180deg,rgba(255,50,50,0.03),transparent)'}}>
        <div style={{padding:'18px 28px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',alignItems:'baseline',gap:12}}>
            <span style={{fontFamily:"'Bebas Neue'",fontSize:40,letterSpacing:3,background:'linear-gradient(135deg,#ff3333,#ff6644,#ff3333)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',filter:'drop-shadow(0 0 25px rgba(255,50,50,0.3))',lineHeight:1}}>SRT LAB</span>
            <span style={{fontSize:9,fontWeight:800,letterSpacing:4,color:'rgba(255,140,50,0.5)'}}>JAILBREAK</span>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <div style={{width:9,height:9,borderRadius:'50%',background:conn?'#ff3333':'#222',boxShadow:conn?'0 0 14px rgba(255,50,50,0.6)':'none',transition:'all 0.6s'}}/>
            <span style={{fontSize:10,fontFamily:"'JetBrains Mono'",color:conn?'rgba(255,80,80,0.6)':'#222',fontWeight:600,letterSpacing:2}}>{conn?'ONLINE':'OFFLINE'}</span>
          </div>
        </div>

        {/* NAV — scrollable */}
        <div style={{display:'flex',padding:'0 16px',background:'rgba(0,0,0,0.12)',overflowX:'auto'}}>
          {PAGES.map(p=>{const a=pg===p.id;return(
            <button key={p.id} onClick={()=>setPg(p.id)} style={{padding:'14px 14px 12px',border:'none',cursor:'pointer',background:'transparent',color:a?'#ff3333':'#333',fontFamily:"'Outfit'",fontWeight:a?800:600,fontSize:12,whiteSpace:'nowrap',position:'relative',transition:'all 0.3s',minWidth:0,flex:'0 0 auto'}}>
              <span style={{fontSize:15,marginRight:5,filter:a?'drop-shadow(0 0 5px rgba(255,50,50,0.4))':'grayscale(1) brightness(0.3)',transition:'filter 0.3s'}}>{p.icon}</span>
              {p.l}
              <div style={{fontSize:7,fontWeight:400,marginTop:2,opacity:0.4}}>{p.s}</div>
              {a&&<div style={{position:'absolute',bottom:0,left:'10%',right:'10%',height:2,background:'linear-gradient(90deg,transparent,#ff3333,transparent)',borderRadius:2}}/>}
            </button>
          );})}
        </div>
      </div>

      <div style={{padding:'24px 28px',maxWidth:1100,margin:'0 auto',position:'relative',zIndex:5}}>
        {pg==='files'&&<FilesP files={files} setFiles={setFiles} loadF={loadF}/>}
        {pg==='live'&&<LiveP conn={conn} setConn={setConn} log={log} addLog={addLog}/>}
        {pg==='seed'&&<SeedP/>}
        {pg==='gpec'&&<GpecP/>}
        {pg==='skim'&&<SkimP files={files}/>}
        {pg==='intel'&&<IntelP/>}
        {pg==='sri'&&<SriP files={files} setFiles={setFiles}/>}
      </div>
    </div>
  );
}

// ═══════════════════ FILES ════════════════════════════════════
function FilesP({files,setFiles,loadF}){
  const[sel,setSel]=useState(null);const[nv,setNv]=useState('');const[ho,setHo]=useState(0);const[msg,setMsg]=useState('');
  const f=sel!==null?files[sel]:null;
  const patch=useCallback(v=>{if(!f||nv.length!==17)return;const d=new Uint8Array(f.data),b=new TextEncoder().encode(nv);if(v.rev){const r=[...b].reverse();for(let i=0;i<17;i++)d[v.off+i]=r[i];d[v.off+17]=crc8r(d.slice(v.off,v.off+17));}else{for(let i=0;i<17;i++)d[v.off+i]=b[i];if(f.type==='BCM'){const c=crc16(d.slice(v.off,v.off+17));d[v.off+17]=(c>>8)&0xFF;d[v.off+18]=c&0xFF;}else if(f.type==='95640')d[v.off-1]=crc8a(d.slice(v.off,v.off+17));}const u=[...files];u[sel]={...f,data:d,vins:findVINs(d)};setFiles(u);setMsg(`Patched @0x${v.off.toString(16).toUpperCase()} — CRC recalculated`);},[f,sel,nv,files,setFiles]);
  const dl=useCallback(()=>{if(!f)return;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([f.data]));a.download=`PATCHED_${f.name}`;a.click();},[f]);

  if(!files.length)return<Rev><div onClick={()=>{const i=document.createElement('input');i.type='file';i.multiple=true;i.onchange=e=>loadF(e.target.files);i.click();}} onDrop={e=>{e.preventDefault();loadF(e.dataTransfer.files);}} onDragOver={e=>e.preventDefault()} style={{border:'2px dashed rgba(255,50,50,0.15)',borderRadius:20,padding:'70px 20px',textAlign:'center',cursor:'pointer',background:'linear-gradient(135deg,rgba(255,50,50,0.02),rgba(255,100,50,0.01))'}}>
    <div style={{fontSize:56,marginBottom:12,filter:'drop-shadow(0 0 25px rgba(255,50,50,0.2))'}}>📂</div>
    <div style={{fontSize:22,fontWeight:900,background:'linear-gradient(135deg,#ff3333,#ff7744)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>Drop EEPROM or firmware files</div>
    <div style={{fontSize:12,color:'#555',marginTop:8}}>BCM · 95640 · RFHUB · GPEC2A · Firmware — auto-detect</div>
  </div></Rev>;

  return<div style={{display:'grid',gridTemplateColumns:'250px 1fr',gap:16}}>
    <div>
      <Rev><Btn onClick={()=>{const i=document.createElement('input');i.type='file';i.multiple=true;i.onchange=e=>loadF(e.target.files);i.click();}} full color="#ff5544">+ Add Files</Btn></Rev>
      {files.map((fi,i)=><Rev key={i} delay={i*60}><G hover onClick={()=>{setSel(i);setHo(fi.vins[0]?Math.max(0,fi.vins[0].off-16):0);setMsg('');}} glow={sel===i} style={{marginTop:8,padding:12,cursor:'pointer'}}>
        <div style={{fontSize:12,fontWeight:700,color:sel===i?'#ff3333':'#aaa'}}>{fi.name}</div>
        <div style={{fontSize:10,color:'#555',marginTop:3,display:'flex',gap:6}}><Tag color="#00bbee">{fi.type}</Tag><span>{(fi.size/1024).toFixed(0)}KB</span><span>{fi.vins.length} VIN{fi.vins.length!==1?'s':''}</span></div>
        {fi.vins[0]&&<div style={{fontFamily:"'JetBrains Mono'",fontSize:11,color:'#ff8833',fontWeight:700,marginTop:4,textShadow:'0 0 8px rgba(255,136,50,0.15)'}}>{fi.vins[0].vin}</div>}
      </G></Rev>)}
      {files.length>=2&&<Rev delay={files.length*60}><G style={{marginTop:10,padding:12}}>
        <div style={{fontSize:10,fontWeight:700,color:'#ff8833',marginBottom:4}}>VIN MATCH</div>
        {(()=>{const vs={};files.forEach(fi=>fi.vins.forEach(v=>{vs[v.vin]=(vs[v.vin]||0)+1;}));return Object.entries(vs).map(([vin,ct])=><div key={vin} style={{fontSize:10,fontFamily:"'JetBrains Mono'"}}><span style={{color:ct===files.length?'#ff3333':'#ff8833'}}>{vin}</span><span style={{color:'#444',marginLeft:6}}>{ct}/{files.length}{ct===files.length?' ✓':''}</span></div>);})()}
      </G></Rev>}
    </div>
    {f&&<div>
      <Rev delay={100}><G glow accent="rgba(255,50,50,0.06)" style={{marginBottom:14}}>
        <div style={{fontSize:13,fontWeight:800,marginBottom:10}}>PATCH VIN</div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <input value={nv} maxLength={17} placeholder="New 17-char VIN" onChange={e=>setNv(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g,''))} style={{flex:1,padding:'10px 14px',borderRadius:8,border:'1px solid rgba(255,255,255,0.05)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:14,letterSpacing:3,outline:'none'}}/>
          <span style={{fontFamily:"'JetBrains Mono'",fontSize:12,color:nv.length===17?'#ff3333':'#222',fontWeight:800}}>{nv.length}/17</span>
        </div>
        <div style={{display:'flex',gap:6,marginTop:10,flexWrap:'wrap'}}>
          {f.vins.map((v,i)=><Btn key={i} onClick={()=>patch(v)} disabled={nv.length!==17}>Patch @0x{v.off.toString(16).toUpperCase()}{v.rev?' (REV)':''}</Btn>)}
          <Btn onClick={dl} color="#00ccff">💾 Download</Btn>
        </div>
        {msg&&<div style={{fontSize:10,color:'#ff3333',marginTop:8,fontFamily:"'JetBrains Mono'",padding:'6px 10px',borderRadius:6,background:'rgba(255,50,50,0.04)',border:'1px solid rgba(255,50,50,0.08)'}}>✓ {msg}</div>}
      </G></Rev>
      <Rev delay={200}><div style={{background:'rgba(6,6,10,0.85)',borderRadius:12,padding:14,border:'1px solid rgba(255,255,255,0.03)',fontFamily:"'JetBrains Mono'",fontSize:11,boxShadow:'0 6px 24px rgba(0,0,0,0.3)'}}>
        <div style={{display:'flex',gap:6,marginBottom:8}}>
          <Btn onClick={()=>setHo(Math.max(0,ho-256))}>◀</Btn>
          <input placeholder="Hex offset" style={{flex:1,padding:'5px 8px',borderRadius:5,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#555',fontFamily:"'JetBrains Mono'",fontSize:10,outline:'none'}} onKeyDown={e=>{if(e.key==='Enter'){const v=parseInt(e.target.value,16);if(!isNaN(v))setHo(Math.min(v,f.size-256));}}}/>
          <Btn onClick={()=>setHo(Math.min(f.size-256,ho+256))}>▶</Btn>
          {f.vins[0]&&<Btn onClick={()=>setHo(Math.max(0,f.vins[0].off-16))} color="#ff8833">VIN</Btn>}
        </div>
        {Array.from({length:16},(_,row)=>{const a=ho+row*16;if(a>=f.size)return null;const bs=f.data.slice(a,Math.min(a+16,f.size));const vr=f.vins.some(v=>a+16>v.off&&a<v.off+17);return<div key={row} style={{display:'flex',gap:8,background:vr?'rgba(255,50,50,0.03)':'transparent',padding:'1px 4px',borderRadius:2}}>
          <span style={{color:'#333',minWidth:50}}>{a.toString(16).toUpperCase().padStart(6,'0')}</span>
          <span style={{flex:1}}>{Array.from(bs).map((b,j)=>{const isV=f.vins.some(v=>(a+j)>=v.off&&(a+j)<v.off+17);return<span key={j} style={{color:isV?'#ff3333':b===0xFF?'#181818':b===0?'#1e1e1e':'#555',fontWeight:isV?700:400,textShadow:isV?'0 0 8px rgba(255,50,50,0.35)':'none'}}>{b.toString(16).toUpperCase().padStart(2,'0')} </span>;})}</span>
          <span style={{color:'#222',minWidth:110}}>{Array.from(bs).map(b=>b>=32&&b<=126?String.fromCharCode(b):'.').join('')}</span>
        </div>;})}
      </div></Rev>
    </div>}
  </div>;
}

// ═══════════════════ LIVE OBD ═════════════════════════════════
function LiveP({conn,setConn,log,addLog}){
  const[found,setFound]=useState([]);const[nv,setNv]=useState('');const[busy,setBusy]=useState('');const[prog,setProg]=useState(0);const eng=useRef(null);
  const connect=useCallback(async()=>{try{if(!navigator.serial){addLog('Chrome required','error');return;}const port=await navigator.serial.requestPort();await port.open({baudRate:115200});const w=port.writable.getWriter();const dec=new TextDecoderStream();port.readable.pipeTo(dec.writable).catch(()=>{});const rd=dec.readable.getReader();let buf='';(async()=>{try{while(true){const{value,done}=await rd.read();if(done)break;if(value)buf+=value;}}catch(e){}})();const send=async(cmd,to=2000)=>{buf='';await w.write(new TextEncoder().encode(cmd+'\r'));addLog('TX > '+cmd,'tx');const s=Date.now();while(Date.now()-s<to){if(buf.includes('>')){const r=buf.replace(/>/g,'').trim();addLog('RX < '+r,'rx');return r;}await new Promise(r=>setTimeout(r,50));}return buf.trim();};await send('ATZ',3000);await new Promise(r=>setTimeout(r,500));addLog('Adapter: '+(await send('ATI')),'info');for(const c of['ATE0','ATL0','ATS1','ATH1','ATCAF1','ATCFC1','ATAL','ATSP6']){await send(c);await new Promise(r=>setTimeout(r,100));}eng.current={send,uds:async(tx,rx,data)=>{await send('ATSH'+tx.toString(16).toUpperCase().padStart(3,'0'));await send('ATCRA'+rx.toString(16).toUpperCase().padStart(3,'0'));const h=Array.from(data).map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join('');const r=await send(h,5000);if(!r||r.includes('NO DATA')||r.includes('ERROR'))return{ok:false};const ls=r.split(/\r?\n/).map(l=>l.trim()).filter(l=>/^[0-9A-F\s]+$/i.test(l));let all=[];ls.forEach(l=>{(l.replace(/\s/g,'').match(/.{2}/g)||[]).forEach(x=>all.push(parseInt(x,16)));});return{ok:true,d:new Uint8Array(all)}}};setConn(true);addLog('Ready — HS-CAN 500kbps','info');}catch(e){addLog('Failed: '+e.message,'error');}},[addLog,setConn]);
  const scan=useCallback(async()=>{if(!eng.current)return;setBusy('Scanning...');setFound([]);for(const m of MODS){try{const r=await eng.current.uds(m.tx,m.rx,[0x22,0xF1,0x90]);if(r.ok&&r.d?.length>3){const vc=Array.from(r.d).filter(b=>b>=0x20&&b<=0x7E);const vin=String.fromCharCode(...vc).slice(-17);if(vin.length>=10){setFound(p=>[...p,{...m,vin}]);addLog(m.c+': '+vin,'rx');}}}catch(e){}}setBusy('');addLog('Scan complete','info');},[addLog]);
  const writeAll=useCallback(async()=>{if(!eng.current||nv.length!==17)return;setBusy('Writing...');setProg(0);for(let i=0;i<found.length;i++){const m=found[i];await eng.current.uds(m.tx,m.rx,[0x10,0x03]);const sr=await eng.current.uds(m.tx,m.rx,[0x27,0x01]);if(sr.ok&&sr.d){const sb=Array.from(sr.d).slice(-4);let sv=0;for(const b of sb)sv=(sv<<8)|b;sv=u32(sv);if(sv){const k=cda6(sv);await eng.current.uds(m.tx,m.rx,[0x27,0x02,(k>>24)&0xFF,(k>>16)&0xFF,(k>>8)&0xFF,k&0xFF]);}}const vb=[...new TextEncoder().encode(nv)];for(const did of[0xF190,0x7B90,0x7B88]){const r=await eng.current.uds(m.tx,m.rx,[0x2E,(did>>8)&0xFF,did&0xFF,...vb]);addLog(m.c+' 0x'+did.toString(16)+': '+(r.ok?'OK':'FAIL'),(r.ok?'rx':'error'));}setProg(Math.round(((i+1)/found.length)*100));}setBusy('');addLog('Done','info');},[found,nv,addLog]);

  return<div style={{display:'grid',gridTemplateColumns:'1fr 280px',gap:16}}>
    <div>
      <Rev><G glow={conn} style={{marginBottom:14}}><div style={{display:'flex',gap:10}}><Btn onClick={connect} disabled={conn} color={conn?'#ff3333':'#00ccff'} full>{conn?'✓ Connected':'🔌 Connect OBDLink EX'}</Btn>{conn&&<Btn onClick={scan} disabled={!!busy} color="#ff8833" full>{busy||'📡 Scan Modules'}</Btn>}</div></G></Rev>
      {found.length>0&&<Rev delay={100}><G glow style={{marginBottom:14}}><div style={{fontSize:14,fontWeight:800,marginBottom:12}}>MODULES ON BUS ({found.length})</div><div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>{found.map((m,i)=><Rev key={i} delay={i*50}><G hover style={{padding:12}}><div style={{fontSize:13,fontWeight:800,color:'#ff3333',textShadow:'0 0 10px rgba(255,50,50,0.2)'}}>{m.c}</div><div style={{fontSize:9,color:'#444'}}>{m.n} · 0x{m.tx.toString(16).toUpperCase()}</div><div style={{fontFamily:"'JetBrains Mono'",fontSize:11,color:'#ff8833',fontWeight:700,marginTop:4}}>{m.vin}</div></G></Rev>)}</div></G></Rev>}
      {conn&&<Rev delay={200}><G glow><div style={{fontSize:14,fontWeight:800,marginBottom:10}}>WRITE NEW VIN</div><input value={nv} maxLength={17} placeholder="Enter 17-character VIN" onChange={e=>setNv(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g,''))} style={{width:'100%',padding:'12px 16px',borderRadius:10,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:18,letterSpacing:4,outline:'none',boxSizing:'border-box'}}/><div style={{display:'flex',justifyContent:'space-between',marginTop:10,alignItems:'center'}}><span style={{fontFamily:"'JetBrains Mono'",fontSize:12,color:nv.length===17?'#ff3333':'#222',fontWeight:800}}>{nv.length}/17</span><Btn onClick={writeAll} disabled={nv.length!==17||!found.length||!!busy}>{busy||`⚡ Write to ${found.length} modules`}</Btn></div>{prog>0&&prog<100&&<div style={{marginTop:10,height:4,borderRadius:3,background:'rgba(255,255,255,0.02)',overflow:'hidden'}}><div style={{height:'100%',width:`${prog}%`,background:'linear-gradient(90deg,#ff3333,#ff6644)',borderRadius:3,transition:'width 0.4s',boxShadow:'0 0 10px rgba(255,50,50,0.4)'}}/></div>}</G></Rev>}
    </div>
    <Rev delay={100}><div style={{background:'rgba(6,6,10,0.9)',borderRadius:12,padding:12,border:'1px solid rgba(255,255,255,0.03)',maxHeight:600,overflow:'auto',boxShadow:'0 6px 24px rgba(0,0,0,0.3)'}}><div style={{fontSize:10,fontWeight:800,color:'#222',marginBottom:6,letterSpacing:2}}>UDS LOG</div>{log.map((e,i)=><div key={i} style={{fontSize:9,fontFamily:"'JetBrains Mono'",padding:'1px 0',color:e.l==='error'?'#ff4444':e.l==='tx'?'#0099cc':e.l==='rx'?'#ff3333':'#333'}}><span style={{color:'#1a1a1a'}}>{e.t}</span> {e.m}</div>)}{!log.length&&<div style={{fontSize:10,color:'#1a1a1a',textAlign:'center',padding:30}}>Connect to see traffic</div>}</div></Rev>
  </div>;
}

// ═══════════════════ SEED→KEY ═════════════════════════════════
function SeedP(){
  const[al,setAl]=useState('gpec2');const[sh,setSh]=useState('');const[res,setRes]=useState(null);
  const calc=useCallback(()=>{const v=parseInt(sh.replace(/\s/g,''),16);if(isNaN(v))return;const a=ALGOS.find(x=>x.id===al);if(!a)return;const k=a.fn(v);setRes({sH:v.toString(16).toUpperCase().padStart(8,'0'),kH:k.toString(16).toUpperCase().padStart(8,'0'),n:a.n});},[al,sh]);
  return<div style={{maxWidth:640}}><Rev><G glow={!!res}>
    <div style={{fontSize:20,fontWeight:900,marginBottom:4,background:'linear-gradient(135deg,#ff3333,#ff6644)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>Seed → Key Calculator</div>
    <div style={{fontSize:11,color:'#444',marginBottom:20}}>14 algorithms from ECU-VILLAIN</div>
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:5,marginBottom:20}}>{ALGOS.map((a,i)=><Rev key={a.id} delay={i*25}><G hover onClick={()=>setAl(a.id)} glow={al===a.id} style={{padding:'8px 12px',cursor:'pointer'}}><div style={{fontSize:11,fontWeight:700,color:al===a.id?'#ff3333':'#555'}}>{a.n}</div><div style={{fontSize:8,color:al===a.id?'rgba(255,50,50,0.4)':'#222'}}>{a.h}</div></G></Rev>)}</div>
    <div style={{fontSize:9,fontWeight:800,color:'#333',marginBottom:6,letterSpacing:3}}>SEED (HEX)</div>
    <input value={sh} placeholder="A1B2C3D4" onChange={e=>setSh(e.target.value.toUpperCase().replace(/[^A-F0-9\s]/g,''))} onKeyDown={e=>e.key==='Enter'&&calc()} style={{width:'100%',padding:'14px 18px',borderRadius:10,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:24,letterSpacing:5,outline:'none',boxSizing:'border-box'}}/>
    <div style={{marginTop:12}}><Btn onClick={calc} full>Calculate Key</Btn></div>
    {res&&<Rev><div style={{marginTop:20,padding:20,borderRadius:14,background:'rgba(255,50,50,0.03)',border:'1px solid rgba(255,50,50,0.08)',boxShadow:'0 0 30px rgba(255,50,50,0.03)'}}><div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:24}}><div><div style={{fontSize:9,color:'#333',letterSpacing:2,marginBottom:6}}>SEED</div><Glow color="#00ccff">{res.sH}</Glow></div><div><div style={{fontSize:9,color:'#333',letterSpacing:2,marginBottom:6}}>KEY</div><Glow color="#ff3333" delay={150}>{res.kH}</Glow></div></div><div style={{marginTop:10,fontFamily:"'JetBrains Mono'",fontSize:10,color:'#222'}}>{res.n}</div></div></Rev>}
  </G></Rev></div>;
}

// ═══════════════════ GPEC ═════════════════════════════════════
function GpecP(){
  const[fw,setFw]=useState(null);const[res,setRes]=useState(null);
  const load=useCallback(e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=ev=>{setFw({name:f.name,data:new Uint8Array(ev.target.result),size:f.size});setRes(null);};r.readAsArrayBuffer(f);},[]);
  const unlock=useCallback(()=>{if(!fw)return;const d=new Uint8Array(fw.data);if(d.length<=0x2FFFC){setRes({ok:false,msg:'File too small'});return;}if(d[0x2FFFC]===0x96){setRes({ok:false,msg:'Already unlocked'});return;}d[0x2FFFC]=0x96;setRes({ok:true,msg:'Unlock flag set at 0x2FFFC = 0x96',data:d});},[fw]);
  const dl=useCallback(()=>{if(!res?.data)return;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([res.data]));a.download='UNLOCKED_'+fw.name;a.click();},[res,fw]);
  return<div style={{maxWidth:640}}><Rev><G glow={!!res}>
    <div style={{fontSize:20,fontWeight:900,marginBottom:4,background:'linear-gradient(135deg,#ff3333,#ff6644)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>GPEC Firmware Unlock</div>
    <div style={{fontSize:11,color:'#444',marginBottom:20}}>Cracked from .NET IL — sets 0x96 at offset 0x2FFFC</div>
    <div style={{display:'flex',gap:10}}><label style={{flex:1}}><G hover style={{padding:14,textAlign:'center',cursor:'pointer'}}><span style={{fontSize:13,fontWeight:700,color:'#888'}}>📂 Load Firmware</span><input type="file" hidden onChange={load}/></G></label><div style={{flex:1}}><G hover onClick={fw?unlock:undefined} glow={!!fw} style={{padding:14,textAlign:'center',cursor:fw?'pointer':'default',opacity:fw?1:0.3}}><span style={{fontSize:13,fontWeight:700,color:'#ff3333'}}>🔓 Unlock</span></G></div></div>
    {fw&&<div style={{marginTop:10,fontFamily:"'JetBrains Mono'",fontSize:11,color:'#444',padding:'8px 12px',borderRadius:8,background:'rgba(255,255,255,0.01)'}}>{fw.name} — {(fw.size/1024).toFixed(0)}KB{fw.data.length>0x2FFFC?` · 0x2FFFC=0x${fw.data[0x2FFFC].toString(16).toUpperCase().padStart(2,'0')}`:''}</div>}
    {res&&<Rev><div style={{marginTop:14,padding:14,borderRadius:10,background:res.ok?'rgba(255,50,50,0.03)':'rgba(255,136,50,0.03)',border:`1px solid ${res.ok?'rgba(255,50,50,0.1)':'rgba(255,136,50,0.1)'}`}}><div style={{fontSize:13,fontWeight:700,color:res.ok?'#ff3333':'#ff8833'}}>{res.ok?'✓ ':''}{res.msg}</div>{res.ok&&<div style={{marginTop:8}}><Btn onClick={dl} color="#00ccff">💾 Download Unlocked</Btn></div>}</div></Rev>}
  </G></Rev></div>;
}

// ═══════════════════ SKIM / IMMO ═════════════════════════════
function SkimP({files}){
  const bcm=files.find(f=>f.type==='BCM');
  const chip=files.find(f=>f.type==='95640');
  const skimData=useMemo(()=>bcm?extractKeys(bcm.data):[],[bcm]);
  const secret=useMemo(()=>chip?findSecret(chip.data):null,[chip]);
  const dlKeys=useCallback(()=>{let t=`SKIM EXTRACTION\n${'='.repeat(40)}\n\n`;skimData.forEach(v=>{t+=`${v.variant} @0x${v.base.toString(16).toUpperCase()}\n`;v.keys.forEach(k=>{t+=`  Key ${k.slot}: ${k.empty?'(EMPTY)':k.hex}\n`;});t+='\n';});if(secret?.found)t+=`95640 Secret: ${secret.hex}\n`;navigator.clipboard?.writeText(t);},[skimData,secret]);

  return<div style={{maxWidth:700}}><Rev><G glow>
    <div style={{fontSize:20,fontWeight:900,marginBottom:4,background:'linear-gradient(135deg,#ff3333,#ff6644)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>SKIM / Immobilizer</div>
    <div style={{fontSize:11,color:'#444',marginBottom:16}}>{bcm?`BCM loaded: ${bcm.name}`:'Load BCM dump in DUMPS tab to extract keys'}</div>

    {skimData.map((v,vi)=><Rev key={vi} delay={vi*80}><div style={{marginBottom:14}}>
      <div style={{fontSize:12,fontWeight:700,color:'#ff8833',marginBottom:6}}>{v.variant} — Base: 0x{v.base.toString(16).toUpperCase()}</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6}}>
        {v.keys.map(k=><G key={k.slot} glow={!k.empty} accent={k.empty?'transparent':'rgba(255,50,50,0.06)'} style={{padding:10}}>
          <div style={{display:'flex',justifyContent:'space-between'}}><span style={{fontSize:10,color:'#555'}}>KEY {k.slot}</span><Tag color={k.empty?'#333':'#ff3333'}>{k.empty?'EMPTY':'SET'}</Tag></div>
          <div style={{fontFamily:"'JetBrains Mono'",fontSize:8,color:k.empty?'#222':'#999',marginTop:4,wordBreak:'break-all'}}>{k.hex}</div>
        </G>)}
      </div>
    </div></Rev>)}

    {!bcm&&<div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6}}>{[1,2,3,4,5,6].map(n=><G key={n} style={{padding:10}}><div style={{fontSize:10,color:'#333'}}>KEY {n}</div><div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:'#1a1a1a',marginTop:2}}>—</div></G>)}</div>}

    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginTop:14}}>
      <G glow={secret?.found} accent="rgba(255,100,50,0.08)" style={{padding:12}}>
        <div style={{fontSize:10,color:'#555'}}>95640 SECRET KEY</div>
        <div style={{fontFamily:"'JetBrains Mono'",fontSize:secret?.found?10:13,color:secret?.found?'#ff8833':'#222',fontWeight:700,marginTop:4}}>{secret?.found?secret.hex:chip?'Pattern not found':'Load 95640 dump'}</div>
      </G>
      <G style={{padding:12}}>
        <div style={{fontSize:10,color:'#555'}}>SKIM STATE (DID 0x6E9EB0)</div>
        <div style={{fontSize:13,fontWeight:700,color:'#ff3333',marginTop:4}}>{bcm?'Check via Live OBD':'N/A'}</div>
      </G>
    </div>

    <div style={{display:'flex',gap:8,marginTop:14}}>
      <Btn onClick={dlKeys} disabled={!skimData.length} color="#ff8833">📋 Copy Keys</Btn>
      <Btn disabled={!bcm} color="#ff3333">🗑️ Virginize</Btn>
    </div>
  </G></Rev></div>;
}

// ═══════════════════ ECU INTEL ═════════════════════════════════
function IntelP(){
  const[sq,setSq]=useState('');const[vq,setVq]=useState('');
  return<div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}><Rev><G glow>
    <div style={{fontSize:16,fontWeight:800,marginBottom:10,background:'linear-gradient(135deg,#ff3333,#ff6644)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>Supplier Database</div>
    <input placeholder="Code (e.g. B7)" value={sq} onChange={e=>setSq(e.target.value.toUpperCase())} style={{width:'100%',padding:'8px 12px',borderRadius:6,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:12,outline:'none',boxSizing:'border-box',marginBottom:8}}/>
    {sq&&SUPPLIERS[sq]&&<div style={{fontSize:18,fontWeight:800,color:'#ff3333',textShadow:'0 0 10px rgba(255,50,50,0.2)',marginBottom:8}}>{SUPPLIERS[sq]}</div>}
    <div style={{maxHeight:250,overflow:'auto'}}>{Object.entries(SUPPLIERS).map(([c,n])=><div key={c} style={{fontSize:10,fontFamily:"'JetBrains Mono'",padding:'2px 0',color:'#555'}}><span style={{color:'#00bbee'}}>{c}</span> → {n}</div>)}</div>
  </G></Rev><Rev delay={100}><G glow>
    <div style={{fontSize:16,fontWeight:800,marginBottom:10,background:'linear-gradient(135deg,#ff3333,#ff6644)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>Vehicle Lines</div>
    <input placeholder="Code (e.g. WK)" value={vq} onChange={e=>setVq(e.target.value.toUpperCase())} style={{width:'100%',padding:'8px 12px',borderRadius:6,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:12,outline:'none',boxSizing:'border-box',marginBottom:8}}/>
    {vq&&VLINES[vq]&&<div style={{fontSize:18,fontWeight:800,color:'#ff3333',textShadow:'0 0 10px rgba(255,50,50,0.2)',marginBottom:8}}>{VLINES[vq]}</div>}
    <div style={{maxHeight:250,overflow:'auto'}}>{Object.entries(VLINES).map(([c,n])=><div key={c} style={{fontSize:10,fontFamily:"'JetBrains Mono'",padding:'2px 0',color:'#555'}}><span style={{color:'#00bbee'}}>{c}</span> → {n}</div>)}</div>
  </G></Rev><Rev delay={200}><G>
    <div style={{fontSize:14,fontWeight:700,marginBottom:8}}>Country Codes</div>
    <div style={{maxHeight:200,overflow:'auto'}}>{Object.entries(COUNTRIES).map(([c,n])=><div key={c} style={{fontSize:10,fontFamily:"'JetBrains Mono'",padding:'2px 0',color:'#555'}}><span style={{color:'#00bbee'}}>0x{c}</span> → {n}</div>)}</div>
  </G></Rev><Rev delay={300}><G>
    <div style={{fontSize:14,fontWeight:700,marginBottom:8}}>UDS Quick Ref</div>
    <div style={{fontFamily:"'JetBrains Mono'",fontSize:10,color:'#555',lineHeight:1.8}}>
      <span style={{color:'#00bbee'}}>0x7B90</span> Current VIN<br/>
      <span style={{color:'#00bbee'}}>0x7B88</span> Original VIN<br/>
      <span style={{color:'#00bbee'}}>0x6E2025</span> Bus TX VIN<br/>
      <span style={{color:'#00bbee'}}>0x6E2027</span> WCM VIN<br/>
      <span style={{color:'#00bbee'}}>0x6E9EB0</span> SKIM State<br/>
      <span style={{color:'#00bbee'}}>0x6EF190</span> EPS VIN<br/>
      <span style={{color:'#00bbee'}}>0x2023</span> BCM PROXI
    </div>
  </G></Rev></div>;
}

// ═══════════════════ SRI / TOOLS ══════════════════════════════
function SriP({files,setFiles}){
  const[mi,setMi]=useState('');const[hx,setHx]=useState('');const[res,setRes]=useState(null);
  const encode=()=>{const v=parseInt(mi);if(!isNaN(v)){const h=v.toString(16).toUpperCase().padStart(6,'0');setRes({hex:h,mi:v,km:Math.round(v*1.60934)});}};
  const decode=()=>{const v=parseInt(hx,16);if(!isNaN(v))setRes({hex:hx.toUpperCase(),mi:v,km:Math.round(v*1.60934)});};
  const doVirgin=useCallback((idx)=>{const f=files[idx];if(!f)return;const r=virginize(f);const u=[...files];u[idx]={...f,data:r.data,vins:findVINs(r.data)};setFiles(u);alert(`Virginized:\n${r.changes.join('\n')}`);},[files,setFiles]);

  return<div style={{maxWidth:700}}>
    <Rev><G glow>
      <div style={{fontSize:20,fontWeight:900,marginBottom:4,background:'linear-gradient(135deg,#ff3333,#ff6644)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>SRI Mileage Calculator</div>
      <div style={{fontSize:11,color:'#444',marginBottom:16}}>From VILLAIN: calculate_sri function</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div><div style={{fontSize:10,fontWeight:700,color:'#555',marginBottom:4}}>MILES → HEX</div>
          <input value={mi} onChange={e=>setMi(e.target.value)} placeholder="Enter miles" type="number" style={{width:'100%',padding:'8px 12px',borderRadius:6,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:12,outline:'none',boxSizing:'border-box'}}/>
          <div style={{marginTop:6}}><Btn onClick={encode} full>Encode</Btn></div>
        </div>
        <div><div style={{fontSize:10,fontWeight:700,color:'#555',marginBottom:4}}>HEX → MILES</div>
          <input value={hx} onChange={e=>setHx(e.target.value.toUpperCase())} placeholder="e.g. 00C350" style={{width:'100%',padding:'8px 12px',borderRadius:6,border:'1px solid rgba(255,255,255,0.04)',background:'rgba(0,0,0,0.3)',color:'#eee',fontFamily:"'JetBrains Mono'",fontSize:12,outline:'none',boxSizing:'border-box'}}/>
          <div style={{marginTop:6}}><Btn onClick={decode} full color="#00ccff">Decode</Btn></div>
        </div>
      </div>
      {res&&<Rev><div style={{marginTop:14,padding:14,borderRadius:10,background:'rgba(255,50,50,0.03)',border:'1px solid rgba(255,50,50,0.08)'}}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12}}>
          <div><div style={{fontSize:9,color:'#333'}}>HEX</div><Glow size={18} color="#00ccff">{res.hex}</Glow></div>
          <div><div style={{fontSize:9,color:'#333'}}>MILES</div><Glow size={18} color="#ff3333">{res.mi.toLocaleString()}</Glow></div>
          <div><div style={{fontSize:9,color:'#333'}}>KM</div><Glow size={18} color="#ff8833">{res.km.toLocaleString()}</Glow></div>
        </div>
      </div></Rev>}
    </G></Rev>

    {files.length>0&&<Rev delay={200}><G style={{marginTop:16}}>
      <div style={{fontSize:16,fontWeight:800,marginBottom:10}}>Virginizer</div>
      <div style={{fontSize:11,color:'#444',marginBottom:12}}>Zero VIN + SKIM bytes, recalculate CRC</div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        {files.map((f,i)=><Btn key={i} onClick={()=>doVirgin(i)} color="#ff3333">🗑️ Virginize {f.name}</Btn>)}
      </div>
    </G></Rev>}
  </div>;
}
