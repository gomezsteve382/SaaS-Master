import { useState, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Upload, Search, Download, Eye, ChevronLeft, ChevronRight } from "lucide-react";

// Known VIN/security offsets from the bundle
const KNOWN_REGIONS: Array<{ name: string; offsets: number[]; color: string; len: number }> = [
  { name: "ECM VIN", offsets: [0x160], color: "text-green-400", len: 17 },
  { name: "BCM VIN", offsets: [0x1298, 0x12B8, 0x1320, 0x1328], color: "text-green-400", len: 17 },
  { name: "BCM VIN (High)", offsets: [0x52B8], color: "text-green-400", len: 17 },
  { name: "BCM VIN (D-Flash)", offsets: [0x5320, 0x5340, 0x5360, 0x5380], color: "text-green-400", len: 17 },
  { name: "RFHUB VIN", offsets: [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1], color: "text-cyan-400", len: 17 },
  { name: "RFHUB VIN (alt)", offsets: [0x0100, 0x0120, 0x0140, 0x0160], color: "text-cyan-400", len: 17 },
  { name: "FCA 95640 VIN", offsets: [0x275, 0x288], color: "text-green-400", len: 17 },
  { name: "Secret Key", offsets: [0x0040, 0x01A0], color: "text-purple-400", len: 16 },
  { name: "SKIM Pairing", offsets: [0x0120, 0x0126], color: "text-yellow-400", len: 6 },
  { name: "BCM Security", offsets: [0x40C0, 0x2000], color: "text-red-400", len: 16 },
  { name: "FCA 95640 Serial", offsets: [0x27, 0x50], color: "text-orange-400", len: 17 },
  { name: "CRC-16", offsets: [0x01FE, 0x02FE, 0x0EB7, 0x0ECB], color: "text-pink-400", len: 2 },
];

const COLS = 16;
const VISIBLE_ROWS = 24;

export default function EEPROMViewer() {
  const [fileData, setFileData] = useState<Uint8Array | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [viewOffset, setViewOffset] = useState(0);
  const [searchHex, setSearchHex] = useState("");
  const [searchResults, setSearchResults] = useState<number[]>([]);
  const [searchIdx, setSearchIdx] = useState(0);
  const [selectedByte, setSelectedByte] = useState<number | null>(null);

  // Build highlight map
  const highlights = useMemo(() => {
    if (!fileData) return new Map<number, string>();
    const map = new Map<number, string>();
    for (const region of KNOWN_REGIONS) {
      for (const off of region.offsets) {
        for (let i = 0; i < region.len && off + i < fileData.length; i++) {
          // Only highlight if the data at this offset looks non-empty
          if (fileData[off + i] !== 0xFF && fileData[off + i] !== 0x00) {
            map.set(off + i, region.color);
          }
        }
      }
    }
    return map;
  }, [fileData]);

  // Available jump targets (only offsets that exist in the file)
  const jumpTargets = useMemo(() => {
    if (!fileData) return [];
    const targets: Array<{ name: string; offset: number; color: string }> = [];
    for (const region of KNOWN_REGIONS) {
      for (const off of region.offsets) {
        if (off < fileData.length) {
          // Check if there's non-empty data here
          let hasData = false;
          for (let i = 0; i < Math.min(region.len, fileData.length - off); i++) {
            if (fileData[off + i] !== 0xFF && fileData[off + i] !== 0x00) { hasData = true; break; }
          }
          if (hasData) targets.push({ name: region.name, offset: off, color: region.color });
        }
      }
    }
    return targets;
  }, [fileData]);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setViewOffset(0);
    setSearchResults([]);
    const reader = new FileReader();
    reader.onload = () => setFileData(new Uint8Array(reader.result as ArrayBuffer));
    reader.readAsArrayBuffer(file);
  };

  const jumpTo = (offset: number) => {
    setViewOffset(Math.floor(offset / COLS) * COLS);
    setSelectedByte(offset);
  };

  const searchHexBytes = () => {
    if (!fileData || !searchHex) return;
    const cleanHex = searchHex.replace(/\s/g, "").toUpperCase();
    if (cleanHex.length % 2 !== 0 || !/^[0-9A-F]+$/.test(cleanHex)) return;

    const searchBytes = cleanHex.match(/.{2}/g)!.map(b => parseInt(b, 16));
    const results: number[] = [];
    for (let i = 0; i <= fileData.length - searchBytes.length; i++) {
      let match = true;
      for (let j = 0; j < searchBytes.length; j++) {
        if (fileData[i + j] !== searchBytes[j]) { match = false; break; }
      }
      if (match) results.push(i);
    }
    setSearchResults(results);
    setSearchIdx(0);
    if (results.length > 0) jumpTo(results[0]);
  };

  // Also search for ASCII VIN
  const searchASCII = () => {
    if (!fileData || !searchHex) return;
    const target = searchHex.toUpperCase();
    const targetBytes = Array.from(target).map(c => c.charCodeAt(0));
    const results: number[] = [];
    for (let i = 0; i <= fileData.length - targetBytes.length; i++) {
      let match = true;
      for (let j = 0; j < targetBytes.length; j++) {
        if (fileData[i + j] !== targetBytes[j]) { match = false; break; }
      }
      if (match) results.push(i);
    }
    setSearchResults(results);
    setSearchIdx(0);
    if (results.length > 0) jumpTo(results[0]);
  };

  const totalRows = fileData ? Math.ceil(fileData.length / COLS) : 0;
  const maxOffset = Math.max(0, (totalRows - VISIBLE_ROWS) * COLS);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-950 via-gray-900 to-black text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Eye className="h-8 w-8 text-cyan-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">EEPROM Viewer</h1>
          </div>
          <p className="text-gray-400">Hex viewer with known VIN/security offset highlighting · BCM · RFHUB · ECM · FCA 95640</p>
        </div>
      </div>

      <div className="container py-8 space-y-6">
        {/* Upload + Search */}
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <input type="file" accept=".bin,.BIN,.eee,.EEE" onChange={handleFile} className="hidden" id="eeprom-upload" />
            <Button asChild variant="outline">
              <label htmlFor="eeprom-upload" className="cursor-pointer">
                <Upload className="h-4 w-4 mr-2" />{fileName || "Upload .bin / .eee"}
              </label>
            </Button>
          </div>

          {fileData && (
            <>
              <div className="flex-1 min-w-[200px]">
                <div className="flex gap-2">
                  <Input value={searchHex} onChange={e => setSearchHex(e.target.value)} placeholder="Search hex (FF 90) or VIN text..." className="font-mono text-sm" />
                  <Button size="sm" variant="secondary" onClick={searchHexBytes}><Search className="h-3 w-3 mr-1" />Hex</Button>
                  <Button size="sm" variant="secondary" onClick={searchASCII}><Search className="h-3 w-3 mr-1" />ASCII</Button>
                </div>
              </div>
              {searchResults.length > 0 && (
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{searchIdx + 1}/{searchResults.length}</Badge>
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { const i = (searchIdx - 1 + searchResults.length) % searchResults.length; setSearchIdx(i); jumpTo(searchResults[i]); }}>
                    <ChevronLeft className="h-3 w-3" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { const i = (searchIdx + 1) % searchResults.length; setSearchIdx(i); jumpTo(searchResults[i]); }}>
                    <ChevronRight className="h-3 w-3" />
                  </Button>
                </div>
              )}
              <Badge variant="secondary" className="font-mono">{fileData.length.toLocaleString()} bytes</Badge>
            </>
          )}
        </div>

        {/* Jump targets */}
        {jumpTargets.length > 0 && (
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm">Known Regions Found</CardTitle>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="flex flex-wrap gap-2">
                {jumpTargets.map((t, i) => (
                  <Button key={i} size="sm" variant="outline" className="font-mono text-xs h-7" onClick={() => jumpTo(t.offset)}>
                    <span className={`mr-1 ${t.color.replace('text-', 'text-')}`}>●</span>
                    {t.name} · 0x{t.offset.toString(16).toUpperCase()}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Hex Dump */}
        {fileData && (
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <div className="p-4 font-mono text-[13px] leading-7 min-w-[800px] bg-gray-950 rounded-lg text-gray-300">
                  {/* Header row */}
                  <div className="flex text-gray-600 text-[11px] border-b border-gray-800 pb-1 mb-1">
                    <span className="w-[80px] shrink-0">OFFSET</span>
                    {Array.from({ length: COLS }, (_, i) => (
                      <span key={i} className="w-[28px] text-center">{i.toString(16).toUpperCase()}</span>
                    ))}
                    <span className="ml-4">ASCII</span>
                  </div>

                  {/* Data rows */}
                  {Array.from({ length: Math.min(VISIBLE_ROWS, totalRows - viewOffset / COLS) }, (_, row) => {
                    const rowOffset = viewOffset + row * COLS;
                    return (
                      <div key={row} className="flex hover:bg-gray-900/50">
                        <span className="w-[80px] shrink-0 text-gray-600">
                          {rowOffset.toString(16).toUpperCase().padStart(6, "0")}
                        </span>
                        {/* Hex bytes */}
                        {Array.from({ length: COLS }, (_, col) => {
                          const addr = rowOffset + col;
                          if (addr >= fileData.length) return <span key={col} className="w-[28px] text-center text-gray-800">··</span>;
                          const byte = fileData[addr];
                          const highlight = highlights.get(addr);
                          const isSearch = searchResults.includes(addr) || (searchResults.length > 0 && addr >= searchResults[searchIdx] && addr < searchResults[searchIdx] + (searchHex.replace(/\s/g, "").length / 2 || searchHex.length));
                          const isSelected = addr === selectedByte;
                          return (
                            <span key={col}
                              className={`w-[28px] text-center cursor-pointer transition-colors ${
                                isSelected ? "bg-cyan-600 text-white rounded" :
                                isSearch ? "bg-yellow-600/40 text-yellow-300" :
                                highlight ? highlight :
                                byte === 0xFF ? "text-gray-700" :
                                byte === 0x00 ? "text-gray-800" :
                                "text-gray-300"
                              }`}
                              onClick={() => setSelectedByte(addr)}
                              title={`0x${addr.toString(16).toUpperCase()} = ${byte} (0x${byte.toString(16).toUpperCase().padStart(2, "0")})`}>
                              {byte.toString(16).toUpperCase().padStart(2, "0")}
                            </span>
                          );
                        })}
                        {/* ASCII */}
                        <span className="ml-4 text-gray-500">
                          {Array.from({ length: COLS }, (_, col) => {
                            const addr = rowOffset + col;
                            if (addr >= fileData.length) return " ";
                            const byte = fileData[addr];
                            return byte >= 0x20 && byte <= 0x7E ? String.fromCharCode(byte) : "·";
                          }).join("")}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between p-3 border-t border-gray-800 bg-gray-950 rounded-b-lg">
                <Button size="sm" variant="ghost" onClick={() => setViewOffset(Math.max(0, viewOffset - VISIBLE_ROWS * COLS))} disabled={viewOffset <= 0}>
                  <ChevronLeft className="h-4 w-4 mr-1" />Page Up
                </Button>
                <div className="flex items-center gap-3">
                  <Input
                    className="w-24 h-7 text-xs font-mono text-center bg-gray-900 border-gray-700"
                    value={`0x${viewOffset.toString(16).toUpperCase()}`}
                    onChange={e => {
                      const val = parseInt(e.target.value.replace(/^0x/i, ""), 16);
                      if (!isNaN(val)) setViewOffset(Math.min(maxOffset, Math.floor(val / COLS) * COLS));
                    }}
                  />
                  <span className="text-xs text-gray-500">
                    Row {Math.floor(viewOffset / COLS) + 1} / {totalRows}
                  </span>
                  {selectedByte !== null && (
                    <Badge variant="outline" className="font-mono text-[10px]">
                      Selected: 0x{selectedByte.toString(16).toUpperCase()} = {fileData[selectedByte]} (0x{fileData[selectedByte].toString(16).toUpperCase().padStart(2, "0")})
                    </Badge>
                  )}
                </div>
                <Button size="sm" variant="ghost" onClick={() => setViewOffset(Math.min(maxOffset, viewOffset + VISIBLE_ROWS * COLS))} disabled={viewOffset >= maxOffset}>
                  Page Down<ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Legend */}
        {fileData && (
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm">Color Legend</CardTitle>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="flex flex-wrap gap-4 text-xs font-mono">
                <span><span className="text-green-400">●</span> VIN Data</span>
                <span><span className="text-cyan-400">●</span> RFHUB VIN</span>
                <span><span className="text-purple-400">●</span> Secret Key</span>
                <span><span className="text-yellow-400">●</span> SKIM Pairing</span>
                <span><span className="text-red-400">●</span> Security Block</span>
                <span><span className="text-orange-400">●</span> Serial Number</span>
                <span><span className="text-pink-400">●</span> CRC Checksum</span>
                <span className="text-gray-700">FF = Erased</span>
                <span className="text-gray-800">00 = Zero</span>
              </div>
            </CardContent>
          </Card>
        )}

        {!fileData && (
          <div className="text-center py-20 text-muted-foreground">
            Upload a .bin or .eee file to begin analysis
          </div>
        )}
      </div>
    </div>
  );
}
