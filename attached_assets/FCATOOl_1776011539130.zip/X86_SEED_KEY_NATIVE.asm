            0x00691d00      3b0d9c136c00   cmp ecx, dword [0x6c139c]   ; [0x6c139c:4]=0x65797e58
        ,=< 0x00691d06      7514           jne 0x691d1c
        |   0x00691d08      ff00           inc dword [eax]
        |   0x00691d0a      5f             pop edi
        |   0x00691d0b      5e             pop esi
        |   0x00691d0c      5d             pop ebp
        |   0x00691d0d      8b4c241c       mov ecx, dword [esp + 0x1c]
        |   0x00691d11      33cc           xor ecx, esp
        |   0x00691d13      e8ca930100     call 0x6ab0e2
        |   0x00691d18      83c420         add esp, 0x20
        |   0x00691d1b      c3             ret
        `-> 0x00691d1c      53             push ebx
            0x00691d1d      56             push esi
            0x00691d1e      52             push edx
            0x00691d1f      50             push eax
            0x00691d20      e8cb380000     call 0x6955f0
            0x00691d25      8bd8           mov ebx, eax
            0x00691d27      897c2420       mov dword [esp + 0x20], edi
            0x00691d2b      8b44241c       mov eax, dword [esp + 0x1c]
            0x00691d2f      89442428       mov dword [esp + 0x28], eax
            0x00691d33      8d442420       lea eax, [esp + 0x20]
            0x00691d37      6a03           push 3                      ; 3
            0x00691d39      50             push eax
            0x00691d3a      8d442434       lea eax, [esp + 0x34]
            0x00691d3e      896c242c       mov dword [esp + 0x2c], ebp
            0x00691d42      50             push eax
            0x00691d43      c74424382855.  mov dword [esp + 0x38], 0x6c5528 ; '(Ul'
                                                                       ; [0x6c5528:4]=0x67616c66 ; "flags"
            0x00691d4b      c744243c3055.  mov dword [esp + 0x3c], 0x6c5530 ; '0Ul'
                                                                       ; [0x6c5530:4]=0x746e6f64 ; "dont_inherit"
            0x00691d53      c74424404055.  mov dword [esp + 0x40], 0x6c5540 ; '@Ul'
                                                                       ; [0x6c5540:4]=0x6974706f ; "optimize"
            0x00691d5b      e8f02b0000     call 0x694950
            0x00691d60      8b3d107a6e00   mov edi, dword [0x6e7a10]   ; [0x6e7a10:4]=0
            0x00691d66      83c418         add esp, 0x18
            0x00691d69      8bf0           mov esi, eax
            0x00691d6b      85ff           test edi, edi
        ,=< 0x00691d6d      7532           jne 0x691da1
        |   0x00691d6f      684c556c00     push 0x6c554c               ; 'LUl' ; "compile"
        |   0x00691d74      ff35bc786e00   push dword [0x6e78bc]
        |   0x00691d7a      ff1574126c00   call dword [0x6c1274]
        |   0x00691d80      8bf8           mov edi, eax
        |   0x00691d82      83c408         add esp, 8
        |   0x00691d85      85ff           test edi, edi
       ,==< 0x00691d87      7512           jne 0x691d9b
       ||   0x00691d89      50             push eax
       ||   0x00691d8a      ff15e8146c00   call dword [0x6c14e8]
       ||   0x00691d90      83c404         add esp, 4
       ||   0x00691d93      6a01           push 1                      ; 1
       ||   0x00691d95      ff15ac146c00   call dword [0x6c14ac]
       `--> 0x00691d9b      893d107a6e00   mov dword [0x6e7a10], edi   ; [0x6e7a10:4]=0
        `-> 0x00691da1      8b4704         mov eax, dword [edi + 4]
            0x00691da4      8b4840         mov ecx, dword [eax + 0x40]
            0x00691da7      85c9           test ecx, ecx
        ,=< 0x00691da9      751c           jne 0x691dc7
        |   0x00691dab      ff700c         push dword [eax + 0xc]
        |   0x00691dae      a10c156c00     mov eax, dword [0x6c150c]   ; [0x6c150c:4]=0x65797584
        |   0x00691db3      6860176c00     push 0x6c1760               ; '`\x17l' ; "'%s' object is not callable"
        |   0x00691db8      ff30           push dword [eax]
        |   0x00691dba      ff152c156c00   call dword [0x6c152c]       ; "5\t\xc8"
        |   0x00691dc0      83c40c         add esp, 0xc
        |   0x00691dc3      33ff           xor edi, edi
       ,==< 0x00691dc5      eb11           jmp 0x691dd8
       |`-> 0x00691dc7      56             push esi
       |    0x00691dc8      53             push ebx
       |    0x00691dc9      57             push edi
       |    0x00691dca      ffd1           call ecx
       |    0x00691dcc      50             push eax
       |    0x00691dcd      57             push edi
       |    0x00691dce      e84d87feff     call 0x67a520
       |    0x00691dd3      83c414         add esp, 0x14
       |    0x00691dd6      8bf8           mov edi, eax
       `--> 0x00691dd8      8303ff         add dword [ebx], 0xffffffff
        ,=< 0x00691ddb      750c           jne 0x691de9
        |   0x00691ddd      8b4b04         mov ecx, dword [ebx + 4]
        |   0x00691de0      53             push ebx
        |   0x00691de1      8b4918         mov ecx, dword [ecx + 0x18]
        |   0x00691de4      ffd1           call ecx
        |   0x00691de6      83c404         add esp, 4
        `-> 0x00691de9      85f6           test esi, esi
        ,=< 0x00691deb      7411           je 0x691dfe
        |   0x00691ded      8306ff         add dword [esi], 0xffffffff
       ,==< 0x00691df0      750c           jne 0x691dfe
       ||   0x00691df2      8b4604         mov eax, dword [esi + 4]
       ||   0x00691df5      56             push esi
       ||   0x00691df6      8b4018         mov eax, dword [eax + 0x18]
       ||   0x00691df9      ffd0           call eax
       ||   0x00691dfb      83c404         add esp, 4
       ``-> 0x00691dfe      8b4c242c       mov ecx, dword [esp + 0x2c]
            0x00691e02      8bc7           mov eax, edi
            0x00691e04      5b             pop ebx
            0x00691e05      5f             pop edi
            0x00691e06      5e             pop esi
            0x00691e07      5d             pop ebp
            0x00691e08      33cc           xor ecx, esp
            0x00691e0a      e8d3920100     call 0x6ab0e2
            0x00691e0f      83c420         add esp, 0x20
            0x00691e12      c3             ret
            0x00691e13      cc             int3
            0x00691e14      cc             int3
            0x00691e15      cc             int3
            0x00691e16      cc             int3
            0x00691e17      cc             int3
            0x00691e18      cc             int3
            0x00691e19      cc             int3
            0x00691e1a      cc             int3
            0x00691e1b      cc             int3
            0x00691e1c      cc             int3
            0x00691e1d      cc             int3
            0x00691e1e      cc             int3
            0x00691e1f      cc             int3
            0x00691e20      8b4c2404       mov ecx, dword [esp + 4]
            0x00691e24      8b4108         mov eax, dword [ecx + 8]
            0x00691e27      85c0           test eax, eax
            0x00691e29      7501           jne 0x691e2c
            0x00691e2b      c3             ret
            0x00691e2c      83f801         cmp eax, 1                  ; 1
            0x00691e2f      7505           jne 0x691e36
            0x00691e31      0fb7410c       movzx eax, word [ecx + 0xc]
            0x00691e35      c3             ret
            0x00691e36      53             push ebx
            0x00691e37      8bd8           mov ebx, eax
            0x00691e39      56             push esi
            0x00691e3a      c1eb1f         shr ebx, 0x1f
            0x00691e3d      33f6           xor esi, esi
            0x00691e3f      84db           test bl, bl
            0x00691e41      7402           je 0x691e45
            0x00691e43      f7d8           neg eax
            0x00691e45      83e801         sub eax, 1
            0x00691e48      57             push edi
            0x00691e49      7821           js 0x691e6c
            0x00691e4b      8d790c         lea edi, [ecx + 0xc]
            0x00691e4e      8d3c47         lea edi, [edi + eax*2]
            0x00691e51      0fb70f         movzx ecx, word [edi]
            0x00691e54      8bd6           mov edx, esi
            0x00691e56      c1e60f         shl esi, 0xf
            0x00691e59      0bf1           or esi, ecx
            0x00691e5b      8bce           mov ecx, esi
            0x00691e5d      c1f90f         sar ecx, 0xf
            0x00691e60      3bca           cmp ecx, edx
            0x00691e62      7515           jne 0x691e79
            0x00691e64      83ef02         sub edi, 2
            0x00691e67      83e801         sub eax, 1
            0x00691e6a      79e5           jns 0x691e51
            0x00691e6c      33c0           xor eax, eax
            0x00691e6e      84db           test bl, bl
            0x00691e70      5f             pop edi
            0x00691e71      0f45f0         cmovne esi, eax
            0x00691e74      8bc6           mov eax, esi
            0x00691e76      5e             pop esi
            0x00691e77      5b             pop ebx
            0x00691e78      c3             ret
            0x00691e79      5f             pop edi
            0x00691e7a      5e             pop esi
            0x00691e7b      83c8ff         or eax, 0xffffffff          ; -1
            0x00691e7e      5b             pop ebx
            0x00691e7f      c3             ret
            0x00691e80      83ec0c         sub esp, 0xc
            0x00691e83      53             push ebx
            0x00691e84      8b5c2414       mov ebx, dword [esp + 0x14]
            0x00691e88      55             push ebp
            0x00691e89      56             push esi
            0x00691e8a      57             push edi
            0x00691e8b      8b7308         mov esi, dword [ebx + 8]
            0x00691e8e      c644241000     mov byte [esp + 0x10], 0
            0x00691e93      85f6           test esi, esi
            0x00691e95      752f           jne 0x691ec6
            0x00691e97      8b35b48b6d00   mov esi, dword [0x6d8bb4]   ; [0x6d8bb4:4]=0x5553460
            0x00691e9d      8b4618         mov eax, dword [esi + 0x18]
            0x00691ea0      ff00           inc dword [eax]
            0x00691ea2      e839e20000     call 0x6a00e0
            0x00691ea7      8bf8           mov edi, eax
            0x00691ea9      8b4618         mov eax, dword [esi + 0x18]
            0x00691eac      894718         mov dword [edi + 0x18], eax
            0x00691eaf      8b461c         mov eax, dword [esi + 0x1c]
            0x00691eb2      89471c         mov dword [edi + 0x1c], eax
            0x00691eb5      c74708000000.  mov dword [edi + 8], 0
            0x00691ebc      8bc7           mov eax, edi
            0x00691ebe      5f             pop edi
            0x00691ebf      5e             pop esi
            0x00691ec0      5d             pop ebp
            0x00691ec1      5b             pop ebx
            0x00691ec2      83c40c         add esp, 0xc
            0x00691ec5      c3             ret
            0x00691ec6      837b1c00       cmp dword [ebx + 0x1c], 0
            0x00691eca      8b4318         mov eax, dword [ebx + 0x18]
            0x00691ecd      0f84e5000000   je 0x691fb8
            0x00691ed3      8b4804         mov ecx, dword [eax + 4]
            0x00691ed6      b856555555     mov eax, 0x55555556         ; 'VUUU'
            0x00691edb      03c9           add ecx, ecx
            0x00691edd      f7e9           imul ecx
            0x00691edf      8bea           mov ebp, edx
            0x00691ee1      c1ed1f         shr ebp, 0x1f
            0x00691ee4      03ea           add ebp, edx
            0x00691ee6      e8f5e10000     call 0x6a00e0
            0x00691eeb      8bf8           mov edi, eax
            0x00691eed      85ed           test ebp, ebp
            0x00691eef      7e73           jle 0x691f64
            0x00691ef1      8b4b18         mov ecx, dword [ebx + 0x18]
            0x00691ef4      33d2           xor edx, edx
            0x00691ef6      8b5c2410       mov ebx, dword [esp + 0x10]
            0x00691efa      894c2418       mov dword [esp + 0x18], ecx
            0x00691efe      896c2414       mov dword [esp + 0x14], ebp
            0x00691f02      8b7104         mov esi, dword [ecx + 4]
            0x00691f05      81feff000000   cmp esi, 0xff               ; 255
            0x00691f0b      7f07           jg 0x691f14
            0x00691f0d      b901000000     mov ecx, 1
            0x00691f12      eb12           jmp 0x691f26
            0x00691f14      33c9           xor ecx, ecx
            0x00691f16      81feffff0000   cmp esi, 0xffff
            0x00691f1c      0f9fc1         setg cl
            0x00691f1f      8d0c4d020000.  lea ecx, [ecx*2 + 2]
            0x00691f26      8bc6           mov eax, esi
            0x00691f28      0fafc1         imul eax, ecx
            0x00691f2b      8b4c2418       mov ecx, dword [esp + 0x18]
            0x00691f2f      03c2           add eax, edx
            0x00691f31      837c081c00     cmp dword [eax + ecx + 0x1c], 0
            0x00691f36      741a           je 0x691f52
            0x00691f38      8b440818       mov eax, dword [eax + ecx + 0x18]
            0x00691f3c      0fb6db         movzx ebx, bl
            0x00691f3f      8b4004         mov eax, dword [eax + 4]
            0x00691f42      8b4054         mov eax, dword [eax + 0x54]
            0x00691f45      c1e81c         shr eax, 0x1c
            0x00691f48      a801           test al, 1                  ; 1
            0x00691f4a      b801000000     mov eax, 1
            0x00691f4f      0f44d8         cmove ebx, eax
            0x00691f52      83c20c         add edx, 0xc                ; 12
            0x00691f55      836c241401     sub dword [esp + 0x14], 1
            0x00691f5a      75a9           jne 0x691f05
            0x00691f5c      895c2410       mov dword [esp + 0x10], ebx
            0x00691f60      8b5c2420       mov ebx, dword [esp + 0x20]
            0x00691f64      8d04ad000000.  lea eax, [ebp*4]
            0x00691f6b      50             push eax
            0x00691f6c      ff159c116c00   call dword [0x6c119c]
            0x00691f72      89471c         mov dword [edi + 0x1c], eax
            0x00691f75      83c404         add esp, 4
            0x00691f78      8b4318         mov eax, dword [ebx + 0x18]
            0x00691f7b      33d2           xor edx, edx
            0x00691f7d      894718         mov dword [edi + 0x18], eax
            0x00691f80      8b4308         mov eax, dword [ebx + 8]
            0x00691f83      894708         mov dword [edi + 8], eax
            0x00691f86      8b4318         mov eax, dword [ebx + 0x18]
            0x00691f89      ff00           inc dword [eax]
            0x00691f8b      85ed           test ebp, ebp
            0x00691f8d      0f8ef4000000   jle 0x692087
            0x00691f93      8b431c         mov eax, dword [ebx + 0x1c]
            0x00691f96      8b0c90         mov ecx, dword [eax + edx*4]
            0x00691f99      8b471c         mov eax, dword [edi + 0x1c]
            0x00691f9c      85c9           test ecx, ecx
            0x00691f9e      7407           je 0x691fa7
            0x00691fa0      890c90         mov dword [eax + edx*4], ecx
            0x00691fa3      ff01           inc dword [ecx]
            0x00691fa5      eb07           jmp 0x691fae
            0x00691fa7      c70490000000.  mov dword [eax + edx*4], 0
            0x00691fae      42             inc edx
            0x00691faf      3bd5           cmp edx, ebp
            0x00691fb1      7ce0           jl 0x691f93
            0x00691fb3      e9cf000000     jmp 0x692087
            0x00691fb8      8b4810         mov ecx, dword [eax + 0x10]
            0x00691fbb      b856555555     mov eax, 0x55555556         ; 'VUUU'
            0x00691fc0      03c9           add ecx, ecx
            0x00691fc2      f7e9           imul ecx
            0x00691fc4      8bc2           mov eax, edx
            0x00691fc6      c1e81f         shr eax, 0x1f
            0x00691fc9      03c2           add eax, edx
            0x00691fcb      3bf0           cmp esi, eax
            0x00691fcd      0f8ce5000000   jl 0x6920b8
            0x00691fd3      e808e10000     call 0x6a00e0
            0x00691fd8      8bf8           mov edi, eax
            0x00691fda      c7471c000000.  mov dword [edi + 0x1c], 0
            0x00691fe1      8b4308         mov eax, dword [ebx + 8]
            0x00691fe4      894708         mov dword [edi + 8], eax
            0x00691fe7      ff7318         push dword [ebx + 0x18]
            0x00691fea      e811040100     call 0x6a2400
            0x00691fef      8bf0           mov esi, eax
            0x00691ff1      56             push esi
            0x00691ff2      ff15d0116c00   call dword [0x6c11d0]
            0x00691ff8      56             push esi
            0x00691ff9      894718         mov dword [edi + 0x18], eax
            0x00691ffc      ff7318         push dword [ebx + 0x18]
            0x00691fff      50             push eax
            0x00692000      e86b9d0100     call 0x6abd70
            0x00692005      8b5718         mov edx, dword [edi + 0x18]
            0x00692008      83c414         add esp, 0x14
            0x0069200b      8b4a04         mov ecx, dword [edx + 4]
            0x0069200e      81f9ff000000   cmp ecx, 0xff               ; 255
            0x00692014      7f07           jg 0x69201d
            0x00692016      b801000000     mov eax, 1
            0x0069201b      eb12           jmp 0x69202f
            0x0069201d      33c0           xor eax, eax
            0x0069201f      81f9ffff0000   cmp ecx, 0xffff
            0x00692025      0f9fc0         setg al
            0x00692028      8d0445020000.  lea eax, [eax*2 + 2]
            0x0069202f      8be9           mov ebp, ecx
            0x00692031      03c9           add ecx, ecx
            0x00692033      0fafe8         imul ebp, eax
            0x00692036      b856555555     mov eax, 0x55555556         ; 'VUUU'
            0x0069203b      03ea           add ebp, edx
            0x0069203d      f7e9           imul ecx
            0x0069203f      8bda           mov ebx, edx
            0x00692041      c1eb1f         shr ebx, 0x1f
            0x00692044      03da           add ebx, edx
            0x00692046      85db           test ebx, ebx
       ::   0x00692100      0000           add byte [eax], al
      ,===< 0x00692102      eb11           jmp 0x692115
      |::   0x00692104      33c9           xor ecx, ecx
      |::   0x00692106      3dffff0000     cmp eax, 0xffff
      |::   0x0069210b      0f9fc1         setg cl
      |::   0x0069210e      8d0c4d020000.  lea ecx, [ecx*2 + 2]
      `---> 0x00692115      0fafc1         imul eax, ecx
       ::   0x00692118      03c2           add eax, edx
       ::   0x0069211a      8b54301c       mov edx, dword [eax + esi + 0x1c]
       ::   0x0069211e      85d2           test edx, edx
      ,===< 0x00692120      742b           je 0x69214d
      |::   0x00692122      8b4c3018       mov ecx, dword [eax + esi + 0x18]
      |::   0x00692126      52             push edx
      |::   0x00692127      51             push ecx
      |::   0x00692128      57             push edi
      |::   0x00692129      8b4104         mov eax, dword [ecx + 4]
      |::   0x0069212c      8b4054         mov eax, dword [eax + 0x54]
      |::   0x0069212f      c1e81c         shr eax, 0x1c
      |::   0x00692132      a801           test al, 1                  ; 1
      |::   0x00692134      8b44241c       mov eax, dword [esp + 0x1c]
      |::   0x00692138      0fb6c0         movzx eax, al
      |::   0x0069213b      0f4444242c     cmove eax, dword [esp + 0x2c]
      |::   0x00692140      8844241c       mov byte [esp + 0x1c], al
      |::   0x00692144      ff15f4146c00   call dword [0x6c14f4]
      |::   0x0069214a      83c40c         add esp, 0xc
      `---> 0x0069214d      83c60c         add esi, 0xc                ; 12
       ::   0x00692150      83ed01         sub ebp, 1
       `==< 0x00692153      759b           jne 0x6920f0
        :   0x00692155      8b442410       mov eax, dword [esp + 0x10]
        :   0x00692159      84c0           test al, al
        `=< 0x0069215b      0f845bfdffff   je 0x691ebc
            0x00692161      8307ff         add dword [edi], 0xffffffff
        ,=< 0x00692164      750c           jne 0x692172
        |   0x00692166      8b4704         mov eax, dword [edi + 4]
        |   0x00692169      57             push edi
        |   0x0069216a      8b4018         mov eax, dword [eax + 0x18]
        |   0x0069216d      ffd0           call eax
        |   0x0069216f      83c404         add esp, 4
        `-> 0x00692172      5f             pop edi
            0x00692173      5e             pop esi
            0x00692174      5d             pop ebp
            0x00692175      33c0           xor eax, eax
            0x00692177      5b             pop ebx
            0x00692178      83c40c         add esp, 0xc
            0x0069217b      c3             ret
            0x0069217c      cc             int3
            0x0069217d      cc             int3
            0x0069217e      cc             int3
            0x0069217f      cc             int3
            0x00692180      56             push esi
            0x00692181      8b742408       mov esi, dword [esp + 8]
            0x00692185      ff7604         push dword [esi + 4]
            0x00692188      ff35847a6e00   push dword [0x6e7a84]
            0x0069218e      e88d070000     call 0x692920
            0x00692193      83c408         add esp, 8
            0x00692196      85c0           test eax, eax
        ,=< 0x00692198      7419           je 0x6921b3
        |   0x0069219a      3b0520156c00   cmp eax, dword [0x6c1520]   ; [0x6c1520:4]=0x657a00b8
       ,==< 0x006921a0      7506           jne 0x6921a8
       ||   0x006921a2      ff06           inc dword [esi]
       ||   0x006921a4      8bc6           mov eax, esi
       ||   0x006921a6      5e             pop esi
       ||   0x006921a7      c3             ret
       `--> 0x006921a8      8b4008         mov eax, dword [eax + 8]
        |   0x006921ab      56             push esi
        |   0x006921ac      ffd0           call eax
        |   0x006921ae      83c404         add esp, 4
        |   0x006921b1      5e             pop esi
        |   0x006921b2      c3             ret
        `-> 0x006921b3      e83fae0100     call 0x6acff7
            0x006921b8      cc             int3
            0x006921b9      cc             int3
            0x006921ba      cc             int3
            0x006921bb      cc             int3
            0x006921bc      cc             int3
            0x006921bd      cc             int3
            0x006921be      cc             int3
            0x006921bf      cc             int3
            0x006921c0      83ec08         sub esp, 8
            0x006921c3      53             push ebx
            0x006921c4      55             push ebp
            0x006921c5      8b6c2414       mov ebp, dword [esp + 0x14]
            0x006921c9      56             push esi
            0x006921ca      57             push edi
            0x006921cb      8b7508         mov esi, dword [ebp + 8]
            0x006921ce      85f6           test esi, esi
        ,=< 0x006921d0      752f           jne 0x692201
        |   0x006921d2      8b35b48b6d00   mov esi, dword [0x6d8bb4]   ; [0x6d8bb4:4]=0x5553460
        |   0x006921d8      8b4618         mov eax, dword [esi + 0x18]
        |   0x006921db      ff00           inc dword [eax]
        |   0x006921dd      e8fede0000     call 0x6a00e0
        |   0x006921e2      8bf8           mov edi, eax
        |   0x006921e4      8b4618         mov eax, dword [esi + 0x18]
        |   0x006921e7      894718         mov dword [edi + 0x18], eax
        |   0x006921ea      8b461c         mov eax, dword [esi + 0x1c]
        |   0x006921ed      89471c         mov dword [edi + 0x1c], eax
        |   0x006921f0      8bc7           mov eax, edi
        |   0x006921f2      c74708000000.  mov dword [edi + 8], 0
        |   0x006921f9      5f             pop edi
        |   0x006921fa      5e             pop esi
        |   0x006921fb      5d             pop ebp
        |   0x006921fc      5b             pop ebx
        |   0x006921fd      83c408         add esp, 8
        |   0x00692200      c3             ret
        `-> 0x00692201      837d1c00       cmp dword [ebp + 0x1c], 0
            0x00692205      8b4518         mov eax, dword [ebp + 0x18]
            0x00692208      0f84b0000000   je 0x6922be
            0x0069220e      8b4804         mov ecx, dword [eax + 4]
            0x00692211      b856555555     mov eax, 0x55555556         ; 'VUUU'
            0x00692216      03c9           add ecx, ecx
            0x00692218      f7e9           imul ecx
            0x0069221a      8bf2           mov esi, edx
            0x0069221c      c1ee1f         shr esi, 0x1f
            0x0069221f      03f2           add esi, edx
            0x00692221      8974241c       mov dword [esp + 0x1c], esi
            0x00692225      e8b6de0000     call 0x6a00e0
            0x0069222a      8bf8           mov edi, eax
            0x0069222c      8d04b5000000.  lea eax, [esi*4]
            0x00692233      50             push eax
            0x00692234      ff159c116c00   call dword [0x6c119c]
            0x0069223a      89471c         mov dword [edi + 0x1c], eax
            0x0069223d      83c404         add esp, 4
            0x00692240      8b4518         mov eax, dword [ebp + 0x18]
            0x00692243      33db           xor ebx, ebx
            0x00692245      894718         mov dword [edi + 0x18], eax
            0x00692248      8b4508         mov eax, dword [ebp + 8]
            0x0069224b      894708         mov dword [edi + 8], eax
            0x0069224e      8b4518         mov eax, dword [ebp + 0x18]
            0x00692251      ff00           inc dword [eax]
            0x00692253      85f6           test esi, esi
            0x00692255      0f8e1a010000   jle 0x692375
            0x0069225b      0f1f440000     nop dword [eax + eax]
            0x00692260      8b451c         mov eax, dword [ebp + 0x1c]
            0x00692263      8b3498         mov esi, dword [eax + ebx*4]
            0x00692266      85f6           test esi, esi
            0x00692268      743e           je 0x6922a8
            0x0069226a      ff7604         push dword [esi + 4]
            0x0069226d      ff35847a6e00   push dword [0x6e7a84]
            0x00692273      e8a8060000     call 0x692920
            0x00692278      83c408         add esp, 8
            0x0069227b      85c0           test eax, eax
            0x0069227d      0f8404020000   je 0x692487
            0x00692283      3b0520156c00   cmp eax, dword [0x6c1520]   ; [0x6c1520:4]=0x657a00b8
            0x00692289      750a           jne 0x692295
            0x0069228b      ff06           inc dword [esi]
            0x0069228d      8b471c         mov eax, dword [edi + 0x1c]
            0x00692290      893498         mov dword [eax + ebx*4], esi
            0x00692293      eb1d           jmp 0x6922b2
            0x00692295      8b4008         mov eax, dword [eax + 8]
            0x00692298      56             push esi
            0x00692299      ffd0           call eax
            0x0069229b      8bf0           mov esi, eax
            0x0069229d      83c404         add esp, 4
            0x006922a0      8b471c         mov eax, dword [edi + 0x1c]
            0x006922a3      893498         mov dword [eax + ebx*4], esi
            0x006922a6      eb0a           jmp 0x6922b2
            0x006922a8      8b471c         mov eax, dword [edi + 0x1c]
            0x006922ab      c70498000000.  mov dword [eax + ebx*4], 0
            0x006922b2      43             inc ebx
            0x006922b3      3b5c241c       cmp ebx, dword [esp + 0x1c]
            0x006922b7      7ca7           jl 0x692260
            0x006922b9      e9b7000000     jmp 0x692375
            0x006922be      8b4810         mov ecx, dword [eax + 0x10]
            0x006922c1      b856555555     mov eax, 0x55555556         ; 'VUUU'
            0x006922c6      03c9           add ecx, ecx
            0x006922c8      f7e9           imul ecx
            0x006922ca      8bc2           mov eax, edx
            0x006922cc      c1e81f         shr eax, 0x1f
            0x006922cf      03c2           add eax, edx
            0x006922d1      3bf0           cmp esi, eax
            0x006922d3      0f8cd2000000   jl 0x6923ab
            0x006922d9      e802de0000     call 0x6a00e0
            0x006922de      8bf8           mov edi, eax
            0x006922e0      c7471c000000.  mov dword [edi + 0x1c], 0
            0x006922e7      8b4508         mov eax, dword [ebp + 8]
            0x006922ea      894708         mov dword [edi + 8], eax
            0x006922ed      ff7518         push dword [ebp + 0x18]
            0x006922f0      e80b010100     call 0x6a2400
            0x006922f5      8bf0           mov esi, eax
            0x006922f7      56             push esi
            0x006922f8      ff15d0116c00   call dword [0x6c11d0]
            0x006922fe      56             push esi
            0x006922ff      894718         mov dword [edi + 0x18], eax
            0x00692302      ff7518         push dword [ebp + 0x18]
            0x00692305      50             push eax
            0x00692306      e8659a0100     call 0x6abd70
            0x0069230b      8b5718         mov edx, dword [edi + 0x18]
            0x0069230e      83c414         add esp, 0x14
            0x00692311      8b4a04         mov ecx, dword [edx + 4]
            0x00692314      81f9ff000000   cmp ecx, 0xff               ; 255
            0x0069231a      7f07           jg 0x692323
            0x0069231c      b801000000     mov eax, 1
            0x00692321      eb12           jmp 0x692335
            0x00692323      33c0           xor eax, eax
            0x00692325      81f9ffff0000   cmp ecx, 0xffff
            0x0069232b      0f9fc0         setg al
            0x0069232e      8d0445020000.  lea eax, [eax*2 + 2]
            0x00692335      8be9           mov ebp, ecx
            0x00692337      03c9           add ecx, ecx
            0x00692339      0fafe8         imul ebp, eax
            0x005ca020      055f33c05e     add eax, 0x5ec0335f
            0x005ca025      c3             ret
            0x005ca026      8b471c         mov eax, dword [edi + 0x1c]
            0x005ca029      85c0           test eax, eax
        ,=< 0x005ca02b      7406           je 0x5ca033
        |   0x005ca02d      5f             pop edi
        |   0x005ca02e      8d04b0         lea eax, [eax + esi*4]
        |   0x005ca031      5e             pop esi
        |   0x005ca032      c3             ret
        `-> 0x005ca033      8b5718         mov edx, dword [edi + 0x18]
            0x005ca036      8b4a04         mov ecx, dword [edx + 4]
            0x005ca039      81f9ff000000   cmp ecx, 0xff               ; 255
        ,=< 0x005ca03f      7f19           jg 0x5ca05a
        |   0x005ca041      b801000000     mov eax, 1
        |   0x005ca046      0fafc8         imul ecx, eax
        |   0x005ca049      8d0475070000.  lea eax, [esi*2 + 7]
        |   0x005ca050      5f             pop edi
        |   0x005ca051      03ca           add ecx, edx
        |   0x005ca053      03c6           add eax, esi
        |   0x005ca055      5e             pop esi
        |   0x005ca056      8d0481         lea eax, [ecx + eax*4]
        |   0x005ca059      c3             ret
        `-> 0x005ca05a      33c0           xor eax, eax
            0x005ca05c      81f9ffff0000   cmp ecx, 0xffff
            0x005ca062      5f             pop edi
            0x005ca063      0f9fc0         setg al
            0x005ca066      8d0445020000.  lea eax, [eax*2 + 2]
            0x005ca06d      0fafc8         imul ecx, eax
            0x005ca070      8d0475070000.  lea eax, [esi*2 + 7]
            0x005ca077      03c6           add eax, esi
            0x005ca079      5e             pop esi
            0x005ca07a      03ca           add ecx, edx
            0x005ca07c      8d0481         lea eax, [ecx + eax*4]
            0x005ca07f      c3             ret
            0x005ca080      803de0336e00.  cmp byte [0x6e33e0], 0      ; [0x6e33e0:1]=1
            0x005ca087      53             push ebx
            0x005ca088      8b5c2408       mov ebx, dword [esp + 8]
            0x005ca08c      55             push ebp
            0x005ca08d      56             push esi
            0x005ca08e      57             push edi
            0x005ca08f      891d94336e00   mov dword [0x6e3394], ebx   ; [0x6e3394:4]=0x7ade438
        ,=< 0x005ca095      7561           jne 0x5ca0f8
        |   0x005ca097      803da0336e00.  cmp byte [0x6e33a0], 0      ; [0x6e33a0:1]=1
       ,==< 0x005ca09e      7519           jne 0x5ca0b9
       ||   0x005ca0a0      6884216c00     push 0x6c2184               ; "cffi.lock"
       ||   0x005ca0a5      68a4336e00     push 0x6e33a4
       ||   0x005ca0aa      e8e1f10d00     call 0x6a9290
       ||   0x005ca0af      83c408         add esp, 8
       ||   0x005ca0b2      c605a0336e00.  mov byte [0x6e33a0], 1      ; [0x6e33a0:1]=1
       `--> 0x005ca0b9      ff35d0336e00   push dword [0x6e33d0]
        |   0x005ca0bf      e8dcaf0c00     call 0x6950a0
        |   0x005ca0c4      6a00           push 0
        |   0x005ca0c6      6a00           push 0
        |   0x005ca0c8      6a00           push 0
        |   0x005ca0ca      6a00           push 0
        |   0x005ca0cc      6a00           push 0
        |   0x005ca0ce      ff35d4336e00   push dword [0x6e33d4]
        |   0x005ca0d4      a39c336e00     mov dword [0x6e339c], eax   ; [0x6e339c:4]=0x7ada330
        |   0x005ca0d9      6a40           push 0x40                   ; '@' ; 64
        |   0x005ca0db      6a01           push 1                      ; 1
        |   0x005ca0dd      50             push eax
        |   0x005ca0de      e86df80d00     call 0x6a9950
        |   0x005ca0e3      8b1d94336e00   mov ebx, dword [0x6e3394]   ; [0x6e3394:4]=0x7ade438
        |   0x005ca0e9      83c428         add esp, 0x28
        |   0x005ca0ec      a3dc336e00     mov dword [0x6e33dc], eax   ; [0x6e33dc:4]=0x7ae0978
        |   0x005ca0f1      c605e0336e00.  mov byte [0x6e33e0], 1      ; [0x6e33e0:1]=1
        `-> 0x005ca0f8      8b2d248c6d00   mov ebp, dword [0x6d8c24]   ; [0x6d8c24:4]=0x55534a8
            0x005ca0fe      8b5b08         mov ebx, dword [ebx + 8]
            0x005ca101      8b3d0c8d6d00   mov edi, dword [0x6d8d0c]   ; [0x6d8d0c:4]=0x554c1d8
            0x005ca107      55             push ebp
            0x005ca108      53             push ebx
            0x005ca109      891d98336e00   mov dword [0x6e3398], ebx   ; [0x6e3398:4]=0x7ade398
            0x005ca10f      e8ccfeffff     call 0x5c9fe0
            0x005ca114      8b35f4146c00   mov esi, dword [0x6c14f4]   ; [0x6c14f4:4]=0x654e4a20
            0x005ca11a      83c408         add esp, 8
            0x005ca11d      85c0           test eax, eax
            0x005ca11f      741d           je 0x5ca13e
            0x005ca121      8b08           mov ecx, dword [eax]
            0x005ca123      85c9           test ecx, ecx
            0x005ca125      7417           je 0x5ca13e
            0x005ca127      ff07           inc dword [edi]
            0x005ca129      8938           mov dword [eax], edi
            0x005ca12b      8301ff         add dword [ecx], 0xffffffff
            0x005ca12e      7516           jne 0x5ca146
            0x005ca130      8b4104         mov eax, dword [ecx + 4]
            0x005ca133      51             push ecx
            0x005ca134      8b4018         mov eax, dword [eax + 0x18]
            0x005ca137      ffd0           call eax
            0x005ca139      83c404         add esp, 4
            0x005ca13c      eb08           jmp 0x5ca146
            0x005ca13e      57             push edi
            0x005ca13f      55             push ebp
            0x005ca140      53             push ebx
            0x005ca141      ffd6           call esi
            0x005ca143      83c40c         add esp, 0xc
            0x005ca146      ff35e48b6d00   push dword [0x6d8be4]
            0x005ca14c      ff3598336e00   push dword [0x6e3398]
            0x005ca152      e889feffff     call 0x5c9fe0
            0x005ca157      83c408         add esp, 8
            0x005ca15a      85c0           test eax, eax
