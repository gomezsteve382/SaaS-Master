import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Upload, Search, Copy, Download, X } from 'lucide-react';

interface VINLocation {
  offset: number;
  vin: string;
  crc?: string;
  status: 'valid' | 'invalid' | 'unknown';
}

interface FileAnalysis {
  id: string;
  fileName: string;
  fileSize: number;
  fileType: 'rfhub' | 'bcm' | 'unknown';
  vinLocations: VINLocation[];
  hexData: Uint8Array;
}

interface BatchComparison {
  vin: string;
  offsets: Map<string, number[]>;
  hasVariance: boolean;
}

const EEPROMVisualizer: React.FC = () => {
  const [analysis, setAnalysis] = useState<FileAnalysis | null>(null);
  const [batchAnalyses, setBatchAnalyses] = useState<FileAnalysis[]>([]);
  const [selectedOffset, setSelectedOffset] = useState<number | null>(null);
  const [batchMode, setBatchMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const batchFileInputRef = useRef<HTMLInputElement>(null);

  // CRC16-CCITT-FALSE calculation (BCM, ECM, Gateway)
  const calculateCRC16 = (data: Uint8Array): number => {
    let crc = 0xFFFF;
    const poly = 0x1021;
    for (let byte of data) {
      crc ^= (byte << 8);
      for (let i = 0; i < 8; i++) {
        crc <<= 1;
        if (crc & 0x10000) {
          crc ^= poly;
        }
        crc &= 0xFFFF;
      }
    }
    return crc;
  };

  // XOR checksum (RFHUB ST95640)
  const calculateXOR = (data: Uint8Array): number => {
    let result = 0;
    for (let byte of data) {
      result ^= byte;
    }
    return result;
  };

  // Detect file type from size
  const detectFileType = (size: number): 'rfhub' | 'bcm' | 'unknown' => {
    if (size === 8192 || size === 16384) return 'rfhub';
    if (size === 65536 || size === 131072) return 'bcm';
    return 'unknown';
  };

  // Analyze file
  const analyzeFile = async (file: File): Promise<FileAnalysis> => {
    const arrayBuffer = await file.arrayBuffer();
    const hexData = new Uint8Array(arrayBuffer);

    // Detect file type FIRST so CRC algo can be chosen correctly
    const fileType = detectFileType(hexData.length);

    const vinLocations: VINLocation[] = [];

    // Search for VIN patterns
    for (let i = 0; i < hexData.length - 17; i++) {
      const chunk = hexData.slice(i, i + 17);
      const str = new TextDecoder().decode(chunk);
      
      if (/^[1-9A-HJ-NPR-Z]{3}[0-9A-HJ-NPR-Z]{14}$/.test(str)) {
        if (fileType === 'rfhub') {
          // RFHUB uses single-byte XOR checksum at VIN+17
          const storedXor = hexData[i + 17] ?? 0;
          const calculatedXor = calculateXOR(chunk);
          vinLocations.push({
            offset: i,
            vin: str,
            crc: `0x${storedXor.toString(16).toUpperCase().padStart(2, '0')}`,
            status: storedXor === calculatedXor ? 'valid' : 'invalid',
          });
        } else {
          // BCM / ECM / Gateway: CRC16-CCITT-FALSE big-endian at VIN+17
          const crcBytes = hexData.slice(i + 17, i + 19);
          const crc = (crcBytes[0] << 8) | crcBytes[1];
          const calculatedCrc = calculateCRC16(chunk);
          vinLocations.push({
            offset: i,
            vin: str,
            crc: `0x${crc.toString(16).toUpperCase().padStart(4, '0')}`,
            status: crc === calculatedCrc ? 'valid' : 'invalid',
          });
        }
      }
    }

    return {
      id: `${file.name}-${Date.now()}`,
      fileName: file.name,
      fileSize: hexData.length,
      fileType,
      vinLocations,
      hexData,
    };
  };

  // Single file upload
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const result = await analyzeFile(file);
    setAnalysis(result);
    setSelectedOffset(null);
    setBatchMode(false);
  };

  // Batch file upload
  const handleBatchUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const results: FileAnalysis[] = [];
    for (let i = 0; i < files.length; i++) {
      const result = await analyzeFile(files[i]);
      results.push(result);
    }

    setBatchAnalyses(results);
    setBatchMode(true);
  };

  // Detect variance in offsets
  const detectVariance = (): BatchComparison[] => {
    const vinMap = new Map<string, Map<string, number[]>>();

    // Group by VIN
    batchAnalyses.forEach((analysis) => {
      analysis.vinLocations.forEach((loc) => {
        if (!vinMap.has(loc.vin)) {
          vinMap.set(loc.vin, new Map());
        }
        const offsetMap = vinMap.get(loc.vin)!;
        if (!offsetMap.has(analysis.fileName)) {
          offsetMap.set(analysis.fileName, []);
        }
        offsetMap.get(analysis.fileName)!.push(loc.offset);
      });
    });

    // Detect variance
    const comparisons: BatchComparison[] = [];
    vinMap.forEach((offsetMap, vin) => {
      const offsets = Array.from(offsetMap.values()).flat();
      const hasVariance = new Set(offsets).size > 1;
      comparisons.push({
        vin,
        offsets: offsetMap,
        hasVariance,
      });
    });

    return comparisons;
  };

  // Export batch results as CSV
  const exportBatchCSV = () => {
    const comparisons = detectVariance();
    let csv = 'VIN,File,Offsets,Variance\n';

    comparisons.forEach((comp) => {
      comp.offsets.forEach((offsets, fileName) => {
        const offsetStr = offsets.map((o) => `0x${o.toString(16).toUpperCase()}`).join(';');
        csv += `${comp.vin},${fileName},"${offsetStr}",${comp.hasVariance ? 'YES' : 'NO'}\n`;
      });
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `batch-analysis-${Date.now()}.csv`;
    a.click();
  };

  // Render hex dump
  const renderHexDump = (hexData: Uint8Array) => {
    const rows = [];
    const bytesPerRow = 16;

    for (let i = 0; i < hexData.length; i += bytesPerRow) {
      const offset = i;
      const bytes = hexData.slice(i, Math.min(i + bytesPerRow, hexData.length));
      
      const isHighlighted = selectedOffset !== null && 
        selectedOffset >= offset && 
        selectedOffset < offset + bytesPerRow;

      rows.push(
        <div
          key={offset}
          className={`font-mono text-sm p-2 rounded ${
            isHighlighted ? 'bg-red-900/30 border-l-2 border-red-500' : 'hover:bg-gray-800/50'
          }`}
          onClick={() => setSelectedOffset(offset)}
        >
          <span className="text-gray-500 mr-4">{offset.toString(16).toUpperCase().padStart(6, '0')}</span>
          <span className="text-cyan-400">
            {Array.from(bytes)
              .map((b) => b.toString(16).toUpperCase().padStart(2, '0'))
              .join(' ')}
          </span>
          <span className="text-gray-600 ml-4">
            {new TextDecoder('utf-8', { fatal: false }).decode(bytes)
              .replace(/[^\x20-\x7E]/g, '.')}
          </span>
        </div>
      );
    }

    return <div className="space-y-1 max-h-96 overflow-y-auto font-mono text-xs">{rows}</div>;
  };

  // Render VIN table
  const renderVINTable = (analysis: FileAnalysis) => {
    if (analysis.vinLocations.length === 0) {
      return <Alert><AlertDescription>No VIN locations found</AlertDescription></Alert>;
    }

    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-gray-700">
            <tr>
              <th className="text-left p-2">Offset</th>
              <th className="text-left p-2">VIN</th>
              <th className="text-left p-2">CRC</th>
              <th className="text-left p-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {analysis.vinLocations.map((loc, idx) => (
              <tr
                key={idx}
                className="border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer"
                onClick={() => setSelectedOffset(loc.offset)}
              >
                <td className="p-2 font-mono text-cyan-400">0x{loc.offset.toString(16).toUpperCase().padStart(6, '0')}</td>
                <td className="p-2 font-mono">{loc.vin}</td>
                <td className="p-2 font-mono text-yellow-400">{loc.crc || 'N/A'}</td>
                <td className="p-2">
                  <Badge className={loc.status === 'valid' ? 'bg-green-900' : 'bg-red-900'}>
                    {loc.status}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  // Render batch comparison table
  const renderBatchComparison = () => {
    const comparisons = detectVariance();

    if (comparisons.length === 0) {
      return <Alert><AlertDescription>No VINs found in batch</AlertDescription></Alert>;
    }

    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-400">
            Found {comparisons.length} unique VINs across {batchAnalyses.length} files
          </div>
          <Button onClick={exportBatchCSV} className="gap-2">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-gray-700">
              <tr>
                <th className="text-left p-2">VIN</th>
                <th className="text-left p-2">Variance</th>
                {batchAnalyses.map((analysis) => (
                  <th key={analysis.id} className="text-left p-2 text-xs">{analysis.fileName}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparisons.map((comp, idx) => (
                <tr
                  key={idx}
                  className={`border-b border-gray-800 ${
                    comp.hasVariance ? 'bg-yellow-900/20' : ''
                  }`}
                >
                  <td className="p-2 font-mono">{comp.vin}</td>
                  <td className="p-2">
                    <Badge className={comp.hasVariance ? 'bg-yellow-900' : 'bg-green-900'}>
                      {comp.hasVariance ? 'VARIANCE' : 'MATCH'}
                    </Badge>
                  </td>
                  {batchAnalyses.map((analysis) => {
                    const offsets = comp.offsets.get(analysis.fileName) || [];
                    return (
                      <td key={analysis.id} className="p-2 font-mono text-xs">
                        {offsets.length > 0 ? (
                          <div className="space-y-1">
                            {offsets.map((offset, i) => (
                              <div key={i} className="text-cyan-400">
                                0x{offset.toString(16).toUpperCase().padStart(6, '0')}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">EEPROM Visualizer</h1>
        <p className="text-gray-400 mt-2">Analyze and compare VIN locations in EEPROM and BCM D-Flash files</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle>Single File</CardTitle>
            <CardDescription>Upload one file for detailed analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => fileInputRef.current?.click()} className="w-full gap-2">
              <Upload className="w-4 h-4" />
              Upload File
            </Button>
            <Input
              ref={fileInputRef}
              type="file"
              accept=".bin,.BIN"
              onChange={handleFileUpload}
              className="hidden"
            />
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle>Batch Analysis</CardTitle>
            <CardDescription>Upload multiple files to compare</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => batchFileInputRef.current?.click()} className="w-full gap-2">
              <Upload className="w-4 h-4" />
              Upload Multiple
            </Button>
            <Input
              ref={batchFileInputRef}
              type="file"
              accept=".bin,.BIN"
              multiple
              onChange={handleBatchUpload}
              className="hidden"
            />
          </CardContent>
        </Card>
      </div>

      {batchMode && batchAnalyses.length > 0 ? (
        <>
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Batch Comparison</CardTitle>
                  <CardDescription>{batchAnalyses.length} files loaded</CardDescription>
                </div>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setBatchMode(false);
                    setBatchAnalyses([]);
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {renderBatchComparison()}
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            {batchAnalyses.map((analysis) => (
              <Card key={analysis.id} className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-lg">{analysis.fileName}</CardTitle>
                  <CardDescription>
                    {(analysis.fileSize / 1024).toFixed(2)} KB • {analysis.fileType.toUpperCase()} • {analysis.vinLocations.length} VINs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="vins" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="vins">VINs</TabsTrigger>
                      <TabsTrigger value="hex">Hex</TabsTrigger>
                    </TabsList>
                    <TabsContent value="vins">
                      {renderVINTable(analysis)}
                    </TabsContent>
                    <TabsContent value="hex">
                      {renderHexDump(analysis.hexData)}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      ) : analysis ? (
        <>
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle>File Info</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-gray-400 text-sm">File Name</p>
                  <p className="font-mono">{analysis.fileName}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">File Size</p>
                  <p className="font-mono">{(analysis.fileSize / 1024).toFixed(2)} KB</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Type</p>
                  <Badge className="mt-1">
                    {analysis.fileType === 'rfhub' ? 'RFHUB ST95640' : analysis.fileType === 'bcm' ? 'BCM D-Flash' : 'Unknown'}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="vins" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="vins">VIN Locations ({analysis.vinLocations.length})</TabsTrigger>
              <TabsTrigger value="hex">Hex Dump</TabsTrigger>
            </TabsList>

            <TabsContent value="vins">
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="pt-6">
                  {renderVINTable(analysis)}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="hex">
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="pt-6">
                  {renderHexDump(analysis.hexData)}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Alert>
          <AlertDescription>Upload a file or multiple files to get started</AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default EEPROMVisualizer;
