/**
 * CRC Worker — runs CRC16/CRC32 and hex diff in a background thread
 * so large EEPROM operations never block the UI.
 */

import type { CRCWorkerRequest, CRCWorkerResponse } from "../lib/workerPool";

// CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflect)
function crc16(data: Uint8Array, start: number, end: number): number {
  let crc = 0xffff;
  for (let i = start; i < end; i++) {
    crc ^= data[i] << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc;
}

// CRC-32 (IEEE 802.3)
function buildCRC32Table(): Uint32Array {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c;
  }
  return table;
}

const CRC32_TABLE = buildCRC32Table();

function crc32(data: Uint8Array, start: number, end: number): number {
  let crc = 0xffffffff;
  for (let i = start; i < end; i++) {
    crc = CRC32_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Hex diff — find all changed bytes between two EEPROM dumps
function hexDiff(
  oldData: Uint8Array,
  newData: Uint8Array
): Array<{ offset: number; oldVal: number; newVal: number }> {
  const changes: Array<{ offset: number; oldVal: number; newVal: number }> = [];
  const len = Math.min(oldData.length, newData.length);
  for (let i = 0; i < len; i++) {
    if (oldData[i] !== newData[i]) {
      changes.push({ offset: i, oldVal: oldData[i], newVal: newData[i] });
    }
  }
  return changes;
}

// Parse Intel HEX format
function parseHex(text: string): { bytes: Uint8Array; error?: string } {
  try {
    const lines = text.trim().split(/\r?\n/);
    const segments: Array<{ addr: number; data: Uint8Array }> = [];
    let maxAddr = 0;
    let baseAddr = 0;

    for (let lineNum = 0; lineNum < lines.length; lineNum++) {
      const line = lines[lineNum];
      if (!line.startsWith(":")) continue;

      // Minimum valid record: ":" + 2(count) + 4(addr) + 2(type) + 2(checksum) = 11 chars
      const rawLen = line.length;
      if (rawLen < 11 || rawLen % 2 === 0) {
        return { bytes: new Uint8Array(0), error: `Line ${lineNum + 1}: invalid record length` };
      }

      const byteCount = parseInt(line.slice(1, 3), 16);
      const addr = parseInt(line.slice(3, 7), 16);
      const recType = parseInt(line.slice(7, 9), 16);

      // Verify expected length: ":" + (byteCount + 4 header bytes + 1 checksum byte) * 2
      const expectedLen = 1 + (byteCount + 5) * 2;
      if (rawLen < expectedLen) {
        return { bytes: new Uint8Array(0), error: `Line ${lineNum + 1}: truncated record (expected ${expectedLen} chars, got ${rawLen})` };
      }

      // Validate record checksum — sum of ALL bytes (count, addr hi/lo, type, data, checksum) must equal 0x00
      let sum = 0;
      const totalRecordBytes = byteCount + 5; // count + addrH + addrL + type + data[byteCount] + checksum
      for (let i = 0; i < totalRecordBytes; i++) {
        sum += parseInt(line.slice(1 + i * 2, 3 + i * 2), 16);
      }
      if ((sum & 0xFF) !== 0) {
        const storedChecksum = parseInt(line.slice(9 + byteCount * 2, 11 + byteCount * 2), 16);
        const computedChecksum = ((~(sum - storedChecksum) + 1) & 0xFF);
        return {
          bytes: new Uint8Array(0),
          error: `Line ${lineNum + 1}: checksum mismatch (stored 0x${storedChecksum.toString(16).toUpperCase().padStart(2, "0")}, expected 0x${computedChecksum.toString(16).toUpperCase().padStart(2, "0")})`,
        };
      }

      if (recType === 0x00) {
        // Data record
        const data = new Uint8Array(byteCount);
        for (let i = 0; i < byteCount; i++) {
          data[i] = parseInt(line.slice(9 + i * 2, 11 + i * 2), 16);
        }
        const absAddr = baseAddr + addr;
        segments.push({ addr: absAddr, data });
        maxAddr = Math.max(maxAddr, absAddr + byteCount);
      } else if (recType === 0x02) {
        // Extended segment address
        baseAddr = parseInt(line.slice(9, 13), 16) << 4;
      } else if (recType === 0x04) {
        // Extended linear address
        baseAddr = parseInt(line.slice(9, 13), 16) << 16;
      } else if (recType === 0x01) {
        // End-of-file record
        break;
      }
    }

    const bytes = new Uint8Array(maxAddr).fill(0xff);
    for (const seg of segments) {
      bytes.set(seg.data, seg.addr);
    }
    return { bytes };
  } catch (e) {
    return {
      bytes: new Uint8Array(0),
      error: e instanceof Error ? e.message : "Parse error",
    };
  }
}

self.onmessage = (e: MessageEvent<CRCWorkerRequest>) => {
  const req = e.data;
  let response: CRCWorkerResponse;

  switch (req.type) {
    case "crc16":
      response = { type: "crc16", result: crc16(req.data, req.start, req.end) };
      break;
    case "crc32":
      response = { type: "crc32", result: crc32(req.data, req.start, req.end) };
      break;
    case "hexDiff":
      response = { type: "hexDiff", changes: hexDiff(req.oldData, req.newData) };
      break;
    case "parseHex": {
      const { bytes, error } = parseHex(req.text);
      response = { type: "parseHex", bytes, error };
      break;
    }
    default:
      return;
  }

  self.postMessage(response);
};
