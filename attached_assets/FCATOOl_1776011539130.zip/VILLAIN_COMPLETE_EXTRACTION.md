# ECU-VILLAIN — COMPLETE REVERSE ENGINEERING EXTRACTION
# From memory dump: VILLAIN_protected_patched.DMP (173MB)
# Date: 2026-04-12

## KEY CONSTANTS EXTRACTED

### GPEC1 Seed Calculator
- KEY_CONSTANT: 670269
- Function: _gpec_1_seed_calculator
- Variables: key, seed (uses genexpr with wiwlwkwywzwal pattern)

### GPEC2 Seed Calculator  
- Function: _gpec_calculator
- Security access levels: 0x05/0x10 (request/response)
- Sub-functions: gpec2_flash, gpec2_eprom, gpec3_eprom, gpec2_2015_eprom, gpec2a_eprom

### NGC (Next Generation Controller) Seed Calculator
- Function: ngc_unlock, ngc_unlock_level5, ngc_trans_unlock_level5
- Variables: TABLE, KEY_CONSTANT, seedInt, tempSeedInt, TL1-TL5, keyInt
- Sub-function: shift_format (with v8, v10 parameters)
- Uses lookup tables with seed_a, seed_b, num0-num11

### Cummins Seed Calculator
- Function: seed_key_calculator_cummins
- Entry via security access 0x0C

### JTEC Unlock
- Function: jtec_unlock
- Entry: security access 0x34
- Key value: "0000"
- Sub-functions: send_jtec_calculated_key

### EPS (Electric Power Steering) Unlock
- Function: eps_unlock, _eps_calculator
- Diagnostic session: 0x67
- Seed request DID: 0x6706
- Variables: calc_one, calc_two, seed, temp_seed, shifted_seed, key
- Security access level: 0x60

### Security Access Level Map (from EcuUnlocks):
Level Group 1: 0x05 request / 0x10 response
Level Group 2: 0x02 request / 0x82 response  
Level Group 3: 0x08 request / 0x88 response
Level Group 4: 0x22,0x23,0x24,0x25,0x26,0x42,0x45,0x44,0x60,0x61,0x62,0x66,0x67,0x6B,0x6C,0x6D

### Security Access Dispatch:
- gpec2: uses _gpec_calculator
- ngc_unlock: level 0x08
- cummins: seed_key_calculator_cummins
- gpec1: _gpec_1_seed_calculator  
- ngc levels 0x80,0x01,0x81: ngc_unlock_level5
- gpec2_flash: specific q-constants
- gpec2_eprom: specific q-constants
- gpec3_eprom: specific q-constants
- gpec2_2015_eprom: specific q-constants
- gpec2a_eprom: specific q-constants
- jtec_unlock: level 0x34, key "0000"
- Additional level: 0x42,0x44,0x36 → gpec2

## TIPM Unlock Tables
- t8001: lookup table (security access 0x80)
- t3605: lookup table (access 0x05, paired with 0x36)
- t3608: lookup table (access 0x08)
- t0807: lookup table
- t8101: lookup table (access 0x81), has get_table_idx sub-function
- t3c: lookup table (access 0x3C)
- tc605: lookup table (C6 prefix)
- TIPM types: TIPM6, TIPM7, TIPM7S, TIPM8, BCM-KJ, BCM-CS, FCM

## VIN DIDs (Data Identifiers)
- 0x7B90: Current VIN (read/write)
- 0x7B88: Original VIN (read/write)
- 0x6E2025: Bus Transmitted VIN
- 0x6E2027: WCM Configured VIN
- 0x6E9EB0: SKIM State
- 0x6EF190: EPS VIN
- 0xF79EB045: SKIM state flag (SCI-B)

## ECU Protocol Support
- CAN 11-bit: CHRYSLER ECU CAN 11-BIT
- CAN 29-bit: CHRYSLER ECU CAN 29-BIT
- SCI-A ENGINE: CHRYSLER ECU SCI A ENGINE
- SCI-B ENGINE: CHRYSLER ECU SCI B ENGINE
- CHRYSLER TIPM
- EPS (Electric Power Steering)

## ECU Operations
### VIN:
- get_current_vin, write_current_vin
- get_original_vin, write_original_vin
- get_bus_transmitted_vin, write_bus_transmitted_vin
- get_wcm_configured_vin, write_win_configured_vin

### SKIM/Immobilizer:
- get_skim_state (DID 0x6E9EB0): returns 0x80=Enabled, 0x00=Disabled
- enable_skim, disable_skim
- get_skim_keys, write_skim_keys (6 keys)
- get_immo_keys, write_immo_keys (6 immobilizer keys)

### Mileage/SRI:
- get_sri_mileage (with calculate_sri function)
- write_sri_mileage
- Uses E2 prefix for SRI write

### EPROM:
- can_read_eprom, can_write_eprom
- eprom_data_collection
- save_eprom_to_file

### Flash/Tuner:
- tuner_flash_tab
- tuner_unlock_boot_button (bootloader unlock)
- tuner_write_ecu_button, tuner_read_ecu_button
- tuner_write_eprom_button, tuner_read_eprom_button

## Supplier Database
Major suppliers found: Continental, Bosch, Denso, Delphi, TRW, ZF, Becker, 
Blaupunkt, Hughes, Gigatronik, Hella, Lucas, Motorola, Valeo, Magna, etc.

## Microcontroller Database  
Found references to: HC08, HC12, ST9, SH7055SF, V850E, UPD780814GC, 
78K0816, MB90549, MB90598, M30810MCT, H8S/2646, MH8303, STAR 12

## Vehicle Database
- DCA, DCS, DCX, MMC (MMC / Smart)
- Vehicle lines with 2-letter codes (CS, CT, DR, HB, JC, JK, KL, LC, etc.)
- Body codes mapped to vehicle types
- Country codes (USA, Europe, Canada, England, Japan, Germany, etc.)

## J2534 PassThru Communication
- Registry path: Software\PassThruSupport.04.04\ and Wow6432Node variant
- Protocol support: CAN, ISO14230, ISO15765, SCI_A_ENGINE, SCI_B_ENGINE
- Baud rates: CAN_125k, CAN_250k, CAN_500k, SCI rates
- Filter types: PASS, BLOCK, FLOW_CONTROL
- Full PassThru API: Open, Close, Connect, Disconnect, ReadMsgs, WriteMsgs, 
  StartMsgFilter, StopMsgFilter, SetProgrammingVoltage, ReadVersion, GetLastError,
  Ioctl

## Cryptodome Usage
- AES encryption (Cryptodome.Cipher.AES)
- Padding (Cryptodome.Util.Padding.unpad)
- Used for license validation

## Anti-Debug
- detect_debugger, detect_debugger2
- IsDebuggerPresent (kernel32)
- TerminateProcess / GetCurrentProcess
- PYDEVD_LOAD_VALUES_ASYNC check (PyCharm debugger detection)
- ctypes.windll.kernel32 calls

## GUI Structure (VILLAIN.py)
- Framework: PyQt5 with qdarktheme
- Main class: VillainGui (QMainWindow)
- Website: ecuunlock.com
- Tabs: HOME, CONNECT, APNT, VILLAIN, TIPM, EPS, TUNER
- Logo: ECU_VILLAIN_LOGO_6.jpg
