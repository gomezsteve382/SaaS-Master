# wiTECH WDE (Wireless Diagnostic Equipment) — Memory Dump Analysis
# From: wiTECH_wde.DMP (77MB)
# Architecture: Erlang/OTP (erl5.8.4.2)
# Install path: C:\Program Files (x86)\DCC Tools\wiTECH\WDE\
# Build system: TeamCity (teamcityagent workspace f85cc3c1481e3464)
# Source path: DiagnosticApplication/erlang/apps/

## WHAT wiTECH IS:
Stellantis/Chrysler's OFFICIAL dealer diagnostic tool.
Built in Erlang (functional programming language for telecom).
Communicates with MicroPod II hardware via TCP sockets.

## KEY FINDING — SERVER-SIDE SEED-KEY:
wiTECH does NOT compute seed-key locally!
It calls Stellantis manufacturing servers:
  - request_sgw_signed_challenge_from_manufacturing_server()
  - request_sgw_cert_from_manufacturing_server()
  - manufacturing_sgw_zone, manufacturing_sgw_station_type
  - manufacturing_sgw_tester_id, manufacturing_sgw_timeout

This means the OFFICIAL tool is LOCKED to dealer network access.
VILLAIN reimplements these algorithms CLIENT-SIDE — that's the value.

## ERLANG MODULE LIST (ECU/Vehicle Related):

### Device Layer:
  - device_unlock_ecu — ECU unlock orchestration
  - device_update — ECU update/flash
  - device_sup — Device supervisor
  - device_srv — Device server
  - device_util — Device utilities
  - device_vector — Vector interface

### Vehicle Layer:
  - veh_unlock — Vehicle unlock operations
  - veh_ecu — ECU management
  - veh_gateway — Gateway/SGW handling
  - veh_identify — Vehicle identification
  - veh_ignition — Ignition state
  - veh_scan — Vehicle network scan
  - veh_session_control — Diagnostic session management
  - veh_session_manager — Session lifecycle
  - veh_sgw — Security Gateway operations
  - veh_transaction — UDS transaction handler
  - veh_broadcast — Broadcast message handling
  - veh_actuator — Actuator test control
  - veh_dde — DDE data handling
  - veh_datarecorder — Data recording
  - veh_freezeframe — Freeze frame capture
  - veh_obdii — OBD-II protocol
  - veh_odometer — Odometer reading
  - veh_onboard_routine — Onboard routines
  - veh_legacy_session — Legacy diagnostic sessions
  - veh_legacy_routine — Legacy routines
  - veh_netdiag — Network diagnostics
  - veh_loc_scan — Local scan
  - veh_eng — Engine functions
  - veh_expire — Session expiration

### Workshop Host Services (WHS):
  - whs_ecu_unlock — ECU unlock via workshop
  - whs_ecu_memory — ECU memory read/write
  - whs_ecu_raw — Raw ECU communication
  - whs_ecu_dtc — DTC management
  - whs_ecu — ECU operations
  - whs_ecu_db — ECU database
  - whs_flash — Flash programming
  - whs_hex — Hex file handling
  - whs_protocol — Protocol layer
  - whs_vehicle — Vehicle operations
  - whs_vehicle_db — Vehicle database
  - whs_vehicle_scan — Vehicle scanning
  - whs_discovery — Device discovery
  - whs_comser — Communication services
  - whs_comser_db — ComSer database
  - whs_bus — Bus communication
  - whs_bus_db — Bus database
  - whs_bus_logger — Bus logging
  - whs_direct_connect — Direct connection
  - whs_feedback — Feedback system
  - whs_feedback_download — Feedback download
  - whs_legacy — Legacy support
  - whs_log — Logging
  - whs_logical_ecu — Logical ECU mapping
  - whs_net_diag — Network diagnostics
  - whs_obdii — OBD-II
  - whs_qualification — Qualification checks
  - whs_report — Report generation
  - whs_routine_data — Routine data
  - whs_routine_download — Routine downloads
  - whs_reset — Reset operations
  - whs_update — Update management
  - whs_vcomm — Vehicle communication
  - whs_veh_data — Vehicle data
  - whs_veh_scan_report — Scan reports
  - whs_elements_db — Elements database
  - whs_device_config — Device configuration
  - whs_db — Main database
  - whs_db_upload — Database upload
  - whs_stream_proxy — Stream proxy
  - whs_simulation — Simulation mode
  - whs_websocket — WebSocket interface

### Flash Modules:
  - flash — Flash core
  - flash_sup — Flash supervisor
  - flash_util — Flash utilities
  - jcanflash — J-CAN flash protocol
  - rmflash — RM flash protocol  
  - vrflash — VR flash protocol

### Communication Layer:
  - vcomm — Vehicle communication core
  - vcomm_api — Communication API
  - vcomm_bus — Bus abstraction
  - vcomm_channel — Channel management
  - vcomm_con — Connection handling
  - vcomm_conf — Configuration
  - vcomm_error — Error handling
  - vcomm_filter — Message filtering
  - vcomm_log — Communication logging
  - vcomm_msg — Message handling
  - vcomm_periodic — Periodic messaging
  - vcomm_sup — Communication supervisor

### Protocol Layer:
  - protocol — Protocol core
  - protocol_api — Protocol API
  - protocol_conf — Protocol configuration
  - protocol_error — Protocol errors
  - protocol_kline — K-Line protocol
  - protocol_msg — Protocol messages
  - protocol_services — Protocol services
  - protocol_state — Protocol state machine
  - protocol_sup — Protocol supervisor

### Discovery/Network:
  - slp — Service Location Protocol
  - slp_client — SLP client
  - slp_server — SLP server
  - slp_sup — SLP supervisor
  - slp_util — SLP utilities
  - discovery — Device discovery
  - discovery_sup — Discovery supervisor

### Simulation:
  - sim — Simulator core
  - sim_unlock_connection — Simulated unlock
  - sim_vci_connection — Simulated VCI
  - sim_event_connection — Simulated events
  - sim_monitor_connection — Simulated monitoring

## UDS FUNCTIONS FOUND:
  - read_seed — Request seed from ECU
  - pre_unlock_init — Pre-unlock initialization
  - send_key — Send calculated key to ECU
  - read_memory — Read ECU memory
  - write_memory — Write ECU memory
  - read_partnumber — Read part number
  - read_vin — Read VIN
  - read_flash_partnumber — Read flash part number
  - read_spare_partnumber — Read spare part number
  - read_hardware_number — Read hardware version
  - read_software_number — Read software version
  - enter_diagnostic_session — Enter diag session
  - disable_normal_messages — Suppress normal CAN traffic
  - enable_normal_messages — Resume normal CAN traffic
  - enable_fault_setting — Enable fault logging
  - disable_fault_setting — Disable fault logging
  - enable_network_messages — Enable network messages
  - disable_network_messages — Disable network messages
  - send_tester_present — Keep-alive heartbeat
  - ecu_reset — ECU reset
  - clear_dtcs — Clear DTCs
  - read_dtc — Read DTCs

## FLASH FUNCTIONS:
  - flash_selection — Select flash target
  - parse_flash_event — Parse flash events
  - check_dependencies — Check flash dependencies
  - get_country_code — Get country code for flash
  - finalize_flash_process — Finalize flash
  - copy_flash_log — Copy flash log
  - get_device_id_and_platform — Get device info
  - get_allowed_devices — Get allowed flash devices
  - flash_mod — Flash module selection (j2534)
  - get_efd_version — Get EFD version
  - consume_flash — Flash consumption

## SGW (Security Gateway):
  - auth_diag_session_id — Authenticated diagnostic session
  - set_auth_diag_session_id — Set auth session
  - request_sgw_cert_from_manufacturing_server — Get SGW cert
  - request_sgw_signed_challenge_from_manufacturing_server — Get signed challenge

## CONFIGURATION:
  - witech.appcontrol.port = 9876
  - WDE_HOME = ..\..\WDE
  - Erlang node: wiTECH_wde
  - SSL/TLS support for server communication
  - SLP (Service Location Protocol) for device discovery
  - MicroPod interface discovery via XML
