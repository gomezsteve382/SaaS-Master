import { describe, it, expect } from 'vitest';

// ═══════════════════════════════════════════════════════════════════════════════
// CRC16-CCITT-FALSE — from crcWorker.ts and VINCommander.tsx
// poly=0x1021, init=0xFFFF, no reflection
// Verified against srtlab.test.ts known values and EEPROM Analysis doc
// ═══════════════════════════════════════════════════════════════════════════════

function crc16CcittFalse(data: Uint8Array): number {
  let crc = 0xFFFF;
  for (let i = 0; i < data.length; i++) {
    crc ^= (data[i] << 8);
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? (((crc << 1) ^ 0x1021) & 0xFFFF) : ((crc << 1) & 0xFFFF);
    }
  }
  return crc;
}

// ═══════════════════════════════════════════════════════════════════════════════
// XOR checksum — from EEPROMVisualizer.test.ts
// ═══════════════════════════════════════════════════════════════════════════════

function xorChecksum(data: Uint8Array): number {
  let result = 0;
  for (let i = 0; i < data.length; i++) result ^= data[i];
  return result;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Intel HEX parseHex — from crcWorker.ts (with checksum validation fix)
// ═══════════════════════════════════════════════════════════════════════════════

function parseHex(text: string): { bytes: Uint8Array; error?: string } {
  try {
    const lines = text.trim().split(/\r?\n/);
    const segments: Array<{ addr: number; data: Uint8Array }> = [];
    let maxAddr = 0;
    let baseAddr = 0;

    for (let lineNum = 0; lineNum < lines.length; lineNum++) {
      const line = lines[lineNum];
      if (!line.startsWith(":")) continue;

      const rawLen = line.length;
      if (rawLen < 11 || rawLen % 2 === 0) {
        return { bytes: new Uint8Array(0), error: `Line ${lineNum + 1}: invalid record length` };
      }

      const byteCount = parseInt(line.slice(1, 3), 16);
      const addr = parseInt(line.slice(3, 7), 16);
      const recType = parseInt(line.slice(7, 9), 16);

      const expectedLen = 1 + (byteCount + 5) * 2;
      if (rawLen < expectedLen) {
        return { bytes: new Uint8Array(0), error: `Line ${lineNum + 1}: truncated record (expected ${expectedLen} chars, got ${rawLen})` };
      }

      let sum = 0;
      const totalRecordBytes = byteCount + 5;
      for (let i = 0; i < totalRecordBytes; i++) {
        sum += parseInt(line.slice(1 + i * 2, 3 + i * 2), 16);
      }
      if ((sum & 0xFF) !== 0) {
        const storedChecksum = parseInt(line.slice(9 + byteCount * 2, 11 + byteCount * 2), 16);
        const computedChecksum = ((~(sum - storedChecksum) + 1) & 0xFF);
        return {
          bytes: new Uint8Array(0),
          error: `Line ${lineNum + 1}: checksum mismatch (stored 0x${storedChecksum.toString(16).toUpperCase().padStart(2, "0")}, expected 0x${computedChecksum.toString(16).toUpperCase().padStart(2, "0")})`,
        };
      }

      if (recType === 0x00) {
        const data = new Uint8Array(byteCount);
        for (let i = 0; i < byteCount; i++) {
          data[i] = parseInt(line.slice(9 + i * 2, 11 + i * 2), 16);
        }
        const absAddr = baseAddr + addr;
        segments.push({ addr: absAddr, data });
        maxAddr = Math.max(maxAddr, absAddr + byteCount);
      } else if (recType === 0x02) {
        baseAddr = parseInt(line.slice(9, 13), 16) << 4;
      } else if (recType === 0x04) {
        baseAddr = parseInt(line.slice(9, 13), 16) << 16;
      } else if (recType === 0x01) {
        break;
      }
    }

    const bytes = new Uint8Array(maxAddr).fill(0xff);
    for (const seg of segments) {
      bytes.set(seg.data, seg.addr);
    }
    return { bytes };
  } catch (e) {
    return {
      bytes: new Uint8Array(0),
      error: e instanceof Error ? e.message : "Parse error",
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// File type detection — from EEPROMVisualizer.tsx
// ═══════════════════════════════════════════════════════════════════════════════

function detectFileType(size: number): 'rfhub' | 'bcm' | 'unknown' {
  if (size === 8192 || size === 16384) return 'rfhub';
  if (size === 65536 || size === 131072) return 'bcm';
  return 'unknown';
}

// ═══════════════════════════════════════════════════════════════════════════════
// BCM bench patch with CRC — from VINCommander.tsx patchBenchVin
// ═══════════════════════════════════════════════════════════════════════════════

const BCM_VIN_OFFSETS = [0x005320, 0x005340, 0x005360, 0x005380];

function patchBcmBenchVin(data: Uint8Array, vin: string): { patched: Uint8Array; crc: number } {
  const patched = new Uint8Array(data);
  const vinBytes = new TextEncoder().encode(vin);
  const crc = crc16CcittFalse(vinBytes);

  for (const offset of BCM_VIN_OFFSETS) {
    if (offset + 19 > patched.length) continue;
    patched.set(vinBytes, offset);
    patched[offset + 17] = (crc >> 8) & 0xFF;
    patched[offset + 18] = crc & 0xFF;
  }

  return { patched, crc };
}

// ═══════════════════════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════════════════════

describe('Fix 1: Intel HEX parseHex — record checksum validation', () => {
  it('accepts valid Intel HEX with correct checksums', () => {
    // 16 bytes of data at address 0x0000, checksum = 0x41
    const hex = [
      ':10000000214601360121470136007EFE09D2190141',
      ':00000001FF', // EOF
    ].join('\n');
    const result = parseHex(hex);
    expect(result.error).toBeUndefined();
    expect(result.bytes.length).toBe(16);
    expect(result.bytes[0]).toBe(0x21);
  });

  it('rejects record with corrupted checksum', () => {
    // Correct checksum is 0x41, changed to 0x42
    const hex = ':10000000214601360121470136007EFE09D2190142';
    const result = parseHex(hex);
    expect(result.error).toBeDefined();
    expect(result.error).toContain('checksum mismatch');
    expect(result.error).toContain('Line 1');
  });

  it('rejects truncated records', () => {
    // Declares 16 bytes (0x10) but line is too short
    const hex = ':100000002146013601';
    const result = parseHex(hex);
    expect(result.error).toBeDefined();
    expect(result.error).toContain('truncated');
  });

  it('rejects invalid record length (even char count)', () => {
    // Line length is even (after colon) = invalid
    const hex = ':1000000021460136012147013600';
    const result = parseHex(hex);
    expect(result.error).toBeDefined();
  });

  it('handles EOF record and stops parsing', () => {
    const hex = [
      ':0400000000000000FC',  // 4 bytes of zeros at 0x0000
      ':00000001FF',          // EOF
      ':10000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00', // Should be ignored
    ].join('\n');
    const result = parseHex(hex);
    expect(result.error).toBeUndefined();
    expect(result.bytes.length).toBe(4);
  });

  it('handles extended linear address records (type 04)', () => {
    const hex = [
      ':020000040001F9',      // Extended linear address: base = 0x00010000
      ':0400000012345678E8',  // 4 bytes at 0x00010000, checksum = 0xE8
      ':00000001FF',
    ].join('\n');
    const result = parseHex(hex);
    expect(result.error).toBeUndefined();
    expect(result.bytes[0x10000]).toBe(0x12);
    expect(result.bytes[0x10001]).toBe(0x34);
  });

  it('reports correct line number for errors', () => {
    const hex = [
      ':0400000000000000FC',  // Valid (checksum FC is correct)
      ':04000400000000F9',    // Corrupted checksum (correct would be F8)
    ].join('\n');
    const result = parseHex(hex);
    expect(result.error).toBeDefined();
    expect(result.error).toContain('Line 2');
  });

  it('skips non-record lines', () => {
    const hex = [
      '# This is a comment',
      ':0400000000000000FC',
      '',
      ':00000001FF',
    ].join('\n');
    const result = parseHex(hex);
    expect(result.error).toBeUndefined();
    expect(result.bytes.length).toBe(4);
  });
});

describe('Fix 2: BCM CRC16-CCITT-FALSE — verified against real files', () => {
  // All expected values from srtlab.test.ts and EEPROM Analysis doc

  it('produces 0x7753 for VIN 2C3CDXHG5EH219538 (from srtlab.test.ts line 607)', () => {
    const vin = new TextEncoder().encode('2C3CDXHG5EH219538');
    expect(crc16CcittFalse(vin)).toBe(0x7753);
  });

  it('produces 0x41D9 for VIN 2B3CJ4DV6AH300549 (from srtlab.test.ts line 611)', () => {
    const vin = new TextEncoder().encode('2B3CJ4DV6AH300549');
    expect(crc16CcittFalse(vin)).toBe(0x41D9);
  });

  it('produces 0xD115 for VIN 1C4RJFDJXEC365477 (from EEPROM Analysis doc and EEPROMVisualizer.test.ts)', () => {
    const vin = new TextEncoder().encode('1C4RJFDJXEC365477');
    expect(crc16CcittFalse(vin)).toBe(0xD115);
  });

  it('CRC is stored big-endian: high byte first (from srtlab.test.ts line 644)', () => {
    const crc = crc16CcittFalse(new TextEncoder().encode('2C3CDXHG5EH219538'));
    expect((crc >> 8) & 0xFF).toBe(0x77);
    expect(crc & 0xFF).toBe(0x53);
  });

  it('init value 0xFFFF returned for empty data', () => {
    expect(crc16CcittFalse(new Uint8Array(0))).toBe(0xFFFF);
  });
});

describe('Fix 2: RFHUB XOR checksum — verified against EEPROMVisualizer.test.ts', () => {
  it('produces 0x36 for RFHUB VIN 1C4RJFN9XJC309165 (from EEPROMVisualizer.test.ts line 74)', () => {
    const vin = new TextEncoder().encode('1C4RJFN9XJC309165');
    expect(xorChecksum(vin)).toBe(0x36);
  });

  it('returns 0 for empty data', () => {
    expect(xorChecksum(new Uint8Array(0))).toBe(0);
  });

  it('returns the byte itself for single byte', () => {
    expect(xorChecksum(new Uint8Array([0xAB]))).toBe(0xAB);
  });

  it('returns 0 for matching byte pairs', () => {
    expect(xorChecksum(new Uint8Array([0x55, 0x55]))).toBe(0);
  });
});

describe('Fix 2: File type detection — from EEPROMVisualizer.tsx', () => {
  it('detects 8192 bytes as RFHUB (from EEPROMVisualizer.test.ts)', () => {
    expect(detectFileType(8192)).toBe('rfhub');
  });

  it('detects 16384 bytes as RFHUB', () => {
    expect(detectFileType(16384)).toBe('rfhub');
  });

  it('detects 65536 bytes as BCM (from EEPROM Analysis doc: 64 KB BCM D-Flash)', () => {
    expect(detectFileType(65536)).toBe('bcm');
  });

  it('detects 131072 bytes as BCM', () => {
    expect(detectFileType(131072)).toBe('bcm');
  });

  it('returns unknown for other sizes', () => {
    expect(detectFileType(1024)).toBe('unknown');
    expect(detectFileType(32768)).toBe('unknown');
  });
});

describe('Fix 3: BCM bench VIN patch with CRC16 recalculation', () => {
  it('writes VIN and CRC16 to all 4 BCM D-Flash slots', () => {
    // Create a mock 64KB BCM D-Flash file
    const data = new Uint8Array(65536).fill(0xFF);
    const vin = '2C3CDXHG5EH219538';
    const { patched, crc } = patchBcmBenchVin(data, vin);

    expect(crc).toBe(0x7753);

    for (const offset of BCM_VIN_OFFSETS) {
      // Check VIN bytes
      const vinBytes = patched.slice(offset, offset + 17);
      expect(new TextDecoder().decode(vinBytes)).toBe(vin);

      // Check CRC16 big-endian at offset+17
      expect(patched[offset + 17]).toBe(0x77); // high byte
      expect(patched[offset + 18]).toBe(0x53); // low byte
    }
  });

  it('all 4 slots get identical CRC (same VIN = same CRC, from srtlab.test.ts line 638)', () => {
    const data = new Uint8Array(65536).fill(0xFF);
    const { patched, crc } = patchBcmBenchVin(data, '1C4RJFDJXEC365477');

    expect(crc).toBe(0xD115);

    for (const offset of BCM_VIN_OFFSETS) {
      const storedCrc = (patched[offset + 17] << 8) | patched[offset + 18];
      expect(storedCrc).toBe(0xD115);
    }
  });

  it('different VINs produce different CRCs', () => {
    const data = new Uint8Array(65536).fill(0xFF);
    const { crc: crc1 } = patchBcmBenchVin(data, '2C3CDXHG5EH219538');
    const { crc: crc2 } = patchBcmBenchVin(data, '2B3CJ4DV6AH300549');
    expect(crc1).not.toBe(crc2);
  });

  it('skips offsets beyond file length', () => {
    // File too small for any BCM offsets (0x5320 = 21280)
    const data = new Uint8Array(1024).fill(0xFF);
    const { patched } = patchBcmBenchVin(data, '2C3CDXHG5EH219538');
    // Nothing should be written — file unchanged
    expect(patched).toEqual(data);
  });
});

describe('Fix 4: BCM D-Flash offsets — verified from EEPROM Analysis doc', () => {
  // From: EEPROM Analysis Findings doc
  // "Actual VIN Locations: 0x005320, 0x005340, 0x005360, 0x005380 (stride 0x20)"

  it('BCM VIN offsets are at stride 0x20 (32 bytes)', () => {
    for (let i = 1; i < BCM_VIN_OFFSETS.length; i++) {
      expect(BCM_VIN_OFFSETS[i] - BCM_VIN_OFFSETS[i - 1]).toBe(0x20);
    }
  });

  it('first BCM VIN offset is 0x5320', () => {
    expect(BCM_VIN_OFFSETS[0]).toBe(0x5320);
  });

  it('all 4 offsets fit within 64KB BCM D-Flash (from EEPROM Analysis: "65,536 bytes (64 KB segment)")', () => {
    for (const offset of BCM_VIN_OFFSETS) {
      // VIN (17) + CRC (2) = 19 bytes needed
      expect(offset + 19).toBeLessThanOrEqual(65536);
    }
  });
});

describe('Integration: round-trip bench patch → validate', () => {
  it('BCM: patched VIN passes CRC16 validation', () => {
    const data = new Uint8Array(65536).fill(0xFF);
    const vin = '2C3CDXHG5EH219538';
    const { patched } = patchBcmBenchVin(data, vin);

    // Now validate each slot like EEPROMVisualizer would
    for (const offset of BCM_VIN_OFFSETS) {
      const vinBytes = patched.slice(offset, offset + 17);
      const storedCrc = (patched[offset + 17] << 8) | patched[offset + 18];
      const calculatedCrc = crc16CcittFalse(vinBytes);
      expect(storedCrc).toBe(calculatedCrc);
    }
  });

  it('BCM: second patch with different VIN updates CRC correctly', () => {
    const data = new Uint8Array(65536).fill(0xFF);

    // First patch
    const { patched: p1 } = patchBcmBenchVin(data, '2C3CDXHG5EH219538');
    expect((p1[0x5320 + 17] << 8) | p1[0x5320 + 18]).toBe(0x7753);

    // Second patch over the first
    const { patched: p2 } = patchBcmBenchVin(p1, '1C4RJFDJXEC365477');
    expect((p2[0x5320 + 17] << 8) | p2[0x5320 + 18]).toBe(0xD115);

    // Verify VIN was actually overwritten
    const vinBytes = new TextDecoder().decode(p2.slice(0x5320, 0x5320 + 17));
    expect(vinBytes).toBe('1C4RJFDJXEC365477');
  });
});
