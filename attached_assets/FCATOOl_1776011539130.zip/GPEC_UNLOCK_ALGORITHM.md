# GPEC2/GPEC2A Unlocker — FULLY CRACKED (.NET IL Disassembly)
# From: GPEC Unlocker.exe (WinLicense protected, .NET 4.8.1)
# Namespace: GPEC2_GPEC2A_Unlocker

## AES-256 Encryption (License)
- Key: $leJ7M!l9t*2Y8P!K(@J8TdAyFp)(=1P
- IV:  $8zfNN&od#qTMA=X

## License Validation
- Machine ID: Win32_Processor.ProcessorId + Win32_BaseBoard.SerialNumber
- SHA256 hash comparison
- Anti-VM: checks for "virtual", "vmware", "bluetooth", "hyper-v"
- Website: https://antiimmo.link/
- Telegram: https://wa.me/c/9647719933814

## UNLOCK ALGORITHM (from .NET IL bytecode):

### DetectFileFlashGeneration(fileData):
    pattern = 4-byte array (field 0x04000005, in WinLicense-protected FieldRVA)
    for i in range(len(fileData) - len(pattern)):
        if fileData[i] == pattern[0]:
            if fileData[i+1] == pattern[1] and fileData[i+2] == pattern[2] and fileData[i+3] == pattern[3]:
                return "2015-2018 FILE FLASH"
    return "NEW 2018+ FILE FLASH"

### IsFileAlreadyUnlocked():
    pattern = 4-byte array (field 0x04000006)
    # Search for pattern in fileData
    for i in range(1, len(fileData) - len(pattern)):
        if fileData[i] == pattern[0] and fileData[i+1] == pattern[1]:
            if fileData[i+2] == pattern[2] and fileData[i+3] == pattern[3]:
                if fileData[i-1] == 0xE8:  # byte BEFORE pattern
                    return True
    if len(fileData) > 0x2FFFC:
        if fileData[0x2FFFC] == 0x96:
            return True
    return False

### BtnUnlock_Click (async MoveNext — THE ACTUAL UNLOCK):
    pattern = 4-byte array (field 0x04000007)
    patternFound = False
    
    # Search for pattern
    for i in range(len(fileData) - len(pattern)):
        if fileData[i] == pattern[0]:
            if fileData[i+1] == pattern[1] and fileData[i+2] == pattern[2] and fileData[i+3] == pattern[3]:
                # UNLOCK: overwrite first byte of pattern with 0xE8
                fileData[i] = 0xE8
                patternFound = True
                break
    
    # Always set offset flag (if file is large enough)
    if len(fileData) > 0x2FFFC:
        fileData[0x2FFFC] = 0x96
    
    if patternFound:
        print("Pattern found and unlocked successfully")
    else:
        print("Pattern not found. Offset changed only.")

## SECURITY ACCESS LEVELS (from IL):
- Group 1: 0x05 request / 0x10 response
- Group 2: 0x02 request / 0x82 response
- Group 3: 0x08 request / 0x88 response
- Group 4: 0x22-0x26, 0x42, 0x45, 0x44, 0x60-0x62, 0x66-0x67, 0x6B-0x6D

## IL BYTECODE (raw disassembly):

### BtnUnlock_MoveNext (462 bytes):
  IL_0000: ldarg.0
  IL_0001: ldfld [04:0067]        // state
  IL_0006: stloc.0
  IL_0007: ldarg.0
  IL_0008: ldfld [04:0069]        // this (MainWindow)
  IL_000D: stloc.1
  IL_000E: ldloc.0
  IL_000F: brfalse IL_0130
  IL_0014: ldloc.1
  IL_0015: ldfld [04:0056]        // fileData
  IL_001A: brfalse IL_0110         // if no file loaded
  IL_001F: ldloc.1
  IL_0020: call [06:007D]          // AnimateProgressBar
  IL_0025: ldc.i4.4
  IL_0026: newarr [01:0040]        // new byte[4]
  IL_002B: dup
  IL_002C: ldtoken [04:0007]       // THE PATTERN (FieldRVA, WinLicense-protected)
  IL_0031: call RuntimeHelpers.InitializeArray
  IL_0036: stloc.2                 // pattern = byte[4]
  IL_0037: ldarg.0
  IL_0038: ldc.i4.0
  IL_0039: stfld [04:006A]        // patternFound = false
  IL_003E: ldc.i4.0
  IL_003F: stloc.3                 // i = 0
  IL_0040: br.s IL_0073            // goto loop check
  
  // LOOP BODY: compare bytes
  IL_0042: ldloc.1
  IL_0043: ldfld [04:0056]        // fileData
  IL_0048: ldloc.3                 // i
  IL_0049: ldc.i4.1
  IL_004A: add                     // i+1
  IL_004B: ldelem.u1               // fileData[i+1]
  IL_004C: ldloc.2                 // pattern
  IL_004D: ldc.i4.1
  IL_004E: ldelem.u1               // pattern[1]
  IL_004F: bne.un.s IL_006F        // if not equal, skip
  IL_0051: ldloc.1
  IL_0052: ldfld [04:0056]        // fileData
  IL_0057: ldloc.3                 // i
  IL_0058: ldc.i4.2
  IL_0059: add
  IL_005A: ldelem.u1               // fileData[i+2]
  IL_005B: ldloc.2                 // pattern
  IL_005C: ldc.i4.2
  IL_005D: ldelem.u1               // pattern[2]
  IL_005E: bne.un.s IL_006F
  IL_0060: ldloc.1
  IL_0061: ldfld [04:0056]        // fileData
  IL_0066: ldloc.3                 // i
  IL_0067: ldc.i4.3
  IL_0068: add
  IL_0069: ldelem.u1               // fileData[i+3]
  IL_006A: ldloc.2                 // pattern
  IL_006B: ldc.i4.3
  IL_006C: ldelem.u1               // pattern[3]
  IL_006D: beq.s IL_0092           // ALL 4 BYTES MATCH -> unlock!
  
  // INCREMENT
  IL_006F: ldloc.3                 // i
  IL_0070: ldc.i4.1
  IL_0071: add
  IL_0072: stloc.3                 // i++
  
  // LOOP CHECK
  IL_0073: ldloc.3                 // i
  IL_0074: ldloc.1
  IL_0075: ldfld [04:0056]        // fileData
  IL_007A: ldlen
  IL_007B: conv.i4
  IL_007C: ldloc.2                 // pattern
  IL_007D: ldlen
  IL_007E: conv.i4
  IL_007F: sub                     // fileData.Length - pattern.Length
  IL_0080: bge.s IL_00A6           // if i >= limit, exit loop
  IL_0082: ldloc.1
  IL_0083: ldfld [04:0056]        // fileData
  IL_0088: ldloc.3                 // i
  IL_0089: ldelem.u1               // fileData[i]
  IL_008A: ldloc.2                 // pattern
  IL_008B: ldc.i4.0
  IL_008C: ldelem.u1               // pattern[0]
  IL_008D: beq.s IL_0042           // if first byte matches, check rest
  IL_008F: nop
  IL_0090: br.s IL_006F            // else increment
  
  // UNLOCK: WRITE 0xE8
  IL_0092: ldloc.1
  IL_0093: ldfld [04:0056]        // fileData
  IL_0098: ldloc.3                 // i (match position)
  IL_0099: ldc.i4 232              // 0xE8
  IL_009E: stelem.i1               // fileData[i] = 0xE8  *** THE UNLOCK PATCH ***
  IL_009F: ldarg.0
  IL_00A0: ldc.i4.1
  IL_00A1: stfld [04:006A]        // patternFound = true
  
  // ALWAYS: SET OFFSET FLAG
  IL_00A6: ldloc.1
  IL_00A7: ldfld [04:0056]        // fileData
  IL_00AC: ldlen
  IL_00AD: conv.i4
  IL_00AE: ldc.i4 196604          // 0x2FFFC
  IL_00B3: ble.s IL_00C6           // skip if file too small
  IL_00B5: ldloc.1
  IL_00B6: ldfld [04:0056]        // fileData
  IL_00BB: ldc.i4 196604          // 0x2FFFC
  IL_00C0: ldc.i4 150             // 0x96
  IL_00C5: stelem.i1               // fileData[0x2FFFC] = 0x96  *** OFFSET FLAG ***

## NOTE: The 4-byte search pattern is stored in FieldRVA entry [04:0007]
## which points to RVA 0x1480000 (virtual section, WinLicense-protected).
## To extract: diff a locked vs unlocked GPEC2A firmware dump,
## or run the tool on Windows and dump memory when pattern is loaded.
