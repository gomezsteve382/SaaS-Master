# wiTECH (WDE) — Complete Extraction
# From: wiTECH_wde.DMP (73.5MB)
# Architecture: Erlang/OTP (BEAM VM)
# Path: C:\Program Files (x86)\DCC Tools\wiTECH\WDE\

## WHAT IS wiTECH?
Stellantis/Chrysler's OFFICIAL dealer diagnostic tool. Built in Erlang.
Uses MicroPod II hardware via J2534 interface.

## KEY FINDING: SERVER-SIDE SEED-KEY
wiTECH does NOT compute seed-key locally. It calls Stellantis servers:
- `request_sgw_cert_from_manufacturing_server`
- `request_sgw_signed_challenge_from_manufacturing_server`
- `make_request_to_manufacturing_server`
- `request_sgw_cert_using_cda_services`
- `request_sgw_signed_challenge_using_cda_services`

### SGW Manufacturing Server Config:
- `manufacturing_sgw_server` — server hostname
- `manufacturing_sgw_port` — server port
- `manufacturing_sgw_timeout` — connection timeout
- `manufacturing_sgw_zone` — geographic zone
- `manufacturing_sgw_station_type` — workstation type
- `manufacturing_sgw_tester_id` — tester identifier

## wiTECH REST API (Erlang HTTP handlers):

### ECU Operations:
- `["vehicle","ecus",ecu_id,"vin"]` → `[whs_ecu,vin]`
- `["vehicle","ecus",ecu_id,"reset"]` → `[whs_ecu,reset]`
- `["vehicle","ecus",ecu_id,"reset",key]` → with key
- `["vehicle","ecus",ecu_id,"raw"]` → `[whs_ecu_raw,raw]`
- `["vehicle","ecus",ecu_id,"qualify"]` → qualification

### ECU Unlock API:
- `["vehicle","ecus",ecu_id,"unlock","levels"]` → `[whs_ecu_unlock,unlock_levels]`
- `["vehicle","ecus",ecu_id,"unlock","by_id"]` → `[whs_ecu_unlock,unlock_by_id]`
- `["vehicle","ecus",ecu_id,"unlock","by_level"]` → `[whs_ecu_unlock,unlock_by_level]`

### Memory Operations:
- `["vehicle","ecus",ecu_id,"memory","read"]` → `[whs_ecu_memory,read_memory]`
- `["vehicle","ecus",ecu_id,"memory","write"]` → `[whs_ecu_memory,write_memory]`

### DTC Operations:
- `["vehicle","ecus",ecu_id,"dtcs"]` → `[whs_ecu_dtc,read]`
- `["vehicle","ecus",ecu_id,"dtcs","clear"]` → `[whs_ecu_dtc,clear]`
- `["vehicle","ecus",ecu_id,"dtcs",hex_code,"env"]` → `[whs_ecu_dtc,env]`
- `["vehicle","ecus",ecu_id,"dtcs",hex_code,"snapshot"]` → `[whs_ecu_dtc,snapshot]`

### Flash Programming API:
- `["vehicle","flash","start"]` → `[whs_flash,start]`
- `["vehicle","flash","start",key]` → `[whs_flash,start_device_config]`
- `["vehicle","flash","start",year,body,key]` → `[whs_flash,start_year_body]`
- `["vehicle","flash","recover"]` → `[whs_flash,recover_remote_flash]`
- `["vehicle","flash","status"]` → `[whs_flash]`
- `["vehicle","flash","input"]` → `[whs_flash,input]`
- `["vehicle","flash","file_info"]` → `[whs_flash,file_info]`

### VIN Operations:
- `["vehicle","vin"]` → `[whs_vehicle,vin]`
- `["vehicle","vin_ecu_id"]` → `[whs_vehicle,vin_ecu_id]`
- `["vehicle","vin_ecu"]` → `[whs_vehicle,vin_ecu]`
- `["vehicle","original_vin"]` → `[whs_vehicle,original_vin]`
- `["vehicle","obdii","vin"]` → `[whs_obdii,vin]`

### ECU Info:
- `vmm_version`, `hardware_version`, `software_version`
- `software_part_number`, `flash_partnumber`, `hardware_number`
- `ecu_config_change`

### ECU Database:
- `["db","ecus","database","global_configs"]` → `[whs_ecu_db,global_configs]`
- `["db","ecus","database","ecu_configs"]` → `[whs_ecu_db,ecu_configs]`
- `["db","ecus","database","ecu_command_implementations"]` → command implementations
- `["db","ecus","database","benchtop_configs"]` → bench configs
- `["db","ecus",ecu_id,"elements"]` → ECU elements
- `["db","ecus",ecu_id,"conversions"]` → data conversions
- `["db","ecus",ecu_id,"routines"]` → diagnostic routines

## UDS Protocol Functions (from protocol_services module):
- `transmit_msg_no_resp_req` — transmit without response
- `transmit_msg_no_response` — fire and forget
- `write_by_local_identifier` — UDS write
- `read_by_local_identifier` — UDS read
- `yb_code` — YB identification code
- `var_ver` — variant version
- `ident` — ECU identification
- `vmm_version` — VMM version
- `read_partnumber` — read part number
- `read_vin` — read VIN
- `read_flash_partnumber` — flash part number
- `read_spare_partnumber` — spare part number
- `read_hardware_number` — hardware number
- `read_software_number` — software number
- `hardware_version`, `software_version`, `software_part_number`
- `read_dtc`, `clear_dtcs` — DTC management
- `reset_ecu`, `get_reset_options` — ECU reset
- `tester_present`, `start_tester_present`, `stop_tester_present`
- `convert_dtc_status`, `dtc_env_xmit`
- `available_diagnostic_sessions` — list sessions
- `enter_diagnostic_session` — enter diag session
- `disable_normal_messages`, `enable_normal_messages`
- `enable_fault_setting`, `disable_fault_setting`
- `enable_network_messages`, `disable_network_messages`

### Security Access:
- `read_seed` — request seed from ECU
- `pre_unlock_init` — pre-unlock initialization
- `send_key` — send computed key
- `read_memory`, `write_memory` — memory access

### Flash Functions:
- `is_efd`, `is_efd_flash_file` — EFD detection
- `recover_flash`, `recover_remote_flash` — flash recovery
- `flash_start`, `flash_sgw_info` — flash with SGW
- `start_flash`, `flash_status`, `flash_input`
- `set_auth_diag_session_id`, `auth_diag_session_id`
- `flash_selection`, `parse_flash_event`
- `flash_mod` — flash module (j2534)
- `get_efd_version`, `flash_file`, `select_flash_mod`
- `consume_flash_status`, `flash_running`

### Device Functions:
- `unlock_ecu`, `try_unlock` — ECU unlock
- `discovery_xml` — device discovery
- `enable_pod_vehicle_id`, `disable_pod_vehicle_id`
- `monitor_device`, `unmonitor_device`
- `remote_flash_location`
- `vas_version`, `vrflash_version`

## Erlang Module List (ECU-Related):
- `device_unlock_ecu` — ECU unlock implementation
- `veh_unlock` — vehicle unlock
- `veh_sgw` — Security Gateway handler
- `veh_gateway` — gateway module
- `whs_ecu_unlock` — workshop ECU unlock (unlock_levels, unlock_by_id, unlock_by_level)
- `whs_ecu_memory` — ECU memory read/write
- `whs_ecu_raw` — raw ECU communication
- `whs_ecu_dtc` — DTC management
- `whs_flash` — flash programming
- `whs_ecu` — ECU management
- `whs_ecu_db` — ECU database
- `flash_sup`, `flash_util` — flash supervisors
- `jcanflash`, `rmflash`, `vrflash` — flash implementations
- `protocol_services`, `protocol_kline` — protocol handlers
- `vcomm_*` — vehicle communication layer
- `sim_unlock_*` — simulation unlock

## Flash Module Types:
- `jcanflash` — J-CAN flash (standard CAN-based)
- `rmflash` — RM flash
- `vrflash` — VR flash
- `ebml_util` — EBML utility

## Source Paths (from BEAM debug info):
- `DiagnosticApplication/erlang/apps/flash/src/flash_sup.erl`
- `DiagnosticApplication/erlang/apps/lhttpc/src/lhttpc_sup.erl`
- `DiagnosticApplication/erlang/apps/logger/src/logger.erl`
- `DiagnosticApplication/erlang/third_party_apps/ssl/src/ssl_server.erl`
- Built by TeamCity CI: `/workspace/teamcityagent/work/f85cc3c1481e3464/`

## Configuration Keys:
- `witech.appcontrol.port=9876`
- `WDE_HOME=..\..\WDE`
- `log_level`, `log_dir`, `num_logs`
- `db_timeout`, `global_file`, `obdii_file`
- `jcanflash_dir`, `vrflash_dir`, `curl_dir`
- `slp_services`, `slp_timeout`, `slp_interval`
- `discovery_xml_timeout`, `discovery_xml_interval`
- `enable_tx_logging`, `enable_rx_logging`
- `min_java_version`
