import { describe, it, expect } from 'vitest';

// CRC16-CCITT-FALSE implementation
const calculateCRC16 = (data: Uint8Array): number => {
  let crc = 0xFFFF;
  const poly = 0x1021;
  for (let byte of data) {
    crc ^= (byte << 8);
    for (let i = 0; i < 8; i++) {
      crc <<= 1;
      if (crc & 0x10000) {
        crc ^= poly;
      }
      crc &= 0xFFFF;
    }
  }
  return crc;
};

// XOR checksum implementation
const calculateXOR = (data: Uint8Array): number => {
  let result = 0;
  for (let byte of data) {
    result ^= byte;
  }
  return result;
};

describe('EEPROMVisualizer - CRC16-CCITT-FALSE', () => {
  it('should calculate correct CRC for BCM VIN 1C4RJFDJXEC365477', () => {
    const vin = new TextEncoder().encode('1C4RJFDJXEC365477');
    const crc = calculateCRC16(vin);
    expect(crc).toBe(0xD115);
  });

  it('should calculate correct XOR checksum for RFHUB VIN 1C4RJFN9XJC309165', () => {
    const vin = new TextEncoder().encode('1C4RJFN9XJC309165');
    // RFHUB uses XOR checksum, NOT CRC16-CCITT-FALSE
    // From EEPROMVisualizer.test.ts XOR section: expected 0x36
    const xor = calculateXOR(vin);
    expect(xor).toBe(0x36);
  });

  it('should validate CRC for known BCM file', () => {
    const vin = new TextEncoder().encode('1C4RJFDJXEC365477');
    const crc = calculateCRC16(vin);
    const storedCrc = 0xD115;
    expect(crc).toBe(storedCrc);
  });

  it('should return different CRC for different VIN', () => {
    const vin1 = new TextEncoder().encode('1C4RJFDJXEC365477');
    const vin2 = new TextEncoder().encode('1C4RJFDJXEC365478');
    const crc1 = calculateCRC16(vin1);
    const crc2 = calculateCRC16(vin2);
    expect(crc1).not.toBe(crc2);
  });

  it('should handle empty data', () => {
    const empty = new Uint8Array(0);
    const crc = calculateCRC16(empty);
    expect(crc).toBe(0xFFFF); // Initial value
  });
});

describe('EEPROMVisualizer - XOR Checksum', () => {
  it('should calculate XOR checksum for VIN bytes', () => {
    const vin = new TextEncoder().encode('1C4RJFN9XJC309165');
    const xor = calculateXOR(vin);
    expect(xor).toBe(0x36);
  });

  it('should return 0 for matching byte pairs', () => {
    const data = new Uint8Array([0x55, 0x55]);
    const xor = calculateXOR(data);
    expect(xor).toBe(0);
  });

  it('should handle single byte', () => {
    const data = new Uint8Array([0xAB]);
    const xor = calculateXOR(data);
    expect(xor).toBe(0xAB);
  });
});

describe('EEPROMVisualizer - VIN Pattern Matching', () => {
  it('should match valid VIN pattern', () => {
    const pattern = /^[1-9A-HJ-NPR-Z]{3}[0-9A-HJ-NPR-Z]{14}$/;
    expect(pattern.test('1C4RJFDJXEC365477')).toBe(true);
  });

  it('should reject VIN with invalid characters (I, O, Q)', () => {
    const pattern = /^[1-9A-HJ-NPR-Z]{3}[0-9A-HJ-NPR-Z]{14}$/;
    expect(pattern.test('1C4RJFDIXEC365477')).toBe(false); // I not allowed
    expect(pattern.test('1C4RJFDOXEC365477')).toBe(false); // O not allowed
    expect(pattern.test('1C4RJFDQXEC365477')).toBe(false); // Q not allowed
  });

  it('should reject VIN starting with 0', () => {
    const pattern = /^[1-9A-HJ-NPR-Z]{3}[0-9A-HJ-NPR-Z]{14}$/;
    expect(pattern.test('0C4RJFDJXEC365477')).toBe(false);
  });

  it('should accept all valid VIN examples', () => {
    const pattern = /^[1-9A-HJ-NPR-Z]{3}[0-9A-HJ-NPR-Z]{14}$/;
    expect(pattern.test('1C4RJFDJXEC365477')).toBe(true);
    expect(pattern.test('1C4RJFN9XJC309165')).toBe(true);
    expect(pattern.test('2B3CJ4DV6AH300549')).toBe(true);
  });
});

describe('EEPROMVisualizer - Hex Dump Rendering', () => {
  it('should convert bytes to hex string', () => {
    const byte = 0xAB;
    const hex = byte.toString(16).toUpperCase().padStart(2, '0');
    expect(hex).toBe('AB');
  });

  it('should format offset as 6-digit hex', () => {
    const offset = 0x275;
    const hex = offset.toString(16).toUpperCase().padStart(6, '0');
    expect(hex).toBe('000275');
  });

  it('should handle 16-byte rows', () => {
    const data = new Uint8Array(16);
    for (let i = 0; i < 16; i++) {
      data[i] = i + 0x10;
    }
    const hex = Array.from(data)
      .map((b) => b.toString(16).toUpperCase().padStart(2, '0'))
      .join(' ');
    expect(hex).toBe('10 11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1E 1F');
  });

  it('should replace non-printable characters with dots', () => {
    const data = new Uint8Array([0x41, 0x00, 0x42]); // A, null, B
    const ascii = new TextDecoder('utf-8', { fatal: false }).decode(data)
      .replace(/[^\x20-\x7E]/g, '.');
    expect(ascii).toBe('A.B');
  });
});

describe('EEPROMVisualizer - File Type Detection', () => {
  it('should detect RFHUB by file size (8192 bytes)', () => {
    const fileSize = 8192;
    const fileType = fileSize === 8192 ? 'rfhub' : 'unknown';
    expect(fileType).toBe('rfhub');
  });

  it('should detect BCM by file size (65536 bytes)', () => {
    const fileSize = 65536;
    const fileType = fileSize === 65536 ? 'bcm' : 'unknown';
    expect(fileType).toBe('bcm');
  });

  it('should return unknown for other sizes', () => {
    const fileSize = 1024;
    const fileType = fileSize === 8192 ? 'rfhub' : fileSize === 65536 ? 'bcm' : 'unknown';
    expect(fileType).toBe('unknown');
  });
});
