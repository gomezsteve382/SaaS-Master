import { useState, useCallback, useRef, useEffect } from "react";

/* ═══ CRC ═══ */
function crc16ccitt(d){var c=0xFFFF;for(var i=0;i<d.length;i++){c^=d[i]<<8;for(var j=0;j<8;j++)c=c&0x8000?((c<<1)^0x1021)&0xFFFF:(c<<1)&0xFFFF;}return c;}
function crc8p26(d){var c=0;for(var i=0;i<d.length;i++){c^=d[i];for(var j=0;j<8;j++)c=c&0x80?((c<<1)^0x26)&0xFF:(c<<1)&0xFF;}return c;}
function crc8ref(d){var c=0x54;for(var i=0;i<d.length;i++){c^=d[i];for(var j=0;j<8;j++)c=c&1?(c>>1)^0xA0:c>>1;}return c&0xFF;}
function hx(n,w){return"0x"+n.toString(16).toUpperCase().padStart(w||4,"0");}
function hxb(d){return Array.from(d).map(function(b){return b.toString(16).toUpperCase().padStart(2,"0");}).join(" ");}
function asc(d){var s="";for(var i=0;i<d.length;i++){var b=d[i];s+=(b>=0x20&&b<=0x7E)?String.fromCharCode(b):".";}return s;}
function extractVin(data,off){if(off+17>data.length)return null;var s="";for(var i=0;i<17;i++){var b=data[off+i];if(b<0x20||b>0x7E)return null;s+=String.fromCharCode(b);}if(!/^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/.test(s))return null;return s;}
var TR={A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9};for(var dd=0;dd<=9;dd++)TR[String(dd)]=dd;
var WT=[8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2];
function ckd(v){var s=0;for(var i=0;i<17;i++)s+=(TR[v[i]]||0)*WT[i];return"0123456789X"[s%11]===v[8];}

var RC={vin:"#34d399",security:"#c084fc",crc:"#fb7185",fob:"#60a5fa",part:"#fbbf24",config:"#22d3ee"};
function getRegions(t,d){var r=[];if(t==="bcm"){for(var i=0;i<=d.length-19;i++){var v=extractVin(d,i);if(!v||!ckd(v))continue;var sc=(d[i+17]<<8)|d[i+18];if(sc===crc16ccitt(d.slice(i,i+17))){r.push({start:i,len:17,label:"VIN",color:"vin"},{start:i+17,len:2,label:"CRC",color:"crc"});i+=16;}}r.push({start:0x40C0,len:32,label:"Security",color:"security"},{start:0x40F0,len:18,label:"Backup",color:"security"},{start:0x2000,len:32,label:"Sec2000",color:"security"});}
else if(t==="95640"){r.push({start:0x274,len:1,label:"CRC",color:"crc"},{start:0x275,len:17,label:"VIN1",color:"vin"},{start:0x287,len:1,label:"CRC",color:"crc"},{start:0x288,len:17,label:"VIN2",color:"vin"},{start:0x40,len:16,label:"Key",color:"security"},{start:0x200,len:64,label:"Fob",color:"fob"},{start:0x20,len:80,label:"Part",color:"part"});}
else if(t==="rfhub_eee"){[0xEA5,0xEB9,0xECD,0xEE1].forEach(function(o,i){r.push({start:o,len:17,label:"VIN"+(i+1),color:"vin"},{start:o+17,len:1,label:"CRC",color:"crc"});});r.push({start:0x40,len:16,label:"Key",color:"security"},{start:0xF90,len:112,label:"Part",color:"part"});}
else if(t==="gpec2a"){r.push({start:0,len:17,label:"VIN1",color:"vin"},{start:0x1F0,len:17,label:"VIN2",color:"vin"},{start:0x224,len:17,label:"VIN3",color:"vin"},{start:0x800,len:64,label:"Config",color:"config"});}return r;}
function regAt(rs,o){for(var i=0;i<rs.length;i++){var r=rs[i];if(o>=r.start&&o<r.start+r.len)return r;}return null;}

function analyze(data,fn){var sz=data.length,m={fileName:fn,size:sz,type:"unknown",vins:[],securityKey:null,securityKeyOffset:-1,securityKeyBlank:true,immoKey:null,immoKeyBlank:true,fobBlank:true,raw:data,backup2000:null,backup2000Blank:true,immoKeysMatch:true};
  if(sz===65536||sz===131072){m.type="bcm";for(var i=0;i<=sz-19;i++){var v=extractVin(data,i);if(!v||!ckd(v))continue;var sc=(data[i+17]<<8)|data[i+18];if(sc===crc16ccitt(data.slice(i,i+17))){m.vins.push({offset:i,vin:v});i+=16;}}var sb=data.slice(0x40C0,0x40E0),sbb=true;for(var j=0;j<sb.length;j++)if(sb[j]!==0xFF){sbb=false;break;}if(!sbb){m.immoKey=data.slice(0x40C8,0x40DA);m.immoKeyBlank=false;var k2=data.slice(0x40F0,0x4102);m.immoKeyBackup=k2;m.immoKeysMatch=true;for(var j=0;j<m.immoKey.length;j++)if(m.immoKey[j]!==k2[j]){m.immoKeysMatch=false;break;}}var s2=data.slice(0x2000,0x2020);m.backup2000Blank=true;for(var j=0;j<s2.length;j++)if(s2[j]!==0xFF){m.backup2000Blank=false;break;}if(!m.backup2000Blank)m.backup2000=s2;}
  else if(sz===8192||sz===16384){m.type="95640";var v1=extractVin(data,0x275);if(v1)m.vins.push({offset:0x275,vin:v1});var v2=extractVin(data,0x288);if(v2)m.vins.push({offset:0x288,vin:v2});m.securityKey=data.slice(0x40,0x50);m.securityKeyOffset=0x40;m.securityKeyBlank=true;for(var j=0;j<16;j++)if(m.securityKey[j]!==0xFF){m.securityKeyBlank=false;break;}m.fobBlank=true;for(var j=0;j<64;j++)if(data[0x200+j]!==0xFF){m.fobBlank=false;break;}}
  else if(sz===4096){var v0=extractVin(data,0);if(v0){m.type="gpec2a";m.vins.push({offset:0,vin:v0});var vb=extractVin(data,0x1F0);if(vb)m.vins.push({offset:0x1F0,vin:vb});var vc=extractVin(data,0x224);if(vc)m.vins.push({offset:0x224,vin:vc});}else{m.type="rfhub_eee";[0xEA5,0xEB9,0xECD,0xEE1].forEach(function(off){if(off+17>data.length||m.vins.length>0)return;var st=data.slice(off,off+17),hd=false;for(var j=0;j<17;j++)if(st[j]!==0xFF&&st[j]!==0x00){hd=true;break;}if(!hd)return;var rv=new Uint8Array(17);for(var j=0;j<17;j++)rv[j]=st[16-j];var s="";for(var j=0;j<17;j++)s+=String.fromCharCode(rv[j]);m.vins.push({offset:off,vin:s,mirrored:true});});m.securityKey=data.slice(0x40,0x50);m.securityKeyOffset=0x40;m.securityKeyBlank=true;for(var j=0;j<16;j++)if(m.securityKey[j]!==0xFF){m.securityKeyBlank=false;break;}}}return m;}

var TY={bcm:{l:"BCM D-FLASH",c:"#f59e0b",e:"🔶"},"95640":{l:"FCA 95640",c:"#a855f7",e:"💎"},rfhub_eee:{l:"RFHUB EEE",c:"#06b6d4",e:"📡"},gpec2a:{l:"GPEC2A ECM",c:"#22c55e",e:"🧠"}};

/* ═══ ANIMATED CARD ═══ */
function Card({children,delay,color,onClick,glow}){
  var _h=useState(false),hov=_h[0],setHov=_h[1];
  var _v=useState(false),vis=_v[0],setVis=_v[1];
  useEffect(function(){var t=setTimeout(function(){setVis(true);},delay||0);return function(){clearTimeout(t);};},[]);
  return(<div onClick={onClick} onMouseEnter={function(){setHov(true);}} onMouseLeave={function(){setHov(false);}}
    style={{background:hov?"linear-gradient(145deg,#1e1e2a,#16161f)":"linear-gradient(145deg,#1a1a24,#13131a)",
      borderRadius:16,padding:20,cursor:onClick?"pointer":"default",
      transform:vis?(hov?"translateY(-4px) scale(1.02)":"translateY(0) scale(1)"):"translateY(20px) scale(0.95)",
      opacity:vis?1:0,transition:"all 0.4s cubic-bezier(0.34,1.56,0.64,1)",
      boxShadow:hov?("0 8px 32px rgba(0,0,0,0.4), 0 0 0 1px "+(color||"#333")+"44, inset 0 1px 0 rgba(255,255,255,0.05)"):"0 2px 8px rgba(0,0,0,0.3), 0 0 0 1px #ffffff08, inset 0 1px 0 rgba(255,255,255,0.03)",
      position:"relative",overflow:"hidden"}}>
    {glow&&<div style={{position:"absolute",top:-20,right:-20,width:80,height:80,background:"radial-gradient(circle,"+(color||"#fff")+"22,transparent 70%)",pointerEvents:"none",transition:"opacity 0.3s",opacity:hov?1:0.4}}/>}
    {children}
  </div>);
}

/* ═══ PILL BADGE ═══ */
function Pill({color,children}){return <span style={{background:color+"18",color:color,border:"1px solid "+color+"33",borderRadius:20,padding:"3px 10px",fontSize:9,fontWeight:700,display:"inline-block"}}>{children}</span>;}

/* ═══ HEX VIEWER ═══ */
function HexView({data,regions,selOff,onSel}){var _p=useState(0),pg=_p[0],setPg=_p[1];var _j=useState(""),jmp=_j[0],setJmp=_j[1];var rpp=26,BPR=16,totR=Math.ceil(data.length/BPR),totP=Math.ceil(totR/rpp),sR=pg*rpp;
function go(){var o=parseInt(jmp.replace(/^0x/i,""),16);if(!isNaN(o)&&o>=0&&o<data.length){setPg(Math.floor(o/BPR/rpp));if(onSel)onSel(o);}}
var rows=[];for(var row=sR;row<Math.min(sR+rpp,totR);row++){var off=row*BPR,hc=[],ac=[];for(var col=0;col<BPR;col++){var bo=off+col;if(bo>=data.length){hc.push(<span key={col} style={{width:19,display:"inline-block"}}> </span>);continue;}var b=data[bo],reg=regAt(regions,bo),fg=reg?RC[reg.color]:"#4a4a5a",bg=reg?(RC[reg.color]+"10"):"transparent";if(!reg&&b===0xFF)fg="#252530";if(!reg&&b===0x00)fg="#303040";var iS=bo===selOff;hc.push(<span key={col} onClick={function(o){return function(){if(onSel)onSel(o);};}(bo)} style={{width:19,display:"inline-block",textAlign:"center",cursor:"pointer",background:iS?"#dc2626":bg,color:iS?"#fff":fg,borderRadius:iS?3:0,fontWeight:reg?700:400,fontSize:10,transition:"background 0.1s"}}>{b.toString(16).toUpperCase().padStart(2,"0")}</span>);ac.push(<span key={col} style={{color:reg?RC[reg.color]+"88":"#303040",fontSize:10}}>{b>=0x20&&b<=0x7E?String.fromCharCode(b):"."}</span>);}rows.push(<div key={row} style={{display:"flex",alignItems:"center",lineHeight:"18px",borderBottom:"1px solid #1a1a22"}}><span style={{width:52,color:"#4a4a5a",flexShrink:0,textAlign:"right",paddingRight:6,fontSize:9}}>{hx(off)}</span><span style={{flex:1}}>{hc}</span><span style={{width:5}}/><span style={{flexShrink:0}}>{ac}</span></div>);}
return(<div style={{background:"#111118",borderRadius:0,overflow:"hidden",height:"100%",display:"flex",flexDirection:"column",fontFamily:"'JetBrains Mono','Fira Code',monospace"}}>
<div style={{display:"flex",alignItems:"center",gap:6,padding:"6px 10px",borderBottom:"1px solid #1e1e28",background:"linear-gradient(180deg,#18181f,#111118)"}}>
  <span style={{fontSize:10,color:"#dc2626",fontWeight:900,letterSpacing:2}}>HEX</span>
  <input value={jmp} onChange={function(e){setJmp(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter")go();}} placeholder="offset" style={{width:70,background:"#1a1a24",border:"1px solid #2a2a36",borderRadius:6,padding:"3px 6px",color:"#ddd",fontSize:9,fontFamily:"inherit",outline:"none"}}/>
  <button onClick={go} style={{background:"#dc2626",color:"#fff",border:"none",borderRadius:6,padding:"3px 8px",fontSize:8,fontWeight:800,cursor:"pointer"}}>GO</button>
  <span style={{flex:1}}/>
  <button onClick={function(){setPg(Math.max(0,pg-1));}} style={{background:"#1e1e28",color:pg===0?"#1e1e28":"#aaa",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",fontSize:10}}>◀</button>
  <span style={{fontSize:9,color:"#4a4a5a"}}>{(pg+1)+"/"+totP}</span>
  <button onClick={function(){setPg(Math.min(totP-1,pg+1));}} style={{background:"#1e1e28",color:pg>=totP-1?"#1e1e28":"#aaa",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",fontSize:10}}>▶</button>
</div>
<div style={{display:"flex",gap:8,padding:"3px 10px",borderBottom:"1px solid #1a1a22"}}>{[{c:"vin",l:"VIN"},{c:"security",l:"Security"},{c:"crc",l:"CRC"},{c:"fob",l:"Fob"},{c:"part",l:"Part#"},{c:"config",l:"Config"}].map(function(x){return <span key={x.c} style={{fontSize:7,color:RC[x.c],fontWeight:700}}>{"● "+x.l}</span>;})}</div>
<div style={{flex:1,overflow:"auto",padding:"2px 4px"}}>{rows}</div>
{selOff!==null&&selOff>=0&&selOff<data.length&&(<div style={{padding:"4px 10px",borderTop:"1px solid #1e1e28",background:"linear-gradient(180deg,#18181f,#111118)",display:"flex",gap:12,fontSize:9,color:"#4a4a5a"}}><span>Offset: <b style={{color:"#fb7185"}}>{hx(selOff)}</b></span><span>Value: <b style={{color:"#fb7185"}}>{"0x"+data[selOff].toString(16).toUpperCase().padStart(2,"0")}</b></span>{(function(){var r=regAt(regions,selOff);return r?<span><b style={{color:RC[r.color]}}>{r.label}</b></span>:null;})()}</div>)}</div>);}

/* ═══ MAIN ═══ */
export default function App(){
  var _m=useState([]),modules=_m[0],setModules=_m[1];var _sel=useState(0),selMod=_sel[0],setSelMod=_sel[1];var _so=useState(null),selOff=_so[0],setSelOff=_so[1];var _tv=useState(""),tVin=_tv[0],setTVin=_tv[1];var _msg=useState(null),msg=_msg[0],setMsg=_msg[1];var _view=useState("dash"),view=_view[0],setView=_view[1];var fRef=useRef(null);
  var _ready=useState(false),ready=_ready[0];useEffect(function(){setTimeout(function(){_ready[1](true);},100);},[]);

  var addFiles=useCallback(function(e){var fl=e.target.files;if(!fl||fl.length===0)return;var ps=[];for(var i=0;i<fl.length;i++){(function(f){ps.push(new Promise(function(res){var r=new FileReader();r.onload=function(){res(analyze(new Uint8Array(r.result),f.name));};r.readAsArrayBuffer(f);}));})(fl[i]);}Promise.all(ps).then(function(nm){setModules(function(p){var u=p.slice();for(var i=0;i<nm.length;i++)if(nm[i].type!=="unknown")u.push(nm[i]);if(!tVin)for(var j=0;j<u.length;j++)if(u[j].vins.length>0){setTVin(u[j].vins[0].vin);break;}return u;});setView("work");});if(fRef.current)fRef.current.value="";},[tVin]);

  function dl(d,n){var b=new Blob([d],{type:"application/octet-stream"}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=n;document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(u);}
  function patchVin(mi,nv){var m=modules[mi],p=new Uint8Array(m.raw),u=nv.toUpperCase(),vb=[];for(var i=0;i<17;i++)vb.push(u.charCodeAt(i));var va=new Uint8Array(vb);if(m.type==="bcm")m.vins.forEach(function(v){for(var j=0;j<17;j++)p[v.offset+j]=vb[j];var c=crc16ccitt(va);p[v.offset+17]=(c>>8)&0xFF;p[v.offset+18]=c&0xFF;});else if(m.type==="95640")[0x275,0x288].forEach(function(o){for(var j=0;j<17;j++)p[o+j]=vb[j];p[o-1]=crc8p26(va);});else if(m.type==="rfhub_eee"){var mir=[];for(var j=16;j>=0;j--)mir.push(vb[j]);var ma=new Uint8Array(mir);[0xEA5,0xEB9,0xECD,0xEE1].forEach(function(o){if(o+18>p.length)return;for(var j=0;j<17;j++)p[o+j]=mir[j];p[o+17]=crc8ref(ma);});}else if(m.type==="gpec2a")[0,0x1F0,0x224].forEach(function(o){if(o+17>p.length)return;for(var j=0;j<17;j++)p[o+j]=vb[j];});var di=m.fileName.lastIndexOf("."),nm=di>0?m.fileName.slice(0,di):m.fileName,ex=di>0?m.fileName.slice(di):".bin";dl(p,nm+"_VIN_"+u+ex);setMsg("✓ "+m.type.toUpperCase()+" patched → "+u);}
  function virginize(mi){var m=modules[mi],p=new Uint8Array(m.raw);if(m.type==="95640"){for(var j=0;j<17;j++){p[0x275+j]=0;p[0x288+j]=0;}p[0x274]=0;p[0x287]=0;for(var i=0;i<16;i++)p[0x40+i]=0xFF;}else if(m.type==="rfhub_eee"){[0xEA5,0xEB9,0xECD,0xEE1].forEach(function(o){for(var j=0;j<18;j++)if(o+j<p.length)p[o+j]=0;});for(var i=0;i<16;i++)p[0x40+i]=0xFF;}else if(m.type==="bcm")m.vins.forEach(function(v){for(var j=0;j<19;j++)p[v.offset+j]=0;});else if(m.type==="gpec2a")[0,0x1F0,0x224].forEach(function(o){for(var j=0;j<17;j++)if(o+j<p.length)p[o+j]=0;});var di=m.fileName.lastIndexOf("."),nm=di>0?m.fileName.slice(0,di):m.fileName,ex=di>0?m.fileName.slice(di):".bin";dl(p,nm+"_VIRGINIZED"+ex);setMsg("⚠ "+m.type.toUpperCase()+" virginized");}

  var cur=modules[selMod]||null,curReg=cur?getRegions(cur.type,cur.raw):[],allV=[];modules.forEach(function(m){m.vins.forEach(function(v){if(allV.indexOf(v.vin)===-1)allV.push(v.vin);});});var vinMM=allV.length>1;

  var tools=[
    {i:"⚡",t:"VIN Patcher",d:"Write VIN + auto CRC recalculation across all module types",c:"#dc2626",tag:"CORE"},
    {i:"🔓",t:"ECU Unlock",d:"Unlock GPEC2A, GPEC3, GPEC4 on bench and OBD",c:"#f59e0b",tag:"COMING SOON"},
    {i:"🔑",t:"Security Match",d:"Compare & sync immobilizer keys between mismatched modules",c:"#c084fc",tag:"CORE"},
    {i:"💀",t:"Virginizer",d:"Factory reset — erase VINs, secret keys, fob data",c:"#fb7185",tag:"CORE"},
    {i:"📊",t:"Hex Viewer",d:"Full binary dump with color-coded security regions",c:"#22d3ee",tag:"CORE"},
    {i:"🔐",t:"Seed-Key Calc",d:"18 algorithms — CDA6, SBEC2, NGC3/4, XTEA, SKIM/WCM, RFHUB",c:"#34d399",tag:"CORE"},
  ];
  var mods=[{l:"BCM D-FLASH",c:"#f59e0b",s:"64/128KB",d:"CRC-16 CCITT-FALSE"},{l:"FCA 95640",c:"#c084fc",s:"8KB",d:"CRC-8 poly=0x26"},{l:"RFHUB EEE",c:"#22d3ee",s:"4KB",d:"Mirrored VIN · Reflected CRC-8"},{l:"GPEC2A ECM",c:"#34d399",s:"4KB",d:"3 VIN slots · No CRC"},{l:"GPEC3",c:"#34d399",s:"—",d:"Coming soon"},{l:"GPEC4",c:"#34d399",s:"—",d:"Coming soon"}];

  var css = `
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;700&display=swap');
    @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
    @keyframes pulse{0%,100%{opacity:0.4}50%{opacity:1}}
    @keyframes slideUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
    @keyframes glow{0%,100%{text-shadow:0 0 20px #dc262688}50%{text-shadow:0 0 40px #dc2626cc,0 0 80px #dc262644}}
    @keyframes scan{0%{background-position:0% 0%}100%{background-position:0% 100%}}
  `;

  /* ═══ DASHBOARD ═══ */
  if(view==="dash")return(
    <div style={{minHeight:"100vh",background:"linear-gradient(180deg,#0f0f14 0%,#0a0a0f 50%,#0d0d14 100%)",color:"#e4e4e7",fontFamily:"'Outfit','SF Pro Display',sans-serif"}}>
      <style>{css}</style>
      <input ref={fRef} type="file" accept=".bin,.BIN,.eee,.EEE" multiple onChange={addFiles} style={{display:"none"}}/>

      {/* HERO */}
      <div style={{padding:"48px 20px 36px",textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:0,left:"50%",transform:"translateX(-50%)",width:600,height:300,background:"radial-gradient(ellipse,#dc262612,transparent 70%)",pointerEvents:"none"}}/>
        <div style={{position:"relative",animation:"slideUp 0.8s ease-out"}}>
          <div style={{fontSize:12,fontWeight:800,color:"#dc2626",letterSpacing:8,marginBottom:6}}>THE SRT LAB</div>
          <div style={{fontSize:38,fontWeight:900,letterSpacing:4,lineHeight:1}}>
            <span style={{color:"#fff"}}>JAILBREAK</span>
          </div>
          <div style={{fontSize:38,fontWeight:900,letterSpacing:4,lineHeight:1,color:"#dc2626",animation:"glow 3s ease-in-out infinite"}}>EDITION</div>
          <div style={{fontSize:11,color:"#555",marginTop:12,letterSpacing:3,fontFamily:"'JetBrains Mono',monospace"}}>FCA / STELLANTIS MODULE WORKBENCH</div>
        </div>
      </div>

      <div style={{maxWidth:880,margin:"0 auto",padding:"0 16px 60px"}}>
        {/* UPLOAD */}
        <Card delay={200} color="#dc2626" onClick={function(){if(fRef.current)fRef.current.click();}} glow>
          <div style={{textAlign:"center",padding:"8px 0"}}>
            <div style={{fontSize:28,marginBottom:8,animation:"float 3s ease-in-out infinite"}}>🚀</div>
            <div style={{fontSize:16,fontWeight:900,color:"#fff",letterSpacing:1}}>LOAD MODULE FILES</div>
            <div style={{fontSize:10,color:"#666",marginTop:4}}>BCM · 95640 · RFHUB EEE · GPEC2A — Multi-select supported</div>
          </div>
        </Card>

        {/* TOOLS */}
        <div style={{fontSize:10,fontWeight:800,color:"#555",letterSpacing:4,marginTop:28,marginBottom:14}}>TOOLS</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:12}}>
          {tools.map(function(t,i){return(
            <Card key={i} delay={300+i*100} color={t.c} onClick={function(){if(fRef.current)fRef.current.click();}} glow>
              <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
                <div style={{fontSize:28,flexShrink:0,animation:"float "+(2.5+i*0.3)+"s ease-in-out infinite"}}>{t.i}</div>
                <div>
                  <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
                    <span style={{fontSize:13,fontWeight:900,color:"#fff"}}>{t.t}</span>
                    <Pill color={t.tag==="COMING SOON"?"#f59e0b":t.c}>{t.tag}</Pill>
                  </div>
                  <div style={{fontSize:10,color:"#666",lineHeight:1.4}}>{t.d}</div>
                </div>
              </div>
            </Card>);})}
        </div>

        {/* MODULES */}
        <div style={{fontSize:10,fontWeight:800,color:"#555",letterSpacing:4,marginTop:28,marginBottom:14}}>SUPPORTED MODULES</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:8}}>
          {mods.map(function(m,i){return(
            <Card key={i} delay={900+i*80} color={m.c}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:10,height:10,borderRadius:5,background:m.c,boxShadow:"0 0 8px "+m.c+"66",flexShrink:0}}/>
                <div>
                  <div style={{fontSize:11,fontWeight:800,color:m.c}}>{m.l}</div>
                  <div style={{fontSize:8,color:"#555"}}>{m.s} · {m.d}</div>
                </div>
              </div>
            </Card>);})}
        </div>

        {/* STATS */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginTop:20}}>
          {[{n:"18",l:"Algorithms",c:"#dc2626"},{n:"4",l:"Modules",c:"#f59e0b"},{n:"3",l:"CRC Engines",c:"#c084fc"},{n:"∞",l:"VINs",c:"#34d399"}].map(function(s,i){return(
            <Card key={i} delay={1400+i*100} color={s.c}>
              <div style={{textAlign:"center"}}>
                <div style={{fontSize:26,fontWeight:900,color:s.c}}>{s.n}</div>
                <div style={{fontSize:8,color:"#555"}}>{s.l}</div>
              </div>
            </Card>);})}
        </div>
        {msg&&<div style={{marginTop:16,fontSize:11,color:"#34d399",background:"#34d39910",border:"1px solid #34d39933",borderRadius:12,padding:"10px 14px",animation:"slideUp 0.3s"}}>{msg}</div>}
      </div>
    </div>);

  /* ═══ WORKBENCH ═══ */
  return(
    <div style={{minHeight:"100vh",background:"#0f0f14",color:"#e4e4e7",fontFamily:"'Outfit',sans-serif",fontSize:11}}>
      <style>{css}</style>
      <input ref={fRef} type="file" accept=".bin,.BIN,.eee,.EEE" multiple onChange={addFiles} style={{display:"none"}}/>
      <div style={{background:"linear-gradient(180deg,#151518,#0f0f14)",borderBottom:"2px solid #dc262644",padding:"6px 14px",display:"flex",alignItems:"center",gap:8}}>
        <button onClick={function(){setView("dash");}} style={{background:"none",border:"none",color:"#dc2626",cursor:"pointer",fontSize:16,padding:"0 4px"}}>←</button>
        <span style={{fontSize:9,fontWeight:900,color:"#dc2626",letterSpacing:3}}>SRT LAB</span>
        <span style={{fontSize:13,fontWeight:900,letterSpacing:2}}>JAILBREAK</span>
        <span style={{flex:1}}/>
        <button onClick={function(){if(fRef.current)fRef.current.click();}} style={{background:"#dc262618",border:"1px solid #dc262644",borderRadius:8,padding:"4px 12px",cursor:"pointer",color:"#dc2626",fontSize:10,fontWeight:800,fontFamily:"inherit"}}>+ ADD</button>
      </div>
      {modules.length>0&&(<div style={{display:"flex",gap:4,padding:"6px 14px",borderBottom:"1px solid #1a1a22",background:"#111118",overflowX:"auto"}}>
        {modules.map(function(m,i){var tc=TY[m.type]||{l:"?",c:"#666",e:"?"},act=i===selMod;return(
          <button key={i} onClick={function(){setSelMod(i);}} style={{background:act?"#dc262618":"transparent",border:"1px solid "+(act?"#dc262644":"#1e1e28"),borderRadius:8,padding:"4px 10px",cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:4,transition:"all 0.2s",flexShrink:0}}>
            <span style={{fontSize:12}}>{tc.e}</span>
            <span style={{fontSize:9,color:act?"#fff":"#555",fontWeight:act?700:400,maxWidth:120,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{m.fileName}</span>
            <span onClick={function(e){e.stopPropagation();setModules(function(p){var n=p.slice();n.splice(i,1);return n;});if(selMod>=modules.length-1)setSelMod(Math.max(0,modules.length-2));}} style={{color:"#333",cursor:"pointer",fontSize:9,marginLeft:2}}>✕</span>
          </button>);})}</div>)}
      {cur&&(<div style={{display:"flex",gap:0,height:"calc(100vh - 80px)"}}>
        <div style={{width:290,flexShrink:0,borderRight:"1px solid #1a1a22",overflow:"auto",padding:"12px",background:"#111116"}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:10}}>
            <span style={{fontSize:18}}>{(TY[cur.type]||{e:"?"}).e}</span>
            <Pill color={(TY[cur.type]||{c:"#666"}).c}>{(TY[cur.type]||{l:"?"}).l}</Pill>
            <span style={{fontSize:9,color:"#555"}}>{(cur.size/1024).toFixed(0)+"KB"}</span>
          </div>
          <div style={{background:"#1a1a24",borderRadius:12,padding:12,marginBottom:8,boxShadow:"inset 0 1px 0 #ffffff06"}}>
            <div style={{fontSize:8,color:"#dc2626",fontWeight:800,letterSpacing:2,marginBottom:4}}>TARGET VIN</div>
            <input value={tVin} onChange={function(e){setTVin(e.target.value.toUpperCase());}} maxLength={17} style={{width:"100%",background:"#13131a",border:"2px solid "+(tVin.length===17?"#34d399":"#2a2a36"),borderRadius:8,padding:"7px",color:"#fff",fontSize:12,fontWeight:900,letterSpacing:2,textAlign:"center",fontFamily:"'JetBrains Mono',monospace",outline:"none",boxSizing:"border-box",transition:"border-color 0.2s"}}/>
          </div>
          {cur.vins.length>0&&(<div style={{background:"#1a1a24",borderRadius:12,padding:12,marginBottom:8,boxShadow:"inset 0 1px 0 #ffffff06"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:8,color:"#666",fontWeight:700}}>CURRENT VIN</span><Pill color={cur.vins[0].vin===tVin?"#34d399":"#fb7185"}>{cur.vins[0].vin===tVin?"✓ MATCH":"✗ MISMATCH"}</Pill></div>
            <div style={{fontSize:13,fontWeight:900,letterSpacing:2,color:cur.vins[0].vin===tVin?"#34d399":"#fb7185",fontFamily:"'JetBrains Mono',monospace"}}>{cur.vins[0].vin}</div>
            {cur.vins[0].mirrored&&<div style={{fontSize:8,color:"#22d3ee",marginTop:2,fontWeight:700}}>📡 STORED MIRRORED</div>}
          </div>)}
          {cur.securityKey&&(<div style={{background:"#1a1a24",borderRadius:12,padding:12,marginBottom:8,boxShadow:"inset 0 1px 0 #ffffff06"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:8,color:"#666",fontWeight:700}}>SECRET KEY</span><Pill color={cur.securityKeyBlank?"#f59e0b":"#34d399"}>{cur.securityKeyBlank?"ERASED":"OK"}</Pill></div>
            <div style={{fontSize:10,color:cur.securityKeyBlank?"#2a2a36":"#c084fc",fontWeight:700,letterSpacing:1,wordBreak:"break-all",lineHeight:1.5,fontFamily:"'JetBrains Mono',monospace"}}>{hxb(cur.securityKey)}</div>
            {!cur.securityKeyBlank&&<div style={{fontSize:8,color:"#555",marginTop:2,fontFamily:"'JetBrains Mono',monospace"}}>{asc(cur.securityKey)}</div>}
          </div>)}
          {cur.type==="bcm"&&(<div style={{background:"#1a1a24",borderRadius:12,padding:12,marginBottom:8,boxShadow:"inset 0 1px 0 #ffffff06"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:8,color:"#666",fontWeight:700}}>IMMO KEY</span><Pill color={cur.immoKeyBlank?"#f59e0b":"#34d399"}>{cur.immoKeyBlank?"BLANK":"OK"}</Pill></div>
            {!cur.immoKeyBlank&&(<div><div style={{fontSize:10,color:"#c084fc",fontWeight:700,letterSpacing:1,wordBreak:"break-all",lineHeight:1.5,fontFamily:"'JetBrains Mono',monospace"}}>{hxb(cur.immoKey)}</div><div style={{fontSize:8,color:cur.immoKeysMatch?"#34d399":"#fb7185",marginTop:3,fontWeight:700}}>{"Backup: "+(cur.immoKeysMatch?"✓":"✗")}</div></div>)}
            <div style={{marginTop:4,paddingTop:4,borderTop:"1px solid #22222e",display:"flex",justifyContent:"space-between"}}><span style={{fontSize:8,color:"#444"}}>@ 0x2000</span><span style={{fontSize:8,color:cur.backup2000Blank?"#333":"#a78bfa",fontWeight:700}}>{cur.backup2000Blank?"—":"DATA"}</span></div>
            {!cur.backup2000Blank&&cur.backup2000&&<div style={{fontSize:8,color:"#a78bfa",marginTop:2,fontFamily:"'JetBrains Mono',monospace",wordBreak:"break-all"}}>{hxb(cur.backup2000.slice(0,16))}</div>}
          </div>)}
          {cur.type==="95640"&&<div style={{background:"#1a1a24",borderRadius:12,padding:10,marginBottom:8}}><span style={{fontSize:9,color:"#555"}}>Fob: </span><span style={{fontSize:9,color:cur.fobBlank?"#333":"#60a5fa",fontWeight:700}}>{cur.fobBlank?"NONE":"PROGRAMMED"}</span></div>}
          <div style={{display:"flex",flexDirection:"column",gap:6,marginTop:6}}>
            {tVin.length===17&&<button onClick={function(){patchVin(selMod,tVin);}} style={{width:"100%",padding:"11px",background:cur.vins.length>0&&cur.vins[0].vin===tVin?"linear-gradient(135deg,#052e16,#064e3b)":"linear-gradient(135deg,#dc2626,#b91c1c)",color:"#fff",border:"none",borderRadius:10,fontSize:11,fontWeight:900,cursor:"pointer",fontFamily:"inherit",letterSpacing:1,boxShadow:"0 4px 12px "+(cur.vins.length>0&&cur.vins[0].vin===tVin?"#34d39922":"#dc262633"),transition:"transform 0.15s"}}>{cur.vins.length>0&&cur.vins[0].vin===tVin?"↓ DOWNLOAD":"⚡ PATCH VIN + DOWNLOAD"}</button>}
            <button onClick={function(){virginize(selMod);}} style={{width:"100%",padding:"9px",background:"linear-gradient(135deg,#1a1a24,#22222e)",color:"#fb7185",border:"1px solid #fb718533",borderRadius:10,fontSize:10,fontWeight:800,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}>💀 VIRGINIZE</button>
            {tVin.length===17&&vinMM&&<button onClick={function(){modules.forEach(function(m,i){if(m.vins.length>0&&m.vins[0].vin!==tVin)patchVin(i,tVin);});}} style={{width:"100%",padding:"9px",background:"linear-gradient(135deg,#1a1a24,#22222e)",color:"#c084fc",border:"1px solid #c084fc33",borderRadius:10,fontSize:10,fontWeight:800,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}>🔗 PATCH ALL → TARGET</button>}
            <button onClick={function(){setView("dash");}} style={{width:"100%",padding:"8px",background:"transparent",color:"#555",border:"1px solid #22222e",borderRadius:10,fontSize:9,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>← DASHBOARD</button>
          </div>
          {modules.length>1&&<div style={{marginTop:8}}><Pill color={vinMM?"#fb7185":"#34d399"}>{vinMM?"⚠ "+allV.length+" VINs":"✓ ALL MATCH"}</Pill></div>}
          {msg&&<div style={{marginTop:6,fontSize:9,color:"#34d399",background:"#34d39910",borderRadius:8,padding:"6px 8px"}}>{msg}</div>}
        </div>
        <div style={{flex:1,minWidth:0}}><HexView data={cur.raw} regions={curReg} selOff={selOff} onSel={setSelOff}/></div>
      </div>)}
    </div>);
}
