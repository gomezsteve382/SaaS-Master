import { useState, useCallback, useMemo, useRef } from "react";

/* ═══ CRC-16/CCITT-FALSE ═══ */
function crc16ccitt(data) {
  let crc = 0xffff;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i] << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) crc = ((crc << 1) ^ 0x1021) & 0xffff;
      else crc = (crc << 1) & 0xffff;
    }
  }
  return crc;
}

/* ═══ CRC-8 poly=0x26 ═══ */
function crc8p26(data) {
  let crc = 0x00;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (let j = 0; j < 8; j++) {
      if (crc & 0x80) crc = ((crc << 1) ^ 0x26) & 0xff;
      else crc = (crc << 1) & 0xff;
    }
  }
  return crc;
}

/* ═══ VIN check digit (ISO 3779) ═══ */
const TR = {A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9};
for (let d = 0; d <= 9; d++) TR[String(d)] = d;
const WT = [8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2];
const CM = "0123456789X";
const WMI = {"1C4":"Chrysler · US","2C3":"Dodge · CA","3C7":"RAM · MX","1C6":"RAM · US","2C4":"Chrysler · CA","1J4":"Jeep · US","1B3":"Dodge · US","2B3":"Dodge · CA","3C6":"RAM · MX","3D7":"RAM · MX"};
const YR = {A:2010,B:2011,C:2012,D:2013,E:2014,F:2015,G:2016,H:2017,J:2018,K:2019,L:2020,M:2021,N:2022,P:2023,R:2024,S:2025,T:2026};

function checkVin(vin) {
  if (!vin || vin.length !== 17) return { ok: false, err: "Need 17 chars" };
  var u = vin.toUpperCase();
  if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(u)) return { ok: false, err: "Bad chars (I,O,Q banned)" };
  var sum = 0;
  for (var i = 0; i < 17; i++) {
    var v = TR[u[i]];
    if (v === undefined) return { ok: false, err: "Bad char pos " + (i + 1) };
    sum += v * WT[i];
  }
  var exp = CM[sum % 11];
  var wmi = u.slice(0, 3);
  return {
    ok: u[8] === exp,
    err: u[8] !== exp ? "Check digit: need " + exp + " got " + u[8] : null,
    cd: exp, wmi: wmi,
    mfr: WMI[wmi] || "Unknown",
    yr: YR[u[9]] || "?",
  };
}

/* ═══ CRC-8 Reflected poly=0xA0 init=0x54 (RFHUB EEE) ═══ */
function crc8ref(data) {
  var crc = 0x54;
  for (var i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (var j = 0; j < 8; j++) {
      if (crc & 1) crc = ((crc >> 1) ^ 0xA0);
      else crc = crc >> 1;
    }
  }
  return crc & 0xFF;
}

/* ═══ Analyze binary ═══ */
function analyze(buf) {
  var data = new Uint8Array(buf);
  var sz = data.length;
  var ft = "?";
  if (sz === 65536 || sz === 131072) ft = "bcm";
  else if (sz === 1048576) ft = "cfl";
  else if (sz === 8192 || sz === 16384) ft = "ee";
  else if (sz === 4096) {
    // 4KB: distinguish RFHUB EEE (mirrored VINs at 0x0EA5) from GPEC2A (VINs at 0x0000)
    // Check if 0x0EA5 area has printable ASCII (VIN data)
    var hasRfhubVin = true;
    for (var j = 0; j < 17; j++) {
      if (data[0x0EA5 + j] < 0x20 || data[0x0EA5 + j] > 0x7E) { hasRfhubVin = false; break; }
    }
    ft = hasRfhubVin ? "rfhub" : "gp";
  }

  var fulls = [];
  var parts = [];
  var pat = /^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/;

  // RFHUB EEE: VINs stored REVERSED at known offsets
  if (ft === "rfhub") {
    var rfhubSlots = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
    for (var si = 0; si < rfhubSlots.length; si++) {
      var voff = rfhubSlots[si];
      if (voff + 18 > sz) continue;
      // Read stored bytes
      var stored = data.slice(voff, voff + 17);
      // Check all printable
      var allPrint = true;
      for (var j = 0; j < 17; j++) { if (stored[j] < 0x20 || stored[j] > 0x7E) { allPrint = false; break; } }
      if (!allPrint) continue;
      // Reverse to get real VIN
      var reversed = new Uint8Array(17);
      for (var j = 0; j < 17; j++) reversed[j] = stored[16 - j];
      var realVin = "";
      for (var j = 0; j < 17; j++) realVin += String.fromCharCode(reversed[j]);
      // Validate check digit on real VIN
      var cv = checkVin(realVin);
      // CRC: reflected CRC-8 poly=0xA0 init=0x54 on STORED (reversed) bytes
      var coff = voff + 17;
      var sc = data[coff];
      var cc = crc8ref(stored);
      var crcOk = (sc === cc);
      // Accept at known offsets regardless of CRC (might be pre-patch)
      fulls.push({ off: voff, vin: realVin, algo: "cr8", coff: coff, sc: sc, cc: cc, ok: crcOk, cv: cv, mirrored: true });
    }
    return { ft: ft, sz: sz, F: fulls, P: parts, raw: data, sec: null };
  }

  // Standard forward-VIN scan for all other file types
  for (var i = 0; i <= sz - 19; i++) {
    var ok = true;
    for (var j = 0; j < 17; j++) {
      if (data[i + j] < 0x20 || data[i + j] > 0x7e) { ok = false; break; }
    }
    if (!ok) continue;
    var s = "";
    for (var j = 0; j < 17; j++) s += String.fromCharCode(data[i + j]);
    if (!pat.test(s)) continue;
    var cv = checkVin(s);
    if (!cv.ok) continue;

    var slice17 = data.slice(i, i + 17);

    if (ft === "ee" && i > 0) {
      var sc = data[i - 1];
      var cc = crc8p26(slice17);
      var crcOk = (sc === cc);
      // Only accept VINs at known 95640 offsets (0x275, 0x288) or where CRC validates
      var knownSlot = (i === 0x0275 || i === 0x0288);
      if (!crcOk && !knownSlot) continue;
      fulls.push({ off: i, vin: s, algo: "c8", coff: i - 1, sc: sc, cc: cc, ok: crcOk, cv: cv });
    } else if (ft === "gp") {
      fulls.push({ off: i, vin: s, algo: "no", coff: -1, sc: 0, cc: 0, ok: true, cv: cv });
    } else {
      var sc = (data[i + 17] << 8) | data[i + 18];
      var cc = crc16ccitt(slice17);
      var crcOk = (sc === cc);
      // For BCM: only skip if CRC mismatches AND check digit passed by coincidence (part numbers)
      // Real VINs with wrong CRC (already patched without recalc) should still show
      if (!crcOk && !cv.ok) continue;
      fulls.push({ off: i, vin: s, algo: "c16", coff: i + 17, sc: sc, cc: cc, ok: crcOk, cv: cv });
    }
  }

  // Partial VINs (BCM only)
  if ((ft === "bcm" || ft === "cfl") && fulls.length > 0) {
    var ref = fulls[0].vin;
    for (var f = 0; f < fulls.length; f++) { if (fulls[f].ok) { ref = fulls[f].vin; break; } }
    var t8 = ref.slice(9);
    var tc = [];
    for (var k = 0; k < 8; k++) tc.push(t8.charCodeAt(k));

    for (var i = 0; i <= sz - 10; i++) {
      var m = true;
      for (var j = 0; j < 8; j++) { if (data[i + j] !== tc[j]) { m = false; break; } }
      if (!m) continue;
      var inFull = false;
      for (var f = 0; f < fulls.length; f++) {
        if (i >= fulls[f].off && i < fulls[f].off + 17) { inFull = true; break; }
      }
      if (inFull) continue;
      var sc = (data[i + 8] << 8) | data[i + 9];
      var cc = crc16ccitt(data.slice(i, i + 8));
      if (sc !== cc) continue;
      parts.push({ off: i, vin: t8, algo: "c16", coff: i + 8, sc: sc, cc: cc });
    }
  }

  // Security bytes analysis
  var sec = null;
  if (ft === "bcm" || ft === "cfl") {
    sec = { type: "bcm" };
    // Security block @ 0x40C0 (primary)
    var sb1 = data.slice(0x40C0, 0x40E0);
    var sb1blank = true;
    for (var j = 0; j < sb1.length; j++) { if (sb1[j] !== 0xFF) { sb1blank = false; break; } }
    sec.block1 = sb1;
    sec.block1blank = sb1blank;
    // Security key bytes (skip 8-byte header)
    sec.key1 = data.slice(0x40C8, 0x40DA);
    // Duplicate key at 0x40F0
    sec.key2 = data.slice(0x40F0, 0x4102);
    var keysMatch = true;
    for (var j = 0; j < sec.key1.length; j++) { if (sec.key1[j] !== sec.key2[j]) { keysMatch = false; break; } }
    sec.keysMatch = keysMatch;
    // Security block @ 0x2000 (backup)
    var sb2 = data.slice(0x2000, 0x2020);
    var sb2blank = true;
    for (var j = 0; j < sb2.length; j++) { if (sb2[j] !== 0xFF) { sb2blank = false; break; } }
    sec.block2 = sb2;
    sec.block2blank = sb2blank;
  } else if (ft === "ee") {
    sec = { type: "ee" };
    sec.secretKey = data.slice(0x0040, 0x0050);
    var skBlank = true;
    for (var j = 0; j < 16; j++) { if (sec.secretKey[j] !== 0xFF) { skBlank = false; break; } }
    sec.secretKeyBlank = skBlank;
    // Part/serial info
    sec.partSerial = data.slice(0x0020, 0x0070);
    // Fob data
    sec.fobData = data.slice(0x0200, 0x0240);
    var fobBlank = true;
    for (var j = 0; j < 64; j++) { if (sec.fobData[j] !== 0xFF) { fobBlank = false; break; } }
    sec.fobBlank = fobBlank;
  } else if (ft === "gp") {
    sec = { type: "gp" };
    sec.configArea = data.slice(0x0800, 0x08C0);
  }

  return { ft: ft, sz: sz, F: fulls, P: parts, raw: data, sec: sec };
}

/* ═══ Patch binary ═══ */
function patch(rawData, an, newVin) {
  var out = new Uint8Array(rawData);
  var u = newVin.toUpperCase();
  var vb = [];
  for (var i = 0; i < 17; i++) vb.push(u.charCodeAt(i));
  var vba = new Uint8Array(vb);
  var log = [];

  for (var i = 0; i < an.F.length; i++) {
    var sl = an.F[i];
    if (sl.mirrored) {
      // RFHUB EEE: write VIN REVERSED, CRC on reversed bytes
      for (var j = 0; j < 17; j++) out[sl.off + j] = vb[16 - j];
      var revBytes = new Uint8Array(17);
      for (var j = 0; j < 17; j++) revBytes[j] = vb[16 - j];
      var c = crc8ref(revBytes);
      out[sl.coff] = c;
      log.push({ off: sl.off, t: "mirrored", h: "0x" + c.toString(16).toUpperCase().padStart(2, "0") });
    } else {
      for (var j = 0; j < 17; j++) out[sl.off + j] = vb[j];
      if (sl.algo === "c16") {
        var c = crc16ccitt(vba);
        out[sl.coff] = (c >> 8) & 0xff;
        out[sl.coff + 1] = c & 0xff;
        log.push({ off: sl.off, t: "full", h: "0x" + c.toString(16).toUpperCase().padStart(4, "0") });
      } else if (sl.algo === "c8") {
        var c = crc8p26(vba);
        out[sl.coff] = c;
        log.push({ off: sl.off, t: "full", h: "0x" + c.toString(16).toUpperCase().padStart(2, "0") });
      } else if (sl.algo === "cr8") {
        var c = crc8ref(vba);
        out[sl.coff] = c;
        log.push({ off: sl.off, t: "full", h: "0x" + c.toString(16).toUpperCase().padStart(2, "0") });
      } else {
        log.push({ off: sl.off, t: "full", h: "N/A" });
      }
    }
  }

  var t8 = u.slice(9);
  var tb = [];
  for (var i = 0; i < 8; i++) tb.push(t8.charCodeAt(i));
  var tba = new Uint8Array(tb);

  for (var i = 0; i < an.P.length; i++) {
    var sl = an.P[i];
    for (var j = 0; j < 8; j++) out[sl.off + j] = tb[j];
    var c = crc16ccitt(tba);
    out[sl.coff] = (c >> 8) & 0xff;
    out[sl.coff + 1] = c & 0xff;
    log.push({ off: sl.off, t: "partial", h: "0x" + c.toString(16).toUpperCase().padStart(4, "0") });
  }

  return { data: out, log: log };
}

/* ═══ Helpers ═══ */
function hx(n, w) { return "0x" + n.toString(16).toUpperCase().padStart(w || 4, "0"); }
var FTN = { bcm: "BCM D-FLASH", cfl: "BCM C-FLASH", ee: "FCA 95640", rfhub: "RFHUB EEE", gp: "GPEC2A EXT EEPROM" };
var R = "#dc2626";
var FNT = "'JetBrains Mono','Fira Code','SF Mono','Consolas',monospace";

/* ═══ COMPONENT ═══ */
export default function VINPatcher() {
  var _s = useState(null), fileName = _s[0], setFileName = _s[1];
  var _a = useState(null), an = _a[0], setAn = _a[1];
  var _v = useState(""), nv = _v[0], setNv = _v[1];
  var _p = useState(null), pLog = _p[0], setPLog = _p[1];
  var _d = useState(null), patchedBytes = _d[0], setPatchedBytes = _d[1];
  var _o = useState(null), origBytes = _o[0], setOrigBytes = _o[1];
  var fRef = useRef(null);

  function reset() {
    setFileName(null); setAn(null); setNv(""); setPLog(null); setPatchedBytes(null); setOrigBytes(null); setVirginized(false);
    if (fRef.current) fRef.current.value = "";
  }

  function onFile(e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    setFileName(file.name);
    setPLog(null); setPatchedBytes(null);
    var reader = new FileReader();
    reader.onload = function () {
      var data = new Uint8Array(reader.result);
      setOrigBytes(data);
      var result = analyze(data);
      setAn(result);
      if (result.F.length > 0) setNv(result.F[0].vin);
    };
    reader.readAsArrayBuffer(file);
  }

  var cv = useMemo(function () {
    return (nv && nv.length === 17) ? checkVin(nv) : null;
  }, [nv]);

  function doPatch() {
    if (!origBytes || !an || nv.length !== 17) return;
    var result = patch(origBytes, an, nv.toUpperCase());
    setPatchedBytes(result.data);
    setPLog(result.log);
    setAn(analyze(result.data));
    setVirginized(false);
  }

  var _vg = useState(false), virginized = _vg[0], setVirginized = _vg[1];

  function doVirginize() {
    if (!origBytes || !an) return;
    var out = new Uint8Array(origBytes);
    var vlog = [];

    if (an.ft === "ee") {
      // FCA 95640: clear VINs, CRC bytes, secret key
      // Check if this is a 95640 (VINs at 0x275) or RFHUB EEE (VINs at 0x0EA5)
      var is95640 = an.F.some(function(v) { return v.off === 0x0275 || v.off === 0x0288; });
      var isRFHUBEEE = an.F.some(function(v) { return v.off >= 0x0E00; });

      if (is95640) {
        // 95640 layout
        for (var i = 0; i < 17; i++) out[0x0275 + i] = 0x00;
        out[0x0274] = 0x00;
        vlog.push({ off: 0x0274, t: "CRC8 + VIN slot 1", h: "→ 0x00" });

        for (var i = 0; i < 17; i++) out[0x0288 + i] = 0x00;
        out[0x0287] = 0x00;
        vlog.push({ off: 0x0287, t: "CRC8 + VIN slot 2", h: "→ 0x00" });
      }

      if (isRFHUBEEE) {
        // RFHUB EEE layout — 4 VIN slots + CRC16 pairs
        var eeVins = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
        var eeCrcs = [0x0EB7, 0x0ECB, 0x0EDF, 0x0EF3];
        for (var v = 0; v < eeVins.length; v++) {
          if (eeVins[v] + 17 <= out.length) {
            for (var i = 0; i < 17; i++) out[eeVins[v] + i] = 0x00;
            vlog.push({ off: eeVins[v], t: "RFHUB VIN slot " + (v + 1), h: "→ 0x00" });
          }
        }
        for (var c = 0; c < eeCrcs.length; c++) {
          if (eeCrcs[c] + 2 <= out.length) {
            out[eeCrcs[c]] = 0x00; out[eeCrcs[c] + 1] = 0x00;
            vlog.push({ off: eeCrcs[c], t: "RFHUB CRC slot " + (c + 1), h: "→ 0x00" });
          }
        }
        // Fob data @ 0x0200 (64B) → 0xFF
        if (0x0200 + 64 <= out.length) {
          for (var i = 0; i < 64; i++) out[0x0200 + i] = 0xFF;
          vlog.push({ off: 0x0200, t: "Fob Data (64B)", h: "→ 0xFF" });
        }
      }

      // Also clear any dynamically detected VIN slots not at known offsets
      for (var i = 0; i < an.F.length; i++) {
        var sl = an.F[i];
        var alreadyHandled = (sl.off === 0x0275 || sl.off === 0x0288);
        if (!alreadyHandled && !isRFHUBEEE) {
          for (var j = 0; j < 17; j++) out[sl.off + j] = 0x00;
          if (sl.coff >= 0) out[sl.coff] = 0x00;
          vlog.push({ off: sl.off, t: "VIN + CRC", h: "→ 0x00" });
        }
      }

      // Secret key @ 0x0040 (16B) → 0xFF (common to both 95640 and RFHUB EEE)
      for (var i = 0; i < 16; i++) out[0x0040 + i] = 0xFF;
      vlog.push({ off: 0x0040, t: "Secret Key (16B)", h: "→ 0xFF" });

    } else if (an.ft === "rfhub") {
      // RFHUB EEE (4KB): clear 4 mirrored VIN slots + CRC bytes
      var rfVins = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
      var rfCrcs = [0x0EB6, 0x0ECA, 0x0EDE, 0x0EF2];
      for (var v = 0; v < rfVins.length; v++) {
        if (rfVins[v] + 17 <= out.length) {
          for (var i = 0; i < 17; i++) out[rfVins[v] + i] = 0x00;
          vlog.push({ off: rfVins[v], t: "RFHUB VIN slot " + (v + 1) + " (mirrored)", h: "→ 0x00" });
        }
        if (rfCrcs[v] < out.length) {
          out[rfCrcs[v]] = 0x00;
          vlog.push({ off: rfCrcs[v], t: "RFHUB CRC slot " + (v + 1), h: "→ 0x00" });
        }
      }
      // Secret key @ 0x0040 (16B) → 0xFF
      for (var i = 0; i < 16; i++) out[0x0040 + i] = 0xFF;
      vlog.push({ off: 0x0040, t: "Secret Key (16B)", h: "→ 0xFF" });
      // Fob data @ 0x0200 (64B) → 0xFF
      for (var i = 0; i < 64; i++) out[0x0200 + i] = 0xFF;
      vlog.push({ off: 0x0200, t: "Fob Data (64B)", h: "→ 0xFF" });

    } else if (an.ft === "gp") {
      // GPEC2A ECM: clear all 3 VIN locations (no CRC to worry about)
      var gpVins = [0x0000, 0x01F0, 0x0224];
      for (var v = 0; v < gpVins.length; v++) {
        if (gpVins[v] + 17 <= out.length) {
          for (var i = 0; i < 17; i++) out[gpVins[v] + i] = 0x00;
          vlog.push({ off: gpVins[v], t: "ECM VIN slot " + (v + 1), h: "→ 0x00" });
        }
      }

    } else if (an.ft === "bcm" || an.ft === "cfl") {
      // BCM: clear all detected VIN slots + CRCs
      for (var i = 0; i < an.F.length; i++) {
        var sl = an.F[i];
        for (var j = 0; j < 17; j++) out[sl.off + j] = 0x00;
        if (sl.algo === "c16") { out[sl.coff] = 0x00; out[sl.coff + 1] = 0x00; }
        vlog.push({ off: sl.off, t: "Full VIN + CRC", h: "→ 0x00" });
      }
      for (var i = 0; i < an.P.length; i++) {
        var sl = an.P[i];
        for (var j = 0; j < 8; j++) out[sl.off + j] = 0x00;
        out[sl.coff] = 0x00; out[sl.coff + 1] = 0x00;
        vlog.push({ off: sl.off, t: "Partial VIN + CRC", h: "→ 0x00" });
      }
    }

    setPatchedBytes(out);
    setPLog(vlog);
    setVirginized(true);
    // Don't re-analyze — virginized file won't have valid VINs anymore
  }

  function doDownload() {
    var data = patchedBytes;
    if (!data || !fileName) return;
    var blob = new Blob([data], { type: "application/octet-stream" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    // Build filename safely
    var base = fileName;
    var dotIdx = base.lastIndexOf(".");
    var name = dotIdx > 0 ? base.slice(0, dotIdx) : base;
    var ext = dotIdx > 0 ? base.slice(dotIdx) : ".bin";
    a.download = name + (virginized ? "_VIRGINIZED" : "_VIN_CRC_" + nv.toUpperCase()) + ext;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // CRC previews
  var pFull = "", pPart = "", p8 = "", pRef = "";
  if (nv.length === 17) {
    var b = []; for (var i = 0; i < 17; i++) b.push(nv.toUpperCase().charCodeAt(i));
    pFull = hx(crc16ccitt(new Uint8Array(b)), 4);
    var t = []; for (var i = 9; i < 17; i++) t.push(nv.toUpperCase().charCodeAt(i));
    pPart = hx(crc16ccitt(new Uint8Array(t)), 4);
    p8 = hx(crc8p26(new Uint8Array(b)), 2);
    // RFHUB EEE: CRC on reversed VIN bytes
    var rev = []; for (var i = 16; i >= 0; i--) rev.push(nv.toUpperCase().charCodeAt(i));
    pRef = hx(crc8ref(new Uint8Array(rev)), 2);
  }

  var box = { background: "#111113", border: "1px solid #1e1e21", borderRadius: 10, padding: 16, marginBottom: 16 };
  var lbl = { fontSize: 11, fontWeight: 700, color: R, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" };

  return (
    <div style={{ minHeight: "100vh", background: "#09090b", color: "#e4e4e7", fontFamily: FNT, fontSize: 12 }}>
      {/* HEADER */}
      <div style={{ background: "linear-gradient(135deg,#0c0c0e,#18080a)", borderBottom: "2px solid " + R, padding: "22px 20px" }}>
        <div style={{ maxWidth: 860, margin: "0 auto", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 34, height: 34, background: R, borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, fontWeight: 900, color: "#fff", flexShrink: 0 }}>V</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase" }}>VIN Patcher</div>
            <div style={{ fontSize: 9, color: "#52525b", marginTop: 1 }}>BCM D-FLASH · FCA 95640 · RFHUB EEE · GPEC2A — Auto-detect + CRC</div>
          </div>
          {an && <button onClick={reset} style={{ background: "#18181b", border: "1px solid #27272a", borderRadius: 6, padding: "6px 14px", color: "#a1a1aa", fontSize: 11, fontWeight: 600, cursor: "pointer", fontFamily: FNT }}>← Back</button>}
        </div>
      </div>

      <div style={{ maxWidth: 860, margin: "0 auto", padding: "20px 20px 60px" }}>

        {/* UPLOAD */}
        {!an && (
          <div onClick={function () { if (fRef.current) fRef.current.click(); }}
            style={{ border: "2px dashed #27272a", borderRadius: 12, padding: "44px 24px", textAlign: "center", cursor: "pointer" }}
            onMouseEnter={function (e) { e.currentTarget.style.borderColor = R; }}
            onMouseLeave={function (e) { e.currentTarget.style.borderColor = "#27272a"; }}>
            <input ref={fRef} type="file" accept=".bin,.BIN,.eee,.EEE" onChange={onFile} style={{ display: "none" }} />
            <div style={{ fontSize: 28, marginBottom: 10, opacity: 0.12 }}>↑</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#71717a" }}>Upload EEPROM Dump</div>
            <div style={{ fontSize: 10, color: "#3f3f46", marginTop: 6 }}>BCM (64/128 KB) · RFHUB 95640 (4/8 KB) · GPEC2A (4 KB)</div>
          </div>
        )}

        {/* MAIN UI */}
        {an && an.F.length > 0 && (<div>
          {/* File info */}
          <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
            <span style={{ background: "#1a0808", border: "1px solid #3b1111", borderRadius: 6, padding: "4px 10px", fontSize: 10, color: R, fontWeight: 700 }}>{FTN[an.ft] || "Unknown"}</span>
            <span style={{ background: "#18181b", border: "1px solid #27272a", borderRadius: 6, padding: "4px 10px", fontSize: 10, color: "#a1a1aa" }}>{fileName}</span>
            <span style={{ background: "#18181b", border: "1px solid #27272a", borderRadius: 6, padding: "4px 10px", fontSize: 10, color: "#a1a1aa" }}>{(an.sz / 1024).toFixed(0) + " KB"}</span>
            <span style={{ background: "#18181b", border: "1px solid #27272a", borderRadius: 6, padding: "4px 10px", fontSize: 10, color: "#a1a1aa" }}>{an.F.length + " full + " + an.P.length + " partial"}</span>
          </div>

          {/* VIN locations */}
          <div style={box}>
            <div style={lbl}>VIN Locations</div>
            {an.F.map(function (v, i) {
              var cl = v.algo === "no" ? "#fbbf24" : v.ok ? "#4ade80" : "#ef4444";
              var ct = v.algo === "no" ? "No checksum"
                : v.algo === "c16" ? "CRC16 " + hx(v.sc, 4) + (v.ok ? " ✓" : " ✗")
                : "CRC8 " + hx(v.sc, 2) + (v.ok ? " ✓" : " ✗");
              return (
                <div key={"f" + i} style={{ display: "flex", alignItems: "center", gap: 10, background: "#0a0a0c", borderRadius: 6, padding: "7px 10px", marginBottom: 3, border: "1px solid " + (v.ok ? "#14331a" : "#331414"), flexWrap: "wrap" }}>
                  <span style={{ fontSize: 10, color: "#52525b", minWidth: 55 }}>{hx(v.off)}</span>
                  <span style={{ fontSize: 13, fontWeight: 800, letterSpacing: 2, flex: 1, minWidth: 180 }}>{v.vin}</span>
                  <span style={{ fontSize: 10, color: cl, fontWeight: 600 }}>{ct}</span>
                  <span style={{ fontSize: 8, background: "#1a1a30", color: "#818cf8", padding: "2px 6px", borderRadius: 3 }}>full</span>
                </div>
              );
            })}
            {an.P.map(function (v, i) {
              return (
                <div key={"p" + i} style={{ display: "flex", alignItems: "center", gap: 10, background: "#0a0a0c", borderRadius: 6, padding: "7px 10px", marginBottom: 3, border: "1px solid #14331a", flexWrap: "wrap" }}>
                  <span style={{ fontSize: 10, color: "#52525b", minWidth: 55 }}>{hx(v.off)}</span>
                  <span style={{ fontSize: 13, fontWeight: 800, letterSpacing: 2, flex: 1, color: "#a78bfa", minWidth: 180 }}>{"········" + v.vin}</span>
                  <span style={{ fontSize: 10, color: "#4ade80", fontWeight: 600 }}>{"CRC16 " + hx(v.sc, 4) + " ✓"}</span>
                  <span style={{ fontSize: 8, background: "#261a30", color: "#c084fc", padding: "2px 6px", borderRadius: 3 }}>partial</span>
                </div>
              );
            })}
          </div>

          {/* Security Bytes */}
          {an.sec && (
            <div style={box}>
              <div style={lbl}>Security Bytes</div>

              {an.sec.type === "bcm" && (<div>
                {/* BCM Security Block */}
                <div style={{ background: "#0a0a0c", borderRadius: 6, padding: 10, marginBottom: 8, border: "1px solid " + (an.sec.block1blank ? "#332a14" : "#14331a") }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: "#a1a1aa", fontWeight: 600 }}>Security Block @ 0x40C0</span>
                    <span style={{ fontSize: 9, color: an.sec.block1blank ? "#fbbf24" : "#4ade80", fontWeight: 700 }}>{an.sec.block1blank ? "BLANK" : "POPULATED"}</span>
                  </div>
                  {!an.sec.block1blank && (<div>
                    <div style={{ fontSize: 10, color: "#71717a", marginBottom: 4 }}>Immobilizer Key (18 bytes):</div>
                    <div style={{ fontSize: 11, color: "#f0abfc", fontWeight: 700, letterSpacing: 1.5, wordBreak: "break-all" }}>
                      {Array.from(an.sec.key1).map(function(b) { return b.toString(16).toUpperCase().padStart(2, "0"); }).join(" ")}
                    </div>
                    <div style={{ fontSize: 9, color: an.sec.keysMatch ? "#4ade80" : "#ef4444", marginTop: 4 }}>
                      {"Backup @ 0x40F0: " + (an.sec.keysMatch ? "✓ matches" : "✗ MISMATCH")}
                    </div>
                  </div>)}
                </div>

                {/* Backup block */}
                <div style={{ background: "#0a0a0c", borderRadius: 6, padding: 10, marginBottom: 8, border: "1px solid #1e1e21" }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{ fontSize: 10, color: "#71717a" }}>Backup Block @ 0x2000</span>
                    <span style={{ fontSize: 9, color: an.sec.block2blank ? "#52525b" : "#4ade80" }}>{an.sec.block2blank ? "BLANK" : "POPULATED"}</span>
                  </div>
                </div>
              </div>)}

              {an.sec.type === "ee" && (<div>
                {/* 95640 Secret Key */}
                <div style={{ background: "#0a0a0c", borderRadius: 6, padding: 10, marginBottom: 8, border: "1px solid " + (an.sec.secretKeyBlank ? "#332a14" : "#14331a") }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: "#a1a1aa", fontWeight: 600 }}>Secret Key @ 0x0040 (16B)</span>
                    <span style={{ fontSize: 9, color: an.sec.secretKeyBlank ? "#fbbf24" : "#4ade80", fontWeight: 700 }}>{an.sec.secretKeyBlank ? "ERASED" : "POPULATED"}</span>
                  </div>
                  <div style={{ fontSize: 11, color: "#f0abfc", fontWeight: 700, letterSpacing: 1.5, wordBreak: "break-all" }}>
                    {Array.from(an.sec.secretKey).map(function(b) { return b.toString(16).toUpperCase().padStart(2, "0"); }).join(" ")}
                  </div>
                  {!an.sec.secretKeyBlank && (function() {
                    var ascii = "";
                    for (var j = 0; j < an.sec.secretKey.length; j++) {
                      var b = an.sec.secretKey[j];
                      ascii += (b >= 0x20 && b <= 0x7e) ? String.fromCharCode(b) : ".";
                    }
                    return <div style={{ fontSize: 10, color: "#71717a", marginTop: 4 }}>{"ASCII: " + ascii}</div>;
                  })()}
                </div>

                {/* Fob Data */}
                <div style={{ background: "#0a0a0c", borderRadius: 6, padding: 10, marginBottom: 8, border: "1px solid #1e1e21" }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{ fontSize: 10, color: "#71717a" }}>Fob Data @ 0x0200 (64B)</span>
                    <span style={{ fontSize: 9, color: an.sec.fobBlank ? "#52525b" : "#4ade80" }}>{an.sec.fobBlank ? "NO FOBS" : "HAS FOB DATA"}</span>
                  </div>
                </div>

                {/* Part/Serial */}
                <div style={{ background: "#0a0a0c", borderRadius: 6, padding: 10, border: "1px solid #1e1e21" }}>
                  <div style={{ fontSize: 10, color: "#71717a", marginBottom: 6 }}>Part / Serial Info (0x0020-0x006F)</div>
                  <div style={{ fontSize: 10, color: "#52525b", lineHeight: 1.6, wordBreak: "break-all" }}>
                    {(function() {
                      var lines = [];
                      for (var row = 0; row < 5; row++) {
                        var off = row * 16;
                        var bytes = an.sec.partSerial.slice(off, off + 16);
                        var allFF = true;
                        for (var j = 0; j < bytes.length; j++) { if (bytes[j] !== 0xFF) { allFF = false; break; } }
                        if (allFF) continue;
                        var hex = Array.from(bytes).map(function(b) { return b.toString(16).toUpperCase().padStart(2, "0"); }).join(" ");
                        var ascii = "";
                        for (var j = 0; j < bytes.length; j++) {
                          var b = bytes[j];
                          ascii += (b >= 0x20 && b <= 0x7e) ? String.fromCharCode(b) : ".";
                        }
                        lines.push(<div key={row}><span style={{ color: "#3f3f46" }}>{"0x" + (0x20 + off).toString(16).toUpperCase().padStart(4, "0") + ": "}</span><span style={{ color: "#71717a" }}>{hex}</span><span style={{ color: "#a1a1aa", marginLeft: 8 }}>{ascii}</span></div>);
                      }
                      return lines;
                    })()}
                  </div>
                </div>
              </div>)}

              {an.sec.type === "gp" && (
                <div style={{ background: "#0a0a0c", borderRadius: 6, padding: 10, border: "1px solid #1e1e21" }}>
                  <span style={{ fontSize: 10, color: "#71717a" }}>ECM config area @ 0x0800 — use GPEC2A tools for detailed security analysis</span>
                </div>
              )}
            </div>
          )}

          {/* New VIN input */}
          <div style={box}>
            <div style={lbl}>New VIN</div>
            <input value={nv}
              onChange={function (e) { setNv(e.target.value.toUpperCase()); setPLog(null); setPatchedBytes(null); }}
              maxLength={17} placeholder="Enter 17-character VIN"
              style={{ width: "100%", background: "#09090b", border: "2px solid " + (cv ? (cv.ok ? "#22c55e" : "#ef4444") : "#27272a"), borderRadius: 8, padding: "11px 12px", color: "#fff", fontSize: 15, fontWeight: 800, letterSpacing: 3, textAlign: "center", fontFamily: FNT, outline: "none", boxSizing: "border-box" }} />
            {cv && (
              <div style={{ marginTop: 8, display: "flex", gap: 12, flexWrap: "wrap", fontSize: 10 }}>
                <span style={{ color: "#71717a" }}>WMI: <b style={{ color: "#d4d4d8" }}>{cv.wmi}</b> — {cv.mfr}</span>
                <span style={{ color: "#71717a" }}>Check: <b style={{ color: cv.ok ? "#4ade80" : "#ef4444" }}>{cv.cd}</b></span>
                <span style={{ color: "#71717a" }}>Year: <b style={{ color: "#d4d4d8" }}>{cv.yr}</b></span>
                {cv.err && <span style={{ color: "#ef4444" }}>{cv.err}</span>}
              </div>
            )}
            {nv.length === 17 && (
              <div style={{ marginTop: 10, background: "#0a0a0c", borderRadius: 6, padding: 9, border: "1px solid #1a1a1e" }}>
                <div style={{ fontSize: 8, color: "#3f3f46", marginBottom: 4, textTransform: "uppercase", letterSpacing: 1 }}>Checksum Preview</div>
                <div style={{ display: "flex", gap: 14, fontSize: 10, flexWrap: "wrap" }}>
                  {an.ft === "ee" ? <span>CRC-8: <b style={{ color: "#fbbf24" }}>{p8}</b></span>
                    : an.ft === "rfhub" ? <span>Reflected CRC-8 (mirrored): <b style={{ color: "#fbbf24" }}>{pRef}</b></span>
                    : an.ft === "gp" ? <span style={{ color: "#fbbf24" }}>No checksum — VIN-only</span>
                    : (<>
                      <span>Full CRC-16: <b style={{ color: "#fbbf24" }}>{pFull}</b></span>
                      {an.P.length > 0 && <span>Partial: <b style={{ color: "#a78bfa" }}>{pPart}</b></span>}
                    </>)}
                </div>
              </div>
            )}
          </div>

          {/* Buttons */}
          <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
            <button onClick={doPatch} disabled={nv.length !== 17}
              style={{ flex: 1, padding: "11px 14px", background: R, color: "#fff", border: "none", borderRadius: 8, fontSize: 11, fontWeight: 800, letterSpacing: 1, textTransform: "uppercase", cursor: nv.length === 17 ? "pointer" : "default", opacity: nv.length !== 17 ? 0.3 : 1, fontFamily: FNT, minWidth: 200 }}>
              Patch VIN + Recalculate CRC
            </button>
            {(an.ft === "ee" || an.ft === "bcm" || an.ft === "gp" || an.ft === "rfhub") && (
              <button onClick={doVirginize}
                style={{ padding: "11px 14px", background: "#1a0505", color: "#f87171", border: "1px solid #7f1d1d", borderRadius: 8, fontSize: 11, fontWeight: 800, letterSpacing: 1, textTransform: "uppercase", cursor: "pointer", fontFamily: FNT }}>
                Virginize
              </button>
            )}
            {patchedBytes && (
              <button onClick={doDownload}
                style={{ padding: "11px 18px", background: "#0a1f0a", color: "#4ade80", border: "1px solid rgba(34,197,94,0.25)", borderRadius: 8, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: FNT, letterSpacing: 1, textTransform: "uppercase" }}>
                ↓ Download
              </button>
            )}
          </div>

          {/* Patch result */}
          {pLog && !virginized && (
            <div style={{ background: "#0a1a0a", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#4ade80", marginBottom: 6 }}>{"✓ Patched " + pLog.length + " location" + (pLog.length !== 1 ? "s" : "")}</div>
              {pLog.map(function (p, i) {
                return <div key={i} style={{ fontSize: 10, color: "#86efac", marginBottom: 2 }}>{hx(p.off) + " — " + p.t + " — CRC → " + p.h}</div>;
              })}
            </div>
          )}
          {pLog && virginized && (
            <div style={{ background: "#1a0a0a", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 10, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#f87171", marginBottom: 6 }}>{"⚠ Virginized — " + pLog.length + " region" + (pLog.length !== 1 ? "s" : "") + " cleared"}</div>
              {pLog.map(function (p, i) {
                return <div key={i} style={{ fontSize: 10, color: "#fca5a5", marginBottom: 2 }}>{hx(p.off) + " — " + p.t + " " + p.h}</div>;
              })}
              <div style={{ fontSize: 9, color: "#7f1d1d", marginTop: 8 }}>VINs, CRC checksums, and secret keys erased. Module will require full reprogramming.</div>
            </div>
          )}

          {/* Algo info */}
          <div style={{ background: "#111113", border: "1px solid #1e1e21", borderRadius: 10, padding: 12 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#3f3f46", marginBottom: 6, letterSpacing: 1, textTransform: "uppercase" }}>Algorithm</div>
            <div style={{ fontSize: 10, color: "#3f3f46", lineHeight: 1.8 }}>
              {an.ft === "ee" ? (<>
                <div><b style={{ color: "#71717a" }}>CRC:</b> CRC-8 poly=0x26 init=0x00 — 1 byte before VIN</div>
              </>) : an.ft === "rfhub" ? (<>
                <div><b style={{ color: "#71717a" }}>CRC:</b> Reflected CRC-8 poly=0xA0 init=0x54 — 1 byte after VIN</div>
                <div><b style={{ color: "#71717a" }}>VIN:</b> Stored MIRRORED (reversed byte order) at 4 slots</div>
                <div><b style={{ color: "#71717a" }}>Slots:</b> 0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1 · CRC at VIN+17</div>
              </>) : an.ft === "gp" ? (<>
                <div><b style={{ color: "#71717a" }}>CRC:</b> None — raw VIN at 0x0000, 0x01F0, 0x0224</div>
              </>) : (<>
                <div><b style={{ color: "#71717a" }}>CRC:</b> CRC-16/CCITT-FALSE poly=0x1021 init=0xFFFF</div>
                <div><b style={{ color: "#71717a" }}>Full:</b> [17B VIN][2B CRC BE] · 4 slots 0x20 apart</div>
                <div><b style={{ color: "#71717a" }}>Partial:</b> [8B tail][2B CRC BE] · 2 slots</div>
              </>)}
            </div>
          </div>
        </div>)}

        {an && an.F.length === 0 && (
          <div style={{ textAlign: "center", padding: 36, color: "#3f3f46" }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>No valid VINs found</div>
            <div style={{ fontSize: 10, marginTop: 4, color: "#27272a" }}>Wrong file type or no VIN data</div>
            <button onClick={reset} style={{ marginTop: 14, background: "#18181b", border: "1px solid #27272a", borderRadius: 6, padding: "7px 14px", color: "#a1a1aa", fontSize: 10, fontWeight: 600, cursor: "pointer", fontFamily: FNT }}>← Try Another</button>
          </div>
        )}
      </div>
    </div>
  );
}
