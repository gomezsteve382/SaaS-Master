import { useState, useCallback, useRef } from "react";

/* ═══ CRC ALGORITHMS ═══ */
function crc16ccitt(data) {
  var crc = 0xFFFF;
  for (var i = 0; i < data.length; i++) {
    crc ^= data[i] << 8;
    for (var j = 0; j < 8; j++) {
      if (crc & 0x8000) crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
      else crc = (crc << 1) & 0xFFFF;
    }
  }
  return crc;
}

function crc8p26(data) {
  var crc = 0x00;
  for (var i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (var j = 0; j < 8; j++) {
      if (crc & 0x80) crc = ((crc << 1) ^ 0x26) & 0xFF;
      else crc = (crc << 1) & 0xFF;
    }
  }
  return crc;
}

function crc8ref(data) {
  var crc = 0x54;
  for (var i = 0; i < data.length; i++) {
    crc ^= data[i];
    for (var j = 0; j < 8; j++) {
      if (crc & 1) crc = (crc >> 1) ^ 0xA0;
      else crc = crc >> 1;
    }
  }
  return crc & 0xFF;
}

/* ═══ HELPERS ═══ */
function hx(n, w) { return "0x" + n.toString(16).toUpperCase().padStart(w || 4, "0"); }
function hxb(data) { return Array.from(data).map(function(b) { return b.toString(16).toUpperCase().padStart(2, "0"); }).join(" "); }
function asc(data) { var s = ""; for (var i = 0; i < data.length; i++) { var b = data[i]; s += (b >= 0x20 && b <= 0x7E) ? String.fromCharCode(b) : "."; } return s; }

/* ═══ VIN UTILITIES ═══ */
function extractVin(data, off) {
  if (off + 17 > data.length) return null;
  var s = "";
  for (var i = 0; i < 17; i++) {
    var b = data[off + i];
    if (b < 0x20 || b > 0x7E) return null;
    s += String.fromCharCode(b);
  }
  if (!/^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/.test(s)) return null;
  return s;
}

/* ═══ MODULE ANALYZER ═══ */
function analyzeModule(data, fileName) {
  var sz = data.length;
  var mod = { fileName: fileName, size: sz, type: "unknown", vins: [], securityKey: null, securityKeyOffset: -1, securityKeyBlank: true, immoKey: null, immoKeyBlank: true, fobBlank: true, partSerial: "", raw: data };

  if (sz === 65536 || sz === 131072) {
    mod.type = "bcm";
    // Find VINs
    var vinPat = /^[1-9A-HJ-NPR-Z][A-HJ-NPR-Z0-9]{16}$/;
    var TR = {A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9};
    for (var d = 0; d <= 9; d++) TR[String(d)] = d;
    var W = [8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2];
    for (var i = 0; i <= sz - 19; i++) {
      var v = extractVin(data, i);
      if (!v) continue;
      // Check digit
      var sum = 0;
      for (var j = 0; j < 17; j++) sum += (TR[v[j]] || 0) * W[j];
      if ("0123456789X"[sum % 11] !== v[8]) continue;
      var sc = (data[i+17] << 8) | data[i+18];
      var cc = crc16ccitt(data.slice(i, i+17));
      if (sc === cc) mod.vins.push({ offset: i, vin: v });
      i += 16;
    }
    // Security block @ 0x40C0
    var sb = data.slice(0x40C0, 0x40E0);
    var sbBlank = true;
    for (var j = 0; j < sb.length; j++) { if (sb[j] !== 0xFF) { sbBlank = false; break; } }
    if (!sbBlank) {
      mod.immoKey = data.slice(0x40C8, 0x40DA);
      mod.immoKeyBlank = false;
      var k2 = data.slice(0x40F0, 0x4102);
      mod.immoKeyBackup = k2;
      mod.immoKeysMatch = true;
      for (var j = 0; j < mod.immoKey.length; j++) { if (mod.immoKey[j] !== k2[j]) { mod.immoKeysMatch = false; break; } }
    } else {
      mod.immoKeyBlank = true;
    }
    // Backup @ 0x2000
    var sb2 = data.slice(0x2000, 0x2020);
    mod.backup2000Blank = true;
    for (var j = 0; j < sb2.length; j++) { if (sb2[j] !== 0xFF) { mod.backup2000Blank = false; break; } }
    if (!mod.backup2000Blank) {
      mod.backup2000 = sb2;
    }

  } else if (sz === 8192 || sz === 16384) {
    mod.type = "95640";
    var v1 = extractVin(data, 0x0275);
    if (v1) mod.vins.push({ offset: 0x0275, vin: v1 });
    var v2 = extractVin(data, 0x0288);
    if (v2) mod.vins.push({ offset: 0x0288, vin: v2 });
    mod.securityKey = data.slice(0x0040, 0x0050);
    mod.securityKeyOffset = 0x0040;
    mod.securityKeyBlank = true;
    for (var j = 0; j < 16; j++) { if (mod.securityKey[j] !== 0xFF) { mod.securityKeyBlank = false; break; } }
    var fob = data.slice(0x0200, 0x0240);
    mod.fobBlank = true;
    for (var j = 0; j < fob.length; j++) { if (fob[j] !== 0xFF) { mod.fobBlank = false; break; } }
    mod.partSerial = data.slice(0x0020, 0x0070);

  } else if (sz === 4096) {
    // Distinguish GPEC2A vs RFHUB EEE
    var vinAt0 = extractVin(data, 0x0000);
    if (vinAt0) {
      mod.type = "gpec2a";
      mod.vins.push({ offset: 0x0000, vin: vinAt0 });
      var v2 = extractVin(data, 0x01F0);
      if (v2) mod.vins.push({ offset: 0x01F0, vin: v2 });
      var v3 = extractVin(data, 0x0224);
      if (v3) mod.vins.push({ offset: 0x0224, vin: v3 });
      // ECM config at 0x0800
      mod.ecmConfig = data.slice(0x0800, 0x0830);
    } else {
      // Check for RFHUB EEE (reversed VINs at 0x0EA5)
      mod.type = "rfhub_eee";
      var slots = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
      for (var s = 0; s < slots.length; s++) {
        var off = slots[s];
        if (off + 17 > data.length) continue;
        var stored = data.slice(off, off + 17);
        var hasData = false;
        for (var j = 0; j < 17; j++) { if (stored[j] !== 0xFF && stored[j] !== 0x00) { hasData = true; break; } }
        if (!hasData) continue;
        // Reverse to get real VIN
        var reversed = new Uint8Array(17);
        for (var j = 0; j < 17; j++) reversed[j] = stored[16 - j];
        var realVin = "";
        for (var j = 0; j < 17; j++) realVin += String.fromCharCode(reversed[j]);
        mod.vins.push({ offset: off, vin: realVin, stored: String.fromCharCode.apply(null, stored), mirrored: true });
        break; // Only need one
      }
      // RFHUB secret key at 0x0040
      mod.securityKey = data.slice(0x0040, 0x0050);
      mod.securityKeyOffset = 0x0040;
      mod.securityKeyBlank = true;
      for (var j = 0; j < 16; j++) { if (mod.securityKey[j] !== 0xFF) { mod.securityKeyBlank = false; break; } }
      // Part info at end
      mod.partSerial = data.slice(0x0F90, 0x1000);
    }
  }

  return mod;
}

/* ═══ STYLES ═══ */
var R = "#dc2626";
var FNT = "'JetBrains Mono','Fira Code','SF Mono','Consolas',monospace";
var TYPES = { bcm: { label: "BCM D-FLASH", color: "#f59e0b" }, "95640": { label: "FCA 95640", color: "#8b5cf6" }, rfhub_eee: { label: "RFHUB EEE", color: "#06b6d4" }, gpec2a: { label: "GPEC2A ECM", color: "#22c55e" }, unknown: { label: "Unknown", color: "#666" } };

export default function SecurityMatcher() {
  var _m = useState([]), modules = _m[0], setModules = _m[1];
  var _t = useState(""), targetVin = _t[0], setTargetVin = _t[1];
  var _msg = useState(null), msg = _msg[0], setMsg = _msg[1];
  var fRef = useRef(null);

  var addFiles = useCallback(function(e) {
    var fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    var promises = [];
    for (var i = 0; i < fileList.length; i++) {
      (function(file) {
        promises.push(new Promise(function(resolve) {
          var reader = new FileReader();
          reader.onload = function() {
            var data = new Uint8Array(reader.result);
            var mod = analyzeModule(data, file.name);
            resolve(mod);
          };
          reader.readAsArrayBuffer(file);
        }));
      })(fileList[i]);
    }
    Promise.all(promises).then(function(newMods) {
      setModules(function(prev) {
        var updated = prev.slice();
        for (var i = 0; i < newMods.length; i++) {
          if (newMods[i].type !== "unknown") updated.push(newMods[i]);
        }
        // Auto-detect target VIN from first module with VINs
        if (!targetVin && updated.length > 0) {
          for (var j = 0; j < updated.length; j++) {
            if (updated[j].vins.length > 0) {
              setTargetVin(updated[j].vins[0].vin);
              break;
            }
          }
        }
        return updated;
      });
    });
    if (fRef.current) fRef.current.value = "";
  }, [targetVin]);

  var removeModule = function(idx) {
    setModules(function(prev) { var n = prev.slice(); n.splice(idx, 1); return n; });
  };

  // Check VIN match
  var vinMismatch = false;
  var allVins = [];
  for (var i = 0; i < modules.length; i++) {
    for (var j = 0; j < modules[i].vins.length; j++) {
      var v = modules[i].vins[j].vin;
      if (allVins.indexOf(v) === -1) allVins.push(v);
    }
  }
  vinMismatch = allVins.length > 1;

  // Check security key match across modules that have them
  var secKeys = [];
  for (var i = 0; i < modules.length; i++) {
    var m = modules[i];
    if (m.securityKey && !m.securityKeyBlank) {
      secKeys.push({ idx: i, type: m.type, key: m.securityKey, fn: m.fileName });
    }
  }
  var secMismatch = false;
  if (secKeys.length > 1) {
    for (var i = 1; i < secKeys.length; i++) {
      for (var j = 0; j < secKeys[0].key.length; j++) {
        if (secKeys[0].key[j] !== secKeys[i].key[j]) { secMismatch = true; break; }
      }
      if (secMismatch) break;
    }
  }

  // Download helper
  function downloadFile(data, name) {
    var blob = new Blob([data], { type: "application/octet-stream" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Sync security key from source to target
  function syncSecurityKey(sourceIdx, targetIdx) {
    var src = modules[sourceIdx];
    var tgt = modules[targetIdx];
    if (!src.securityKey || src.securityKeyBlank) return;
    if (tgt.securityKeyOffset < 0) return;

    var patched = new Uint8Array(tgt.raw);
    for (var i = 0; i < 16; i++) {
      patched[tgt.securityKeyOffset + i] = src.securityKey[i];
    }

    var dotIdx = tgt.fileName.lastIndexOf(".");
    var name = dotIdx > 0 ? tgt.fileName.slice(0, dotIdx) : tgt.fileName;
    var ext = dotIdx > 0 ? tgt.fileName.slice(dotIdx) : ".bin";
    downloadFile(patched, name + "_SECKEY_SYNCED" + ext);
    setMsg("Security key from " + src.fileName + " written to " + tgt.fileName);
  }

  // Patch VIN on a module
  function patchVin(modIdx, newVin) {
    var m = modules[modIdx];
    var patched = new Uint8Array(m.raw);
    var upper = newVin.toUpperCase();
    var vb = [];
    for (var i = 0; i < 17; i++) vb.push(upper.charCodeAt(i));
    var vba = new Uint8Array(vb);
    var log = [];

    if (m.type === "bcm") {
      // Find and patch all VIN+CRC locations
      for (var i = 0; i < m.vins.length; i++) {
        var off = m.vins[i].offset;
        for (var j = 0; j < 17; j++) patched[off + j] = vb[j];
        var c = crc16ccitt(vba);
        patched[off + 17] = (c >> 8) & 0xFF;
        patched[off + 18] = c & 0xFF;
        log.push("VIN @ " + hx(off) + " + CRC " + hx(c, 4));
      }
      // Also find and patch partial VINs
      if (m.vins.length > 0) {
        var tail8 = upper.slice(9);
        var t8c = [];
        for (var k = 0; k < 8; k++) t8c.push(tail8.charCodeAt(k));
        var refVin = m.vins[0].vin;
        var refTail = refVin.slice(9);
        var rtc = [];
        for (var k = 0; k < 8; k++) rtc.push(refTail.charCodeAt(k));
        for (var i = 0; i <= patched.length - 10; i++) {
          var match = true;
          for (var j = 0; j < 8; j++) { if (patched[i+j] !== rtc[j]) { match = false; break; } }
          if (!match) continue;
          var inFull = false;
          for (var f = 0; f < m.vins.length; f++) { if (i >= m.vins[f].offset && i < m.vins[f].offset + 17) { inFull = true; break; } }
          if (inFull) continue;
          var sc = (patched[i+8] << 8) | patched[i+9];
          var cc = crc16ccitt(patched.slice(i, i+8));
          if (sc !== cc) continue;
          for (var j = 0; j < 8; j++) patched[i+j] = t8c[j];
          var nc = crc16ccitt(new Uint8Array(t8c));
          patched[i+8] = (nc >> 8) & 0xFF;
          patched[i+9] = nc & 0xFF;
          log.push("Partial @ " + hx(i) + " + CRC " + hx(nc, 4));
        }
      }
    } else if (m.type === "95640") {
      var offsets = [0x0275, 0x0288];
      for (var o = 0; o < offsets.length; o++) {
        var off = offsets[o];
        for (var j = 0; j < 17; j++) patched[off + j] = vb[j];
        var c = crc8p26(vba);
        patched[off - 1] = c;
        log.push("VIN @ " + hx(off) + " CRC8 " + hx(c, 2));
      }
    } else if (m.type === "rfhub_eee") {
      var slots = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
      // Mirror the VIN
      var mirrored = [];
      for (var j = 16; j >= 0; j--) mirrored.push(vb[j]);
      var ma = new Uint8Array(mirrored);
      for (var s = 0; s < slots.length; s++) {
        var off = slots[s];
        if (off + 18 > patched.length) continue;
        for (var j = 0; j < 17; j++) patched[off + j] = mirrored[j];
        var c = crc8ref(ma);
        patched[off + 17] = c;
        log.push("VIN @ " + hx(off) + " (mirrored) CRC8 " + hx(c, 2));
      }
    } else if (m.type === "gpec2a") {
      var offsets = [0x0000, 0x01F0, 0x0224];
      for (var o = 0; o < offsets.length; o++) {
        var off = offsets[o];
        if (off + 17 > patched.length) continue;
        for (var j = 0; j < 17; j++) patched[off + j] = vb[j];
        log.push("VIN @ " + hx(off));
      }
    }

    var dotIdx = m.fileName.lastIndexOf(".");
    var name = dotIdx > 0 ? m.fileName.slice(0, dotIdx) : m.fileName;
    var ext = dotIdx > 0 ? m.fileName.slice(dotIdx) : ".bin";
    downloadFile(patched, name + "_VIN_" + upper + ext);
    setMsg("Patched " + log.length + " locations: " + log.join(", "));
  }

  function patchAllToTarget() {
    if (!targetVin || targetVin.length !== 17) return;
    for (var i = 0; i < modules.length; i++) {
      if (modules[i].vins.length > 0 && modules[i].vins[0].vin !== targetVin) {
        patchVin(i, targetVin);
      }
    }
  }

  var box = { background: "#111113", border: "1px solid #1e1e21", borderRadius: 10, padding: 14, marginBottom: 12 };

  return (
    <div style={{ minHeight: "100vh", background: "#09090b", color: "#e4e4e7", fontFamily: FNT, fontSize: 12 }}>
      {/* HEADER */}
      <div style={{ background: "linear-gradient(135deg,#0c0c0e,#18080a)", borderBottom: "2px solid " + R, padding: "20px 16px" }}>
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div style={{ fontSize: 17, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase" }}>Security Byte Matcher</div>
          <div style={{ fontSize: 9, color: "#52525b", marginTop: 2 }}>Load modules from different cars · Match VINs + security keys · Export patched files</div>
        </div>
      </div>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "16px 16px 60px" }}>
        {/* Upload */}
        <div onClick={function() { if (fRef.current) fRef.current.click(); }}
          style={{ border: "2px dashed #27272a", borderRadius: 10, padding: "24px 16px", textAlign: "center", cursor: "pointer", marginBottom: 14 }}
          onMouseEnter={function(e) { e.currentTarget.style.borderColor = R; }}
          onMouseLeave={function(e) { e.currentTarget.style.borderColor = "#27272a"; }}>
          <input ref={fRef} type="file" accept=".bin,.BIN,.eee,.EEE" multiple onChange={addFiles} style={{ display: "none" }} />
          <div style={{ fontSize: 13, fontWeight: 700, color: "#71717a" }}>+ Add Module Files</div>
          <div style={{ fontSize: 9, color: "#3f3f46", marginTop: 4 }}>BCM · RFHUB 95640 · RFHUB EEE · GPEC2A — drop multiple files</div>
        </div>

        {/* Target VIN */}
        {modules.length > 0 && (
          <div style={box}>
            <div style={{ fontSize: 11, fontWeight: 700, color: R, marginBottom: 8, letterSpacing: 1, textTransform: "uppercase" }}>Target VIN</div>
            <input value={targetVin} onChange={function(e) { setTargetVin(e.target.value.toUpperCase()); }} maxLength={17} placeholder="Enter target VIN"
              style={{ width: "100%", background: "#09090b", border: "2px solid " + (targetVin.length === 17 ? "#22c55e" : "#27272a"), borderRadius: 6, padding: "8px 10px", color: "#fff", fontSize: 14, fontWeight: 800, letterSpacing: 3, textAlign: "center", fontFamily: FNT, outline: "none", boxSizing: "border-box" }} />
            {vinMismatch && targetVin.length === 17 && (
              <button onClick={patchAllToTarget} style={{ marginTop: 8, width: "100%", padding: "10px", background: R, color: "#fff", border: "none", borderRadius: 6, fontSize: 11, fontWeight: 800, cursor: "pointer", fontFamily: FNT, letterSpacing: 1, textTransform: "uppercase" }}>
                Patch All Mismatched VINs → {targetVin}
              </button>
            )}
          </div>
        )}

        {/* Status Banner */}
        {modules.length > 1 && (
          <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
            <span style={{ background: vinMismatch ? "#3b1111" : "#0a1f0a", border: "1px solid " + (vinMismatch ? "#7f1d1d" : "rgba(34,197,94,0.25)"), borderRadius: 6, padding: "5px 10px", fontSize: 10, color: vinMismatch ? "#f87171" : "#4ade80", fontWeight: 700 }}>
              {vinMismatch ? "⚠ VIN MISMATCH — " + allVins.length + " different VINs" : "✓ VINs Match"}
            </span>
            {secKeys.length > 0 && (
              <span style={{ background: secMismatch ? "#3b1111" : "#0a1f0a", border: "1px solid " + (secMismatch ? "#7f1d1d" : "rgba(34,197,94,0.25)"), borderRadius: 6, padding: "5px 10px", fontSize: 10, color: secMismatch ? "#f87171" : "#4ade80", fontWeight: 700 }}>
                {secMismatch ? "⚠ SECURITY KEY MISMATCH" : "✓ Security Keys Match"}
              </span>
            )}
          </div>
        )}

        {/* Module Cards */}
        {modules.map(function(m, idx) {
          var tc = TYPES[m.type] || TYPES.unknown;
          var vinMatch = m.vins.length > 0 && m.vins[0].vin === targetVin;
          var cardBorder = vinMatch ? "#22c55e55" : m.vins.length > 0 && targetVin.length === 17 ? "#ef444488" : "#333";
          return (
            <div key={idx} style={{ background: "#141416", border: "1px solid " + cardBorder, borderRadius: 10, padding: 16, marginBottom: 14 }}>
              {/* Module header */}
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <span style={{ background: tc.color + "30", color: tc.color, border: "1px solid " + tc.color + "66", borderRadius: 5, padding: "3px 10px", fontSize: 10, fontWeight: 800, letterSpacing: 0.5 }}>{tc.label}</span>
                <span style={{ flex: 1, fontSize: 10, color: "#d4d4d8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.fileName}</span>
                <span style={{ fontSize: 9, color: "#71717a" }}>{(m.size / 1024).toFixed(0)} KB</span>
                <button onClick={function() { removeModule(idx); }} style={{ background: "none", border: "none", color: "#71717a", cursor: "pointer", fontSize: 14, fontFamily: FNT, padding: "0 4px" }}>✕</button>
              </div>

              {/* VIN */}
              {m.vins.length > 0 && (
                <div style={{ background: "#0c0c0e", borderRadius: 8, padding: "10px 12px", marginBottom: 8, border: "1px solid " + (vinMatch ? "#22c55e44" : "#ef444444") }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 6 }}>
                    <div>
                      <span style={{ fontSize: 9, color: "#a1a1aa" }}>VIN: </span>
                      <span style={{ fontSize: 14, fontWeight: 900, letterSpacing: 2.5, color: vinMatch ? "#4ade80" : "#f87171" }}>{m.vins[0].vin}</span>
                      {m.vins[0].mirrored && <span style={{ fontSize: 8, color: "#22d3ee", marginLeft: 8, fontWeight: 700 }}>MIRRORED</span>}
                    </div>
                    <span style={{ fontSize: 9, color: vinMatch ? "#4ade80" : "#f87171", fontWeight: 700 }}>{vinMatch ? "✓ MATCH" : "✗ MISMATCH"}</span>
                  </div>
                </div>
              )}

              {/* Security Key (95640 / RFHUB EEE) */}
              {m.securityKey && (
                <div style={{ background: "#0c0c0e", borderRadius: 8, padding: "10px 12px", marginBottom: 8, border: "1px solid #252528" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: "#d4d4d8", fontWeight: 600 }}>Secret Key @ {hx(m.securityKeyOffset)}</span>
                    <span style={{ fontSize: 9, padding: "2px 8px", borderRadius: 4, fontWeight: 800, background: m.securityKeyBlank ? "#422006" : "#052e16", color: m.securityKeyBlank ? "#fb923c" : "#4ade80" }}>{m.securityKeyBlank ? "ERASED" : "POPULATED"}</span>
                  </div>
                  <div style={{ fontSize: 11, color: m.securityKeyBlank ? "#525252" : "#e879f9", fontWeight: 700, letterSpacing: 1.5, wordBreak: "break-all", lineHeight: 1.6 }}>{hxb(m.securityKey)}</div>
                  {!m.securityKeyBlank && <div style={{ fontSize: 9, color: "#a1a1aa", marginTop: 4 }}>ASCII: {asc(m.securityKey)}</div>}
                  {m.securityKeyBlank && secKeys.length > 0 && (
                    <div style={{ marginTop: 8, display: "flex", gap: 6, flexWrap: "wrap" }}>
                      {secKeys.map(function(sk) {
                        if (sk.idx === idx) return null;
                        return (
                          <button key={sk.idx} onClick={function() { syncSecurityKey(sk.idx, idx); }}
                            style={{ background: "#2e1065", color: "#c084fc", border: "1px solid #7c3aed66", borderRadius: 6, padding: "6px 12px", fontSize: 10, fontWeight: 700, cursor: "pointer", fontFamily: FNT }}>
                            Copy from {TYPES[sk.type].label}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Immobilizer Key (BCM) */}
              {m.type === "bcm" && (
                <div style={{ background: "#0c0c0e", borderRadius: 8, padding: "10px 12px", marginBottom: 8, border: "1px solid #252528" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: "#d4d4d8", fontWeight: 600 }}>Immobilizer Key @ 0x40C0</span>
                    <span style={{ fontSize: 9, padding: "2px 8px", borderRadius: 4, fontWeight: 800, background: m.immoKeyBlank ? "#422006" : "#052e16", color: m.immoKeyBlank ? "#fb923c" : "#4ade80" }}>{m.immoKeyBlank ? "BLANK" : "POPULATED"}</span>
                  </div>
                  {!m.immoKeyBlank && (
                    <div>
                      <div style={{ fontSize: 11, color: "#e879f9", fontWeight: 700, letterSpacing: 1.5, wordBreak: "break-all", lineHeight: 1.6 }}>{hxb(m.immoKey)}</div>
                      <div style={{ fontSize: 9, color: m.immoKeysMatch ? "#4ade80" : "#ef4444", marginTop: 4, fontWeight: 600 }}>
                        {"Backup @ 0x40F0: " + (m.immoKeysMatch ? "✓ matches primary" : "✗ MISMATCH — backup differs")}
                      </div>
                    </div>
                  )}
                  {/* 0x2000 backup */}
                  <div style={{ marginTop: 6, paddingTop: 6, borderTop: "1px solid #1e1e21" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontSize: 9, color: "#a1a1aa" }}>Security Backup @ 0x2000</span>
                      <span style={{ fontSize: 9, color: m.backup2000Blank ? "#525252" : "#4ade80", fontWeight: 600 }}>{m.backup2000Blank ? "BLANK" : "POPULATED"}</span>
                    </div>
                    {!m.backup2000Blank && m.backup2000 && (
                      <div style={{ fontSize: 9, color: "#a78bfa", fontWeight: 600, letterSpacing: 1, marginTop: 4, wordBreak: "break-all" }}>{hxb(m.backup2000.slice(0, 16))}</div>
                    )}
                  </div>
                </div>
              )}

              {/* Fob Status (95640) */}
              {m.type === "95640" && (
                <div style={{ background: "#0c0c0e", borderRadius: 8, padding: "8px 12px", marginBottom: 8, border: "1px solid #252528" }}>
                  <span style={{ fontSize: 10, color: "#a1a1aa" }}>Fob Data: </span>
                  <span style={{ fontSize: 10, color: m.fobBlank ? "#71717a" : "#4ade80", fontWeight: 600 }}>{m.fobBlank ? "NO FOBS PROGRAMMED" : "HAS FOB DATA"}</span>
                </div>
              )}

              {/* GPEC2A all VIN slots */}
              {m.type === "gpec2a" && (
                <div style={{ background: "#0c0c0e", borderRadius: 8, padding: "10px 12px", marginBottom: 8, border: "1px solid #252528" }}>
                  <span style={{ fontSize: 10, color: "#d4d4d8", fontWeight: 600 }}>ECM VIN Slots</span>
                  {m.vins.map(function(v, vi) {
                    return <div key={vi} style={{ fontSize: 9, color: "#a1a1aa", marginTop: 3 }}>{hx(v.offset) + ": " + v.vin}</div>;
                  })}
                  {m.ecmConfig && <div style={{ fontSize: 9, color: "#525252", marginTop: 6 }}>Config @ 0x0800: {hxb(m.ecmConfig.slice(0, 12))} ...</div>}
                </div>
              )}

              {/* ACTION BUTTONS — always visible */}
              <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                {targetVin.length === 17 && (
                  <button onClick={function() { patchVin(idx, targetVin); }}
                    style={{ flex: 1, padding: "10px 12px", background: vinMatch ? "#1a3a1a" : R, color: vinMatch ? "#4ade80" : "#fff", border: vinMatch ? "1px solid #22c55e44" : "none", borderRadius: 6, fontSize: 10, fontWeight: 800, cursor: "pointer", fontFamily: FNT, letterSpacing: 0.5, textTransform: "uppercase", minWidth: 140 }}>
                    {vinMatch ? "↓ Download with current VIN" : "Patch VIN + Download"}
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {/* Message */}
        {msg && (
          <div style={{ background: "#0a1a0a", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 8, padding: 12, marginTop: 10 }}>
            <div style={{ fontSize: 10, color: "#86efac" }}>{msg}</div>
          </div>
        )}

        {modules.length === 0 && (
          <div style={{ textAlign: "center", padding: 40, color: "#3f3f46", fontSize: 11 }}>
            Upload BCM, RFHUB, 95640, and GPEC2A files to compare security bytes
          </div>
        )}
      </div>
    </div>
  );
}
