import { and, asc, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, alphaParams, bcmParams, diagSessions, dtcDatabase, ecmCalibrations, moduleSnapshots, udsLogs, users, auditLogs, InsertAuditLog, AuditLog
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── DTC Database ─────────────────────────────────────────────────────────────
export async function lookupDTC(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(dtcDatabase).where(eq(dtcDatabase.code, code.toUpperCase())).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function lookupDTCs(codes: string[]) {
  const db = await getDb();
  if (!db || codes.length === 0) return [];
  // Batch lookup
  const results = await db.select().from(dtcDatabase).where(
    or(...codes.map(c => eq(dtcDatabase.code, c.toUpperCase())))
  );
  return results;
}

export async function searchDTCs(query: string, faultType?: string, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return { results: [], total: 0 };
  const conditions = [];
  if (query) {
    conditions.push(or(
      like(dtcDatabase.code, `%${query.toUpperCase()}%`),
      like(dtcDatabase.description, `%${query}%`),
      like(dtcDatabase.system, `%${query}%`)
    ));
  }
  if (faultType) conditions.push(eq(dtcDatabase.faultType, faultType));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const [results, countResult] = await Promise.all([
    db.select().from(dtcDatabase).where(where).orderBy(asc(dtcDatabase.code)).limit(limit).offset(offset),
    db.select({ count: sql<number>`COUNT(*)` }).from(dtcDatabase).where(where),
  ]);
  return { results, total: Number(countResult[0]?.count ?? 0) };
}

// ─── AlphaOBD Parameters ──────────────────────────────────────────────────────
export async function searchAlphaParams(query: string, tableSource?: string, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return { results: [], total: 0 };
  const conditions = [];
  if (query) {
    conditions.push(or(
      like(alphaParams.name, `%${query}%`),
      like(alphaParams.description, `%${query}%`),
      like(alphaParams.paramId, `%${query}%`),
      like(alphaParams.didHex, `%${query.toUpperCase()}%`),
      like(alphaParams.category, `%${query}%`)
    ));
  }
  if (tableSource) conditions.push(eq(alphaParams.tableSource, tableSource));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const [results, countResult] = await Promise.all([
    db.select().from(alphaParams).where(where).orderBy(asc(alphaParams.tableSource), asc(alphaParams.name)).limit(limit).offset(offset),
    db.select({ count: sql<number>`COUNT(*)` }).from(alphaParams).where(where),
  ]);
  return { results, total: Number(countResult[0]?.count ?? 0) };
}

export async function getAlphaTableStats() {
  const db = await getDb();
  if (!db) return [];
  const result = await db.select({
    tableSource: alphaParams.tableSource,
    count: sql<number>`COUNT(*)`,
  }).from(alphaParams).groupBy(alphaParams.tableSource).orderBy(asc(alphaParams.tableSource));
  return result.map(r => ({ tableSource: r.tableSource, count: Number(r.count) }));
}

// ─── BCM Parameters ───────────────────────────────────────────────────────────
export async function getBcmParams(category?: string, search?: string, limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return { results: [], total: 0 };
  const conditions = [];
  if (category) conditions.push(eq(bcmParams.category, category));
  if (search) {
    conditions.push(or(
      like(bcmParams.name, `%${search}%`),
      like(bcmParams.description, `%${search}%`),
      like(bcmParams.didHex, `%${search.toUpperCase()}%`)
    ));
  }
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const [results, countResult] = await Promise.all([
    db.select().from(bcmParams).where(where).orderBy(asc(bcmParams.category), asc(bcmParams.name)).limit(limit).offset(offset),
    db.select({ count: sql<number>`COUNT(*)` }).from(bcmParams).where(where),
  ]);
  return { results, total: Number(countResult[0]?.count ?? 0) };
}

export async function getBcmCategories() {
  const db = await getDb();
  if (!db) return [];
  const result = await db.select({
    category: bcmParams.category,
    count: sql<number>`COUNT(*)`,
  }).from(bcmParams).groupBy(bcmParams.category).orderBy(asc(bcmParams.category));
  return result.map(r => ({ category: r.category, count: Number(r.count) }));
}

export async function getBcmSrtPreset(preset: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bcmParams).where(eq(bcmParams.srtPreset, preset)).orderBy(asc(bcmParams.category), asc(bcmParams.name));
}

// ─── Diagnostic Sessions ──────────────────────────────────────────────────────
export async function createSession(data: {
  userId?: number;
  vin?: string;
  tool: string;
  adapterInfo?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(diagSessions).values({
    userId: data.userId,
    vin: data.vin,
    tool: data.tool,
    adapterInfo: data.adapterInfo,
    status: "active",
  });
  return (result as any).insertId as number;
}

export async function completeSession(sessionId: number, summary: string, status: "completed" | "failed" = "completed") {
  const db = await getDb();
  if (!db) return;
  await db.update(diagSessions).set({
    status,
    summary,
    endedAt: new Date(),
  }).where(eq(diagSessions.id, sessionId));
}

export async function addUdsLog(sessionId: number, entry: {
  direction: "tx" | "rx" | "info" | "success" | "error" | "warning";
  txId?: number;
  rxId?: number;
  service?: string;
  data?: string;
  message: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(udsLogs).values({
    sessionId,
    direction: entry.direction,
    txId: entry.txId,
    rxId: entry.rxId,
    service: entry.service,
    data: entry.data,
    message: entry.message,
  });
}

export async function getSessionLogs(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(udsLogs).where(eq(udsLogs.sessionId, sessionId)).orderBy(asc(udsLogs.ts));
}

export async function getSessionsByVin(vin: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(diagSessions).where(eq(diagSessions.vin, vin)).orderBy(desc(diagSessions.startedAt)).limit(limit);
}

export async function getRecentSessions(userId?: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  const where = userId ? eq(diagSessions.userId, userId) : undefined;
  return db.select().from(diagSessions).where(where).orderBy(desc(diagSessions.startedAt)).limit(limit);
}

export async function saveModuleSnapshot(data: {
  sessionId: number;
  moduleAddr: number;
  moduleName?: string;
  snapshotType: "before" | "after";
  vin?: string;
  partNumber?: string;
  serialNumber?: string;
  supplierCode?: string;
  hwVersion?: string;
  swVersion?: string;
  dtcCount?: number;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(moduleSnapshots).values(data);
}

export async function getModuleSnapshots(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(moduleSnapshots).where(eq(moduleSnapshots.sessionId, sessionId)).orderBy(asc(moduleSnapshots.moduleAddr));
}

// ─── ECM Calibration Files ────────────────────────────────────────────────────
export async function insertCalibration(data: {
  userId?: number;
  fileName: string;
  fileKey: string;
  fileUrl: string;
  fileSize: number;
  crc32?: string;
  crc16?: string;
  md5?: string;
  moduleType?: string;
  platform?: string;
  partNumber?: string;
  swVersion?: string;
  hwVersion?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(ecmCalibrations).values(data);
  return (result[0] as any).insertId as number;
}

export async function listCalibrations(userId?: number, moduleType?: string, platform?: string, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (userId) conditions.push(eq(ecmCalibrations.userId, userId));
  if (moduleType) conditions.push(eq(ecmCalibrations.moduleType, moduleType));
  if (platform) conditions.push(eq(ecmCalibrations.platform, platform));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(ecmCalibrations).where(where).orderBy(desc(ecmCalibrations.createdAt)).limit(limit).offset(offset);
}

export async function getCalibrationById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(ecmCalibrations).where(eq(ecmCalibrations.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function deleteCalibration(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(ecmCalibrations).where(eq(ecmCalibrations.id, id));
}

export async function incrementFlashCount(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(ecmCalibrations)
    .set({ flashCount: sql`${ecmCalibrations.flashCount} + 1`, lastFlashedAt: new Date() })
    .where(eq(ecmCalibrations.id, id));
}

export async function updateCalibrationNotes(id: number, notes: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(ecmCalibrations).set({ notes }).where(eq(ecmCalibrations.id, id));
}

// ─── Snapshot Comparison Helpers ──────────────────────────────────────────────
export async function listAllSnapshots(vin?: string, limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  const where = vin ? eq(moduleSnapshots.vin, vin) : undefined;
  return db
    .select({
      id: moduleSnapshots.id,
      sessionId: moduleSnapshots.sessionId,
      moduleAddr: moduleSnapshots.moduleAddr,
      moduleName: moduleSnapshots.moduleName,
      snapshotType: moduleSnapshots.snapshotType,
      vin: moduleSnapshots.vin,
      partNumber: moduleSnapshots.partNumber,
      serialNumber: moduleSnapshots.serialNumber,
      supplierCode: moduleSnapshots.supplierCode,
      hwVersion: moduleSnapshots.hwVersion,
      swVersion: moduleSnapshots.swVersion,
      dtcCount: moduleSnapshots.dtcCount,
      capturedAt: moduleSnapshots.capturedAt,
    })
    .from(moduleSnapshots)
    .where(where)
    .orderBy(desc(moduleSnapshots.capturedAt))
    .limit(limit)
    .offset(offset);
}

export async function getSnapshotById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(moduleSnapshots)
    .where(eq(moduleSnapshots.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export async function getSnapshotsByIds(ids: number[]) {
  const db = await getDb();
  if (!db) return [];
  if (ids.length === 0) return [];
  const results = [];
  for (const id of ids) {
    const rows = await db.select().from(moduleSnapshots).where(eq(moduleSnapshots.id, id)).limit(1);
    if (rows[0]) results.push(rows[0]);
  }
  return results;
}

// ─── Snapshot Pair Lookup ─────────────────────────────────────────────────────
// Returns the best before+after pair for a session (first before, first after per module addr)
export async function getSnapshotPairForSession(sessionId: number): Promise<{
  beforeId: number | null;
  afterId: number | null;
  moduleAddr: number | null;
  moduleName: string | null;
  hasPair: boolean;
}> {
  const db = await getDb();
  if (!db) return { beforeId: null, afterId: null, moduleAddr: null, moduleName: null, hasPair: false };

  const rows = await db
    .select({
      id: moduleSnapshots.id,
      moduleAddr: moduleSnapshots.moduleAddr,
      moduleName: moduleSnapshots.moduleName,
      snapshotType: moduleSnapshots.snapshotType,
    })
    .from(moduleSnapshots)
    .where(eq(moduleSnapshots.sessionId, sessionId))
    .orderBy(asc(moduleSnapshots.moduleAddr), asc(moduleSnapshots.id));

  if (rows.length === 0) return { beforeId: null, afterId: null, moduleAddr: null, moduleName: null, hasPair: false };

  // Group by moduleAddr, find first addr that has both before and after
  const byAddr = new Map<number, { before?: number; after?: number; moduleName: string | null }>();
  for (const row of rows) {
    if (!byAddr.has(row.moduleAddr)) byAddr.set(row.moduleAddr, { moduleName: row.moduleName });
    const entry = byAddr.get(row.moduleAddr)!;
    if (row.snapshotType === "before" && !entry.before) entry.before = row.id;
    if (row.snapshotType === "after" && !entry.after) entry.after = row.id;
  }

  // Prefer a module that has both before and after
  for (const [addr, entry] of Array.from(byAddr.entries())) {
    if (entry.before && entry.after) {
      return { beforeId: entry.before, afterId: entry.after, moduleAddr: addr, moduleName: entry.moduleName, hasPair: true };
    }
  }

  // Fallback: return any two snapshots from the session (first before + first after regardless of module)
  const firstBefore = rows.find((r) => r.snapshotType === "before");
  const firstAfter = rows.find((r) => r.snapshotType === "after");
  if (firstBefore && firstAfter) {
    return { beforeId: firstBefore.id, afterId: firstAfter.id, moduleAddr: firstBefore.moduleAddr, moduleName: firstBefore.moduleName, hasPair: true };
  }

  // Only one type exists — return what we have
  const first = rows[0];
  return { beforeId: first.snapshotType === "before" ? first.id : null, afterId: first.snapshotType === "after" ? first.id : null, moduleAddr: first.moduleAddr, moduleName: first.moduleName, hasPair: false };
}

// ─── Session Module Pairs ─────────────────────────────────────────────────────
// Returns ALL before+after pairs grouped by module for a session.
// Each entry represents one module address that has at least one snapshot.
export type ModulePairEntry = {
  moduleAddr: number;
  moduleName: string | null;
  beforeId: number | null;
  afterId: number | null;
  beforeCapturedAt: Date | null;
  afterCapturedAt: Date | null;
  hasPair: boolean; // true when both before and after exist
};

export async function getSessionModulePairs(sessionId: number): Promise<ModulePairEntry[]> {
  const db = await getDb();
  if (!db) return [];

  const rows = await db
    .select({
      id: moduleSnapshots.id,
      moduleAddr: moduleSnapshots.moduleAddr,
      moduleName: moduleSnapshots.moduleName,
      snapshotType: moduleSnapshots.snapshotType,
      capturedAt: moduleSnapshots.capturedAt,
    })
    .from(moduleSnapshots)
    .where(eq(moduleSnapshots.sessionId, sessionId))
    .orderBy(asc(moduleSnapshots.moduleAddr), asc(moduleSnapshots.id));

  if (rows.length === 0) return [];

  // Group by moduleAddr
  const byAddr = new Map<number, ModulePairEntry>();
  for (const row of rows) {
    if (!byAddr.has(row.moduleAddr)) {
      byAddr.set(row.moduleAddr, {
        moduleAddr: row.moduleAddr,
        moduleName: row.moduleName,
        beforeId: null,
        afterId: null,
        beforeCapturedAt: null,
        afterCapturedAt: null,
        hasPair: false,
      });
    }
    const entry = byAddr.get(row.moduleAddr)!;
    if (row.snapshotType === "before" && !entry.beforeId) {
      entry.beforeId = row.id;
      entry.beforeCapturedAt = row.capturedAt as Date;
    }
    if (row.snapshotType === "after" && !entry.afterId) {
      entry.afterId = row.id;
      entry.afterCapturedAt = row.capturedAt as Date;
    }
    entry.hasPair = entry.beforeId !== null && entry.afterId !== null;
  }

  // Sort: complete pairs first, then by moduleAddr
  return Array.from(byAddr.values()).sort((a, b) => {
    if (a.hasPair && !b.hasPair) return -1;
    if (!a.hasPair && b.hasPair) return 1;
    return a.moduleAddr - b.moduleAddr;
  });
}

// ─── Cross-Session Module Tracking ───────────────────────────────────────────

export type DistinctModule = {
  moduleAddr: number;
  moduleName: string | null;
  snapshotCount: number;
  sessionCount: number;
  firstSeen: Date | null;
  lastSeen: Date | null;
};

/** Returns all unique module addresses that have at least one snapshot, with counts. */
export async function getDistinctModules(vin?: string): Promise<DistinctModule[]> {
  const db = await getDb();
  if (!db) return [];

  const whereClause = vin ? eq(moduleSnapshots.vin, vin) : undefined;

  const rows = await db
    .select({
      moduleAddr: moduleSnapshots.moduleAddr,
      moduleName: moduleSnapshots.moduleName,
      snapshotCount: sql<number>`COUNT(*)`,
      sessionCount: sql<number>`COUNT(DISTINCT ${moduleSnapshots.sessionId})`,
      firstSeen: sql<Date>`MIN(${moduleSnapshots.capturedAt})`,
      lastSeen: sql<Date>`MAX(${moduleSnapshots.capturedAt})`,
    })
    .from(moduleSnapshots)
    .where(whereClause)
    .groupBy(moduleSnapshots.moduleAddr, moduleSnapshots.moduleName)
    .orderBy(asc(moduleSnapshots.moduleAddr));

  // Deduplicate: same addr may appear with different moduleName values; keep most recent name
  const byAddr = new Map<number, DistinctModule>();
  for (const row of rows) {
    const existing = byAddr.get(row.moduleAddr);
    if (!existing || (row.lastSeen && existing.lastSeen && row.lastSeen > existing.lastSeen)) {
      byAddr.set(row.moduleAddr, {
        moduleAddr: row.moduleAddr,
        moduleName: row.moduleName,
        snapshotCount: Number(row.snapshotCount),
        sessionCount: Number(row.sessionCount),
        firstSeen: row.firstSeen ? new Date(row.firstSeen) : null,
        lastSeen: row.lastSeen ? new Date(row.lastSeen) : null,
      });
    } else if (existing) {
      existing.snapshotCount += Number(row.snapshotCount);
    }
  }

  return Array.from(byAddr.values()).sort((a, b) => b.snapshotCount - a.snapshotCount);
}

export type ModuleSnapshotEntry = {
  id: number;
  sessionId: number;
  moduleAddr: number;
  moduleName: string | null;
  snapshotType: "before" | "after";
  vin: string | null;
  partNumber: string | null;
  serialNumber: string | null;
  supplierCode: string | null;
  hwVersion: string | null;
  swVersion: string | null;
  dtcCount: number | null;
  capturedAt: Date;
  sessionTool: string | null;
};

/** Returns all snapshots for a given module address, across all sessions, newest first. */
export async function getSnapshotsByModule(
  moduleAddr: number,
  opts?: { vin?: string; limit?: number }
): Promise<ModuleSnapshotEntry[]> {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(moduleSnapshots.moduleAddr, moduleAddr)];
  if (opts?.vin) conditions.push(eq(moduleSnapshots.vin, opts.vin));

  const rows = await db
    .select({
      id: moduleSnapshots.id,
      sessionId: moduleSnapshots.sessionId,
      moduleAddr: moduleSnapshots.moduleAddr,
      moduleName: moduleSnapshots.moduleName,
      snapshotType: moduleSnapshots.snapshotType,
      vin: moduleSnapshots.vin,
      partNumber: moduleSnapshots.partNumber,
      serialNumber: moduleSnapshots.serialNumber,
      supplierCode: moduleSnapshots.supplierCode,
      hwVersion: moduleSnapshots.hwVersion,
      swVersion: moduleSnapshots.swVersion,
      dtcCount: moduleSnapshots.dtcCount,
      capturedAt: moduleSnapshots.capturedAt,
      sessionTool: diagSessions.tool,
    })
    .from(moduleSnapshots)
    .leftJoin(diagSessions, eq(moduleSnapshots.sessionId, diagSessions.id))
    .where(and(...conditions))
    .orderBy(desc(moduleSnapshots.capturedAt))
    .limit(opts?.limit ?? 100);

  return rows.map((r) => ({
    ...r,
    capturedAt: new Date(r.capturedAt),
    snapshotType: r.snapshotType as "before" | "after",
  }));
}


// ─── Audit Logs ───────────────────────────────────────────────────────────────
/**
 * Create a new audit log entry for VIN writing exports
 */
export async function createAuditLog(data: InsertAuditLog): Promise<AuditLog | null> {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot create audit log: database not available"); return null; }
  try {
    await db.insert(auditLogs).values(data);
    const rows = await db.select().from(auditLogs).where(eq(auditLogs.userId, data.userId)).orderBy(desc(auditLogs.createdAt)).limit(1);
    return rows[0] || null;
  } catch (error) { console.error("[Database] Failed to create audit log:", error); throw error; }
}

/**
 * Get audit logs for a specific user with optional filters
 */
export async function getAuditLogs(userId: number, opts?: {
  limit?: number;
  offset?: number;
  vehicleVin?: string;
  exportFormat?: 'json' | 'csv' | 'html';
}) {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get audit logs: database not available"); return []; }
  try {
    const conditions = [eq(auditLogs.userId, userId)];
    if (opts?.vehicleVin) conditions.push(eq(auditLogs.vehicleVin, opts.vehicleVin));
    if (opts?.exportFormat) conditions.push(eq(auditLogs.exportFormat, opts.exportFormat));

    const rows = await db.select()
      .from(auditLogs)
      .where(and(...conditions))
      .orderBy(desc(auditLogs.createdAt))
      .limit(opts?.limit ?? 50)
      .offset(opts?.offset ?? 0);

    return rows.map(r => ({
      ...r,
      createdAt: new Date(r.createdAt),
      exportedAt: new Date(r.exportedAt),
    }));
  } catch (error) { console.error("[Database] Failed to get audit logs:", error); throw error; }
}

/**
 * Get a specific audit log by ID
 */
export async function getAuditLogById(id: number): Promise<AuditLog | null> {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get audit log: database not available"); return null; }
  try {
    const row = await db.select().from(auditLogs).where(eq(auditLogs.id, id)).limit(1);
    if (!row[0]) return null;
    return {
      ...row[0],
      createdAt: new Date(row[0].createdAt),
      exportedAt: new Date(row[0].exportedAt),
    };
  } catch (error) { console.error("[Database] Failed to get audit log:", error); throw error; }
}

/**
 * Delete an audit log entry
 */
export async function deleteAuditLog(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot delete audit log: database not available"); return false; }
  try {
    await db.delete(auditLogs).where(eq(auditLogs.id, id));
    return true;
  } catch (error) { console.error("[Database] Failed to delete audit log:", error); throw error; }
}

/**
 * Get audit log statistics for a user
 */
export async function getAuditLogStats(userId: number) {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get audit stats: database not available"); return null; }
  try {
    const rows = await db.select({
      totalExports: sql<number>`COUNT(*)`,
      totalSuccessful: sql<number>`SUM(${auditLogs.successCount})`,
      totalFailed: sql<number>`SUM(${auditLogs.failureCount})`,
      totalLogs: sql<number>`SUM(${auditLogs.logCount})`,
      uniqueVins: sql<number>`COUNT(DISTINCT ${auditLogs.vehicleVin})`,
    })
      .from(auditLogs)
      .where(eq(auditLogs.userId, userId));

    return rows[0] || null;
  } catch (error) { console.error("[Database] Failed to get audit stats:", error); throw error; }
}
