/**
 * Real-Time Collaboration Server — adapted from Claude Code's collaboration-socket.ts
 * Manages technician presence, shared session state, and tool-use approval workflow.
 * Multiple technicians can watch the same vehicle session in real time.
 */

import { Server as SocketServer, Socket } from "socket.io";
import type { Server as HTTPServer } from "http";
import { getSessionCookieOptions } from "./_core/cookies";
import { getUserByOpenId } from "./db";

export interface CollabUser {
  userId: number;
  name: string;
  role: "owner" | "viewer" | "technician";
  sessionId: string;
  vin?: string;
  tool?: string;
  color: string;
}

export interface ToolApprovalRequest {
  id: string;
  requesterId: number;
  requesterName: string;
  tool: string;
  description: string;
  payload: unknown;
  sessionId: string;
  timestamp: number;
}

export interface ToolApprovalResponse {
  requestId: string;
  approved: boolean;
  approverId: number;
  approverName: string;
}

// Assign a deterministic color per user
const COLLAB_COLORS = [
  "#ef4444", "#f97316", "#eab308", "#22c55e",
  "#06b6d4", "#8b5cf6", "#ec4899", "#14b8a6",
];

function colorForUser(userId: number): string {
  return COLLAB_COLORS[userId % COLLAB_COLORS.length];
}

// Room = VIN-based session room
function vinRoom(vin: string): string {
  return `vin:${vin.toUpperCase()}`;
}

export function setupCollaboration(httpServer: HTTPServer): SocketServer {
  const io = new SocketServer(httpServer, {
    path: "/api/collab",
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
      credentials: true,
    },
  });

  // Track connected users per room
  const rooms = new Map<string, Map<string, CollabUser>>();
  // Track pending tool approval requests
  const pendingApprovals = new Map<string, ToolApprovalRequest>();

  io.on("connection", (socket: Socket) => {
    let currentUser: CollabUser | null = null;
    let currentVin: string | null = null;

    // Join a vehicle session room
    socket.on("join_session", async (data: { vin: string; userId: number; name: string; role?: CollabUser["role"] }) => {
      const { vin, userId, name, role = "technician" } = data;
      currentVin = vin.toUpperCase();
      const room = vinRoom(currentVin);

      currentUser = {
        userId,
        name,
        role,
        sessionId: socket.id,
        vin: currentVin,
        color: colorForUser(userId),
      };

      socket.join(room);

      if (!rooms.has(room)) rooms.set(room, new Map());
      rooms.get(room)!.set(socket.id, currentUser);

      // Broadcast updated presence list to room
      const presence = Array.from(rooms.get(room)!.values());
      io.to(room).emit("presence_update", presence);

      // Send current pending approvals to new joiner
      const roomApprovals = Array.from(pendingApprovals.values()).filter(
        (a) => a.sessionId === room
      );
      socket.emit("pending_approvals", roomApprovals);

      console.log(`[Collab] ${name} joined room ${room} as ${role}`);
    });

    // Update current tool/activity
    socket.on("update_activity", (data: { tool?: string }) => {
      if (!currentUser || !currentVin) return;
      const room = vinRoom(currentVin);
      currentUser.tool = data.tool;
      if (rooms.has(room)) {
        rooms.get(room)!.set(socket.id, currentUser);
        const presence = Array.from(rooms.get(room)!.values());
        io.to(room).emit("presence_update", presence);
      }
    });

    // Request tool-use approval (for write operations)
    socket.on("request_approval", (data: Omit<ToolApprovalRequest, "requesterId" | "requesterName" | "sessionId" | "timestamp">) => {
      if (!currentUser || !currentVin) return;
      const room = vinRoom(currentVin);

      const request: ToolApprovalRequest = {
        ...data,
        requesterId: currentUser.userId,
        requesterName: currentUser.name,
        sessionId: room,
        timestamp: Date.now(),
      };

      pendingApprovals.set(request.id, request);
      // Broadcast to all room members (owners/senior techs can approve)
      io.to(room).emit("approval_requested", request);
    });

    // Respond to tool-use approval
    socket.on("respond_approval", (data: ToolApprovalResponse) => {
      if (!currentUser || !currentVin) return;
      const room = vinRoom(currentVin);

      pendingApprovals.delete(data.requestId);
      io.to(room).emit("approval_response", {
        ...data,
        approverId: currentUser.userId,
        approverName: currentUser.name,
      });
    });

    // Broadcast UDS log entry to all room viewers
    socket.on("broadcast_log", (entry: unknown) => {
      if (!currentVin) return;
      const room = vinRoom(currentVin);
      socket.to(room).emit("log_entry", entry);
    });

    // Broadcast scan progress
    socket.on("scan_progress", (data: unknown) => {
      if (!currentVin) return;
      socket.to(vinRoom(currentVin)).emit("scan_progress", data);
    });

    socket.on("disconnect", () => {
      if (!currentVin) return;
      const room = vinRoom(currentVin);
      if (rooms.has(room)) {
        rooms.get(room)!.delete(socket.id);
        if (rooms.get(room)!.size === 0) {
          rooms.delete(room);
        } else {
          const presence = Array.from(rooms.get(room)!.values());
          io.to(room).emit("presence_update", presence);
        }
      }
      if (currentUser) {
        console.log(`[Collab] ${currentUser.name} left room ${room}`);
      }
    });
  });

  return io;
}
