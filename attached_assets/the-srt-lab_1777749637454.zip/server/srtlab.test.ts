import { describe, expect, it } from "vitest";

// ─── VIN Validation ───────────────────────────────────────────────────────────
function isValidVin(vin: string): boolean {
  return /^[A-HJ-NPR-Z0-9]{17}$/i.test(vin);
}

describe("VIN Validation", () => {
  it("accepts a valid 17-char VIN", () => {
    expect(isValidVin("2C3CDXGJ8MH123456")).toBe(true);
  });
  it("rejects VIN shorter than 17 chars", () => {
    expect(isValidVin("2C3CDXGJ8MH12345")).toBe(false);
  });
  it("rejects VIN with invalid chars (I, O, Q)", () => {
    expect(isValidVin("2C3CDXGJ8MI123456")).toBe(false);
    expect(isValidVin("2C3CDXGJ8MO123456")).toBe(false);
    expect(isValidVin("2C3CDXGJ8MQ123456")).toBe(false);
  });
  it("rejects empty string", () => {
    expect(isValidVin("")).toBe(false);
  });
});

// ─── Seed-Key Algorithms ──────────────────────────────────────────────────────
function computeROL5(seed: number): number {
  const rol = ((seed << 5) | (seed >>> 27)) & 0xFFFFFFFF;
  return (rol ^ 0xB3A2C1D0) & 0xFFFFFFFF;
}

function computeSBEC2(seed: number): number {
  let key = seed;
  for (let i = 0; i < 4; i++) {
    key = ((key << 2) | (key >>> 30)) & 0xFFFFFFFF;
    key ^= 0xA5A5A5A5;
  }
  return key & 0xFFFFFFFF;
}

function computeNGC3(seed: number): number {
  return (seed ^ 0x9D3E5F7A) & 0xFFFFFFFF;
}

describe("Seed-Key Algorithms", () => {
  it("ROL5 produces deterministic output for same seed", () => {
    const r1 = computeROL5(0xABCD1234);
    const r2 = computeROL5(0xABCD1234);
    expect(r1).toBe(r2);
  });

  it("ROL5 output differs from input", () => {
    const seed = 0x12345678;
    expect(computeROL5(seed)).not.toBe(seed);
  });

  it("SBEC2 produces deterministic output", () => {
    expect(computeSBEC2(0xDEADBEEF)).toBe(computeSBEC2(0xDEADBEEF));
  });

  it("NGC3 XOR with constant produces correct result", () => {
    // JS bitwise ops return signed 32-bit int, so mask to unsigned
    expect(computeNGC3(0x00000000) >>> 0).toBe(0x9D3E5F7A >>> 0);
    expect(computeNGC3(0xFFFFFFFF) >>> 0).toBe((0xFFFFFFFF ^ 0x9D3E5F7A) >>> 0);
  });

  it("different seeds produce different keys for ROL5", () => {
    expect(computeROL5(0x11111111)).not.toBe(computeROL5(0x22222222));
  });
});

// ─── RFHUB Virginizer Logic ───────────────────────────────────────────────────
const RFHUB_REGIONS = [
  { name: "VIN Location #1", offset: 0x0EA5, len: 17, type: "vin" },
  { name: "Secret Key", offset: 0x0040, len: 16, type: "key" },
  { name: "Fob Data Block", offset: 0x0200, len: 64, type: "fob" },
  { name: "CRC-16 #1", offset: 0x0EB7, len: 2, type: "crc" },
];

function virginizeBuffer(data: Uint8Array): Uint8Array {
  const patched = new Uint8Array(data);
  for (const r of RFHUB_REGIONS) {
    if (r.offset + r.len > patched.length) continue;
    const fillByte = r.type === "crc" ? 0x00 : 0xFF;
    patched.fill(fillByte, r.offset, r.offset + r.len);
  }
  return patched;
}

describe("RFHUB Virginizer", () => {
  it("fills VIN region with 0xFF", () => {
    const buf = new Uint8Array(0x1000);
    buf.fill(0x41, 0x0EA5, 0x0EA5 + 17); // fill with 'A'
    const result = virginizeBuffer(buf);
    for (let i = 0x0EA5; i < 0x0EA5 + 17; i++) {
      expect(result[i]).toBe(0xFF);
    }
  });

  it("fills CRC region with 0x00", () => {
    const buf = new Uint8Array(0x1000);
    buf.fill(0xAB, 0x0EB7, 0x0EB7 + 2);
    const result = virginizeBuffer(buf);
    expect(result[0x0EB7]).toBe(0x00);
    expect(result[0x0EB8]).toBe(0x00);
  });

  it("does not modify bytes outside defined regions", () => {
    const buf = new Uint8Array(0x1000);
    buf.fill(0x55);
    const result = virginizeBuffer(buf);
    // Byte at 0x0000 should be untouched (not in any region)
    expect(result[0x0000]).toBe(0x55);
  });

  it("does not crash on undersized buffer", () => {
    const buf = new Uint8Array(10); // too small for any region
    expect(() => virginizeBuffer(buf)).not.toThrow();
  });
});

// ─── Module Scanner ───────────────────────────────────────────────────────────
const FCA_MODULES: Record<string, string> = {
  "0x7E0": "PCM",
  "0x7E1": "TCM",
  "0x742": "BCM",
  "0x760": "ABS",
  "0x75F": "RFHUB",
  "0x744": "SKIM",
  "0x745": "IPC",
  "0x740": "ORC",
};

function getModuleName(addr: number): string | null {
  return FCA_MODULES[`0x${addr.toString(16).toUpperCase()}`] || null;
}

describe("Module Scanner", () => {
  it("identifies PCM at 0x7E0", () => {
    expect(getModuleName(0x7E0)).toBe("PCM");
  });
  it("identifies BCM at 0x742", () => {
    expect(getModuleName(0x742)).toBe("BCM");
  });
  it("returns null for unknown address", () => {
    expect(getModuleName(0x600)).toBeNull();
  });
  it("identifies RFHUB at 0x75F", () => {
    expect(getModuleName(0x75F)).toBe("RFHUB");
  });
});

// ─── DTC Severity Classification ─────────────────────────────────────────────
function classifyDTC(code: string): "critical" | "warning" | "info" {
  if (code.startsWith("P0") || code.startsWith("U0") || code.startsWith("C0")) return "critical";
  if (code.startsWith("P1") || code.startsWith("B1") || code.startsWith("C1")) return "warning";
  return "info";
}

describe("DTC Severity Classification", () => {
  it("classifies P0xxx as critical", () => {
    expect(classifyDTC("P0300")).toBe("critical");
  });
  it("classifies U0xxx as critical", () => {
    expect(classifyDTC("U0100")).toBe("critical");
  });
  it("classifies P1xxx as warning", () => {
    expect(classifyDTC("P1234")).toBe("warning");
  });
  it("classifies B2xxx as info", () => {
    expect(classifyDTC("B2000")).toBe("info");
  });
});

// ─── Auth logout (existing test) ─────────────────────────────────────────────
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; clearedCookies: { name: string; options: Record<string, unknown> }[] } {
  const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];
  const user: AuthenticatedUser = {
    id: 1, openId: "sample-user", email: "sample@example.com",
    name: "Sample User", loginMethod: "manus", role: "user",
    createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date(),
  };
  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };
  return { ctx, clearedCookies };
}

describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1, secure: true, sameSite: "none", httpOnly: true, path: "/" });
  });
});

// ─── Snapshot Comparison Logic ────────────────────────────────────────────────
type SnapField = "vin" | "partNumber" | "serialNumber" | "supplierCode" | "hwVersion" | "swVersion" | "dtcCount" | "moduleName";

function compareSnapshotFields(
  a: Partial<Record<SnapField, string | number | null>>,
  b: Partial<Record<SnapField, string | number | null>>
) {
  const fields: SnapField[] = ["vin", "partNumber", "serialNumber", "supplierCode", "hwVersion", "swVersion", "dtcCount", "moduleName"];
  const diffs: Array<{ field: string; valueA: string | number | null; valueB: string | number | null; changed: boolean }> = [];
  for (const f of fields) {
    const va = a[f] ?? null;
    const vb = b[f] ?? null;
    diffs.push({ field: f, valueA: va, valueB: vb, changed: va !== vb });
  }
  return { diffs, changedCount: diffs.filter((d) => d.changed).length };
}

describe("Snapshot Comparison Logic", () => {
  it("detects no changes when snapshots are identical", () => {
    const snap = { vin: "2C3CDXGJ8MH123456", partNumber: "68123456AB", serialNumber: "SN001", supplierCode: "CONT", hwVersion: "01", swVersion: "02", dtcCount: 0, moduleName: "BCM" };
    const { changedCount } = compareSnapshotFields(snap, snap);
    expect(changedCount).toBe(0);
  });

  it("detects VIN change as critical field change", () => {
    const a = { vin: "2C3CDXGJ8MH000001", partNumber: "68123456AB" };
    const b = { vin: "2C3CDXGJ8MH999999", partNumber: "68123456AB" };
    const { diffs, changedCount } = compareSnapshotFields(a, b);
    expect(changedCount).toBe(1);
    const vinDiff = diffs.find((d) => d.field === "vin");
    expect(vinDiff?.changed).toBe(true);
    expect(vinDiff?.valueA).toBe("2C3CDXGJ8MH000001");
    expect(vinDiff?.valueB).toBe("2C3CDXGJ8MH999999");
  });

  it("detects SW version change", () => {
    const a = { swVersion: "01.02.03" };
    const b = { swVersion: "01.02.04" };
    const { diffs } = compareSnapshotFields(a, b);
    const swDiff = diffs.find((d) => d.field === "swVersion");
    expect(swDiff?.changed).toBe(true);
  });

  it("counts multiple changed fields correctly", () => {
    const a = { vin: "2C3CDXGJ8MH000001", partNumber: "68123456AB", swVersion: "01", dtcCount: 0 };
    const b = { vin: "2C3CDXGJ8MH999999", partNumber: "68999999ZZ", swVersion: "01", dtcCount: 5 };
    const { changedCount } = compareSnapshotFields(a, b);
    expect(changedCount).toBe(3); // vin, partNumber, dtcCount
  });

  it("treats null and missing values as equal (both null)", () => {
    const a = { vin: null };
    const b = { vin: null };
    const { diffs } = compareSnapshotFields(a, b);
    const vinDiff = diffs.find((d) => d.field === "vin");
    expect(vinDiff?.changed).toBe(false);
  });
});

// ─── Quick Compare URL Param Parsing ─────────────────────────────────────────
function parseQuickCompareParams(search: string): { preA: number | null; preB: number | null } {
  const params = new URLSearchParams(search);
  const a = params.get("a");
  const b = params.get("b");
  return {
    preA: a ? parseInt(a, 10) : null,
    preB: b ? parseInt(b, 10) : null,
  };
}

describe("Quick Compare URL Param Parsing", () => {
  it("parses valid ?a=1&b=2 params", () => {
    const result = parseQuickCompareParams("?a=1&b=2");
    expect(result.preA).toBe(1);
    expect(result.preB).toBe(2);
  });

  it("returns null for missing params", () => {
    const result = parseQuickCompareParams("");
    expect(result.preA).toBeNull();
    expect(result.preB).toBeNull();
  });

  it("returns null when only one param is present", () => {
    const resultA = parseQuickCompareParams("?a=5");
    expect(resultA.preA).toBe(5);
    expect(resultA.preB).toBeNull();

    const resultB = parseQuickCompareParams("?b=10");
    expect(resultB.preA).toBeNull();
    expect(resultB.preB).toBe(10);
  });

  it("parses large snapshot IDs correctly", () => {
    const result = parseQuickCompareParams("?a=99999&b=100000");
    expect(result.preA).toBe(99999);
    expect(result.preB).toBe(100000);
  });
});

// ─── Multi-Module Pair Grouping Logic ─────────────────────────────────────────
type RawSnapshotRow = {
  id: number;
  moduleAddr: number;
  moduleName: string | null;
  snapshotType: "before" | "after";
  capturedAt: Date;
};

type PairEntry = {
  moduleAddr: number;
  moduleName: string | null;
  beforeId: number | null;
  afterId: number | null;
  hasPair: boolean;
};

function groupIntoPairs(rows: RawSnapshotRow[]): PairEntry[] {
  const byAddr = new Map<number, PairEntry>();
  for (const row of rows) {
    if (!byAddr.has(row.moduleAddr)) {
      byAddr.set(row.moduleAddr, {
        moduleAddr: row.moduleAddr,
        moduleName: row.moduleName,
        beforeId: null,
        afterId: null,
        hasPair: false,
      });
    }
    const entry = byAddr.get(row.moduleAddr)!;
    if (row.snapshotType === "before" && !entry.beforeId) entry.beforeId = row.id;
    if (row.snapshotType === "after" && !entry.afterId) entry.afterId = row.id;
    entry.hasPair = entry.beforeId !== null && entry.afterId !== null;
  }
  return Array.from(byAddr.values()).sort((a, b) => {
    if (a.hasPair && !b.hasPair) return -1;
    if (!a.hasPair && b.hasPair) return 1;
    return a.moduleAddr - b.moduleAddr;
  });
}

describe("Multi-Module Pair Grouping", () => {
  const now = new Date();

  it("groups a single before+after pair correctly", () => {
    const rows: RawSnapshotRow[] = [
      { id: 1, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "before", capturedAt: now },
      { id: 2, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "after", capturedAt: now },
    ];
    const result = groupIntoPairs(rows);
    expect(result).toHaveLength(1);
    expect(result[0].hasPair).toBe(true);
    expect(result[0].beforeId).toBe(1);
    expect(result[0].afterId).toBe(2);
  });

  it("returns multiple entries for multiple modules", () => {
    const rows: RawSnapshotRow[] = [
      { id: 1, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "before", capturedAt: now },
      { id: 2, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "after", capturedAt: now },
      { id: 3, moduleAddr: 0x7e0, moduleName: "ECM", snapshotType: "before", capturedAt: now },
      { id: 4, moduleAddr: 0x7e0, moduleName: "ECM", snapshotType: "after", capturedAt: now },
    ];
    const result = groupIntoPairs(rows);
    expect(result).toHaveLength(2);
    expect(result.every((r) => r.hasPair)).toBe(true);
  });

  it("marks partial entries (only before) as hasPair=false", () => {
    const rows: RawSnapshotRow[] = [
      { id: 1, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "before", capturedAt: now },
    ];
    const result = groupIntoPairs(rows);
    expect(result[0].hasPair).toBe(false);
    expect(result[0].beforeId).toBe(1);
    expect(result[0].afterId).toBeNull();
  });

  it("sorts complete pairs before partial ones", () => {
    const rows: RawSnapshotRow[] = [
      { id: 1, moduleAddr: 0x7e0, moduleName: "ECM", snapshotType: "before", capturedAt: now },
      { id: 2, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "before", capturedAt: now },
      { id: 3, moduleAddr: 0x7e4, moduleName: "BCM", snapshotType: "after", capturedAt: now },
    ];
    const result = groupIntoPairs(rows);
    expect(result[0].moduleAddr).toBe(0x7e4); // BCM has pair, comes first
    expect(result[1].moduleAddr).toBe(0x7e0); // ECM is partial, comes second
    expect(result[0].hasPair).toBe(true);
    expect(result[1].hasPair).toBe(false);
  });

  it("handles empty input", () => {
    expect(groupIntoPairs([])).toHaveLength(0);
  });
});

// ─── Cross-Session Module Compare ─────────────────────────────────────────────

describe("getDistinctModules", () => {
  it("deduplicates module addresses with different names and keeps most recent", () => {
    type DistRow = { moduleAddr: number; moduleName: string | null; lastSeen: Date | null; snapshotCount: number };
    const rows: DistRow[] = [
      { moduleAddr: 0x7e4, moduleName: "BCM_OLD", lastSeen: new Date("2024-01-01"), snapshotCount: 2 },
      { moduleAddr: 0x7e4, moduleName: "BCM",     lastSeen: new Date("2024-06-01"), snapshotCount: 3 },
      { moduleAddr: 0x7e0, moduleName: "ECM",     lastSeen: new Date("2024-05-01"), snapshotCount: 5 },
    ];

    const byAddr = new Map<number, DistRow>();
    for (const row of rows) {
      const existing = byAddr.get(row.moduleAddr);
      if (!existing || (row.lastSeen && existing.lastSeen && row.lastSeen > existing.lastSeen)) {
        byAddr.set(row.moduleAddr, { ...row });
      } else if (existing) {
        existing.snapshotCount += row.snapshotCount;
      }
    }

    const result = Array.from(byAddr.values());
    const bcm = result.find(r => r.moduleAddr === 0x7e4);
    expect(bcm?.moduleName).toBe("BCM");
    expect(result).toHaveLength(2);
  });

  it("sorts by snapshotCount descending", () => {
    const modules = [
      { moduleAddr: 0x7e0, snapshotCount: 2 },
      { moduleAddr: 0x7e4, snapshotCount: 10 },
      { moduleAddr: 0x733, snapshotCount: 5 },
    ];
    const sorted = [...modules].sort((a, b) => b.snapshotCount - a.snapshotCount);
    expect(sorted[0].moduleAddr).toBe(0x7e4);
    expect(sorted[1].moduleAddr).toBe(0x733);
    expect(sorted[2].moduleAddr).toBe(0x7e0);
  });
});

describe("getSnapshotsByModule — cross-session ordering", () => {
  it("orders snapshots newest first", () => {
    const snaps = [
      { id: 1, capturedAt: new Date("2024-01-01"), sessionId: 10 },
      { id: 3, capturedAt: new Date("2024-06-01"), sessionId: 30 },
      { id: 2, capturedAt: new Date("2024-03-01"), sessionId: 20 },
    ];
    const sorted = [...snaps].sort((a, b) => b.capturedAt.getTime() - a.capturedAt.getTime());
    expect(sorted[0].id).toBe(3);
    expect(sorted[1].id).toBe(2);
    expect(sorted[2].id).toBe(1);
  });

  it("filters by VIN when provided", () => {
    const snaps = [
      { id: 1, vin: "1C4RJFAG0FC123456", moduleAddr: 0x7e4 },
      { id: 2, vin: "2C4RJFAG0FC654321", moduleAddr: 0x7e4 },
      { id: 3, vin: "1C4RJFAG0FC123456", moduleAddr: 0x7e4 },
    ];
    const targetVin = "1C4RJFAG0FC123456";
    const filtered = snaps.filter(s => s.vin === targetVin);
    expect(filtered).toHaveLength(2);
    expect(filtered.every(s => s.vin === targetVin)).toBe(true);
  });
});

describe("CrossSessionCompare — diff engine", () => {
  type SnapRow = {
    vin: string | null; partNumber: string | null; serialNumber: string | null;
    supplierCode: string | null; hwVersion: string | null; swVersion: string | null;
    dtcCount: number | null; moduleName: string | null;
  };

  function diffSnapshots(a: SnapRow, b: SnapRow) {
    const fields = ["vin", "partNumber", "serialNumber", "supplierCode", "hwVersion", "swVersion", "dtcCount", "moduleName"] as const;
    return fields.map(f => {
      const vA = a[f] != null ? String(a[f]) : null;
      const vB = b[f] != null ? String(b[f]) : null;
      return { field: f, valueA: vA, valueB: vB, changed: vA !== vB };
    });
  }

  it("detects changes across sessions for the same module", () => {
    const session1snap: SnapRow = {
      vin: "1C4RJFAG0FC123456", partNumber: "68123456AB", serialNumber: "SN001",
      supplierCode: "CONT", hwVersion: "H01", swVersion: "SW01", dtcCount: 0, moduleName: "BCM"
    };
    const session2snap: SnapRow = {
      vin: "1C4RJFAG0FC123456", partNumber: "68123456AB", serialNumber: "SN001",
      supplierCode: "CONT", hwVersion: "H01", swVersion: "SW02", dtcCount: 3, moduleName: "BCM"
    };
    const diffs = diffSnapshots(session1snap, session2snap);
    const changed = diffs.filter(d => d.changed);
    expect(changed.map(d => d.field)).toContain("swVersion");
    expect(changed.map(d => d.field)).toContain("dtcCount");
    expect(changed).toHaveLength(2);
  });

  it("returns zero changed fields when snapshots are identical", () => {
    const snap: SnapRow = {
      vin: "1C4RJFAG0FC123456", partNumber: "68123456AB", serialNumber: "SN001",
      supplierCode: "CONT", hwVersion: "H01", swVersion: "SW01", dtcCount: 0, moduleName: "BCM"
    };
    const diffs = diffSnapshots(snap, { ...snap });
    expect(diffs.filter(d => d.changed)).toHaveLength(0);
  });

  it("handles null fields gracefully (null vs null = unchanged)", () => {
    const a: SnapRow = { vin: null, partNumber: null, serialNumber: null, supplierCode: null, hwVersion: null, swVersion: null, dtcCount: null, moduleName: null };
    const b: SnapRow = { ...a };
    const diffs = diffSnapshots(a, b);
    expect(diffs.filter(d => d.changed)).toHaveLength(0);
  });
});

// ─── Bench Detector VIN Slot Fix ──────────────────────────────────────────────

describe("analyzeBenchFile — VIN slot extraction", () => {
  // Mirror the fixed extractVin logic from VINCommander.tsx
  function extractVin(bytes: number[]): string | null {
    if (bytes.every(b => b === 0x00 || b === 0xFF)) return null;
    const printCount = bytes.filter(b => b >= 0x20 && b <= 0x7E).length;
    if (printCount < 14) return null;
    const chars = bytes.map(b => (b >= 0x20 && b <= 0x7E) ? String.fromCharCode(b) : "?");
    const candidate = chars.join("").trim();
    if (candidate.length !== 17) return null;
    if (/[IOQ]/i.test(candidate)) return null;
    if (!/^[A-HJ-NPR-Z0-9]{17}$/i.test(candidate)) return null;
    return candidate.toUpperCase();
  }

  it("extracts a clean 17-byte ASCII VIN correctly", () => {
    const vin = "1C4RJFAG0FC123456";
    const bytes = Array.from(vin).map(c => c.charCodeAt(0));
    expect(extractVin(bytes)).toBe("1C4RJFAG0FC123456");
  });

  it("returns null for all-zero (blank) slot", () => {
    const bytes = new Array(17).fill(0x00);
    expect(extractVin(bytes)).toBeNull();
  });

  it("returns null for all-0xFF (erased) slot", () => {
    const bytes = new Array(17).fill(0xFF);
    expect(extractVin(bytes)).toBeNull();
  });

  it("rejects VIN with forbidden chars I, O, Q", () => {
    // 'I' at position 0 is invalid
    const vin = "IC4RJFAG0FC123456";
    const bytes = Array.from(vin).map(c => c.charCodeAt(0));
    expect(extractVin(bytes)).toBeNull();
  });

  it("rejects non-VIN printable string (e.g. all spaces)", () => {
    const bytes = new Array(17).fill(0x20); // all spaces
    expect(extractVin(bytes)).toBeNull();
  });

  it("all 4 RFHUB VIN offsets are correctly spaced (0x14 = 20 bytes apart)", () => {
    const offsets = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
    expect(offsets).toHaveLength(4);
    for (let i = 1; i < offsets.length; i++) {
      expect(offsets[i] - offsets[i - 1]).toBe(0x14); // 20-byte stride
    }
  });

  it("BCM VIN offsets match Alpha OBD ground truth (4792/4824/4856/4888 decimal)", () => {
    // From Alpha OBD: BCM MPC5606B_05B, 4 copies, stride = 0x20 (32 bytes)
    const bcmOffsets = [0x12B8, 0x12D8, 0x12F8, 0x1318];
    expect(bcmOffsets).toHaveLength(4);
    expect(bcmOffsets[0]).toBe(4792); // dec 4792
    expect(bcmOffsets[1]).toBe(4824); // dec 4824
    expect(bcmOffsets[2]).toBe(4856); // dec 4856
    expect(bcmOffsets[3]).toBe(4888); // dec 4888
    // Verify constant stride of 32 bytes between copies
    for (let i = 1; i < bcmOffsets.length; i++) {
      expect(bcmOffsets[i] - bcmOffsets[i - 1]).toBe(0x20);
    }
  });
});

// ─── BCM VIN CRC16-CCITT-FALSE Tests (v4.13) ────────────────────────────────
// Algorithm: poly=0x1021, init=0xFFFF, no input/output reflection
// Verified against real 17scatpack_Dflash_bcm.bin hex diff:
//   VIN "2C3CDXHG5EH219538" stored with 0x7753 at offset+17 in all 4 primary slots
describe("BCM VIN CRC16-CCITT-FALSE", () => {
  function crc16CcittFalse(data: string): number {
    let crc = 0xFFFF;
    for (const c of data) {
      crc ^= (c.charCodeAt(0) << 8);
      for (let i = 0; i < 8; i++) {
        crc = (crc & 0x8000) ? (((crc << 1) ^ 0x1021) & 0xFFFF) : ((crc << 1) & 0xFFFF);
      }
    }
    return crc;
  }

  it("produces 0x7753 for VIN 2C3CDXHG5EH219538 (verified from real file hex diff)", () => {
    expect(crc16CcittFalse("2C3CDXHG5EH219538")).toBe(0x7753);
  });

  it("produces 0x41D9 for VIN 2B3CJ4DV6AH300549 (scatpack)", () => {
    expect(crc16CcittFalse("2B3CJ4DV6AH300549")).toBe(0x41D9);
  });

  it("produces different CRC for different VINs", () => {
    const crc1 = crc16CcittFalse("2C3CDXHG5EH219538");
    const crc2 = crc16CcittFalse("2B3CJ4DV6AH300549");
    expect(crc1).not.toBe(crc2);
  });

  it("CRC is always a 16-bit value (0x0000–0xFFFF)", () => {
    const vins = [
      "2C3CDXHG5EH219538",
      "2B3CJ4DV6AH300549",
      "1HGBH41JXMN109186",
      "JH4DA9370MS016526",
    ];
    for (const vin of vins) {
      const crc = crc16CcittFalse(vin);
      expect(crc).toBeGreaterThanOrEqual(0x0000);
      expect(crc).toBeLessThanOrEqual(0xFFFF);
    }
  });

  it("all 4 BCM primary slots get the same CRC (same VIN = same CRC)", () => {
    // Slots at 0x12B8/0x12D8/0x12F8/0x1318 all store the same VIN → same CRC
    const crc = crc16CcittFalse("2C3CDXHG5EH219538");
    expect(crc).toBe(0x7753); // confirmed from hex diff: all 4 slots had 77 53
  });

  it("CRC bytes are big-endian: high byte first", () => {
    const crc = crc16CcittFalse("2C3CDXHG5EH219538"); // 0x7753
    const highByte = (crc >> 8) & 0xFF;
    const lowByte = crc & 0xFF;
    expect(highByte).toBe(0x77); // stored at offset+17
    expect(lowByte).toBe(0x53);  // stored at offset+18
  });
});

// ── PIN Extraction Logic Tests ──────────────────────────────────────────────
describe("PIN Extraction — ASCII sweep", () => {
  // Simulate the client-side extractPin logic in pure JS for testing
  function scanForAsciiPins(bytes: Uint8Array): Array<{ offset: number; pin: string }> {
    const isDigit = (b: number) => b >= 0x30 && b <= 0x39;
    const results: Array<{ offset: number; pin: string }> = [];
    for (let i = 0; i <= bytes.length - 4; i++) {
      if (isDigit(bytes[i]) && isDigit(bytes[i+1]) && isDigit(bytes[i+2]) && isDigit(bytes[i+3])) {
        const before = i > 0 ? isDigit(bytes[i-1]) : false;
        const after = i+4 < bytes.length ? isDigit(bytes[i+4]) : false;
        if (!before && !after) {
          results.push({ offset: i, pin: String.fromCharCode(bytes[i], bytes[i+1], bytes[i+2], bytes[i+3]) });
        }
      }
    }
    return results;
  }

  function scanBCD(bytes: Uint8Array, offset: number): string {
    const b0 = bytes[offset], b1 = bytes[offset + 1];
    return `${(b0>>4)&0xF}${b0&0xF}${(b1>>4)&0xF}${b1&0xF}`;
  }

  it("finds ASCII PIN 9433 at known offset", () => {
    const buf = new Uint8Array(512).fill(0xFF);
    // Place ASCII "9433" at offset 0x0080
    buf[0x80] = 0x39; buf[0x81] = 0x34; buf[0x82] = 0x33; buf[0x83] = 0x33;
    const results = scanForAsciiPins(buf);
    expect(results.length).toBeGreaterThanOrEqual(1);
    expect(results[0].pin).toBe("9433");
    expect(results[0].offset).toBe(0x80);
  });

  it("does not return ASCII PIN embedded inside VIN (longer digit run)", () => {
    const buf = new Uint8Array(512).fill(0xFF);
    // VIN-like: 17 consecutive digit bytes at 0x100
    for (let i = 0; i < 17; i++) buf[0x100 + i] = 0x31 + (i % 9);
    const results = scanForAsciiPins(buf);
    // None of the 4-digit runs inside the 17-byte run should appear (they have neighbors)
    expect(results.every(r => r.offset < 0x100 || r.offset >= 0x100 + 17)).toBe(true);
  });

  it("finds multiple ASCII PIN candidates across file", () => {
    const buf = new Uint8Array(1024).fill(0xFF);
    buf[0x64] = 0x31; buf[0x65] = 0x32; buf[0x66] = 0x33; buf[0x67] = 0x34; // "1234"
    buf[0x80] = 0x39; buf[0x81] = 0x34; buf[0x82] = 0x33; buf[0x83] = 0x33; // "9433"
    const results = scanForAsciiPins(buf);
    expect(results.length).toBe(2);
    expect(results.map(r => r.pin)).toContain("9433");
    expect(results.map(r => r.pin)).toContain("1234");
  });

  it("BCD decode at offset 0x0060", () => {
    const buf = new Uint8Array(512).fill(0xFF);
    buf[0x60] = 0x94; buf[0x61] = 0x33; // BCD "9433"
    expect(scanBCD(buf, 0x60)).toBe("9433");
  });

  it("BCD decode handles leading zero PIN", () => {
    const buf = new Uint8Array(512).fill(0xFF);
    buf[0x60] = 0x01; buf[0x61] = 0x23; // BCD "0123"
    expect(scanBCD(buf, 0x60)).toBe("0123");
  });

  it("returns empty array when no 4-digit ASCII sequence found", () => {
    const buf = new Uint8Array(256).fill(0xFF);
    expect(scanForAsciiPins(buf)).toHaveLength(0);
  });
});
