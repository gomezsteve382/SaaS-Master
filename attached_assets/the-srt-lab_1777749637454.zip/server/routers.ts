import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  addUdsLog, completeSession, createSession, getBcmCategories, getBcmParams,
  getBcmSrtPreset, getModuleSnapshots, getRecentSessions, getSessionLogs,
  getSessionsByVin, lookupDTC, lookupDTCs, saveModuleSnapshot, searchAlphaParams,
  searchDTCs, getAlphaTableStats,
  insertCalibration, listCalibrations, getCalibrationById, deleteCalibration,
  incrementFlashCount, updateCalibrationNotes,
  listAllSnapshots, getSnapshotById, getSnapshotsByIds, getSnapshotPairForSession, getSessionModulePairs,
  getDistinctModules, getSnapshotsByModule
} from "./db";
import { assistantRouter } from "./routers/assistant";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── DTC Database ──────────────────────────────────────────────────────────
  dtc: router({
    lookup: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return lookupDTC(input.code);
      }),

    lookupBatch: publicProcedure
      .input(z.object({ codes: z.array(z.string()) }))
      .query(async ({ input }) => {
        return lookupDTCs(input.codes);
      }),

    search: publicProcedure
      .input(z.object({
        query: z.string().default(""),
        faultType: z.string().optional(),
        limit: z.number().min(1).max(200).default(50),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input }) => {
        return searchDTCs(input.query, input.faultType, input.limit, input.offset);
      }),
  }),

  // ─── AlphaOBD Parameters ───────────────────────────────────────────────────
  alpha: router({
    search: publicProcedure
      .input(z.object({
        query: z.string().default(""),
        tableSource: z.string().optional(),
        limit: z.number().min(1).max(200).default(50),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input }) => {
        return searchAlphaParams(input.query, input.tableSource, input.limit, input.offset);
      }),

    tableStats: publicProcedure.query(async () => {
      return getAlphaTableStats();
    }),
  }),

  // ─── BCM Configuration ─────────────────────────────────────────────────────
  bcm: router({
    params: publicProcedure
      .input(z.object({
        category: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().min(1).max(200).default(100),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input }) => {
        return getBcmParams(input.category, input.search, input.limit, input.offset);
      }),

    categories: publicProcedure.query(async () => {
      return getBcmCategories();
    }),

    srtPreset: publicProcedure
      .input(z.object({ preset: z.enum(["track", "daily", "valet"]) }))
      .query(async ({ input }) => {
        return getBcmSrtPreset(input.preset);
      }),
  }),

  // ─── Diagnostic Sessions ───────────────────────────────────────────────────
  sessions: router({
    create: publicProcedure
      .input(z.object({
        vin: z.string().optional(),
        tool: z.string(),
        adapterInfo: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const sessionId = await createSession({
          userId: ctx.user?.id,
          vin: input.vin,
          tool: input.tool,
          adapterInfo: input.adapterInfo,
        });
        return { sessionId };
      }),

    complete: publicProcedure
      .input(z.object({
        sessionId: z.number(),
        summary: z.string(),
        status: z.enum(["completed", "failed"]).default("completed"),
      }))
      .mutation(async ({ input }) => {
        await completeSession(input.sessionId, input.summary, input.status);
        return { success: true };
      }),

    addLog: publicProcedure
      .input(z.object({
        sessionId: z.number(),
        direction: z.enum(["tx", "rx", "info", "success", "error", "warning"]),
        txId: z.number().optional(),
        rxId: z.number().optional(),
        service: z.string().optional(),
        data: z.string().optional(),
        message: z.string(),
      }))
      .mutation(async ({ input }) => {
        await addUdsLog(input.sessionId, input);
        return { success: true };
      }),

    addLogBatch: publicProcedure
      .input(z.object({
        sessionId: z.number(),
        entries: z.array(z.object({
          direction: z.enum(["tx", "rx", "info", "success", "error", "warning"]),
          txId: z.number().optional(),
          rxId: z.number().optional(),
          service: z.string().optional(),
          data: z.string().optional(),
          message: z.string(),
        })),
      }))
      .mutation(async ({ input }) => {
        for (const entry of input.entries) {
          await addUdsLog(input.sessionId, entry);
        }
        return { success: true };
      }),

    getLogs: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return getSessionLogs(input.sessionId);
      }),

    byVin: publicProcedure
      .input(z.object({ vin: z.string(), limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return getSessionsByVin(input.vin, input.limit);
      }),

    recent: publicProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ input, ctx }) => {
        return getRecentSessions(ctx.user?.id, input.limit);
      }),

    saveSnapshot: publicProcedure
      .input(z.object({
        sessionId: z.number(),
        moduleAddr: z.number(),
        moduleName: z.string().optional(),
        snapshotType: z.enum(["before", "after"]),
        vin: z.string().optional(),
        partNumber: z.string().optional(),
        serialNumber: z.string().optional(),
        supplierCode: z.string().optional(),
        hwVersion: z.string().optional(),
        swVersion: z.string().optional(),
        dtcCount: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await saveModuleSnapshot(input);
        return { success: true };
      }),

    getSnapshots: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return getModuleSnapshots(input.sessionId);
      }),
    listAllSnapshots: publicProcedure
      .input(z.object({
        vin: z.string().optional(),
        limit: z.number().min(1).max(500).default(100),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input }) => {
        return listAllSnapshots(input.vin, input.limit, input.offset);
      }),
    getSnapshotById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getSnapshotById(input.id);
      }),
    getSnapshotPair: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return getSnapshotPairForSession(input.sessionId);
      }),
    getSessionModulePairs: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return getSessionModulePairs(input.sessionId);
      }),
    getDistinctModules: publicProcedure
      .input(z.object({ vin: z.string().optional() }))
      .query(async ({ input }) => {
        return getDistinctModules(input.vin);
      }),
    getSnapshotsByModule: publicProcedure
      .input(z.object({
        moduleAddr: z.number(),
        vin: z.string().optional(),
        limit: z.number().min(1).max(200).optional(),
      }))
      .query(async ({ input }) => {
        return getSnapshotsByModule(input.moduleAddr, { vin: input.vin, limit: input.limit });
      }),
    compareSnapshots: publicProcedure
      .input(z.object({ idA: z.number(), idB: z.number() }))
      .query(async ({ input }) => {
        const [a, b] = await getSnapshotsByIds([input.idA, input.idB]);
        if (!a || !b) throw new Error("One or both snapshots not found");
        // Compute field-level diff
        const fields = [
          "vin", "partNumber", "serialNumber", "supplierCode",
          "hwVersion", "swVersion", "dtcCount", "moduleName",
        ] as const;
        type SnapField = typeof fields[number];
        const diffs: Array<{ field: string; valueA: string | number | null; valueB: string | number | null; changed: boolean }> = [];
        for (const f of fields) {
          const va = (a as Record<string, unknown>)[f] ?? null;
          const vb = (b as Record<string, unknown>)[f] ?? null;
          diffs.push({ field: f, valueA: va as string | number | null, valueB: vb as string | number | null, changed: va !== vb });
        }
        return { snapshotA: a, snapshotB: b, diffs, changedCount: diffs.filter((d) => d.changed).length };
      }),
  }),

  // ─── ECM Calibration Files ──────────────────────────────────────────────────
  calibrations: router({
    list: publicProcedure
      .input(z.object({
        moduleType: z.string().optional(),
        platform: z.string().optional(),
        limit: z.number().min(1).max(100).default(50),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input, ctx }) => {
        return listCalibrations(ctx.user?.id, input.moduleType, input.platform, input.limit, input.offset);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getCalibrationById(input.id);
      }),

    create: publicProcedure
      .input(z.object({
        fileName: z.string(),
        fileKey: z.string(),
        fileUrl: z.string(),
        fileSize: z.number(),
        crc32: z.string().optional(),
        crc16: z.string().optional(),
        md5: z.string().optional(),
        moduleType: z.string().optional(),
        platform: z.string().optional(),
        partNumber: z.string().optional(),
        swVersion: z.string().optional(),
        hwVersion: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const id = await insertCalibration({ ...input, userId: ctx.user?.id });
        return { id };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const cal = await getCalibrationById(input.id);
        if (!cal) throw new Error("Calibration not found");
        await deleteCalibration(input.id);
        return { success: true, fileKey: cal.fileKey };
      }),

    recordFlash: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await incrementFlashCount(input.id);
        return { success: true };
      }),

    updateNotes: publicProcedure
      .input(z.object({ id: z.number(), notes: z.string() }))
      .mutation(async ({ input }) => {
        await updateCalibrationNotes(input.id, input.notes);
        return { success: true };
      }),
  }),

  // ─── Audit Logs ──────────────────────────────────────────────────────────────
  auditLogs: router({
    create: protectedProcedure
      .input(z.object({
        exportFormat: z.enum(['json', 'csv', 'html']),
        logCount: z.number().int().min(0),
        successCount: z.number().int().min(0),
        failureCount: z.number().int().min(0),
        vehicleVin: z.string().length(17).optional(),
        sessionId: z.number().int().optional(),
        metadata: z.record(z.string(), z.any()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { createAuditLog } = await import('./db');
        return await createAuditLog({
          userId: ctx.user.id,
          exportFormat: input.exportFormat,
          logCount: input.logCount,
          successCount: input.successCount,
          failureCount: input.failureCount,
          vehicleVin: input.vehicleVin || null,
          sessionId: input.sessionId || null,
          metadata: input.metadata ? JSON.stringify(input.metadata) : null,
          exportedAt: new Date(),
        });
      }),

    list: protectedProcedure
      .input(z.object({
        limit: z.number().int().min(1).max(100).optional(),
        offset: z.number().int().min(0).optional(),
        vehicleVin: z.string().length(17).optional(),
        exportFormat: z.enum(['json', 'csv', 'html']).optional(),
      }))
      .query(async ({ ctx, input }) => {
        const { getAuditLogs } = await import('./db');
        return await getAuditLogs(ctx.user.id, {
          limit: input.limit,
          offset: input.offset,
          vehicleVin: input.vehicleVin,
          exportFormat: input.exportFormat,
        });
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number().int() }))
      .query(async ({ input }) => {
        const { getAuditLogById } = await import('./db');
        return await getAuditLogById(input.id);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number().int() }))
      .mutation(async ({ input }) => {
        const { deleteAuditLog } = await import('./db');
        const success = await deleteAuditLog(input.id);
        return { success };
      }),

    stats: protectedProcedure
      .query(async ({ ctx }) => {
        const { getAuditLogStats } = await import('./db');
        return await getAuditLogStats(ctx.user.id);
      }),
  }),

  // ─── AI Diagnostic Assistant ────────────────────────────────────────────────
  assistant: assistantRouter,
});
export type AppRouter = typeof appRouter;
