/**
 * AI Diagnostic Assistant router — powered by the built-in LLM
 * Adapted from Claude Code's chat + tool-use system.
 * The assistant can query the DTC database, BCM params, and AlphaOBD tables
 * and suggest diagnostic steps. Write operations require explicit user approval.
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { getDb } from "../db";
import { dtcDatabase, bcmParams, alphaParams } from "../../drizzle/schema";
import { like, or, eq } from "drizzle-orm";

const SYSTEM_PROMPT = `You are an expert FCA/Stellantis automotive diagnostic technician assistant embedded in The SRT Lab platform.

You have access to the following tools:
- search_dtcs: Search the 22,166-code DTC database by code or description
- search_bcm_params: Search 4,826+ BCM parameters by name or category
- search_alphaobd: Search 34,625+ AlphaOBD parameters across all tables
- explain_uds_frame: Decode a raw UDS frame (hex bytes) into human-readable format
- suggest_procedure: Given a symptom or module, suggest the correct diagnostic procedure

When a user asks about a DTC, VIN issue, BCM parameter, or module problem, use the appropriate tool to look up real data before answering.

For write operations (VIN write, BCM config change, module clone), always describe what you would do and ask for explicit confirmation before proceeding. Never perform writes autonomously.

Be concise, technical, and accurate. Use correct FCA/Stellantis terminology.`;

const tools = [
  {
    type: "function" as const,
    function: {
      name: "search_dtcs",
      description: "Search the DTC database by code (e.g. P0300) or description keywords",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "DTC code or description to search" },
          limit: { type: "number", description: "Max results (default 5)" },
        },
        required: ["query"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "search_bcm_params",
      description: "Search BCM parameters by name, DID, or category",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string" },
          category: { type: "string", description: "Optional category filter" },
          limit: { type: "number" },
        },
        required: ["query"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "search_alphaobd",
      description: "Search AlphaOBD parameters across all 10 tables",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string" },
          table_name: { type: "string", description: "Optional table filter (e.g. FGA_BCM_DATA)" },
          limit: { type: "number" },
        },
        required: ["query"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "explain_uds_frame",
      description: "Decode a raw UDS frame hex string into human-readable format",
      parameters: {
        type: "object",
        properties: {
          frame: { type: "string", description: "Hex bytes e.g. '67 01 12 34 56 78'" },
          service: { type: "string", description: "Known service context (optional)" },
        },
        required: ["frame"],
        additionalProperties: false,
      },
    },
  },
];

// Execute a tool call from the LLM
async function executeTool(name: string, args: Record<string, unknown>): Promise<string> {
  const db = await getDb();
  if (!db) return JSON.stringify({ error: "Database unavailable" });

  if (name === "search_dtcs") {
    const query = String(args.query ?? "");
    const limit = Number(args.limit ?? 5);
    const results = await db
      .select()
      .from(dtcDatabase)
      .where(
        or(
          like(dtcDatabase.code, `%${query}%`),
          like(dtcDatabase.description, `%${query}%`)
        )
      )
      .limit(limit);
    return JSON.stringify(results);
  }

  if (name === "search_bcm_params") {
    const query = String(args.query ?? "");
    const limit = Number(args.limit ?? 10);
    const results = await db
      .select()
      .from(bcmParams)
      .where(
        or(
          like(bcmParams.name, `%${query}%`),
          like(bcmParams.description, `%${query}%`),
          like(bcmParams.category, `%${query}%`)
        )
      )
      .limit(limit);
    return JSON.stringify(results);
  }

  if (name === "search_alphaobd") {
    const query = String(args.query ?? "");
    const limit = Number(args.limit ?? 10);
    const conditions = [
      like(alphaParams.name, `%${query}%`),
      like(alphaParams.description, `%${query}%`),
    ];
    if (args.table_name) {
      conditions.push(eq(alphaParams.tableSource, String(args.table_name)));
    }
    const results = await db
      .select()
      .from(alphaParams)
      .where(or(...conditions))
      .limit(limit);
    return JSON.stringify(results);
  }

  if (name === "explain_uds_frame") {
    const frame = String(args.frame ?? "").trim();
    const bytes = frame.split(/\s+/).map((b) => parseInt(b, 16));
    if (bytes.length === 0) return JSON.stringify({ error: "Empty frame" });

    const serviceId = bytes[0];
    const serviceMap: Record<number, string> = {
      0x10: "DiagnosticSessionControl",
      0x11: "ECUReset",
      0x14: "ClearDiagnosticInformation",
      0x19: "ReadDTCInformation",
      0x22: "ReadDataByIdentifier",
      0x27: "SecurityAccess",
      0x2E: "WriteDataByIdentifier",
      0x31: "RoutineControl",
      0x50: "DiagnosticSessionControl (response)",
      0x51: "ECUReset (response)",
      0x54: "ClearDiagnosticInformation (response)",
      0x59: "ReadDTCInformation (response)",
      0x62: "ReadDataByIdentifier (response)",
      0x67: "SecurityAccess (response)",
      0x6E: "WriteDataByIdentifier (response)",
      0x71: "RoutineControl (response)",
      0x7F: "NegativeResponse",
    };

    const service = serviceMap[serviceId] ?? `Unknown (0x${serviceId.toString(16).toUpperCase()})`;
    const payload = bytes.slice(1).map((b) => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");

    let decoded = `Service: ${service}\nPayload: ${payload}`;

    if (serviceId === 0x7F && bytes.length >= 3) {
      const nrcMap: Record<number, string> = {
        0x10: "generalReject",
        0x11: "serviceNotSupported",
        0x12: "subFunctionNotSupported",
        0x13: "incorrectMessageLengthOrInvalidFormat",
        0x22: "conditionsNotCorrect",
        0x24: "requestSequenceError",
        0x25: "noResponseFromSubnetComponent",
        0x26: "failurePreventsExecutionOfRequestedAction",
        0x31: "requestOutOfRange",
        0x33: "securityAccessDenied",
        0x35: "invalidKey",
        0x36: "exceededNumberOfAttempts",
        0x37: "requiredTimeDelayNotExpired",
        0x70: "uploadDownloadNotAccepted",
        0x71: "transferDataSuspended",
        0x72: "generalProgrammingFailure",
        0x73: "wrongBlockSequenceCounter",
        0x78: "requestCorrectlyReceivedResponsePending",
        0x7E: "subFunctionNotSupportedInActiveSession",
        0x7F: "serviceNotSupportedInActiveSession",
      };
      const rejectedService = serviceMap[bytes[1]] ?? `0x${bytes[1].toString(16).toUpperCase()}`;
      const nrc = nrcMap[bytes[2]] ?? `0x${bytes[2].toString(16).toUpperCase()}`;
      decoded += `\nRejected Service: ${rejectedService}\nNRC: ${nrc}`;
    }

    return JSON.stringify({ frame, decoded });
  }

  return JSON.stringify({ error: `Unknown tool: ${name}` });
}

export const assistantRouter = router({
  chat: protectedProcedure
    .input(
      z.object({
        messages: z.array(
          z.object({
            role: z.enum(["user", "assistant", "system"]),
            content: z.string(),
          })
        ),
        vin: z.string().optional(),
        module: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { messages, vin, module } = input;

      // Build context-aware system prompt
      let systemPrompt = SYSTEM_PROMPT;
      if (vin) systemPrompt += `\n\nCurrent vehicle VIN: ${vin}`;
      if (module) systemPrompt += `\nActive module: ${module}`;

      const llmMessages = [
        { role: "system" as const, content: systemPrompt },
        ...messages,
      ];

      // First LLM call — may include tool calls
      let response = await invokeLLM({
        messages: llmMessages,
        tools,
        tool_choice: "auto",
      });

      const firstChoice = response.choices?.[0];
      if (!firstChoice) {
        return { content: "No response from assistant.", toolCalls: [] };
      }

      const toolCallResults: Array<{ name: string; result: string }> = [];

      // Agentic loop — execute tool calls and feed results back
      let iterations = 0;
      while (
        firstChoice.message?.tool_calls?.length &&
        iterations < 5
      ) {
        iterations++;
        const toolCalls = firstChoice.message.tool_calls;

        // Execute all tool calls
        const toolResults = await Promise.all(
          toolCalls.map(async (tc: { id: string; function: { name: string; arguments: string } }) => {
            const args = JSON.parse(tc.function.arguments ?? "{}") as Record<string, unknown>;
            const result = await executeTool(tc.function.name, args);
            toolCallResults.push({ name: tc.function.name, result });
            return {
              role: "tool" as const,
              content: result,
              tool_call_id: tc.id,
            };
          })
        );

        // Second LLM call with tool results
        response = await invokeLLM({
          messages: [
            ...llmMessages,
            { role: "assistant" as const, content: firstChoice.message.content ?? "" },
            ...toolResults,
          ],
        });

        break; // Single agentic loop for now
      }

      const finalContent =
        response.choices?.[0]?.message?.content ?? "No response.";

      return {
        content: finalContent,
        toolCalls: toolCallResults,
      };
    }),
});
