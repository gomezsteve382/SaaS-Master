import {
  int, mysqlEnum, mysqlTable, text, timestamp, varchar, bigint, json, boolean, index, float
} from "drizzle-orm/mysql-core";

// ─── Core Users ──────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Diagnostic Sessions ─────────────────────────────────────────────────────
// Each session is tied to a VIN and records all UDS operations performed
export const diagSessions = mysqlTable("diag_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  vin: varchar("vin", { length: 17 }),
  tool: varchar("tool", { length: 64 }).notNull(), // "VINCommander" | "DTCReader" | etc.
  adapterInfo: varchar("adapterInfo", { length: 128 }),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  endedAt: timestamp("endedAt"),
  status: mysqlEnum("status", ["active", "completed", "failed"]).default("active").notNull(),
  summary: text("summary"), // human-readable outcome
}, (t) => [index("idx_session_vin").on(t.vin), index("idx_session_user").on(t.userId)]);

export type DiagSession = typeof diagSessions.$inferSelect;

// ─── UDS Log Entries ─────────────────────────────────────────────────────────
// Every UDS frame sent/received during a session
export const udsLogs = mysqlTable("uds_logs", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  ts: timestamp("ts").defaultNow().notNull(),
  direction: mysqlEnum("direction", ["tx", "rx", "info", "success", "error", "warning"]).notNull(),
  txId: int("txId"),
  rxId: int("rxId"),
  service: varchar("service", { length: 8 }), // e.g. "10", "27", "2E"
  data: varchar("data", { length: 512 }), // hex string of frame bytes
  message: text("message").notNull(),
}, (t) => [index("idx_udslog_session").on(t.sessionId)]);

// ─── Module Snapshots ────────────────────────────────────────────────────────
// Before/after state of a module captured during a session
export const moduleSnapshots = mysqlTable("module_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  moduleAddr: int("moduleAddr").notNull(),
  moduleName: varchar("moduleName", { length: 64 }),
  snapshotType: mysqlEnum("snapshotType", ["before", "after"]).notNull(),
  vin: varchar("vin", { length: 17 }),
  partNumber: varchar("partNumber", { length: 32 }),
  serialNumber: varchar("serialNumber", { length: 32 }),
  supplierCode: varchar("supplierCode", { length: 16 }),
  hwVersion: varchar("hwVersion", { length: 32 }),
  swVersion: varchar("swVersion", { length: 32 }),
  dtcCount: int("dtcCount"),
  capturedAt: timestamp("capturedAt").defaultNow().notNull(),
}, (t) => [index("idx_snapshot_session").on(t.sessionId)]);

// ─── DTC Database ────────────────────────────────────────────────────────────
// Full 22,166-code AlphaOBD fault database
export const dtcDatabase = mysqlTable("dtc_database", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 8 }).notNull().unique(),      // e.g. "P0300"
  description: text("description").notNull(),
  severity: mysqlEnum("severity", ["critical", "warning", "info"]).notNull(),
  system: varchar("system", { length: 32 }),                    // "Engine" | "Transmission" | etc.
  module: varchar("module", { length: 32 }),                    // "PCM" | "BCM" | etc.
  faultType: varchar("faultType", { length: 4 }),               // "P" | "B" | "C" | "U"
}, (t) => [index("idx_dtc_code").on(t.code), index("idx_dtc_type").on(t.faultType)]);

export type DtcRecord = typeof dtcDatabase.$inferSelect;

// ─── AlphaOBD Parameters ─────────────────────────────────────────────────────
// Unified table for all 10 AlphaOBD tables (34,625+ records)
export const alphaParams = mysqlTable("alpha_params", {
  id: int("id").autoincrement().primaryKey(),
  tableSource: varchar("tableSource", { length: 32 }).notNull(), // "FGA_BCM_DATA" | "FGA_ENGINE_DATA" | etc.
  paramId: varchar("paramId", { length: 32 }),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description"),
  unit: varchar("unit", { length: 32 }),
  minVal: float("minVal"),
  maxVal: float("maxVal"),
  defaultVal: varchar("defaultVal", { length: 64 }),
  dataType: varchar("dataType", { length: 32 }),
  didHex: varchar("didHex", { length: 8 }),                     // UDS DID e.g. "F190"
  category: varchar("category", { length: 64 }),
  subcategory: varchar("subcategory", { length: 64 }),
  ecuList: varchar("ecuList", { length: 128 }),                 // applicable ECUs
  notes: text("notes"),
}, (t) => [
  index("idx_alpha_table").on(t.tableSource),
  index("idx_alpha_name").on(t.name),
  index("idx_alpha_did").on(t.didHex),
]);

export type AlphaParam = typeof alphaParams.$inferSelect;

// ─── BCM Configuration Parameters ────────────────────────────────────────────
// 4,826+ BCM programmable parameters with write metadata
export const bcmParams = mysqlTable("bcm_params", {
  id: int("id").autoincrement().primaryKey(),
  paramKey: varchar("paramKey", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 256 }).notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  subcategory: varchar("subcategory", { length: 64 }),
  description: text("description"),
  didHex: varchar("didHex", { length: 8 }),                     // UDS DID for writeDID
  byteOffset: int("byteOffset"),                                // byte offset within DID response
  bitMask: varchar("bitMask", { length: 8 }),                   // hex bitmask e.g. "0x01"
  dataType: mysqlEnum("dataType", ["boolean", "uint8", "uint16", "uint32", "enum", "bcd"]).default("boolean").notNull(),
  enumValues: json("enumValues"),                               // { "0": "OFF", "1": "ON", "2": "AUTO" }
  defaultValue: varchar("defaultValue", { length: 32 }),
  minValue: int("minValue"),
  maxValue: int("maxValue"),
  unit: varchar("unit", { length: 32 }),
  srtPreset: varchar("srtPreset", { length: 32 }),              // "track" | "daily" | "valet" | null
  requiresReboot: boolean("requiresReboot").default(false).notNull(),
  securityLevel: int("securityLevel").default(1),               // 1=L1, 3=L3, etc.
  notes: text("notes"),
}, (t) => [
  index("idx_bcm_category").on(t.category),
  index("idx_bcm_did").on(t.didHex),
]);

export type BcmParam = typeof bcmParams.$inferSelect;

// ─── ECM Calibration Files ────────────────────────────────────────────────────
// Uploaded .bin calibration files stored in S3 with metadata
export const ecmCalibrations = mysqlTable("ecm_calibrations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  fileName: varchar("fileName", { length: 256 }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(),   // S3 key
  fileUrl: text("fileUrl").notNull(),                        // S3 public URL
  fileSize: int("fileSize").notNull(),                       // bytes
  crc32: varchar("crc32", { length: 8 }),                   // hex CRC-32
  crc16: varchar("crc16", { length: 4 }),                   // hex CRC-16
  md5: varchar("md5", { length: 32 }),                      // MD5 hex
  moduleType: varchar("moduleType", { length: 32 }),         // "ECM" | "PCM" | "TCM" | "BCM"
  platform: varchar("platform", { length: 64 }),             // "Challenger SRT" | "Trackhawk" | etc.
  partNumber: varchar("partNumber", { length: 32 }),
  swVersion: varchar("swVersion", { length: 32 }),
  hwVersion: varchar("hwVersion", { length: 32 }),
  notes: text("notes"),
  flashCount: int("flashCount").default(0).notNull(),        // how many times flashed
  lastFlashedAt: timestamp("lastFlashedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_cal_user").on(t.userId),
  index("idx_cal_module").on(t.moduleType),
  index("idx_cal_platform").on(t.platform),
]);

export type EcmCalibration = typeof ecmCalibrations.$inferSelect;
export type InsertEcmCalibration = typeof ecmCalibrations.$inferInsert;


// ─── Audit Logs ──────────────────────────────────────────────────────────────
// VIN writing export audit trail for compliance and historical tracking
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  exportFormat: mysqlEnum("exportFormat", ["json", "csv", "html"]).notNull(),
  logCount: int("logCount").notNull(),              // total entries exported
  successCount: int("successCount").notNull(),      // successful VIN writes
  failureCount: int("failureCount").notNull(),      // failed attempts
  vehicleVin: varchar("vehicleVin", { length: 17 }),
  sessionId: int("sessionId"),                      // optional link to diagSessions
  metadata: json("metadata"),                       // operator, notes, etc.
  exportedAt: timestamp("exportedAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => [
  index("idx_audit_user").on(t.userId),
  index("idx_audit_vin").on(t.vehicleVin),
  index("idx_audit_created").on(t.createdAt),
]);

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;
