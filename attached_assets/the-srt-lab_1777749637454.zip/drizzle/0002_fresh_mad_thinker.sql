CREATE TABLE `ecm_calibrations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`fileName` varchar(256) NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileSize` int NOT NULL,
	`crc32` varchar(8),
	`crc16` varchar(4),
	`md5` varchar(32),
	`moduleType` varchar(32),
	`platform` varchar(64),
	`partNumber` varchar(32),
	`swVersion` varchar(32),
	`hwVersion` varchar(32),
	`notes` text,
	`flashCount` int NOT NULL DEFAULT 0,
	`lastFlashedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ecm_calibrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `idx_cal_user` ON `ecm_calibrations` (`userId`);--> statement-breakpoint
CREATE INDEX `idx_cal_module` ON `ecm_calibrations` (`moduleType`);--> statement-breakpoint
CREATE INDEX `idx_cal_platform` ON `ecm_calibrations` (`platform`);