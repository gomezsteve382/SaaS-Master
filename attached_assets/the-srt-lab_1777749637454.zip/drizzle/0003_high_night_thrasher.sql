CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`exportFormat` enum('json','csv','html') NOT NULL,
	`logCount` int NOT NULL,
	`successCount` int NOT NULL,
	`failureCount` int NOT NULL,
	`vehicleVin` varchar(17),
	`sessionId` int,
	`metadata` json,
	`exportedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `idx_audit_user` ON `audit_logs` (`userId`);--> statement-breakpoint
CREATE INDEX `idx_audit_vin` ON `audit_logs` (`vehicleVin`);--> statement-breakpoint
CREATE INDEX `idx_audit_created` ON `audit_logs` (`createdAt`);