CREATE TABLE `alpha_params` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tableSource` varchar(32) NOT NULL,
	`paramId` varchar(32),
	`name` varchar(256) NOT NULL,
	`description` text,
	`unit` varchar(32),
	`minVal` float,
	`maxVal` float,
	`defaultVal` varchar(64),
	`dataType` varchar(32),
	`didHex` varchar(8),
	`category` varchar(64),
	`subcategory` varchar(64),
	`ecuList` varchar(128),
	`notes` text,
	CONSTRAINT `alpha_params_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bcm_params` (
	`id` int AUTO_INCREMENT NOT NULL,
	`paramKey` varchar(64) NOT NULL,
	`name` varchar(256) NOT NULL,
	`category` varchar(64) NOT NULL,
	`subcategory` varchar(64),
	`description` text,
	`didHex` varchar(8),
	`byteOffset` int,
	`bitMask` varchar(8),
	`dataType` enum('boolean','uint8','uint16','uint32','enum','bcd') NOT NULL DEFAULT 'boolean',
	`enumValues` json,
	`defaultValue` varchar(32),
	`minValue` int,
	`maxValue` int,
	`unit` varchar(32),
	`srtPreset` varchar(32),
	`requiresReboot` boolean NOT NULL DEFAULT false,
	`securityLevel` int DEFAULT 1,
	`notes` text,
	CONSTRAINT `bcm_params_id` PRIMARY KEY(`id`),
	CONSTRAINT `bcm_params_paramKey_unique` UNIQUE(`paramKey`)
);
--> statement-breakpoint
CREATE TABLE `diag_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`vin` varchar(17),
	`tool` varchar(64) NOT NULL,
	`adapterInfo` varchar(128),
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`endedAt` timestamp,
	`status` enum('active','completed','failed') NOT NULL DEFAULT 'active',
	`summary` text,
	CONSTRAINT `diag_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dtc_database` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(8) NOT NULL,
	`description` text NOT NULL,
	`severity` enum('critical','warning','info') NOT NULL,
	`system` varchar(32),
	`module` varchar(32),
	`faultType` varchar(4),
	CONSTRAINT `dtc_database_id` PRIMARY KEY(`id`),
	CONSTRAINT `dtc_database_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `module_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`moduleAddr` int NOT NULL,
	`moduleName` varchar(64),
	`snapshotType` enum('before','after') NOT NULL,
	`vin` varchar(17),
	`partNumber` varchar(32),
	`serialNumber` varchar(32),
	`supplierCode` varchar(16),
	`hwVersion` varchar(32),
	`swVersion` varchar(32),
	`dtcCount` int,
	`capturedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `module_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `uds_logs` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`ts` timestamp NOT NULL DEFAULT (now()),
	`direction` enum('tx','rx','info','success','error','warning') NOT NULL,
	`txId` int,
	`rxId` int,
	`service` varchar(8),
	`data` varchar(512),
	`message` text NOT NULL,
	CONSTRAINT `uds_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `idx_alpha_table` ON `alpha_params` (`tableSource`);--> statement-breakpoint
CREATE INDEX `idx_alpha_name` ON `alpha_params` (`name`);--> statement-breakpoint
CREATE INDEX `idx_alpha_did` ON `alpha_params` (`didHex`);--> statement-breakpoint
CREATE INDEX `idx_bcm_category` ON `bcm_params` (`category`);--> statement-breakpoint
CREATE INDEX `idx_bcm_did` ON `bcm_params` (`didHex`);--> statement-breakpoint
CREATE INDEX `idx_session_vin` ON `diag_sessions` (`vin`);--> statement-breakpoint
CREATE INDEX `idx_session_user` ON `diag_sessions` (`userId`);--> statement-breakpoint
CREATE INDEX `idx_dtc_code` ON `dtc_database` (`code`);--> statement-breakpoint
CREATE INDEX `idx_dtc_type` ON `dtc_database` (`faultType`);--> statement-breakpoint
CREATE INDEX `idx_snapshot_session` ON `module_snapshots` (`sessionId`);--> statement-breakpoint
CREATE INDEX `idx_udslog_session` ON `uds_logs` (`sessionId`);