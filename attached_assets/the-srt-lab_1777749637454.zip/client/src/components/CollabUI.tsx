/**
 * CollabUI — presence bar and tool approval modal components
 * Shows who else is in the session and handles write-operation approval requests.
 */

import { useState } from "react";
import { Users, CheckCircle, XCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useCollab, type CollabUser, type ToolApprovalRequest } from "@/contexts/CollabContext";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// Presence avatar strip
export function PresenceBar({ className }: { className?: string }) {
  const { connected, presence } = useCollab();
  const [expanded, setExpanded] = useState(false);

  if (!connected || presence.length === 0) return null;

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className="flex items-center gap-1 cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <Users className="w-3.5 h-3.5 text-gray-400" />
        <div className="flex -space-x-1.5">
          {presence.slice(0, 5).map((user) => (
            <div
              key={user.sessionId}
              className="w-6 h-6 rounded-full border-2 border-black flex items-center justify-center text-xs font-bold"
              style={{ backgroundColor: user.color }}
              title={`${user.name} (${user.role})${user.tool ? ` — ${user.tool}` : ""}`}
            >
              {user.name.charAt(0).toUpperCase()}
            </div>
          ))}
          {presence.length > 5 && (
            <div className="w-6 h-6 rounded-full border-2 border-black bg-gray-700 flex items-center justify-center text-xs text-gray-300">
              +{presence.length - 5}
            </div>
          )}
        </div>
      </div>

      {expanded && (
        <div className="absolute top-full right-0 mt-1 bg-[#1a1a1a] border border-white/10 rounded shadow-xl z-50 min-w-48 p-2">
          <div className="text-xs text-gray-400 mb-2 px-1">Active in this session</div>
          {presence.map((user) => (
            <div key={user.sessionId} className="flex items-center gap-2 px-1 py-1 rounded hover:bg-white/5">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
                style={{ backgroundColor: user.color }}
              >
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-white truncate">{user.name}</div>
                {user.tool && (
                  <div className="text-xs text-gray-500 truncate">{user.tool}</div>
                )}
              </div>
              <Badge
                variant="outline"
                className={cn(
                  "text-xs h-4 px-1",
                  user.role === "owner" && "border-yellow-500/40 text-yellow-400",
                  user.role === "technician" && "border-blue-500/40 text-blue-400",
                  user.role === "viewer" && "border-gray-500/40 text-gray-400"
                )}
              >
                {user.role}
              </Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Tool approval request card
function ApprovalCard({ request }: { request: ToolApprovalRequest }) {
  const { respondApproval } = useCollab();
  const elapsed = Math.floor((Date.now() - request.timestamp) / 1000);

  return (
    <div className="border border-yellow-500/30 bg-yellow-950/20 rounded p-3 flex flex-col gap-2">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-sm font-semibold text-white">{request.tool}</div>
          <div className="text-xs text-gray-400">{request.description}</div>
          <div className="text-xs text-gray-500 mt-1">
            Requested by <span className="text-yellow-400">{request.requesterName}</span> · {elapsed}s ago
          </div>
        </div>
        <Clock className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
      </div>
      <div className="flex gap-2">
        <Button
          size="sm"
          className="flex-1 h-7 text-xs bg-green-600 hover:bg-green-700"
          onClick={() => {
            respondApproval(request.id, true);
            toast.success(`Approved: ${request.tool}`);
          }}
        >
          <CheckCircle className="w-3 h-3 mr-1" /> Approve
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="flex-1 h-7 text-xs border-red-500/40 text-red-400 hover:bg-red-950/30"
          onClick={() => {
            respondApproval(request.id, false);
            toast.error(`Rejected: ${request.tool}`);
          }}
        >
          <XCircle className="w-3 h-3 mr-1" /> Reject
        </Button>
      </div>
    </div>
  );
}

// Modal that shows pending approval requests
export function ToolApprovalModal() {
  const { pendingApprovals } = useCollab();
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const visible = pendingApprovals.filter((a) => !dismissed.has(a.id));
  if (visible.length === 0) return null;

  return (
    <Dialog open>
      <DialogContent className="bg-[#1a1a1a] border-yellow-500/30 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-yellow-400 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Tool Approval Required
          </DialogTitle>
          <DialogDescription className="text-gray-400 text-xs">
            A technician is requesting permission to perform a write operation.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-2 mt-2">
          {visible.map((req) => (
            <ApprovalCard key={req.id} request={req} />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
