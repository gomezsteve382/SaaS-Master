/**
 * ModulePickerDialog — shown when a session has snapshots for multiple modules.
 * Lets the technician select which module pair to send to Snapshot Comparison.
 */

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { GitCompare, Cpu, Clock, CheckCircle2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export type ModulePairEntry = {
  moduleAddr: number;
  moduleName: string | null;
  beforeId: number | null;
  afterId: number | null;
  beforeCapturedAt: Date | string | null;
  afterCapturedAt: Date | string | null;
  hasPair: boolean;
};

function formatAddr(addr: number) {
  return `0x${addr.toString(16).toUpperCase().padStart(3, "0")}`;
}

function formatTime(d: Date | string | null) {
  if (!d) return "—";
  return new Date(d).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

// Known FCA module names by CAN address
const KNOWN_MODULES: Record<number, string> = {
  0x7e0: "ECM",
  0x7e1: "TCM",
  0x7e2: "ABS",
  0x7e3: "EPS",
  0x7e4: "BCM",
  0x7e5: "HVAC",
  0x7e6: "IPC",
  0x7e7: "RFH",
  0x7e8: "SCCM",
  0x760: "GWAY",
  0x7d0: "SGW",
  0x7c0: "CGW",
  0x7a0: "ADAS-GW",
  0x733: "RFHUB",
  0x745: "SKIM",
};

function getModuleLabel(addr: number, name: string | null): string {
  return name || KNOWN_MODULES[addr] || `Module ${formatAddr(addr)}`;
}

interface ModulePickerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sessionId: number;
  pairs: ModulePairEntry[];
  isLoading: boolean;
  onSelect: (beforeId: number, afterId: number) => void;
}

export default function ModulePickerDialog({
  open,
  onOpenChange,
  sessionId,
  pairs,
  isLoading,
  onSelect,
}: ModulePickerDialogProps) {
  const completePairs = pairs.filter((p) => p.hasPair);
  const incompletePairs = pairs.filter((p) => !p.hasPair);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-zinc-900 border-zinc-700 text-white max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white font-mono tracking-wide">
            <GitCompare className="w-4 h-4 text-indigo-400" />
            Select Module to Compare
          </DialogTitle>
          <DialogDescription className="text-zinc-400 text-sm">
            Session #{sessionId} has snapshots for {pairs.length} module{pairs.length !== 1 ? "s" : ""}.
            Choose which module pair to diff.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="py-8 text-center text-zinc-500 text-sm font-mono animate-pulse">
            Loading module pairs...
          </div>
        ) : pairs.length === 0 ? (
          <div className="py-8 text-center text-zinc-600 text-sm">
            No snapshots found for this session.
          </div>
        ) : (
          <div className="flex flex-col gap-2 mt-1 max-h-[400px] overflow-y-auto pr-1">
            {/* Complete pairs first */}
            {completePairs.length > 0 && (
              <>
                <div className="text-xs text-zinc-500 font-mono uppercase tracking-wider px-1 mb-1">
                  Complete Pairs ({completePairs.length})
                </div>
                {completePairs.map((pair) => (
                  <ModulePairRow
                    key={pair.moduleAddr}
                    pair={pair}
                    onSelect={onSelect}
                    onClose={() => onOpenChange(false)}
                  />
                ))}
              </>
            )}

            {/* Incomplete entries */}
            {incompletePairs.length > 0 && (
              <>
                <div className="text-xs text-zinc-500 font-mono uppercase tracking-wider px-1 mt-2 mb-1">
                  Partial Snapshots ({incompletePairs.length})
                </div>
                {incompletePairs.map((pair) => (
                  <ModulePairRow
                    key={pair.moduleAddr}
                    pair={pair}
                    onSelect={onSelect}
                    onClose={() => onOpenChange(false)}
                    incomplete
                  />
                ))}
              </>
            )}
          </div>
        )}

        <div className="flex justify-end pt-2 border-t border-zinc-800">
          <Button
            variant="ghost"
            size="sm"
            className="text-zinc-400 hover:text-white"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ModulePairRow({
  pair,
  onSelect,
  onClose,
  incomplete,
}: {
  pair: ModulePairEntry;
  onSelect: (beforeId: number, afterId: number) => void;
  onClose: () => void;
  incomplete?: boolean;
}) {
  const label = getModuleLabel(pair.moduleAddr, pair.moduleName);
  const canCompare = pair.beforeId !== null && pair.afterId !== null;

  const handleClick = () => {
    if (!canCompare) return;
    onSelect(pair.beforeId!, pair.afterId!);
    onClose();
  };

  return (
    <div
      className={cn(
        "border rounded-lg p-3 transition-all",
        canCompare
          ? "border-indigo-500/30 bg-indigo-950/10 hover:bg-indigo-950/20 hover:border-indigo-400/50 cursor-pointer"
          : "border-zinc-700/50 bg-zinc-800/20 opacity-60 cursor-not-allowed"
      )}
      onClick={handleClick}
    >
      <div className="flex items-center justify-between gap-3">
        {/* Module info */}
        <div className="flex items-center gap-2.5 min-w-0">
          <Cpu className={cn("w-4 h-4 shrink-0", canCompare ? "text-indigo-400" : "text-zinc-500")} />
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-white font-mono text-sm font-semibold">{label}</span>
              <span className="text-zinc-500 font-mono text-xs">{formatAddr(pair.moduleAddr)}</span>
            </div>
            <div className="flex items-center gap-3 mt-0.5">
              {pair.beforeId ? (
                <span className="text-xs text-yellow-400 flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" />
                  Before {formatTime(pair.beforeCapturedAt)}
                </span>
              ) : (
                <span className="text-xs text-zinc-600 italic">No before snapshot</span>
              )}
              {pair.afterId ? (
                <span className="text-xs text-green-400 flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" />
                  After {formatTime(pair.afterCapturedAt)}
                </span>
              ) : (
                <span className="text-xs text-zinc-600 italic">No after snapshot</span>
              )}
            </div>
          </div>
        </div>

        {/* Status + action */}
        <div className="flex items-center gap-2 shrink-0">
          {canCompare ? (
            <>
              <Badge variant="outline" className="text-[10px] border-green-500/40 text-green-400 px-1.5">
                <CheckCircle2 className="w-2.5 h-2.5 mr-1" />PAIR
              </Badge>
              <Button
                size="sm"
                className="h-7 px-3 text-xs bg-indigo-600 hover:bg-indigo-500 text-white"
                onClick={(e) => { e.stopPropagation(); handleClick(); }}
              >
                <GitCompare className="w-3 h-3 mr-1" />
                Compare
              </Button>
            </>
          ) : (
            <Badge variant="outline" className="text-[10px] border-yellow-500/40 text-yellow-500 px-1.5">
              <AlertTriangle className="w-2.5 h-2.5 mr-1" />PARTIAL
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
