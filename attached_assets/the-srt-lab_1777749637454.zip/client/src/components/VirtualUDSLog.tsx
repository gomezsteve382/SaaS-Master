/**
 * VirtualUDSLog — virtualized UDS traffic log component
 * Adapted from Claude Code's VirtualMessageList.tsx using @tanstack/react-virtual.
 * Handles thousands of UDS frames without DOM bloat — renders only visible rows.
 */

import { useRef, useEffect, useCallback } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { cn } from "@/lib/utils";

export interface UDSLogEntry {
  id: string;
  timestamp: string;
  direction: "TX" | "RX" | "INFO" | "ERROR" | "WARN";
  module?: string;
  raw: string;
  decoded?: string;
}

interface VirtualUDSLogProps {
  entries: UDSLogEntry[];
  isStreaming?: boolean;
  className?: string;
  maxHeight?: string;
}

const DIRECTION_STYLES: Record<UDSLogEntry["direction"], string> = {
  TX: "text-blue-400",
  RX: "text-green-400",
  INFO: "text-gray-400",
  ERROR: "text-red-400",
  WARN: "text-yellow-400",
};

const DIRECTION_PREFIX: Record<UDSLogEntry["direction"], string> = {
  TX: "→",
  RX: "←",
  INFO: "·",
  ERROR: "✗",
  WARN: "⚠",
};

function estimateEntryHeight(entry: UDSLogEntry): number {
  if (entry.decoded) return 52;
  return 36;
}

export function VirtualUDSLog({
  entries,
  isStreaming = false,
  className,
  maxHeight = "400px",
}: VirtualUDSLogProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const isAtBottomRef = useRef(true);

  const virtualizer = useVirtualizer({
    count: entries.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: (index) => estimateEntryHeight(entries[index]),
    overscan: 8,
  });

  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current;
    if (el) {
      if (isStreaming) {
        el.scrollTop = el.scrollHeight;
      } else {
        el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
      }
    }
  }, [isStreaming]);

  // Track scroll position to decide whether to auto-scroll
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const handleScroll = () => {
      const threshold = 60;
      isAtBottomRef.current =
        el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
    };
    el.addEventListener("scroll", handleScroll, { passive: true });
    return () => el.removeEventListener("scroll", handleScroll);
  }, []);

  // Auto-scroll when new entries arrive if user is at bottom
  useEffect(() => {
    if (isAtBottomRef.current && entries.length > 0) {
      scrollToBottom();
    }
  }, [entries.length, scrollToBottom]);

  if (entries.length === 0) {
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-black/40 border border-white/10 rounded font-mono text-xs text-gray-500",
          className
        )}
        style={{ height: maxHeight }}
      >
        No UDS traffic yet — connect adapter and start operation
      </div>
    );
  }

  return (
    <div
      ref={scrollRef}
      className={cn(
        "overflow-auto bg-black/60 border border-white/10 rounded font-mono text-xs",
        className
      )}
      style={{ height: maxHeight }}
    >
      <div
        style={{
          height: `${virtualizer.getTotalSize()}px`,
          width: "100%",
          position: "relative",
        }}
      >
        {virtualizer.getVirtualItems().map((virtualItem) => {
          const entry = entries[virtualItem.index];
          return (
            <div
              key={entry.id}
              data-index={virtualItem.index}
              ref={virtualizer.measureElement}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                transform: `translateY(${virtualItem.start}px)`,
              }}
              className="px-3 py-1 border-b border-white/5 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-start gap-2">
                <span className="text-gray-600 shrink-0 w-20 text-right select-none">
                  {entry.timestamp}
                </span>
                <span
                  className={cn(
                    "shrink-0 w-4 text-center font-bold",
                    DIRECTION_STYLES[entry.direction]
                  )}
                >
                  {DIRECTION_PREFIX[entry.direction]}
                </span>
                {entry.module && (
                  <span className="shrink-0 text-purple-400 w-16 truncate">
                    {entry.module}
                  </span>
                )}
                <span className={cn("flex-1 break-all", DIRECTION_STYLES[entry.direction])}>
                  {entry.raw}
                </span>
              </div>
              {entry.decoded && (
                <div className="ml-28 text-gray-500 text-xs mt-0.5">
                  {entry.decoded}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
