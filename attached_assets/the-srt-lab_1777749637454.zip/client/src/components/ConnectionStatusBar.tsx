export default function ConnectionStatusBar() {
  return <div className="h-8 bg-gray-200" />;
}
