/**
 * EEPROMDiffViewer — before/after EEPROM byte diff with hunk accept/reject
 * Adapted from Claude Code's DiffViewer.tsx using LCS algorithm.
 * Shows exactly which bytes changed after VIN write, BCM config change, or module clone.
 */

import { useState, useMemo, useCallback } from "react";
import { CheckSquare, X, RotateCcw, Columns, AlignJustify, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type DiffMode = "unified" | "side-by-side" | "hex";

interface ByteDiff {
  offset: number;
  oldVal: number;
  newVal: number;
}

interface Hunk {
  id: string;
  startOffset: number;
  endOffset: number;
  diffs: ByteDiff[];
  status: "pending" | "accepted" | "rejected";
}

interface EEPROMDiffViewerProps {
  oldData: Uint8Array;
  newData: Uint8Array;
  label?: string;
  onApply?: (patched: Uint8Array) => void;
  className?: string;
}

// Group consecutive byte changes into hunks (gap > 16 bytes = new hunk)
function buildHunks(diffs: ByteDiff[]): Hunk[] {
  if (diffs.length === 0) return [];
  const hunks: Hunk[] = [];
  let current: ByteDiff[] = [diffs[0]];

  for (let i = 1; i < diffs.length; i++) {
    if (diffs[i].offset - diffs[i - 1].offset <= 16) {
      current.push(diffs[i]);
    } else {
      hunks.push({
        id: `hunk-${current[0].offset}`,
        startOffset: current[0].offset,
        endOffset: current[current.length - 1].offset,
        diffs: current,
        status: "pending",
      });
      current = [diffs[i]];
    }
  }
  hunks.push({
    id: `hunk-${current[0].offset}`,
    startOffset: current[0].offset,
    endOffset: current[current.length - 1].offset,
    diffs: current,
    status: "pending",
  });
  return hunks;
}

// Compute byte-level diff between two EEPROM dumps
function computeByteDiff(oldData: Uint8Array, newData: Uint8Array): ByteDiff[] {
  const len = Math.min(oldData.length, newData.length);
  const diffs: ByteDiff[] = [];
  for (let i = 0; i < len; i++) {
    if (oldData[i] !== newData[i]) {
      diffs.push({ offset: i, oldVal: oldData[i], newVal: newData[i] });
    }
  }
  return diffs;
}

function toHex(val: number): string {
  return val.toString(16).toUpperCase().padStart(2, "0");
}

function toHexAddr(val: number): string {
  return val.toString(16).toUpperCase().padStart(6, "0");
}

export function EEPROMDiffViewer({
  oldData,
  newData,
  label = "EEPROM Diff",
  onApply,
  className,
}: EEPROMDiffViewerProps) {
  const [mode, setMode] = useState<DiffMode>("unified");
  const [hunks, setHunks] = useState<Hunk[]>(() => {
    const diffs = computeByteDiff(oldData, newData);
    return buildHunks(diffs);
  });

  // Recompute when data changes
  const allDiffs = useMemo(() => computeByteDiff(oldData, newData), [oldData, newData]);

  const acceptHunk = useCallback((id: string) => {
    setHunks((prev) =>
      prev.map((h) => (h.id === id ? { ...h, status: "accepted" } : h))
    );
  }, []);

  const rejectHunk = useCallback((id: string) => {
    setHunks((prev) =>
      prev.map((h) => (h.id === id ? { ...h, status: "rejected" } : h))
    );
  }, []);

  const resetHunk = useCallback((id: string) => {
    setHunks((prev) =>
      prev.map((h) => (h.id === id ? { ...h, status: "pending" } : h))
    );
  }, []);

  const acceptAll = useCallback(() => {
    setHunks((prev) => prev.map((h) => ({ ...h, status: "accepted" })));
  }, []);

  const rejectAll = useCallback(() => {
    setHunks((prev) => prev.map((h) => ({ ...h, status: "rejected" })));
  }, []);

  const applyChanges = useCallback(() => {
    if (!onApply) return;
    const patched = new Uint8Array(oldData);
    for (const hunk of hunks) {
      if (hunk.status === "accepted") {
        for (const diff of hunk.diffs) {
          patched[diff.offset] = diff.newVal;
        }
      }
    }
    onApply(patched);
  }, [hunks, oldData, onApply]);

  const pendingCount = hunks.filter((h) => h.status === "pending").length;
  const acceptedCount = hunks.filter((h) => h.status === "accepted").length;
  const rejectedCount = hunks.filter((h) => h.status === "rejected").length;

  if (allDiffs.length === 0) {
    return (
      <div className={cn("p-4 bg-green-950/30 border border-green-500/30 rounded text-green-400 text-sm", className)}>
        ✓ No differences — EEPROM dumps are identical
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-white font-semibold text-sm">{label}</span>
          <Badge variant="outline" className="text-yellow-400 border-yellow-400/40 text-xs">
            {allDiffs.length} bytes changed
          </Badge>
          <Badge variant="outline" className="text-blue-400 border-blue-400/40 text-xs">
            {hunks.length} hunks
          </Badge>
        </div>
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            className={cn("h-7 px-2 text-xs", mode === "unified" && "bg-white/10")}
            onClick={() => setMode("unified")}
          >
            <AlignJustify className="w-3 h-3 mr-1" /> Unified
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={cn("h-7 px-2 text-xs", mode === "side-by-side" && "bg-white/10")}
            onClick={() => setMode("side-by-side")}
          >
            <Columns className="w-3 h-3 mr-1" /> Side-by-Side
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={cn("h-7 px-2 text-xs", mode === "hex" && "bg-white/10")}
            onClick={() => setMode("hex")}
          >
            <Layers className="w-3 h-3 mr-1" /> Hex
          </Button>
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-gray-400">{pendingCount} pending</span>
        <span className="text-green-400">{acceptedCount} accepted</span>
        <span className="text-red-400">{rejectedCount} rejected</span>
        <div className="ml-auto flex gap-1">
          <Button size="sm" variant="outline" className="h-6 px-2 text-xs border-green-500/40 text-green-400 hover:bg-green-950/30" onClick={acceptAll}>
            Accept All
          </Button>
          <Button size="sm" variant="outline" className="h-6 px-2 text-xs border-red-500/40 text-red-400 hover:bg-red-950/30" onClick={rejectAll}>
            Reject All
          </Button>
          {onApply && (
            <Button
              size="sm"
              className="h-6 px-2 text-xs bg-srt-red hover:bg-srt-red/80"
              onClick={applyChanges}
              disabled={acceptedCount === 0}
            >
              Apply {acceptedCount} Hunks
            </Button>
          )}
        </div>
      </div>

      {/* Hunks */}
      <div className="flex flex-col gap-2 max-h-[500px] overflow-y-auto">
        {hunks.map((hunk) => (
          <div
            key={hunk.id}
            className={cn(
              "border rounded overflow-hidden",
              hunk.status === "accepted" && "border-green-500/40 bg-green-950/10",
              hunk.status === "rejected" && "border-red-500/40 bg-red-950/10 opacity-50",
              hunk.status === "pending" && "border-white/10 bg-black/30"
            )}
          >
            {/* Hunk header */}
            <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/10">
              <span className="font-mono text-xs text-gray-400">
                @@ 0x{toHexAddr(hunk.startOffset)} – 0x{toHexAddr(hunk.endOffset)} ({hunk.diffs.length} bytes)
              </span>
              <div className="flex gap-1">
                {hunk.status !== "pending" ? (
                  <Button size="sm" variant="ghost" className="h-6 px-2 text-xs" onClick={() => resetHunk(hunk.id)}>
                    <RotateCcw className="w-3 h-3 mr-1" /> Reset
                  </Button>
                ) : (
                  <>
                    <Button size="sm" variant="ghost" className="h-6 px-2 text-xs text-green-400 hover:bg-green-950/30" onClick={() => acceptHunk(hunk.id)}>
                      <CheckSquare className="w-3 h-3 mr-1" /> Accept
                    </Button>
                    <Button size="sm" variant="ghost" className="h-6 px-2 text-xs text-red-400 hover:bg-red-950/30" onClick={() => rejectHunk(hunk.id)}>
                      <X className="w-3 h-3 mr-1" /> Reject
                    </Button>
                  </>
                )}
              </div>
            </div>

            {/* Diff content */}
            <div className="font-mono text-xs p-2">
              {mode === "unified" && (
                <div className="flex flex-col gap-0.5">
                  {hunk.diffs.map((d) => (
                    <div key={d.offset}>
                      <div className="flex gap-2 text-red-400 bg-red-950/20 px-1 rounded-sm">
                        <span className="text-gray-600 w-16">0x{toHexAddr(d.offset)}</span>
                        <span>- {toHex(d.oldVal)}</span>
                        <span className="text-gray-600">({d.oldVal})</span>
                      </div>
                      <div className="flex gap-2 text-green-400 bg-green-950/20 px-1 rounded-sm">
                        <span className="text-gray-600 w-16">0x{toHexAddr(d.offset)}</span>
                        <span>+ {toHex(d.newVal)}</span>
                        <span className="text-gray-600">({d.newVal})</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {mode === "side-by-side" && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="text-gray-500 mb-1">Before</div>
                    {hunk.diffs.map((d) => (
                      <div key={d.offset} className="flex gap-2 text-red-400 bg-red-950/20 px-1 rounded-sm mb-0.5">
                        <span className="text-gray-600 w-16">0x{toHexAddr(d.offset)}</span>
                        <span>{toHex(d.oldVal)}</span>
                      </div>
                    ))}
                  </div>
                  <div>
                    <div className="text-gray-500 mb-1">After</div>
                    {hunk.diffs.map((d) => (
                      <div key={d.offset} className="flex gap-2 text-green-400 bg-green-950/20 px-1 rounded-sm mb-0.5">
                        <span className="text-gray-600 w-16">0x{toHexAddr(d.offset)}</span>
                        <span>{toHex(d.newVal)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {mode === "hex" && (
                <div className="flex flex-col gap-0.5">
                  {hunk.diffs.map((d) => (
                    <div key={d.offset} className="flex gap-3 items-center">
                      <span className="text-gray-500 w-16">0x{toHexAddr(d.offset)}</span>
                      <span className="text-red-400 w-8">{toHex(d.oldVal)}</span>
                      <span className="text-gray-600">→</span>
                      <span className="text-green-400 w-8">{toHex(d.newVal)}</span>
                      <span className="text-gray-600 text-xs">
                        ({d.oldVal} → {d.newVal})
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
