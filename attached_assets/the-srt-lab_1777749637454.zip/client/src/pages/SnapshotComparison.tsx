/**
 * SnapshotComparison — Compare two module snapshots from Session History
 * Shows field-level metadata diff, change statistics, and export options.
 * Snapshots are captured before/after UDS operations (VIN write, BCM config, cloning, etc.)
 */

import { useState, useMemo, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import {
  ArrowLeft, GitCompare, Search, Filter, Download, RefreshCw,
  ChevronDown, ChevronUp, CheckCircle2, XCircle, Minus, AlertTriangle,
  Clock, Cpu, Hash, Tag, Layers, FileText, BarChart3, Copy
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

// ─── Known FCA EEPROM field labels ───────────────────────────────────────────
const FIELD_LABELS: Record<string, { label: string; icon: React.ReactNode; critical: boolean }> = {
  vin: { label: "VIN", icon: <Hash className="w-3 h-3" />, critical: true },
  partNumber: { label: "Part Number", icon: <Tag className="w-3 h-3" />, critical: true },
  serialNumber: { label: "Serial Number", icon: <Layers className="w-3 h-3" />, critical: false },
  supplierCode: { label: "Supplier Code", icon: <FileText className="w-3 h-3" />, critical: false },
  hwVersion: { label: "HW Version", icon: <Cpu className="w-3 h-3" />, critical: false },
  swVersion: { label: "SW Version", icon: <Cpu className="w-3 h-3" />, critical: false },
  dtcCount: { label: "DTC Count", icon: <AlertTriangle className="w-3 h-3" />, critical: false },
  moduleName: { label: "Module Name", icon: <Cpu className="w-3 h-3" />, critical: false },
};

type SnapshotRow = {
  id: number;
  sessionId: number;
  moduleAddr: number;
  moduleName: string | null;
  snapshotType: "before" | "after";
  vin: string | null;
  partNumber: string | null;
  serialNumber: string | null;
  supplierCode: string | null;
  hwVersion: string | null;
  swVersion: string | null;
  dtcCount: number | null;
  capturedAt: Date | string;
};

function formatAddr(addr: number) {
  return `0x${addr.toString(16).toUpperCase().padStart(3, "0")}`;
}

function formatDate(d: Date | string) {
  return new Date(d).toLocaleString();
}

function SnapshotCard({
  snapshot,
  label,
  selected,
  onClick,
}: {
  snapshot: SnapshotRow;
  label: "A" | "B";
  selected: boolean;
  onClick: () => void;
}) {
  const color = label === "A" ? "border-blue-500/60 bg-blue-950/10" : "border-orange-500/60 bg-orange-950/10";
  const badge = label === "A" ? "bg-blue-600 text-white" : "bg-orange-600 text-white";
  const typeBadge = snapshot.snapshotType === "before"
    ? "border-yellow-500/40 text-yellow-400"
    : "border-green-500/40 text-green-400";

  return (
    <div
      className={cn(
        "border rounded-lg p-3 cursor-pointer transition-all hover:brightness-110",
        selected ? color : "border-white/10 bg-black/20 hover:border-white/20"
      )}
      onClick={onClick}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <span className={cn("text-xs font-bold px-1.5 py-0.5 rounded", badge)}>
            {label}
          </span>
          <span className="text-white font-mono text-sm font-semibold">
            {formatAddr(snapshot.moduleAddr)}
          </span>
          {snapshot.moduleName && (
            <span className="text-gray-400 text-xs">{snapshot.moduleName}</span>
          )}
        </div>
        <Badge variant="outline" className={cn("text-xs", typeBadge)}>
          {snapshot.snapshotType}
        </Badge>
      </div>
      {snapshot.vin && (
        <div className="font-mono text-xs text-srt-red mb-1">{snapshot.vin}</div>
      )}
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <Clock className="w-3 h-3" />
        <span>{formatDate(snapshot.capturedAt)}</span>
        <span className="text-gray-700">·</span>
        <span>Session #{snapshot.sessionId}</span>
      </div>
      {snapshot.partNumber && (
        <div className="text-xs text-gray-500 mt-1 font-mono">PN: {snapshot.partNumber}</div>
      )}
    </div>
  );
}

type DiffRow = {
  field: string;
  valueA: string | number | null;
  valueB: string | number | null;
  changed: boolean;
};

function DiffTable({ diffs }: { diffs: DiffRow[] }) {
  const [showUnchanged, setShowUnchanged] = useState(false);
  const visible = showUnchanged ? diffs : diffs.filter((d) => d.changed);

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-gray-500">
          {diffs.filter((d) => d.changed).length} changed · {diffs.filter((d) => !d.changed).length} unchanged
        </span>
        <Button
          size="sm"
          variant="ghost"
          className="h-6 px-2 text-xs text-gray-400 hover:text-white"
          onClick={() => setShowUnchanged((v) => !v)}
        >
          {showUnchanged ? <ChevronUp className="w-3 h-3 mr-1" /> : <ChevronDown className="w-3 h-3 mr-1" />}
          {showUnchanged ? "Hide unchanged" : "Show all fields"}
        </Button>
      </div>

      <div className="rounded-lg border border-white/10 overflow-hidden">
        {/* Header */}
        <div className="grid grid-cols-[1fr_1fr_1fr_auto] gap-0 bg-white/5 border-b border-white/10 text-xs text-gray-500 font-medium">
          <div className="px-3 py-2">Field</div>
          <div className="px-3 py-2 border-l border-white/10">Snapshot A (Before)</div>
          <div className="px-3 py-2 border-l border-white/10">Snapshot B (After)</div>
          <div className="px-3 py-2 border-l border-white/10 w-16 text-center">Status</div>
        </div>

        {visible.length === 0 && (
          <div className="px-3 py-6 text-center text-gray-600 text-sm">
            No changed fields to display
          </div>
        )}

        {visible.map((row, i) => {
          const meta = FIELD_LABELS[row.field];
          const isCritical = meta?.critical ?? false;
          return (
            <div
              key={row.field}
              className={cn(
                "grid grid-cols-[1fr_1fr_1fr_auto] gap-0 border-b border-white/5 last:border-0 text-sm transition-colors",
                row.changed
                  ? isCritical
                    ? "bg-red-950/20 hover:bg-red-950/30"
                    : "bg-yellow-950/10 hover:bg-yellow-950/20"
                  : "hover:bg-white/3"
              )}
            >
              {/* Field name */}
              <div className="px-3 py-2.5 flex items-center gap-1.5">
                <span className={cn("text-gray-400", isCritical && row.changed && "text-red-400")}>
                  {meta?.icon}
                </span>
                <span className={cn(
                  "font-medium",
                  row.changed ? (isCritical ? "text-red-300" : "text-yellow-300") : "text-gray-400"
                )}>
                  {meta?.label ?? row.field}
                </span>
                {isCritical && row.changed && (
                  <Badge variant="outline" className="text-[10px] px-1 py-0 border-red-500/40 text-red-400 ml-1">
                    CRITICAL
                  </Badge>
                )}
              </div>

              {/* Value A */}
              <div className={cn(
                "px-3 py-2.5 border-l border-white/10 font-mono text-xs flex items-center",
                row.changed ? "text-red-300 bg-red-950/10" : "text-gray-400"
              )}>
                {row.valueA !== null && row.valueA !== undefined ? (
                  <span>{String(row.valueA)}</span>
                ) : (
                  <span className="text-gray-700 italic">—</span>
                )}
              </div>

              {/* Value B */}
              <div className={cn(
                "px-3 py-2.5 border-l border-white/10 font-mono text-xs flex items-center",
                row.changed ? "text-green-300 bg-green-950/10" : "text-gray-400"
              )}>
                {row.valueB !== null && row.valueB !== undefined ? (
                  <span>{String(row.valueB)}</span>
                ) : (
                  <span className="text-gray-700 italic">—</span>
                )}
              </div>

              {/* Status icon */}
              <div className="px-3 py-2.5 border-l border-white/10 w-16 flex items-center justify-center">
                {row.changed ? (
                  <XCircle className="w-4 h-4 text-red-400" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <div className="bg-black/40 border border-white/10 rounded-lg px-4 py-3 flex flex-col gap-1">
      <span className="text-xs text-gray-500 uppercase tracking-wider">{label}</span>
      <span className={cn("text-2xl font-bold font-mono", color)}>{value}</span>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function SnapshotComparison() {
  const [, navigate] = useLocation();
  const [vinFilter, setVinFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "before" | "after">("all");

  // Parse ?a=ID&b=ID from URL for Quick Compare deep-link
  const urlParams = useMemo(() => {
    const params = new URLSearchParams(window.location.search);
    const a = params.get("a");
    const b = params.get("b");
    return {
      preA: a ? parseInt(a, 10) : null,
      preB: b ? parseInt(b, 10) : null,
    };
  }, []);

  const [selectedA, setSelectedA] = useState<number | null>(urlParams.preA);
  const [selectedB, setSelectedB] = useState<number | null>(urlParams.preB);
  const [compareEnabled, setCompareEnabled] = useState(
    urlParams.preA !== null && urlParams.preB !== null
  );
  const [autoCompareToast, setAutoCompareToast] = useState(false);

  // Show a toast once when auto-comparing from URL params
  useEffect(() => {
    if (urlParams.preA && urlParams.preB && !autoCompareToast) {
      setAutoCompareToast(true);
      toast.success(
        `Quick Compare loaded — Snapshot #${urlParams.preA} vs #${urlParams.preB}`,
        { description: "Before/after pair auto-selected from Session History" }
      );
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load all snapshots
  const { data: snapshots = [], isLoading, refetch } = trpc.sessions.listAllSnapshots.useQuery({
    vin: vinFilter.trim().length >= 3 ? vinFilter.trim() : undefined,
    limit: 200,
  });

  // Filtered list
  const filtered = useMemo(() => {
    return snapshots.filter((s) => {
      if (typeFilter !== "all" && s.snapshotType !== typeFilter) return false;
      return true;
    });
  }, [snapshots, typeFilter]);

  // Run comparison
  const { data: comparison, isLoading: comparing, error: compareError } = trpc.sessions.compareSnapshots.useQuery(
    { idA: selectedA!, idB: selectedB! },
    { enabled: compareEnabled && selectedA !== null && selectedB !== null }
  );

  const handleCompare = useCallback(() => {
    if (!selectedA || !selectedB) {
      toast.error("Select both Snapshot A and Snapshot B first");
      return;
    }
    if (selectedA === selectedB) {
      toast.error("Select two different snapshots");
      return;
    }
    setCompareEnabled(true);
  }, [selectedA, selectedB]);

  const handleReset = useCallback(() => {
    setSelectedA(null);
    setSelectedB(null);
    setCompareEnabled(false);
  }, []);

  const handleExport = useCallback(() => {
    if (!comparison) return;
    const lines: string[] = [
      "# SRT Lab — Snapshot Comparison Report",
      `Generated: ${new Date().toISOString()}`,
      "",
      `## Snapshot A`,
      `  ID: ${comparison.snapshotA.id}`,
      `  Module: ${formatAddr(comparison.snapshotA.moduleAddr)} ${comparison.snapshotA.moduleName ?? ""}`,
      `  Type: ${comparison.snapshotA.snapshotType}`,
      `  VIN: ${comparison.snapshotA.vin ?? "—"}`,
      `  Captured: ${formatDate(comparison.snapshotA.capturedAt)}`,
      `  Session: #${comparison.snapshotA.sessionId}`,
      "",
      `## Snapshot B`,
      `  ID: ${comparison.snapshotB.id}`,
      `  Module: ${formatAddr(comparison.snapshotB.moduleAddr)} ${comparison.snapshotB.moduleName ?? ""}`,
      `  Type: ${comparison.snapshotB.snapshotType}`,
      `  VIN: ${comparison.snapshotB.vin ?? "—"}`,
      `  Captured: ${formatDate(comparison.snapshotB.capturedAt)}`,
      `  Session: #${comparison.snapshotB.sessionId}`,
      "",
      `## Diff Summary`,
      `  Changed fields: ${comparison.changedCount}`,
      `  Total fields: ${comparison.diffs.length}`,
      "",
      "## Field Differences",
    ];
    for (const d of comparison.diffs) {
      const meta = FIELD_LABELS[d.field];
      const label = meta?.label ?? d.field;
      const status = d.changed ? "CHANGED" : "SAME";
      lines.push(`  [${status}] ${label}: "${d.valueA ?? "—"}" → "${d.valueB ?? "—"}"`);
    }
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `snapshot-diff-${selectedA}-vs-${selectedB}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report exported");
  }, [comparison, selectedA, selectedB]);

  const handleCopyDiff = useCallback(() => {
    if (!comparison) return;
    const changed = comparison.diffs.filter((d) => d.changed);
    const text = changed.map((d) => {
      const meta = FIELD_LABELS[d.field];
      return `${meta?.label ?? d.field}: ${d.valueA ?? "—"} → ${d.valueB ?? "—"}`;
    }).join("\n");
    navigator.clipboard.writeText(text);
    toast.success("Diff copied to clipboard");
  }, [comparison]);

  const snapshotA = selectedA ? snapshots.find((s) => s.id === selectedA) : null;
  const snapshotB = selectedB ? snapshots.find((s) => s.id === selectedB) : null;

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <Button
          variant="ghost"
          size="sm"
          className="text-gray-400 hover:text-white"
          onClick={() => navigate("/sessions")}
        >
          <ArrowLeft className="w-4 h-4 mr-1" /> Back
        </Button>
        <Separator orientation="vertical" className="h-5 bg-white/20" />
        <GitCompare className="w-5 h-5 text-srt-red" />
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">Snapshot Comparison</h1>
          <p className="text-xs text-gray-500">Select two module snapshots to compare field-level changes</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Badge variant="outline" className="border-srt-red/40 text-srt-red text-xs font-mono">
            JAILBREAK ACTIVE
          </Badge>
        </div>
      </div>

      {/* Quick Compare banner — shown when navigated from Session History */}
      {urlParams.preA && urlParams.preB && (
        <div className="mb-4 flex items-center gap-3 bg-indigo-950/30 border border-indigo-500/30 rounded-lg px-4 py-2.5">
          <GitCompare className="w-4 h-4 text-indigo-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <span className="text-indigo-300 text-sm font-semibold">Quick Compare</span>
            <span className="text-indigo-400/70 text-xs ml-2">
              Auto-loaded from Session History — Snapshot #{urlParams.preA} vs #{urlParams.preB}
            </span>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="h-6 px-2 text-xs text-indigo-400 hover:text-indigo-200"
            onClick={() => {
              setSelectedA(null);
              setSelectedB(null);
              setCompareEnabled(false);
              // Clear URL params without navigation
              window.history.replaceState({}, "", window.location.pathname);
            }}
          >
            Clear
          </Button>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_1.6fr] gap-6">
        {/* LEFT: Snapshot Picker */}
        <div className="flex flex-col gap-4">
          {/* Filters */}
          <div className="bg-black/40 border border-white/10 rounded-xl p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 mb-1">
              <Filter className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-semibold text-white">Filter Snapshots</span>
              <Button
                size="sm"
                variant="ghost"
                className="ml-auto h-7 px-2 text-xs text-gray-400"
                onClick={() => refetch()}
              >
                <RefreshCw className="w-3 h-3 mr-1" /> Refresh
              </Button>
            </div>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                <Input
                  placeholder="Filter by VIN..."
                  value={vinFilter}
                  onChange={(e) => setVinFilter(e.target.value)}
                  className="pl-8 h-8 text-xs bg-black/30 border-white/10 font-mono"
                />
              </div>
              <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as typeof typeFilter)}>
                <SelectTrigger className="w-28 h-8 text-xs bg-black/30 border-white/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="before">Before</SelectItem>
                  <SelectItem value="after">After</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-blue-950/20 border border-blue-500/20 rounded-lg px-4 py-3 text-xs text-blue-300">
            <strong>Instructions:</strong> Click a snapshot to set it as <strong>A (before)</strong>, then click another to set it as <strong>B (after)</strong>. Then click Compare.
          </div>

          {/* Snapshot list */}
          <div className="flex flex-col gap-2 max-h-[520px] overflow-y-auto pr-1">
            {isLoading && (
              <div className="text-center py-8 text-gray-500 text-sm">Loading snapshots...</div>
            )}
            {!isLoading && filtered.length === 0 && (
              <div className="text-center py-8 text-gray-600 text-sm">
                No snapshots found. Snapshots are captured during VIN write, BCM config, module cloning, and gateway cloning operations.
              </div>
            )}
            {filtered.map((snap) => {
              const isA = snap.id === selectedA;
              const isB = snap.id === selectedB;
              return (
                <div
                  key={snap.id}
                  className={cn(
                    "border rounded-lg p-3 cursor-pointer transition-all",
                    isA && "border-blue-500/60 bg-blue-950/15 ring-1 ring-blue-500/30",
                    isB && "border-orange-500/60 bg-orange-950/15 ring-1 ring-orange-500/30",
                    !isA && !isB && "border-white/10 bg-black/20 hover:border-white/20 hover:bg-black/30"
                  )}
                  onClick={() => {
                    if (!selectedA || isA) {
                      setSelectedA(isA ? null : snap.id);
                      if (compareEnabled) setCompareEnabled(false);
                    } else if (!selectedB || isB) {
                      setSelectedB(isB ? null : snap.id);
                      if (compareEnabled) setCompareEnabled(false);
                    } else {
                      // Replace B
                      setSelectedB(snap.id);
                      if (compareEnabled) setCompareEnabled(false);
                    }
                  }}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2">
                      {isA && (
                        <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-blue-600 text-white">A</span>
                      )}
                      {isB && (
                        <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-orange-600 text-white">B</span>
                      )}
                      {!isA && !isB && (
                        <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-white/10 text-gray-500">#{snap.id}</span>
                      )}
                      <span className="text-white font-mono text-sm font-semibold">
                        {formatAddr(snap.moduleAddr)}
                      </span>
                      {snap.moduleName && (
                        <span className="text-gray-400 text-xs">{snap.moduleName}</span>
                      )}
                    </div>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-xs",
                        snap.snapshotType === "before"
                          ? "border-yellow-500/40 text-yellow-400"
                          : "border-green-500/40 text-green-400"
                      )}
                    >
                      {snap.snapshotType}
                    </Badge>
                  </div>
                  {snap.vin && (
                    <div className="font-mono text-xs text-srt-red mb-1">{snap.vin}</div>
                  )}
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <Clock className="w-3 h-3" />
                    <span>{formatDate(snap.capturedAt)}</span>
                    <span>· Session #{snap.sessionId}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action buttons */}
          <div className="flex gap-2 mt-1">
            <Button
              className="flex-1 bg-srt-red hover:bg-srt-red/80 text-white font-semibold"
              disabled={!selectedA || !selectedB || selectedA === selectedB}
              onClick={handleCompare}
            >
              <GitCompare className="w-4 h-4 mr-2" />
              Compare Snapshots
            </Button>
            <Button
              variant="outline"
              className="border-white/20 text-gray-400 hover:text-white"
              onClick={handleReset}
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* RIGHT: Comparison Results */}
        <div className="flex flex-col gap-4">
          {/* Selected snapshot summary */}
          {(snapshotA || snapshotB) && (
            <div className="grid grid-cols-2 gap-3">
              {snapshotA ? (
                <SnapshotCard snapshot={snapshotA} label="A" selected onClick={() => {}} />
              ) : (
                <div className="border border-dashed border-blue-500/30 rounded-lg p-4 flex items-center justify-center text-blue-500/50 text-sm">
                  Select Snapshot A
                </div>
              )}
              {snapshotB ? (
                <SnapshotCard snapshot={snapshotB} label="B" selected onClick={() => {}} />
              ) : (
                <div className="border border-dashed border-orange-500/30 rounded-lg p-4 flex items-center justify-center text-orange-500/50 text-sm">
                  Select Snapshot B
                </div>
              )}
            </div>
          )}

          {/* Empty state */}
          {!compareEnabled && !snapshotA && !snapshotB && (
            <div className="bg-black/40 border border-white/10 rounded-xl p-12 flex flex-col items-center gap-4 text-center">
              <GitCompare className="w-12 h-12 text-gray-700" />
              <div>
                <p className="text-gray-400 font-semibold">No comparison active</p>
                <p className="text-gray-600 text-sm mt-1">
                  Select two snapshots from the list on the left, then click Compare.
                </p>
              </div>
            </div>
          )}

          {/* Loading comparison */}
          {comparing && (
            <div className="bg-black/40 border border-white/10 rounded-xl p-8 flex items-center justify-center gap-3 text-gray-400">
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Running comparison...</span>
            </div>
          )}

          {/* Error */}
          {compareError && (
            <div className="bg-red-950/20 border border-red-500/30 rounded-xl p-4 text-red-400 text-sm">
              {compareError.message}
            </div>
          )}

          {/* Results */}
          {comparison && !comparing && (
            <div className="flex flex-col gap-4">
              {/* Stats row */}
              <div className="grid grid-cols-4 gap-3">
                <StatCard
                  label="Changed"
                  value={comparison.changedCount}
                  color={comparison.changedCount > 0 ? "text-red-400" : "text-green-400"}
                />
                <StatCard
                  label="Unchanged"
                  value={comparison.diffs.length - comparison.changedCount}
                  color="text-green-400"
                />
                <StatCard
                  label="Total Fields"
                  value={comparison.diffs.length}
                  color="text-gray-300"
                />
                <StatCard
                  label="Change Rate"
                  value={`${Math.round((comparison.changedCount / comparison.diffs.length) * 100)}%`}
                  color={comparison.changedCount > 0 ? "text-yellow-400" : "text-green-400"}
                />
              </div>

              {/* Critical changes alert */}
              {comparison.diffs.some((d) => d.changed && FIELD_LABELS[d.field]?.critical) && (
                <div className="bg-red-950/30 border border-red-500/40 rounded-lg px-4 py-3 flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <div className="text-sm">
                    <span className="text-red-300 font-semibold">Critical fields changed</span>
                    <span className="text-red-400/70 ml-2">
                      VIN or Part Number differs between snapshots — verify intentional change
                    </span>
                  </div>
                </div>
              )}

              {/* No changes */}
              {comparison.changedCount === 0 && (
                <div className="bg-green-950/20 border border-green-500/30 rounded-lg px-4 py-3 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                  <span className="text-green-300 text-sm font-semibold">
                    Snapshots are identical — no field changes detected
                  </span>
                </div>
              )}

              {/* Diff table */}
              <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-semibold text-white">Field-Level Diff</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-xs text-gray-400 hover:text-white"
                      onClick={handleCopyDiff}
                    >
                      <Copy className="w-3 h-3 mr-1" /> Copy
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-xs text-gray-400 hover:text-white"
                      onClick={handleExport}
                    >
                      <Download className="w-3 h-3 mr-1" /> Export
                    </Button>
                  </div>
                </div>
                <DiffTable diffs={comparison.diffs} />
              </div>

              {/* Module address match warning */}
              {comparison.snapshotA.moduleAddr !== comparison.snapshotB.moduleAddr && (
                <div className="bg-yellow-950/20 border border-yellow-500/30 rounded-lg px-4 py-3 flex items-center gap-3">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <span className="text-yellow-300 text-xs">
                    Warning: Snapshots are from different module addresses (
                    {formatAddr(comparison.snapshotA.moduleAddr)} vs {formatAddr(comparison.snapshotB.moduleAddr)}).
                    Cross-module comparison may not be meaningful.
                  </span>
                </div>
              )}

              {/* Session context */}
              <div className="bg-black/30 border border-white/10 rounded-lg px-4 py-3">
                <div className="text-xs text-gray-500 mb-2 font-semibold uppercase tracking-wider">Session Context</div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-gray-600">Snapshot A session:</span>
                    <span className="text-gray-300 ml-2 font-mono">#{comparison.snapshotA.sessionId}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Snapshot B session:</span>
                    <span className="text-gray-300 ml-2 font-mono">#{comparison.snapshotB.sessionId}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">A captured:</span>
                    <span className="text-gray-300 ml-2">{formatDate(comparison.snapshotA.capturedAt)}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">B captured:</span>
                    <span className="text-gray-300 ml-2">{formatDate(comparison.snapshotB.capturedAt)}</span>
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 px-3 text-xs border-white/20 text-gray-400 hover:text-white"
                    onClick={() => navigate(`/sessions`)}
                  >
                    <FileText className="w-3 h-3 mr-1" /> View Session History
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
