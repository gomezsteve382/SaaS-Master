/**
 * Diagnostic Assistant — AI-powered FCA/Stellantis diagnostic chat
 * Adapted from Claude Code's chat UI with tool-use approval workflow.
 * Uses the real LLM with access to DTC database, BCM params, and AlphaOBD tables.
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Bot, User, Wrench, ChevronDown, ChevronRight, Zap, AlertTriangle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Streamdown } from "streamdown";

interface ToolCall {
  name: string;
  result: string;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  toolCalls?: ToolCall[];
  timestamp: number;
}

const QUICK_PROMPTS = [
  "What does P0300 mean on a Hellcat?",
  "How do I virginize an RFHUB?",
  "Explain security access algorithm CDA6 L4",
  "What BCM parameters control the SRT launch control?",
  "How do I read VIN from the BCM over UDS?",
  "What modules are on the HS-CAN bus of a 2018 Challenger SRT?",
];

function ToolCallBadge({ toolCall }: { toolCall: ToolCall }) {
  const [expanded, setExpanded] = useState(false);
  let parsed: unknown = null;
  try { parsed = JSON.parse(toolCall.result); } catch { /* raw */ }

  const toolLabels: Record<string, string> = {
    search_dtcs: "DTC Lookup",
    search_bcm_params: "BCM Params",
    search_alphaobd: "AlphaOBD",
    explain_uds_frame: "UDS Decode",
    suggest_procedure: "Procedure",
  };

  return (
    <div className="mt-2 border border-blue-500/20 rounded bg-blue-950/20">
      <button
        className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-blue-400 hover:bg-blue-950/30"
        onClick={() => setExpanded(!expanded)}
      >
        <Wrench className="w-3 h-3" />
        <span className="font-mono">{toolLabels[toolCall.name] ?? toolCall.name}</span>
        <span className="ml-auto">
          {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </span>
      </button>
      {expanded && (
        <div className="px-3 pb-2 text-xs font-mono text-gray-400 max-h-40 overflow-y-auto">
          <pre className="whitespace-pre-wrap break-all">
            {typeof parsed === "object"
              ? JSON.stringify(parsed, null, 2)
              : toolCall.result}
          </pre>
        </div>
      )}
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";

  return (
    <div className={cn("flex gap-3 mb-4", isUser && "flex-row-reverse")}>
      <div
        className={cn(
          "w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5",
          isUser ? "bg-red-600" : "bg-blue-600"
        )}
      >
        {isUser ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
      </div>
      <div className={cn("flex-1 min-w-0 max-w-[85%]", isUser && "flex flex-col items-end")}>
        <div
          className={cn(
            "rounded-lg px-4 py-2.5 text-sm",
            isUser
              ? "bg-red-950/40 border border-red-500/20 text-white"
              : "bg-[#1a1a1a] border border-white/10 text-gray-200"
          )}
        >
          {isUser ? (
            <p className="whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div className="prose prose-invert prose-sm max-w-none">
              <Streamdown>{message.content}</Streamdown>
            </div>
          )}
          {message.toolCalls && message.toolCalls.length > 0 && (
            <div className="mt-2 space-y-1">
              {message.toolCalls.map((tc, i) => (
                <ToolCallBadge key={i} toolCall={tc} />
              ))}
            </div>
          )}
        </div>
        <div className="text-xs text-gray-600 mt-1 px-1">
          {new Date(message.timestamp).toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
}

export default function DiagnosticAssistant() {
  const vin: string | null = null; // VIN is read per-operation via OBD protocol
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: `# SRT Lab Diagnostic Assistant\n\nI'm your AI-powered FCA/Stellantis diagnostic expert. I have direct access to:\n\n- **22,166 DTC codes** with full descriptions and severity\n- **4,826+ BCM parameters** across all categories\n- **34,625+ AlphaOBD parameters** across all 10 tables\n- **UDS frame decoder** for raw protocol analysis\n\nAsk me anything about FCA/Stellantis diagnostics, module programming, seed-key algorithms, or EEPROM operations.${vin ? `\n\n**Active VIN:** \`${vin}\`` : ""}`,
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const chatMutation = trpc.assistant.chat.useMutation();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: text.trim(),
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      // Build message history for the LLM (exclude welcome message)
      const history = messages
        .filter((m) => m.id !== "welcome")
        .map((m) => ({ role: m.role, content: m.content }));

      const result = await chatMutation.mutateAsync({
        messages: [...history, { role: "user", content: text.trim() }],
        vin: vin ?? undefined,
      });

      const assistantMsg: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: typeof result.content === 'string' ? result.content : JSON.stringify(result.content),
        toolCalls: result.toolCalls,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      const errorMsg: Message = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: `**Error:** ${err instanceof Error ? err.message : "Failed to get response. Please try again."}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  }, [messages, input, isLoading, chatMutation, vin]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">Diagnostic Assistant</h1>
            <p className="text-xs text-gray-400">AI-powered FCA/Stellantis expert with live database access</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {vin && (
            <Badge variant="outline" className="border-green-500/40 text-green-400 text-xs font-mono">
              VIN: {vin}
            </Badge>
          )}
          <Badge variant="outline" className="border-blue-500/40 text-blue-400 text-xs">
            <Zap className="w-3 h-3 mr-1" />
            Live DB
          </Badge>
        </div>
      </div>

      {/* Info banner */}
      <div className="mx-6 mt-3 px-3 py-2 bg-blue-950/20 border border-blue-500/20 rounded flex items-start gap-2 shrink-0">
        <Info className="w-3.5 h-3.5 text-blue-400 mt-0.5 shrink-0" />
        <p className="text-xs text-blue-300">
          The assistant queries real databases for every lookup. Tool calls are shown inline so you can verify what data was used.
          Write operations always require your explicit confirmation.
        </p>
      </div>

      {/* Quick prompts */}
      {messages.length <= 1 && (
        <div className="px-6 mt-4 shrink-0">
          <p className="text-xs text-gray-500 mb-2">Quick starts:</p>
          <div className="flex flex-wrap gap-2">
            {QUICK_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                className="text-xs px-3 py-1.5 rounded border border-white/10 text-gray-400 hover:border-red-500/40 hover:text-red-400 transition-colors bg-white/5"
                onClick={() => sendMessage(prompt)}
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-1">
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        {isLoading && (
          <div className="flex gap-3 mb-4">
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3">
              <div className="flex gap-1 items-center">
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                <span className="text-xs text-gray-500 ml-2">Querying databases...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input area */}
      <div className="px-6 py-4 border-t border-white/10 shrink-0">
        <div className="flex gap-3 items-end">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about DTCs, modules, algorithms, EEPROM offsets, UDS frames..."
            className="flex-1 min-h-[44px] max-h-32 bg-[#1a1a1a] border-white/10 text-white placeholder:text-gray-600 resize-none text-sm"
            rows={1}
          />
          <Button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || isLoading}
            className="bg-red-600 hover:bg-red-700 h-11 px-4 shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-600 mt-1.5">Enter to send · Shift+Enter for new line</p>
      </div>
    </div>
  );
}
