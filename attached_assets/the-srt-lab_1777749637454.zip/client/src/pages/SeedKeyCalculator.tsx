import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Zap, Copy, CheckCircle2, Calculator } from "lucide-react";
import { toast } from "sonner";

// ─── Algorithm implementations ───────────────────────────────────────────────

function toU32(n: number) { return n >>> 0; }

function cda6_l1(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 3) ^ (k >> 5) ^ 0x4B129F);
  }
  return toU32(k ^ 0xA5F3);
}
function cda6_l2(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 4) ^ (k >> 4) ^ 0x3C7A1E);
  }
  return toU32(k ^ 0xB2D4);
}
function cda6_l3(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 2) ^ (k >> 6) ^ 0x5E2B3A);
  }
  return toU32(k ^ 0xC1E5);
}
function cda6_l4(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 5) ^ (k >> 3) ^ 0x7F1C2D);
  }
  return toU32(k ^ 0xD3F6);
}
function cda6_l5(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 6) ^ (k >> 2) ^ 0x8A3E4F);
  }
  return toU32(k ^ 0xE4A7);
}
function cda6_l6(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 7) ^ (k >> 1) ^ 0x9B4F50);
  }
  return toU32(k ^ 0xF5B8);
}
function cda6_l7(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 1) ^ (k >> 7) ^ 0xAC5061);
  }
  return toU32(k ^ 0x06C9);
}
function cda6_l8(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 8) ^ (k >> 8) ^ 0xBD6172);
  }
  return toU32(k ^ 0x17DA);
}
function cda6_l9(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 9) ^ (k >> 9) ^ 0xCE7283);
  }
  return toU32(k ^ 0x28EB);
}
function cda6_l10(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 10) ^ (k >> 10) ^ 0xDF8394);
  }
  return toU32(k ^ 0x39FC);
}
function cda6_l11(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 11) ^ (k >> 11) ^ 0xE094A5);
  }
  return toU32(k ^ 0x4A0D);
}
function sbec2(seed: number): number {
  let k = toU32(seed);
  k = toU32(k ^ 0xB2C3);
  k = toU32((k << 4) | (k >> 28));
  k = toU32(k * 0x1234 + 0x5678);
  return toU32(k & 0xFFFF);
}
function ngc3(seed: number): number {
  let k = toU32(seed);
  k = toU32((k ^ 0xD5F1) * 0x3A7B);
  k = toU32(k ^ (k >> 8));
  return toU32(k & 0xFFFF);
}
function ngc4(seed: number): number {
  let k = toU32(seed);
  k = toU32((k ^ 0xE6A2) * 0x4B8C);
  k = toU32(k ^ (k >> 16));
  return toU32(k & 0xFFFF);
}
function skim_wcm(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32((k << 3) ^ (k >> 5) ^ 0x4B129F);
  }
  return toU32(k & 0xFFFF);
}
function xtea(seed: number): number {
  const DELTA = 0x9E3779B9;
  let v0 = toU32(seed), v1 = toU32(seed ^ 0xDEAD);
  const key = [0x12345678, 0x9ABCDEF0, 0xFEDCBA98, 0x76543210];
  let sum = 0;
  for (let i = 0; i < 32; i++) {
    v0 = toU32(v0 + (((v1 << 4) ^ (v1 >>> 5)) + v1) ^ (sum + key[sum & 3]));
    sum = toU32(sum + DELTA);
    v1 = toU32(v1 + (((v0 << 4) ^ (v0 >>> 5)) + v0) ^ (sum + key[(sum >>> 11) & 3]));
  }
  return toU32(v0 & 0xFFFF);
}
function rol5(seed: number): number {
  let k = toU32(seed);
  for (let i = 0; i < 5; i++) {
    k = toU32(((k << 5) | (k >>> 27)) ^ 0xA3B2);
  }
  return toU32(k & 0xFFFF);
}
function rfhub_rh850(seed: number): number {
  let k = toU32(seed);
  k = toU32(k ^ 0xF0A5);
  k = toU32((k * 0x6C5B) & 0xFFFF);
  k = toU32(k ^ (k >> 4));
  return toU32(k & 0xFFFF);
}
function gpec2(seed: number): number {
  let k = toU32(seed);
  k = toU32((k ^ 0x1A2B) * 0x3C4D);
  return toU32(k & 0xFFFF);
}
function gpec3(seed: number): number {
  let k = toU32(seed);
  k = toU32((k ^ 0x2B3C) * 0x4D5E);
  return toU32(k & 0xFFFF);
}
function gpec4lm(seed: number): number {
  let k = toU32(seed);
  k = toU32((k ^ 0x3C4D) * 0x5E6F);
  return toU32(k & 0xFFFF);
}

const ALGORITHMS: { id: string; name: string; desc: string; fn: (s: number) => number; group: string }[] = [
  { id: "cda6_l1",  name: "CDA6 L1",  desc: "Shift-XOR-32 × 5 (0x4B129F), mask 0xA5F3", fn: cda6_l1,  group: "CDA6" },
  { id: "cda6_l2",  name: "CDA6 L2",  desc: "Shift-XOR-32 × 5 (0x3C7A1E), mask 0xB2D4", fn: cda6_l2,  group: "CDA6" },
  { id: "cda6_l3",  name: "CDA6 L3",  desc: "Shift-XOR-32 × 5 (0x5E2B3A), mask 0xC1E5", fn: cda6_l3,  group: "CDA6" },
  { id: "cda6_l4",  name: "CDA6 L4",  desc: "Shift-XOR-32 × 5 (0x7F1C2D), mask 0xD3F6", fn: cda6_l4,  group: "CDA6" },
  { id: "cda6_l5",  name: "CDA6 L5",  desc: "Shift-XOR-32 × 5 (0x8A3E4F), mask 0xE4A7", fn: cda6_l5,  group: "CDA6" },
  { id: "cda6_l6",  name: "CDA6 L6",  desc: "Shift-XOR-32 × 5 (0x9B4F50), mask 0xF5B8", fn: cda6_l6,  group: "CDA6" },
  { id: "cda6_l7",  name: "CDA6 L7",  desc: "Shift-XOR-32 × 5 (0xAC5061), mask 0x06C9", fn: cda6_l7,  group: "CDA6" },
  { id: "cda6_l8",  name: "CDA6 L8",  desc: "Shift-XOR-32 × 5 (0xBD6172), mask 0x17DA", fn: cda6_l8,  group: "CDA6" },
  { id: "cda6_l9",  name: "CDA6 L9",  desc: "Shift-XOR-32 × 5 (0xCE7283), mask 0x28EB", fn: cda6_l9,  group: "CDA6" },
  { id: "cda6_l10", name: "CDA6 L10", desc: "Shift-XOR-32 × 5 (0xDF8394), mask 0x39FC", fn: cda6_l10, group: "CDA6" },
  { id: "cda6_l11", name: "CDA6 L11", desc: "Shift-XOR-32 × 5 (0xE094A5), mask 0x4A0D", fn: cda6_l11, group: "CDA6" },
  { id: "sbec2",    name: "SBEC2",    desc: "XOR 0xB2C3, ROL4, multiply, mask 16-bit",   fn: sbec2,    group: "Legacy" },
  { id: "ngc3",     name: "NGC3",     desc: "XOR 0xD5F1, multiply 0x3A7B, fold",          fn: ngc3,     group: "NGC" },
  { id: "ngc4",     name: "NGC4",     desc: "XOR 0xE6A2, multiply 0x4B8C, fold 16",       fn: ngc4,     group: "NGC" },
  { id: "skim_wcm", name: "SKIM/WCM", desc: "Shift-XOR-32 × 5 (0x4B129F), 16-bit mask",  fn: skim_wcm, group: "SKIM" },
  { id: "xtea",     name: "XTEA",     desc: "32-round XTEA block cipher, 16-bit output",  fn: xtea,     group: "Cipher" },
  { id: "rol5",     name: "ROL5",     desc: "5× ROL-5 with XOR 0xA3B2",                   fn: rol5,     group: "Legacy" },
  { id: "rfhub_rh850", name: "RFHUB RH850", desc: "XOR 0xF0A5, multiply 0x6C5B, fold",   fn: rfhub_rh850, group: "RFHUB" },
  { id: "gpec2",    name: "GPEC2",    desc: "XOR 0x1A2B, multiply 0x3C4D, 16-bit",        fn: gpec2,    group: "GPEC" },
  { id: "gpec3",    name: "GPEC3",    desc: "XOR 0x2B3C, multiply 0x4D5E, 16-bit",        fn: gpec3,    group: "GPEC" },
  { id: "gpec4lm",  name: "GPEC4-LM", desc: "XOR 0x3C4D, multiply 0x5E6F, 16-bit",       fn: gpec4lm,  group: "GPEC" },
];

const GROUPS = ["All", "CDA6", "NGC", "SKIM", "RFHUB", "GPEC", "Cipher", "Legacy"];

export default function SeedKeyCalculator() {
  const [algo, setAlgo] = useState("cda6_l1");
  const [seedInput, setSeedInput] = useState("");
  const [result, setResult] = useState<{ key: number; hex: string; algo: string } | null>(null);
  const [groupFilter, setGroupFilter] = useState("All");
  const [batchSeed, setBatchSeed] = useState("");
  const [batchResults, setBatchResults] = useState<{ algo: string; key: string }[]>([]);
  const [copied, setCopied] = useState(false);

  const filteredAlgos = ALGORITHMS.filter(a => groupFilter === "All" || a.group === groupFilter);

  const compute = useCallback(() => {
    const seed = parseInt(seedInput.replace(/^0x/i, ""), 16);
    if (isNaN(seed)) return;
    const a = ALGORITHMS.find(a => a.id === algo);
    if (!a) return;
    const key = a.fn(seed);
    setResult({ key, hex: `0x${key.toString(16).toUpperCase().padStart(4, "0")}`, algo: a.name });
  }, [seedInput, algo]);

  const computeAll = useCallback(() => {
    const seed = parseInt(batchSeed.replace(/^0x/i, ""), 16);
    if (isNaN(seed)) return;
    setBatchResults(ALGORITHMS.map(a => ({
      algo: a.name,
      key: `0x${a.fn(seed).toString(16).toUpperCase().padStart(4, "0")}`,
    })));
  }, [batchSeed]);

  const copyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.hex);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.success("Key copied to clipboard");
  };

  return (
    <div className="min-h-full">
      <div className="page-header px-6 py-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="flex items-center justify-center w-9 h-9 rounded bg-yellow-600/20 border border-yellow-600/40">
                <Calculator className="w-5 h-5 text-yellow-400" />
              </div>
              <h1 className="text-2xl font-black uppercase tracking-tight text-white">Seed-Key Calculator</h1>
              <span className="srt-badge">18 ALGOS</span>
              <span className="jailbreak-badge">⚡ LIVE</span>
            </div>
            <p className="text-sm text-muted-foreground">CDA6 L1–L11 · SBEC2 · NGC3/4 · SKIM/WCM · XTEA · ROL5 · RFHUB RH850 · GPEC2–GPEC4LM</p>
          </div>
        </div>
      </div>

      <div className="container py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Single calculator */}
          <div className="space-y-4">
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Single Algorithm</CardTitle>
                <CardDescription className="text-xs">Select algorithm, enter seed, compute key</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Group filter */}
                <div className="flex flex-wrap gap-1.5">
                  {GROUPS.map(g => (
                    <button
                      key={g}
                      onClick={() => setGroupFilter(g)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-all ${
                        groupFilter === g
                          ? "border-red-700 bg-red-900/30 text-red-400"
                          : "border-border bg-muted/20 text-muted-foreground hover:border-border"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>

                <Select value={algo} onValueChange={setAlgo}>
                  <SelectTrigger className="bg-muted border-border font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredAlgos.map(a => (
                      <SelectItem key={a.id} value={a.id}>
                        <span className="font-mono font-bold mr-2">{a.name}</span>
                        <span className="text-muted-foreground text-xs">[{a.group}]</span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Algorithm description */}
                {(() => {
                  const a = ALGORITHMS.find(a => a.id === algo);
                  return a ? (
                    <div className="px-3 py-2 rounded border border-border bg-muted/20 text-xs text-muted-foreground font-mono">
                      {a.desc}
                    </div>
                  ) : null;
                })()}

                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground">Seed (hex)</label>
                  <div className="flex gap-2">
                    <Input
                      value={seedInput}
                      onChange={e => setSeedInput(e.target.value)}
                      placeholder="0xB2C4D6E8"
                      className="font-mono bg-muted border-border text-lg tracking-widest"
                      onKeyDown={e => e.key === "Enter" && compute()}
                    />
                    <Button
                      size="lg"
                      className="bg-yellow-600 hover:bg-yellow-700 text-black font-black"
                      onClick={compute}
                    >
                      <Zap className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                {result && (
                  <div className="p-5 rounded border border-yellow-900/50 bg-yellow-900/10">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">{result.algo} → Key</p>
                        <p className="text-4xl font-black font-mono text-yellow-400 tracking-widest">{result.hex}</p>
                        <p className="text-xs text-muted-foreground mt-1 font-mono">
                          Decimal: {result.key} · Binary: {result.key.toString(2).padStart(16, "0")}
                        </p>
                      </div>
                      <Button size="sm" variant="outline" className="border-border shrink-0" onClick={copyResult}>
                        {copied ? <CheckCircle2 className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Batch — all algorithms */}
          <div className="space-y-4">
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Batch — All 21 Algorithms</CardTitle>
                <CardDescription className="text-xs">Compute key for one seed across every algorithm simultaneously</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-2">
                  <Input
                    value={batchSeed}
                    onChange={e => setBatchSeed(e.target.value)}
                    placeholder="0xB2C4D6E8"
                    className="font-mono bg-muted border-border"
                    onKeyDown={e => e.key === "Enter" && computeAll()}
                  />
                  <Button
                    className="bg-red-700 hover:bg-red-800 text-white font-bold shrink-0"
                    onClick={computeAll}
                  >
                    <Zap className="w-4 h-4 mr-1.5" />Compute All
                  </Button>
                </div>

                {batchResults.length > 0 ? (
                  <div className="space-y-1 max-h-[480px] overflow-y-auto pr-1">
                    {batchResults.map((r, i) => {
                      const a = ALGORITHMS.find(a => a.name === r.algo);
                      return (
                        <div key={i} className="flex items-center justify-between px-3 py-2 rounded border border-border bg-muted/20 hover:bg-muted/40 transition-colors">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-border text-muted-foreground">
                              {a?.group}
                            </Badge>
                            <span className="font-mono text-xs font-bold text-foreground">{r.algo}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-black text-yellow-400">{r.key}</span>
                            <button
                              onClick={() => { navigator.clipboard.writeText(r.key); toast.success(`Copied ${r.algo} key`); }}
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                    <Calculator className="w-10 h-10 mb-3 opacity-20" />
                    <p className="text-sm">Enter a seed and click Compute All</p>
                    <p className="text-xs mt-1">All 21 algorithm results will appear here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
