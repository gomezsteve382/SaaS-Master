import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Database, Loader2, Download, Copy, Filter } from "lucide-react";
// import { trpc } from "@/lib/trpc";

/**
 * AlphaOBD Database Explorer
 * 
 * Searches ALL tables in alfaobd_android.db:
 *   FGA_BCM_DATA     (4,826 params)  — BCM configuration
 *   FGA_ENGINE_DATA  (4,427 params)  — Engine parameters
 *   FGA_PETROL_DATA  (5,099 params)  — Petrol engine data
 *   FGA_IPC_DATA     (1,389 params)  — Instrument cluster
 *   FGA_IPC_ROUTINES (232 routines)  — Special functions
 *   FGA_ABS_DATA     (4,089 params)  — ABS/ESP
 *   Diag_names       (3,891 procs)   — Diagnostic procedures
 *   Param_names      (4,757 params)  — Live data parameters
 *   ECUList          (1,632 ECUs)    — Supported ECUs
 *   Faults           (22,166 DTCs)   — Trouble codes
 * 
 * Total: 34,625+ searchable records
 */

interface SearchResult {
  source: string;
  request?: string;
  group_name?: string;
  response_name?: string;
  bit_pos?: number;
  bit_len?: number;
  table_value?: string;
  table_name?: string;
  lower_level?: number;
  upper_level?: number;
  slope?: number;
  offset?: number;
  unit_name?: string;
  device_id?: string;
  // For Diag_names / Param_names / ECUList / Faults
  name?: string;
  description?: string;
  code?: string;
  id?: number;
}

// Predefined searches for common things people look for
const QUICK_SEARCHES = [
  { label: "HP / Horsepower", query: "horsepower" },
  { label: "Rated Power", query: "rated power" },
  { label: "Engine Power", query: "engine power" },
  { label: "Torque", query: "torque" },
  { label: "Vehicle Config", query: "vehicle config" },
  { label: "Trim Level", query: "trim level" },
  { label: "Model ID", query: "model" },
  { label: "Performance Page", query: "performance page" },
  { label: "Display Value", query: "display value" },
  { label: "Cluster Config", query: "cluster config" },
  { label: "Startup Screen", query: "startup" },
  { label: "DRL", query: "daytime running" },
  { label: "Auto Lock", query: "auto lock" },
  { label: "Launch Control", query: "launch control" },
  { label: "Line Lock", query: "line lock" },
  { label: "Exhaust", query: "exhaust" },
  { label: "Gauge Sweep", query: "gauge sweep" },
  { label: "Radio Config", query: "radio" },
  { label: "Uconnect", query: "uconnect" },
  { label: "IPC", query: "ipc" },
];

// The tables to search
const SEARCH_TABLES = [
  { key: "bcm", label: "FGA_BCM_DATA", count: 4826, color: "bg-blue-500" },
  { key: "engine", label: "FGA_ENGINE_DATA", count: 4427, color: "bg-red-500" },
  { key: "petrol", label: "FGA_PETROL_DATA", count: 5099, color: "bg-orange-500" },
  { key: "ipc", label: "FGA_IPC_DATA", count: 1389, color: "bg-green-500" },
  { key: "ipc_routines", label: "FGA_IPC_ROUTINES", count: 232, color: "bg-purple-500" },
  { key: "abs", label: "FGA_ABS_DATA", count: 4089, color: "bg-yellow-500" },
  { key: "diag", label: "Diag_names", count: 3891, color: "bg-cyan-500" },
  { key: "params", label: "Param_names", count: 4757, color: "bg-pink-500" },
  { key: "dtcs", label: "Faults", count: 22166, color: "bg-gray-500" },
  { key: "ecus", label: "ECUList", count: 1632, color: "bg-indigo-500" },
];

export default function AlphaOBDExplorer() {
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedTable, setSelectedTable] = useState<string>("all");
  const [searchedQuery, setSearchedQuery] = useState("");
  const [tableCounts, setTableCounts] = useState<Record<string, number>>({});

  /**
   * In production, this calls your real tRPC endpoints:
   * 
   * const bcmResults = await trpc.alphaOBD.getAllFGABCMData.query({ limit: 5000 });
   * const engineResults = await trpc.alphaOBD.getAllFGAEngineData.query({ limit: 5000 });
   * const petrolResults = await trpc.alphaOBD.getAllFGAPetrolData.query({ limit: 5000 });
   * const ipcResults = await trpc.alphaOBD.getFGAIPCData.query({ limit: 2000 });
   * const routineResults = await trpc.alphaOBD.getRoutineControlLibrary.query({ search: query });
   * const absResults = await trpc.alphaOBD.getAllFGAABSData.query({ limit: 5000 });
   * const diagResults = await trpc.alphaOBD.getDiagnosticProcedures.query({ deviceID: '' });
   * const paramResults = await trpc.alphaOBD.getAllLiveDataParameters.query({ search: query, limit: 500 });
   * const dtcResults = await trpc.alphaOBD.searchDTCs.query({ query });
   * const ecuResults = await trpc.alphaOBD.searchECUs.query({ query });
   */
  const runSearch = async () => {
    if (!query.trim()) return;
    setSearching(true);
    setSearchedQuery(query);
    setResults([]);
    setTableCounts({});

    const q = query.toLowerCase();
    const allResults: SearchResult[] = [];
    const counts: Record<string, number> = {};

    // ── In production, replace each block below with the real tRPC call ──
    // ── For now, this shows the EXACT code you need to wire up ──

    try {
      // 1. FGA_BCM_DATA (4,826 params)
      // const bcmData = await trpc.alphaOBD.getAllFGABCMData.query({ limit: 5000 });
      // const bcmHits = bcmData.filter(p => 
      //   (p.response_name || '').toLowerCase().includes(q) ||
      //   (p.group_name || '').toLowerCase().includes(q) ||
      //   (p.request || '').toLowerCase().includes(q) ||
      //   (p.table_value || '').toLowerCase().includes(q) ||
      //   (p.table_name || '').toLowerCase().includes(q)
      // );
      // bcmHits.forEach(p => allResults.push({ source: 'FGA_BCM_DATA', ...p }));
      // counts['bcm'] = bcmHits.length;

      // 2. FGA_ENGINE_DATA (4,427 params)
      // const engineData = await trpc.alphaOBD.getAllFGAEngineData.query({ limit: 5000 });
      // const engineHits = engineData.filter(p => ...same filter...);
      // engineHits.forEach(p => allResults.push({ source: 'FGA_ENGINE_DATA', ...p }));
      // counts['engine'] = engineHits.length;

      // 3. FGA_PETROL_DATA (5,099 params)
      // const petrolData = await trpc.alphaOBD.getAllFGAPetrolData.query({ limit: 6000 });
      // ...

      // 4. FGA_IPC_DATA (1,389 params)
      // const ipcData = await trpc.alphaOBD.getFGAIPCData.query({ limit: 2000 });
      // ...

      // 5. FGA_IPC_ROUTINES (232 routines)
      // const routines = await trpc.alphaOBD.getRoutineControlLibrary.query({ search: query });
      // ...

      // 6. FGA_ABS_DATA (4,089 params)
      // const absData = await trpc.alphaOBD.getAllFGAABSData.query({ limit: 5000 });
      // ...

      // 7. Param_names (4,757 params)
      // const params = await trpc.alphaOBD.getAllLiveDataParameters.query({ search: query, limit: 500 });
      // ...

      // 8. Faults / DTCs (22,166 codes)
      // const dtcs = await trpc.alphaOBD.searchDTCs.query({ query });
      // ...

      // 9. ECUList (1,632 ECUs)
      // const ecus = await trpc.alphaOBD.searchECUs.query({ query });
      // ...

      // ── PLACEHOLDER: Use the searchAll endpoint which searches everything at once ──
      // This is the simplest approach - your backend already has searchSRTLab()
      // const searchResults = await trpc.alphaOBD.searchAll.query({ query, limit: 500 });

      // For demo, show what the UI looks like with sample results
      await delay(600);
      
      // Simulate what the real search would return
      if (q.includes("power") || q.includes("horse") || q.includes("hp") || q.includes("rated")) {
        allResults.push(
          { source: "FGA_ENGINE_DATA", request: "22026A", group_name: "Engine Status", response_name: `⚠️ SEARCH YOUR REAL DB: trpc.alphaOBD.getAllFGAEngineData.query({ limit: 5000 })`, bit_pos: 0, bit_len: 16, unit_name: "kW", device_id: "PCM" },
        );
        counts['engine'] = 1;
        allResults.push(
          { source: "INSTRUCTIONS", response_name: "👆 Wire up the tRPC calls below to search all 34,625 real parameters", group_name: "See the commented code in this component" },
        );
      }

    } catch (error: any) {
      console.error("Search error:", error);
    }

    setResults(allResults);
    setTableCounts(counts);
    setSearching(false);
  };

  // Filter results by table
  const filteredResults = selectedTable === "all" 
    ? results 
    : results.filter(r => {
        const tableMap: Record<string, string> = {
          bcm: "FGA_BCM_DATA", engine: "FGA_ENGINE_DATA", petrol: "FGA_PETROL_DATA",
          ipc: "FGA_IPC_DATA", ipc_routines: "FGA_IPC_ROUTINES", abs: "FGA_ABS_DATA",
          diag: "Diag_names", params: "Param_names", dtcs: "Faults", ecus: "ECUList",
        };
        return r.source === tableMap[selectedTable];
      });

  const copyResult = (r: SearchResult) => {
    const text = [
      `Source: ${r.source}`,
      r.request ? `DID: ${r.request}` : null,
      r.group_name ? `Group: ${r.group_name}` : null,
      r.response_name ? `Name: ${r.response_name}` : null,
      r.bit_pos !== undefined ? `Bit: ${r.bit_pos}` : null,
      r.bit_len !== undefined ? `Len: ${r.bit_len}` : null,
      r.table_value ? `Values: ${r.table_value}` : null,
      r.unit_name ? `Unit: ${r.unit_name}` : null,
      r.device_id ? `Device: ${r.device_id}` : null,
    ].filter(Boolean).join("\n");
    navigator.clipboard.writeText(text);
  };

  const exportResults = () => {
    const csv = "Source,DID,Group,Name,BitPos,BitLen,Values,Unit,Device\n" +
      filteredResults.map(r => [
        r.source, r.request || "", r.group_name || "", 
        `"${(r.response_name || "").replace(/"/g, '""')}"`,
        r.bit_pos ?? "", r.bit_len ?? "",
        `"${(r.table_value || "").replace(/"/g, '""')}"`,
        r.unit_name || "", r.device_id || ""
      ].join(",")).join("\n");
    
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `alphaobd_search_${query.replace(/\s/g, "_")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-950 via-gray-900 to-black text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Database className="h-8 w-8 text-indigo-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">AlphaOBD Database Explorer</h1>
          </div>
          <p className="text-gray-400">
            Search all 34,625 parameters across 10 tables in alfaobd_android.db — find any DID, parameter, or routine
          </p>
        </div>
      </div>

      <div className="container py-6 space-y-6">
        {/* Search Bar */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <div className="flex-1">
                <Input
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && runSearch()}
                  placeholder="Search parameters, DIDs, routines, DTCs... (e.g. 'horsepower', 'rated power', 'DE01', 'launch control')"
                  className="text-base h-12"
                />
              </div>
              <Button onClick={runSearch} disabled={searching || !query.trim()} className="h-12 px-8">
                {searching ? <Loader2 className="h-5 w-5 animate-spin" /> : <><Search className="h-5 w-5 mr-2" />Search</>}
              </Button>
            </div>

            {/* Quick Searches */}
            <div className="mt-4">
              <div className="text-xs text-muted-foreground mb-2 font-semibold uppercase">Quick Searches</div>
              <div className="flex flex-wrap gap-2">
                {QUICK_SEARCHES.map(qs => (
                  <Button key={qs.query} size="sm" variant="outline" className="text-xs h-7"
                    onClick={() => { setQuery(qs.query); setTimeout(() => { setQuery(qs.query); runSearch(); }, 0); }}>
                    {qs.label}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Table Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {SEARCH_TABLES.map(t => (
            <button key={t.key} onClick={() => setSelectedTable(selectedTable === t.key ? "all" : t.key)}
              className={`p-3 rounded-lg border text-left transition-all ${
                selectedTable === t.key ? "border-indigo-400 bg-indigo-50 dark:bg-indigo-950" : "border-gray-200 dark:border-gray-800 hover:border-gray-300"
              }`}>
              <div className="flex items-center gap-2 mb-1">
                <div className={`w-2 h-2 rounded-full ${t.color}`} />
                <span className="text-xs font-mono font-semibold truncate">{t.label}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-black">{t.count.toLocaleString()}</span>
                {tableCounts[t.key] !== undefined && (
                  <Badge variant={tableCounts[t.key] > 0 ? "default" : "secondary"} className="text-[10px]">
                    {tableCounts[t.key]} hits
                  </Badge>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Results */}
        {searchedQuery && (
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">
                  {filteredResults.length} results for "{searchedQuery}"
                  {selectedTable !== "all" && <span className="text-muted-foreground"> in {selectedTable}</span>}
                </CardTitle>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={exportResults} disabled={filteredResults.length === 0}>
                    <Download className="h-3 w-3 mr-1" />CSV
                  </Button>
                  {selectedTable !== "all" && (
                    <Button size="sm" variant="ghost" onClick={() => setSelectedTable("all")}>Show All</Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredResults.length === 0 && !searching ? (
                <div className="text-center py-12 space-y-4">
                  <p className="text-muted-foreground">No results found</p>
                  <div className="text-sm text-muted-foreground max-w-lg mx-auto space-y-2">
                    <p className="font-semibold">⚠️ To search the REAL database, wire up the tRPC calls:</p>
                    <pre className="text-left bg-muted p-4 rounded text-xs overflow-x-auto">{`// In this component, uncomment the tRPC calls:
const bcmData = await trpc.alphaOBD.getAllFGABCMData.query({ limit: 5000 });
const hits = bcmData.filter(p => 
  (p.response_name || '').toLowerCase().includes(query)
);

// Or use the unified search:
const results = await trpc.alphaOBD.searchAll.query({ query, limit: 500 });`}</pre>
                  </div>
                </div>
              ) : (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {filteredResults.map((r, i) => (
                    <div key={i} className="p-4 rounded-lg border border-gray-200 dark:border-gray-800 hover:bg-muted/50 transition-colors">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-[10px] font-mono shrink-0">{r.source}</Badge>
                            {r.request && <Badge variant="secondary" className="text-[10px] font-mono">DID: {r.request}</Badge>}
                            {r.device_id && <Badge variant="secondary" className="text-[10px]">{r.device_id}</Badge>}
                          </div>
                          <div className="font-semibold text-sm">{r.response_name || r.name || r.description || "—"}</div>
                          {r.group_name && <div className="text-xs text-muted-foreground">{r.group_name}</div>}
                        </div>
                        <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => copyResult(r)}>
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] font-mono text-muted-foreground">
                        {r.bit_pos !== undefined && <span>bit: {r.bit_pos}</span>}
                        {r.bit_len !== undefined && <span>len: {r.bit_len}</span>}
                        {r.lower_level !== null && r.lower_level !== undefined && <span>range: {r.lower_level}–{r.upper_level}</span>}
                        {r.slope !== null && r.slope !== undefined && <span>slope: {r.slope}</span>}
                        {r.offset !== null && r.offset !== undefined && r.offset !== 0 && <span>offset: {r.offset}</span>}
                        {r.unit_name && <span>unit: {r.unit_name}</span>}
                      </div>
                      
                      {r.table_value && (
                        <div className="mt-2 text-xs bg-muted/50 p-2 rounded font-mono break-all">
                          <span className="text-muted-foreground">values: </span>{r.table_value}
                        </div>
                      )}
                      {r.table_name && (
                        <div className="text-xs text-muted-foreground mt-1">
                          table: {r.table_name}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Wiring Instructions */}
        <Card className="border-indigo-200 dark:border-indigo-800">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Database className="h-4 w-4 text-indigo-500" />
              How to wire up real database search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="text-xs bg-muted p-4 rounded overflow-x-auto whitespace-pre">{`// 1. Import tRPC client
import { trpc } from "@/lib/trpc";

// 2. In the runSearch() function, replace the placeholder with:

// Search BCM parameters (4,826 rows)
const bcmData = await trpc.alphaOBD.getAllFGABCMData.query({ limit: 5000 });
const bcmHits = bcmData.filter(p =>
  [p.response_name, p.group_name, p.request, p.table_value, p.table_name]
    .some(field => (field || "").toLowerCase().includes(query))
);
bcmHits.forEach(p => allResults.push({ source: "FGA_BCM_DATA", ...p }));

// Search Engine parameters (4,427 rows)
const engineData = await trpc.alphaOBD.getAllFGAEngineData.query({ limit: 5000 });
// ...same filter pattern...

// Search IPC parameters (1,389 rows)
const ipcData = await trpc.alphaOBD.getFGAIPCData.query({ limit: 2000 });

// Search IPC Routines (232 rows)
const routines = await trpc.alphaOBD.getRoutineControlLibrary.query({ search: query });

// Search DTCs (22,166 rows)  
const dtcs = await trpc.alphaOBD.searchDTCs.query({ query });

// Or use the unified search endpoint:
const everything = await trpc.alphaOBD.searchAll.query({ query, limit: 500 });

// 3. To find the HP display DID specifically, search for:
//    "horsepower", "rated power", "engine power", "rated hp",
//    "vehicle power", "max power", "peak power"
//
// 4. The result will show the exact DID, bit position, 
//    and table_value options — that's your answer.`}</pre>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function delay(ms: number) { return new Promise(r => setTimeout(r, ms)); }
