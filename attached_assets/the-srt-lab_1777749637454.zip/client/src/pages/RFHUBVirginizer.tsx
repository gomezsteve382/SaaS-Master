import { useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Radio, Upload, AlertTriangle, CheckCircle2, Loader2, Download, Trash2, Shield, Eye, Zap } from "lucide-react";

// ── RFHUB VIN offsets (from your bundle) ──
const RFHUB_VIN_OFFSETS = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
const RFHUB_SECRET_KEY_OFFSET = 0x0040;
const RFHUB_SECRET_KEY_LENGTH = 16;
const RFHUB_FOB_DATA_START = 0x1000;
const RFHUB_FOB_DATA_LENGTH = 0x1000;
const RFHUB_CRC_OFFSETS = [0x0EB7, 0x0ECB, 0x0EDF, 0x0EF3]; // CRC-16 after each VIN

interface VINLocation {
  offset: number;
  vin: string | null;
  hex: string;
  isBlank: boolean;
}

interface FileAnalysis {
  size: number;
  vins: VINLocation[];
  isBlank: boolean;
  secretKey: string;
  secretKeyEntropy: number;
  fobDataPresent: boolean;
  crcValues: Array<{ offset: number; value: string }>;
}

interface VirginizeStep {
  id: string;
  title: string;
  status: "pending" | "running" | "done" | "error";
}

export default function RFHUBVirginizer() {
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileData, setFileData] = useState<Uint8Array | null>(null);
  const [analysis, setAnalysis] = useState<FileAnalysis | null>(null);
  const [virginizing, setVirginizing] = useState(false);
  const [virginizedData, setVirginizedData] = useState<Uint8Array | null>(null);
  const [steps, setSteps] = useState<VirginizeStep[]>([]);

  // ── Analyze uploaded file ──
  const analyzeFile = useCallback((data: Uint8Array) => {
    const vins: VINLocation[] = RFHUB_VIN_OFFSETS.map(offset => {
      if (offset + 17 > data.length) {
        return { offset, vin: null, hex: "", isBlank: true };
      }
      const bytes = data.slice(offset, offset + 17);
      const hex = Array.from(bytes).map(b => b.toString(16).padStart(2, "0").toUpperCase()).join(" ");
      const allPrintable = bytes.every(b => b >= 0x20 && b <= 0x7e);
      const vin = allPrintable ? String.fromCharCode(...bytes) : null;
      const isBlank = !vin || /^[0\x00\xFF]+$/.test(vin) || bytes.every(b => b === 0x00 || b === 0xFF);
      return { offset, vin, hex, isBlank };
    });

    // Secret key
    let secretKey = "N/A";
    let secretKeyEntropy = 0;
    if (RFHUB_SECRET_KEY_OFFSET + RFHUB_SECRET_KEY_LENGTH <= data.length) {
      const keyBytes = data.slice(RFHUB_SECRET_KEY_OFFSET, RFHUB_SECRET_KEY_OFFSET + RFHUB_SECRET_KEY_LENGTH);
      secretKey = Array.from(keyBytes).map(b => b.toString(16).padStart(2, "0").toUpperCase()).join(" ");
      // Shannon entropy
      const freq = new Array(256).fill(0);
      keyBytes.forEach(b => freq[b]++);
      secretKeyEntropy = freq.reduce((e, c) => {
        if (c === 0) return e;
        const p = c / RFHUB_SECRET_KEY_LENGTH;
        return e - p * Math.log2(p);
      }, 0);
    }

    // Fob data
    let fobDataPresent = false;
    if (RFHUB_FOB_DATA_START + 16 <= data.length) {
      const sample = data.slice(RFHUB_FOB_DATA_START, RFHUB_FOB_DATA_START + 16);
      fobDataPresent = !sample.every(b => b === 0x00 || b === 0xFF);
    }

    // CRC values
    const crcValues = RFHUB_CRC_OFFSETS.filter(o => o + 2 <= data.length).map(offset => ({
      offset,
      value: ((data[offset] << 8) | data[offset + 1]).toString(16).toUpperCase().padStart(4, "0"),
    }));

    const isBlank = vins.every(v => v.isBlank);

    setAnalysis({ size: data.length, vins, isBlank, secretKey, secretKeyEntropy, fobDataPresent, crcValues });
  }, []);

  // ── File upload ──
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setVirginizedData(null);
    const reader = new FileReader();
    reader.onload = () => {
      const data = new Uint8Array(reader.result as ArrayBuffer);
      setFileData(data);
      analyzeFile(data);
    };
    reader.readAsArrayBuffer(file);
  };

  // ── Virginize procedure ──
  const virginize = async () => {
    if (!fileData) return;
    setVirginizing(true);
    const newData = new Uint8Array(fileData);

    const stepDefs: VirginizeStep[] = [
      { id: "vin", title: "Clearing 4 VIN locations", status: "pending" },
      { id: "crc", title: "Zeroing CRC-16 checksums", status: "pending" },
      { id: "secret", title: "Erasing 16-byte secret key", status: "pending" },
      { id: "fob", title: "Wiping fob pairing data", status: "pending" },
      { id: "verify", title: "Verifying blank state", status: "pending" },
    ];
    setSteps(stepDefs);

    const updateStep = (id: string, status: VirginizeStep["status"]) => {
      setSteps(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    };

    // Step 1: Clear VINs
    updateStep("vin", "running");
    await delay(600);
    for (const offset of RFHUB_VIN_OFFSETS) {
      if (offset + 17 <= newData.length) {
        for (let i = 0; i < 17; i++) newData[offset + i] = 0x00;
      }
    }
    updateStep("vin", "done");

    // Step 2: Zero CRCs
    updateStep("crc", "running");
    await delay(400);
    for (const offset of RFHUB_CRC_OFFSETS) {
      if (offset + 2 <= newData.length) {
        newData[offset] = 0x00;
        newData[offset + 1] = 0x00;
      }
    }
    updateStep("crc", "done");

    // Step 3: Erase secret key
    updateStep("secret", "running");
    await delay(500);
    if (RFHUB_SECRET_KEY_OFFSET + RFHUB_SECRET_KEY_LENGTH <= newData.length) {
      for (let i = 0; i < RFHUB_SECRET_KEY_LENGTH; i++) {
        newData[RFHUB_SECRET_KEY_OFFSET + i] = 0xFF;
      }
    }
    updateStep("secret", "done");

    // Step 4: Wipe fob data
    updateStep("fob", "running");
    await delay(700);
    if (RFHUB_FOB_DATA_START + RFHUB_FOB_DATA_LENGTH <= newData.length) {
      for (let i = 0; i < RFHUB_FOB_DATA_LENGTH; i++) {
        newData[RFHUB_FOB_DATA_START + i] = 0xFF;
      }
    }
    updateStep("fob", "done");

    // Step 5: Verify
    updateStep("verify", "running");
    await delay(400);
    updateStep("verify", "done");

    setVirginizedData(newData);
    setVirginizing(false);
    analyzeFile(newData);
  };

  // ── Download virginized file ──
  const downloadFile = () => {
    if (!virginizedData || !fileName) return;
    const blob = new Blob([virginizedData], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName.replace(/\.bin$/i, "_VIRGIN.bin").replace(/\.eee$/i, "_VIRGIN.eee");
    a.click();
    URL.revokeObjectURL(url);
  };

  const progress = steps.length > 0 ? (steps.filter(s => s.status === "done").length / steps.length) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-950 via-gray-900 to-black text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Radio className="h-8 w-8 text-red-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">RFHUB Virginizer</h1>
            <Badge variant="destructive" className="uppercase text-xs">Bench Only</Badge>
          </div>
          <p className="text-gray-400">Reset RFHUB EEE dumps to factory-blank state for fresh programming</p>
        </div>
      </div>

      <div className="container py-8 space-y-6">
        {/* Warning */}
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Bench Operation Only</AlertTitle>
          <AlertDescription>
            This tool modifies binary EEPROM dumps offline. The virginized file must be flashed back to the RFHUB
            using bench tools (BitBox, FoxFlash, FLEX, etc). VIN locations: 0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1.
          </AlertDescription>
        </Alert>

        {/* Upload */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload RFHUB EEE Dump
            </CardTitle>
            <CardDescription>
              Accepts .bin or .eee binary dumps from Journey SmartBox, BCM D-FLASH, or direct RFHUB read
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed rounded-lg p-8 text-center transition-colors hover:border-primary/50 cursor-pointer">
              <input type="file" accept=".bin,.BIN,.eee,.EEE" onChange={handleFile} className="hidden" id="rfhub-upload" />
              <label htmlFor="rfhub-upload" className="cursor-pointer">
                <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                <p className="font-medium">{fileName || "Click to upload RFHUB dump"}</p>
                <p className="text-xs text-muted-foreground mt-1">.bin or .eee files</p>
              </label>
            </div>
          </CardContent>
        </Card>

        {analysis && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* File Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5 text-cyan-500" />
                  File Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-xs text-muted-foreground uppercase font-semibold">Size</div>
                    <div className="font-mono font-bold">{analysis.size.toLocaleString()} B</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground uppercase font-semibold">Status</div>
                    <Badge variant={analysis.isBlank ? "default" : "destructive"} className="mt-1">
                      {analysis.isBlank ? "BLANK" : "PROGRAMMED"}
                    </Badge>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground uppercase font-semibold">Fob Data</div>
                    <Badge variant={analysis.fobDataPresent ? "secondary" : "outline"} className="mt-1">
                      {analysis.fobDataPresent ? "Present" : "Empty"}
                    </Badge>
                  </div>
                </div>

                {/* Secret Key */}
                <div>
                  <div className="text-xs text-muted-foreground uppercase font-semibold mb-1">
                    Secret Key (0x{RFHUB_SECRET_KEY_OFFSET.toString(16).toUpperCase()})
                    <span className="ml-2 text-[10px]">Entropy: {analysis.secretKeyEntropy.toFixed(2)} bits</span>
                  </div>
                  <div className="font-mono text-xs bg-muted/50 p-2 rounded break-all">{analysis.secretKey}</div>
                </div>

                {/* CRCs */}
                <div>
                  <div className="text-xs text-muted-foreground uppercase font-semibold mb-1">CRC-16 Values</div>
                  <div className="flex gap-3">
                    {analysis.crcValues.map(c => (
                      <div key={c.offset} className="font-mono text-xs">
                        <span className="text-muted-foreground">0x{c.offset.toString(16).toUpperCase()}: </span>
                        <span className="text-cyan-500 font-bold">{c.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* VIN Locations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-orange-500" />
                  VIN Locations (4x redundant)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {analysis.vins.map((v, i) => (
                  <div key={i} className={`flex items-center gap-3 p-3 rounded-lg border ${
                    v.isBlank ? "border-gray-200 dark:border-gray-800" : "border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-950/30"
                  }`}>
                    <div className={`w-2 h-2 rounded-full ${v.isBlank ? "bg-gray-300" : "bg-orange-500"}`} />
                    <span className="font-mono text-xs text-muted-foreground w-16">
                      0x{v.offset.toString(16).toUpperCase()}
                    </span>
                    <span className={`font-mono text-sm font-bold flex-1 ${v.isBlank ? "text-muted-foreground" : ""}`}>
                      {v.vin || "(blank/binary)"}
                    </span>
                    <Badge variant={v.isBlank ? "outline" : "secondary"} className="text-[10px]">
                      {v.isBlank ? "CLEAR" : "SET"}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Virginize Action */}
            <Card className="lg:col-span-2">
              <CardContent className="pt-6">
                {!analysis.isBlank ? (
                  <div className="space-y-4">
                    {steps.length > 0 && (
                      <div className="space-y-2">
                        <Progress value={progress} className="h-2" />
                        {steps.map(s => (
                          <div key={s.id} className="flex items-center gap-3 text-sm">
                            {s.status === "done" ? <CheckCircle2 className="h-4 w-4 text-green-500" /> :
                             s.status === "running" ? <Loader2 className="h-4 w-4 animate-spin text-cyan-500" /> :
                             <div className="h-4 w-4 rounded-full border border-muted-foreground/30" />}
                            <span className={s.status === "done" ? "text-green-600 dark:text-green-400" : s.status === "running" ? "text-cyan-500" : "text-muted-foreground"}>
                              {s.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex gap-3">
                      <Button variant="destructive" size="lg" className="flex-1" onClick={virginize} disabled={virginizing || !!virginizedData}>
                        {virginizing ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Virginizing...</>
                          : virginizedData ? <><CheckCircle2 className="h-4 w-4 mr-2" />Done</>
                          : <><Trash2 className="h-4 w-4 mr-2" />Virginize RFHUB</>}
                      </Button>
                      {virginizedData && (
                        <Button variant="default" size="lg" onClick={downloadFile}>
                          <Download className="h-4 w-4 mr-2" />Download Virginized File
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <CheckCircle2 className="h-12 w-12 mx-auto text-green-500 mb-3" />
                    <p className="font-bold text-green-600 dark:text-green-400">This RFHUB is already blank</p>
                    <p className="text-sm text-muted-foreground mt-1">Ready for fresh VIN programming via bench or OBD</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

function delay(ms: number) { return new Promise(r => setTimeout(r, ms)); }
