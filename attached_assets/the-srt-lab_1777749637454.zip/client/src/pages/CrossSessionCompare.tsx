/**
 * CrossSessionCompare — Compare the same module across two different sessions.
 * Enables long-term state tracking: pick a module, pick two snapshots from
 * different sessions, and see the field-level diff.
 *
 * URL: /cross-session-compare?module=0x7E4&a=ID&b=ID
 */

import { useState, useMemo, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import {
  ArrowLeft, GitCompare, Search, RefreshCw, Clock, Cpu,
  ChevronDown, ChevronUp, CheckCircle2, XCircle, Minus,
  AlertTriangle, BarChart3, Download, Copy, Layers, History,
  TrendingUp, Filter
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ─── Constants ────────────────────────────────────────────────────────────────
const KNOWN_MODULES: Record<number, string> = {
  0x7e0: "ECM", 0x7e1: "TCM", 0x7e2: "ABS", 0x7e3: "EPS",
  0x7e4: "BCM", 0x7e5: "HVAC", 0x7e6: "IPC", 0x7e7: "RFH",
  0x7e8: "SCCM", 0x760: "GWAY", 0x7d0: "SGW", 0x7c0: "CGW",
  0x7a0: "ADAS-GW", 0x733: "RFHUB", 0x745: "SKIM",
};

const FIELD_LABELS: Record<string, { label: string; critical?: boolean }> = {
  vin:          { label: "VIN",             critical: true },
  partNumber:   { label: "Part Number",     critical: true },
  serialNumber: { label: "Serial Number",   critical: true },
  supplierCode: { label: "Supplier Code" },
  hwVersion:    { label: "HW Version" },
  swVersion:    { label: "SW Version" },
  dtcCount:     { label: "DTC Count" },
  moduleName:   { label: "Module Name" },
};

function formatAddr(addr: number) {
  return `0x${addr.toString(16).toUpperCase().padStart(3, "0")}`;
}

function formatDate(d: Date | string | null) {
  if (!d) return "—";
  return new Date(d).toLocaleString([], {
    month: "short", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit"
  });
}

function getModuleLabel(addr: number, name: string | null) {
  return name || KNOWN_MODULES[addr] || `Module ${formatAddr(addr)}`;
}

// ─── Diff engine (same as SnapshotComparison) ────────────────────────────────
type SnapRow = {
  id: number; sessionId: number; moduleAddr: number; moduleName: string | null;
  snapshotType: string; vin: string | null; partNumber: string | null;
  serialNumber: string | null; supplierCode: string | null; hwVersion: string | null;
  swVersion: string | null; dtcCount: number | null; capturedAt: Date | string;
  sessionTool: string | null;
};

type DiffRow = { field: string; valueA: string | null; valueB: string | null; changed: boolean };

function diffSnapshots(a: SnapRow, b: SnapRow): DiffRow[] {
  const fields = ["vin", "partNumber", "serialNumber", "supplierCode", "hwVersion", "swVersion", "dtcCount", "moduleName"] as const;
  return fields.map((f) => {
    const vA = a[f] != null ? String(a[f]) : null;
    const vB = b[f] != null ? String(b[f]) : null;
    return { field: f, valueA: vA, valueB: vB, changed: vA !== vB };
  });
}

// ─── Snapshot Card ────────────────────────────────────────────────────────────
function SnapshotCard({
  snap, label, selected, onClick
}: {
  snap: SnapRow; label: "A" | "B"; selected: boolean; onClick: () => void;
}) {
  const labelColor = label === "A" ? "bg-blue-600" : "bg-orange-600";
  return (
    <div
      className={cn(
        "border rounded-lg p-3 cursor-pointer transition-all",
        selected
          ? label === "A"
            ? "border-blue-500/60 bg-blue-950/15 ring-1 ring-blue-500/30"
            : "border-orange-500/60 bg-orange-950/15 ring-1 ring-orange-500/30"
          : "border-white/10 bg-black/20 hover:border-white/20 hover:bg-black/30"
      )}
      onClick={onClick}
    >
      <div className="flex items-center gap-2 mb-1.5">
        <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${labelColor} text-white`}>{label}</span>
        <span className="text-white font-mono text-sm font-semibold">{formatAddr(snap.moduleAddr)}</span>
        <Badge
          variant="outline"
          className={cn("text-xs ml-auto",
            snap.snapshotType === "before"
              ? "border-yellow-500/40 text-yellow-400"
              : "border-green-500/40 text-green-400"
          )}
        >
          {snap.snapshotType}
        </Badge>
      </div>
      {snap.vin && <div className="font-mono text-xs text-srt-red mb-1">{snap.vin}</div>}
      <div className="text-xs text-gray-500 flex items-center gap-2">
        <Clock className="w-3 h-3" />
        <span>{formatDate(snap.capturedAt)}</span>
        <span>· Session #{snap.sessionId}</span>
        {snap.sessionTool && <span>· {snap.sessionTool}</span>}
      </div>
    </div>
  );
}

// ─── Diff Table ───────────────────────────────────────────────────────────────
function DiffTable({ diffs }: { diffs: DiffRow[] }) {
  const [showUnchanged, setShowUnchanged] = useState(false);
  const visible = showUnchanged ? diffs : diffs.filter((d) => d.changed);

  return (
    <div className="bg-black/40 border border-white/10 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/10">
        <span className="text-sm font-semibold text-white flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-srt-red" /> Field Diff
        </span>
        <Button
          size="sm" variant="ghost"
          className="h-6 px-2 text-xs text-gray-400"
          onClick={() => setShowUnchanged((v) => !v)}
        >
          {showUnchanged ? <ChevronUp className="w-3 h-3 mr-1" /> : <ChevronDown className="w-3 h-3 mr-1" />}
          {showUnchanged ? "Hide unchanged" : "Show all"}
        </Button>
      </div>
      {visible.length === 0 ? (
        <div className="p-6 text-center text-gray-600 text-sm">
          {diffs.every((d) => !d.changed) ? "All fields are identical." : "No changed fields."}
        </div>
      ) : (
        <table className="w-full text-xs font-mono">
          <thead>
            <tr className="border-b border-white/5 text-gray-500">
              <th className="px-4 py-2 text-left w-32">Field</th>
              <th className="px-4 py-2 text-left">Snapshot A</th>
              <th className="px-4 py-2 text-left">Snapshot B</th>
              <th className="px-3 py-2 text-center w-16">Status</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((d) => {
              const meta = FIELD_LABELS[d.field];
              return (
                <tr
                  key={d.field}
                  className={cn(
                    "border-b border-white/5 transition-colors",
                    d.changed
                      ? meta?.critical
                        ? "bg-red-950/10 hover:bg-red-950/20"
                        : "bg-yellow-950/10 hover:bg-yellow-950/15"
                      : "hover:bg-white/5"
                  )}
                >
                  <td className="px-4 py-2.5 text-gray-400 font-semibold">
                    {meta?.label ?? d.field}
                    {meta?.critical && d.changed && (
                      <AlertTriangle className="w-3 h-3 text-red-400 inline ml-1" />
                    )}
                  </td>
                  <td className={cn("px-4 py-2.5", d.changed ? "text-blue-300" : "text-gray-400")}>
                    {d.valueA ?? <span className="text-gray-700 italic">—</span>}
                  </td>
                  <td className={cn("px-4 py-2.5", d.changed ? "text-orange-300" : "text-gray-400")}>
                    {d.valueB ?? <span className="text-gray-700 italic">—</span>}
                  </td>
                  <td className="px-3 py-2.5 text-center">
                    {d.changed
                      ? <XCircle className="w-3.5 h-3.5 text-red-400 mx-auto" />
                      : <CheckCircle2 className="w-3.5 h-3.5 text-green-600 mx-auto" />
                    }
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function CrossSessionCompare() {
  const [, navigate] = useLocation();

  // Parse URL params
  const urlParams = useMemo(() => {
    const p = new URLSearchParams(window.location.search);
    const mod = p.get("module");
    const a = p.get("a");
    const b = p.get("b");
    return {
      preModule: mod ? parseInt(mod, 16) : null,
      preA: a ? parseInt(a, 10) : null,
      preB: b ? parseInt(b, 10) : null,
    };
  }, []);

  const [vinFilter, setVinFilter] = useState("");
  const [selectedModule, setSelectedModule] = useState<number | null>(urlParams.preModule);
  const [selectedA, setSelectedA] = useState<number | null>(urlParams.preA);
  const [selectedB, setSelectedB] = useState<number | null>(urlParams.preB);
  const [typeFilter, setTypeFilter] = useState<"all" | "before" | "after">("all");
  const [compareTriggered, setCompareTriggered] = useState(
    urlParams.preA !== null && urlParams.preB !== null
  );

  // Load all distinct modules
  const { data: modules = [], isLoading: modulesLoading } = trpc.sessions.getDistinctModules.useQuery({
    vin: vinFilter.trim().length >= 3 ? vinFilter.trim() : undefined,
  });

  // Load snapshots for selected module
  const { data: snapshots = [], isLoading: snapsLoading } = trpc.sessions.getSnapshotsByModule.useQuery(
    {
      moduleAddr: selectedModule!,
      vin: vinFilter.trim().length >= 3 ? vinFilter.trim() : undefined,
      limit: 100,
    },
    { enabled: selectedModule !== null }
  );

  const filteredSnaps = useMemo(() => {
    if (typeFilter === "all") return snapshots;
    return snapshots.filter((s) => s.snapshotType === typeFilter);
  }, [snapshots, typeFilter]);

  const snapA = useMemo(() => snapshots.find((s) => s.id === selectedA) ?? null, [snapshots, selectedA]);
  const snapB = useMemo(() => snapshots.find((s) => s.id === selectedB) ?? null, [snapshots, selectedB]);

  const diffs = useMemo(() => {
    if (!snapA || !snapB || !compareTriggered) return null;
    return diffSnapshots(snapA as SnapRow, snapB as SnapRow);
  }, [snapA, snapB, compareTriggered]);

  const changedCount = diffs ? diffs.filter((d) => d.changed).length : 0;

  // Auto-toast when pre-loaded from URL
  useEffect(() => {
    if (urlParams.preA && urlParams.preB) {
      toast.success("Cross-session comparison loaded", {
        description: `Snapshot #${urlParams.preA} vs #${urlParams.preB}`,
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCompare = useCallback(() => {
    if (!selectedA || !selectedB) {
      toast.error("Select both Snapshot A and Snapshot B");
      return;
    }
    if (selectedA === selectedB) {
      toast.error("Select two different snapshots");
      return;
    }
    setCompareTriggered(true);
    // Update URL without navigation
    const params = new URLSearchParams();
    if (selectedModule) params.set("module", selectedModule.toString(16));
    if (selectedA) params.set("a", String(selectedA));
    if (selectedB) params.set("b", String(selectedB));
    window.history.replaceState({}, "", `${window.location.pathname}?${params.toString()}`);
  }, [selectedA, selectedB, selectedModule]);

  const handleReset = useCallback(() => {
    setSelectedA(null);
    setSelectedB(null);
    setCompareTriggered(false);
    window.history.replaceState({}, "", window.location.pathname);
  }, []);

  const handleExport = useCallback(() => {
    if (!diffs || !snapA || !snapB) return;
    const lines = [
      "# SRT Lab — Cross-Session Module Comparison",
      `Generated: ${new Date().toISOString()}`,
      `Module: ${getModuleLabel(snapA.moduleAddr, snapA.moduleName)} (${formatAddr(snapA.moduleAddr)})`,
      "",
      `Snapshot A — #${snapA.id} | Session #${snapA.sessionId} | ${snapA.sessionTool ?? ""} | ${formatDate(snapA.capturedAt)}`,
      `Snapshot B — #${snapB.id} | Session #${snapB.sessionId} | ${snapB.sessionTool ?? ""} | ${formatDate(snapB.capturedAt)}`,
      "",
      `Changed fields: ${changedCount} / ${diffs.length}`,
      "",
      "Field Differences:",
      ...diffs.map((d) => {
        const meta = FIELD_LABELS[d.field];
        return `  [${d.changed ? "CHANGED" : "SAME"}] ${meta?.label ?? d.field}: "${d.valueA ?? "—"}" → "${d.valueB ?? "—"}"`;
      }),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cross-session-diff-${snapA.id}-vs-${snapB.id}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report exported");
  }, [diffs, snapA, snapB, changedCount]);

  const handleCopy = useCallback(() => {
    if (!diffs) return;
    const text = diffs
      .filter((d) => d.changed)
      .map((d) => `${FIELD_LABELS[d.field]?.label ?? d.field}: ${d.valueA ?? "—"} → ${d.valueB ?? "—"}`)
      .join("\n");
    navigator.clipboard.writeText(text);
    toast.success("Diff copied");
  }, [diffs]);

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <Button
          variant="ghost" size="sm"
          className="text-gray-400 hover:text-white"
          onClick={() => navigate("/sessions")}
        >
          <ArrowLeft className="w-4 h-4 mr-1" /> Back
        </Button>
        <Separator orientation="vertical" className="h-5 bg-white/20" />
        <TrendingUp className="w-5 h-5 text-srt-red" />
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">Cross-Session Module Compare</h1>
          <p className="text-xs text-gray-500">Track a module's state changes across different diagnostic sessions</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Badge variant="outline" className="border-srt-red/40 text-srt-red text-xs font-mono">
            LONG-TERM TRACKING
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[320px_1fr_1fr] gap-5">
        {/* COLUMN 1 — Module Selector */}
        <div className="flex flex-col gap-4">
          <div className="bg-black/40 border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Cpu className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-semibold text-white">Select Module</span>
            </div>

            {/* VIN filter */}
            <div className="relative mb-3">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
              <Input
                placeholder="Filter by VIN..."
                value={vinFilter}
                onChange={(e) => setVinFilter(e.target.value)}
                className="pl-8 h-8 text-xs bg-black/30 border-white/10 font-mono"
              />
            </div>

            {modulesLoading ? (
              <div className="text-center py-6 text-gray-500 text-xs font-mono animate-pulse">Loading modules...</div>
            ) : modules.length === 0 ? (
              <div className="text-center py-6 text-gray-600 text-xs">
                No modules with snapshots found.
              </div>
            ) : (
              <div className="flex flex-col gap-1.5 max-h-[420px] overflow-y-auto pr-1">
                {modules.map((mod) => {
                  const isSelected = selectedModule === mod.moduleAddr;
                  return (
                    <div
                      key={mod.moduleAddr}
                      className={cn(
                        "border rounded-lg p-2.5 cursor-pointer transition-all",
                        isSelected
                          ? "border-srt-red/60 bg-red-950/15 ring-1 ring-srt-red/30"
                          : "border-white/10 bg-black/20 hover:border-white/20 hover:bg-black/30"
                      )}
                      onClick={() => {
                        setSelectedModule(mod.moduleAddr);
                        setSelectedA(null);
                        setSelectedB(null);
                        setCompareTriggered(false);
                      }}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-white font-mono text-sm font-semibold">
                              {getModuleLabel(mod.moduleAddr, mod.moduleName)}
                            </span>
                            <span className="text-gray-600 font-mono text-xs">{formatAddr(mod.moduleAddr)}</span>
                          </div>
                          <div className="text-xs text-gray-600 mt-0.5 flex items-center gap-2">
                            <Layers className="w-2.5 h-2.5" />
                            {mod.snapshotCount} snapshots · {mod.sessionCount} sessions
                          </div>
                        </div>
                        {isSelected && (
                          <CheckCircle2 className="w-4 h-4 text-srt-red shrink-0" />
                        )}
                      </div>
                      <div className="text-xs text-gray-700 mt-1 flex items-center gap-1">
                        <History className="w-2.5 h-2.5" />
                        Last seen: {formatDate(mod.lastSeen)}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* COLUMN 2 — Snapshot A Picker */}
        <SnapshotPicker
          label="A"
          color="blue"
          selectedId={selectedA}
          otherId={selectedB}
          snapshots={filteredSnaps}
          isLoading={snapsLoading}
          moduleSelected={selectedModule !== null}
          typeFilter={typeFilter}
          onTypeFilter={setTypeFilter}
          onSelect={(id) => {
            setSelectedA(id);
            setCompareTriggered(false);
          }}
        />

        {/* COLUMN 3 — Snapshot B Picker */}
        <SnapshotPicker
          label="B"
          color="orange"
          selectedId={selectedB}
          otherId={selectedA}
          snapshots={filteredSnaps}
          isLoading={snapsLoading}
          moduleSelected={selectedModule !== null}
          typeFilter={typeFilter}
          onTypeFilter={setTypeFilter}
          onSelect={(id) => {
            setSelectedB(id);
            setCompareTriggered(false);
          }}
        />
      </div>

      {/* Compare Controls */}
      <div className="mt-5 flex items-center gap-3">
        <Button
          className="bg-srt-red hover:bg-srt-red/80 text-white font-semibold px-6"
          disabled={!selectedA || !selectedB || selectedA === selectedB}
          onClick={handleCompare}
        >
          <GitCompare className="w-4 h-4 mr-2" />
          Compare Snapshots
        </Button>
        <Button
          variant="outline"
          className="border-white/20 text-gray-400 hover:text-white"
          onClick={handleReset}
        >
          <RefreshCw className="w-4 h-4 mr-1" /> Reset
        </Button>
        {diffs && (
          <>
            <Separator orientation="vertical" className="h-6 bg-white/20" />
            <div className="flex items-center gap-4 text-sm">
              <span className={cn("font-semibold", changedCount > 0 ? "text-red-400" : "text-green-400")}>
                {changedCount} changed
              </span>
              <span className="text-gray-600">{diffs.length - changedCount} unchanged</span>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <Button size="sm" variant="outline" className="h-7 px-2.5 text-xs border-white/20 text-gray-400 hover:text-white" onClick={handleCopy}>
                <Copy className="w-3 h-3 mr-1" /> Copy Diff
              </Button>
              <Button size="sm" variant="outline" className="h-7 px-2.5 text-xs border-white/20 text-gray-400 hover:text-white" onClick={handleExport}>
                <Download className="w-3 h-3 mr-1" /> Export
              </Button>
            </div>
          </>
        )}
      </div>

      {/* Selected snapshot summary */}
      {(snapA || snapB) && (
        <div className="mt-4 grid grid-cols-2 gap-3">
          {snapA
            ? <SnapshotCard snap={snapA as SnapRow} label="A" selected onClick={() => {}} />
            : <div className="border border-dashed border-white/10 rounded-lg p-4 text-center text-gray-700 text-xs">No Snapshot A selected</div>
          }
          {snapB
            ? <SnapshotCard snap={snapB as SnapRow} label="B" selected onClick={() => {}} />
            : <div className="border border-dashed border-white/10 rounded-lg p-4 text-center text-gray-700 text-xs">No Snapshot B selected</div>
          }
        </div>
      )}

      {/* Diff Results */}
      {diffs && (
        <div className="mt-5">
          {/* Stats */}
          <div className="grid grid-cols-4 gap-3 mb-4">
            {[
              { label: "Changed", value: changedCount, color: changedCount > 0 ? "text-red-400" : "text-green-400" },
              { label: "Unchanged", value: diffs.length - changedCount, color: "text-green-500" },
              { label: "Total Fields", value: diffs.length, color: "text-gray-300" },
              {
                label: "Change Rate",
                value: `${diffs.length > 0 ? Math.round((changedCount / diffs.length) * 100) : 0}%`,
                color: changedCount > 0 ? "text-yellow-400" : "text-green-400"
              },
            ].map((stat) => (
              <div key={stat.label} className="bg-black/40 border border-white/10 rounded-xl p-3 text-center">
                <div className={`text-2xl font-bold font-mono ${stat.color}`}>{stat.value}</div>
                <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          <DiffTable diffs={diffs} />
        </div>
      )}

      {/* Empty state when module selected but no comparison yet */}
      {selectedModule && !diffs && (
        <div className="mt-6 border border-dashed border-white/10 rounded-xl p-10 text-center">
          <GitCompare className="w-10 h-10 text-gray-700 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">
            Select <strong className="text-blue-400">Snapshot A</strong> and <strong className="text-orange-400">Snapshot B</strong> from the lists above, then click <strong className="text-white">Compare Snapshots</strong>.
          </p>
          <p className="text-gray-700 text-xs mt-2">
            Snapshots from different sessions will reveal how the module changed over time.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Snapshot Picker Column ───────────────────────────────────────────────────
type SnapEntry = {
  id: number; sessionId: number; moduleAddr: number; moduleName: string | null;
  snapshotType: string; vin: string | null; capturedAt: Date | string; sessionTool: string | null;
};

function SnapshotPicker({
  label, color, selectedId, otherId, snapshots, isLoading, moduleSelected,
  typeFilter, onTypeFilter, onSelect,
}: {
  label: "A" | "B";
  color: "blue" | "orange";
  selectedId: number | null;
  otherId: number | null;
  snapshots: SnapEntry[];
  isLoading: boolean;
  moduleSelected: boolean;
  typeFilter: "all" | "before" | "after";
  onTypeFilter: (v: "all" | "before" | "after") => void;
  onSelect: (id: number | null) => void;
}) {
  const borderColor = color === "blue" ? "border-blue-500/40" : "border-orange-500/40";
  const labelBg = color === "blue" ? "bg-blue-600" : "bg-orange-600";
  const ringColor = color === "blue" ? "ring-blue-500/30 border-blue-500/60 bg-blue-950/15" : "ring-orange-500/30 border-orange-500/60 bg-orange-950/15";

  return (
    <div className={cn("bg-black/40 border rounded-xl p-4 flex flex-col gap-3", borderColor)}>
      <div className="flex items-center gap-2">
        <span className={`text-xs font-bold px-2 py-0.5 rounded ${labelBg} text-white`}>{label}</span>
        <span className="text-sm font-semibold text-white">Snapshot {label}</span>
        <div className="ml-auto">
          <Select value={typeFilter} onValueChange={(v) => onTypeFilter(v as typeof typeFilter)}>
            <SelectTrigger className="w-24 h-7 text-xs bg-black/30 border-white/10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="before">Before</SelectItem>
              <SelectItem value="after">After</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {!moduleSelected ? (
        <div className="flex-1 flex items-center justify-center py-8 text-gray-600 text-xs text-center">
          <div>
            <Cpu className="w-6 h-6 mx-auto mb-2 opacity-40" />
            Select a module first
          </div>
        </div>
      ) : isLoading ? (
        <div className="text-center py-6 text-gray-500 text-xs font-mono animate-pulse">Loading snapshots...</div>
      ) : snapshots.length === 0 ? (
        <div className="text-center py-6 text-gray-600 text-xs">No snapshots for this module</div>
      ) : (
        <div className="flex flex-col gap-1.5 max-h-[460px] overflow-y-auto pr-1">
          {snapshots.map((snap) => {
            const isSelected = snap.id === selectedId;
            const isOther = snap.id === otherId;
            return (
              <div
                key={snap.id}
                className={cn(
                  "border rounded-lg p-2.5 cursor-pointer transition-all",
                  isSelected && `ring-1 ${ringColor}`,
                  isOther && "opacity-40 cursor-not-allowed",
                  !isSelected && !isOther && "border-white/10 bg-black/20 hover:border-white/20 hover:bg-black/30"
                )}
                onClick={() => {
                  if (isOther) return;
                  onSelect(isSelected ? null : snap.id);
                }}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <div className="flex items-center gap-2">
                    {isSelected && (
                      <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${labelBg} text-white`}>{label}</span>
                    )}
                    <span className="text-white font-mono text-xs font-semibold">#{snap.id}</span>
                    {snap.sessionTool && (
                      <span className="text-gray-500 text-xs">{snap.sessionTool}</span>
                    )}
                  </div>
                  <Badge
                    variant="outline"
                    className={cn("text-[10px]",
                      snap.snapshotType === "before"
                        ? "border-yellow-500/40 text-yellow-400"
                        : "border-green-500/40 text-green-400"
                    )}
                  >
                    {snap.snapshotType}
                  </Badge>
                </div>
                {snap.vin && (
                  <div className="font-mono text-xs text-srt-red mb-1">{snap.vin}</div>
                )}
                <div className="text-xs text-gray-600 flex items-center gap-1.5">
                  <Clock className="w-2.5 h-2.5" />
                  {formatDate(snap.capturedAt)}
                  <span>· Session #{snap.sessionId}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
