/**
 * Gateway Cloning — GWAY / SGW / CGW / ADAS-GW
 *
 * Full UDS workflow:
 *   1. Detect gateway variant (0x760 GWAY, 0x7D0 SGW, 0x7C0 CGW, 0x7A0 ADAS-GW)
 *   2. Read module identity DIDs (F101, F18C, F187, F1A0, F189, F190)
 *   3. Security access — XTEA (level 0x01) for read, CDA6-L9 (level 0x11) for write
 *   4. Read full EEPROM via UDS 0x23 (ReadMemoryByAddress) in 128-byte blocks
 *   5. Parse EEPROM: locate VIN (ASCII 17-byte), secret key (16-byte), CRC fields
 *   6. Patch VIN + secret key in memory buffer
 *   7. Recalculate CRC-16/CCITT-FALSE over patched regions
 *   8. Write patched EEPROM back via UDS 0x3D (WriteMemoryByAddress) in 128-byte blocks
 *   9. Reset module, verify with VIN read-back
 */

import { useState, useCallback, useRef } from "react";
import { computeKey } from "@/lib/seedkey";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Network, Cpu, Shield, ArrowLeft, Play, Download, Upload,
  CheckCircle2, XCircle, AlertTriangle, RefreshCw, FileDown,
} from "lucide-react";
import { Link } from "wouter";
import { EEPROMDiffViewer } from "@/components/EEPROMDiffViewer";
import { VirtualUDSLog } from "@/components/VirtualUDSLog";
import type { LogEntry } from "@/lib/AlphaOBDProtocol";
import type { UDSLogEntry } from "@/components/VirtualUDSLog";

// ─── Gateway Variant Definitions ─────────────────────────────────────────────
const GATEWAY_VARIANTS = [
  {
    id: "GWAY",
    name: "GWAY (FCA Gateway)",
    txId: 0x760,
    rxId: 0x768,
    eepromBase: 0x00000000,
    eepromSize: 0x8000,       // 32 KB
    vinOffset: 0x0140,        // VIN ASCII 17 bytes
    secretKeyOffset: 0x0160,  // 16-byte secret key
    crcOffset: 0x7FFE,        // CRC-16 at end of EEPROM
    crcRegion: [0x0000, 0x7FFE],
    readAlgo: "xtea",
    writeAlgo: "cda6_l9",
    readLevel: 0x01,
    writeLevel: 0x11,
    blockSize: 128,
    description: "FCA/Stellantis Gateway — Challenger, Charger, Durango, RAM, Jeep (2013+)",
  },
  {
    id: "SGW",
    name: "SGW (Secure Gateway)",
    txId: 0x7D0,
    rxId: 0x7D8,
    eepromBase: 0x00000000,
    eepromSize: 0x10000,      // 64 KB
    vinOffset: 0x0200,
    secretKeyOffset: 0x0220,
    crcOffset: 0xFFFE,
    crcRegion: [0x0000, 0xFFFE],
    readAlgo: "xtea",
    writeAlgo: "cda6_l9",
    readLevel: 0x01,
    writeLevel: 0x11,
    blockSize: 128,
    description: "Secure Gateway — Stellantis 2019+ (Gladiator, Wagoneer, Grand Cherokee L)",
  },
  {
    id: "CGW",
    name: "CGW (Central Gateway)",
    txId: 0x7C0,
    rxId: 0x7C8,
    eepromBase: 0x00000000,
    eepromSize: 0x8000,
    vinOffset: 0x0180,
    secretKeyOffset: 0x01A0,
    crcOffset: 0x7FFE,
    crcRegion: [0x0000, 0x7FFE],
    readAlgo: "xtea",
    writeAlgo: "cda6_l9",
    readLevel: 0x01,
    writeLevel: 0x11,
    blockSize: 128,
    description: "Central Gateway — Fiat 500X, Alfa Romeo Giulia/Stelvio, Maserati",
  },
  {
    id: "ADAS_GW",
    name: "ADAS-GW (ADAS Gateway)",
    txId: 0x7A0,
    rxId: 0x7A8,
    eepromBase: 0x00000000,
    eepromSize: 0x8000,
    vinOffset: 0x0100,
    secretKeyOffset: 0x0120,
    crcOffset: 0x7FFE,
    crcRegion: [0x0000, 0x7FFE],
    readAlgo: "xtea",
    writeAlgo: "cda6_l9",
    readLevel: 0x01,
    writeLevel: 0x11,
    blockSize: 128,
    description: "ADAS Gateway — Jeep Grand Cherokee, Ram 1500 (2019+ with ADAS suite)",
  },
] as const;

type GatewayVariantId = typeof GATEWAY_VARIANTS[number]["id"];

// ─── CRC-16/CCITT-FALSE ──────────────────────────────────────────────────────
function crc16ccitt(data: Uint8Array, start = 0, length?: number): number {
  let crc = 0xFFFF;
  const end = start + (length ?? data.length - start);
  for (let i = start; i < end; i++) {
    crc ^= data[i]! << 8;
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
      crc &= 0xFFFF;
    }
  }
  return crc;
}

// ─── VIN Validation ──────────────────────────────────────────────────────────
function validateVIN(vin: string): string | null {
  if (vin.length !== 17) return "VIN must be exactly 17 characters";
  if (!/^[A-HJ-NPR-Z0-9]{17}$/i.test(vin)) return "Invalid VIN characters (I, O, Q not allowed)";
  const transliteration: Record<string, number> = {
    A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,
    S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9,'0':0,'1':1,'2':2,'3':3,'4':4,
    '5':5,'6':6,'7':7,'8':8,'9':9,
  };
  const weights = [8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2];
  const checkDigitMap: Record<number, string> = {0:'0',1:'1',2:'2',3:'3',4:'4',5:'5',6:'6',7:'7',8:'8',9:'9',10:'X'};
  let sum = 0;
  for (let i = 0; i < 17; i++) {
    const c = vin[i]!.toUpperCase();
    const val = transliteration[c];
    if (val === undefined) return `Invalid character at position ${i+1}: ${c}`;
    sum += val * weights[i]!;
  }
  const check = checkDigitMap[sum % 11];
  if (check !== vin[8]!.toUpperCase()) return `Check digit mismatch: expected ${check}, got ${vin[8]}`;
  return null;
}

// ─── Types ───────────────────────────────────────────────────────────────────
type Step = "idle" | "detecting" | "reading" | "patching" | "writing" | "verifying" | "done" | "error";

interface ModuleInfo {
  partNumber: string;
  serial: string;
  supplier: string;
  hwVersion: string;
  swVersion: string;
  vin: string;
}

// ─── Component ───────────────────────────────────────────────────────────────
export default function GatewayCloning() {

  const [variantId, setVariantId] = useState<GatewayVariantId>("GWAY");
  const [targetVIN, setTargetVIN] = useState("");
  const [secretKeyHex, setSecretKeyHex] = useState("");
  const [step, setStep] = useState<Step>("idle");
  const [progress, setProgress] = useState(0);
  const [progressLabel, setProgressLabel] = useState("");
  const [moduleInfo, setModuleInfo] = useState<ModuleInfo | null>(null);
  const [originalEEPROM, setOriginalEEPROM] = useState<Uint8Array | null>(null);
  const [patchedEEPROM, setPatchedEEPROM] = useState<Uint8Array | null>(null);
  const [logs, setLogs] = useState<UDSLogEntry[]>([]);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const sidRef = useRef<number>(0);
  const [vinError, setVinError] = useState<string | null>(null);
  const [showDiff, setShowDiff] = useState(false);

  const abortRef = useRef(false);

  const createSessionMutation = trpc.sessions.create.useMutation();
  const addLogBatchMutation = trpc.sessions.addLogBatch.useMutation();
  const completeSessionMutation = trpc.sessions.complete.useMutation();
  const saveSnapshotMutation = trpc.sessions.saveSnapshot.useMutation();

  const variant = GATEWAY_VARIANTS.find(v => v.id === variantId)!;

  // ─── Logging ───────────────────────────────────────────────────────────────
  const logBuffer = useRef<LogEntry[]>([]);
  const addLog = useCallback((level: LogEntry["level"], msg: string) => {
    const entry: LogEntry = {
      time: new Date().toLocaleTimeString("en-US", { hour12: false }),
      level,
      msg,
    };
    const udsEntry: UDSLogEntry = {
      id: `${Date.now()}-${Math.random()}`,
      timestamp: entry.time,
      direction: (level === "TX" ? "TX" : level === "RX" ? "RX" : level === "ERROR" ? "ERROR" : level === "WARN" ? "WARN" : "INFO") as UDSLogEntry["direction"],
      raw: msg,
    };
    setLogs(prev => [...prev, udsEntry]);
    logBuffer.current.push(entry);
  }, []);

  const flushLogs = useCallback(async (sid: number) => {
    if (!sid) return;
    if (logBuffer.current.length === 0) return;
    const entries = logBuffer.current.splice(0);
    await addLogBatchMutation.mutateAsync({
      sessionId: sid,
      entries: entries.map(e => ({
        direction: (e.level === "TX" ? "tx" : e.level === "RX" ? "rx" : e.level === "ERROR" ? "error" : e.level === "SUCCESS" ? "success" : e.level === "WARN" ? "warning" : "info") as "tx" | "rx" | "info" | "success" | "error" | "warning",
        message: e.msg,
      })),
    });
  }, [addLogBatchMutation]);

  // ─── Security Access Helper ─────────────────────────────────────────────────
  const doSecurityAccess = useCallback(async (
    txId: number, rxId: number, level: number, algoId: string
  ): Promise<boolean> => {
    addLog("INFO", `Security access level 0x${level.toString(16).toUpperCase().padStart(2, "0")} (${algoId})...`);
    const seedResp = await protocol.sendUDS(txId, rxId, [0x27, level]);
    if (!seedResp.success || !seedResp.data) {
      addLog("ERROR", `Seed request failed: ${seedResp.error ?? "no response"}`);
      return false;
    }
    addLog("RX", `Seed: ${seedResp.data.map(b => b.toString(16).padStart(2, "0").toUpperCase()).join(" ")}`);
    const seedBytes = seedResp.data.slice(2);
    const seedHex = seedBytes.map(b => b.toString(16).padStart(2, "0")).join("");
    const { key, bytes, error } = computeKey(algoId, seedHex);
    if (error) {
      addLog("ERROR", `Key computation failed: ${error}`);
      return false;
    }
    addLog("TX", `Key: ${key}`);
    const sendLevel = level + 1;
    const keyResp = await protocol.sendUDS(txId, rxId, [0x27, sendLevel, ...bytes]);
    if (!keyResp.success) {
      addLog("ERROR", `Key send failed: ${keyResp.error ?? "rejected"}`);
      return false;
    }
    addLog("SUCCESS", "Security access granted");
    return true;
  }, [protocol, addLog]);

  // ─── Read EEPROM ────────────────────────────────────────────────────────────
  const readEEPROM = useCallback(async (
    txId: number, rxId: number, baseAddr: number, totalSize: number, blockSize: number
  ): Promise<Uint8Array | null> => {
    const buffer = new Uint8Array(totalSize);
    const numBlocks = Math.ceil(totalSize / blockSize);
    addLog("INFO", `Reading EEPROM: ${totalSize} bytes in ${numBlocks} blocks of ${blockSize} bytes`);

    for (let i = 0; i < numBlocks; i++) {
      if (abortRef.current) { addLog("WARN", "Aborted by user"); return null; }
      const addr = baseAddr + i * blockSize;
      const len = Math.min(blockSize, totalSize - i * blockSize);
      // UDS 0x23 ReadMemoryByAddress: [0x23, addrLen+lenLen, addr(3 bytes), len(1 byte)]
      const addrBytes = [(addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF];
      const resp = await protocol.sendUDS(txId, rxId, [0x23, 0x31, ...addrBytes, len]);
      if (!resp.success || !resp.data) {
        addLog("ERROR", `Read failed at 0x${addr.toString(16).toUpperCase()}: ${resp.error ?? "no data"}`);
        return null;
      }
      // Response: [0x63, ...data]
      const data = resp.data.slice(1);
      buffer.set(data.slice(0, len), i * blockSize);
      addLog("RX", `Block ${i+1}/${numBlocks} @ 0x${addr.toString(16).toUpperCase().padStart(6, "0")}: ${len} bytes`);
      setProgress(Math.round(((i + 1) / numBlocks) * 50));
      setProgressLabel(`Reading block ${i+1}/${numBlocks}`);
    }
    return buffer;
  }, [protocol, addLog]);

  // ─── Write EEPROM ───────────────────────────────────────────────────────────
  const writeEEPROM = useCallback(async (
    txId: number, rxId: number, baseAddr: number, data: Uint8Array, blockSize: number
  ): Promise<boolean> => {
    const numBlocks = Math.ceil(data.length / blockSize);
    addLog("INFO", `Writing EEPROM: ${data.length} bytes in ${numBlocks} blocks`);

    for (let i = 0; i < numBlocks; i++) {
      if (abortRef.current) { addLog("WARN", "Aborted by user"); return false; }
      const addr = baseAddr + i * blockSize;
      const len = Math.min(blockSize, data.length - i * blockSize);
      const chunk = Array.from(data.slice(i * blockSize, i * blockSize + len));
      // UDS 0x3D WriteMemoryByAddress: [0x3D, addrLen+lenLen, addr(3 bytes), len(1 byte), ...data]
      const addrBytes = [(addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF];
      const resp = await protocol.sendUDS(txId, rxId, [0x3D, 0x31, ...addrBytes, len, ...chunk], 5000);
      if (!resp.success) {
        addLog("ERROR", `Write failed at 0x${addr.toString(16).toUpperCase()}: ${resp.error ?? "NRC"}`);
        return false;
      }
      addLog("TX", `Block ${i+1}/${numBlocks} @ 0x${addr.toString(16).toUpperCase().padStart(6, "0")}: ${len} bytes written`);
      setProgress(50 + Math.round(((i + 1) / numBlocks) * 45));
      setProgressLabel(`Writing block ${i+1}/${numBlocks}`);
    }
    return true;
  }, [protocol, addLog]);

  // ─── Main Clone Workflow ────────────────────────────────────────────────────
  const runClone = useCallback(async () => {
    if (!isConnected) { toast.error("OBD adapter not connected"); return; }
    const vinErr = validateVIN(targetVIN.trim().toUpperCase());
    if (vinErr) { setVinError(vinErr); return; }
    setVinError(null);
    abortRef.current = false;

    const { txId, rxId, eepromBase, eepromSize, blockSize,
            vinOffset, secretKeyOffset, crcOffset, crcRegion,
            readAlgo, writeAlgo, readLevel, writeLevel } = variant;

    // Create session
    const { sessionId: _sid } = await createSessionMutation.mutateAsync({
      vin: targetVIN.trim().toUpperCase(),
      tool: `GatewayCloning-${variantId}`,
      adapterInfo: "WebSerial ELM327",
    });
    const sid: number = _sid ?? 0;
    setSessionId(sid);
    sidRef.current = sid;
    setLogs([]);
    logBuffer.current = [];

    try {
      // ── Step 1: Detect & identify ──────────────────────────────────────────
      setStep("detecting");
      setProgress(2);
      setProgressLabel("Starting diagnostic session...");
      addLog("INFO", `=== Gateway Cloning: ${variant.name} ===`);
      addLog("INFO", `TX: 0x${txId.toString(16).toUpperCase()}  RX: 0x${rxId.toString(16).toUpperCase()}`);

      const sessResp = await protocol.startSession(txId, rxId, 0x03);
      if (!sessResp.success) {
        addLog("ERROR", `Failed to start extended session: ${sessResp.error}`);
        setStep("error"); return;
      }
      addLog("SUCCESS", "Extended diagnostic session started");

      // Read identity DIDs
      const readDIDStr = async (did: number): Promise<string> => {
        const r = await protocol.readDID(txId, rxId, did);
        if (!r.success || !r.data) return "";
        return r.data.slice(3).map(b => String.fromCharCode(b)).join("").replace(/\0/g, "").trim();
      };

      const partNumber  = await readDIDStr(0xF101);
      const serial      = await readDIDStr(0xF18C);
      const supplier    = await readDIDStr(0xF187);
      const hwVersion   = await readDIDStr(0xF1A0);
      const swVersion   = await readDIDStr(0xF189);
      const currentVIN  = await readDIDStr(0xF190);

      const info: ModuleInfo = { partNumber, serial, supplier, hwVersion, swVersion, vin: currentVIN };
      setModuleInfo(info);
      addLog("INFO", `Part#: ${partNumber || "N/A"}  Serial: ${serial || "N/A"}`);
      addLog("INFO", `HW: ${hwVersion || "N/A"}  SW: ${swVersion || "N/A"}`);
      addLog("INFO", `Current VIN: ${currentVIN || "(none)"}`);

      await saveSnapshotMutation.mutateAsync({
        sessionId: sid,
        moduleAddr: txId,
        moduleName: variant.name,
        snapshotType: "before",
        vin: currentVIN || undefined,
        partNumber: partNumber || undefined,
        serialNumber: serial || undefined,
        supplierCode: supplier || undefined,
        hwVersion: hwVersion || undefined,
        swVersion: swVersion || undefined,
      });

      await flushLogs(sid);

      // ── Step 2: Security access for read ──────────────────────────────────
      setProgress(8);
      setProgressLabel("Security access (read)...");
      const readAccess = await doSecurityAccess(txId, rxId, readLevel, readAlgo);
      if (!readAccess) { setStep("error"); return; }
      await flushLogs(sid);

      // ── Step 3: Read full EEPROM ───────────────────────────────────────────
      setStep("reading");
      setProgress(10);
      setProgressLabel("Reading EEPROM...");
      const eeprom = await readEEPROM(txId, rxId, eepromBase, eepromSize, blockSize);
      if (!eeprom) { setStep("error"); return; }
      setOriginalEEPROM(new Uint8Array(eeprom));
      addLog("SUCCESS", `EEPROM read complete: ${eepromSize} bytes`);
      await flushLogs(sid);

      // ── Step 4: Patch VIN + secret key ────────────────────────────────────
      setStep("patching");
      setProgress(52);
      setProgressLabel("Patching VIN and secret key...");
      const patched = new Uint8Array(eeprom);

      // Patch VIN (17 ASCII bytes)
      const vinUpper = targetVIN.trim().toUpperCase();
      for (let i = 0; i < 17; i++) {
        patched[vinOffset + i] = vinUpper.charCodeAt(i);
      }
      addLog("INFO", `VIN patched at offset 0x${vinOffset.toString(16).toUpperCase()}: ${vinUpper}`);

      // Patch secret key if provided
      if (secretKeyHex.trim()) {
        const keyBytes = secretKeyHex.trim().replace(/\s+/g, "").match(/.{1,2}/g)?.map(h => parseInt(h, 16)) ?? [];
        if (keyBytes.length === 16) {
          for (let i = 0; i < 16; i++) {
            patched[secretKeyOffset + i] = keyBytes[i]!;
          }
          addLog("INFO", `Secret key patched at offset 0x${secretKeyOffset.toString(16).toUpperCase()}`);
        } else {
          addLog("WARN", `Secret key ignored — expected 16 bytes, got ${keyBytes.length}`);
        }
      }

      // Recalculate CRC-16/CCITT-FALSE over the patched region
      const crcVal = crc16ccitt(patched, crcRegion[0], crcRegion[1] - crcRegion[0]);
      patched[crcOffset]     = (crcVal >> 8) & 0xFF;
      patched[crcOffset + 1] = crcVal & 0xFF;
      addLog("SUCCESS", `CRC-16/CCITT recalculated: 0x${crcVal.toString(16).toUpperCase().padStart(4, "0")} @ 0x${crcOffset.toString(16).toUpperCase()}`);
      setPatchedEEPROM(patched);
      await flushLogs(sid);

      // ── Step 5: Security access for write ─────────────────────────────────
      setProgress(54);
      setProgressLabel("Security access (write)...");
      const writeAccess = await doSecurityAccess(txId, rxId, writeLevel, writeAlgo);
      if (!writeAccess) { setStep("error"); return; }
      await flushLogs(sid);

      // ── Step 6: Write patched EEPROM back ─────────────────────────────────
      setStep("writing");
      setProgress(56);
      setProgressLabel("Writing patched EEPROM...");
      const writeOk = await writeEEPROM(txId, rxId, eepromBase, patched, blockSize);
      if (!writeOk) { setStep("error"); return; }
      addLog("SUCCESS", "EEPROM write complete");
      await flushLogs(sid);

      // ── Step 7: Reset and verify ───────────────────────────────────────────
      setStep("verifying");
      setProgress(96);
      setProgressLabel("Resetting module...");
      await protocol.ecuReset(txId, rxId, 0x01);
      addLog("INFO", "ECU reset sent — waiting 3 seconds for module restart...");
      await new Promise(r => setTimeout(r, 3000));

      setProgressLabel("Verifying VIN read-back...");
      await protocol.startSession(txId, rxId, 0x03);
      const verifyVIN = await readDIDStr(0xF190);
      if (verifyVIN.toUpperCase() === vinUpper) {
        addLog("SUCCESS", `VIN verified: ${verifyVIN} ✓`);
      } else {
        addLog("WARN", `VIN mismatch after write: expected ${vinUpper}, got ${verifyVIN || "(empty)"}`);
      }

      await saveSnapshotMutation.mutateAsync({
        sessionId: sid,
        moduleAddr: txId,
        moduleName: variant.name,
        snapshotType: "after",
        vin: verifyVIN || vinUpper,
        partNumber: partNumber || undefined,
        serialNumber: serial || undefined,
      });

      await completeSessionMutation.mutateAsync({
        sessionId: sid,
        summary: `Gateway clone complete. VIN: ${vinUpper}. Module: ${variant.name}.`,
        status: "completed",
      });
      await flushLogs(sid);

      setProgress(100);
      setProgressLabel("Clone complete");
      setStep("done");
      toast.success("Gateway clone complete — VIN written and verified");

    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      addLog("ERROR", `Fatal error: ${msg}`);
      await completeSessionMutation.mutateAsync({
        sessionId: sid,
        summary: `Gateway clone failed: ${msg}`,
        status: "failed",
      });
      await flushLogs(sid);
      setStep("error");
      toast.error(`Clone failed: ${msg}`);
    }
  }, [
    isConnected, targetVIN, secretKeyHex, variant, variantId,
    protocol, addLog, flushLogs, doSecurityAccess, readEEPROM, writeEEPROM,
    createSessionMutation, addLogBatchMutation, completeSessionMutation, saveSnapshotMutation,
  ]);

  // ─── Download EEPROM dump ──────────────────────────────────────────────────
  const downloadDump = useCallback((data: Uint8Array, label: string) => {
    const blob = new Blob([data.buffer as ArrayBuffer], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${variantId}_${label}_${Date.now()}.bin`;
    a.click();
    URL.revokeObjectURL(url);
  }, [variantId]);

  // ─── Status badge ──────────────────────────────────────────────────────────
  const statusBadge = () => {
    if (step === "done") return <Badge className="bg-green-500/20 text-green-400 border-green-500/40"><CheckCircle2 className="w-3 h-3 mr-1" />Complete</Badge>;
    if (step === "error") return <Badge className="bg-red-500/20 text-red-400 border-red-500/40"><XCircle className="w-3 h-3 mr-1" />Error</Badge>;
    if (step !== "idle") return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/40"><RefreshCw className="w-3 h-3 mr-1 animate-spin" />Running</Badge>;
    return <Badge className="bg-zinc-500/20 text-zinc-400 border-zinc-500/40">Idle</Badge>;
  };

  const isRunning = !["idle", "done", "error"].includes(step);

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link href="/module-cloning">
          <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-lg bg-red-500/20 border border-red-500/40 flex items-center justify-center">
            <Network className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white font-mono tracking-wide">GATEWAY CLONING</h1>
            <p className="text-xs text-zinc-400">GWAY / SGW / CGW / ADAS-GW — Full EEPROM read, patch, write-back</p>
          </div>
        </div>
        {statusBadge()}
      </div>

      {/* Connection warning */}
      {!isConnected && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 text-sm">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          OBD adapter not connected. Connect via the sidebar before running a clone operation.
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* ── Left column: Config ─────────────────────────────────────────── */}
        <div className="xl:col-span-1 space-y-4">

          {/* Variant selector */}
          <div className="srt-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300 uppercase tracking-wider">
              <Cpu className="w-4 h-4 text-red-400" />
              Gateway Variant
            </div>
            <Select value={variantId} onValueChange={v => setVariantId(v as GatewayVariantId)} disabled={isRunning}>
              <SelectTrigger className="bg-zinc-900 border-zinc-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-700">
                {GATEWAY_VARIANTS.map(v => (
                  <SelectItem key={v.id} value={v.id} className="text-white hover:bg-zinc-800">
                    {v.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-zinc-500">{variant.description}</p>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-zinc-900 rounded p-2">
                <div className="text-zinc-500">TX ID</div>
                <div className="text-green-400">0x{variant.txId.toString(16).toUpperCase()}</div>
              </div>
              <div className="bg-zinc-900 rounded p-2">
                <div className="text-zinc-500">RX ID</div>
                <div className="text-green-400">0x{variant.rxId.toString(16).toUpperCase()}</div>
              </div>
              <div className="bg-zinc-900 rounded p-2">
                <div className="text-zinc-500">EEPROM Size</div>
                <div className="text-blue-400">{(variant.eepromSize / 1024).toFixed(0)} KB</div>
              </div>
              <div className="bg-zinc-900 rounded p-2">
                <div className="text-zinc-500">Block Size</div>
                <div className="text-blue-400">{variant.blockSize} B</div>
              </div>
              <div className="bg-zinc-900 rounded p-2">
                <div className="text-zinc-500">VIN Offset</div>
                <div className="text-yellow-400">0x{variant.vinOffset.toString(16).toUpperCase()}</div>
              </div>
              <div className="bg-zinc-900 rounded p-2">
                <div className="text-zinc-500">Key Offset</div>
                <div className="text-yellow-400">0x{variant.secretKeyOffset.toString(16).toUpperCase()}</div>
              </div>
            </div>
          </div>

          {/* Target VIN */}
          <div className="srt-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300 uppercase tracking-wider">
              <Shield className="w-4 h-4 text-red-400" />
              Target VIN
            </div>
            <Input
              value={targetVIN}
              onChange={e => { setTargetVIN(e.target.value.toUpperCase()); setVinError(null); }}
              placeholder="1C4RJFBG5FC123456"
              maxLength={17}
              className="font-mono bg-zinc-900 border-zinc-700 text-white uppercase tracking-widest"
              disabled={isRunning}
            />
            {vinError && <p className="text-xs text-red-400">{vinError}</p>}
            {targetVIN.length === 17 && !vinError && (
              <p className="text-xs text-green-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Valid VIN
              </p>
            )}
          </div>

          {/* Secret Key */}
          <div className="srt-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-zinc-300 uppercase tracking-wider">
              <Shield className="w-4 h-4 text-orange-400" />
              Secret Key <span className="text-zinc-500 font-normal normal-case">(optional — 16 bytes hex)</span>
            </div>
            <Input
              value={secretKeyHex}
              onChange={e => setSecretKeyHex(e.target.value)}
              placeholder="A1 B2 C3 D4 E5 F6 07 08 09 0A 0B 0C 0D 0E 0F 10"
              className="font-mono bg-zinc-900 border-zinc-700 text-white text-xs"
              disabled={isRunning}
            />
            <p className="text-xs text-zinc-500">
              Leave blank to preserve the existing secret key from the donor EEPROM.
            </p>
          </div>

          {/* Security info */}
          <div className="srt-card p-4 space-y-2">
            <div className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Security Algorithms</div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Read (level 0x{variant.readLevel.toString(16).toUpperCase()})</span>
              <span className="text-cyan-400 font-mono">{variant.readAlgo.toUpperCase()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">Write (level 0x{variant.writeLevel.toString(16).toUpperCase()})</span>
              <span className="text-red-400 font-mono">{variant.writeAlgo.toUpperCase()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">CRC Algorithm</span>
              <span className="text-yellow-400 font-mono">CRC-16/CCITT-FALSE</span>
            </div>
          </div>

          {/* Module info (after detection) */}
          {moduleInfo && (
            <div className="srt-card p-4 space-y-2">
              <div className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Module Identity</div>
              {[
                ["Part #", moduleInfo.partNumber],
                ["Serial", moduleInfo.serial],
                ["Supplier", moduleInfo.supplier],
                ["HW Ver", moduleInfo.hwVersion],
                ["SW Ver", moduleInfo.swVersion],
                ["Current VIN", moduleInfo.vin],
              ].map(([label, value]) => value ? (
                <div key={label} className="flex justify-between text-xs">
                  <span className="text-zinc-500">{label}</span>
                  <span className="text-white font-mono">{value}</span>
                </div>
              ) : null)}
            </div>
          )}

          {/* Run button */}
          <Button
            onClick={runClone}
            disabled={isRunning || !isConnected || targetVIN.length !== 17}
            className="w-full bg-red-600 hover:bg-red-500 text-white font-bold font-mono uppercase tracking-widest h-12"
          >
            {isRunning ? (
              <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />{progressLabel}</>
            ) : (
              <><Play className="w-4 h-4 mr-2" />Run Gateway Clone</>
            )}
          </Button>

          {isRunning && (
            <Button
              variant="outline"
              onClick={() => { abortRef.current = true; }}
              className="w-full border-red-500/40 text-red-400 hover:bg-red-500/10"
            >
              Abort
            </Button>
          )}
        </div>

        {/* ── Right column: Progress + Logs + Diff ────────────────────────── */}
        <div className="xl:col-span-2 space-y-4">

          {/* Progress */}
          {step !== "idle" && (
            <div className="srt-card p-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-300 font-mono">{progressLabel}</span>
                <span className="text-red-400 font-mono font-bold">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2 bg-zinc-800" />
              <div className="grid grid-cols-7 gap-1 text-xs text-center">
                {(["detecting","reading","patching","writing","verifying","done"] as Step[]).map((s, i) => (
                  <div key={s} className={`rounded px-1 py-0.5 font-mono uppercase ${
                    step === s ? "bg-red-500/30 text-red-400 border border-red-500/50" :
                    (["detecting","reading","patching","writing","verifying","done"] as Step[]).indexOf(step) > i
                      ? "bg-green-500/20 text-green-400" : "bg-zinc-800 text-zinc-600"
                  }`}>
                    {s === "detecting" ? "detect" : s === "verifying" ? "verify" : s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* EEPROM Diff */}
          {originalEEPROM && patchedEEPROM && (
            <div className="srt-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold text-zinc-300 uppercase tracking-wider">EEPROM Diff</div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDiff(!showDiff)}
                    className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs"
                  >
                    {showDiff ? "Hide Diff" : "Show Diff"}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadDump(originalEEPROM, "original")}
                    className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs"
                  >
                    <Download className="w-3 h-3 mr-1" />Original
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadDump(patchedEEPROM, "patched")}
                    className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs"
                  >
                    <Upload className="w-3 h-3 mr-1" />Patched
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const csvRows = ["Offset,Original,Patched,Changed"];
                      for (let i = 0; i < originalEEPROM.length; i++) {
                        if (originalEEPROM[i] !== patchedEEPROM[i]) {
                          csvRows.push(`0x${i.toString(16).toUpperCase().padStart(4,"0")},0x${originalEEPROM[i]!.toString(16).padStart(2,"0").toUpperCase()},0x${patchedEEPROM[i]!.toString(16).padStart(2,"0").toUpperCase()},true`);
                        }
                      }
                      const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url; a.download = `${variantId}_diff_${Date.now()}.csv`; a.click();
                      URL.revokeObjectURL(url);
                    }}
                    className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs"
                  >
                    <FileDown className="w-3 h-3 mr-1" />CSV
                  </Button>
                </div>
              </div>
              {showDiff && (
                <EEPROMDiffViewer
                  oldData={originalEEPROM}
                  newData={patchedEEPROM}
                  label={`${variant.name} EEPROM`}
                />
              )}
            </div>
          )}

          {/* UDS Log */}
          <div className="srt-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold text-zinc-300 uppercase tracking-wider">
                UDS Traffic Log
                {sessionId && <span className="ml-2 text-xs text-zinc-500 font-normal normal-case">Session #{sessionId}</span>}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLogs([])}
                className="text-zinc-500 hover:text-white text-xs"
              >
                Clear
              </Button>
            </div>
            <VirtualUDSLog entries={logs} maxHeight="320px" />
          </div>
        </div>
      </div>
    </div>
  );
}
