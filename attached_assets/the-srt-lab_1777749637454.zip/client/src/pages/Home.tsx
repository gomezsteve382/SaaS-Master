import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import {
  Zap, ArrowRight, Cpu, Key, Scan, AlertTriangle, Radio,
  Eye, Navigation, Trash2, Car, Settings, Monitor, Database,
} from "lucide-react";

const tools = [
  {
    name: "VIN Commander",
    path: "/vin-commander",
    description: "One-button VIN programming over OBD. Scan → select → write. RFHUB virginizer. Bench editor for BCM/ECM/RFHUB EEPROMs.",
    icon: Car, color: "text-red-500", bg: "bg-red-50 dark:bg-red-950", border: "border-red-200 dark:border-red-800",
  },
  {
    name: "Key Programming",
    path: "/key-programming",
    description: "FOBIK key learn/erase/locate, PIN extraction from RFHUB (BCD/Binary/ASCII), SKIM unlock, up to 8 key slots.",
    icon: Key, color: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-950", border: "border-purple-200 dark:border-purple-800",
  },
  {
    name: "BCM Configuration",
    path: "/bcm-config",
    description: "4,826 BCM parameters from AlphaOBD. Lighting, locks, comfort, performance, SRT features. Read/write with security access.",
    icon: Settings, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-950", border: "border-blue-200 dark:border-blue-800",
  },
  {
    name: "Cluster & Uconnect",
    path: "/cluster-uconnect",
    description: "Startup screen (Demon/Hellcat/Scat Pack), gauge sweep, display units, SRT Performance Pages, custom HP/TQ display.",
    icon: Monitor, color: "text-orange-500", bg: "bg-orange-50 dark:bg-orange-950", border: "border-orange-200 dark:border-orange-800",
  },
  {
    name: "RFHUB Programming",
    path: "/rfhub-tool",
    description: "RF Hub module programming — detect, unlock via UDS security access, virginize, and reprogram with correct seed-key algorithms.",
    icon: Radio, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-950", border: "border-blue-200 dark:border-blue-800",
  },
  {
    name: "RFHUB Virginizer",
    path: "/rfhub-virginizer",
    description: "Reset RFHUB EEE dumps to factory-blank state. Clears VINs, secret key, fob data, CRC checksums. Bench operation only.",
    icon: Trash2, color: "text-red-500", bg: "bg-red-50 dark:bg-red-950", border: "border-red-200 dark:border-red-800",
  },
  {
    name: "Proxy Alignment",
    path: "/proxy-alignment",
    description: "Steering angle sensor calibration via EPS (0x75F). Routine 0x0301 clear + 0x0302 align with full UDS log.",
    icon: Navigation, color: "text-green-500", bg: "bg-green-50 dark:bg-green-950", border: "border-green-200 dark:border-green-800",
  },
  {
    name: "Module Scanner",
    path: "/module-scanner",
    description: "Scan CAN bus for all 90+ FCA modules. Quick scan or full sweep. VIN read, DTC count, mismatch detection.",
    icon: Scan, color: "text-green-500", bg: "bg-green-50 dark:bg-green-950", border: "border-green-200 dark:border-green-800",
  },
  {
    name: "DTC Reader",
    path: "/dtc-reader",
    description: "Read and clear diagnostic trouble codes. 22,166 decrypted AlphaOBD DTCs with severity classification.",
    icon: AlertTriangle, color: "text-orange-500", bg: "bg-orange-50 dark:bg-orange-950", border: "border-orange-200 dark:border-orange-800",
  },
  {
    name: "Seed-Key Calculator",
    path: "/seed-key-calculator",
    description: "18-algorithm waterfall: CDA6 L1-L11, SBEC2, NGC3/4, SKIM/WCM, XTEA, ROL5, RFHUB RH850. GPEC2–GPEC4LM.",
    icon: Key, color: "text-cyan-500", bg: "bg-cyan-50 dark:bg-cyan-950", border: "border-cyan-200 dark:border-cyan-800",
  },
  {
    name: "EEPROM Viewer",
    path: "/eeprom-viewer",
    description: "Hex viewer with auto-highlighting of VIN, secret key, SKIM pairing, CRC offsets. BCM, RFHUB, ECM, FCA 95640.",
    icon: Eye, color: "text-cyan-500", bg: "bg-cyan-50 dark:bg-cyan-950", border: "border-cyan-200 dark:border-cyan-800",
  },
  {
    name: "Live VIN Programmer",
    path: "/live-programmer",
    description: "Legacy OBD2 VIN programming via ELM327, J2534, or Arduino CAN. Module scanning and multi-module write.",
    icon: Cpu, color: "text-gray-500", bg: "bg-gray-50 dark:bg-gray-950", border: "border-gray-200 dark:border-gray-800",
  },
  {
    name: "Database Explorer",
    path: "/db-explorer",
    description: "Search all 34,625 parameters in AlphaOBD database. Find any DID, routine, DTC, or parameter by name.",
    icon: Database, color: "text-indigo-500", bg: "bg-indigo-50 dark:bg-indigo-950", border: "border-indigo-200 dark:border-indigo-800",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      <div className="relative overflow-hidden bg-gradient-to-r from-black via-gray-900 to-red-950 text-white">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30"></div>
        <div className="container relative py-16 md:py-20">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-red-600/20 border border-red-600 px-4 py-2 rounded-full mb-6 animate-pulse">
              <Zap className="w-4 h-4 text-red-500" />
              <span className="text-sm font-bold uppercase tracking-wide">13 Tools · 34,625+ Parameters · 22,166 DTCs · 10 Databases</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tight mb-4 bg-gradient-to-r from-white via-red-200 to-red-600 bg-clip-text text-transparent">
              THE SRT LAB
            </h1>
            <p className="text-xl md:text-2xl font-bold text-red-500 mb-4 uppercase tracking-wide">
              Diagnostic Command Center
            </p>
            <p className="text-lg text-gray-300 max-w-2xl">
              Complete diagnostic and programming platform for Chrysler/FCA/Stellantis. Access 34,625+ parameters across 10 Alpha OBD databases: BCM (4,826), Engine (4,427), Petrol (5,099), IPC (1,389), ABS (4,089), plus 22,166 decrypted DTCs. VIN programming, key programming, BCM configuration, RFHUB virginizing, proxy alignment. Connects via OBDLink EX / ELM327.
            </p>
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Link key={tool.path} href={tool.path}>
                <Card className={`hover:shadow-lg transition-all cursor-pointer h-full ${tool.border} hover:scale-[1.02]`}>
                  <CardHeader>
                    <div className="flex items-start gap-3">
                      <div className={`p-3 rounded-lg ${tool.bg}`}>
                        <Icon className={`h-6 w-6 ${tool.color}`} />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg flex items-center gap-2">
                          {tool.name}
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        </CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm leading-relaxed">
                      {tool.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
