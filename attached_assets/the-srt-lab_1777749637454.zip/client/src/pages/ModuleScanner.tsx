import { useState, useCallback, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Scan, Loader2, AlertTriangle, Zap, Radio, Download, Trash2, Wifi, WifiOff, Search, CheckCircle2, Layers } from "lucide-react";
import { toast } from "sonner";
import { runSwarmScan, FCA_MODULE_MAP, QUICK_SCAN_MODULES, type SwarmResult } from "@/lib/swarmScanner";

// 90+ known FCA modules
const KNOWN_MODULES = [
  { code: "PCM", name: "Powertrain Control Module", tx: 0x7E0, rx: 0x7E8 },
  { code: "TCM", name: "Transmission Control Module", tx: 0x7E1, rx: 0x7E9 },
  { code: "BCM", name: "Body Control Module", tx: 0x742, rx: 0x762 },
  { code: "RFHUB", name: "RF Hub Module", tx: 0x75F, rx: 0x767 },
  { code: "ABS/ESC", name: "Anti-Lock Brake / Stability Control", tx: 0x760, rx: 0x768 },
  { code: "SCCM", name: "Steering Column Control Module", tx: 0x744, rx: 0x764 },
  { code: "HVAC", name: "Heating / Ventilation / AC", tx: 0x743, rx: 0x763 },
  { code: "IPC", name: "Instrument Panel Cluster", tx: 0x745, rx: 0x765 },
  { code: "SKIM", name: "Sentry Key Immobilizer Module", tx: 0x744, rx: 0x764 },
  { code: "ECM", name: "Engine Control Module", tx: 0x7E0, rx: 0x7E8 },
  { code: "EPS", name: "Electric Power Steering", tx: 0x75F, rx: 0x767 },
  { code: "TPMS", name: "Tire Pressure Monitoring System", tx: 0x747, rx: 0x757 },
  { code: "ORC", name: "Occupant Restraint Controller", tx: 0x740, rx: 0x760 },
  { code: "RADIO", name: "Radio / Infotainment", tx: 0x772, rx: 0x77A },
  { code: "GATEWY", name: "CAN Gateway Module", tx: 0x6C0, rx: 0x6C8 },
  { code: "FCIM", name: "Front Control Interface Module", tx: 0x773, rx: 0x77B },
  { code: "HVAC2", name: "Rear HVAC Module", tx: 0x74B, rx: 0x76B },
  { code: "PDM", name: "Power Distribution Module", tx: 0x74C, rx: 0x76C },
  { code: "SUNROOF", name: "Sunroof Module", tx: 0x74D, rx: 0x76D },
  { code: "TRAILER", name: "Trailer Tow Module", tx: 0x74E, rx: 0x76E },
  { code: "PARK", name: "Park Assist Module", tx: 0x74F, rx: 0x76F },
  { code: "CAMERA", name: "Rear Camera Module", tx: 0x750, rx: 0x758 },
  { code: "SEAT_L", name: "Left Seat Module", tx: 0x751, rx: 0x759 },
  { code: "SEAT_R", name: "Right Seat Module", tx: 0x752, rx: 0x75A },
  { code: "MIRROR", name: "Mirror Control Module", tx: 0x753, rx: 0x75B },
  { code: "DOOR_FL", name: "Front Left Door Module", tx: 0x754, rx: 0x75C },
  { code: "DOOR_FR", name: "Front Right Door Module", tx: 0x755, rx: 0x75D },
  { code: "DOOR_RL", name: "Rear Left Door Module", tx: 0x756, rx: 0x75E },
  { code: "DOOR_RR", name: "Rear Right Door Module", tx: 0x757, rx: 0x75F },
  { code: "FUEL", name: "Fuel Pump Control Module", tx: 0x758, rx: 0x760 },
  { code: "TRANS_AUX", name: "Transfer Case Module", tx: 0x759, rx: 0x761 },
  { code: "ACTIVE_SUSP", name: "Active Suspension Module", tx: 0x75A, rx: 0x762 },
  { code: "LAUNCH", name: "Launch Control Module", tx: 0x75B, rx: 0x763 },
  { code: "EXHAUST", name: "Active Exhaust Module", tx: 0x75C, rx: 0x764 },
  { code: "COOLING", name: "Active Cooling Module", tx: 0x75D, rx: 0x765 },
  { code: "BRAKE_AUX", name: "Brake Assist Module", tx: 0x75E, rx: 0x766 },
];

interface ScannedModule {
  code: string;
  name: string;
  tx: number;
  rx: number;
  vin: string | null;
  dtcCount: number;
  status: "ok" | "mismatch" | "no_vin";
  responseTime: number;
}

interface LogEntry { msg: string; level: string; time: string; }
function hex(n: number) { return `0x${n.toString(16).toUpperCase().padStart(3, "0")}`; }

export default function ModuleScanner() {
  const [scanMode, setScanMode] = useState<"quick" | "full" | "swarm">("swarm");
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [scannedModules, setScannedModules] = useState<ScannedModule[]>([]);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [filter, setFilter] = useState("");
  const [currentAddr, setCurrentAddr] = useState<number | null>(null);
  const [referenceVin, setReferenceVin] = useState<string | null>(null);
  const abortRef = useRef(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((msg: string, level = "info") => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    setLog(prev => [...prev.slice(-299), { msg, level, time }]);
    setTimeout(() => logEndRef.current?.scrollIntoView({ behavior: "smooth" }), 30);
  }, []);

  const runScan = useCallback(async () => {
    if (!isConnected) { toast.error("Connect OBD adapter first"); return; }
    abortRef.current = false;
    setScanning(true);
    setScannedModules([]);
    setLog([]);
    setProgress(0);
    setReferenceVin(null);
    let firstVin: string | null = null;

    if (scanMode === "swarm") {
      // Parallel swarm scan — 4 concurrent workers
      addLog(`━━━ SWARM SCAN — ${QUICK_SCAN_MODULES.length} MODULES × 4 CONCURRENT WORKERS ━━━`, "info");
      const abortController = new AbortController();
      const swarmResults: SwarmResult[] = [];
      await runSwarmScan(
        protocol,
        QUICK_SCAN_MODULES,
        (completed, total, found, active) => {
          setProgress((completed / total) * 100);
          if (active.length > 0) setCurrentAddr(active[0].txId);
          // Sync found modules to state
          const newModules: ScannedModule[] = found.map(r => ({
            code: r.label,
            name: r.label,
            tx: r.txId,
            rx: r.rxId,
            vin: r.vin || null,
            dtcCount: r.dtcCount || 0,
            status: r.vin && firstVin && r.vin !== firstVin ? "mismatch" : r.vin ? "ok" : "no_vin",
            responseTime: r.responseTimeMs,
          }));
          if (found.length > swarmResults.length) {
            const newest = found[found.length - 1];
            if (newest.vin && !firstVin) { firstVin = newest.vin; setReferenceVin(newest.vin); }
            addLog(`⚡ SWARM → TX:0x${newest.txId.toString(16).toUpperCase()} [${newest.label}] ✓ ${newest.responseTimeMs}ms${newest.vin ? ` VIN:${newest.vin}` : ""}${newest.partNumber ? ` PN:${newest.partNumber}` : ""}${newest.dtcCount ? ` DTCs:${newest.dtcCount}` : ""}`, "rx");
            swarmResults.push(newest);
          }
          setScannedModules(newModules);
        },
        4,
        abortController.signal
      );
      addLog(`\n━━━ SWARM SCAN COMPLETE — ${swarmResults.length} modules found ━━━`, "success");
      toast.success(`Swarm found ${swarmResults.length} module(s)`);
    } else if (scanMode === "quick") {
      addLog(`━━━ QUICK SCAN — ${KNOWN_MODULES.length} KNOWN MODULES ━━━`, "info");
      const found: ScannedModule[] = [];
      for (let i = 0; i < KNOWN_MODULES.length; i++) {
        if (abortRef.current) { addLog("Scan aborted", "info"); break; }
        const mod = KNOWN_MODULES[i];
        setProgress(((i + 1) / KNOWN_MODULES.length) * 100);
        setCurrentAddr(mod.tx);
        addLog(`TX → ${hex(mod.tx)}: Tester Present [${mod.code}]`, "tx");
        const t0 = Date.now();
        const alive = await protocol.pingModule(mod.tx, mod.rx);
        const responseTime = Date.now() - t0;
        if (alive) {
          addLog(`RX ← ${hex(mod.rx)}: ✓ ${responseTime}ms`, "rx");
          await protocol.startSession(mod.tx, mod.rx, 0x03);
          const vin = await protocol.readVIN(mod.tx, mod.rx);
          if (vin && !firstVin) { firstVin = vin; setReferenceVin(vin); }
          const dtcResp = await protocol.readDTCs(mod.tx, mod.rx);
          const dtcCount = dtcResp.success && dtcResp.data ? Math.floor((dtcResp.data.length - 1) / 4) : 0;
          const vinMismatch = !!(vin && firstVin && vin !== firstVin);
          if (vin) addLog(`RX ← ${hex(mod.rx)}: VIN = ${vin}${vinMismatch ? " ⚠ MISMATCH" : " ✓"}`, vinMismatch ? "warning" : "rx");
          if (dtcCount > 0) addLog(`[${mod.code}] DTCs: ${dtcCount}`, "info");
          found.push({ ...mod, vin, dtcCount, status: vinMismatch ? "mismatch" : vin ? "ok" : "no_vin", responseTime });
          setScannedModules([...found]);
        } else {
          addLog(`   ${mod.code} — no response`, "info");
        }
      }
      addLog(`\n━━━ QUICK SCAN COMPLETE — ${found.length} modules found ━━━`, "success");
      toast.success(`Found ${found.length} module(s)`);
    } else {
      addLog("━━━ FULL SWEEP 0x600–0x7FF ━━━", "info");
      const found: ScannedModule[] = [];
      const total = 0x7FF - 0x600 + 1;
      for (let addr = 0x600; addr <= 0x7FF; addr++) {
        if (abortRef.current) { addLog("Scan aborted", "info"); break; }
        setProgress(((addr - 0x600) / total) * 100);
        setCurrentAddr(addr);
        const t0 = Date.now();
        const alive = await protocol.pingModule(addr, addr + 8);
        const responseTime = Date.now() - t0;
        if (alive) {
          const known = KNOWN_MODULES.find(m => m.tx === addr);
          addLog(`TX → ${hex(addr)}: ✓ ${responseTime}ms ${known ? `[${known.code}]` : "[UNKNOWN]"}`, "rx");
          await protocol.startSession(addr, addr + 8, 0x03);
          const vin = await protocol.readVIN(addr, addr + 8);
          if (vin && !firstVin) { firstVin = vin; setReferenceVin(vin); }
          const dtcResp2 = await protocol.readDTCs(addr, addr + 8);
          const dtcCount = dtcResp2.success && dtcResp2.data ? Math.floor((dtcResp2.data.length - 1) / 4) : 0;
          const vinMismatch = !!(vin && firstVin && vin !== firstVin);
          found.push({
            code: known?.code || `UNK_${addr.toString(16).toUpperCase()}`,
            name: known?.name || `Unknown @ ${hex(addr)}`,
            tx: addr, rx: addr + 8, vin, dtcCount,
            status: vinMismatch ? "mismatch" : vin ? "ok" : "no_vin",
            responseTime,
          });
          setScannedModules([...found]);
        }
      }
      addLog(`\n━━━ FULL SWEEP COMPLETE — ${found.length} modules found ━━━`, "success");
      toast.success(`Found ${found.length} module(s)`);
    }

    setScanning(false);
    setCurrentAddr(null);
  }, [isConnected, protocol, scanMode, addLog]);

  const filtered = scannedModules.filter(m =>
    !filter || m.code.toLowerCase().includes(filter.toLowerCase()) || m.name.toLowerCase().includes(filter.toLowerCase())
  );

  const mismatches = scannedModules.filter(m => m.status === "mismatch");
  const totalDTCs = scannedModules.reduce((sum, m) => sum + m.dtcCount, 0);

  return (
    <div className="min-h-full">
      <div className="page-header px-6 py-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="flex items-center justify-center w-9 h-9 rounded bg-green-600/20 border border-green-600/40">
                <Scan className="w-5 h-5 text-green-400" />
              </div>
              <h1 className="text-2xl font-black uppercase tracking-tight text-white">Module Scanner</h1>
              <span className="jailbreak-badge">⚡ CAN BUS</span>
            </div>
            <p className="text-sm text-muted-foreground">⚡ Swarm (4 parallel workers) · Quick scan 36 known modules · Full sweep 0x600–0x7FF · VIN · DTC count · Part# · Serial</p>
          </div>
          {scannedModules.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              <Badge variant="outline" className="font-mono text-xs border-green-900 text-green-400">{scannedModules.length} found</Badge>
              {mismatches.length > 0 && <Badge variant="outline" className="font-mono text-xs border-yellow-900 text-yellow-400">{mismatches.length} mismatches</Badge>}
              {totalDTCs > 0 && <Badge variant="outline" className="font-mono text-xs border-orange-900 text-orange-400">{totalDTCs} DTCs</Badge>}
            </div>
          )}
        </div>
      </div>

      <div className="container py-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Left */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="border-border bg-card">
              <CardHeader className="pb-3"><CardTitle className="text-sm">Scan Mode</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setScanMode("swarm")}
                    className={`p-3 rounded border text-xs font-semibold transition-all ${
                      scanMode === "swarm"
                        ? "border-red-700 bg-red-900/20 text-red-400"
                        : "border-border bg-muted/20 text-muted-foreground hover:border-border"
                    }`}
                  >
                    <Layers className="w-4 h-4 mx-auto mb-1" />
                    ⚡ Swarm
                    <div className="text-[10px] font-normal mt-0.5">4× parallel</div>
                  </button>
                  <button
                    onClick={() => setScanMode("quick")}
                    className={`p-3 rounded border text-xs font-semibold transition-all ${
                      scanMode === "quick"
                        ? "border-green-700 bg-green-900/20 text-green-400"
                        : "border-border bg-muted/20 text-muted-foreground hover:border-border"
                    }`}
                  >
                    <Zap className="w-4 h-4 mx-auto mb-1" />
                    Quick
                    <div className="text-[10px] font-normal mt-0.5">36 modules</div>
                  </button>
                  <button
                    onClick={() => setScanMode("full")}
                    className={`p-3 rounded border text-xs font-semibold transition-all ${
                      scanMode === "full"
                        ? "border-green-700 bg-green-900/20 text-green-400"
                        : "border-border bg-muted/20 text-muted-foreground hover:border-border"
                    }`}
                  >
                    <Radio className="w-4 h-4 mx-auto mb-1" />
                    Full Sweep
                    <div className="text-[10px] font-normal mt-0.5">0x600–0x7FF</div>
                  </button>
                </div>

                {scanning && (
                  <div className="space-y-1.5">
                    <Progress value={progress} className="h-1.5" />
                    <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
                      <span>{Math.round(progress)}%</span>
                      {currentAddr && <span>Scanning {hex(currentAddr)}</span>}
                    </div>
                  </div>
                )}

                <Button
                  size="lg"
                  className="w-full bg-green-700 hover:bg-green-800 text-white font-bold uppercase"
                  onClick={runScan}
                  disabled={scanning}
                >
                  {scanning
                    ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Scanning...</>
                    : <><Scan className="w-4 h-4 mr-2" />{scanMode === "quick" ? "Quick Scan" : "Full Sweep"}</>
                  }
                </Button>
              </CardContent>
            </Card>

            {/* Log */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3"><CardTitle className="text-sm">CAN Log</CardTitle></CardHeader>
              <CardContent>
                <div className="h-[320px] overflow-y-auto font-mono text-[10px] bg-black/40 rounded p-2 space-y-0.5">
                  {log.length === 0 && <div className="text-center text-muted-foreground py-8">Start scan to see CAN traffic</div>}
                  {log.map((e, i) => (
                    <div key={i} className={`py-0.5 ${
                      e.level === "tx" ? "log-tx" : e.level === "rx" ? "log-rx" :
                      e.level === "success" ? "log-success" : e.level === "warning" ? "log-warning" : "log-dim"
                    }`}>
                      <span className="log-dim mr-1">{e.time}</span>{e.msg}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            <Card className="border-border bg-card h-full">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-3">
                  <CardTitle className="text-sm">
                    Discovered Modules {scannedModules.length > 0 && `(${filtered.length})`}
                  </CardTitle>
                  {scannedModules.length > 0 && (
                    <div className="relative">
                      <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
                      <Input
                        value={filter}
                        onChange={e => setFilter(e.target.value)}
                        placeholder="Filter..."
                        className="pl-7 h-7 text-xs bg-muted border-border w-32"
                      />
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {scannedModules.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-[480px] text-muted-foreground">
                    <Scan className="w-12 h-12 mb-3 opacity-20" />
                    <p className="text-sm">Run a scan to discover modules</p>
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-[520px] overflow-y-auto pr-1">
                    {filtered.map((m, i) => (
                      <div key={i} className={`flex items-center gap-3 px-3 py-2.5 rounded border text-xs ${
                        m.status === "mismatch"
                          ? "border-yellow-900/50 bg-yellow-900/10"
                          : "border-border bg-muted/20"
                      }`}>
                        <div className={`w-2 h-2 rounded-full shrink-0 ${
                          m.status === "ok" ? "bg-green-500" :
                          m.status === "mismatch" ? "bg-yellow-500" : "bg-blue-500"
                        }`} />
                        <div className="font-mono font-bold w-20 shrink-0 text-foreground">{m.code}</div>
                        <div className="flex-1 min-w-0">
                          <div className="text-foreground truncate">{m.name}</div>
                          <div className="font-mono text-[10px] text-muted-foreground">
                            TX:{hex(m.tx)} RX:{hex(m.rx)} · {m.responseTime}ms
                          </div>
                        </div>
                        <div className="text-right shrink-0 space-y-0.5">
                          {m.vin ? (
                            <div className={`font-mono text-[10px] ${m.status === "mismatch" ? "text-yellow-400" : "text-green-400"}`}>
                              {m.vin.slice(0, 8)}…
                            </div>
                          ) : (
                            <div className="text-[10px] text-muted-foreground">No VIN</div>
                          )}
                          {m.dtcCount > 0 && (
                            <div className="text-[10px] text-orange-400">{m.dtcCount} DTC{m.dtcCount !== 1 ? "s" : ""}</div>
                          )}
                        </div>
                        {m.status === "mismatch" && (
                          <AlertTriangle className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
                        )}
                        {m.status === "ok" && m.vin && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-400 shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
