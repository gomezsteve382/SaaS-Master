import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  History, Search, ChevronDown, ChevronRight, Clock, Cpu,
  CheckCircle2, XCircle, AlertTriangle, GitCompare, Layers
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import ModulePickerDialog, { type ModulePairEntry } from "@/components/ModulePickerDialog";

const TOOL_COLORS: Record<string, string> = {
  VINCommander: "bg-red-900/40 text-red-300 border-red-700",
  DTCReader: "bg-orange-900/40 text-orange-300 border-orange-700",
  "DTCReader-Clear": "bg-yellow-900/40 text-yellow-300 border-yellow-700",
  ModuleScanner: "bg-green-900/40 text-green-300 border-green-700",
  KeyProgramming: "bg-blue-900/40 text-blue-300 border-blue-700",
  ProxyAlignment: "bg-purple-900/40 text-purple-300 border-purple-700",
  RFHUBVirginizer: "bg-pink-900/40 text-pink-300 border-pink-700",
  BCMConfiguration: "bg-teal-900/40 text-teal-300 border-teal-700",
  GatewayCloning: "bg-red-900/40 text-red-300 border-red-700",
  ModuleCloning: "bg-red-900/40 text-red-300 border-red-700",
  ECMCalibration: "bg-emerald-900/40 text-emerald-300 border-emerald-700",
};

const DIR_STYLES: Record<string, string> = {
  tx: "text-blue-400",
  rx: "text-green-400",
  info: "text-zinc-400",
  success: "text-green-300",
  error: "text-red-400",
  warning: "text-yellow-400",
};

const DIR_PREFIX: Record<string, string> = {
  tx: "→ TX",
  rx: "← RX",
  info: "  ℹ",
  success: "  ✓",
  error: "  ✗",
  warning: "  ⚠",
};

// Tools that are known to produce module snapshots
const SNAPSHOT_TOOLS = new Set([
  "VINCommander", "BCMConfiguration", "GatewayCloning", "ModuleCloning", "ECMCalibration"
]);

// ─── Expanded Session Logs ────────────────────────────────────────────────────
function SessionLogs({ sessionId }: { sessionId: number }) {
  const { data: logs, isLoading } = trpc.sessions.getLogs.useQuery({ sessionId });

  if (isLoading) {
    return (
      <div className="border-t border-zinc-800 p-4 text-center text-zinc-500 text-xs font-mono">
        Loading logs...
      </div>
    );
  }
  if (!logs || logs.length === 0) {
    return (
      <div className="border-t border-zinc-800 p-4 text-center text-zinc-600 text-xs font-mono">
        No log entries
      </div>
    );
  }
  return (
    <div className="border-t border-zinc-800 bg-black/30 p-4">
      <div className="font-mono text-xs space-y-0.5 max-h-80 overflow-y-auto">
        {logs.map((entry, i) => (
          <div key={i} className={`flex gap-3 ${DIR_STYLES[entry.direction] ?? "text-zinc-400"}`}>
            <span className="shrink-0 w-14 text-right opacity-60">{DIR_PREFIX[entry.direction] ?? "  ·"}</span>
            <span className="flex-1">{entry.message}</span>
            {entry.data && <span className="text-zinc-600 truncate max-w-xs">{entry.data}</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Quick Compare Button ─────────────────────────────────────────────────────
// Fetches all module pairs for a session. If only one pair exists, navigates
// directly. If multiple modules are present, opens the ModulePickerDialog.
function QuickCompareButton({ sessionId }: { sessionId: number }) {
  const [, navigate] = useLocation();
  const [fetchEnabled, setFetchEnabled] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: pairs = [], isLoading } = trpc.sessions.getSessionModulePairs.useQuery(
    { sessionId },
    { enabled: fetchEnabled }
  );

  const handleClick = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();

    // If already fetched, act on it immediately
    if (fetchEnabled && !isLoading) {
      handlePairsReady(pairs);
      return;
    }

    // Trigger fetch — the useEffect-like logic runs on next render via the pairs watcher below
    setFetchEnabled(true);
  }, [fetchEnabled, isLoading, pairs]); // eslint-disable-line react-hooks/exhaustive-deps

  // Once data arrives after the user clicked, route appropriately
  const handlePairsReady = useCallback((resolvedPairs: ModulePairEntry[]) => {
    const completePairs = resolvedPairs.filter((p) => p.hasPair);

    if (completePairs.length === 0) {
      toast.warning("No before/after snapshot pair found for this session");
      return;
    }

    if (completePairs.length === 1) {
      // Single pair — navigate directly
      const p = completePairs[0];
      navigate(`/snapshot-comparison?a=${p.beforeId}&b=${p.afterId}`);
      return;
    }

    // Multiple pairs — open the module picker dialog
    setDialogOpen(true);
  }, [navigate]);

  // Watch for data arriving after the button click
  if (fetchEnabled && !isLoading && pairs.length >= 0 && !dialogOpen) {
    // Use a flag to avoid calling handlePairsReady on every render
    // We only want to fire once when data first arrives
  }

  // Trigger navigation/dialog as soon as fetch completes
  const [handled, setHandled] = useState(false);
  if (fetchEnabled && !isLoading && !handled && !dialogOpen) {
    setHandled(true);
    // Defer to avoid setState-in-render
    setTimeout(() => handlePairsReady(pairs), 0);
  }

  const handleSelect = useCallback((beforeId: number, afterId: number) => {
    navigate(`/snapshot-comparison?a=${beforeId}&b=${afterId}`);
  }, [navigate]);

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        className={cn(
          "h-7 px-2.5 text-xs border-indigo-500/40 text-indigo-400 hover:bg-indigo-950/30 hover:text-indigo-300 hover:border-indigo-400/60 shrink-0",
          isLoading && "opacity-60 cursor-wait"
        )}
        onClick={handleClick}
        disabled={isLoading}
        title="Quick Compare — auto-load before/after snapshots for this session"
      >
        <GitCompare className={cn("w-3 h-3 mr-1", isLoading && "animate-pulse")} />
        {isLoading ? "Loading..." : "Quick Compare"}
      </Button>

      <ModulePickerDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) {
            // Reset so the button can be clicked again
            setHandled(false);
          }
        }}
        sessionId={sessionId}
        pairs={pairs}
        isLoading={isLoading}
        onSelect={handleSelect}
      />
    </>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function SessionHistory() {
  const [vinFilter, setVinFilter] = useState("");
  const [debouncedVin, setDebouncedVin] = useState("");
  const [expandedSessions, setExpandedSessions] = useState<Set<number>>(new Set());
  const [debounceTimer, setDebounceTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  const { data: recentSessions, isLoading: recentLoading } = trpc.sessions.recent.useQuery({ limit: 50 });
  const { data: vinSessions, isLoading: vinLoading } = trpc.sessions.byVin.useQuery(
    { vin: debouncedVin, limit: 50 },
    { enabled: !!debouncedVin }
  );
  const sessions = debouncedVin ? vinSessions : recentSessions;
  const isLoading = debouncedVin ? vinLoading : recentLoading;

  const handleVinChange = (val: string) => {
    setVinFilter(val);
    if (debounceTimer) clearTimeout(debounceTimer);
    const t = setTimeout(() => setDebouncedVin(val), 300);
    setDebounceTimer(t);
  };

  const toggleSession = (id: number) => {
    setExpandedSessions(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const formatDuration = (start: Date, end?: Date | null) => {
    if (!end) return "—";
    const ms = new Date(end).getTime() - new Date(start).getTime();
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white font-mono tracking-wider">SESSION HISTORY</h1>
          <p className="text-zinc-400 text-sm mt-1">Per-VIN audit trail of all diagnostic operations</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-zinc-800 text-zinc-300 border-zinc-600 font-mono">
            <History className="w-3 h-3 mr-1" />{sessions?.length ?? 0} SESSIONS
          </Badge>
          <Badge variant="outline" className="border-indigo-500/40 text-indigo-400 text-xs font-mono">
            <GitCompare className="w-3 h-3 mr-1" /> MULTI-MODULE COMPARE
          </Badge>
        </div>
      </div>

      {/* Filter */}
      <Card className="bg-zinc-900 border-zinc-700">
        <CardContent className="p-4">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="relative max-w-sm flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                value={vinFilter}
                onChange={e => handleVinChange(e.target.value)}
                placeholder="Filter by VIN..."
                className="pl-9 bg-zinc-800 border-zinc-600 text-white placeholder:text-zinc-500 font-mono"
              />
            </div>
            <div className="flex items-center gap-2 text-xs text-zinc-500">
              <GitCompare className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                Click <span className="text-indigo-400 font-semibold">Quick Compare</span> on any session.
                Multiple modules? A picker dialog will appear.
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Session list */}
      {isLoading ? (
        <div className="p-12 text-center">
          <History className="w-8 h-8 text-srt-red animate-pulse mx-auto mb-4" />
          <p className="text-zinc-400 font-mono">Loading sessions...</p>
        </div>
      ) : sessions && sessions.length > 0 ? (
        <div className="space-y-2">
          {sessions!.map((session: typeof sessions extends (infer T)[] | undefined ? T : never) => {
            const expanded = expandedSessions.has(session.id);
            const mightHaveSnapshots = SNAPSHOT_TOOLS.has(session.tool);
            return (
              <Card key={session.id} className="bg-zinc-900 border-zinc-700 overflow-hidden">
                {/* Session row */}
                <div className="flex items-center gap-2 pr-3">
                  <button
                    className="flex-1 p-4 flex items-center gap-4 hover:bg-zinc-800/30 transition-colors text-left"
                    onClick={() => toggleSession(session.id)}
                  >
                    <div className="shrink-0">
                      {expanded
                        ? <ChevronDown className="w-4 h-4 text-zinc-500" />
                        : <ChevronRight className="w-4 h-4 text-zinc-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge className={`text-xs font-mono ${TOOL_COLORS[session.tool] ?? "bg-zinc-700 text-zinc-300 border-zinc-500"}`}>
                          {session.tool}
                        </Badge>
                        {session.vin && (
                          <span className="font-mono text-sm text-white">{session.vin}</span>
                        )}
                        {session.status === "completed" ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />
                        ) : session.status === "failed" ? (
                          <XCircle className="w-3.5 h-3.5 text-red-400" />
                        ) : (
                          <AlertTriangle className="w-3.5 h-3.5 text-yellow-400" />
                        )}
                        {session.summary && (
                          <span className="text-zinc-400 text-xs truncate max-w-xs">{session.summary}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-zinc-500 text-xs flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(session.startedAt).toLocaleString()}
                        </span>
                        <span className="text-zinc-600 text-xs">
                          {formatDuration(session.startedAt, session.endedAt)}
                        </span>
                        {session.adapterInfo && (
                          <span className="text-zinc-600 text-xs flex items-center gap-1">
                            <Cpu className="w-3 h-3" />{session.adapterInfo}
                          </span>
                        )}
                        {mightHaveSnapshots && (
                          <span className="text-indigo-500/60 text-xs flex items-center gap-1">
                            <Layers className="w-3 h-3" /> snapshots
                          </span>
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Quick Compare button */}
                  <QuickCompareButton sessionId={session.id} />
                </div>

                {/* Expanded log panel */}
                {expanded && <SessionLogs sessionId={session.id} />}
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="p-12 text-center">
          <History className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
          <p className="text-zinc-400 font-mono">No sessions yet</p>
          <p className="text-zinc-600 text-sm mt-2">
            Sessions are recorded when you run any diagnostic tool with an OBD adapter connected
          </p>
        </div>
      )}
    </div>
  );
}
