import { useState, useCallback, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, CheckCircle, XCircle, Search, Trash2, RefreshCw, Database, Download } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const FCA_MODULES: Record<number, string> = {
  0x7E0: "PCM", 0x7E2: "TCM", 0x7B0: "BCM", 0x7C0: "ABS/ESC",
  0x7A0: "IPC", 0x762: "HVAC", 0x764: "RFHUB", 0x7D0: "GW",
  0x7B4: "SCCM", 0x7B8: "OCSM", 0x7E4: "EPS", 0x7E6: "TPMS",
  0x75F: "EPS/SAS", 0x7C4: "FCIM", 0x7C8: "APIM", 0x760: "IPMB",
};

interface LiveDTC {
  code: string;
  rawStatus: number;
  status: string;
  description?: string;
  severity?: string;
  system?: string;
}

interface ModuleDTCResult {
  addr: number;
  name: string;
  dtcs: LiveDTC[];
  error?: string;
}

export default function DTCReader() {
  const [selectedModule, setSelectedModule] = useState<string>("0x7E0");
  const [results, setResults] = useState<ModuleDTCResult[]>([]);
  const [isReading, setIsReading] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [sessionId, setSessionId] = useState<number | null>(null);
  const logBuffer = useRef<any[]>([]);
  const scannedCodes = useRef<string[]>([]);

  const createSession = trpc.sessions.create.useMutation();
  const completeSession = trpc.sessions.complete.useMutation();
  const addLogBatch = trpc.sessions.addLogBatch.useMutation();

  // Real DB lookup for all scanned codes
  const { data: dbLookup } = trpc.dtc.lookupBatch.useQuery(
    { codes: scannedCodes.current },
    { enabled: scannedCodes.current.length > 0 }
  );

  const flushLogs = useCallback(async (sid: number) => {
    if (logBuffer.current.length === 0) return;
    const entries = [...logBuffer.current];
    logBuffer.current = [];
    try { await addLogBatch.mutateAsync({ sessionId: sid, entries }); } catch { /* non-fatal */ }
  }, [addLogBatch]);

  const log = useCallback((sid: number, direction: string, message: string, extra?: object) => {
    logBuffer.current.push({ direction, message, ...extra });
    if (logBuffer.current.length >= 20) flushLogs(sid);
  }, [flushLogs]);

  const parseDTCStatus = (status: number): string => {
    const flags: string[] = [];
    if (status & 0x01) flags.push("Active");
    if (status & 0x02) flags.push("Pending");
    if (status & 0x04) flags.push("Confirmed");
    if (status & 0x08) flags.push("MIL On");
    if (status & 0x10) flags.push("Test Not Completed");
    if (status & 0x20) flags.push("Failed Since Last Clear");
    if (status & 0x40) flags.push("Failed This Drive Cycle");
    if (status & 0x80) flags.push("Warning Indicator");
    return flags.length > 0 ? flags.join(", ") : "Stored";
  };

  const readDTCs = useCallback(async () => {
    if (!connected || !protocol) { toast.error("No OBD adapter connected"); return; }
    setIsReading(true);
    setResults([]);
    logBuffer.current = [];
    scannedCodes.current = [];

    const targetAddrs = selectedModule === "all"
      ? Object.keys(FCA_MODULES).map(Number)
      : [parseInt(selectedModule, 16)];

    const { sessionId: sid } = await createSession.mutateAsync({
      tool: "DTCReader",
      adapterInfo: "ELM327/STN",
    });
    setSessionId(sid ?? 0);

    const allResults: ModuleDTCResult[] = [];
    const activeSid = sid ?? 0;

    for (const addr of targetAddrs) {
      const rxId = addr + 8;
      const modName = FCA_MODULES[addr] ?? `MOD_${addr.toString(16).toUpperCase()}`;
      log(activeSid, "info", `Scanning ${modName} (0x${addr.toString(16).toUpperCase()}) for DTCs...`);
      try {
        const response = await protocol.readDTCs(addr, rxId);
        if (!response || !response.success) {
          allResults.push({ addr, name: modName, dtcs: [] });
          log(activeSid, "info", `${modName}: No response or no DTCs`);
          continue;
        }
        const rawBytes: number[] = response.data ?? [];
        const dtcs: LiveDTC[] = [];
        let idx = 0;
        // Skip 59 02 <statusAvailabilityMask>
        if (rawBytes[0] === 0x59 && rawBytes[1] === 0x02) idx = 3;
        while (idx + 3 <= rawBytes.length) {
          const b1 = rawBytes[idx], b2 = rawBytes[idx + 1];
          const statusByte = rawBytes[idx + 3] ?? 0;
          idx += 4;
          const prefix = ["P", "C", "B", "U"][(b1 >> 6) & 0x03];
          const digits = (((b1 & 0x3F) << 8) | b2).toString(16).toUpperCase().padStart(4, "0");
          const code = `${prefix}${digits}`;
          dtcs.push({ code, rawStatus: statusByte, status: parseDTCStatus(statusByte) });
          scannedCodes.current.push(code);
        }
        allResults.push({ addr, name: modName, dtcs });
        log(activeSid, "success", `${modName}: ${dtcs.length} DTC(s)`, { data: dtcs.map(d => d.code).join(", ") });
      } catch (err: any) {
        allResults.push({ addr, name: modName, dtcs: [], error: err.message });
        log(activeSid, "error", `${modName}: ${err.message}`);
      }
    }

    setResults(allResults);
    await flushLogs(activeSid);
    const total = allResults.reduce((s, r) => s + r.dtcs.length, 0);
    await completeSession.mutateAsync({ sessionId: activeSid, summary: `${total} DTC(s) from ${allResults.length} module(s)` });
    setIsReading(false);
    toast.success(`Scan complete: ${total} DTC(s) found`);
  }, [connected, protocol, selectedModule, createSession, completeSession, flushLogs, log]);

  const clearDTCs = useCallback(async () => {
    if (!connected || !protocol) { toast.error("No OBD adapter connected"); return; }
    if (results.length === 0) { toast.error("Run a scan first"); return; }
    setIsClearing(true);
    logBuffer.current = [];
    const targetAddrs = selectedModule === "all" ? results.map(r => r.addr) : [parseInt(selectedModule, 16)];
    const { sessionId: sid } = await createSession.mutateAsync({ tool: "DTCReader-Clear" });
    const activeSid = sid ?? 0;
    for (const addr of targetAddrs) {
      const rxId = addr + 8;
      const modName = FCA_MODULES[addr] ?? `MOD_${addr.toString(16).toUpperCase()}`;
      log(activeSid, "info", `Clearing DTCs on ${modName}...`);
      try {
        await protocol.clearDTCs(addr, rxId);
        log(activeSid, "success", `${modName}: DTCs cleared`);
      } catch (err: any) {
        log(activeSid, "error", `${modName}: ${err.message}`);
      }
    }
    await flushLogs(activeSid);
    await completeSession.mutateAsync({ sessionId: activeSid, summary: "DTCs cleared" });
    setResults([]);
    scannedCodes.current = [];
    setIsClearing(false);
    toast.success("DTCs cleared");
  }, [connected, protocol, results, selectedModule, createSession, completeSession, flushLogs, log]);

  // Merge real DB descriptions into live results
  const enrichedResults = results.map(r => ({
    ...r,
    dtcs: r.dtcs.map(dtc => {
      const db = dbLookup?.find(d => d.code === dtc.code);
      return { ...dtc, description: db?.description ?? "Unknown — not in database", severity: db?.severity ?? "warning", system: db?.system };
    }),
  }));

  const filtered = enrichedResults.map(r => ({
    ...r,
    dtcs: r.dtcs.filter(d => {
      const q = searchQuery.toLowerCase();
      const matchQ = !q || d.code.toLowerCase().includes(q) || (d.description ?? "").toLowerCase().includes(q);
      const matchS = filterSeverity === "all" || d.severity === filterSeverity;
      return matchQ && matchS;
    }),
  })).filter(r => r.dtcs.length > 0 || r.error);

  const totalDTCs = enrichedResults.reduce((s, r) => s + r.dtcs.length, 0);
  const criticalCount = enrichedResults.flatMap(r => r.dtcs).filter(d => d.severity === "critical").length;
  const warningCount = enrichedResults.flatMap(r => r.dtcs).filter(d => d.severity === "warning").length;

  const exportCSV = () => {
    const rows = [["Module", "Code", "Description", "Severity", "System", "Status"]];
    enrichedResults.forEach(r => r.dtcs.forEach(d => rows.push([r.name, d.code, d.description ?? "", d.severity ?? "", d.system ?? "", d.status])));
    const csv = rows.map(r => r.map(c => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `dtc_${new Date().toISOString().slice(0,10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const sevIcon = (s?: string) => s === "critical" ? <XCircle className="w-4 h-4 text-red-500" /> : s === "warning" ? <AlertTriangle className="w-4 h-4 text-yellow-500" /> : <CheckCircle className="w-4 h-4 text-blue-400" />;
  const sevBadge = (s?: string) => s === "critical" ? <Badge className="bg-red-900/50 text-red-300 border-red-700 text-xs">CRITICAL</Badge> : s === "warning" ? <Badge className="bg-yellow-900/50 text-yellow-300 border-yellow-700 text-xs">WARNING</Badge> : <Badge className="bg-blue-900/50 text-blue-300 border-blue-700 text-xs">INFO</Badge>;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white font-mono tracking-wider">DTC READER</h1>
          <p className="text-zinc-400 text-sm mt-1">Read & clear diagnostic trouble codes — 22,166 FCA codes in database</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={connected ? "bg-green-900/50 text-green-300 border-green-700" : "bg-zinc-800 text-zinc-400 border-zinc-600"}>
            {connected ? "● CONNECTED" : "○ DISCONNECTED"}
          </Badge>
          <Badge className="bg-zinc-800 text-zinc-400 border-zinc-600 font-mono">
            <Database className="w-3 h-3 mr-1" />22,166 CODES
          </Badge>
        </div>
      </div>

      {totalDTCs > 0 && (
        <div className="grid grid-cols-3 gap-4">
          {[{ label: "Total DTCs", val: totalDTCs, color: "text-white" }, { label: "Critical", val: criticalCount, color: "text-red-400" }, { label: "Warnings", val: warningCount, color: "text-yellow-400" }].map(s => (
            <Card key={s.label} className="bg-zinc-900 border-zinc-700">
              <CardContent className="p-4 text-center">
                <div className={`text-3xl font-bold font-mono ${s.color}`}>{s.val}</div>
                <div className="text-zinc-400 text-sm">{s.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card className="bg-zinc-900 border-zinc-700">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <Select value={selectedModule} onValueChange={setSelectedModule}>
              <SelectTrigger className="w-52 bg-zinc-800 border-zinc-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-600">
                <SelectItem value="all" className="text-white">All Modules</SelectItem>
                {Object.entries(FCA_MODULES).map(([addr, name]) => (
                  <SelectItem key={addr} value={`0x${parseInt(addr).toString(16)}`} className="text-white">
                    {name} (0x{parseInt(addr).toString(16).toUpperCase()})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={readDTCs} disabled={isReading || !connected} className="bg-srt-red hover:bg-red-700 text-white font-mono">
              {isReading ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
              {isReading ? "READING..." : "READ DTCs"}
            </Button>
            <Button onClick={clearDTCs} disabled={isClearing || !connected || results.length === 0} variant="outline" className="border-red-700 text-red-400 hover:bg-red-900/20 font-mono">
              {isClearing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
              {isClearing ? "CLEARING..." : "CLEAR DTCs"}
            </Button>
            {totalDTCs > 0 && (
              <Button onClick={exportCSV} variant="outline" className="border-zinc-600 text-zinc-300 font-mono ml-auto">
                <Download className="w-4 h-4 mr-2" />EXPORT CSV
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {totalDTCs > 0 && (
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search code or description..." className="pl-9 bg-zinc-800 border-zinc-600 text-white placeholder:text-zinc-500" />
          </div>
          <Select value={filterSeverity} onValueChange={setFilterSeverity}>
            <SelectTrigger className="w-40 bg-zinc-800 border-zinc-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-zinc-800 border-zinc-600">
              {["all", "critical", "warning", "info"].map(s => <SelectItem key={s} value={s} className="text-white capitalize">{s === "all" ? "All Severities" : s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}

      {filtered.length > 0 ? (
        <div className="space-y-4">
          {filtered.map(result => (
            <Card key={result.addr} className="bg-zinc-900 border-zinc-700">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white font-mono text-sm">
                    {result.name} <span className="text-zinc-500">0x{result.addr.toString(16).toUpperCase()}</span>
                  </CardTitle>
                  <Badge className="bg-zinc-800 text-zinc-300 border-zinc-600 font-mono">{result.dtcs.length} DTC{result.dtcs.length !== 1 ? "s" : ""}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {result.error ? (
                  <div className="text-red-400 text-sm font-mono">Error: {result.error}</div>
                ) : (
                  <div className="space-y-2">
                    {result.dtcs.map((dtc, i) => (
                      <div key={i} className="flex items-start gap-3 p-3 bg-zinc-800 rounded border border-zinc-700">
                        {sevIcon(dtc.severity)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono font-bold text-white">{dtc.code}</span>
                            {sevBadge(dtc.severity)}
                            {dtc.system && <Badge className="bg-zinc-700 text-zinc-300 border-zinc-600 text-xs">{dtc.system}</Badge>}
                          </div>
                          <p className="text-zinc-300 text-sm mt-1">{dtc.description}</p>
                          <p className="text-zinc-500 text-xs mt-1 font-mono">Status: {dtc.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : results.length > 0 ? (
        <Card className="bg-zinc-900 border-zinc-700">
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
            <p className="text-white font-mono text-lg">NO DTCs FOUND</p>
            <p className="text-zinc-400 text-sm mt-2">All scanned modules are clear</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-zinc-900 border-zinc-700">
          <CardContent className="p-12 text-center">
            <AlertTriangle className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
            <p className="text-zinc-400 font-mono">Connect an OBD adapter and click READ DTCs to scan</p>
            <p className="text-zinc-600 text-sm mt-2">UDS service 0x19 — supports all FCA/Stellantis modules</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
