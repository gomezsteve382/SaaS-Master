/**
 * Plugin Marketplace — vehicle platform packs
 * Install platform-specific module maps, DID overrides, BCM presets, and known DTCs
 */

import { useState, useEffect } from "react";
import { Package, CheckCircle, Download, Trash2, Car, Truck, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { PLATFORM_PLUGINS, pluginRegistry, type PlatformPlugin } from "@/lib/pluginSystem";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const CATEGORY_ICONS = {
  muscle: "🏎️",
  truck: "🛻",
  suv: "🚙",
  sedan: "🚗",
  ev: "⚡",
};

const CATEGORY_COLORS = {
  muscle: "text-red-400 border-red-500/30 bg-red-950/20",
  truck: "text-orange-400 border-orange-500/30 bg-orange-950/20",
  suv: "text-green-400 border-green-500/30 bg-green-950/20",
  sedan: "text-blue-400 border-blue-500/30 bg-blue-950/20",
  ev: "text-cyan-400 border-cyan-500/30 bg-cyan-950/20",
};

function PluginCard({ plugin, onInstall, onUninstall, installed }: {
  plugin: PlatformPlugin;
  installed: boolean;
  onInstall: (id: string) => void;
  onUninstall: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={cn(
      "border rounded-lg p-4 transition-all",
      installed ? "border-red-500/40 bg-red-950/10" : "border-white/10 bg-white/5 hover:border-white/20"
    )}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-lg">{CATEGORY_ICONS[plugin.category]}</span>
            <span className="text-sm font-bold text-white">{plugin.name}</span>
            {installed && <Badge className="bg-red-600 text-white text-xs">Installed</Badge>}
            <Badge variant="outline" className={cn("text-xs", CATEGORY_COLORS[plugin.category])}>
              {plugin.category.toUpperCase()}
            </Badge>
          </div>
          <p className="text-xs text-gray-400 mt-1">{plugin.description}</p>
          <div className="flex items-center gap-3 mt-2 text-xs text-gray-500 font-mono">
            <span>📅 {plugin.years}</span>
            <span>🔧 {plugin.moduleOverrides.length} modules</span>
            <span>🚨 {plugin.knownDTCs.length} DTCs</span>
            <span>⚙️ {plugin.bcmPresets.length} presets</span>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {installed ? (
            <Button
              size="sm"
              variant="outline"
              className="border-red-500/30 text-red-400 hover:bg-red-950/30 h-7 text-xs"
              onClick={() => onUninstall(plugin.id)}
            >
              <Trash2 className="w-3 h-3 mr-1" /> Remove
            </Button>
          ) : (
            <Button
              size="sm"
              className="bg-red-600 hover:bg-red-700 h-7 text-xs"
              onClick={() => onInstall(plugin.id)}
            >
              <Download className="w-3 h-3 mr-1" /> Install
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            className="border-white/10 h-7 text-xs"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? "Less" : "Details"}
          </Button>
        </div>
      </div>

      {expanded && (
        <div className="mt-4 space-y-3 border-t border-white/10 pt-3">
          {/* Module overrides */}
          <div>
            <div className="text-xs font-semibold text-gray-400 mb-2 flex items-center gap-1">
              <Cpu className="w-3 h-3" /> Module Addresses
            </div>
            <div className="grid grid-cols-2 gap-1">
              {plugin.moduleOverrides.map((m) => (
                <div key={m.txId} className="text-xs bg-black/30 rounded p-2 font-mono">
                  <span className="text-red-400">TX:0x{m.txId.toString(16).toUpperCase()}</span>
                  <span className="text-gray-500 mx-1">→</span>
                  <span className="text-white">{m.label}</span>
                  {m.securityAlgo && <span className="text-gray-500 ml-1">({m.securityAlgo})</span>}
                  {m.notes && <div className="text-gray-500 mt-0.5 text-[10px] font-sans">{m.notes}</div>}
                </div>
              ))}
            </div>
          </div>

          {/* Known DTCs */}
          {plugin.knownDTCs.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-gray-400 mb-2">Known DTCs</div>
              <div className="space-y-1">
                {plugin.knownDTCs.map((dtc) => (
                  <div key={dtc.code} className="flex items-center gap-2 text-xs">
                    <span className={cn(
                      "font-mono px-1.5 py-0.5 rounded text-[10px]",
                      dtc.severity === "critical" ? "bg-red-900/50 text-red-400" :
                      dtc.severity === "warning" ? "bg-yellow-900/50 text-yellow-400" :
                      "bg-blue-900/50 text-blue-400"
                    )}>{dtc.code}</span>
                    <span className="text-gray-400">{dtc.description}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* BCM Presets */}
          {plugin.bcmPresets.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-gray-400 mb-2">BCM Presets</div>
              <div className="flex flex-wrap gap-1">
                {plugin.bcmPresets.map((preset) => (
                  <Badge key={preset.name} variant="outline" className="border-white/10 text-gray-300 text-xs">
                    {preset.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {plugin.notes.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-gray-400 mb-2">Technical Notes</div>
              <ul className="space-y-1">
                {plugin.notes.map((note, i) => (
                  <li key={i} className="text-xs text-gray-400 flex items-start gap-1">
                    <span className="text-red-500 mt-0.5">›</span> {note}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function PluginMarketplace() {
  const [installedIds, setInstalledIds] = useState<Set<string>>(
    new Set(pluginRegistry.getInstalled().map((p) => p.id))
  );
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "installed" | "muscle" | "truck" | "suv" | "sedan" | "ev">("all");

  useEffect(() => {
    const unsub = pluginRegistry.subscribe((plugins) => {
      setInstalledIds(new Set(plugins.map((p) => p.id)));
    });
    return unsub;
  }, []);

  const handleInstall = (id: string) => {
    pluginRegistry.install(id);
    toast.success(`Plugin installed: ${PLATFORM_PLUGINS.find((p) => p.id === id)?.name}`);
  };

  const handleUninstall = (id: string) => {
    pluginRegistry.uninstall(id);
    toast.info(`Plugin removed: ${PLATFORM_PLUGINS.find((p) => p.id === id)?.name}`);
  };

  const filtered = PLATFORM_PLUGINS.filter((p) => {
    const matchesSearch = search === "" ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase()) ||
      p.platforms.some((pl) => pl.toLowerCase().includes(search.toLowerCase()));
    const matchesFilter =
      filter === "all" ||
      (filter === "installed" && installedIds.has(p.id)) ||
      filter === p.category;
    return matchesSearch && matchesFilter;
  });

  const installedCount = installedIds.size;

  return (
    <div className="flex flex-col h-full p-6 gap-4">
      {/* Header */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-red-500" />
            Plugin Marketplace
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            Vehicle platform packs — module maps, DID overrides, BCM presets, known DTCs
          </p>
        </div>
        <div className="flex items-center gap-2">
          {installedCount > 0 && (
            <Badge className="bg-red-600 text-white">
              <CheckCircle className="w-3 h-3 mr-1" /> {installedCount} installed
            </Badge>
          )}
        </div>
      </div>

      {/* Search + filters */}
      <div className="flex items-center gap-2 shrink-0 flex-wrap">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search plugins..."
          className="max-w-xs bg-white/5 border-white/10 text-white h-8 text-sm"
        />
        {(["all", "installed", "muscle", "truck", "suv", "sedan", "ev"] as const).map((f) => (
          <Button
            key={f}
            size="sm"
            variant={filter === f ? "default" : "outline"}
            className={cn(
              "h-7 text-xs capitalize",
              filter === f ? "bg-red-600 hover:bg-red-700" : "border-white/10"
            )}
            onClick={() => setFilter(f)}
          >
            {f === "all" ? "All" : f === "installed" ? `Installed (${installedCount})` : `${CATEGORY_ICONS[f as keyof typeof CATEGORY_ICONS]} ${f}`}
          </Button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 shrink-0">
        {[
          { label: "Total Plugins", value: PLATFORM_PLUGINS.length, icon: Package },
          { label: "Installed", value: installedCount, icon: CheckCircle },
          { label: "Module Maps", value: PLATFORM_PLUGINS.reduce((s, p) => s + p.moduleOverrides.length, 0), icon: Cpu },
          { label: "BCM Presets", value: PLATFORM_PLUGINS.reduce((s, p) => s + p.bcmPresets.length, 0), icon: Car },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="bg-[#111] border border-white/10 rounded p-3">
            <div className="flex items-center gap-2 mb-1">
              <Icon className="w-3.5 h-3.5 text-red-500" />
              <span className="text-xs text-gray-400">{label}</span>
            </div>
            <div className="text-xl font-black text-white">{value}</div>
          </div>
        ))}
      </div>

      {/* Plugin list */}
      <div className="flex-1 overflow-y-auto space-y-3">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-gray-500">
            <Truck className="w-8 h-8 mb-2 opacity-30" />
            <p className="text-sm">No plugins match your search</p>
          </div>
        ) : (
          filtered.map((plugin) => (
            <PluginCard
              key={plugin.id}
              plugin={plugin}
              installed={installedIds.has(plugin.id)}
              onInstall={handleInstall}
              onUninstall={handleUninstall}
            />
          ))
        )}
      </div>
    </div>
  );
}
