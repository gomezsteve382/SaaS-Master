import { useState, useRef, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { EEPROMDiffViewer } from "@/components/EEPROMDiffViewer";
import { VirtualUDSLog } from "@/components/VirtualUDSLog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Upload, Cpu, Zap, Shield, Trash2, Eye, FileCode2,
  CheckCircle, AlertTriangle, RefreshCw, ChevronLeft,
  HardDrive, Activity, Hash
} from "lucide-react";
import { Link } from "wouter";
import type { UDSLogEntry } from "@/components/VirtualUDSLog";

// ─── Types ────────────────────────────────────────────────────────────────────
interface CalibrationFile {
  id: number;
  fileName: string;
  fileKey: string;
  fileUrl: string;
  fileSize: number;
  crc32: string | null;
  crc16: string | null;
  md5: string | null;
  moduleType: string | null;
  platform: string | null;
  partNumber: string | null;
  swVersion: string | null;
  hwVersion: string | null;
  notes: string | null;
  flashCount: number;
  lastFlashedAt: Date | null;
  createdAt: Date;
}

interface ChecksumResult {
  crc32: string;
  crc16: string;
  md5: string;
  size: number;
  valid: boolean;
  issues: string[];
}

// ─── CRC / Checksum Utilities ─────────────────────────────────────────────────
function computeCRC32(data: Uint8Array): number {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    table[i] = c;
  }
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < data.length; i++) crc = table[(crc ^ data[i]!) & 0xFF]! ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function computeCRC16(data: Uint8Array): number {
  let crc = 0xFFFF;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i]!;
    for (let j = 0; j < 8; j++) crc = (crc & 1) ? ((crc >>> 1) ^ 0x8408) : (crc >>> 1);
  }
  return crc & 0xFFFF;
}

async function computeMD5(data: Uint8Array): Promise<string> {
  const hashBuffer = await crypto.subtle.digest("SHA-256", data.buffer as ArrayBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

function validateBinFile(data: Uint8Array, moduleType: string): ChecksumResult {
  const crc32 = computeCRC32(data).toString(16).toUpperCase().padStart(8, "0");
  const crc16 = computeCRC16(data).toString(16).toUpperCase().padStart(4, "0");
  const issues: string[] = [];

  const expectedSizes: Record<string, number[]> = {
    ECM: [0x40000, 0x80000, 0x100000],
    PCM: [0x40000, 0x80000, 0x100000],
    TCM: [0x20000, 0x40000],
    BCM: [0x10000, 0x20000],
    GWAY: [0x20000, 0x40000],
    RFHUB: [0x2000, 0x4000],
  };

  const validSizes = expectedSizes[moduleType] ?? [];
  if (validSizes.length > 0 && !validSizes.includes(data.length)) {
    issues.push(`Unexpected size ${data.length.toLocaleString()} bytes for ${moduleType} (expected: ${validSizes.map(s => `${(s / 1024).toFixed(0)}KB`).join(" or ")})`);
  }

  const ffCount = data.filter(b => b === 0xFF).length;
  if (ffCount / data.length > 0.95) issues.push("File appears to be blank/erased flash (>95% 0xFF bytes)");

  const zeroCount = data.filter(b => b === 0x00).length;
  if (zeroCount / data.length > 0.95) issues.push("File appears to be all zeros — likely corrupt");

  return { crc32, crc16, md5: "", size: data.length, valid: issues.length === 0, issues };
}

// ─── Module / Platform constants ─────────────────────────────────────────────
const MODULE_TYPES = ["ECM", "PCM", "TCM", "BCM", "GWAY", "RFHUB", "ABS", "EPS", "HVAC", "IPC"];
const PLATFORMS = [
  "Challenger SRT 392", "Challenger SRT Hellcat", "Challenger SRT Demon",
  "Charger SRT 392", "Charger SRT Hellcat", "Charger SRT Widebody",
  "Durango SRT 392", "Durango SRT Hellcat",
  "Grand Cherokee Trackhawk", "Grand Cherokee SRT",
  "RAM TRX", "RAM 1500 Classic",
  "Jeep Wrangler 392", "Jeep Gladiator Mojave",
  "Viper ACR", "Viper GTS",
];

// Module address map: txId, rxId
const MODULE_ADDRS: Record<string, { tx: number; rx: number }> = {
  ECM:   { tx: 0x7E0, rx: 0x7E8 },
  PCM:   { tx: 0x7E0, rx: 0x7E8 },
  TCM:   { tx: 0x7E1, rx: 0x7E9 },
  BCM:   { tx: 0x7B0, rx: 0x7B8 },
  GWAY:  { tx: 0x760, rx: 0x768 },
  RFHUB: { tx: 0x762, rx: 0x76A },
  ABS:   { tx: 0x760, rx: 0x768 },
  EPS:   { tx: 0x75F, rx: 0x767 },
};

const FLASH_STEPS = [
  { id: "connect",  label: "Establish UDS session",      service: "10 03" },
  { id: "security", label: "Security access unlock",     service: "27 01/02" },
  { id: "snapshot", label: "Capture pre-flash snapshot", service: "22 F190" },
  { id: "erase",    label: "Erase flash memory",         service: "31 01 FF 00" },
  { id: "transfer", label: "Transfer calibration data",  service: "34/36/37" },
  { id: "verify",   label: "Verify checksum",            service: "31 01 02 02" },
  { id: "reset",    label: "ECU reset & validation",     service: "11 01" },
];

let _logSeq = 0;
type TrpcDirection = "tx" | "rx" | "info" | "success" | "error" | "warning";

function trpcToUdsDir(d: TrpcDirection): UDSLogEntry["direction"] {
  if (d === "tx") return "TX";
  if (d === "rx") return "RX";
  if (d === "error") return "ERROR";
  if (d === "warning") return "WARN";
  return "INFO";
}

function makeLogEntry(
  direction: TrpcDirection,
  decoded: string,
  raw = ""
): UDSLogEntry {
  return {
    id: `log-${++_logSeq}`,
    timestamp: new Date().toISOString(),
    direction: trpcToUdsDir(direction),
    decoded,
    raw,
  };
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function ECMCalibrationManager() {

  const [filterModule, setFilterModule] = useState<string>("all");
  const [filterPlatform, setFilterPlatform] = useState<string>("all");
  const [selectedCal, setSelectedCal] = useState<CalibrationFile | null>(null);
  const [viewMode, setViewMode] = useState<"library" | "upload" | "flash" | "diff">("library");

  // Upload state
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadData, setUploadData] = useState<Uint8Array | null>(null);
  const [checksumResult, setChecksumResult] = useState<ChecksumResult | null>(null);
  const [uploadMeta, setUploadMeta] = useState({
    moduleType: "ECM", platform: "", partNumber: "", swVersion: "", hwVersion: "", notes: "",
  });
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Flash state
  const [flashing, setFlashing] = useState(false);
  const [flashStep, setFlashStep] = useState(-1);
  const [flashProgress, setFlashProgress] = useState(0);
  const [flashLogs, setFlashLogs] = useState<UDSLogEntry[]>([]);
  const [preFlashData, setPreFlashData] = useState<Uint8Array | null>(null);
  const [postFlashData, setPostFlashData] = useState<Uint8Array | null>(null);

  // tRPC
  const { data: calibrations, refetch } = trpc.calibrations.list.useQuery({
    moduleType: filterModule !== "all" ? filterModule : undefined,
    platform: filterPlatform !== "all" ? filterPlatform : undefined,
    limit: 100,
  });

  const createCalMutation = trpc.calibrations.create.useMutation();
  const deleteCalMutation = trpc.calibrations.delete.useMutation();
  const recordFlashMutation = trpc.calibrations.recordFlash.useMutation();
  const createSessionMutation = trpc.sessions.create.useMutation();
  const addLogMutation = trpc.sessions.addLog.useMutation();
  const completeSessionMutation = trpc.sessions.complete.useMutation();
  const saveSnapshotMutation = trpc.sessions.saveSnapshot.useMutation();

  const addLog = useCallback((direction: TrpcDirection, decoded: string, raw = "") => {
    setFlashLogs(prev => [...prev, makeLogEntry(direction, decoded, raw)]);
  }, []);

  // ─── File Selection ──────────────────────────────────────────────────────────
  const handleFileSelect = useCallback(async (file: File) => {
    setUploadFile(file);
    setChecksumResult(null);
    const buffer = await file.arrayBuffer();
    const data = new Uint8Array(buffer);
    setUploadData(data);

    const result = validateBinFile(data, uploadMeta.moduleType);
    result.md5 = await computeMD5(data);
    setChecksumResult(result);

    // Auto-detect module type
    if (data.length <= 0x4000) setUploadMeta(m => ({ ...m, moduleType: "RFHUB" }));
    else if (data.length <= 0x20000) setUploadMeta(m => ({ ...m, moduleType: "BCM" }));
    else setUploadMeta(m => ({ ...m, moduleType: "ECM" }));
  }, [uploadMeta.moduleType]);

  // ─── Upload ──────────────────────────────────────────────────────────────────
  const handleUpload = useCallback(async () => {
    if (!uploadFile || !uploadData || !checksumResult) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", uploadFile);

      const uploadRes = await fetch(`${import.meta.env.VITE_FRONTEND_FORGE_API_URL}/storage/upload`, {
        method: "POST",
        headers: { Authorization: `Bearer ${import.meta.env.VITE_FRONTEND_FORGE_API_KEY}` },
        body: formData,
      });

      if (!uploadRes.ok) throw new Error(`Upload failed: ${uploadRes.statusText}`);
      const { key, url } = await uploadRes.json() as { key: string; url: string };

      await createCalMutation.mutateAsync({
        fileName: uploadFile.name,
        fileKey: key,
        fileUrl: url,
        fileSize: uploadData.length,
        crc32: checksumResult.crc32,
        crc16: checksumResult.crc16,
        md5: checksumResult.md5,
        moduleType: uploadMeta.moduleType,
        platform: uploadMeta.platform || undefined,
        partNumber: uploadMeta.partNumber || undefined,
        swVersion: uploadMeta.swVersion || undefined,
        hwVersion: uploadMeta.hwVersion || undefined,
        notes: uploadMeta.notes || undefined,
      });

      toast.success("Calibration file uploaded successfully");
      setUploadFile(null); setUploadData(null); setChecksumResult(null);
      setUploadMeta({ moduleType: "ECM", platform: "", partNumber: "", swVersion: "", hwVersion: "", notes: "" });
      setViewMode("library");
      refetch();
    } catch (err: unknown) {
      toast.error(`Upload failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setUploading(false);
    }
  }, [uploadFile, uploadData, checksumResult, uploadMeta, createCalMutation, refetch]);

  // ─── Flash Workflow ──────────────────────────────────────────────────────────
  const handleFlash = useCallback(async (cal: CalibrationFile) => {
    if (!isConnected) { toast.error("Connect an OBD adapter first"); return; }

    setFlashing(true); setFlashStep(0); setFlashProgress(0);
    setFlashLogs([]); setPreFlashData(null); setPostFlashData(null);

    const addrs = MODULE_ADDRS[cal.moduleType ?? "ECM"] ?? MODULE_ADDRS.ECM!;
    const { tx, rx } = addrs;

    let sid: number | null = null;
    try {
      const res = await createSessionMutation.mutateAsync({
        tool: "ECMCalibrationManager",
        adapterInfo: protocol.adapterInfo?.type ?? "ELM327",
      });
      sid = res.sessionId ?? null;
    } catch { /* non-fatal */ }

    const log = async (direction: TrpcDirection, decoded: string, raw = "") => {
      addLog(direction, decoded, raw);
      if (sid !== null) {
        try { await addLogMutation.mutateAsync({ sessionId: sid, direction, message: decoded, data: raw || undefined }); }
        catch { /* non-fatal */ }
      }
    };

    try {
      // Step 0: Extended session
      setFlashStep(0);
      await log("info", `Targeting ${cal.moduleType} TX=0x${tx.toString(16).toUpperCase()} RX=0x${rx.toString(16).toUpperCase()}`);
      const sessRes = await protocol.startSession(tx, rx, 0x03);
      if (!sessRes.success) throw new Error(`Failed to start extended session: ${sessRes.error}`);
      await log("success", "Extended diagnostic session established", "10 03 → 50 03");
      setFlashProgress(10);

      // Step 1: Security access — NGC3 for ECM/PCM
      setFlashStep(1);
      await log("info", "Requesting security access seed...");
      const secRes = await protocol.securityAccess(tx, rx, 1, (seed) => {
        let key = seed >>> 0;
        for (let i = 0; i < 5; i++) { key = ((key << 1) | (key >>> 31)) >>> 0; key ^= 0x1234ABCD; }
        return new Uint8Array([(key >>> 24) & 0xFF, (key >>> 16) & 0xFF, (key >>> 8) & 0xFF, key & 0xFF]);
      });
      if (!secRes.success) throw new Error(`Security access denied: ${secRes.error}`);
      await log("success", "Security access granted", "27 01 → 67 01 [seed] → 27 02 [key] → 67 02");
      setFlashProgress(20);

      // Step 2: Pre-flash snapshot
      setFlashStep(2);
      await log("info", "Reading pre-flash module state...");
      const vinRes = await protocol.readDID(tx, rx, 0xF190);
      const preVin = (vinRes.success && vinRes.data && vinRes.data.length >= 20)
        ? String.fromCharCode(...vinRes.data.slice(3, 20).filter(b => b >= 0x20 && b <= 0x7E))
        : "UNKNOWN";
      await log("rx", `Pre-flash VIN: ${preVin}`, vinRes.data?.map(b => b.toString(16).padStart(2, "0")).join(" ") ?? "");

      // Read first 0x1000 bytes for diff
      const preReadRes = await protocol.sendUDS(tx, rx, [0x23, 0x14, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00]);
      if (preReadRes.success && preReadRes.data) setPreFlashData(new Uint8Array(preReadRes.data));

      if (sid !== null) {
        await saveSnapshotMutation.mutateAsync({
          sessionId: sid, moduleAddr: tx, moduleName: cal.moduleType ?? "ECM",
          snapshotType: "before", vin: preVin !== "UNKNOWN" ? preVin : undefined,
          swVersion: cal.swVersion ?? undefined,
        });
      }
      setFlashProgress(30);

      // Step 3: Download calibration file
      setFlashStep(3);
      await log("info", `Downloading calibration: ${cal.fileName} (${(cal.fileSize / 1024).toFixed(1)} KB)`);
      const calFileRes = await fetch(cal.fileUrl);
      if (!calFileRes.ok) throw new Error(`Failed to download calibration file: ${calFileRes.statusText}`);
      const calBuffer = await calFileRes.arrayBuffer();
      const calData = new Uint8Array(calBuffer);

      // Verify CRC32 before flashing
      const localCRC32 = computeCRC32(calData).toString(16).toUpperCase().padStart(8, "0");
      if (cal.crc32 && localCRC32 !== cal.crc32) {
        throw new Error(`CRC32 mismatch! Expected ${cal.crc32}, got ${localCRC32}. File may be corrupt.`);
      }
      await log("success", `Checksum verified: CRC32=${localCRC32}`);
      setFlashProgress(40);

      // Step 4: Erase flash (routine 0xFF00)
      setFlashStep(3);
      await log("tx", "Erasing flash memory (31 01 FF 00)...", "31 01 FF 00");
      const eraseRes = await protocol.routineControl(tx, rx, 0xFF00, 0x01, []);
      if (!eraseRes.success) throw new Error(`Flash erase failed: ${eraseRes.error}`);
      await log("success", "Flash erase complete");
      setFlashProgress(50);

      // Step 5: RequestDownload (0x34)
      setFlashStep(4);
      const fileSize = calData.length;
      const reqDlBytes = [
        0x34, 0x00, 0x44,
        0x00, 0x00, 0x00, 0x00,           // memAddress (4 bytes)
        (fileSize >>> 24) & 0xFF, (fileSize >>> 16) & 0xFF, (fileSize >>> 8) & 0xFF, fileSize & 0xFF,
      ];
      await log("tx", `RequestDownload: ${(fileSize / 1024).toFixed(1)} KB at 0x00000000`, reqDlBytes.map(b => b.toString(16).padStart(2, "0")).join(" ").toUpperCase());
      const reqDlRes = await protocol.sendUDS(tx, rx, reqDlBytes);
      if (!reqDlRes.success) throw new Error(`RequestDownload failed: ${reqDlRes.error}`);

      // TransferData (0x36) in 0x100-byte blocks
      const blockSize = 0x100;
      const totalBlocks = Math.ceil(calData.length / blockSize);
      let blockNum = 1;
      for (let offset = 0; offset < calData.length; offset += blockSize) {
        const chunk = Array.from(calData.slice(offset, offset + blockSize));
        const xferRes = await protocol.sendUDS(tx, rx, [0x36, blockNum & 0xFF, ...chunk]);
        if (!xferRes.success) throw new Error(`TransferData block ${blockNum} failed: ${xferRes.error}`);
        blockNum++;
        const pct = 50 + Math.floor((offset / calData.length) * 35);
        setFlashProgress(pct);
        if (blockNum % 20 === 0) {
          await log("tx", `Transfer: ${Math.floor((offset / calData.length) * 100)}% (${(offset / 1024).toFixed(1)}/${(calData.length / 1024).toFixed(1)} KB)`, `36 ${(blockNum & 0xFF).toString(16).padStart(2, "0")} ...`);
        }
      }

      // RequestTransferExit (0x37)
      const xferExitRes = await protocol.sendUDS(tx, rx, [0x37]);
      if (!xferExitRes.success) throw new Error(`RequestTransferExit failed: ${xferExitRes.error}`);
      await log("success", `Data transfer complete — ${totalBlocks} blocks transferred`);
      setFlashProgress(85);

      // Step 6: Verify checksum (routine 0x0202)
      setFlashStep(5);
      await log("tx", "Verifying flash checksum (31 01 02 02)...", "31 01 02 02");
      const verifyRes = await protocol.routineControl(tx, rx, 0x0202, 0x01, []);
      if (!verifyRes.success) throw new Error(`Checksum verification failed: ${verifyRes.error}`);
      await log("success", "Flash checksum verified successfully");
      setFlashProgress(92);

      // Step 7: ECU reset
      setFlashStep(6);
      await log("tx", "Performing ECU hard reset (11 01)...", "11 01");
      await protocol.ecuReset(tx, rx, 0x01);
      await new Promise(r => setTimeout(r, 3000));
      await log("info", "Waiting for ECU to boot (3s)...");

      // Re-establish and read post-flash state
      await protocol.startSession(tx, rx, 0x03);
      const postVinRes = await protocol.readDID(tx, rx, 0xF190);
      const postVin = (postVinRes.success && postVinRes.data && postVinRes.data.length >= 20)
        ? String.fromCharCode(...postVinRes.data.slice(3, 20).filter(b => b >= 0x20 && b <= 0x7E))
        : "UNKNOWN";
      await log("rx", `Post-flash VIN: ${postVin}`);

      const postReadRes = await protocol.sendUDS(tx, rx, [0x23, 0x14, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00]);
      if (postReadRes.success && postReadRes.data) setPostFlashData(new Uint8Array(postReadRes.data));

      if (sid !== null) {
        await saveSnapshotMutation.mutateAsync({
          sessionId: sid, moduleAddr: tx, moduleName: cal.moduleType ?? "ECM",
          snapshotType: "after", vin: postVin !== "UNKNOWN" ? postVin : undefined,
          swVersion: cal.swVersion ?? undefined,
        });
      }

      setFlashProgress(100);
      setFlashStep(7);
      await log("success", `Flash complete! ${cal.fileName} successfully programmed to ${cal.moduleType} (TX=0x${tx.toString(16).toUpperCase()})`);

      await recordFlashMutation.mutateAsync({ id: cal.id });
      if (sid !== null) await completeSessionMutation.mutateAsync({ sessionId: sid, summary: `Flashed ${cal.fileName} to ${cal.moduleType}`, status: "completed" });

      toast.success("ECM calibration flashed successfully!");
      refetch();
      if (preFlashData && postFlashData) setTimeout(() => setViewMode("diff"), 1500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      addLog("error", `Flash failed: ${msg}`);
      if (sid !== null) await completeSessionMutation.mutateAsync({ sessionId: sid, summary: `Flash failed: ${msg}`, status: "failed" });
      toast.error(`Flash failed: ${msg}`);
    } finally {
      setFlashing(false);
    }
  }, [isConnected, protocol, createSessionMutation, addLogMutation, completeSessionMutation,
      saveSnapshotMutation, recordFlashMutation, addLog, refetch, preFlashData, postFlashData]);

  // ─── Delete ──────────────────────────────────────────────────────────────────
  const handleDelete = useCallback(async (cal: CalibrationFile) => {
    if (!confirm(`Delete "${cal.fileName}"? This cannot be undone.`)) return;
    try {
      await deleteCalMutation.mutateAsync({ id: cal.id });
      toast.success("Calibration deleted");
      if (selectedCal?.id === cal.id) setSelectedCal(null);
      refetch();
    } catch (err: unknown) {
      toast.error(`Delete failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [deleteCalMutation, selectedCal, refetch]);

  // ─── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Link href="/">
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
            <ChevronLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-srt-red/10 border border-srt-red/30">
            <Cpu className="h-6 w-6 text-srt-red" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
              ECM Calibration Manager
              <Badge className="bg-srt-red text-white text-xs">FLASH</Badge>
            </h1>
            <p className="text-xs text-muted-foreground">Upload, validate, and flash ECM/PCM/TCM calibration .bin files</p>
          </div>
        </div>
        <div className="ml-auto">
          <Badge variant={isConnected ? "default" : "secondary"} className={isConnected ? "bg-green-600 text-white" : ""}>
            {isConnected ? "OBD CONNECTED" : "OBD DISCONNECTED"}
          </Badge>
        </div>
      </div>

      {/* View Tabs */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {[
          { id: "library", label: "Library", icon: HardDrive },
          { id: "upload",  label: "Upload",  icon: Upload },
          { id: "flash",   label: "Flash Log", icon: Zap },
          { id: "diff",    label: "Diff Viewer", icon: Eye },
        ].map(({ id, label, icon: Icon }) => (
          <Button key={id} variant={viewMode === id ? "default" : "outline"} size="sm"
            onClick={() => setViewMode(id as typeof viewMode)}
            className={viewMode === id ? "bg-srt-red text-white hover:bg-srt-red/90" : "border-border text-muted-foreground hover:text-foreground"}>
            <Icon className="h-4 w-4 mr-1.5" />{label}
          </Button>
        ))}
      </div>

      {/* ─── Library ─────────────────────────────────────────────────────────── */}
      {viewMode === "library" && (
        <div className="space-y-4">
          <div className="flex gap-3 flex-wrap">
            <Select value={filterModule} onValueChange={setFilterModule}>
              <SelectTrigger className="w-40 bg-card border-border text-foreground"><SelectValue placeholder="Module type" /></SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="all">All Modules</SelectItem>
                {MODULE_TYPES.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterPlatform} onValueChange={setFilterPlatform}>
              <SelectTrigger className="w-56 bg-card border-border text-foreground"><SelectValue placeholder="Platform" /></SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="all">All Platforms</SelectItem>
                {PLATFORMS.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button onClick={() => refetch()} variant="outline" size="sm" className="border-border">
              <RefreshCw className="h-4 w-4 mr-1.5" />Refresh
            </Button>
            <Button onClick={() => setViewMode("upload")} className="ml-auto bg-srt-red hover:bg-srt-red/90 text-white">
              <Upload className="h-4 w-4 mr-1.5" />Upload Calibration
            </Button>
          </div>

          {!calibrations || calibrations.length === 0 ? (
            <Card className="bg-card border-border">
              <CardContent className="py-16 text-center">
                <FileCode2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No calibration files yet.</p>
                <p className="text-sm text-muted-foreground mt-1">Upload a .bin file to get started.</p>
                <Button onClick={() => setViewMode("upload")} className="mt-4 bg-srt-red hover:bg-srt-red/90 text-white">
                  <Upload className="h-4 w-4 mr-1.5" />Upload First Calibration
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {(calibrations as CalibrationFile[]).map(cal => (
                <Card key={cal.id}
                  className={`bg-card border-border cursor-pointer transition-all hover:border-srt-red/50 ${selectedCal?.id === cal.id ? "border-srt-red" : ""}`}
                  onClick={() => setSelectedCal(cal)}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-sm font-mono text-foreground truncate">{cal.fileName}</CardTitle>
                        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                          {cal.moduleType && <Badge className="bg-srt-red/20 text-srt-red border-srt-red/30 text-xs">{cal.moduleType}</Badge>}
                          {cal.platform && <Badge variant="outline" className="text-xs border-border text-muted-foreground">{cal.platform}</Badge>}
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-srt-red"
                        onClick={(e) => { e.stopPropagation(); handleDelete(cal); }}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-2">
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1"><HardDrive className="h-3 w-3" />{(cal.fileSize / 1024).toFixed(1)} KB</div>
                      <div className="flex items-center gap-1"><Activity className="h-3 w-3" />Flashed: {cal.flashCount}×</div>
                      {cal.partNumber && <div className="flex items-center gap-1 col-span-2"><Hash className="h-3 w-3" />{cal.partNumber}</div>}
                      {cal.swVersion && <div className="flex items-center gap-1"><FileCode2 className="h-3 w-3" />SW: {cal.swVersion}</div>}
                      {cal.crc32 && <div className="flex items-center gap-1 font-mono"><Shield className="h-3 w-3" />{cal.crc32}</div>}
                    </div>
                    {cal.notes && <p className="text-xs text-muted-foreground italic truncate">{cal.notes}</p>}
                    <Button className="w-full bg-srt-red hover:bg-srt-red/90 text-white text-xs h-8"
                      disabled={!isConnected || flashing}
                      onClick={(e) => { e.stopPropagation(); setSelectedCal(cal); setViewMode("flash"); handleFlash(cal); }}>
                      <Zap className="h-3.5 w-3.5 mr-1.5" />
                      {flashing && selectedCal?.id === cal.id ? "Flashing..." : "Flash to ECU"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ─── Upload ──────────────────────────────────────────────────────────── */}
      {viewMode === "upload" && (
        <div className="max-w-2xl space-y-4">
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-10">
              <div className="text-center cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleFileSelect(f); }}>
                <Upload className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-foreground font-medium">Drop .bin file here or click to browse</p>
                <p className="text-sm text-muted-foreground mt-1">ECM, PCM, TCM, BCM, GWAY, RFHUB calibration files</p>
                {uploadFile && (
                  <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded bg-srt-red/10 border border-srt-red/30 text-srt-red text-sm">
                    <FileCode2 className="h-4 w-4" />{uploadFile.name} ({(uploadFile.size / 1024).toFixed(1)} KB)
                  </div>
                )}
              </div>
              <input ref={fileInputRef} type="file" accept=".bin,.hex,.s19,.mot" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFileSelect(f); }} />
            </CardContent>
          </Card>

          {checksumResult && (
            <Card className={`border ${checksumResult.valid ? "border-green-600/50 bg-green-950/20" : "border-yellow-600/50 bg-yellow-950/20"}`}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  {checksumResult.valid
                    ? <><CheckCircle className="h-4 w-4 text-green-500" />Validation Passed</>
                    : <><AlertTriangle className="h-4 w-4 text-yellow-500" />Validation Warnings</>}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  {[
                    ["CRC-32", checksumResult.crc32],
                    ["CRC-16", checksumResult.crc16],
                    ["SHA-256 (32)", checksumResult.md5],
                    ["Size", `${checksumResult.size.toLocaleString()} bytes`],
                  ].map(([label, value]) => (
                    <div key={label} className="bg-background/50 rounded p-2">
                      <span className="text-muted-foreground">{label}: </span>
                      <span className="text-foreground">{value}</span>
                    </div>
                  ))}
                </div>
                {checksumResult.issues.map((issue, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-yellow-400">
                    <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />{issue}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {uploadFile && (
            <Card className="bg-card border-border">
              <CardHeader className="pb-3"><CardTitle className="text-sm">Calibration Metadata</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-muted-foreground">Module Type</Label>
                    <Select value={uploadMeta.moduleType} onValueChange={v => setUploadMeta(m => ({ ...m, moduleType: v }))}>
                      <SelectTrigger className="bg-background border-border text-foreground mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {MODULE_TYPES.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Platform</Label>
                    <Select value={uploadMeta.platform} onValueChange={v => setUploadMeta(m => ({ ...m, platform: v }))}>
                      <SelectTrigger className="bg-background border-border text-foreground mt-1"><SelectValue placeholder="Select platform..." /></SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {PLATFORMS.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  {[
                    { key: "partNumber", label: "Part Number", placeholder: "e.g. 68123456AA" },
                    { key: "swVersion",  label: "SW Version",  placeholder: "e.g. 14.01.00" },
                    { key: "hwVersion",  label: "HW Version",  placeholder: "e.g. H02" },
                  ].map(({ key, label, placeholder }) => (
                    <div key={key}>
                      <Label className="text-xs text-muted-foreground">{label}</Label>
                      <Input className="bg-background border-border text-foreground mt-1 font-mono"
                        placeholder={placeholder}
                        value={uploadMeta[key as keyof typeof uploadMeta]}
                        onChange={e => setUploadMeta(m => ({ ...m, [key]: e.target.value }))} />
                    </div>
                  ))}
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Notes</Label>
                  <Textarea className="bg-background border-border text-foreground mt-1 resize-none"
                    placeholder="Tune notes, dyno results, target vehicle..." rows={2}
                    value={uploadMeta.notes}
                    onChange={e => setUploadMeta(m => ({ ...m, notes: e.target.value }))} />
                </div>
                <div className="flex gap-2 pt-1">
                  <Button className="flex-1 bg-srt-red hover:bg-srt-red/90 text-white"
                    disabled={uploading || !checksumResult} onClick={handleUpload}>
                    {uploading ? <><RefreshCw className="h-4 w-4 mr-1.5 animate-spin" />Uploading...</> : <><Upload className="h-4 w-4 mr-1.5" />Upload to Library</>}
                  </Button>
                  <Button variant="outline" className="border-border"
                    onClick={() => { setUploadFile(null); setUploadData(null); setChecksumResult(null); }}>
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* ─── Flash Log ───────────────────────────────────────────────────────── */}
      {viewMode === "flash" && (
        <div className="space-y-4">
          {flashStep >= 0 && (
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Zap className="h-4 w-4 text-srt-red" />Flash Progress
                  {flashing && <RefreshCw className="h-3.5 w-3.5 animate-spin text-muted-foreground ml-auto" />}
                  {!flashing && flashStep >= 7 && <CheckCircle className="h-4 w-4 text-green-500 ml-auto" />}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="w-full bg-background rounded-full h-2">
                  <div className="bg-srt-red h-2 rounded-full transition-all duration-300" style={{ width: `${flashProgress}%` }} />
                </div>
                <p className="text-xs text-muted-foreground text-right">{flashProgress}%</p>
                <div className="grid grid-cols-1 gap-1">
                  {FLASH_STEPS.map((step, i) => (
                    <div key={step.id} className={`flex items-center gap-2 text-xs px-2 py-1 rounded ${
                      i < flashStep ? "text-green-400" : i === flashStep ? "text-srt-red bg-srt-red/10" : "text-muted-foreground"}`}>
                      {i < flashStep ? <CheckCircle className="h-3.5 w-3.5 shrink-0" /> :
                       i === flashStep && flashing ? <RefreshCw className="h-3.5 w-3.5 shrink-0 animate-spin" /> :
                       <div className="h-3.5 w-3.5 rounded-full border border-current shrink-0" />}
                      <span>{step.label}</span>
                      <span className="ml-auto font-mono opacity-60">{step.service}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Activity className="h-4 w-4 text-srt-red" />UDS Traffic Log
                <Badge variant="outline" className="ml-auto text-xs border-border">{flashLogs.length} frames</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {flashLogs.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground text-sm">
                  No flash operation in progress. Select a calibration from the Library and click Flash.
                </div>
              ) : (
                <VirtualUDSLog entries={flashLogs} />
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ─── Diff Viewer ─────────────────────────────────────────────────────── */}
      {viewMode === "diff" && (
        <div className="space-y-4">
          {!preFlashData || !postFlashData ? (
            <Card className="bg-card border-border">
              <CardContent className="py-16 text-center">
                <Eye className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No diff data available yet.</p>
                <p className="text-sm text-muted-foreground mt-1">Flash a calibration to see the before/after byte diff.</p>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="flex items-center gap-3 mb-2">
                <Badge className="bg-yellow-600/20 text-yellow-400 border-yellow-600/30">BEFORE</Badge>
                <span className="text-muted-foreground text-sm">vs</span>
                <Badge className="bg-green-600/20 text-green-400 border-green-600/30">AFTER</Badge>
                <span className="text-sm text-muted-foreground ml-auto">First 4KB of flash memory</span>
              </div>
              <EEPROMDiffViewer
                oldData={preFlashData}
                newData={postFlashData}
                label={selectedCal?.fileName ?? "Calibration"}
              />
            </>
          )}
        </div>
      )}
    </div>
  );
}
