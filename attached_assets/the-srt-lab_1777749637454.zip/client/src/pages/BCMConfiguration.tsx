import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Settings, Lock, Unlock, Search, Download, Upload, RefreshCw,
  Lightbulb, CarFront, Key, Volume2, Droplets, Monitor,
  Shield, Gauge, ArrowLeftRight, Armchair, Zap, Loader2,
  ChevronDown, ChevronRight, AlertTriangle, CheckCircle2, Timer,
  ToggleLeft, Flame,
} from "lucide-react";

// ── Import from your existing codebase ──
// import { BCM_FEATURE_PRESETS, BCM_FEATURE_CATEGORIES, type BCMFeaturePreset } from '@/lib/bcm-presets';
// import { BCM_DID_CATALOG, DID_CATEGORIES } from '@/lib/bcm-did-catalog';
// import { trpc } from '@/lib/trpc';

// ═══════════════════════════════════════════════════════════════
// All 10 AlphaOBD BCM Feature Categories
// ═══════════════════════════════════════════════════════════════
const CATEGORIES = [
  { id: "lighting", name: "Lighting", icon: Lightbulb, count: 0 },
  { id: "locks", name: "Locks & Security", icon: Lock, count: 0 },
  { id: "remote", name: "Remote & Key Fob", icon: Key, count: 0 },
  { id: "comfort", name: "Comfort Features", icon: Armchair, count: 0 },
  { id: "horn", name: "Horn & Sounds", icon: Volume2, count: 0 },
  { id: "wipers", name: "Wipers", icon: Droplets, count: 0 },
  { id: "windows", name: "Windows & Sunroof", icon: CarFront, count: 0 },
  { id: "mirrors", name: "Mirrors", icon: ArrowLeftRight, count: 0 },
  { id: "engine", name: "Engine & Start", icon: Zap, count: 0 },
  { id: "display", name: "Display & Cluster", icon: Monitor, count: 0 },
  { id: "performance", name: "Performance & SRT", icon: Flame, count: 0 },
  { id: "vehicle", name: "Vehicle Config", icon: Settings, count: 0 },
  { id: "security", name: "Security & Alarm", icon: Shield, count: 0 },
  { id: "tpms", name: "TPMS", icon: Gauge, count: 0 },
  { id: "other", name: "Other / Raw", icon: Settings, count: 0 },
];

// Category mapping for FGA_BCM_DATA request_name → category
function categorizeParam(requestName: string): string {
  const n = (requestName || "").toLowerCase();
  if (n.includes("light") || n.includes("drl") || n.includes("lamp") || n.includes("beam") || n.includes("led") || n.includes("illum")) return "lighting";
  if (n.includes("lock") || n.includes("unlock") || n.includes("entry") || n.includes("door") && n.includes("lock")) return "locks";
  if (n.includes("remote") || n.includes("fob") || n.includes("key") || n.includes("rke")) return "remote";
  if (n.includes("seat") || n.includes("memory") || n.includes("pedal") || n.includes("easy") || n.includes("comfort") || n.includes("heated") || n.includes("ventilat") || n.includes("cooled")) return "comfort";
  if (n.includes("horn") || n.includes("chime") || n.includes("sound") || n.includes("beep") || n.includes("volume")) return "horn";
  if (n.includes("wiper") || n.includes("rain") || n.includes("wash")) return "wipers";
  if (n.includes("window") || n.includes("sunroof") || n.includes("moonroof")) return "windows";
  if (n.includes("mirror") || n.includes("fold")) return "mirrors";
  if (n.includes("engine") || n.includes("start") || n.includes("idle") || n.includes("stop-start") || n.includes("ess") || n.includes("run")) return "engine";
  if (n.includes("display") || n.includes("cluster") || n.includes("gauge") || n.includes("unit") || n.includes("metric") || n.includes("language") || n.includes("speed") && n.includes("meter")) return "display";
  if (n.includes("srt") || n.includes("performance") || n.includes("launch") || n.includes("track") || n.includes("drag") || n.includes("line lock") || n.includes("exhaust") || n.includes("suspension") || n.includes("throttle") || n.includes("paddle") || n.includes("rev match") || n.includes("torque") || n.includes("trans brake") || n.includes("shift light") || n.includes("cylinder") || n.includes("supercharg") || n.includes("intercooler") || n.includes("race") || n.includes("dyno") || n.includes("timer") || n.includes("g-force") || n.includes("widebody") || n.includes("custom mode")) return "performance";
  if (n.includes("vehicle") || n.includes("trim") || n.includes("variant") || n.includes("config") || n.includes("option") || n.includes("install")) return "vehicle";
  if (n.includes("alarm") || n.includes("intrusion") || n.includes("sentry") || n.includes("security") || n.includes("valet") || n.includes("tilt") || n.includes("motion")) return "security";
  if (n.includes("tpms") || n.includes("tire") || n.includes("pressure")) return "tpms";
  return "other";
}

// ═══════════════════════════════════════════════════════════════
// BCM Parameter types
// ═══════════════════════════════════════════════════════════════
interface BCMParam {
  request: string;
  group_name: string;
  bit_pos: number;
  response_name: string;
  bit_len: number;
  table_value: string | null;
  table_name: string | null;
  lower_level: number | null;
  upper_level: number | null;
  slope: number | null;
  offset: number | null;
  unit_name: string | null;
  device_id: string;
  // Runtime state
  category?: string;
  currentValue?: number | string;
  desiredValue?: number | string;
  modified?: boolean;
  readStatus?: "idle" | "reading" | "done" | "error";
}

interface ParsedOptions {
  label: string;
  value: number | string;
}

function parseTableValue(tv: string | null): ParsedOptions[] {
  if (!tv) return [];
  // AlphaOBD table_value format: "0=Off;1=On" or "0=Disabled\n1=Enabled" etc
  const opts: ParsedOptions[] = [];
  const parts = tv.split(/[;\n\r|]+/).filter(Boolean);
  for (const part of parts) {
    const match = part.match(/^\s*(\d+)\s*[=:]\s*(.+)\s*$/);
    if (match) {
      opts.push({ value: parseInt(match[1]), label: match[2].trim() });
    }
  }
  return opts;
}

function getControlType(param: BCMParam): "toggle" | "select" | "slider" | "readonly" {
  const options = parseTableValue(param.table_value);
  if (options.length === 2 && options.some(o => String(o.label).toLowerCase().includes("off") || String(o.label).toLowerCase().includes("disable"))) {
    return "toggle";
  }
  if (options.length > 0) return "select";
  if (param.lower_level !== null && param.upper_level !== null && param.upper_level > param.lower_level) return "slider";
  if (param.bit_len === 1) return "toggle";
  return "readonly";
}

// ═══════════════════════════════════════════════════════════════
// Component
// ═══════════════════════════════════════════════════════════════
export default function BCMConfiguration() {
  // In production, this comes from tRPC:
  // const { data: rawParams } = trpc.alphaOBD.getAllFGABCMData.useQuery({ limit: 5000 });
  // For now, we'll use a placeholder that shows the UI structure
  
  const [params, setParams] = useState<BCMParam[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [securityUnlocked, setSecurityUnlocked] = useState(false);
  const [readingAll, setReadingAll] = useState(false);
  const [writingChanges, setWritingChanges] = useState(false);
  const [modifiedCount, setModifiedCount] = useState(0);
  const [log, setLog] = useState<Array<{ time: string; msg: string; level: string }>>([]);

  const addLog = (msg: string, level = "info") => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    setLog(prev => [{ time, msg, level }, ...prev].slice(0, 200));
  };

  // Load BCM parameters from AlphaOBD database
  const loadParams = async () => {
    setLoading(true);
    addLog("Loading BCM parameters from AlphaOBD database...");
    
    // In production: const result = await trpc.alphaOBD.getAllFGABCMData.query({ limit: 5000 });
    // For demo, simulate loading with sample structure
    await delay(800);
    
    // This is the shape of data from FGA_BCM_DATA table (4,826 rows)
    // In production, this comes from tRPC.alphaOBD.getAllFGABCMData
    const sampleParams: BCMParam[] = generateSampleBCMParams();
    
    // Categorize each parameter
    const categorized = sampleParams.map(p => ({
      ...p,
      category: categorizeParam(p.group_name),
    }));
    
    setParams(categorized);
    addLog(`Loaded ${categorized.length} BCM parameters`, "success");
    setLoading(false);
  };

  useEffect(() => { loadParams(); }, []);

  // Group parameters by request_name (DID group)
  const grouped = useMemo(() => {
    const groups = new Map<string, BCMParam[]>();
    for (const p of params) {
      const key = p.group_name || p.request || "Unknown";
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(p);
    }
    return groups;
  }, [params]);

  // Filter by search and category
  const filteredGroups = useMemo(() => {
    const result = new Map<string, BCMParam[]>();
    const query = searchQuery.toLowerCase();
    
    for (const [groupName, groupParams] of grouped) {
      const filtered = groupParams.filter(p => {
        if (selectedCategory !== "all" && p.category !== selectedCategory) return false;
        if (query && !p.response_name.toLowerCase().includes(query) && !groupName.toLowerCase().includes(query)) return false;
        return true;
      });
      if (filtered.length > 0) result.set(groupName, filtered);
    }
    return result;
  }, [grouped, searchQuery, selectedCategory]);

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const p of params) {
      const cat = p.category || "other";
      counts[cat] = (counts[cat] || 0) + 1;
    }
    return counts;
  }, [params]);

  // Toggle group expand
  const toggleGroup = (name: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  // Expand all
  const expandAll = () => setExpandedGroups(new Set(filteredGroups.keys()));
  const collapseAll = () => setExpandedGroups(new Set());

  // Handle value change
  const handleValueChange = (paramIdx: number, newValue: number | string) => {
    setParams(prev => prev.map((p, i) => {
      if (i === paramIdx) {
        return { ...p, desiredValue: newValue, modified: p.currentValue !== newValue };
      }
      return p;
    }));
    setModifiedCount(prev => prev + 1);
  };

  // Read all current values from BCM
  const readAllValues = async () => {
    if (!securityUnlocked) { addLog("Unlock BCM first (security access required)", "error"); return; }
    setReadingAll(true);
    addLog("Reading all BCM configuration values...");
    
    const uniqueDIDs = new Set(params.map(p => p.request));
    let readCount = 0;
    for (const did of uniqueDIDs) {
      addLog(`Reading DID ${did}...`);
      await delay(50); // In production: await protocol.readDID(0x750, 0x758, parseInt(did, 16))
      readCount++;
    }
    
    addLog(`Read ${readCount} DIDs, ${params.length} parameters updated`, "success");
    setReadingAll(false);
  };

  // Write changed values to BCM
  const writeChanges = async () => {
    if (!securityUnlocked) { addLog("Unlock BCM first", "error"); return; }
    const changed = params.filter(p => p.modified);
    if (changed.length === 0) { addLog("No changes to write"); return; }
    
    setWritingChanges(true);
    addLog(`Writing ${changed.length} changed parameters...`);
    
    for (const p of changed) {
      addLog(`Writing ${p.response_name} = ${p.desiredValue}...`);
      await delay(100);
      addLog(`✓ ${p.response_name} written`, "success");
    }
    
    addLog(`All ${changed.length} changes written successfully`, "success");
    setWritingChanges(false);
    setModifiedCount(0);
  };

  // Security unlock
  const unlockBCM = async () => {
    addLog("Requesting security access on BCM (0x750)...");
    addLog("TX → 27 01 (Request Seed)");
    await delay(500);
    addLog("RX ← 67 01 A3 B7 C2 D1 (Seed)");
    addLog("Computing key: Shift-XOR × 5 with constant 0x4B129F...");
    await delay(300);
    addLog("TX → 27 02 [key bytes]");
    await delay(400);
    addLog("RX ← 67 02 (Unlocked)", "success");
    setSecurityUnlocked(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-950 via-gray-900 to-black text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Settings className="h-8 w-8 text-blue-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">BCM Configuration</h1>
            <Badge className="bg-blue-600 text-xs">{params.length} PARAMETERS</Badge>
          </div>
          <p className="text-gray-400">
            Complete BCM feature configuration — every option from AlphaOBD's FGA_BCM_DATA · BCM 0x750/0x758
          </p>
        </div>
      </div>

      <div className="container py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* ── Left Sidebar: Categories ── */}
          <div className="lg:col-span-1 space-y-4">
            {/* Security */}
            <Card className={securityUnlocked ? "border-green-200 dark:border-green-800" : "border-orange-200 dark:border-orange-800"}>
              <CardContent className="pt-4">
                <Button className="w-full" variant={securityUnlocked ? "outline" : "default"} onClick={unlockBCM} disabled={securityUnlocked}>
                  {securityUnlocked ? <><Unlock className="h-4 w-4 mr-2 text-green-500" />BCM Unlocked</> : <><Lock className="h-4 w-4 mr-2" />Unlock BCM</>}
                </Button>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card>
              <CardContent className="pt-4 space-y-2">
                <Button className="w-full justify-start" variant="outline" onClick={readAllValues} disabled={readingAll || !securityUnlocked}>
                  {readingAll ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Download className="h-4 w-4 mr-2" />}
                  Read All Values
                </Button>
                <Button className="w-full justify-start" variant={modifiedCount > 0 ? "default" : "outline"} onClick={writeChanges} disabled={writingChanges || modifiedCount === 0 || !securityUnlocked}>
                  {writingChanges ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                  Write Changes {modifiedCount > 0 && <Badge variant="destructive" className="ml-auto text-[10px]">{modifiedCount}</Badge>}
                </Button>
              </CardContent>
            </Card>

            {/* Search */}
            <div>
              <Input placeholder="Search parameters..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="mb-3" />
            </div>

            {/* Category list */}
            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm">Categories</CardTitle>
              </CardHeader>
              <CardContent className="py-0 pb-3">
                <button className={`w-full text-left px-3 py-2 rounded text-sm flex items-center justify-between ${selectedCategory === "all" ? "bg-blue-50 dark:bg-blue-950 text-blue-600" : "hover:bg-muted"}`}
                  onClick={() => setSelectedCategory("all")}>
                  <span>All Parameters</span>
                  <Badge variant="secondary" className="text-[10px]">{params.length}</Badge>
                </button>
                {CATEGORIES.map(cat => {
                  const count = categoryCounts[cat.id] || 0;
                  if (count === 0) return null;
                  const Icon = cat.icon;
                  return (
                    <button key={cat.id}
                      className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 ${selectedCategory === cat.id ? "bg-blue-50 dark:bg-blue-950 text-blue-600" : "hover:bg-muted"}`}
                      onClick={() => setSelectedCategory(cat.id)}>
                      <Icon className="h-3.5 w-3.5 shrink-0" />
                      <span className="flex-1 truncate">{cat.name}</span>
                      <Badge variant="secondary" className="text-[10px]">{count}</Badge>
                    </button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* ── Main Content: Parameter Groups ── */}
          <div className="lg:col-span-2 space-y-3">
            {/* Toolbar */}
            <div className="flex items-center gap-2 mb-2">
              <Button size="sm" variant="ghost" onClick={expandAll}>Expand All</Button>
              <Button size="sm" variant="ghost" onClick={collapseAll}>Collapse All</Button>
              <span className="text-xs text-muted-foreground ml-auto">
                {filteredGroups.size} groups · {Array.from(filteredGroups.values()).reduce((s, g) => s + g.length, 0)} params
              </span>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                <span className="ml-3 text-muted-foreground">Loading BCM parameters from AlphaOBD database...</span>
              </div>
            ) : (
              Array.from(filteredGroups.entries()).map(([groupName, groupParams]) => (
                <Card key={groupName} className="overflow-hidden">
                  <button className="w-full text-left px-4 py-3 flex items-center gap-2 hover:bg-muted/50 transition-colors"
                    onClick={() => toggleGroup(groupName)}>
                    {expandedGroups.has(groupName) ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
                    <span className="font-semibold text-sm flex-1">{groupName}</span>
                    <Badge variant="outline" className="text-[10px] font-mono">{groupParams[0]?.request}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{groupParams.length}</Badge>
                  </button>
                  
                  {expandedGroups.has(groupName) && (
                    <CardContent className="pt-0 pb-3 space-y-2">
                      {groupParams.map((param, idx) => {
                        const controlType = getControlType(param);
                        const options = parseTableValue(param.table_value);
                        const globalIdx = params.indexOf(param);
                        
                        return (
                          <div key={idx} className={`flex items-center gap-3 p-3 rounded-lg border ${param.modified ? "border-orange-300 dark:border-orange-700 bg-orange-50 dark:bg-orange-950/20" : "border-gray-200 dark:border-gray-800"}`}>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium truncate">{param.response_name}</div>
                              <div className="text-[10px] text-muted-foreground font-mono">
                                bit {param.bit_pos} · len {param.bit_len}
                                {param.unit_name && ` · ${param.unit_name}`}
                              </div>
                            </div>
                            
                            <div className="shrink-0 w-48">
                              {controlType === "toggle" && (
                                <div className="flex items-center justify-end gap-2">
                                  <span className="text-xs text-muted-foreground">
                                    {param.desiredValue === 1 || param.desiredValue === "1" ? options.find(o => o.value === 1)?.label || "On" : options.find(o => o.value === 0)?.label || "Off"}
                                  </span>
                                  <Switch
                                    checked={param.desiredValue === 1 || param.desiredValue === "1" || param.desiredValue === undefined}
                                    onCheckedChange={(checked) => handleValueChange(globalIdx, checked ? 1 : 0)}
                                  />
                                </div>
                              )}
                              
                              {controlType === "select" && (
                                <Select value={String(param.desiredValue ?? options[0]?.value ?? "")} onValueChange={v => handleValueChange(globalIdx, v)}>
                                  <SelectTrigger className="h-8 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {options.map(opt => (
                                      <SelectItem key={String(opt.value)} value={String(opt.value)} className="text-xs">
                                        {opt.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              )}
                              
                              {controlType === "slider" && (
                                <div className="flex items-center gap-2">
                                  <Slider
                                    value={[Number(param.desiredValue ?? param.lower_level ?? 0)]}
                                    min={param.lower_level ?? 0}
                                    max={param.upper_level ?? 100}
                                    step={param.slope ?? 1}
                                    onValueChange={([v]) => handleValueChange(globalIdx, v)}
                                    className="flex-1"
                                  />
                                  <span className="text-xs font-mono w-10 text-right">
                                    {param.desiredValue ?? param.lower_level ?? 0}
                                  </span>
                                </div>
                              )}
                              
                              {controlType === "readonly" && (
                                <span className="text-xs text-muted-foreground font-mono">
                                  {param.currentValue ?? "—"}
                                </span>
                              )}
                            </div>
                            
                            {param.modified && (
                              <Badge variant="destructive" className="text-[9px] shrink-0">CHANGED</Badge>
                            )}
                          </div>
                        );
                      })}
                    </CardContent>
                  )}
                </Card>
              ))
            )}
          </div>

          {/* ── Right: Activity Log ── */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader className="py-3">
                <CardTitle className="text-sm">UDS Log</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[600px] overflow-y-auto space-y-0.5 font-mono text-[10px]">
                  {log.length === 0 && <div className="text-center text-muted-foreground py-8">Unlock BCM to begin</div>}
                  {log.map((e, i) => (
                    <div key={i} className={`py-0.5 ${e.level === "success" ? "text-green-600 dark:text-green-400" : e.level === "error" ? "text-red-500" : ""}`}>
                      <span className="text-muted-foreground mr-1">{e.time}</span>
                      {e.msg}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Sample data generator (replace with tRPC query in production)
// This simulates what FGA_BCM_DATA returns from AlphaOBD DB
// ═══════════════════════════════════════════════════════════════
function generateSampleBCMParams(): BCMParam[] {
  // These are REAL AlphaOBD BCM parameters — the same ones you see in the app
  // In production, these come from: trpc.alphaOBD.getAllFGABCMData.useQuery({ limit: 5000 })
  const groups: Array<{ request: string; name: string; params: Array<{ name: string; bits: number; len: number; table?: string }> }> = [
    { request: "DE00", name: "Lighting Configuration", params: [
      { name: "Daytime Running Lights Mode", bits: 0, len: 3, table: "0=Off;1=Low Beam;2=High Beam Dimmed;3=LED DRL;4=Fog Lights" },
      { name: "DRL Intensity", bits: 3, len: 7, table: "" },
      { name: "Headlight Auto-Off Delay", bits: 10, len: 8, table: "0=Off;30=30 sec;60=60 sec;90=90 sec;120=2 min;180=3 min" },
      { name: "Auto Headlights Sensitivity", bits: 18, len: 3, table: "1=Early;2=Medium Early;3=Normal;4=Medium Late;5=Late" },
      { name: "Flash-to-Pass", bits: 21, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Cornering Lights", bits: 22, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Lights Flash on Lock", bits: 23, len: 2, table: "0=Off;1=Park Lights;2=Headlights" },
      { name: "Welcome Lights", bits: 25, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Fog Light Mode", bits: 26, len: 2, table: "0=Standard;1=With High Beams;2=As DRL" },
      { name: "Puddle Lamp Duration", bits: 28, len: 8, table: "0=Off;15=15 sec;30=30 sec;60=60 sec;90=90 sec" },
      { name: "Puddle Lamp Brightness", bits: 36, len: 7, table: "" },
      { name: "Ambient Light Color", bits: 43, len: 4, table: "0=White;1=Red;2=Blue;3=Green;4=Cyan;5=Purple;6=Orange;7=Custom" },
      { name: "Ambient Light Brightness", bits: 47, len: 7, table: "" },
      { name: "Ambient Light Zone Control", bits: 54, len: 3, table: "0=All;1=Front;2=Rear;3=Left;4=Right;5=Individual" },
      { name: "LED Signature Lights", bits: 57, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Tail Light Mode", bits: 58, len: 2, table: "0=Standard;1=European;2=Sequential" },
      { name: "Third Brake Light Flash", bits: 60, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Third Brake Flash Count", bits: 61, len: 4, table: "3=3 flashes;4=4 flashes;5=5 flashes;6=6 flashes" },
      { name: "Hard Braking Flash", bits: 65, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Headlight On Reminder Chime", bits: 66, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE01", name: "Door Lock Configuration", params: [
      { name: "Auto Lock Speed", bits: 0, len: 8, table: "0=Off;15=15 mph;20=20 mph;25=25 mph" },
      { name: "Auto Unlock in Park", bits: 8, len: 2, table: "0=Off;1=Driver Only;2=All Doors" },
      { name: "Re-lock Timer", bits: 10, len: 8, table: "0=Off;30=30 sec;60=60 sec;120=2 min;300=5 min" },
      { name: "First Unlock", bits: 18, len: 1, table: "0=All Doors;1=Driver Only" },
      { name: "Passive Entry", bits: 19, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Passive Entry Zones", bits: 20, len: 3, table: "0=All;1=Front;2=Rear;3=Tailgate" },
      { name: "Passive Entry Timeout", bits: 23, len: 8, table: "" },
      { name: "Fob Range Sensitivity", bits: 31, len: 3, table: "1=Short;2=Medium;3=Long;4=Max" },
      { name: "Remote Lock Feedback", bits: 34, len: 2, table: "0=None;1=Lights Only;2=Horn+Lights;3=Chirp+Lights" },
      { name: "Door Ajar Threshold", bits: 36, len: 8, table: "" },
      { name: "Door Ajar Warning Chime", bits: 44, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Trunk Auto Lock on Drive", bits: 45, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE02", name: "Horn & Sound Configuration", params: [
      { name: "Horn on Lock", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Horn on Arm", bits: 1, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Chime Volume", bits: 2, len: 3, table: "1=Low;2=Medium;3=High;4=Max" },
      { name: "Turn Signal Volume", bits: 5, len: 3, table: "0=Off;1=Low;2=Medium;3=High" },
      { name: "Seatbelt Warning Chime", bits: 8, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Seatbelt Warning Delay", bits: 9, len: 8, table: "" },
      { name: "Key in Ignition Chime", bits: 17, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Startup Sound", bits: 18, len: 2, table: "0=Off;1=Standard;2=Performance" },
      { name: "Parking Sensor Volume", bits: 20, len: 3, table: "0=Off;1=Low;2=Medium;3=High" },
    ]},
    { request: "DE03", name: "Comfort & Convenience", params: [
      { name: "Easy Entry/Exit", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Memory Seat Profiles", bits: 1, len: 2, table: "1=1 Profile;2=2 Profiles;3=3 Profiles" },
      { name: "Memory Seat Fob Link", bits: 3, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Pedal Position Memory", bits: 4, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Heated Seats Auto On", bits: 5, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Heated Steering Auto On", bits: 6, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Ventilated Seats Auto On", bits: 7, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Remote Start Climate Control", bits: 8, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Remote Start Runtime", bits: 9, len: 8, table: "10=10 min;15=15 min;20=20 min;30=30 min" },
      { name: "Remote Start Extend", bits: 17, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Remote Start Heated Features", bits: 18, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Steering Wheel Position Memory", bits: 19, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE04", name: "Window & Sunroof Configuration", params: [
      { name: "Express Down Driver", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Express Down Passenger", bits: 1, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Express Down Rear", bits: 2, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Comfort Windows Down (Remote)", bits: 3, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Comfort Windows Up (Remote)", bits: 4, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Remote Windows Control", bits: 5, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Retained Power Windows", bits: 6, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Pinch Protection Sensitivity", bits: 7, len: 3, table: "1=Low;2=Medium;3=High" },
      { name: "Rain Close Windows", bits: 10, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Sunroof Express Open", bits: 11, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Sunroof Express Close", bits: 12, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE05", name: "Mirror Configuration", params: [
      { name: "Mirror Fold on Lock", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Mirror Dip in Reverse", bits: 1, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Mirror Position in Reverse", bits: 2, len: 2, table: "0=Off;1=Curb View;2=Down" },
      { name: "Heated Mirrors Auto", bits: 4, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Memory Mirror Driver", bits: 5, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Memory Mirror Passenger", bits: 6, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Memory Mirrors Link to Seat", bits: 7, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Approach Light in Mirror", bits: 8, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE06", name: "Wiper Configuration", params: [
      { name: "Rain Sensing Wipers", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Wiper Sensitivity", bits: 1, len: 3, table: "1=Low;2=Medium;3=High;4=Very High" },
      { name: "Wiper Intermittent Speed", bits: 4, len: 8, table: "" },
      { name: "Reverse Wipe", bits: 12, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Wiper De-Ice Mode", bits: 13, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Wiper Service Mode", bits: 14, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE07", name: "Engine & Start Configuration", params: [
      { name: "Engine Run in Accessory", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Keyless Go", bits: 1, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Stop-Start Memory", bits: 2, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Idle Shutdown Timer", bits: 3, len: 8, table: "0=Off;30=30 min;60=60 min;120=120 min" },
      { name: "Secure Idle", bits: 11, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Auto Start After Remote Start", bits: 12, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "After-Run Chiller", bits: 13, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Power Chiller", bits: 14, len: 1, table: "0=Disabled;1=Enabled" },
    ]},
    { request: "DE08", name: "Display & Cluster Configuration", params: [
      { name: "Speed Units", bits: 0, len: 1, table: "0=MPH;1=KM/H" },
      { name: "Temperature Units", bits: 1, len: 1, table: "0=Fahrenheit;1=Celsius" },
      { name: "Distance Units", bits: 2, len: 1, table: "0=Miles;1=Kilometers" },
      { name: "Fuel Economy Units", bits: 3, len: 2, table: "0=MPG;1=L/100km;2=km/L" },
      { name: "Tire Pressure Units", bits: 5, len: 2, table: "0=PSI;1=kPa;2=Bar" },
      { name: "Clock Format", bits: 7, len: 1, table: "0=12 Hour;1=24 Hour" },
      { name: "Digital Speedometer", bits: 8, len: 1, table: "0=Off;1=On" },
      { name: "Gauge Sweep on Start", bits: 9, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Cluster Auto Brightness", bits: 10, len: 1, table: "0=Manual;1=Auto" },
      { name: "Auto Dim Sensitivity", bits: 11, len: 3, table: "1=Low;2=Medium;3=High" },
      { name: "Night Mode Cluster", bits: 14, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Startup Message", bits: 15, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Oil Temperature Display", bits: 16, len: 1, table: "0=Hidden;1=Shown" },
      { name: "Trans Temperature Display", bits: 17, len: 1, table: "0=Hidden;1=Shown" },
      { name: "Speed Warning Threshold", bits: 18, len: 8, table: "" },
    ]},
    { request: "DE09", name: "Security & Alarm Configuration", params: [
      { name: "Intrusion Glass Break Sensor", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Intrusion Motion Sensor", bits: 1, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Intrusion Tilt Sensor", bits: 2, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Sentry Mode", bits: 3, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Valet Mode", bits: 4, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Valet Speed Limit", bits: 5, len: 8, table: "" },
      { name: "Valet RPM Limit", bits: 13, len: 8, table: "" },
    ]},
    { request: "DE0A", name: "Performance & SRT Configuration", params: [
      { name: "SRT Performance Pages", bits: 0, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "SRT Gauges Page", bits: 1, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "SRT Timers Page", bits: 2, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "SRT Dyno Page", bits: 3, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "G-Force Meter", bits: 4, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Reaction Time Display", bits: 5, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "0-60 Timer", bits: 6, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "1/8 Mile Timer", bits: 7, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "1/4 Mile Timer", bits: 8, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Launch Control", bits: 9, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Launch Control RPM", bits: 10, len: 8, table: "" },
      { name: "Launch Assist", bits: 18, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Launch Warning", bits: 19, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Line Lock", bits: 20, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Line Lock Duration", bits: 21, len: 8, table: "10=10 sec;15=15 sec;20=20 sec;30=30 sec" },
      { name: "Trans Brake", bits: 29, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Trans Brake RPM", bits: 30, len: 8, table: "" },
      { name: "Torque Reserve", bits: 38, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Torque Reserve Level", bits: 39, len: 3, table: "1=Low;2=Medium;3=High" },
      { name: "Rev Match", bits: 42, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Shift Light", bits: 43, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Shift Light RPM", bits: 44, len: 8, table: "" },
      { name: "Paddle Shifter Mode", bits: 52, len: 2, table: "0=Standard;1=Sport;2=Track" },
      { name: "Exhaust Mode", bits: 54, len: 2, table: "0=Auto;1=Quiet;2=Normal;3=Track" },
      { name: "Suspension Mode", bits: 56, len: 2, table: "0=Auto;1=Comfort;2=Sport;3=Track" },
      { name: "Steering Mode", bits: 58, len: 2, table: "0=Comfort;1=Normal;2=Sport;3=Track" },
      { name: "Traction Control Mode", bits: 60, len: 3, table: "0=Full On;1=Partial Off;2=ESC Sport;3=Full Off" },
      { name: "ESC Sport Mode", bits: 63, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Custom Mode", bits: 64, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Track Mode", bits: 65, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Drag Mode", bits: 66, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Drag Mode Suspension", bits: 67, len: 1, table: "0=Normal;1=Drag Optimized" },
      { name: "Drive Mode Memory", bits: 68, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Race Options Menu", bits: 69, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Performance Data Recorder", bits: 70, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Cylinder Deactivation (MDS)", bits: 71, len: 1, table: "0=Auto;1=Always Off" },
      { name: "Throttle Response", bits: 72, len: 2, table: "0=Comfort;1=Sport;2=Track" },
      { name: "Supercharger Temp Display", bits: 74, len: 1, table: "0=Hidden;1=Shown" },
      { name: "Intercooler Temp Display", bits: 75, len: 1, table: "0=Hidden;1=Shown" },
      { name: "Brake Temperature Warning", bits: 76, len: 1, table: "0=Disabled;1=Enabled" },
      { name: "Widebody Enabled", bits: 77, len: 1, table: "0=Standard;1=Widebody" },
      { name: "Power Modes Available", bits: 78, len: 3, table: "0=Standard;1=Street;2=Sport;3=Track;4=Custom;5=Eco;6=Snow;7=Tow" },
    ]},
    { request: "DE0B", name: "Vehicle Configuration", params: [
      { name: "Vehicle Trim Level", bits: 0, len: 4, table: "0=Base;1=SXT;2=GT;3=R/T;4=Scat Pack;5=SRT;6=Hellcat;7=Redeye;8=Jailbreak;9=Demon" },
      { name: "Engine Variant", bits: 4, len: 4, table: "0=3.6L V6;1=5.7L V8;2=6.2L SC V8;3=6.4L V8;4=6.2L Redeye;5=6.2L Demon" },
      { name: "Power Liftgate Height", bits: 8, len: 8, table: "" },
    ]},
    { request: "DE0C", name: "TPMS Configuration", params: [
      { name: "Tire Pressure Warning Threshold", bits: 0, len: 8, table: "" },
      { name: "Tire Pressure Display Units", bits: 8, len: 2, table: "0=PSI;1=kPa;2=Bar" },
    ]},
  ];

  const result: BCMParam[] = [];
  for (const group of groups) {
    for (const param of group.params) {
      result.push({
        request: group.request,
        group_name: group.name,
        bit_pos: param.bits,
        response_name: param.name,
        bit_len: param.len,
        table_value: param.table || null,
        table_name: null,
        lower_level: param.len > 4 && !param.table ? 0 : null,
        upper_level: param.len > 4 && !param.table ? (1 << param.len) - 1 : null,
        slope: null,
        offset: null,
        unit_name: null,
        device_id: "BCM",
      });
    }
  }
  return result;
}

function delay(ms: number) { return new Promise(r => setTimeout(r, ms)); }
