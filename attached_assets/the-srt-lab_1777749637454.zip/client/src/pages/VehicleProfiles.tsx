/**
 * Vehicle Profiles — per-VIN persistent context viewer
 * Shows all vehicles in memory with their notes, DTC history, BCM snapshots, and module manifests
 */

import { useState, useEffect } from "react";
import { Car, Plus, Trash2, FileText, AlertTriangle, Settings, Cpu, Clock, Tag, ChevronDown, ChevronRight, Edit2, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { vehicleMemory, type VehicleMemory, type VehicleNote } from "@/lib/vehicleMemory";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const CATEGORY_COLORS: Record<VehicleNote["category"], string> = {
  issue: "bg-red-900/40 text-red-400 border-red-500/30",
  fix: "bg-green-900/40 text-green-400 border-green-500/30",
  note: "bg-blue-900/40 text-blue-400 border-blue-500/30",
  warning: "bg-yellow-900/40 text-yellow-400 border-yellow-500/30",
};

function VehicleCard({ vehicle, onDelete, onRefresh }: {
  vehicle: VehicleMemory;
  onDelete: (vin: string) => void;
  onRefresh: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<"notes" | "dtcs" | "modules" | "bcm">("notes");
  const [newNote, setNewNote] = useState("");
  const [noteCategory, setNoteCategory] = useState<VehicleNote["category"]>("note");
  const [editingMeta, setEditingMeta] = useState(false);
  const [meta, setMeta] = useState({
    year: vehicle.year?.toString() ?? "",
    make: vehicle.make ?? "",
    model: vehicle.model ?? "",
    trim: vehicle.trim ?? "",
    engine: vehicle.engine ?? "",
    mileage: vehicle.mileage?.toString() ?? "",
  });

  const activeDTCs = vehicle.dtcHistory.filter((d) => !d.cleared);
  const clearedDTCs = vehicle.dtcHistory.filter((d) => d.cleared);

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    vehicleMemory.addNote(vehicle.vin, { text: newNote.trim(), category: noteCategory, author: "Technician" });
    setNewNote("");
    onRefresh();
    toast.success("Note added");
  };

  const handleSaveMeta = () => {
    vehicleMemory.upsert(vehicle.vin, {
      year: meta.year ? parseInt(meta.year) : undefined,
      make: meta.make || undefined,
      model: meta.model || undefined,
      trim: meta.trim || undefined,
      engine: meta.engine || undefined,
      mileage: meta.mileage ? parseInt(meta.mileage) : undefined,
    });
    setEditingMeta(false);
    onRefresh();
    toast.success("Vehicle info updated");
  };

  const displayName = [vehicle.year, vehicle.make, vehicle.model, vehicle.trim].filter(Boolean).join(" ") || vehicle.vin;

  return (
    <div className={cn("border rounded-lg overflow-hidden transition-all", expanded ? "border-red-500/30" : "border-white/10")}>
      {/* Header */}
      <div
        className="flex items-center gap-3 p-4 cursor-pointer hover:bg-white/5 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center justify-center w-8 h-8 rounded bg-red-600/20 border border-red-600/30 shrink-0">
          <Car className="w-4 h-4 text-red-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-bold text-white truncate">{displayName}</span>
            <span className="text-xs font-mono text-gray-500">{vehicle.vin}</span>
          </div>
          <div className="flex items-center gap-3 mt-0.5 text-xs text-gray-500">
            <span><Clock className="w-3 h-3 inline mr-0.5" />Last seen {new Date(vehicle.lastSeen).toLocaleDateString()}</span>
            {vehicle.knownModules.length > 0 && <span><Cpu className="w-3 h-3 inline mr-0.5" />{vehicle.knownModules.length} modules</span>}
            {activeDTCs.length > 0 && <span className="text-orange-400"><AlertTriangle className="w-3 h-3 inline mr-0.5" />{activeDTCs.length} active DTCs</span>}
            {vehicle.notes.length > 0 && <span><FileText className="w-3 h-3 inline mr-0.5" />{vehicle.notes.length} notes</span>}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {vehicle.tags.map((tag) => (
            <Badge key={tag} variant="outline" className="border-white/10 text-gray-400 text-xs">{tag}</Badge>
          ))}
          <button
            onClick={(e) => { e.stopPropagation(); onDelete(vehicle.vin); }}
            className="text-gray-600 hover:text-red-400 transition-colors p-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          {expanded ? <ChevronDown className="w-4 h-4 text-gray-500" /> : <ChevronRight className="w-4 h-4 text-gray-500" />}
        </div>
      </div>

      {expanded && (
        <div className="border-t border-white/10">
          {/* Meta editor */}
          <div className="p-4 border-b border-white/10 bg-black/20">
            {editingMeta ? (
              <div className="space-y-2">
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { key: "year", label: "Year" },
                    { key: "make", label: "Make" },
                    { key: "model", label: "Model" },
                    { key: "trim", label: "Trim" },
                    { key: "engine", label: "Engine" },
                    { key: "mileage", label: "Mileage" },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="text-xs text-gray-500 mb-1 block">{label}</label>
                      <Input
                        value={meta[key as keyof typeof meta]}
                        onChange={(e) => setMeta({ ...meta, [key]: e.target.value })}
                        className="h-7 text-xs bg-white/5 border-white/10"
                        placeholder={label}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" className="h-7 text-xs bg-red-600 hover:bg-red-700" onClick={handleSaveMeta}>
                    <Check className="w-3 h-3 mr-1" /> Save
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs border-white/10" onClick={() => setEditingMeta(false)}>
                    <X className="w-3 h-3 mr-1" /> Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex flex-wrap gap-3 text-xs text-gray-400">
                  {vehicle.year && <span>📅 {vehicle.year}</span>}
                  {vehicle.make && <span>🏭 {vehicle.make}</span>}
                  {vehicle.model && <span>🚗 {vehicle.model}</span>}
                  {vehicle.trim && <span>✨ {vehicle.trim}</span>}
                  {vehicle.engine && <span>⚙️ {vehicle.engine}</span>}
                  {vehicle.mileage && <span>📍 {vehicle.mileage.toLocaleString()} mi</span>}
                  {!vehicle.year && !vehicle.make && <span className="text-gray-600 italic">No vehicle info — click Edit to add</span>}
                </div>
                <Button size="sm" variant="outline" className="h-6 text-xs border-white/10 shrink-0" onClick={() => setEditingMeta(true)}>
                  <Edit2 className="w-3 h-3 mr-1" /> Edit
                </Button>
              </div>
            )}
          </div>

          {/* Tabs */}
          <div className="flex border-b border-white/10">
            {(["notes", "dtcs", "modules", "bcm"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-4 py-2 text-xs font-semibold uppercase tracking-wide transition-colors",
                  activeTab === tab ? "text-red-400 border-b-2 border-red-500" : "text-gray-500 hover:text-gray-300"
                )}
              >
                {tab === "notes" ? `Notes (${vehicle.notes.length})` :
                 tab === "dtcs" ? `DTCs (${activeDTCs.length})` :
                 tab === "modules" ? `Modules (${vehicle.knownModules.length})` :
                 `BCM (${vehicle.bcmSnapshots.length})`}
              </button>
            ))}
          </div>

          <div className="p-4">
            {activeTab === "notes" && (
              <div className="space-y-3">
                {vehicle.notes.length === 0 && (
                  <p className="text-xs text-gray-600 italic">No notes yet</p>
                )}
                {vehicle.notes.slice().reverse().map((note) => (
                  <div key={note.id} className={cn("rounded p-2 border text-xs", CATEGORY_COLORS[note.category])}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold uppercase text-[10px] tracking-wide">{note.category}</span>
                      <span className="text-gray-500">{new Date(note.timestamp).toLocaleString()}</span>
                    </div>
                    <p>{note.text}</p>
                  </div>
                ))}
                <div className="flex gap-2 mt-3">
                  <Select value={noteCategory} onValueChange={(v) => setNoteCategory(v as VehicleNote["category"])}>
                    <SelectTrigger className="w-28 h-8 text-xs bg-white/5 border-white/10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="note">Note</SelectItem>
                      <SelectItem value="issue">Issue</SelectItem>
                      <SelectItem value="fix">Fix</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                    </SelectContent>
                  </Select>
                  <Textarea
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Add a note..."
                    className="flex-1 h-8 min-h-0 py-1.5 text-xs bg-white/5 border-white/10 resize-none"
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleAddNote(); } }}
                  />
                  <Button size="sm" className="h-8 text-xs bg-red-600 hover:bg-red-700 shrink-0" onClick={handleAddNote}>
                    Add
                  </Button>
                </div>
              </div>
            )}

            {activeTab === "dtcs" && (
              <div className="space-y-2">
                {activeDTCs.length === 0 && clearedDTCs.length === 0 && (
                  <p className="text-xs text-gray-600 italic">No DTC history</p>
                )}
                {activeDTCs.map((dtc, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs bg-orange-950/20 border border-orange-500/20 rounded p-2">
                    <AlertTriangle className="w-3 h-3 text-orange-400 shrink-0" />
                    <span className="font-mono text-orange-400">{dtc.code}</span>
                    <span className="text-gray-300 flex-1">{dtc.description}</span>
                    <span className="text-gray-500 shrink-0">{new Date(dtc.timestamp).toLocaleDateString()}</span>
                  </div>
                ))}
                {clearedDTCs.length > 0 && (
                  <div className="mt-2">
                    <p className="text-xs text-gray-600 mb-1">Cleared DTCs ({clearedDTCs.length})</p>
                    {clearedDTCs.slice(-5).map((dtc, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-gray-600 py-1">
                        <span className="font-mono line-through">{dtc.code}</span>
                        <span className="flex-1 line-through">{dtc.description}</span>
                        <span>{new Date(dtc.timestamp).toLocaleDateString()}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === "modules" && (
              <div className="space-y-1">
                {vehicle.knownModules.length === 0 && (
                  <p className="text-xs text-gray-600 italic">No module scan history — run a scan to populate</p>
                )}
                {vehicle.knownModules.map((mod) => (
                  <div key={mod.txId} className="flex items-center gap-2 text-xs bg-white/5 rounded p-2">
                    <Cpu className="w-3 h-3 text-green-400 shrink-0" />
                    <span className="font-mono text-green-400">TX:0x{mod.txId.toString(16).toUpperCase()}</span>
                    <span className="text-white font-semibold">{mod.label}</span>
                    {mod.partNumber && <span className="text-gray-400">PN:{mod.partNumber}</span>}
                    {mod.serialNumber && <span className="text-gray-500">SN:{mod.serialNumber}</span>}
                    <span className="text-gray-600 ml-auto">{new Date(mod.lastSeen).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "bcm" && (
              <div className="space-y-2">
                {vehicle.bcmSnapshots.length === 0 && (
                  <p className="text-xs text-gray-600 italic">No BCM snapshots — save a snapshot from BCM Config</p>
                )}
                {vehicle.bcmSnapshots.slice().reverse().map((snap, i) => (
                  <div key={i} className="border border-white/10 rounded p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-white">{snap.label}</span>
                      <span className="text-xs text-gray-500">{new Date(snap.timestamp).toLocaleString()}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1">
                      {Object.entries(snap.params).slice(0, 8).map(([k, v]) => (
                        <div key={k} className="text-xs">
                          <span className="text-gray-500">{k}: </span>
                          <span className="text-gray-300">{v}</span>
                        </div>
                      ))}
                      {Object.keys(snap.params).length > 8 && (
                        <span className="text-xs text-gray-600">+{Object.keys(snap.params).length - 8} more</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function VehicleProfiles() {
  const [vehicles, setVehicles] = useState<VehicleMemory[]>([]);
  const [search, setSearch] = useState("");
  const [newVin, setNewVin] = useState("");

  const refresh = () => setVehicles(vehicleMemory.getAll());

  useEffect(() => { refresh(); }, []);

  const handleAddVehicle = () => {
    const vin = newVin.trim().toUpperCase();
    if (!vin || vin.length < 5) { toast.error("Enter a valid VIN"); return; }
    vehicleMemory.upsert(vin, {});
    setNewVin("");
    refresh();
    toast.success(`Vehicle ${vin} added to memory`);
  };

  const handleDelete = (vin: string) => {
    vehicleMemory.delete(vin);
    refresh();
    toast.info(`Vehicle ${vin} removed from memory`);
  };

  const filtered = vehicles.filter((v) =>
    !search ||
    v.vin.toLowerCase().includes(search.toLowerCase()) ||
    [v.make, v.model, v.year?.toString(), v.trim].some((f) => f?.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="flex flex-col h-full p-6 gap-4">
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Car className="w-6 h-6 text-red-500" />
            Vehicle Profiles
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            Per-VIN persistent memory — notes, DTC history, module manifests, BCM snapshots
          </p>
        </div>
        <Badge className="bg-red-600 text-white">{vehicles.length} vehicles</Badge>
      </div>

      {/* Add vehicle + search */}
      <div className="flex items-center gap-2 shrink-0">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by VIN, make, model..."
          className="max-w-xs bg-white/5 border-white/10 text-white h-8 text-sm"
        />
        <div className="flex items-center gap-2 ml-auto">
          <Input
            value={newVin}
            onChange={(e) => setNewVin(e.target.value.toUpperCase())}
            placeholder="Enter VIN to add..."
            className="w-48 bg-white/5 border-white/10 text-white h-8 text-sm font-mono"
            onKeyDown={(e) => { if (e.key === "Enter") handleAddVehicle(); }}
          />
          <Button size="sm" className="h-8 bg-red-600 hover:bg-red-700" onClick={handleAddVehicle}>
            <Plus className="w-3.5 h-3.5 mr-1" /> Add Vehicle
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 shrink-0">
        {[
          { label: "Vehicles", value: vehicles.length, icon: Car },
          { label: "Active DTCs", value: vehicles.reduce((s, v) => s + v.dtcHistory.filter((d) => !d.cleared).length, 0), icon: AlertTriangle },
          { label: "Total Notes", value: vehicles.reduce((s, v) => s + v.notes.length, 0), icon: FileText },
          { label: "BCM Snapshots", value: vehicles.reduce((s, v) => s + v.bcmSnapshots.length, 0), icon: Settings },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="bg-[#111] border border-white/10 rounded p-3">
            <div className="flex items-center gap-2 mb-1">
              <Icon className="w-3.5 h-3.5 text-red-500" />
              <span className="text-xs text-gray-400">{label}</span>
            </div>
            <div className="text-xl font-black text-white">{value}</div>
          </div>
        ))}
      </div>

      {/* Vehicle list */}
      <div className="flex-1 overflow-y-auto space-y-2">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-gray-500">
            <Car className="w-8 h-8 mb-2 opacity-30" />
            <p className="text-sm">{search ? "No vehicles match your search" : "No vehicles in memory yet"}</p>
            <p className="text-xs mt-1">Add a VIN above or connect an OBD adapter to auto-populate</p>
          </div>
        ) : (
          filtered.map((vehicle) => (
            <VehicleCard key={vehicle.vin} vehicle={vehicle} onDelete={handleDelete} onRefresh={refresh} />
          ))
        )}
      </div>
    </div>
  );
}
