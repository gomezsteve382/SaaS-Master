import { useState, useCallback, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Cpu, Radio, Key, Shield, Zap, CheckCircle2, Loader2, AlertTriangle,
  Upload, Download, Eye, Trash2, ArrowRight, RotateCcw, Car, FileJson, FileText, FileUp
} from "lucide-react";
import { exportAndDownload, type VINWriteLogEntry } from "@/lib/logExporter";

// ═══════════════════════════════════════════════════════════
// MODULE DATABASE — CAN IDs + Security Constants
// ═══════════════════════════════════════════════════════════
const MODULES = [
  { code: "ECM", name: "Engine Control Module", tx: 0x7E0, rx: 0x7E8, constant: 0x8A3C71, cat: "Powertrain" },
  { code: "TCM", name: "Transmission Control", tx: 0x7E1, rx: 0x7E9, constant: 0x6E4B92, cat: "Powertrain" },
  { code: "BCM", name: "Body Control Module", tx: 0x750, rx: 0x758, constant: 0x4B129F, cat: "Body" },
  { code: "RFHUB", name: "RF Hub Module", tx: 0x75F, rx: 0x767, constant: 0xD5F1, cat: "Body" },
  { code: "ABS", name: "Anti-Lock Brake System", tx: 0x760, rx: 0x768, constant: 0x4B129F, cat: "Chassis" },
  { code: "IPC", name: "Instrument Cluster", tx: 0x740, rx: 0x748, constant: 0x4B129F, cat: "Body" },
  { code: "ORC", name: "Occupant Restraint", tx: 0x758, rx: 0x760, constant: 0x4B129F, cat: "Safety" },
  { code: "EPS", name: "Electric Power Steering", tx: 0x761, rx: 0x769, constant: 0x4B129F, cat: "Chassis" },
  { code: "HVAC", name: "HVAC Control", tx: 0x751, rx: 0x759, constant: 0x4B129F, cat: "Body" },
  { code: "DTCM", name: "Transfer Case Module", tx: 0x7E2, rx: 0x7EA, constant: 0x6E4B92, cat: "Powertrain" },
  { code: "RDM", name: "Radio / Uconnect", tx: 0x754, rx: 0x75C, constant: 0x4B129F, cat: "Multimedia" },
  { code: "TPM", name: "Tire Pressure Monitor", tx: 0x752, rx: 0x75A, constant: 0x4B129F, cat: "Chassis" },
  { code: "ACC", name: "Adaptive Cruise Control", tx: 0x764, rx: 0x76C, constant: 0x4B129F, cat: "ADAS" },
  { code: "ADASF", name: "ADAS Front Camera", tx: 0x763, rx: 0x76B, constant: 0x4B129F, cat: "ADAS" },
];

// ── Seed-Key: Shift-XOR-32 (covers GPEC2–GPEC4LM) ──
function shiftXor32(seed: number, constant: number): Uint8Array {
  let key = seed >>> 0;
  for (let i = 0; i < 5; i++) {
    if (key & 0x80000000) key = (((key << 1) >>> 0) ^ (constant >>> 0)) >>> 0;
    else key = (key << 1) >>> 0;
  }
  return new Uint8Array([(key >>> 24) & 0xFF, (key >>> 16) & 0xFF, (key >>> 8) & 0xFF, key & 0xFF]);
}

// ── Bench EEPROM offset maps ──
const BENCH_OFFSETS = {
  BCM_DFLASH: {
    label: "BCM D-FLASH",
    vinLocations: [
      { offset: 0x001328, label: "VIN Slot 1 (FF prefix)" },
      { offset: 0x001348, label: "VIN Slot 2 (FV prefix)" },
      { offset: 0x001368, label: "VIN Slot 3 (FW prefix)" },
      { offset: 0x001388, label: "VIN Slot 4 (FR prefix)" },
    ],
    securityBytes: { primary: 0x002000, backup: 0x002010, length: 4 },
    fileExts: [".bin", ".BIN"],
  },
  RFHUB_EEE: {
    label: "RFHUB EEE",
    vinLocations: [
      { offset: 0x0EA5, label: "VIN Slot 1" },
      { offset: 0x0EB9, label: "VIN Slot 2" },
      { offset: 0x0ECD, label: "VIN Slot 3" },
      { offset: 0x0EE1, label: "VIN Slot 4" },
    ],
    crcOffsets: [0x0EB7, 0x0ECB, 0x0EDF, 0x0EF3],
    secretKeyOffset: 0x0040,
    secretKeyLength: 16,
    fileExts: [".bin", ".BIN", ".eee", ".EEE"],
  },
  ECM_FLASH: {
    label: "ECM Flash",
    vinLocations: [
      { offset: 0x10000, label: "VIN Primary" },
    ],
    fileExts: [".bin", ".BIN"],
  },
  IPCM_FLASH: {
    label: "IPC Flash",
    vinLocations: [
      { offset: 0x0040, label: "VIN Slot 1" },
      { offset: 0x0100, label: "VIN Slot 2" },
      { offset: 0x0200, label: "VIN Slot 3" },
    ],
    fileExts: [".bin", ".BIN"],
  },
};

// ── Log entry ──
interface LogEntry {
  time: string;
  msg: string;
  level: "info" | "success" | "error" | "warning" | "tx" | "rx";
}

// ── Bench VIN found ──
interface BenchVIN {
  offset: number;
  label: string;
  vin: string | null;
  hex: string;
  isBlank: boolean;
}

const hex = (n: number) => "0x" + n.toString(16).toUpperCase().padStart(3, "0");
const delay = (ms: number) => new Promise(r => setTimeout(r, ms));

export default function VINCommander() {
  const [targetVin, setTargetVin] = useState("");
  const [log, setLog] = useState<LogEntry[]>([]);
  const [activeJob, setActiveJob] = useState<string | null>(null);
  const [jobProgress, setJobProgress] = useState(0);
  const [scannedModules, setScannedModules] = useState<Array<typeof MODULES[0] & { alive: boolean; currentVin: string | null }>>([]);
  const [selectedModules, setSelectedModules] = useState<Set<string>>(new Set());

  // Bench state
  const [benchFileType, setBenchFileType] = useState<keyof typeof BENCH_OFFSETS>("BCM_DFLASH");
  const [benchFileName, setBenchFileName] = useState<string | null>(null);
  const [benchData, setBenchData] = useState<Uint8Array | null>(null);
  const [benchVins, setBenchVins] = useState<BenchVIN[]>([]);
  const [benchNewVin, setBenchNewVin] = useState("");
  const [benchModifiedData, setBenchModifiedData] = useState<Uint8Array | null>(null);

  const logRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((msg: string, level: LogEntry["level"] = "info") => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit", fractionalSecondDigits: 3 } as any);
    setLog(prev => [...prev, { time, msg, level }].slice(-200));
    setTimeout(() => logRef.current?.scrollTo(0, logRef.current.scrollHeight), 50);
  }, []);

  const validVin = /^[A-HJ-NPR-Z0-9]{17}$/.test(targetVin);

  // ═══════════════════════════════════════════════════════
  // OBD: SCAN ALL MODULES
  // ═══════════════════════════════════════════════════════
  const scanModules = async () => {
    setActiveJob("scan");
    setScannedModules([]);
    addLog("━━━ SCANNING ALL MODULES ━━━", "info");

    const results: typeof scannedModules = [];
    for (let i = 0; i < MODULES.length; i++) {
      const mod = MODULES[i];
      setJobProgress(((i + 1) / MODULES.length) * 100);
      addLog(`TX → ${hex(mod.tx)}: 02 3E 00 (TesterPresent)`, "tx");
      await delay(200);

      // Simulated — replace with: const resp = await sendUDS(mod.tx, mod.rx, [0x3E, 0x00]);
      const alive = Math.random() > 0.15;
      if (alive) {
        addLog(`RX ← ${hex(mod.rx)}: 02 7E 00 ✓ ${mod.code} ALIVE`, "rx");
        // Read VIN
        addLog(`TX → ${hex(mod.tx)}: 03 22 F1 90 (Read VIN)`, "tx");
        await delay(150);
        addLog(`RX ← ${hex(mod.rx)}: 62 F1 90 [VIN]`, "rx");
        results.push({ ...mod, alive, currentVin: "2C3CDXKT3FH796320" });
      } else {
        addLog(`    ${hex(mod.rx)}: NO RESPONSE — ${mod.code} not present`, "warning");
        results.push({ ...mod, alive, currentVin: null });
      }
    }
    setScannedModules(results);
    setSelectedModules(new Set(results.filter(m => m.alive).map(m => m.code)));
    const aliveCount = results.filter(r => r.alive).length;
    addLog(`━━━ SCAN COMPLETE: ${aliveCount}/${MODULES.length} modules found ━━━`, "success");
    setActiveJob(null);
  };

  // ═══════════════════════════════════════════════════════
  // OBD: WRITE VIN TO SELECTED MODULES (ONE BUTTON)
  // ═══════════════════════════════════════════════════════
  const writeVinToAll = async () => {
    if (!validVin) return;
    const targets = scannedModules.filter(m => m.alive && selectedModules.has(m.code));
    if (targets.length === 0) return;

    setActiveJob("write");
    addLog(`━━━ WRITING VIN ${targetVin} TO ${targets.length} MODULES ━━━`, "info");

    for (let i = 0; i < targets.length; i++) {
      const mod = targets[i];
      setJobProgress(((i + 1) / targets.length) * 100);
      addLog(`\n── ${mod.code} (${mod.name}) ──`, "info");

      // Step 1: Extended diagnostic session
      addLog(`TX → ${hex(mod.tx)}: 02 10 03 (Extended Session)`, "tx");
      await delay(200);
      addLog(`RX ← ${hex(mod.rx)}: 06 50 03 00 40 C8 ✓`, "rx");

      // Step 2: Security access
      addLog(`TX → ${hex(mod.tx)}: 02 27 01 (Request Seed)`, "tx");
      await delay(250);
      const fakeSeed = Math.floor(Math.random() * 0xFFFFFFFF);
      const seedHex = fakeSeed.toString(16).toUpperCase().padStart(8, "0");
      addLog(`RX ← ${hex(mod.rx)}: 06 67 01 ${seedHex.match(/.{2}/g)!.join(" ")} (Seed)`, "rx");

      const key = shiftXor32(fakeSeed, mod.constant);
      const keyHex = Array.from(key).map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");
      addLog(`   Shift-XOR-32 × 5 (constant 0x${mod.constant.toString(16).toUpperCase()})`, "info");
      addLog(`TX → ${hex(mod.tx)}: 06 27 02 ${keyHex} (Send Key)`, "tx");
      await delay(200);
      addLog(`RX ← ${hex(mod.rx)}: 02 67 02 ✓ UNLOCKED`, "success");

      // Step 3: Write VIN
      const vinBytes = Array.from(targetVin).map(c => c.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0")).join(" ");
      addLog(`TX → ${hex(mod.tx)}: 2E F1 90 ${vinBytes}`, "tx");
      await delay(300);
      addLog(`RX ← ${hex(mod.rx)}: 03 6E F1 90 ✓ VIN WRITTEN`, "success");

      // Step 4: ECU Reset
      addLog(`TX → ${hex(mod.tx)}: 02 11 01 (Hard Reset)`, "tx");
      await delay(200);
      addLog(`RX ← ${hex(mod.rx)}: 02 51 01 ✓`, "rx");

      addLog(`✅ ${mod.code} — VIN changed to ${targetVin}`, "success");
    }

    addLog(`\n━━━ COMPLETE: VIN written to ${targets.length} modules ━━━`, "success");
    setActiveJob(null);
  };

  // ═══════════════════════════════════════════════════════
  // OBD: VIRGINIZE RFHUB (ONE BUTTON)
  // ═══════════════════════════════════════════════════════
  const virginizeRFHUB = async () => {
    setActiveJob("virginize");
    addLog("━━━ VIRGINIZING RFHUB OVER OBD ━━━", "info");

    const TX = 0x75F, RX = 0x767;

    addLog(`TX → ${hex(TX)}: 02 10 03 (Extended Session)`, "tx");
    await delay(200);
    addLog(`RX ← ${hex(RX)}: 06 50 03 00 40 C8 ✓`, "rx");

    addLog(`TX → ${hex(TX)}: 02 27 01 (Request Seed)`, "tx");
    await delay(300);
    addLog(`RX ← ${hex(RX)}: 06 67 01 A3 B7 C2 D1 (Seed)`, "rx");
    addLog(`   Shift-XOR-32 × 5 (constant 0xD5F1)`, "info");
    addLog(`TX → ${hex(TX)}: 06 27 02 [key] (Send Key)`, "tx");
    await delay(200);
    addLog(`RX ← ${hex(RX)}: 02 67 02 ✓ RFHUB UNLOCKED`, "success");

    const blankVin = "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
    addLog(`TX → ${hex(TX)}: 2E F1 90 ${blankVin}`, "tx");
    await delay(300);
    addLog(`RX ← ${hex(RX)}: 03 6E F1 90 ✓ VIN BLANKED`, "success");

    addLog(`TX → ${hex(TX)}: 02 11 01 (Hard Reset)`, "tx");
    await delay(200);
    addLog(`RX ← ${hex(RX)}: 02 51 01 ✓`, "rx");

    addLog("━━━ RFHUB VIRGINIZED ━━━", "success");
    setActiveJob(null);
  };

  // ═══════════════════════════════════════════════════════
  // BENCH: LOAD + ANALYZE EEPROM FILE
  // ═══════════════════════════════════════════════════════
  const handleBenchFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBenchFileName(file.name);
    setBenchModifiedData(null);
    const reader = new FileReader();
    reader.onload = () => {
      const data = new Uint8Array(reader.result as ArrayBuffer);
      setBenchData(data);
      analyzeBenchFile(data);
    };
    reader.readAsArrayBuffer(file);
  };

  const analyzeBenchFile = (data: Uint8Array) => {
    const config = BENCH_OFFSETS[benchFileType];
    const vins: BenchVIN[] = config.vinLocations.map(loc => {
      if (loc.offset + 17 > data.length) {
        return { offset: loc.offset, label: loc.label, vin: null, hex: "", isBlank: true };
      }
      const bytes = data.slice(loc.offset, loc.offset + 17);
      const hex = Array.from(bytes).map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");
      const allPrint = bytes.every(b => b >= 0x20 && b <= 0x7E);
      const vin = allPrint ? String.fromCharCode(...bytes) : null;
      const isBlank = !vin || /^[0\x00\xFF]+$/.test(vin) || bytes.every(b => b === 0x00 || b === 0xFF);
      return { offset: loc.offset, label: loc.label, vin, hex, isBlank };
    });
    setBenchVins(vins);
  };

  const patchBenchVin = () => {
    if (!benchData || !/^[A-HJ-NPR-Z0-9]{17}$/.test(benchNewVin)) return;
    const config = BENCH_OFFSETS[benchFileType];
    const patched = new Uint8Array(benchData);
    const vinBytes = new TextEncoder().encode(benchNewVin);

    for (const loc of config.vinLocations) {
      if (loc.offset + 17 <= patched.length) {
        patched.set(vinBytes, loc.offset);
      }
    }

    // RFHUB: zero CRC fields
    if (benchFileType === "RFHUB_EEE" && BENCH_OFFSETS.RFHUB_EEE.crcOffsets) {
      for (const crcOff of BENCH_OFFSETS.RFHUB_EEE.crcOffsets) {
        if (crcOff + 2 <= patched.length) {
          patched[crcOff] = 0x00;
          patched[crcOff + 1] = 0x00;
        }
      }
    }

    setBenchModifiedData(patched);
    analyzeBenchFile(patched);
    setBenchData(patched);
    addLog(`BENCH: Patched ${config.vinLocations.length} VIN locations with ${benchNewVin}`, "success");
  };

  const virginizeBenchRFHUB = () => {
    if (!benchData || benchFileType !== "RFHUB_EEE") return;
    const config = BENCH_OFFSETS.RFHUB_EEE;
    const patched = new Uint8Array(benchData);

    // Clear VINs
    for (const loc of config.vinLocations) {
      if (loc.offset + 17 <= patched.length) {
        for (let i = 0; i < 17; i++) patched[loc.offset + i] = 0x00;
      }
    }
    // Zero CRCs
    for (const crcOff of config.crcOffsets!) {
      if (crcOff + 2 <= patched.length) { patched[crcOff] = 0x00; patched[crcOff + 1] = 0x00; }
    }
    // Erase secret key
    if (config.secretKeyOffset! + config.secretKeyLength! <= patched.length) {
      for (let i = 0; i < config.secretKeyLength!; i++) patched[config.secretKeyOffset! + i] = 0xFF;
    }

    setBenchModifiedData(patched);
    analyzeBenchFile(patched);
    setBenchData(patched);
    addLog("BENCH: RFHUB virginized — VINs cleared, CRCs zeroed, secret key erased", "success");
  };

  const downloadBenchFile = () => {
    const data = benchModifiedData || benchData;
    if (!data || !benchFileName) return;
    const blob = new Blob([data], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = benchFileName.replace(/\.(bin|eee)$/i, `_PATCHED.$1`);
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleModule = (code: string) => {
    setSelectedModules(prev => {
      const next = new Set(prev);
      next.has(code) ? next.delete(code) : next.add(code);
      return next;
    });
  };

  // Convert VINCommander logs to audit format for export
  const convertLogsToAuditFormat = (): VINWriteLogEntry[] => {
    return log
      .filter(entry => entry.level === "success" || entry.level === "error")
      .map((entry) => {
        // Extract module info from log message if available
        const moduleMatch = entry.msg.match(/Module: ([\w\s]+)/);
        const module = moduleMatch ? moduleMatch[1] : "Unknown";
        const moduleCode = module.substring(0, 3).toUpperCase();

        return {
          timestamp: entry.time,
          module,
          moduleCode,
          txId: "0x000",
          rxId: "0x000",
          oldVin: null,
          newVin: targetVin || "N/A",
          status: entry.level === "success" ? "success" : "failed",
          error: entry.level === "error" ? entry.msg : undefined,
        };
      });
  };

  const handleExportLogs = (format: "json" | "csv" | "html") => {
    const auditLogs = convertLogsToAuditFormat();
    if (auditLogs.length === 0) {
      addLog("No logs to export", "warning");
      return;
    }

    exportAndDownload(auditLogs, format, {
      vehicleVin: targetVin || undefined,
      exportedAt: new Date().toISOString(),
    });
    addLog(`Exported ${auditLogs.length} log entries as ${format.toUpperCase()}`, "success");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-gray-900 to-red-950 text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Car className="h-8 w-8 text-red-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">VIN Commander</h1>
          </div>
          <p className="text-gray-400">One-button VIN changes · Any module · OBD or Bench · RFHUB Virginizer</p>
        </div>
      </div>

      <div className="container py-8">
        <Tabs defaultValue="obd" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="obd" className="gap-2"><Zap className="h-4 w-4" />OBD (Live)</TabsTrigger>
            <TabsTrigger value="bench" className="gap-2"><Upload className="h-4 w-4" />Bench (File)</TabsTrigger>
          </TabsList>

          {/* ═══════ OBD TAB ═══════ */}
          <TabsContent value="obd" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left: Controls */}
              <div className="space-y-4">
                {/* Target VIN */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Target VIN</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Input
                      value={targetVin} onChange={e => setTargetVin(e.target.value.toUpperCase())} maxLength={17}
                      placeholder="Enter 17-character VIN"
                      className={`font-mono text-lg text-center tracking-[0.15em] font-bold ${validVin ? "border-green-500" : targetVin.length > 0 ? "border-red-500" : ""}`}
                    />
                    <div className="flex justify-between mt-2 text-xs font-mono">
                      <span className={validVin ? "text-green-500" : "text-muted-foreground"}>{validVin ? "✓ Valid" : `${targetVin.length}/17`}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2"><Zap className="h-4 w-4 text-cyan-500" />Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full justify-start" onClick={scanModules} disabled={!!activeJob}>
                      {activeJob === "scan" ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Cpu className="h-4 w-4 mr-2" />}
                      Scan All Modules
                    </Button>
                    <Button className="w-full justify-start" variant="default" onClick={writeVinToAll}
                      disabled={!!activeJob || !validVin || selectedModules.size === 0}>
                      {activeJob === "write" ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <ArrowRight className="h-4 w-4 mr-2" />}
                      Write VIN → {selectedModules.size} Module{selectedModules.size !== 1 ? "s" : ""}
                    </Button>
                    <hr className="border-border" />
                    <Button className="w-full justify-start" variant="destructive" onClick={virginizeRFHUB} disabled={!!activeJob}>
                      {activeJob === "virginize" ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Trash2 className="h-4 w-4 mr-2" />}
                      Virginize RFHUB (OBD)
                    </Button>
                  </CardContent>
                </Card>

                {activeJob && <Progress value={jobProgress} className="h-2" />}
              </div>

              {/* Center: Module Grid */}
              <div>
                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center justify-between">
                      Modules
                      <Badge variant="secondary">{scannedModules.filter(m => m.alive).length} alive</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1.5">
                    {scannedModules.length === 0 ? (
                      <div className="text-center py-10 text-muted-foreground text-sm">Press "Scan All Modules" to discover ECUs</div>
                    ) : scannedModules.map(mod => (
                      <div key={mod.code}
                        onClick={() => mod.alive && toggleModule(mod.code)}
                        className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                          !mod.alive ? "opacity-30 cursor-not-allowed border-transparent" :
                          selectedModules.has(mod.code) ? "bg-cyan-50 dark:bg-cyan-950/30 border-cyan-300 dark:border-cyan-800" :
                          "border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-900"
                        }`}>
                        <div className={`w-2 h-2 rounded-full shrink-0 ${mod.alive ? "bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.5)]" : "bg-gray-400"}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-sm">{mod.code}</span>
                            {selectedModules.has(mod.code) && <CheckCircle2 className="h-3 w-3 text-cyan-500" />}
                          </div>
                          {mod.currentVin && (
                            <div className="font-mono text-[10px] text-muted-foreground truncate">{mod.currentVin}</div>
                          )}
                        </div>
                        <span className="font-mono text-[10px] text-muted-foreground">{hex(mod.tx)}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Right: UDS Log */}
              <div>
                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <div className="flex flex-col gap-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">UDS Traffic Log</CardTitle>
                        <Button size="sm" variant="ghost" className="h-6 px-2 text-xs" onClick={() => setLog([])}>Clear</Button>
                      </div>
                      {log.length > 0 && (
                        <div className="flex gap-2 flex-wrap">
                          <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => handleExportLogs("json")}>
                            <FileJson className="h-3 w-3" />JSON
                          </Button>
                          <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => handleExportLogs("csv")}>
                            <FileText className="h-3 w-3" />CSV
                          </Button>
                          <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => handleExportLogs("html")}>
                            <FileUp className="h-3 w-3" />Report
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {log.length > 0 && (
                        <div className="text-xs text-muted-foreground">
                          {log.length} entries · {log.filter(e => e.level === "success").length} success · {log.filter(e => e.level === "error").length} errors
                        </div>
                      )}
                      <div ref={logRef} className="h-[500px] overflow-y-auto space-y-0.5 font-mono text-[11px] bg-gray-950 rounded-lg p-3">
                        {log.length === 0 && <div className="text-center text-gray-600 py-10">Waiting for commands...</div>}
                        {log.map((entry, i) => (
                          <div key={i} className={
                            entry.level === "success" ? "text-green-400" :
                            entry.level === "error" ? "text-red-400" :
                            entry.level === "warning" ? "text-yellow-500" :
                            entry.level === "tx" ? "text-cyan-400" :
                            entry.level === "rx" ? "text-emerald-400" :
                            "text-gray-400"
                          }>
                            <span className="text-gray-600 mr-2">{entry.time}</span>
                            {entry.msg}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* ═══════ BENCH TAB ═══════ */}
          <TabsContent value="bench" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left: File upload + module type */}
              <div className="space-y-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Module Type</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {(Object.keys(BENCH_OFFSETS) as Array<keyof typeof BENCH_OFFSETS>).map(key => (
                      <Button key={key} variant={benchFileType === key ? "default" : "outline"} size="sm"
                        className="w-full justify-start font-mono text-xs" onClick={() => { setBenchFileType(key); setBenchData(null); setBenchVins([]); setBenchFileName(null); }}>
                        {BENCH_OFFSETS[key].label}
                      </Button>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Upload EEPROM Dump</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <input type="file" accept=".bin,.BIN,.eee,.EEE" onChange={handleBenchFile} className="text-sm" />
                    {benchFileName && <p className="text-xs text-muted-foreground mt-2 font-mono">{benchFileName} · {benchData?.length.toLocaleString()} bytes</p>}
                  </CardContent>
                </Card>

                {benchData && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">New VIN</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Input value={benchNewVin} onChange={e => setBenchNewVin(e.target.value.toUpperCase())} maxLength={17}
                        placeholder="Enter new VIN" className="font-mono text-center tracking-[0.1em] font-bold" />
                      <Button className="w-full" onClick={patchBenchVin} disabled={!/^[A-HJ-NPR-Z0-9]{17}$/.test(benchNewVin)}>
                        <ArrowRight className="h-4 w-4 mr-2" />Write VIN to All Slots
                      </Button>
                      {benchFileType === "RFHUB_EEE" && (
                        <Button className="w-full" variant="destructive" onClick={virginizeBenchRFHUB}>
                          <Trash2 className="h-4 w-4 mr-2" />Virginize RFHUB
                        </Button>
                      )}
                      {(benchModifiedData || benchData) && (
                        <Button className="w-full" variant="outline" onClick={downloadBenchFile}>
                          <Download className="h-4 w-4 mr-2" />Download Patched File
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Center + Right: VIN Locations Display */}
              <div className="lg:col-span-2">
                {benchVins.length > 0 ? (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="h-5 w-5 text-cyan-500" />
                        {BENCH_OFFSETS[benchFileType].label} — VIN Locations
                      </CardTitle>
                      <CardDescription>
                        {benchVins.filter(v => !v.isBlank).length} of {benchVins.length} slots contain VINs
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {benchVins.map((v, i) => (
                        <div key={i} className={`p-4 rounded-lg border ${
                          v.isBlank ? "border-gray-200 dark:border-gray-800" : "border-cyan-300 dark:border-cyan-700 bg-cyan-50 dark:bg-cyan-950/20"
                        }`}>
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <Badge variant={v.isBlank ? "outline" : "default"} className="font-mono text-xs">
                                0x{v.offset.toString(16).toUpperCase().padStart(6, "0")}
                              </Badge>
                              <span className="text-sm font-medium">{v.label}</span>
                            </div>
                            <Badge variant={v.isBlank ? "secondary" : "default"}>
                              {v.isBlank ? "BLANK" : "SET"}
                            </Badge>
                          </div>
                          <div className="font-mono text-lg font-black tracking-[0.15em] mb-1">
                            {v.vin || "(empty)"}
                          </div>
                          <div className="font-mono text-[10px] text-muted-foreground break-all">
                            {v.hex}
                          </div>
                        </div>
                      ))}

                      {/* Security bytes display for BCM */}
                      {benchFileType === "BCM_DFLASH" && benchData && BENCH_OFFSETS.BCM_DFLASH.securityBytes && (
                        <div className="p-4 rounded-lg border border-purple-300 dark:border-purple-800 bg-purple-50 dark:bg-purple-950/20">
                          <div className="flex items-center gap-3 mb-2">
                            <Shield className="h-4 w-4 text-purple-500" />
                            <span className="text-sm font-medium">Security Bytes (SKIM Pairing)</span>
                          </div>
                          <div className="grid grid-cols-2 gap-4 font-mono text-xs">
                            <div>
                              <span className="text-muted-foreground">Primary (0x{BENCH_OFFSETS.BCM_DFLASH.securityBytes.primary.toString(16).toUpperCase()}):</span>
                              <div className="text-purple-500 font-bold mt-1">
                                {benchData.length > BENCH_OFFSETS.BCM_DFLASH.securityBytes.primary + 4
                                  ? Array.from(benchData.slice(BENCH_OFFSETS.BCM_DFLASH.securityBytes.primary, BENCH_OFFSETS.BCM_DFLASH.securityBytes.primary + 4)).map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ")
                                  : "N/A"}
                              </div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Backup (0x{BENCH_OFFSETS.BCM_DFLASH.securityBytes.backup.toString(16).toUpperCase()}):</span>
                              <div className="text-purple-500 font-bold mt-1">
                                {benchData.length > BENCH_OFFSETS.BCM_DFLASH.securityBytes.backup + 4
                                  ? Array.from(benchData.slice(BENCH_OFFSETS.BCM_DFLASH.securityBytes.backup, BENCH_OFFSETS.BCM_DFLASH.securityBytes.backup + 4)).map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ")
                                  : "N/A"}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* RFHUB secret key + CRC display */}
                      {benchFileType === "RFHUB_EEE" && benchData && (
                        <>
                          <div className="p-4 rounded-lg border border-purple-300 dark:border-purple-800 bg-purple-50 dark:bg-purple-950/20">
                            <div className="flex items-center gap-3 mb-2">
                              <Key className="h-4 w-4 text-purple-500" />
                              <span className="text-sm font-medium">Secret Key (0x{BENCH_OFFSETS.RFHUB_EEE.secretKeyOffset!.toString(16).toUpperCase()})</span>
                            </div>
                            <div className="font-mono text-xs text-purple-500 font-bold break-all">
                              {benchData.length > BENCH_OFFSETS.RFHUB_EEE.secretKeyOffset! + BENCH_OFFSETS.RFHUB_EEE.secretKeyLength!
                                ? Array.from(benchData.slice(BENCH_OFFSETS.RFHUB_EEE.secretKeyOffset!, BENCH_OFFSETS.RFHUB_EEE.secretKeyOffset! + BENCH_OFFSETS.RFHUB_EEE.secretKeyLength!))
                                    .map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ")
                                : "N/A"}
                            </div>
                          </div>
                          <div className="p-4 rounded-lg border border-pink-300 dark:border-pink-800 bg-pink-50 dark:bg-pink-950/20">
                            <div className="flex items-center gap-3 mb-2">
                              <Shield className="h-4 w-4 text-pink-500" />
                              <span className="text-sm font-medium">CRC-16 Values</span>
                            </div>
                            <div className="flex gap-6 font-mono text-xs">
                              {BENCH_OFFSETS.RFHUB_EEE.crcOffsets!.map((off, i) => (
                                <div key={i}>
                                  <span className="text-muted-foreground">0x{off.toString(16).toUpperCase()}: </span>
                                  <span className="text-pink-500 font-bold">
                                    {benchData.length > off + 2
                                      ? ((benchData[off] << 8) | benchData[off + 1]).toString(16).toUpperCase().padStart(4, "0")
                                      : "N/A"}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <div className="text-center">
                      <Upload className="h-12 w-12 mx-auto mb-3 opacity-30" />
                      <p>Select module type and upload an EEPROM dump</p>
                      <p className="text-xs mt-1">BCM D-FLASH · RFHUB EEE · ECM Flash · IPC Flash</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
