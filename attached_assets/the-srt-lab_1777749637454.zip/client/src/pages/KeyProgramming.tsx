import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Key, Lock, Unlock, Search, Trash2, Plus, Radio, Shield, AlertTriangle, CheckCircle2, Loader2, Eye } from "lucide-react";

// Seed-Key: Shift-XOR for RFHUB (constant 0xD5F1)
function rfhubKeyCalc(seed: Uint8Array): Uint8Array {
  let key = ((seed[0] << 24) | (seed[1] << 16) | (seed[2] << 8) | seed[3]) >>> 0;
  const constant = 0xD5F1;
  for (let i = 0; i < 5; i++) {
    if (key & 0x80000000) key = (((key << 1) >>> 0) ^ constant) >>> 0;
    else key = (key << 1) >>> 0;
  }
  return new Uint8Array([(key >>> 24) & 0xFF, (key >>> 16) & 0xFF, (key >>> 8) & 0xFF, key & 0xFF]);
}

const RFHUB_TX = 0x75F;
const RFHUB_RX = 0x767;
// Older SKIM/WCM addresses
const SKIM_TX = 0x742;
const SKIM_RX = 0x762;

interface KeySlot {
  slot: number;
  status: "programmed" | "empty";
  type: string | null;
  serial?: string;
}

interface PINCandidate {
  did: string;
  encoding: string;
  pin: string;
  rawData: string;
}

export default function KeyProgramming() {
  const { sendUDS, readDID, startSession, securityAccess, routineControl, isConnected } = useUDS();

  const [pin, setPin] = useState("");
  const [pinCandidates, setPinCandidates] = useState<PINCandidate[]>([]);
  const [readingPin, setReadingPin] = useState(false);
  const [learningKey, setLearningKey] = useState(false);
  const [locatingKeys, setLocatingKeys] = useState(false);
  const [erasingSlot, setErasingSlot] = useState<number | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [log, setLog] = useState<Array<{ msg: string; level: string; time: string }>>([]);
  const [keySlots, setKeySlots] = useState<KeySlot[]>(
    Array.from({ length: 8 }, (_, i) => ({ slot: i + 1, status: "empty" as const, type: null }))
  );

  const addLog = (msg: string, level = "info") => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    setLog(prev => [{ msg, level, time }, ...prev].slice(0, 50));
  };

  // ── PIN Extraction (real UDS) ──
  const readPIN = async () => {
    if (!isConnected) { addLog("Connect adapter first", "error"); return; }
    setReadingPin(true);
    setPinCandidates([]);

    addLog("Entering diagnostic session on RFHUB...");
    const sessResp = await startSession(RFHUB_TX, RFHUB_RX, 0x03);
    if (!sessResp.success) { addLog(`Session failed: ${sessResp.error}`, "error"); setReadingPin(false); return; }
    addLog("✓ Extended session active", "success");

    addLog("Requesting security access...");
    const saResp = await securityAccess(RFHUB_TX, RFHUB_RX, 0x01, rfhubKeyCalc);
    if (!saResp.success) { addLog(`Security access denied: ${saResp.error}`, "error"); setReadingPin(false); return; }
    addLog("✓ Security unlocked", "success");

    const pinDIDs: Array<{ did: number; desc: string }> = [
      { did: 0xF18C, desc: "ECU Serial / PIN Storage 1" },
      { did: 0xF18D, desc: "PIN Storage 2" },
      { did: 0xF18E, desc: "PIN Storage 3" },
      { did: 0xF1A0, desc: "Security Data" },
      { did: 0xF1A1, desc: "Security Data 2" },
    ];

    const results: PINCandidate[] = [];

    for (const { did, desc } of pinDIDs) {
      addLog(`Reading DID 0x${did.toString(16).toUpperCase()} (${desc})...`);
      const resp = await readDID(RFHUB_TX, RFHUB_RX, did);

      if (!resp.success || !resp.data || resp.data.length < 5) {
        addLog(`No data at 0x${did.toString(16).toUpperCase()}`, "dim");
        continue;
      }

      // Skip 62 XX XX header (3 bytes)
      const raw = resp.data.slice(3);
      const rawHex = Array.from(raw).map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");
      addLog(`Raw: ${rawHex}`);

      // Try BCD decode
      if (raw.length >= 2) {
        const h1 = (raw[0] >> 4) & 0x0F, l1 = raw[0] & 0x0F;
        const h2 = (raw[1] >> 4) & 0x0F, l2 = raw[1] & 0x0F;
        if (h1 <= 9 && l1 <= 9 && h2 <= 9 && l2 <= 9) {
          const bcdPin = `${h1}${l1}${h2}${l2}`;
          results.push({ did: `0x${did.toString(16).toUpperCase()}`, encoding: "BCD", pin: bcdPin, rawData: rawHex });
          addLog(`✓ PIN found (BCD): ${bcdPin}`, "success");
        }
      }

      // Try binary decode
      if (raw.length >= 2) {
        const binVal = (raw[0] << 8) | raw[1];
        if (binVal >= 1000 && binVal <= 9999) {
          const binPin = binVal.toString().padStart(4, "0");
          if (!results.some(r => r.pin === binPin)) {
            results.push({ did: `0x${did.toString(16).toUpperCase()}`, encoding: "Binary", pin: binPin, rawData: rawHex });
            addLog(`✓ PIN found (Binary): ${binPin}`, "success");
          }
        }
      }

      // Try ASCII decode
      if (raw.length >= 4) {
        const asciiStr = String.fromCharCode(...raw.slice(0, 4));
        if (/^\d{4}$/.test(asciiStr) && !results.some(r => r.pin === asciiStr)) {
          results.push({ did: `0x${did.toString(16).toUpperCase()}`, encoding: "ASCII", pin: asciiStr, rawData: rawHex });
          addLog(`✓ PIN found (ASCII): ${asciiStr}`, "success");
        }
      }
    }

    setPinCandidates(results);
    if (results.length > 0) {
      setPin(results[0].pin);
      addLog(`PIN extraction complete — most likely: ${results[0].pin}`, "success");
    } else {
      addLog("No PIN found in standard DIDs", "warning");
    }
    setReadingPin(false);
  };

  // ── Security Unlock with PIN ──
  const unlockWithPIN = async () => {
    if (pin.length !== 4 || !isConnected) return;
    addLog(`Unlocking RFHUB with PIN ${pin}...`);

    const sessResp = await startSession(RFHUB_TX, RFHUB_RX, 0x03);
    if (!sessResp.success) { addLog(`Session failed: ${sessResp.error}`, "error"); return; }

    const saResp = await securityAccess(RFHUB_TX, RFHUB_RX, 0x01, rfhubKeyCalc);
    if (!saResp.success) { addLog(`Security access failed: ${saResp.error}`, "error"); return; }

    addLog("✓ RFHUB unlocked — key programming enabled", "success");
    setUnlocked(true);
  };

  // ── Learn New Key (real UDS) ──
  const learnNewKey = async () => {
    if (!unlocked || !isConnected) return;
    setLearningKey(true);
    addLog("Starting FOBIK key learning procedure...");

    // RoutineControl Start (0x31 0x01) with routine ID 0x0401 (Learn Key)
    const resp = await routineControl(RFHUB_TX, RFHUB_RX, 0x0401, 0x01);
    if (!resp.success) {
      addLog(`Key learning failed to start: ${resp.error}`, "error");
      setLearningKey(false);
      return;
    }

    addLog("✓ Learning mode active — press UNLOCK on new key fob NOW", "success");
    addLog("Waiting for key fob signal (up to 30 seconds)...");

    // Poll for completion — check routine results
    let learned = false;
    for (let i = 0; i < 30; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const resultResp = await routineControl(RFHUB_TX, RFHUB_RX, 0x0401, 0x03); // RequestResults
      if (resultResp.success && resultResp.data && resultResp.data.length >= 5) {
        const status = resultResp.data[4];
        if (status === 0x00) { learned = true; break; } // Success
        if (status === 0x01) continue; // Still waiting
        if (status === 0x02) { addLog("Key learning timed out on ECU side", "error"); break; }
      }
    }

    if (learned) {
      addLog("✓ Key learned successfully!", "success");
      // Find first empty slot and mark as programmed
      setKeySlots(prev => {
        const idx = prev.findIndex(k => k.status === "empty");
        if (idx === -1) return prev;
        const next = [...prev];
        next[idx] = { ...next[idx], status: "programmed", type: "FOBIK" };
        return next;
      });
    }
    setLearningKey(false);
  };

  // ── Erase Key (real UDS) ──
  const eraseKey = async (slot: number) => {
    if (!unlocked || !isConnected) return;
    setErasingSlot(slot);
    addLog(`Erasing key slot ${slot}...`);

    // RoutineControl Start with routine 0x0402 (Erase Key) + slot byte
    const resp = await sendUDS(RFHUB_TX, RFHUB_RX, [0x31, 0x01, 0x04, 0x02, slot]);
    if (!resp.success) {
      addLog(`Erase failed: ${resp.error}`, "error");
      setErasingSlot(null);
      return;
    }

    addLog(`✓ Key slot ${slot} erased`, "success");
    setKeySlots(prev => prev.map(k =>
      k.slot === slot ? { ...k, status: "empty", type: null, serial: undefined } : k
    ));
    setErasingSlot(null);
  };

  // ── Locate Keys (real UDS) ──
  const locateKeys = async () => {
    if (!unlocked || !isConnected) return;
    setLocatingKeys(true);
    addLog("Locating programmed keys...");

    const resp = await routineControl(RFHUB_TX, RFHUB_RX, 0x0403, 0x01);
    if (!resp.success) {
      addLog(`Locate failed: ${resp.error}`, "error");
      setLocatingKeys(false);
      return;
    }

    // Parse response — routine result contains key status bytes
    if (resp.data && resp.data.length >= 12) {
      // Data format: 71 01 04 03 [status1] [status2] ... [status8]
      const statuses = resp.data.slice(4, 12);
      setKeySlots(prev => prev.map((k, i) => ({
        ...k,
        status: statuses[i] > 0 ? "programmed" as const : "empty" as const,
        type: statuses[i] > 0 ? "FOBIK" : null,
      })));
      const programmed = Array.from(statuses).filter(s => s > 0).length;
      addLog(`✓ Found ${programmed} programmed key(s)`, "success");
    } else {
      addLog("✓ Routine complete — check key slots", "success");
    }
    setLocatingKeys(false);
  };

  const programmedCount = keySlots.filter(k => k.status === "programmed").length;
  const emptyCount = keySlots.filter(k => k.status === "empty").length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      <div className="bg-gradient-to-r from-purple-950 via-gray-900 to-black text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Key className="h-8 w-8 text-purple-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">Key Programming</h1>
          </div>
          <p className="text-gray-400">FOBIK learn/erase/locate · PIN extraction · RFHUB 0x75F/0x767</p>
        </div>
      </div>

      <div className="container py-8">
        {!isConnected && (
          <Alert variant="destructive" className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Connect your OBDLink EX / ELM327 adapter first using the connection bar at the bottom of the screen.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: PIN + Actions */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-purple-200 dark:border-purple-800">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Eye className="h-5 w-5 text-purple-500" />
                  PIN Extraction
                </CardTitle>
                <CardDescription>Read 4-digit SKIM PIN from RFHUB via UDS</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full" variant="outline" onClick={readPIN} disabled={readingPin || !isConnected}>
                  {readingPin ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Reading...</> : <><Search className="h-4 w-4 mr-2" />Read PIN from RFHUB</>}
                </Button>
                {pinCandidates.length > 0 && (
                  <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4 text-center">
                    <div className="text-4xl font-black tracking-[0.4em] text-green-600 dark:text-green-400 font-mono">{pinCandidates[0].pin}</div>
                    <div className="text-xs text-muted-foreground mt-1">DID {pinCandidates[0].did} · {pinCandidates[0].encoding} · Raw: {pinCandidates[0].rawData}</div>
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Manual PIN Entry</label>
                  <div className="flex gap-2">
                    <Input value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="0000" maxLength={4} className="font-mono text-xl text-center tracking-[0.4em] font-bold" />
                    <Button onClick={unlockWithPIN} disabled={pin.length !== 4 || unlocked || !isConnected} variant={unlocked ? "outline" : "default"}>
                      {unlocked ? <><Unlock className="h-4 w-4 mr-1" />OK</> : <><Lock className="h-4 w-4 mr-1" />Unlock</>}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2"><Shield className="h-5 w-5 text-blue-500" />Key Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" variant="outline" onClick={learnNewKey} disabled={!unlocked || learningKey || !isConnected}>
                  {learningKey ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Learning...</> : <><Plus className="h-4 w-4 mr-2 text-green-500" />Learn New Key (0x0401)</>}
                </Button>
                <Button className="w-full justify-start" variant="outline" onClick={locateKeys} disabled={!unlocked || locatingKeys || !isConnected}>
                  {locatingKeys ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Scanning...</> : <><Search className="h-4 w-4 mr-2 text-blue-500" />Locate Learned Keys (0x0403)</>}
                </Button>
                {!unlocked && <Alert><AlertTriangle className="h-4 w-4" /><AlertDescription className="text-xs">Enter PIN and unlock RFHUB first</AlertDescription></Alert>}
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              <Card className="text-center p-4"><div className="text-2xl font-black text-green-500">{programmedCount}</div><div className="text-xs text-muted-foreground uppercase">Programmed</div></Card>
              <Card className="text-center p-4"><div className="text-2xl font-black text-gray-400">{emptyCount}</div><div className="text-xs text-muted-foreground uppercase">Empty</div></Card>
            </div>
          </div>

          {/* Middle: Key Slots */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Radio className="h-5 w-5 text-cyan-500" />Key Slots<Badge variant="secondary" className="ml-auto">{programmedCount}/8</Badge>
                </CardTitle>
                <CardDescription>RFHUB 0x75F · FOBIK key fob memory</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {keySlots.map(k => (
                  <div key={k.slot} className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${k.status === "programmed" ? "bg-cyan-50 dark:bg-cyan-950/30 border-cyan-200 dark:border-cyan-800" : "border-gray-200 dark:border-gray-800"}`}>
                    <div className={`w-2 h-2 rounded-full ${k.status === "programmed" ? "bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.5)]" : "bg-gray-300 dark:bg-gray-700"}`} />
                    <span className="font-mono text-sm text-muted-foreground w-6">#{k.slot}</span>
                    <div className="flex-1">
                      <span className={`font-semibold text-sm ${k.status === "programmed" ? "" : "text-muted-foreground"}`}>{k.status === "programmed" ? k.type : "Empty"}</span>
                    </div>
                    {k.status === "programmed" && (
                      <Button size="sm" variant="ghost" className="text-red-500 hover:text-red-700 h-7 px-2" onClick={() => eraseKey(k.slot)} disabled={!unlocked || erasingSlot === k.slot || !isConnected}>
                        {erasingSlot === k.slot ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right: Log */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-3"><CardTitle className="text-lg">UDS Log</CardTitle></CardHeader>
              <CardContent>
                <div className="h-[500px] overflow-y-auto space-y-1 font-mono text-xs">
                  {log.length === 0 && <div className="text-muted-foreground text-center py-8">Connect adapter and read PIN to begin</div>}
                  {log.map((entry, i) => (
                    <div key={i} className={`flex gap-2 py-1 px-2 rounded ${entry.level === "success" ? "text-green-600 dark:text-green-400" : entry.level === "warning" ? "text-yellow-600" : entry.level === "error" ? "text-red-500" : entry.level === "dim" ? "text-muted-foreground" : ""}`}>
                      <span className="text-muted-foreground shrink-0">{entry.time}</span><span>{entry.msg}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
