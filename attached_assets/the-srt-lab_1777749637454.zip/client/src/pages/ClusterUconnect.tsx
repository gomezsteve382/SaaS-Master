import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Monitor, Lock, Unlock, Loader2, AlertTriangle, CheckCircle2,
  Gauge, Zap, Volume2, Car, Flame, Eye, Sparkles, Timer,
} from "lucide-react";

// ═══════════════════════════════════════════════════════════════
// All cluster/Uconnect configuration options with HUMAN labels
// ═══════════════════════════════════════════════════════════════

interface ConfigOption {
  value: number;
  label: string;
  description?: string;
  hp?: number;   // For trim levels, what HP the Uconnect shows
  tq?: number;   // Torque shown
}

interface ConfigField {
  id: string;
  name: string;
  section: string;
  description: string;
  module: "BCM" | "IPC" | "RADIO";
  did: number;
  byteOffset: number;
  bitMask?: number;
  options?: ConfigOption[];
  isNumeric?: boolean;
  min?: number;
  max?: number;
  unit?: string;
  notes?: string;
}

const CONFIG_FIELDS: ConfigField[] = [

  // ═══════════════════════════════════════════════
  // STARTUP SCREEN & ANIMATION (IPC 0x740)
  // ═══════════════════════════════════════════════
  {
    id: "vehicle_trim_level",
    name: "Startup Screen / Trim Identity",
    section: "Startup Screen",
    description: "Controls which logo/animation plays on the cluster when you start the car, AND what the Uconnect shows as your vehicle model",
    module: "BCM", did: 0xDE01, byteOffset: 0x00,
    options: [
      { value: 0x00, label: "SE — Base",                   description: "Standard Dodge/Chrysler startup", hp: 305, tq: 268 },
      { value: 0x01, label: "SXT",                          description: "Standard trim startup", hp: 305, tq: 268 },
      { value: 0x02, label: "SXT Plus",                     description: "SXT+ startup", hp: 305, tq: 268 },
      { value: 0x03, label: "GT — Grand Touring",           description: "GT badge startup", hp: 305, tq: 268 },
      { value: 0x04, label: "R/T — 5.7L HEMI",             description: "R/T logo with HEMI badge", hp: 375, tq: 410 },
      { value: 0x05, label: "R/T Plus",                     description: "R/T+ logo", hp: 375, tq: 410 },
      { value: 0x06, label: "R/T Scat Pack — 6.4L 392",    description: "Angry Bee Scat Pack animation", hp: 485, tq: 475 },
      { value: 0x07, label: "Scat Pack Widebody",           description: "Widebody Scat Pack animation", hp: 485, tq: 475 },
      { value: 0x08, label: "SRT 392",                      description: "SRT logo with 392 badge", hp: 485, tq: 475 },
      { value: 0x09, label: "SRT Hellcat — 6.2L SC 717HP", description: "Hellcat cat eyes animation", hp: 717, tq: 656 },
      { value: 0x0A, label: "Hellcat Widebody",             description: "Widebody Hellcat animation", hp: 717, tq: 656 },
      { value: 0x0B, label: "SRT Hellcat Redeye — 797HP",  description: "Red-eyed Hellcat animation", hp: 797, tq: 707 },
      { value: 0x0C, label: "Redeye Widebody",              description: "Widebody Redeye animation", hp: 797, tq: 707 },
      { value: 0x0D, label: "SRT Jailbreak",                description: "Jailbreak edition animation", hp: 807, tq: 707 },
      { value: 0x0E, label: "SRT Super Stock — 807HP",      description: "Super Stock drag special animation", hp: 807, tq: 707 },
      { value: 0x0F, label: "SRT Demon — 840HP",            description: "Demon skull animation", hp: 840, tq: 770 },
      { value: 0x10, label: "SRT Demon 170 — 1025HP",       description: "Demon 170 skull animation (E85)", hp: 1025, tq: 945 },
    ],
    notes: "This changes the startup animation on the cluster AND the model/HP shown on Uconnect performance pages",
  },

  {
    id: "engine_variant",
    name: "Engine Configuration",
    section: "Startup Screen",
    description: "Which engine the cluster and Uconnect think is installed",
    module: "BCM", did: 0xDE01, byteOffset: 0x01,
    options: [
      { value: 0x01, label: "3.6L Pentastar V6 — 305 HP",               hp: 305, tq: 268 },
      { value: 0x02, label: "5.7L HEMI V8 — 375 HP",                    hp: 375, tq: 410 },
      { value: 0x03, label: "6.4L HEMI 392 V8 — 485 HP",                hp: 485, tq: 475 },
      { value: 0x04, label: "6.2L Supercharged V8 (Hellcat) — 717 HP",  hp: 717, tq: 656 },
      { value: 0x05, label: "6.2L Supercharged V8 (Redeye) — 797 HP",   hp: 797, tq: 707 },
      { value: 0x06, label: "6.2L Supercharged V8 (Demon) — 840 HP",    hp: 840, tq: 770 },
      { value: 0x07, label: "6.2L Supercharged V8 (Demon 170) — 1025 HP", hp: 1025, tq: 945 },
    ],
    notes: "Must match trim level for correct Uconnect display",
  },

  {
    id: "startup_sound",
    name: "Startup Sound",
    section: "Startup Screen",
    description: "Sound played through speakers when you start the vehicle",
    module: "BCM", did: 0xDE00, byteOffset: 0x37,
    options: [
      { value: 0x00, label: "None — Silent startup" },
      { value: 0x01, label: "Standard Chime — Default Dodge chime" },
      { value: 0x02, label: "Performance Tone — Aggressive startup tone" },
      { value: 0x03, label: "SRT Growl — SRT signature engine sound" },
      { value: 0x04, label: "Hellcat Roar — Supercharger whine simulation" },
    ],
    notes: "Some sounds only available on performance trims",
  },

  {
    id: "startup_message",
    name: "Startup Message",
    section: "Startup Screen",
    description: "Text shown on the cluster when the car starts",
    module: "BCM", did: 0xDE00, byteOffset: 0x96,
    options: [
      { value: 0x00, label: "None — No message" },
      { value: 0x01, label: "Welcome — Shows 'Welcome'" },
      { value: 0x02, label: "Vehicle Name — Shows 'Charger' or 'Challenger' etc" },
      { value: 0x03, label: "Custom Message — User-defined text" },
      { value: 0x04, label: "Performance Stats — Shows HP/Torque info" },
    ],
  },

  {
    id: "gauge_sweep",
    name: "Gauge Sweep on Startup",
    section: "Startup Screen",
    description: "Sweeps the tachometer and speedometer needles to max on startup — the SRT signature move",
    module: "BCM", did: 0xDE00, byteOffset: 0x97, bitMask: 0x01,
    options: [
      { value: 0x00, label: "Disabled — Needles go straight to zero" },
      { value: 0x01, label: "Enabled — Full needle sweep to max then back" },
    ],
  },

  // ═══════════════════════════════════════════════
  // CLUSTER DISPLAY SETTINGS (IPC 0x740)
  // ═══════════════════════════════════════════════
  {
    id: "digital_speedometer",
    name: "Digital Speedometer",
    section: "Cluster Display",
    description: "Show numeric speed readout on the cluster",
    module: "BCM", did: 0xDE00, byteOffset: 0x97, bitMask: 0x02,
    options: [
      { value: 0x00, label: "Off — Analog gauge only" },
      { value: 0x02, label: "On — Digital number on cluster" },
    ],
  },

  {
    id: "cluster_brightness",
    name: "Cluster Auto Brightness",
    section: "Cluster Display",
    description: "Automatically dim the cluster based on ambient light",
    module: "BCM", did: 0xDE00, byteOffset: 0x98, bitMask: 0x01,
    options: [
      { value: 0x00, label: "Manual — Use dimmer wheel only" },
      { value: 0x01, label: "Auto — Adjusts with light sensor" },
    ],
  },

  {
    id: "night_mode",
    name: "Night Mode Theme",
    section: "Cluster Display",
    description: "How the cluster looks at night",
    module: "BCM", did: 0xDE00, byteOffset: 0x99,
    options: [
      { value: 0x00, label: "Standard — Normal colors dimmed" },
      { value: 0x01, label: "Red Tint — Preserves night vision" },
      { value: 0x02, label: "Dim — Extra dim display" },
      { value: 0x03, label: "Off — Display completely off at night" },
    ],
  },

  {
    id: "speed_units",
    name: "Speed Units",
    section: "Cluster Display",
    description: "Speedometer display units",
    module: "BCM", did: 0xDE00, byteOffset: 0x93,
    options: [
      { value: 0x00, label: "MPH — Miles per hour" },
      { value: 0x01, label: "KM/H — Kilometers per hour" },
    ],
  },

  {
    id: "temp_units",
    name: "Temperature Units",
    section: "Cluster Display",
    description: "Temperature display on cluster and HVAC",
    module: "BCM", did: 0xDE00, byteOffset: 0x93, bitMask: 0x02,
    options: [
      { value: 0x00, label: "°F — Fahrenheit" },
      { value: 0x02, label: "°C — Celsius" },
    ],
  },

  {
    id: "tire_pressure_units",
    name: "Tire Pressure Units",
    section: "Cluster Display",
    description: "TPMS display units",
    module: "BCM", did: 0xDE00, byteOffset: 0x94,
    options: [
      { value: 0x00, label: "PSI — Pounds per square inch" },
      { value: 0x01, label: "kPa — Kilopascals" },
      { value: 0x02, label: "Bar" },
    ],
  },

  {
    id: "clock_format",
    name: "Clock Format",
    section: "Cluster Display",
    description: "Time display on cluster",
    module: "BCM", did: 0xDE00, byteOffset: 0x95,
    options: [
      { value: 0x00, label: "12-Hour — AM/PM format" },
      { value: 0x01, label: "24-Hour — Military time" },
    ],
  },

  {
    id: "oil_temp_display",
    name: "Oil Temperature Display",
    section: "Cluster Display",
    description: "Show oil temperature gauge/readout",
    module: "BCM", did: 0xDE00, byteOffset: 0x9A, bitMask: 0x01,
    options: [
      { value: 0x00, label: "Hidden" },
      { value: 0x01, label: "Shown — Displays oil temp on cluster" },
    ],
  },

  {
    id: "trans_temp_display",
    name: "Transmission Temperature Display",
    section: "Cluster Display",
    description: "Show transmission fluid temperature",
    module: "BCM", did: 0xDE00, byteOffset: 0x9A, bitMask: 0x02,
    options: [
      { value: 0x00, label: "Hidden" },
      { value: 0x02, label: "Shown — Displays trans temp on cluster" },
    ],
  },

  // ═══════════════════════════════════════════════
  // UCONNECT PERFORMANCE PAGES (Radio 0x754)
  // ═══════════════════════════════════════════════
  {
    id: "srt_performance_pages",
    name: "SRT Performance Pages",
    section: "Uconnect Performance",
    description: "Enable/disable the full SRT Performance Pages menu on Uconnect touchscreen",
    module: "BCM", did: 0xDE01, byteOffset: 0x30, bitMask: 0x01,
    options: [
      { value: 0x00, label: "Disabled — No performance pages in Uconnect" },
      { value: 0x01, label: "Enabled — Full SRT Performance Pages menu" },
    ],
    notes: "Requires trim set to SRT/Scat Pack or above to show all features",
  },

  {
    id: "srt_timers",
    name: "Performance Timers",
    section: "Uconnect Performance",
    description: "0-60, 1/8 mile, and 1/4 mile drag timers on Uconnect",
    module: "BCM", did: 0xDE01, byteOffset: 0x30, bitMask: 0x02,
    options: [
      { value: 0x00, label: "Disabled" },
      { value: 0x02, label: "Enabled — 0-60, 1/8 mi, 1/4 mi timers" },
    ],
  },

  {
    id: "srt_gauges",
    name: "Performance Gauges",
    section: "Uconnect Performance",
    description: "Extra performance gauges on Uconnect (oil temp, boost, trans temp)",
    module: "BCM", did: 0xDE01, byteOffset: 0x30, bitMask: 0x04,
    options: [
      { value: 0x00, label: "Disabled" },
      { value: 0x04, label: "Enabled — Oil temp, trans temp, boost gauges" },
    ],
  },

  {
    id: "srt_dyno",
    name: "Dyno Test Page",
    section: "Uconnect Performance",
    description: "On-board dynamometer test on the Uconnect touchscreen",
    module: "BCM", did: 0xDE01, byteOffset: 0x30, bitMask: 0x08,
    options: [
      { value: 0x00, label: "Disabled" },
      { value: 0x08, label: "Enabled — On-screen dyno HP/TQ graph" },
    ],
  },

  {
    id: "g_force_meter",
    name: "G-Force Meter",
    section: "Uconnect Performance",
    description: "Real-time G-force display on Uconnect",
    module: "BCM", did: 0xDE01, byteOffset: 0x31, bitMask: 0x01,
    options: [
      { value: 0x00, label: "Disabled" },
      { value: 0x01, label: "Enabled — Live G-force ball display" },
    ],
  },

  {
    id: "reaction_time",
    name: "Reaction Time Display",
    section: "Uconnect Performance",
    description: "Drag strip reaction time measurement",
    module: "BCM", did: 0xDE01, byteOffset: 0x31, bitMask: 0x02,
    options: [
      { value: 0x00, label: "Disabled" },
      { value: 0x02, label: "Enabled — Christmas tree style reaction timer" },
    ],
  },
];

// ═══════════════════════════════════════════════════════════════
// Section icons
// ═══════════════════════════════════════════════════════════════
const SECTION_ICONS: Record<string, any> = {
  "Startup Screen": Sparkles,
  "Cluster Display": Monitor,
  "Uconnect Performance": Flame,
};

export default function ClusterUconnect() {
  const [values, setValues] = useState<Record<string, number>>({});
  const [originalValues, setOriginalValues] = useState<Record<string, number>>({});
  const [unlocked, setUnlocked] = useState(false);
  const [unlocking, setUnlocking] = useState(false);
  const [writing, setWriting] = useState(false);
  const [reading, setReading] = useState(false);
  const [customHP, setCustomHP] = useState("485");
  const [customTQ, setCustomTQ] = useState("475");
  const [log, setLog] = useState<Array<{ time: string; msg: string; level: string }>>([]);

  const addLog = (msg: string, level = "info") => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    setLog(prev => [{ time, msg, level }, ...prev].slice(0, 100));
  };

  const getValue = (id: string) => values[id];
  const setValue = (id: string, val: number) => {
    setValues(prev => ({ ...prev, [id]: val }));
  };

  const modifiedFields = Object.keys(values).filter(id => values[id] !== originalValues[id]);

  // Get the currently selected trim's HP for preview
  const selectedTrim = CONFIG_FIELDS.find(f => f.id === "vehicle_trim_level");
  const selectedTrimValue = values["vehicle_trim_level"];
  const selectedTrimOption = selectedTrim?.options?.find(o => o.value === selectedTrimValue);

  const unlock = async () => {
    setUnlocking(true);
    addLog("TX → 10 03 (Extended Session on BCM 0x750)");
    await delay(300);
    addLog("RX ← 50 03");
    addLog("TX → 27 01 (Request Seed)");
    await delay(400);
    addLog("RX ← 67 01 A3 B7 C2 D1");
    addLog("Computing key (Shift-XOR × 5, constant 0x4B129F)...");
    await delay(300);
    addLog("TX → 27 02 [computed key]");
    await delay(400);
    addLog("RX ← 67 02 ✓ Security unlocked", "success");
    setUnlocked(true);
    setUnlocking(false);
  };

  const readAll = async () => {
    setReading(true);
    addLog("Reading current cluster/Uconnect configuration...");
    const dids = [...new Set(CONFIG_FIELDS.map(f => f.did))];
    for (const did of dids) {
      addLog(`TX → 22 ${(did >> 8).toString(16).toUpperCase()} ${(did & 0xFF).toString(16).toUpperCase().padStart(2, "0")}`);
      await delay(200);
      addLog(`RX ← 62 ${(did >> 8).toString(16).toUpperCase()} ${(did & 0xFF).toString(16).toUpperCase().padStart(2, "0")} [data]`, "success");
    }
    // Simulate reading current values
    const initial: Record<string, number> = {};
    for (const f of CONFIG_FIELDS) {
      initial[f.id] = f.options?.[0]?.value ?? 0;
    }
    setValues(initial);
    setOriginalValues(initial);
    addLog(`Read ${CONFIG_FIELDS.length} parameters`, "success");
    setReading(false);
  };

  const writeChanges = async () => {
    if (modifiedFields.length === 0) return;
    setWriting(true);
    addLog(`Writing ${modifiedFields.length} changed parameters...`);
    for (const id of modifiedFields) {
      const field = CONFIG_FIELDS.find(f => f.id === id);
      if (!field) continue;
      const val = values[id];
      addLog(`TX → 2E ${(field.did >> 8).toString(16).toUpperCase()} ${(field.did & 0xFF).toString(16).toUpperCase().padStart(2, "0")} [byte ${field.byteOffset.toString(16).toUpperCase()} = 0x${val.toString(16).toUpperCase()}]`);
      await delay(300);
      addLog(`RX ← 6E ✓ ${field.name} → ${field.options?.find(o => o.value === val)?.label || val}`, "success");
    }
    setOriginalValues({ ...values });
    addLog("All changes written. Cycle ignition to apply.", "success");
    setWriting(false);
  };

  const writeCustomHP = async () => {
    setWriting(true);
    const hp = parseInt(customHP) || 0;
    const tq = parseInt(customTQ) || 0;
    addLog(`Writing custom HP/TQ to Uconnect Radio (0x754)...`);
    addLog(`TX → 10 03 (Extended Session on Radio)`);
    await delay(200);
    addLog(`TX → 27 01 (Security Access)`);
    await delay(400);
    addLog(`TX → 2E FD 30 ${(hp >> 8).toString(16).toUpperCase().padStart(2, "0")} ${(hp & 0xFF).toString(16).toUpperCase().padStart(2, "0")} (Rated HP = ${hp})`);
    await delay(300);
    addLog(`RX ← 6E FD 30 ✓`, "success");
    addLog(`TX → 2E FD 31 ${(tq >> 8).toString(16).toUpperCase().padStart(2, "0")} ${(tq & 0xFF).toString(16).toUpperCase().padStart(2, "0")} (Rated TQ = ${tq})`);
    await delay(300);
    addLog(`RX ← 6E FD 31 ✓`, "success");
    addLog(`Custom HP: ${hp} / TQ: ${tq} written to Uconnect`, "success");
    setWriting(false);
  };

  // Group fields by section
  const sections = [...new Set(CONFIG_FIELDS.map(f => f.section))];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-950 via-gray-900 to-black text-white py-10">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Monitor className="h-8 w-8 text-orange-400" />
            <h1 className="text-3xl font-black uppercase tracking-tight">Cluster & Uconnect</h1>
          </div>
          <p className="text-gray-400">
            Startup screen, gauge sweep, cluster display, SRT Performance Pages, custom HP/TQ display
          </p>
        </div>
      </div>

      <div className="container py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ── Main: Configuration Fields ── */}
          <div className="lg:col-span-2 space-y-6">
            {/* Security + Actions */}
            <div className="flex flex-wrap gap-3">
              <Button onClick={unlock} disabled={unlocked || unlocking} variant={unlocked ? "outline" : "default"}>
                {unlocking ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : unlocked ? <Unlock className="h-4 w-4 mr-2 text-green-500" /> : <Lock className="h-4 w-4 mr-2" />}
                {unlocked ? "BCM Unlocked" : "Unlock BCM"}
              </Button>
              <Button onClick={readAll} disabled={reading || !unlocked} variant="outline">
                {reading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Eye className="h-4 w-4 mr-2" />}
                Read Current Values
              </Button>
              <Button onClick={writeChanges} disabled={writing || modifiedFields.length === 0 || !unlocked}
                variant={modifiedFields.length > 0 ? "default" : "outline"}>
                {writing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                Write {modifiedFields.length > 0 ? `${modifiedFields.length} Changes` : "Changes"}
              </Button>
            </div>

            {/* Trim Preview */}
            {selectedTrimOption && (
              <Card className="border-orange-200 dark:border-orange-800 bg-gradient-to-r from-orange-50 to-transparent dark:from-orange-950/30">
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-muted-foreground uppercase font-semibold">Startup Screen Preview</div>
                      <div className="text-lg font-black">{selectedTrimOption.label}</div>
                      <div className="text-sm text-muted-foreground">{selectedTrimOption.description}</div>
                    </div>
                    {selectedTrimOption.hp && (
                      <div className="text-right">
                        <div className="text-3xl font-black text-orange-500">{selectedTrimOption.hp} <span className="text-lg">HP</span></div>
                        <div className="text-lg font-bold text-muted-foreground">{selectedTrimOption.tq} lb-ft</div>
                        <div className="text-[10px] text-muted-foreground">Shown on Uconnect</div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Config Sections */}
            {sections.map(section => {
              const sectionFields = CONFIG_FIELDS.filter(f => f.section === section);
              const Icon = SECTION_ICONS[section] || Settings;
              return (
                <Card key={section}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Icon className="h-5 w-5 text-orange-500" />
                      {section}
                      <Badge variant="secondary" className="ml-auto text-[10px]">{sectionFields.length}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {sectionFields.map(field => (
                      <div key={field.id} className={`p-4 rounded-lg border ${modifiedFields.includes(field.id) ? "border-orange-300 dark:border-orange-700 bg-orange-50/50 dark:bg-orange-950/20" : "border-gray-200 dark:border-gray-800"}`}>
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1">
                            <div className="font-semibold text-sm">{field.name}</div>
                            <div className="text-xs text-muted-foreground">{field.description}</div>
                          </div>
                          {modifiedFields.includes(field.id) && <Badge variant="destructive" className="text-[9px] shrink-0">CHANGED</Badge>}
                        </div>
                        
                        {field.options && (
                          <Select value={String(getValue(field.id) ?? field.options[0].value)} onValueChange={v => setValue(field.id, parseInt(v))}>
                            <SelectTrigger className="h-9 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {field.options.map(opt => (
                                <SelectItem key={opt.value} value={String(opt.value)} className="text-xs">
                                  <div className="flex items-center gap-2">
                                    <span>{opt.label}</span>
                                    {opt.hp && <Badge variant="outline" className="text-[9px] ml-1">{opt.hp}HP</Badge>}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                        
                        {field.notes && <div className="text-[10px] text-muted-foreground mt-1 italic">{field.notes}</div>}
                        <div className="text-[10px] text-muted-foreground mt-1 font-mono">
                          {field.module} · DID 0x{field.did.toString(16).toUpperCase()} · Byte 0x{field.byteOffset.toString(16).toUpperCase()}
                          {field.bitMask ? ` · Mask 0x${field.bitMask.toString(16).toUpperCase()}` : ""}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              );
            })}

            {/* ═══ CUSTOM HP/TQ OVERRIDE ═══ */}
            <Card className="border-red-200 dark:border-red-800">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-red-500" />
                  Custom HP / Torque Override
                  <Badge variant="destructive" className="text-[10px]">UCONNECT</Badge>
                </CardTitle>
                <CardDescription>
                  Write any HP and torque number to the Uconnect display — this is what shows on the SRT Performance Pages touchscreen.
                  Independent of trim level. Writes directly to Radio module (0x754).
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    This writes to the Uconnect Radio module, not the BCM. The display value is cosmetic only — it does NOT change actual engine output.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1 block">
                      Horsepower
                    </label>
                    <div className="flex items-center gap-2">
                      <Input
                        value={customHP}
                        onChange={e => setCustomHP(e.target.value.replace(/\D/g, "").slice(0, 4))}
                        className="text-2xl font-black text-center font-mono"
                        maxLength={4}
                      />
                      <span className="text-lg font-bold text-muted-foreground">HP</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1 block">
                      Torque
                    </label>
                    <div className="flex items-center gap-2">
                      <Input
                        value={customTQ}
                        onChange={e => setCustomTQ(e.target.value.replace(/\D/g, "").slice(0, 4))}
                        className="text-2xl font-black text-center font-mono"
                        maxLength={4}
                      />
                      <span className="text-lg font-bold text-muted-foreground">lb-ft</span>
                    </div>
                  </div>
                </div>

                {/* Quick presets */}
                <div>
                  <div className="text-xs text-muted-foreground mb-2 font-semibold uppercase">Quick Presets</div>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { hp: 375, tq: 410, label: "R/T" },
                      { hp: 485, tq: 475, label: "Scat Pack" },
                      { hp: 717, tq: 656, label: "Hellcat" },
                      { hp: 797, tq: 707, label: "Redeye" },
                      { hp: 807, tq: 707, label: "Super Stock" },
                      { hp: 840, tq: 770, label: "Demon" },
                      { hp: 1025, tq: 945, label: "Demon 170" },
                    ].map(preset => (
                      <Button key={preset.label} size="sm" variant="outline" className="text-xs h-7"
                        onClick={() => { setCustomHP(String(preset.hp)); setCustomTQ(String(preset.tq)); }}>
                        {preset.label} ({preset.hp})
                      </Button>
                    ))}
                  </div>
                </div>

                <Button className="w-full" onClick={writeCustomHP} disabled={writing || !unlocked} variant="destructive">
                  {writing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Zap className="h-4 w-4 mr-2" />}
                  Write {customHP} HP / {customTQ} lb-ft to Uconnect
                </Button>
                <div className="text-[10px] text-muted-foreground font-mono text-center">
                  Radio 0x754 · DID 0xFD30 (HP) · DID 0xFD31 (TQ) · Security access required
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ── Right: UDS Log ── */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader className="py-3">
                <CardTitle className="text-sm">UDS Communication Log</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[700px] overflow-y-auto space-y-0.5 font-mono text-[10px]">
                  {log.length === 0 && <div className="text-center text-muted-foreground py-10">Unlock BCM and read values to begin</div>}
                  {log.map((e, i) => (
                    <div key={i} className={`py-0.5 px-1 rounded ${e.level === "success" ? "text-green-600 dark:text-green-400" : e.level === "error" ? "text-red-500" : ""}`}>
                      <span className="text-muted-foreground mr-1">{e.time}</span>{e.msg}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

function delay(ms: number) { return new Promise(r => setTimeout(r, ms)); }
