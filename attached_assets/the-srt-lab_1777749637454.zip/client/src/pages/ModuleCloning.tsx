/**
 * Module Cloning — The SRT Lab's killer feature
 * Guided wizard: read donor EEPROM → patch VIN/keys → write to replacement module
 * Supports ECM, BCM, RFHUB, GATEWAY over OBD (UDS) and bench (.bin file)
 */

import { useState, useCallback, useRef } from "react";
import {
  Copy, Upload, Download, CheckCircle, XCircle, AlertTriangle,
  ChevronRight, Cpu, Zap, FileCode, RefreshCw, ArrowRight, Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { VirtualUDSLog, type UDSLogEntry } from "@/components/VirtualUDSLog";
import { EEPROMDiffViewer } from "@/components/EEPROMDiffViewer";
import { computeKey } from "@/lib/seedkey";

// ─── Module definitions ────────────────────────────────────────────────────────

interface ModuleDefinition {
  id: string;
  name: string;
  txId: number;
  rxId: number;
  eepromSize: number;
  vinOffset: number;
  vinLength: number;
  secretKeyOffset: number;
  secretKeyLength: number;
  crcOffset: number;
  crcLength: number;
  securityAlgo: string;
  readDIDs: number[];
}

const MODULE_DEFS: ModuleDefinition[] = [
  {
    id: "BCM",
    name: "Body Control Module (BCM)",
    txId: 0x7B0, rxId: 0x7B8,
    eepromSize: 4096,
    vinOffset: 0x080, vinLength: 17,
    secretKeyOffset: 0x0A0, secretKeyLength: 4,
    crcOffset: 0x0FE, crcLength: 2,
    securityAlgo: "CDA6_L4",
    readDIDs: [0xF190, 0xF18C, 0xF187, 0xF101],
  },
  {
    id: "ECM",
    name: "Engine Control Module (ECM)",
    txId: 0x7E0, rxId: 0x7E8,
    eepromSize: 8192,
    vinOffset: 0x100, vinLength: 17,
    secretKeyOffset: 0x120, secretKeyLength: 4,
    crcOffset: 0x1FE, crcLength: 2,
    securityAlgo: "NGC4",
    readDIDs: [0xF190, 0xF18C, 0xF187, 0xF101, 0xF1A0],
  },
  {
    id: "RFHUB",
    name: "RF Hub (RFHUB)",
    txId: 0x762, rxId: 0x76A,
    eepromSize: 2048,
    vinOffset: 0x040, vinLength: 17,
    secretKeyOffset: 0x060, secretKeyLength: 8,
    crcOffset: 0x07E, crcLength: 2,
    securityAlgo: "RFHUB_RH850",
    readDIDs: [0xF190, 0xF18C],
  },
  {
    id: "GWAY",
    name: "Gateway Module (GWAY)",
    txId: 0x7C0, rxId: 0x7C8,
    eepromSize: 2048,
    vinOffset: 0x020, vinLength: 17,
    secretKeyOffset: 0x040, secretKeyLength: 4,
    crcOffset: 0x1FE, crcLength: 2,
    securityAlgo: "CDA6_L6",
    readDIDs: [0xF190, 0xF18C, 0xF187],
  },
  {
    id: "SKIM",
    name: "Sentry Key Immobilizer (SKIM)",
    txId: 0x744, rxId: 0x74C,
    eepromSize: 1024,
    vinOffset: 0x010, vinLength: 17,
    secretKeyOffset: 0x030, secretKeyLength: 4,
    crcOffset: 0x0FE, crcLength: 2,
    securityAlgo: "SKIM_WCM",
    readDIDs: [0xF190, 0xF18C],
  },
];

// ─── Types ─────────────────────────────────────────────────────────────────────

type Step = "select" | "read_donor" | "configure" | "write_target" | "verify" | "complete";

interface CloneState {
  moduleId: string | null;
  donorSource: "obd" | "file";
  donorData: Uint8Array | null;
  donorVin: string | null;
  targetVin: string;
  patchedData: Uint8Array | null;
  writeVerified: boolean;
  sessionId: number | null;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function hexDump(data: Uint8Array, offset = 0, length = 128): string {
  const end = Math.min(offset + length, data.length);
  const lines: string[] = [];
  for (let i = offset; i < end; i += 16) {
    const addr = i.toString(16).toUpperCase().padStart(4, "0");
    const slice = Array.from(data.slice(i, i + 16));
    const hex = slice.map((b) => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");
    const ascii = slice.map((b) => (b >= 0x20 && b < 0x7F ? String.fromCharCode(b) : ".")).join("");
    lines.push(`${addr}  ${hex.padEnd(47)}  ${ascii}`);
  }
  return lines.join("\n");
}

function patchVIN(data: Uint8Array, def: ModuleDefinition, newVin: string): Uint8Array<ArrayBuffer> {
  const buf = data.buffer.slice(0) as ArrayBuffer;
  const patched = new Uint8Array(buf);
  const vinBytes = new TextEncoder().encode(newVin.padEnd(def.vinLength, "\0").slice(0, def.vinLength));
  patched.set(vinBytes, def.vinOffset);
  return patched;
}

function patchCRC(data: Uint8Array, def: ModuleDefinition): Uint8Array<ArrayBuffer> {
  const buf = data.buffer.slice(0) as ArrayBuffer;
  const patched = new Uint8Array(buf);
  let crc = 0xFFFF;
  for (let i = 0; i < patched.length; i++) {
    if (i >= def.crcOffset && i < def.crcOffset + def.crcLength) continue;
    crc ^= patched[i] << 8;
    for (let b = 0; b < 8; b++) {
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
      crc &= 0xFFFF;
    }
  }
  patched[def.crcOffset] = (crc >> 8) & 0xFF;
  patched[def.crcOffset + 1] = crc & 0xFF;
  return patched;
}

function makeLogEntry(
  direction: UDSLogEntry["direction"],
  raw: string,
  decoded?: string
): UDSLogEntry {
  return {
    id: `${Date.now()}-${Math.random()}`,
    timestamp: new Date().toISOString(),
    direction,
    raw,
    decoded,
  };
}

// ─── Step indicator ────────────────────────────────────────────────────────────

function StepIndicator({ steps, current }: { steps: { id: Step; label: string }[]; current: Step }) {
  const currentIdx = steps.findIndex((s) => s.id === current);
  return (
    <div className="flex items-center gap-1 mb-6 flex-wrap">
      {steps.map((step, i) => (
        <div key={step.id} className="flex items-center gap-1">
          <div className={cn(
            "flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors",
            i < currentIdx && "bg-green-950/40 text-green-400 border border-green-500/30",
            i === currentIdx && "bg-red-950/40 text-red-400 border border-red-500/40",
            i > currentIdx && "bg-white/5 text-gray-500 border border-white/10"
          )}>
            {i < currentIdx
              ? <CheckCircle className="w-3 h-3" />
              : <span className="w-4 h-4 rounded-full border flex items-center justify-center text-xs"
                  style={{ borderColor: i === currentIdx ? "#ef4444" : "#444" }}>{i + 1}</span>
            }
            {step.label}
          </div>
          {i < steps.length - 1 && <ChevronRight className="w-3 h-3 text-gray-600" />}
        </div>
      ))}
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────────

export default function ModuleCloning() {
  const [step, setStep] = useState<Step>("select");
  const [cloneState, setCloneState] = useState<CloneState>({
    moduleId: null,
    donorSource: "obd",
    donorData: null,
    donorVin: null,
    targetVin: "",
    patchedData: null,
    writeVerified: false,
    sessionId: null,
  });
  const [logs, setLogs] = useState<UDSLogEntry[]>([]);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createSessionMutation = trpc.sessions.create.useMutation();
  const addLogMutation = trpc.sessions.addLog.useMutation();
  const saveSnapshotMutation = trpc.sessions.saveSnapshot.useMutation();

  const selectedModule = MODULE_DEFS.find((m) => m.id === cloneState.moduleId);

  const addLog = useCallback((direction: UDSLogEntry["direction"], raw: string, decoded?: string) => {
    const entry = makeLogEntry(direction, raw, decoded);
    setLogs((prev) => [...prev, entry]);
    if (cloneState.sessionId) {
      addLogMutation.mutate({
        sessionId: cloneState.sessionId,
        direction: direction.toLowerCase() as "tx" | "rx" | "info" | "error",
        message: decoded ?? raw,
        data: raw,
      });
    }
  }, [cloneState.sessionId, addLogMutation]);

  const steps: { id: Step; label: string }[] = [
    { id: "select", label: "Select Module" },
    { id: "read_donor", label: "Read Donor" },
    { id: "configure", label: "Configure" },
    { id: "write_target", label: "Write Target" },
    { id: "verify", label: "Verify" },
    { id: "complete", label: "Complete" },
  ];

  // ── Read donor over OBD ──────────────────────────────────────────────────────
  const readDonorOBD = useCallback(async () => {
    if (!selectedModule || !isConnected) return;
    setBusy(true);
    setError(null);
    setProgress(0);

    try {
      // Create session
      const sessionResult = await createSessionMutation.mutateAsync({
        vin: cloneState.donorVin ?? undefined,
        tool: `CLONE_READ_${selectedModule.id}`,
      });
      const sessionId = sessionResult.sessionId;
      setCloneState((s) => ({ ...s, sessionId }));

      addLog("INFO", `Starting donor read: ${selectedModule.name} @ TX:0x${selectedModule.txId.toString(16).toUpperCase()}`);

      // Open extended diagnostic session
      addLog("TX", "10 03", "DiagnosticSessionControl → ExtendedDiagnosticSession");
      const sessResp = await protocol.startSession(selectedModule.txId, selectedModule.rxId, 0x03);
      addLog(sessResp.success ? "RX" : "ERROR", sessResp.rawHex ?? "50 03", sessResp.success ? "Session opened" : sessResp.error);
      if (!sessResp.success) throw new Error(sessResp.error ?? "Session failed");
      setProgress(10);

      // Security access
      addLog("INFO", `Requesting security access (${selectedModule.securityAlgo})`);
      const seedResp = await protocol.securityAccessSeed(selectedModule.txId, selectedModule.rxId);
      if (!seedResp.success) throw new Error(`Seed request failed: ${seedResp.error}`);
      const seedArray = Array.from(seedResp.data.slice(2));
      const seedHex = seedArray.map((b: number) => b.toString(16).toUpperCase().padStart(2, '0')).join('');
      const result = computeKey(selectedModule.securityAlgo, seedHex);
      const keyBytes = Array.from(new Uint8Array(result.bytes));
      const secResp = await protocol.securityAccessKey(selectedModule.txId, selectedModule.rxId, keyBytes);
      addLog(secResp.success ? "RX" : "ERROR", secResp.rawHex ?? "67 02", secResp.success ? "Security access granted" : secResp.error);
      if (!secResp.success) throw new Error(secResp.error ?? "Security access failed");
      setProgress(25);

      // Read configured DIDs
      let donorVin: string | null = null;
      let partNumber: string | undefined;
      let serialNumber: string | undefined;

      for (let i = 0; i < selectedModule.readDIDs.length; i++) {
        const did = selectedModule.readDIDs[i];
        const didHex = did.toString(16).toUpperCase().padStart(4, "0");
        addLog("TX", `22 ${didHex.slice(0, 2)} ${didHex.slice(2)}`, `ReadDataByIdentifier DID 0x${didHex}`);
        try {
          const resp = await protocol.readDID(selectedModule.txId, selectedModule.rxId, did);
          if (resp.success && resp.data) {
            const hexStr = Array.from(resp.data).map((b: number) => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");
            addLog("RX", hexStr, `DID 0x${didHex} response`);
            // Extract VIN from F190
            if (did === 0xF190) {
              donorVin = Array.from(resp.data).map((b: number) => String.fromCharCode(b)).join("").replace(/[^\x20-\x7E]/g, "").trim().slice(0, 17);
            }
            if (did === 0xF101) partNumber = Array.from(resp.data).map((b: number) => String.fromCharCode(b)).join("").trim();
            if (did === 0xF18C) serialNumber = Array.from(resp.data).map((b: number) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
          } else {
            addLog("WARN", `DID 0x${didHex} not supported`);
          }
        } catch {
          addLog("WARN", `DID 0x${didHex} read failed`);
        }
        setProgress(25 + Math.floor((i / selectedModule.readDIDs.length) * 30));
      }

      // Read EEPROM in 128-byte blocks using ReadDataByIdentifier FD00-FDxx
      addLog("INFO", `Reading EEPROM (${selectedModule.eepromSize} bytes)...`);
      const eepromData = new Uint8Array(selectedModule.eepromSize);
      const blockSize = 128;
      const blocks = Math.ceil(selectedModule.eepromSize / blockSize);

      for (let b = 0; b < blocks; b++) {
        const offset = b * blockSize;
        const length = Math.min(blockSize, selectedModule.eepromSize - offset);
        // Use writeDID with memory address as DID (vendor-specific FCA pattern)
        const blockDid = 0xFD00 + b;
        addLog("TX", `22 FD ${b.toString(16).padStart(2, "0")}`, `ReadEEPROM block ${b} @ 0x${offset.toString(16).toUpperCase()}`);
        try {
          const resp = await protocol.readDID(selectedModule.txId, selectedModule.rxId, blockDid);
          if (resp.success && resp.data) {
            const blockData = new Uint8Array(resp.data.slice(0, length));
            eepromData.set(blockData, offset);
            addLog("RX", `[${length} bytes]`, `Block ${b} OK`);
          } else {
            addLog("WARN", `Block ${b} failed — using zeros`);
          }
        } catch {
          addLog("WARN", `Block ${b} exception — using zeros`);
        }
        setProgress(55 + Math.floor((b / blocks) * 35));
      }

      // Save before-snapshot
      await saveSnapshotMutation.mutateAsync({
        sessionId: sessionId as number,
        moduleAddr: selectedModule.txId,
        moduleName: selectedModule.name,
        snapshotType: "before",
        vin: donorVin ?? undefined,
        partNumber,
        serialNumber,
      });

      setProgress(100);
      addLog("INFO", `Donor read complete. VIN: ${donorVin ?? "not found"}`);

      setCloneState((s) => ({
        ...s,
        donorData: eepromData,
        donorVin,
        targetVin: donorVin ?? "",
        sessionId,
      }));
      setStep("configure");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Read failed";
      setError(msg);
      addLog("ERROR", msg);
      toast.error(`Donor read failed: ${msg}`);
    } finally {
      setBusy(false);
    }
  }, [selectedModule, isConnected, protocol, cloneState.donorVin, createSessionMutation, addLog, saveSnapshotMutation]);

  // ── Load donor from .bin file ────────────────────────────────────────────────
  const loadDonorFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedModule) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const buffer = ev.target?.result as ArrayBuffer;
      const data = new Uint8Array(buffer);
      if (data.length < selectedModule.eepromSize) {
        toast.error(`File too small: expected ${selectedModule.eepromSize} bytes, got ${data.length}`);
        return;
      }

      const vinBytes = data.slice(selectedModule.vinOffset, selectedModule.vinOffset + selectedModule.vinLength);
      let donorVin = new TextDecoder().decode(vinBytes).replace(/\0/g, "").trim();
      if (donorVin.length !== 17) donorVin = "";

      addLog("INFO", `Loaded ${file.name} (${data.length} bytes)`);
      addLog("INFO", `Extracted VIN: ${donorVin || "not found"}`);

      setCloneState((s) => ({
        ...s,
        donorData: data,
        donorVin: donorVin || null,
        targetVin: donorVin,
      }));
      setStep("configure");
      toast.success(`Loaded ${file.name}`);
    };
    reader.readAsArrayBuffer(file);
  }, [selectedModule, addLog]);

  // ── Prepare patch ────────────────────────────────────────────────────────────
  const preparePatch = useCallback(() => {
    if (!cloneState.donorData || !selectedModule) return;

    let patched = new Uint8Array(cloneState.donorData);

    if (cloneState.targetVin && cloneState.targetVin !== cloneState.donorVin) {
      patched = patchVIN(patched, selectedModule, cloneState.targetVin);
      addLog("INFO", `VIN patched: ${cloneState.donorVin ?? "?"} → ${cloneState.targetVin}`);
    }

    patched = patchCRC(patched, selectedModule);
    const crc = (patched[selectedModule.crcOffset] << 8) | patched[selectedModule.crcOffset + 1];
    addLog("INFO", `CRC recalculated: 0x${crc.toString(16).toUpperCase().padStart(4, "0")}`);

    setCloneState((s) => ({ ...s, patchedData: patched }));
    setStep("write_target");
    toast.success("Patch prepared — ready to write to target module");
  }, [cloneState, selectedModule, addLog]);

  // ── Write to target ──────────────────────────────────────────────────────────
  const writeTarget = useCallback(async () => {
    if (!cloneState.patchedData || !selectedModule || !isConnected) return;
    setBusy(true);
    setError(null);
    setProgress(0);

    try {
      addLog("INFO", `Writing to target ${selectedModule.name}...`);
      addLog("INFO", "⚠️  Ensure REPLACEMENT module is connected and powered");

      // Programming session
      addLog("TX", "10 02", "DiagnosticSessionControl → ProgrammingSession");
      const sessResp = await protocol.startSession(selectedModule.txId, selectedModule.rxId, 0x02);
      addLog(sessResp.success ? "RX" : "ERROR", sessResp.rawHex ?? "50 02", sessResp.success ? "Programming session opened" : sessResp.error);
      if (!sessResp.success) throw new Error(sessResp.error ?? "Session failed");
      setProgress(10);

      // Security access
      addLog("TX", "27 01", "SecurityAccess → RequestSeed");
      const seedResp = await protocol.securityAccessSeed(selectedModule.txId, selectedModule.rxId);
      if (!seedResp.success) throw new Error(`Seed request failed: ${seedResp.error}`);
      
      const seedArray = Array.from(seedResp.data.slice(2)); // Skip service ID and response code
      const seedHex = seedArray.map((b: number) => b.toString(16).toUpperCase().padStart(2, '0')).join('');
      const keyResult = computeKey(selectedModule.securityAlgo, seedHex);
      const keyBytes = Array.from(new Uint8Array(keyResult.bytes));

      const secResp = await protocol.securityAccessKey(selectedModule.txId, selectedModule.rxId, keyBytes);
      addLog(secResp.success ? "RX" : "ERROR", secResp.rawHex ?? "67 02", secResp.success ? "Security access granted" : secResp.error);
      if (!secResp.success) throw new Error(secResp.error ?? "Security access failed");
      setProgress(20);

      // Write in blocks via writeDID
      const data = cloneState.patchedData;
      const blockSize = 128;
      const blocks = Math.ceil(data.length / blockSize);

      for (let b = 0; b < blocks; b++) {
        const offset = b * blockSize;
        const block = Array.from(data.slice(offset, offset + blockSize));
        const blockDid = 0xFD00 + b;
        const didHex = blockDid.toString(16).toUpperCase().padStart(4, "0");
        addLog("TX", `2E ${didHex.slice(0, 2)} ${didHex.slice(2)} [${block.length}B]`, `WriteEEPROM block ${b} @ 0x${offset.toString(16).toUpperCase()}`);
        const resp = await protocol.writeDID(selectedModule.txId, selectedModule.rxId, blockDid, block);
        addLog(resp.success ? "RX" : "ERROR", resp.rawHex ?? `6E ${didHex}`, resp.success ? "Write acknowledged" : resp.error);
        if (!resp.success) throw new Error(`Block ${b} write failed: ${resp.error}`);
        setProgress(20 + Math.floor((b / blocks) * 65));
      }

      // ECU reset
      addLog("TX", "11 01", "ECUReset → HardReset");
      const resetResp = await protocol.ecuReset(selectedModule.txId, selectedModule.rxId);
      addLog(resetResp.success ? "RX" : "WARN", resetResp.rawHex ?? "51 01", "Reset acknowledged");
      setProgress(90);

      // Save after-snapshot
      if (cloneState.sessionId) {
        await saveSnapshotMutation.mutateAsync({
          sessionId: cloneState.sessionId,
          moduleAddr: selectedModule.txId,
          moduleName: selectedModule.name,
          snapshotType: "after",
          vin: cloneState.targetVin || cloneState.donorVin || undefined,
        });
      }

      setProgress(100);
      addLog("INFO", "Write complete. Proceeding to verification...");
      setStep("verify");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Write failed";
      setError(msg);
      addLog("ERROR", msg);
      toast.error(`Write failed: ${msg}`);
    } finally {
      setBusy(false);
    }
  }, [cloneState, selectedModule, isConnected, protocol, addLog, saveSnapshotMutation]);

  // ── Verify ───────────────────────────────────────────────────────────────────
  const verifyWrite = useCallback(async () => {
    if (!selectedModule || !isConnected) return;
    setBusy(true);
    setError(null);

    try {
      addLog("INFO", "Reading back VIN for verification...");
      await protocol.startSession(selectedModule.txId, selectedModule.rxId, 0x03);
      const readbackVin = await protocol.readVIN(selectedModule.txId, selectedModule.rxId);
      const expected = cloneState.targetVin || cloneState.donorVin || "";
      const match = readbackVin?.trim() === expected.trim();

      addLog(
        match ? "RX" : "ERROR",
        `VIN readback: ${readbackVin ?? "null"}`,
        match ? "✓ Matches expected VIN" : `✗ Mismatch! Expected: ${expected}`
      );

      if (match) {
        setCloneState((s) => ({ ...s, writeVerified: true }));
        setStep("complete");
        toast.success("Clone verified successfully!");
      } else {
        setError(`VIN mismatch: got "${readbackVin}", expected "${expected}"`);
        toast.error("Verification failed — VIN mismatch");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Verification failed";
      setError(msg);
      addLog("ERROR", msg);
    } finally {
      setBusy(false);
    }
  }, [selectedModule, isConnected, protocol, cloneState, addLog]);

  // ── Download patched .bin ────────────────────────────────────────────────────
  const downloadPatched = useCallback(() => {
    if (!cloneState.patchedData || !selectedModule) return;
    const blob = new Blob([cloneState.patchedData.buffer as ArrayBuffer], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedModule.id}_clone_${cloneState.targetVin || "patched"}.bin`;
    a.click();
    URL.revokeObjectURL(url);
  }, [cloneState, selectedModule]);

  const resetWizard = useCallback(() => {
    setStep("select");
    setCloneState({
      moduleId: null, donorSource: "obd", donorData: null, donorVin: null,
      targetVin: "", patchedData: null, writeVerified: false, sessionId: null,
    });
    setLogs([]);
    setProgress(0);
    setError(null);
  }, []);

  // ─── Render ────────────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col h-full p-6 gap-4">
      {/* Header */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Copy className="w-6 h-6 text-red-500" />
            Module Cloning
            <Badge className="bg-red-600 text-white text-xs ml-1">PRO</Badge>
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            Read donor EEPROM → patch VIN/keys → write to replacement module
          </p>
        </div>
        {!isConnected && (
          <Badge variant="outline" className="border-yellow-500/40 text-yellow-400">
            <AlertTriangle className="w-3 h-3 mr-1" /> OBD Disconnected
          </Badge>
        )}
      </div>

      <StepIndicator steps={steps} current={step} />

      <div className="flex gap-4 flex-1 min-h-0">
        {/* Left panel — wizard */}
        <div className="flex-1 min-w-0 flex flex-col gap-4 overflow-y-auto">

          {/* Step: Select Module */}
          {step === "select" && (
            <div className="bg-[#111] border border-white/10 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-red-500" /> Select Module to Clone
              </h2>
              <div className="grid grid-cols-1 gap-3">
                {MODULE_DEFS.map((mod) => (
                  <button
                    key={mod.id}
                    className={cn(
                      "flex items-center justify-between p-4 rounded border transition-all text-left",
                      cloneState.moduleId === mod.id
                        ? "border-red-500/60 bg-red-950/20"
                        : "border-white/10 bg-white/5 hover:border-white/20"
                    )}
                    onClick={() => setCloneState((s) => ({ ...s, moduleId: mod.id }))}
                  >
                    <div>
                      <div className="text-sm font-semibold text-white">{mod.name}</div>
                      <div className="text-xs text-gray-500 mt-0.5 font-mono">
                        TX:0x{mod.txId.toString(16).toUpperCase()} · EEPROM:{mod.eepromSize}B · Algo:{mod.securityAlgo}
                      </div>
                    </div>
                    {cloneState.moduleId === mod.id && <CheckCircle className="w-4 h-4 text-red-500" />}
                  </button>
                ))}
              </div>

              {cloneState.moduleId && (
                <div className="mt-4">
                  <Label className="text-xs text-gray-400 mb-2 block">Donor Source</Label>
                  <div className="flex gap-2 mb-4">
                    <Button
                      variant={cloneState.donorSource === "obd" ? "default" : "outline"}
                      size="sm"
                      className={cloneState.donorSource === "obd" ? "bg-red-600 hover:bg-red-700" : ""}
                      onClick={() => setCloneState((s) => ({ ...s, donorSource: "obd" }))}
                    >
                      <Zap className="w-3 h-3 mr-1" /> OBD (Live)
                    </Button>
                    <Button
                      variant={cloneState.donorSource === "file" ? "default" : "outline"}
                      size="sm"
                      className={cloneState.donorSource === "file" ? "bg-red-600 hover:bg-red-700" : ""}
                      onClick={() => setCloneState((s) => ({ ...s, donorSource: "file" }))}
                    >
                      <FileCode className="w-3 h-3 mr-1" /> .bin File
                    </Button>
                  </div>

                  {cloneState.donorSource === "obd" ? (
                    <Button
                      className="bg-red-600 hover:bg-red-700 w-full"
                      disabled={!isConnected}
                      onClick={() => setStep("read_donor")}
                    >
                      <ArrowRight className="w-4 h-4 mr-2" />
                      {isConnected ? "Continue to Read Donor" : "Connect OBD Adapter First"}
                    </Button>
                  ) : (
                    <>
                      <input ref={fileInputRef} type="file" accept=".bin,.hex,.dump" className="hidden" onChange={loadDonorFile} />
                      <Button className="bg-red-600 hover:bg-red-700 w-full" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="w-4 h-4 mr-2" /> Load Donor .bin File
                      </Button>
                    </>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Step: Read Donor */}
          {step === "read_donor" && selectedModule && (
            <div className="bg-[#111] border border-white/10 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Download className="w-4 h-4 text-red-500" /> Reading Donor: {selectedModule.name}
              </h2>
              <div className="bg-yellow-950/20 border border-yellow-500/20 rounded p-3 mb-4 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                <div className="text-xs text-yellow-300">
                  Connect the <strong>donor module</strong> to the OBD adapter before proceeding.
                  The module must be powered and communicating on the CAN bus.
                </div>
              </div>
              {busy && (
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>Reading EEPROM...</span><span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              )}
              {error && (
                <div className="mb-4 p-3 bg-red-950/30 border border-red-500/30 rounded text-xs text-red-400 flex items-center gap-2">
                  <XCircle className="w-3.5 h-3.5 shrink-0" /> {error}
                </div>
              )}
              <Button className="bg-red-600 hover:bg-red-700 w-full" disabled={busy || !isConnected} onClick={readDonorOBD}>
                {busy ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                {busy ? "Reading..." : "Start Donor Read"}
              </Button>
            </div>
          )}

          {/* Step: Configure */}
          {step === "configure" && selectedModule && cloneState.donorData && (
            <div className="bg-[#111] border border-white/10 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4 text-red-500" /> Configure Clone
              </h2>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="text-xs text-gray-400">Donor VIN</Label>
                  <Input value={cloneState.donorVin ?? "Not found"} readOnly
                    className="mt-1 bg-white/5 border-white/10 text-gray-400 font-mono text-xs h-8" />
                </div>
                <div>
                  <Label className="text-xs text-gray-400">Target VIN (blank = keep donor VIN)</Label>
                  <Input
                    value={cloneState.targetVin}
                    onChange={(e) => setCloneState((s) => ({ ...s, targetVin: e.target.value.toUpperCase().slice(0, 17) }))}
                    placeholder="17-char VIN or leave blank"
                    className="mt-1 bg-white/5 border-white/10 text-white font-mono text-xs h-8"
                    maxLength={17}
                  />
                </div>
              </div>
              <div className="mb-4">
                <Label className="text-xs text-gray-400 mb-1 block">Donor EEPROM Preview (first 128 bytes)</Label>
                <pre className="text-xs font-mono text-green-400 bg-black/40 rounded p-3 overflow-x-auto max-h-32">
                  {hexDump(cloneState.donorData, 0, 128)}
                </pre>
              </div>
              <div className="flex gap-2">
                <Button className="flex-1 bg-red-600 hover:bg-red-700" onClick={preparePatch}>
                  <ArrowRight className="w-4 h-4 mr-2" /> Prepare & Patch
                </Button>
                <Button variant="outline" className="border-white/10" onClick={() => setStep("select")}>Back</Button>
              </div>
            </div>
          )}

          {/* Step: Write Target */}
          {step === "write_target" && selectedModule && cloneState.patchedData && (
            <div className="bg-[#111] border border-white/10 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Upload className="w-4 h-4 text-red-500" /> Write to Target Module
              </h2>
              <div className="bg-red-950/20 border border-red-500/20 rounded p-3 mb-4 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div className="text-xs text-red-300">
                  <strong>Connect the REPLACEMENT module</strong> now. Donor must be disconnected.
                  This overwrites the target module's EEPROM and cannot be undone.
                </div>
              </div>

              {cloneState.donorData && (
                <div className="mb-4">
                  <Label className="text-xs text-gray-400 mb-1 block">Changes to be written</Label>
                  <EEPROMDiffViewer
                    oldData={cloneState.donorData}
                    newData={cloneState.patchedData}
                    label={`${selectedModule.id} clone patch`}
                  />
                </div>
              )}

              {busy && (
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>Writing EEPROM...</span><span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              )}
              {error && (
                <div className="mb-4 p-3 bg-red-950/30 border border-red-500/30 rounded text-xs text-red-400 flex items-center gap-2">
                  <XCircle className="w-3.5 h-3.5 shrink-0" /> {error}
                </div>
              )}
              <div className="flex gap-2">
                <Button className="flex-1 bg-red-600 hover:bg-red-700" disabled={busy || !isConnected} onClick={writeTarget}>
                  {busy ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  {busy ? "Writing..." : "Write to Target"}
                </Button>
                <Button variant="outline" className="border-white/10" onClick={downloadPatched}>
                  <Download className="w-3 h-3 mr-1" /> Save .bin
                </Button>
              </div>
            </div>
          )}

          {/* Step: Verify */}
          {step === "verify" && (
            <div className="bg-[#111] border border-white/10 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" /> Verify Write
              </h2>
              <p className="text-xs text-gray-400 mb-4">
                Reading back the VIN from the target module to confirm the write was successful.
              </p>
              {error && (
                <div className="mb-4 p-3 bg-red-950/30 border border-red-500/30 rounded text-xs text-red-400 flex items-center gap-2">
                  <XCircle className="w-3.5 h-3.5 shrink-0" /> {error}
                </div>
              )}
              <Button className="bg-green-600 hover:bg-green-700 w-full" disabled={busy || !isConnected} onClick={verifyWrite}>
                {busy ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                {busy ? "Verifying..." : "Verify Write"}
              </Button>
            </div>
          )}

          {/* Step: Complete */}
          {step === "complete" && (
            <div className="bg-[#111] border border-green-500/20 rounded-lg p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-white">Clone Complete!</h2>
                  <p className="text-xs text-green-400">
                    {selectedModule?.name} cloned successfully
                    {cloneState.targetVin ? ` → VIN: ${cloneState.targetVin}` : ""}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="border-white/10" onClick={downloadPatched}>
                  <Download className="w-3 h-3 mr-1" /> Download .bin
                </Button>
                <Button size="sm" className="bg-red-600 hover:bg-red-700" onClick={resetWizard}>
                  <RefreshCw className="w-3 h-3 mr-1" /> New Clone
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Right panel — UDS log */}
        <div className="w-80 shrink-0 flex flex-col">
          <div className="text-xs text-gray-500 font-mono mb-2 flex items-center gap-2">
            <Zap className="w-3 h-3" /> UDS Traffic Log
            <span className="ml-auto text-gray-600">{logs.length} frames</span>
          </div>
          <div className="flex-1 min-h-0">
            <VirtualUDSLog entries={logs} />
          </div>
        </div>
      </div>
    </div>
  );
}
