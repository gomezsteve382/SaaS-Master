import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ConnectionProvider } from "./contexts/ConnectionContext";
import Home from "./pages/Home";
// import ModuleScanner from "./pages/ModuleScanner";
// import DTCReader from "./pages/DTCReader";
import SeedKeyCalculator from './pages/SeedKeyCalculator';
import KeyProgramming from './pages/KeyProgramming';
import RFHUBVirginizer from './pages/RFHUBVirginizer';
// import EEPROMViewer from './pages/EEPROMViewer';
import ProxyAlignment from './pages/ProxyAlignment';
import VINCommander from './pages/VINCommander';
// import BCMConfiguration from './pages/BCMConfiguration';
// import ClusterUconnect from './pages/ClusterUconnect';
import AlphaOBDExplorer from './pages/AlphaOBDExplorer';

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      {/* <Route path={"/module-scanner"} component={ModuleScanner} /> */}
      {/* <Route path={"/dtc-reader"} component={DTCReader} /> */}
      <Route path="/seed-key-calculator" component={SeedKeyCalculator} />
      <Route path="/key-programming" component={KeyProgramming} />
      <Route path="/rfhub-virginizer" component={RFHUBVirginizer} />
      {/* <Route path="/eeprom-viewer" component={EEPROMViewer} /> */}
      <Route path="/proxy-alignment" component={ProxyAlignment} />
      <Route path="/vin-commander" component={VINCommander} />
      {/* <Route path="/bcm-config" component={BCMConfiguration} /> */}
      {/* <Route path="/cluster-uconnect" component={ClusterUconnect} /> */}
      <Route path="/db-explorer" component={AlphaOBDExplorer} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <ConnectionProvider>
          <TooltipProvider>
            <div className="flex flex-col min-h-screen">
              <div className="flex-1">
                <Toaster />
                <Router />
              </div>
            </div>
          </TooltipProvider>
        </ConnectionProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
