import React, { createContext, useContext, useState, useCallback } from 'react';
import { AlphaOBDProtocol } from '@/lib/AlphaOBDProtocol';

interface ConnectionContextType {
  protocol: AlphaOBDProtocol | null;
  isConnected: boolean;
  connect: () => Promise<boolean>;
  disconnect: () => Promise<void>;
  error: string | null;
}

const ConnectionContext = createContext<ConnectionContextType | undefined>(undefined);

export function ConnectionProvider({ children }: { children: React.ReactNode }) {
  const [protocol, setProtocol] = useState<AlphaOBDProtocol | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const connect = useCallback(async () => {
    try {
      setError(null);
      const proto = new AlphaOBDProtocol();
      const connected = await proto.connect();
      if (connected) {
        setProtocol(proto);
        setIsConnected(true);
        return true;
      } else {
        setError('Failed to connect to OBD adapter');
        return false;
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      return false;
    }
  }, []);

  const disconnect = useCallback(async () => {
    try {
      if (protocol) {
        await protocol.disconnect();
        setProtocol(null);
        setIsConnected(false);
        setError(null);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
    }
  }, [protocol]);

  return (
    <ConnectionContext.Provider value={{ protocol, isConnected, connect, disconnect, error }}>
      {children}
    </ConnectionContext.Provider>
  );
}

export function useConnection() {
  const context = useContext(ConnectionContext);
  if (!context) {
    throw new Error('useConnection must be used within ConnectionProvider');
  }
  return context;
}
