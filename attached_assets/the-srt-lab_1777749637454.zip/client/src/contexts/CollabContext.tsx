/**
 * CollabContext — real-time collaboration state for The SRT Lab
 * Manages socket.io connection, presence list, and tool approval workflow.
 * Wrap pages that need live collaboration with <CollabProvider vin={vin} />.
 */

import { createContext, useContext, useEffect, useRef, useState, useCallback, ReactNode } from "react";
import { io, Socket } from "socket.io-client";
import { useAuth } from "@/_core/hooks/useAuth";

export interface CollabUser {
  userId: number;
  name: string;
  role: "owner" | "viewer" | "technician";
  sessionId: string;
  vin?: string;
  tool?: string;
  color: string;
}

export interface ToolApprovalRequest {
  id: string;
  requesterId: number;
  requesterName: string;
  tool: string;
  description: string;
  payload: unknown;
  sessionId: string;
  timestamp: number;
}

interface CollabContextValue {
  connected: boolean;
  presence: CollabUser[];
  pendingApprovals: ToolApprovalRequest[];
  requestApproval: (tool: string, description: string, payload: unknown) => Promise<boolean>;
  respondApproval: (requestId: string, approved: boolean) => void;
  broadcastLog: (entry: unknown) => void;
  broadcastScanProgress: (data: unknown) => void;
  updateActivity: (tool?: string) => void;
}

const CollabContext = createContext<CollabContextValue | null>(null);

export function useCollab(): CollabContextValue {
  const ctx = useContext(CollabContext);
  if (!ctx) throw new Error("useCollab must be used inside CollabProvider");
  return ctx;
}

interface CollabProviderProps {
  vin: string | null;
  children: ReactNode;
}

export function CollabProvider({ vin, children }: CollabProviderProps) {
  const { user } = useAuth();
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [presence, setPresence] = useState<CollabUser[]>([]);
  const [pendingApprovals, setPendingApprovals] = useState<ToolApprovalRequest[]>([]);

  // Pending approval resolvers — keyed by request ID
  const approvalResolvers = useRef<Map<string, (approved: boolean) => void>>(new Map());

  useEffect(() => {
    if (!vin || !user) return;

    const socket = io(window.location.origin, {
      path: "/api/collab",
      transports: ["websocket"],
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      socket.emit("join_session", {
        vin,
        userId: user.id,
        name: user.name ?? "Technician",
        role: user.role === "admin" ? "owner" : "technician",
      });
    });

    socket.on("disconnect", () => setConnected(false));

    socket.on("presence_update", (users: CollabUser[]) => {
      setPresence(users);
    });

    socket.on("pending_approvals", (approvals: ToolApprovalRequest[]) => {
      setPendingApprovals(approvals);
    });

    socket.on("approval_requested", (req: ToolApprovalRequest) => {
      setPendingApprovals((prev) => [...prev.filter((a) => a.id !== req.id), req]);
    });

    socket.on("approval_response", (res: { requestId: string; approved: boolean }) => {
      setPendingApprovals((prev) => prev.filter((a) => a.id !== res.requestId));
      const resolver = approvalResolvers.current.get(res.requestId);
      if (resolver) {
        resolver(res.approved);
        approvalResolvers.current.delete(res.requestId);
      }
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
      setConnected(false);
      setPresence([]);
    };
  }, [vin, user]);

  const requestApproval = useCallback(
    (tool: string, description: string, payload: unknown): Promise<boolean> => {
      return new Promise((resolve) => {
        const id = `approval-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        approvalResolvers.current.set(id, resolve);
        socketRef.current?.emit("request_approval", { id, tool, description, payload });
        // Auto-approve after 30s if no response (solo operation)
        setTimeout(() => {
          if (approvalResolvers.current.has(id)) {
            approvalResolvers.current.delete(id);
            resolve(true);
          }
        }, 30000);
      });
    },
    []
  );

  const respondApproval = useCallback((requestId: string, approved: boolean) => {
    socketRef.current?.emit("respond_approval", { requestId, approved });
    setPendingApprovals((prev) => prev.filter((a) => a.id !== requestId));
  }, []);

  const broadcastLog = useCallback((entry: unknown) => {
    socketRef.current?.emit("broadcast_log", entry);
  }, []);

  const broadcastScanProgress = useCallback((data: unknown) => {
    socketRef.current?.emit("scan_progress", data);
  }, []);

  const updateActivity = useCallback((tool?: string) => {
    socketRef.current?.emit("update_activity", { tool });
  }, []);

  return (
    <CollabContext.Provider
      value={{
        connected,
        presence,
        pendingApprovals,
        requestApproval,
        respondApproval,
        broadcastLog,
        broadcastScanProgress,
        updateActivity,
      }}
    >
      {children}
    </CollabContext.Provider>
  );
}
