import { describe, it, expect } from 'vitest';
import {
  exportLogsAsJSON,
  exportLogsAsCSV,
  exportLogsAsHTML,
  generateFilename,
  type VINWriteLogEntry,
} from './logExporter';

const mockLogs: VINWriteLogEntry[] = [
  {
    timestamp: '2026-04-09T10:30:00Z',
    module: 'Body Control Module',
    moduleCode: 'BCM',
    txId: '0x750',
    rxId: '0x758',
    oldVin: 'JTHBP5C1XA5034078',
    newVin: '2B3CJ4DV6AH300549',
    status: 'success',
  },
  {
    timestamp: '2026-04-09T10:31:15Z',
    module: 'RF Hub Module',
    moduleCode: 'RFHUB',
    txId: '0x75F',
    rxId: '0x767',
    oldVin: '2B3CJ4DV6AH300549',
    newVin: '2B3CJ4DV6AH300549',
    status: 'failed',
    error: 'Security access denied (NRC 0x33)',
  },
];

const mockMetadata = {
  sessionId: 'sess-20260409-001',
  operator: 'Tech-001',
  vehicleVin: '2B3CJ4DV6AH300549',
};

describe('logExporter', () => {
  describe('exportLogsAsJSON', () => {
    it('should export logs with metadata as valid JSON', () => {
      const json = exportLogsAsJSON(mockLogs, mockMetadata);
      const parsed = JSON.parse(json);

      expect(parsed.metadata).toBeDefined();
      expect(parsed.metadata.totalEntries).toBe(2);
      expect(parsed.metadata.successCount).toBe(1);
      expect(parsed.metadata.failureCount).toBe(1);
      expect(parsed.metadata.sessionId).toBe('sess-20260409-001');
      expect(parsed.logs).toHaveLength(2);
    });

    it('should include all log entry fields', () => {
      const json = exportLogsAsJSON(mockLogs);
      const parsed = JSON.parse(json);

      const firstLog = parsed.logs[0];
      expect(firstLog.timestamp).toBe('2026-04-09T10:30:00Z');
      expect(firstLog.module).toBe('Body Control Module');
      expect(firstLog.moduleCode).toBe('BCM');
      expect(firstLog.newVin).toBe('2B3CJ4DV6AH300549');
      expect(firstLog.status).toBe('success');
    });

    it('should handle empty logs array', () => {
      const json = exportLogsAsJSON([]);
      const parsed = JSON.parse(json);

      expect(parsed.metadata.totalEntries).toBe(0);
      expect(parsed.metadata.successCount).toBe(0);
      expect(parsed.metadata.failureCount).toBe(0);
      expect(parsed.logs).toHaveLength(0);
    });
  });

  describe('exportLogsAsCSV', () => {
    it('should export logs as valid CSV format', () => {
      const csv = exportLogsAsCSV(mockLogs);

      expect(csv).toContain('Timestamp,Module,Module Code,TX ID,RX ID,Old VIN,New VIN,Status,Error');
      expect(csv).toContain('2026-04-09T10:30:00Z');
      expect(csv).toContain('BCM');
      expect(csv).toContain('2B3CJ4DV6AH300549');
      expect(csv).toContain('SUCCESS');
    });

    it('should include metadata as comments', () => {
      const csv = exportLogsAsCSV(mockLogs, mockMetadata);

      expect(csv).toContain('# Session ID: sess-20260409-001');
      expect(csv).toContain('# Operator: Tech-001');
      expect(csv).toContain('# Vehicle VIN: 2B3CJ4DV6AH300549');
      expect(csv).toContain('# Total Entries: 2');
      expect(csv).toContain('# Success: 1');
      expect(csv).toContain('# Failed: 1');
    });

    it('should properly escape CSV values with commas', () => {
      const logsWithComma: VINWriteLogEntry[] = [
        {
          timestamp: '2026-04-09T10:30:00Z',
          module: 'Module, with comma',
          moduleCode: 'TEST',
          txId: '0x750',
          rxId: '0x758',
          oldVin: 'VIN1',
          newVin: 'VIN2',
          status: 'success',
        },
      ];

      const csv = exportLogsAsCSV(logsWithComma);
      expect(csv).toContain('"Module, with comma"');
    });

    it('should handle errors in CSV export', () => {
      const csv = exportLogsAsCSV(mockLogs);

      expect(csv).toContain('Security access denied (NRC 0x33)');
      expect(csv).toContain('FAILED');
    });
  });

  describe('exportLogsAsHTML', () => {
    it('should export logs as valid HTML', () => {
      const html = exportLogsAsHTML(mockLogs, mockMetadata);

      expect(html).toContain('<!DOCTYPE html>');
      expect(html).toContain('<html>');
      expect(html).toContain('VIN Writing Audit Report');
      expect(html).toContain('</html>');
    });

    it('should include metadata in HTML report', () => {
      const html = exportLogsAsHTML(mockLogs, mockMetadata);

      expect(html).toContain('Session ID: sess-20260409-001');
      expect(html).toContain('Operator: Tech-001');
      expect(html).toContain('Vehicle VIN: 2B3CJ4DV6AH300549');
    });

    it('should include statistics in HTML report', () => {
      const html = exportLogsAsHTML(mockLogs);

      expect(html).toContain('Total Operations');
      expect(html).toContain('Successful');
      expect(html).toContain('Failed');
      expect(html).toContain('>2<'); // 2 total
      expect(html).toContain('>1<'); // 1 success
    });

    it('should format log entries in HTML table', () => {
      const html = exportLogsAsHTML(mockLogs);

      expect(html).toContain('2026-04-09T10:30:00Z');
      expect(html).toContain('Body Control Module');
      expect(html).toContain('2B3CJ4DV6AH300549');
      expect(html).toContain('SUCCESS');
      expect(html).toContain('FAILED');
    });

    it('should apply proper CSS styling', () => {
      const html = exportLogsAsHTML(mockLogs);

      expect(html).toContain('<style>');
      expect(html).toContain('status-success');
      expect(html).toContain('status-failed');
      expect(html).toContain('color: #059669'); // success color
      expect(html).toContain('color: #dc2626'); // failed color
    });
  });

  describe('generateFilename', () => {
    it('should generate JSON filename with timestamp', () => {
      const filename = generateFilename('json');
      expect(filename).toMatch(/^vin-audit-\d{4}-\d{2}-\d{2}\.json$/);
    });

    it('should generate CSV filename with timestamp', () => {
      const filename = generateFilename('csv');
      expect(filename).toMatch(/^vin-audit-\d{4}-\d{2}-\d{2}\.csv$/);
    });

    it('should generate HTML filename with timestamp', () => {
      const filename = generateFilename('html');
      expect(filename).toMatch(/^vin-audit-\d{4}-\d{2}-\d{2}\.html$/);
    });

    it('should include VIN in filename if provided', () => {
      const filename = generateFilename('json', '2B3CJ4DV6AH300549');
      expect(filename).toContain('2B3CJ4DV6AH300549');
      expect(filename).toMatch(/^vin-audit-\d{4}-\d{2}-\d{2}_2B3CJ4DV6AH300549\.json$/);
    });
  });

  describe('metadata calculation', () => {
    it('should correctly count success and failure statuses', () => {
      const logs: VINWriteLogEntry[] = [
        { ...mockLogs[0], status: 'success' },
        { ...mockLogs[1], status: 'failed' },
        { ...mockLogs[0], status: 'success' },
      ];

      const json = exportLogsAsJSON(logs);
      const parsed = JSON.parse(json);

      expect(parsed.metadata.successCount).toBe(2);
      expect(parsed.metadata.failureCount).toBe(1);
      expect(parsed.metadata.totalEntries).toBe(3);
    });

    it('should include exportedAt timestamp in metadata', () => {
      const json = exportLogsAsJSON(mockLogs);
      const parsed = JSON.parse(json);

      expect(parsed.metadata.exportedAt).toBeDefined();
      expect(new Date(parsed.metadata.exportedAt)).toBeInstanceOf(Date);
    });
  });

  describe('edge cases', () => {
    it('should handle logs with missing optional fields', () => {
      const minimalLogs: VINWriteLogEntry[] = [
        {
          timestamp: '2026-04-09T10:30:00Z',
          module: 'BCM',
          moduleCode: 'BCM',
          txId: '0x750',
          rxId: '0x758',
          oldVin: null,
          newVin: '2B3CJ4DV6AH300549',
          status: 'success',
        },
      ];

      const json = exportLogsAsJSON(minimalLogs);
      const csv = exportLogsAsCSV(minimalLogs);
      const html = exportLogsAsHTML(minimalLogs);

      expect(json).toBeDefined();
      expect(csv).toBeDefined();
      expect(html).toBeDefined();
    });

    it('should handle special characters in error messages', () => {
      const logsWithSpecialChars: VINWriteLogEntry[] = [
        {
          ...mockLogs[0],
          error: 'Error with "quotes" and <html> & special chars',
        },
      ];

      const csv = exportLogsAsCSV(logsWithSpecialChars);
      expect(csv).toContain('Error with "quotes" and <html> & special chars');
    });

    it('should handle very long VIN strings gracefully', () => {
      const longVin = 'A'.repeat(100);
      const logs: VINWriteLogEntry[] = [
        {
          ...mockLogs[0],
          newVin: longVin,
        },
      ];

      const json = exportLogsAsJSON(logs);
      const parsed = JSON.parse(json);
      expect(parsed.logs[0].newVin).toBe(longVin);
    });
  });
});
