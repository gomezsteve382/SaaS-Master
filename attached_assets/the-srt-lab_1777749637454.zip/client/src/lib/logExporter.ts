/**
 * Log Exporter Utility
 * 
 * Exports VIN writing logs in multiple formats for auditing purposes:
 * - JSON: Full structured data with metadata
 * - CSV: Spreadsheet-friendly format for analysis
 * - PDF: Formatted report for archival
 */

export interface VINWriteLogEntry {
  timestamp: string;
  module: string;
  moduleCode: string;
  txId: string;
  rxId: string;
  oldVin: string | null;
  newVin: string;
  status: 'success' | 'failed' | 'pending';
  error?: string;
  udsSequence?: string[];
}

export interface LogExportMetadata {
  exportedAt: string;
  sessionId?: string;
  operator?: string;
  vehicleVin?: string;
  totalEntries: number;
  successCount: number;
  failureCount: number;
}

/**
 * Export logs as JSON with full metadata
 */
export function exportLogsAsJSON(
  logs: VINWriteLogEntry[],
  metadata?: Partial<LogExportMetadata>
): string {
  const fullMetadata: LogExportMetadata = {
    exportedAt: new Date().toISOString(),
    totalEntries: logs.length,
    successCount: logs.filter(l => l.status === 'success').length,
    failureCount: logs.filter(l => l.status === 'failed').length,
    ...metadata,
  };

  const exportData = {
    metadata: fullMetadata,
    logs,
  };

  return JSON.stringify(exportData, null, 2);
}

/**
 * Export logs as CSV for spreadsheet analysis
 */
export function exportLogsAsCSV(
  logs: VINWriteLogEntry[],
  metadata?: Partial<LogExportMetadata>
): string {
  const headers = [
    'Timestamp',
    'Module',
    'Module Code',
    'TX ID',
    'RX ID',
    'Old VIN',
    'New VIN',
    'Status',
    'Error',
  ];

  const rows = logs.map(log => [
    log.timestamp,
    log.module,
    log.moduleCode,
    log.txId,
    log.rxId,
    log.oldVin || '',
    log.newVin,
    log.status.toUpperCase(),
    log.error || '',
  ]);

  // Escape CSV values
  const escapedRows = rows.map(row =>
    row.map(cell => {
      const str = String(cell);
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    })
  );

  const csv = [headers, ...escapedRows].map(row => row.join(',')).join('\n');

  // Add metadata as comments at the top
  let output = '';
  if (metadata) {
    output += `# Exported: ${metadata.exportedAt || new Date().toISOString()}\n`;
    if (metadata.sessionId) output += `# Session ID: ${metadata.sessionId}\n`;
    if (metadata.operator) output += `# Operator: ${metadata.operator}\n`;
    if (metadata.vehicleVin) output += `# Vehicle VIN: ${metadata.vehicleVin}\n`;
    output += `# Total Entries: ${logs.length}\n`;
    output += `# Success: ${logs.filter(l => l.status === 'success').length}\n`;
    output += `# Failed: ${logs.filter(l => l.status === 'failed').length}\n`;
    output += '\n';
  }

  return output + csv;
}

/**
 * Export logs as HTML table (for PDF conversion or display)
 */
export function exportLogsAsHTML(
  logs: VINWriteLogEntry[],
  metadata?: Partial<LogExportMetadata>
): string {
  const successCount = logs.filter(l => l.status === 'success').length;
  const failureCount = logs.filter(l => l.status === 'failed').length;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>VIN Writing Audit Report</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      margin: 20px;
      background: #f5f5f5;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    h1 {
      color: #1a1a1a;
      border-bottom: 3px solid #dc2626;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }
    .metadata {
      background: #f9fafb;
      border-left: 4px solid #dc2626;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 4px;
    }
    .metadata-row {
      display: flex;
      justify-content: space-between;
      margin: 8px 0;
      font-size: 14px;
    }
    .metadata-label {
      font-weight: 600;
      color: #374151;
      min-width: 150px;
    }
    .stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
      margin-bottom: 20px;
    }
    .stat-card {
      background: #f3f4f6;
      padding: 15px;
      border-radius: 6px;
      text-align: center;
      border-top: 3px solid #dc2626;
    }
    .stat-value {
      font-size: 28px;
      font-weight: 700;
      color: #1a1a1a;
      margin: 5px 0;
    }
    .stat-label {
      font-size: 12px;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      font-size: 13px;
    }
    thead {
      background: #1a1a1a;
      color: white;
    }
    th {
      padding: 12px;
      text-align: left;
      font-weight: 600;
      border: 1px solid #e5e7eb;
    }
    td {
      padding: 10px 12px;
      border: 1px solid #e5e7eb;
    }
    tbody tr:nth-child(even) {
      background: #f9fafb;
    }
    tbody tr:hover {
      background: #f3f4f6;
    }
    .status-success {
      color: #059669;
      font-weight: 600;
    }
    .status-failed {
      color: #dc2626;
      font-weight: 600;
    }
    .status-pending {
      color: #f59e0b;
      font-weight: 600;
    }
    .error-text {
      color: #7f1d1d;
      font-size: 12px;
      max-width: 300px;
      word-break: break-word;
    }
    .footer {
      margin-top: 30px;
      padding-top: 15px;
      border-top: 1px solid #e5e7eb;
      font-size: 12px;
      color: #6b7280;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>VIN Writing Audit Report</h1>
    
    <div class="metadata">
      <div class="metadata-row">
        <span class="metadata-label">Exported:</span>
        <span>${metadata?.exportedAt || new Date().toISOString()}</span>
      </div>
      ${metadata?.sessionId ? `<div class="metadata-row"><span class="metadata-label">Session ID:</span><span>${metadata.sessionId}</span></div>` : ''}
      ${metadata?.operator ? `<div class="metadata-row"><span class="metadata-label">Operator:</span><span>${metadata.operator}</span></div>` : ''}
      ${metadata?.vehicleVin ? `<div class="metadata-row"><span class="metadata-label">Vehicle VIN:</span><span>${metadata.vehicleVin}</span></div>` : ''}
    </div>

    <div class="stats">
      <div class="stat-card">
        <div class="stat-label">Total Operations</div>
        <div class="stat-value">${logs.length}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Successful</div>
        <div class="stat-value" style="color: #059669;">${successCount}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Failed</div>
        <div class="stat-value" style="color: #dc2626;">${failureCount}</div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>Timestamp</th>
          <th>Module</th>
          <th>Code</th>
          <th>Old VIN</th>
          <th>New VIN</th>
          <th>Status</th>
          <th>Error</th>
        </tr>
      </thead>
      <tbody>
        ${logs.map(log => `
          <tr>
            <td>${log.timestamp}</td>
            <td>${log.module}</td>
            <td>${log.moduleCode}</td>
            <td>${log.oldVin || '—'}</td>
            <td><strong>${log.newVin}</strong></td>
            <td><span class="status-${log.status}">${log.status.toUpperCase()}</span></td>
            <td class="error-text">${log.error || '—'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="footer">
      <p>This report was automatically generated by SRT Lab VIN Writing Audit System.</p>
      <p>For compliance and auditing purposes only. Treat as confidential.</p>
    </div>
  </div>
</body>
</html>
  `.trim();

  return html;
}

/**
 * Download file to user's computer
 */
export function downloadFile(content: string, filename: string, mimeType: string = 'text/plain'): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Generate filename with timestamp
 */
export function generateFilename(format: 'json' | 'csv' | 'html' | 'pdf', vehicleVin?: string): string {
  const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const vin = vehicleVin ? `_${vehicleVin}` : '';
  const ext = format === 'html' ? 'html' : format;
  return `vin-audit-${timestamp}${vin}.${ext}`;
}

/**
 * Export and download logs in specified format
 */
export function exportAndDownload(
  logs: VINWriteLogEntry[],
  format: 'json' | 'csv' | 'html',
  metadata?: Partial<LogExportMetadata>
): void {
  let content: string;
  let mimeType: string;
  let filename: string;

  switch (format) {
    case 'json':
      content = exportLogsAsJSON(logs, metadata);
      mimeType = 'application/json';
      break;
    case 'csv':
      content = exportLogsAsCSV(logs, metadata);
      mimeType = 'text/csv';
      break;
    case 'html':
      content = exportLogsAsHTML(logs, metadata);
      mimeType = 'text/html';
      break;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }

  filename = generateFilename(format, metadata?.vehicleVin);
  downloadFile(content, filename, mimeType);
}
