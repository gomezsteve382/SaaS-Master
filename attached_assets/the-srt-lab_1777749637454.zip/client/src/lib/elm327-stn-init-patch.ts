/**
 * ELM327 + STN Initialization Patch
 * 
 * Replaces the existing ELM327Protocol.initialize() method with the
 * AlphaOBD-style STN initialization sequence that properly configures
 * OBDLink EX/MX+ adapters for FCA/Stellantis diagnostic work.
 * 
 * INSTALLATION:
 *   In shared/obd2-protocol.ts, replace the existing `private async initialize()`
 *   method (around line 905) with this version.
 * 
 * What this adds over the original:
 *   1. STN device detection (STDI) — identifies OBDLink adapters
 *   2. Programmable Parameter 0x2C = 0x81 — enables MFG extended mode
 *   3. Programmable Parameter 0x2D = 0x01 — enables CAN protocol options
 *   4. Proper ATZ reset AFTER PP configuration (AlphaOBD order)
 *   5. ATCFC1 — CAN flow control ON (lets adapter handle ISO-TP automatically)
 *   6. STP60/STP61 — OBDLink-specific CAN bus switching (HS-CAN / MS-CAN)
 *   7. TesterPresent keepalive configuration
 * 
 * This matches the exact initialization sequence captured from AlphaOBD 2.5.7.0
 * communicating with an OBDLink EX r2.1 adapter.
 */

// ── Drop-in replacement for ELM327Protocol.initialize() ──
// Copy this into shared/obd2-protocol.ts replacing the existing initialize() method

/*
  private isSTN = false;
  private adapterName = '';

  private async initialize(): Promise<void> {
    // ── Phase 1: Detect adapter type ──
    // Reset first to clear any previous state
    const resetResp = await this.sendCommand('ATZ');
    await this.delay(1000);
    
    // Identify adapter
    const idResp = await this.sendCommand('ATI');
    this.adapterName = idResp;
    console.log(`[ELM327] Adapter: ${idResp}`);

    // Check for STN/OBDLink (supports extended commands)
    this.isSTN = false;
    try {
      const stnResp = await this.sendCommand('STDI');
      if (stnResp && !stnResp.includes('?') && !stnResp.includes('ERROR')) {
        this.isSTN = true;
        console.log(`[ELM327] STN adapter detected: ${stnResp}`);
      }
    } catch {
      // Not an STN adapter — that's fine, standard ELM327 commands only
    }

    // ── Phase 2: AlphaOBD STN configuration ──
    // These programmable parameters configure OBDLink adapters for
    // FCA/Stellantis extended diagnostic mode
    if (this.isSTN) {
      try {
        // PP 0x2C = 0x81: MFG extended mode (enables STN-specific features)
        // This is what AlphaOBD sends: ATPP2CSV81 + ATPP2CON
        await this.sendCommand('ATPP2CSV81');
        await this.sendCommand('ATPP2CON');
        
        // PP 0x2D = 0x01: CAN protocol options
        // AlphaOBD sends: ATPP2DSV01 + ATPP2DON
        await this.sendCommand('ATPP2DSV01');
        await this.sendCommand('ATPP2DON');
        
        console.log('[ELM327] STN programmable parameters configured (AlphaOBD mode)');
        
        // Reset after PP changes to apply them (AlphaOBD does this)
        await this.sendCommand('ATZ');
        await this.delay(1000);
      } catch (e) {
        console.log('[ELM327] STN PP configuration failed (non-critical):', e);
      }
    }

    // ── Phase 3: Standard ELM327 initialization ──
    await this.sendCommand('ATE0');     // Echo off
    await this.sendCommand('ATL0');     // Linefeeds off
    await this.sendCommand('ATS1');     // Spaces ON — required for response parsing
    await this.sendCommand('ATH1');     // Headers ON — show CAN IDs in response
    await this.sendCommand('ATSP6');    // Protocol 6 = ISO 15765-4 CAN (11-bit, 500 kbps)
    await this.sendCommand('ATAT1');    // Adaptive timing auto
    await this.sendCommand('ATST64');   // Timeout = 100 × 4ms = 400ms
    await this.sendCommand('ATCAF0');   // CAN Auto Formatting OFF — we handle ISO-TP manually

    // ── Phase 4: OBDLink-specific CAN bus config ──
    if (this.isSTN) {
      try {
        // Enable CAN flow control (adapter handles FC frames automatically)
        // This is critical for multi-frame responses (VIN, DIDs, etc.)
        await this.sendCommand('ATCFC1');

        // Try OBDLink CAN-C mode (HS-CAN, pins 6/14, 500kbps)
        // STP60 = CAN-C channel — standard HS-CAN for most FCA modules
        const stpResp = await this.sendCommand('STP60');
        if (stpResp && !stpResp.includes('?')) {
          console.log('[ELM327] STP60 OK — OBDLink HS-CAN (pins 6/14, 500kbps)');
        }

        // Set OBDLink-specific timing for FCA modules
        // STPTO = Set Protocol Timeout (ms) — longer timeout for slow ECUs
        await this.sendCommand('STPTO 1000');
      } catch {
        console.log('[ELM327] STN extended config not fully supported');
      }
    }

    console.log(`[ELM327] Initialized: ${this.isSTN ? 'OBDLink/STN' : 'Standard ELM327'} | CAN 500kbps | Headers ON | CAF OFF`);
  }
*/

// ════════════════════════════════════════════════════════════════
// COMPLETE DIFF — exact lines to change in shared/obd2-protocol.ts
// ════════════════════════════════════════════════════════════════

export const ELM327_INIT_PATCH = {
  file: 'shared/obd2-protocol.ts',
  
  description: 'Replace initialize() method with AlphaOBD-style STN initialization',

  // Add these two properties to the ELM327Protocol class (around line 737):
  addProperties: `
  private isSTN = false;
  private adapterName = '';
`,

  // Replace the initialize() method (lines ~905-915) with:
  oldInitialize: `
  private async initialize(): Promise<void> {
    await this.sendCommand('ATZ');      // Reset ELM327
    await this.delay(1000);
    await this.sendCommand('ATE0');     // Echo off
    await this.sendCommand('ATL0');     // Linefeeds off
    await this.sendCommand('ATS1');     // Spaces ON - required for response parsing!
    await this.sendCommand('ATH1');     // Headers on (show CAN IDs in response)
    await this.sendCommand('ATSP6');    // Protocol 6 = ISO 15765-4 CAN (11 bit, 500 kbps)
    await this.sendCommand('ATAT1');    // Adaptive timing auto
    await this.sendCommand('ATST64');   // Set timeout to 100 * 4ms = 400ms
    await this.sendCommand('ATCAF0');   // CAN Auto Formatting OFF - we handle ISO-TP framing manually
    console.log('ELM327 initialized: Protocol 6 (CAN 500kbps), Spaces ON, Headers ON, CAF OFF');
  }`,

  newInitialize: `
  private async initialize(): Promise<void> {
    // Phase 1: Reset and detect adapter
    const resetResp = await this.sendCommand('ATZ');
    await this.delay(1000);
    
    const idResp = await this.sendCommand('ATI');
    this.adapterName = idResp;
    console.log('[ELM327] Adapter:', idResp);

    // Detect STN/OBDLink (STDI = STN Device Identification)
    this.isSTN = false;
    try {
      const stnResp = await this.sendCommand('STDI');
      if (stnResp && !stnResp.includes('?') && !stnResp.includes('ERROR')) {
        this.isSTN = true;
        console.log('[ELM327] STN/OBDLink detected:', stnResp);
      }
    } catch { /* standard ELM327, no STN support */ }

    // Phase 2: AlphaOBD STN programmable parameters
    if (this.isSTN) {
      try {
        await this.sendCommand('ATPP2CSV81');  // PP 0x2C = 0x81 (MFG extended mode)
        await this.sendCommand('ATPP2CON');    // Activate PP 0x2C
        await this.sendCommand('ATPP2DSV01');  // PP 0x2D = 0x01 (CAN protocol options)
        await this.sendCommand('ATPP2DON');    // Activate PP 0x2D
        console.log('[ELM327] STN programmable parameters set (AlphaOBD mode)');
        await this.sendCommand('ATZ');         // Reset to apply PP changes
        await this.delay(1000);
      } catch (e) {
        console.log('[ELM327] STN PP config failed (non-critical):', e);
      }
    }

    // Phase 3: Standard ELM327 initialization
    await this.sendCommand('ATE0');     // Echo off
    await this.sendCommand('ATL0');     // Linefeeds off
    await this.sendCommand('ATS1');     // Spaces ON
    await this.sendCommand('ATH1');     // Headers ON
    await this.sendCommand('ATSP6');    // ISO 15765-4 CAN 500kbps 11-bit
    await this.sendCommand('ATAT1');    // Adaptive timing auto
    await this.sendCommand('ATST64');   // Timeout 400ms
    await this.sendCommand('ATCAF0');   // CAN Auto Formatting OFF

    // Phase 4: OBDLink CAN bus configuration
    if (this.isSTN) {
      try {
        await this.sendCommand('ATCFC1');      // CAN flow control ON
        const stpResp = await this.sendCommand('STP60'); // HS-CAN pins 6/14
        if (stpResp && !stpResp.includes('?')) {
          console.log('[ELM327] STP60 OK — HS-CAN (pins 6/14, 500kbps)');
        }
        await this.sendCommand('STPTO 1000');  // Protocol timeout 1000ms
      } catch {
        console.log('[ELM327] STN extended config partial');
      }
    }

    console.log('[ELM327] Init complete:', this.isSTN ? 'OBDLink/STN + AlphaOBD PP' : 'Standard ELM327');
  }`,

  // Also add this method for switching to MS-CAN (IHS-CAN) for body modules:
  addMethod: `
  async switchToMSCAN(): Promise<boolean> {
    if (!this.isSTN) {
      console.log('[ELM327] MS-CAN switching requires OBDLink/STN adapter');
      return false;
    }
    try {
      const resp = await this.sendCommand('STP61'); // CAN-IHS 125kbps pins 3/11
      if (resp && !resp.includes('?')) {
        console.log('[ELM327] STP61 OK — MS-CAN (pins 3/11, 125kbps)');
        return true;
      }
    } catch {}
    return false;
  }

  async switchToHSCAN(): Promise<boolean> {
    if (!this.isSTN) return true; // Standard ELM327 is always HS-CAN
    try {
      const resp = await this.sendCommand('STP60');
      if (resp && !resp.includes('?')) {
        console.log('[ELM327] STP60 OK — HS-CAN (pins 6/14, 500kbps)');
        return true;
      }
    } catch {}
    return false;
  }

  getAdapterInfo(): { name: string; isSTN: boolean } {
    return { name: this.adapterName, isSTN: this.isSTN };
  }
`,
};
