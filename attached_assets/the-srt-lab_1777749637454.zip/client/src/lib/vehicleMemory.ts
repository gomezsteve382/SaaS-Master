/**
 * Vehicle Memory System — per-VIN persistent context
 * Adapted from Claude Code's memdir/memory system.
 * Stores per-vehicle context that persists across sessions:
 * - Known issues and quirks
 * - Previous DTC history
 * - BCM config snapshots
 * - Technician notes
 * - Module manifest (what was found last scan)
 * - Security algorithm overrides
 */

export interface VehicleNote {
  id: string;
  timestamp: number;
  author: string;
  text: string;
  category: "issue" | "fix" | "note" | "warning";
}

export interface ModuleMemory {
  txId: number;
  rxId: number;
  label: string;
  lastSeen: number;
  partNumber?: string;
  serialNumber?: string;
  supplierCode?: string;
  hwVersion?: string;
  lastVin?: string;
  securityAlgoOverride?: string;
}

export interface VehicleMemory {
  vin: string;
  year?: number;
  make?: string;
  model?: string;
  platform?: string;
  trim?: string;
  engine?: string;
  color?: string;
  mileage?: number;
  lastSeen: number;
  createdAt: number;
  notes: VehicleNote[];
  knownModules: ModuleMemory[];
  dtcHistory: { code: string; description: string; timestamp: number; cleared: boolean }[];
  bcmSnapshots: { timestamp: number; label: string; params: Record<string, string> }[];
  pluginId?: string;
  tags: string[];
}

const STORAGE_KEY = "srtlab_vehicle_memory";
const MAX_VEHICLES = 100;

class VehicleMemoryStore {
  private cache: Map<string, VehicleMemory> = new Map();
  private loaded = false;

  private load(): void {
    if (this.loaded) return;
    this.loaded = true;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data: VehicleMemory[] = JSON.parse(raw);
        data.forEach((v) => this.cache.set(v.vin, v));
      }
    } catch { /* ignore */ }
  }

  private save(): void {
    try {
      const data = Array.from(this.cache.values())
        .sort((a, b) => b.lastSeen - a.lastSeen)
        .slice(0, MAX_VEHICLES);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch { /* ignore */ }
  }

  get(vin: string): VehicleMemory | undefined {
    this.load();
    return this.cache.get(vin);
  }

  getAll(): VehicleMemory[] {
    this.load();
    return Array.from(this.cache.values()).sort((a, b) => b.lastSeen - a.lastSeen);
  }

  upsert(vin: string, updates: Partial<VehicleMemory>): VehicleMemory {
    this.load();
    const existing = this.cache.get(vin);
    const now = Date.now();
    const memory: VehicleMemory = {
      vin,
      createdAt: existing?.createdAt ?? now,
      notes: existing?.notes ?? [],
      knownModules: existing?.knownModules ?? [],
      dtcHistory: existing?.dtcHistory ?? [],
      bcmSnapshots: existing?.bcmSnapshots ?? [],
      tags: existing?.tags ?? [],
      ...existing,
      ...updates,
      lastSeen: now,
    };
    this.cache.set(vin, memory);
    this.save();
    return memory;
  }

  addNote(vin: string, note: Omit<VehicleNote, "id" | "timestamp">): void {
    this.load();
    const memory = this.get(vin) ?? this.upsert(vin, {});
    memory.notes.push({
      id: `note_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: Date.now(),
      ...note,
    });
    memory.lastSeen = Date.now();
    this.cache.set(vin, memory);
    this.save();
  }

  updateModules(vin: string, modules: ModuleMemory[]): void {
    this.load();
    const memory = this.get(vin) ?? this.upsert(vin, {});
    // Merge — update existing by txId, add new ones
    const byTx = new Map(memory.knownModules.map((m) => [m.txId, m]));
    modules.forEach((m) => byTx.set(m.txId, { ...byTx.get(m.txId), ...m }));
    memory.knownModules = Array.from(byTx.values());
    memory.lastSeen = Date.now();
    this.cache.set(vin, memory);
    this.save();
  }

  addDTCs(vin: string, dtcs: { code: string; description: string }[]): void {
    this.load();
    const memory = this.get(vin) ?? this.upsert(vin, {});
    const now = Date.now();
    dtcs.forEach((dtc) => {
      // Don't duplicate — check if same code was added in last 24h
      const recent = memory.dtcHistory.find(
        (d) => d.code === dtc.code && !d.cleared && now - d.timestamp < 86400000
      );
      if (!recent) {
        memory.dtcHistory.push({ ...dtc, timestamp: now, cleared: false });
      }
    });
    // Keep last 500 DTCs
    memory.dtcHistory = memory.dtcHistory.slice(-500);
    memory.lastSeen = now;
    this.cache.set(vin, memory);
    this.save();
  }

  clearDTCs(vin: string): void {
    this.load();
    const memory = this.get(vin);
    if (!memory) return;
    memory.dtcHistory = memory.dtcHistory.map((d) => ({ ...d, cleared: true }));
    memory.lastSeen = Date.now();
    this.cache.set(vin, memory);
    this.save();
  }

  saveBCMSnapshot(vin: string, label: string, params: Record<string, string>): void {
    this.load();
    const memory = this.get(vin) ?? this.upsert(vin, {});
    memory.bcmSnapshots.push({ timestamp: Date.now(), label, params });
    // Keep last 20 snapshots
    memory.bcmSnapshots = memory.bcmSnapshots.slice(-20);
    memory.lastSeen = Date.now();
    this.cache.set(vin, memory);
    this.save();
  }

  delete(vin: string): void {
    this.load();
    this.cache.delete(vin);
    this.save();
  }
}

export const vehicleMemory = new VehicleMemoryStore();
