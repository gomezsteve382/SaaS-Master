/**
 * Full-Text Search Engine — adapted from Claude Code's client-search.ts
 * Token-based scoring with word boundary bonuses, frequency bonuses, and
 * partial match penalties. Used for DTC, BCM parameters, and AlphaOBD tables.
 */

export interface SearchableRecord {
  id: string | number;
  [key: string]: unknown;
}

export interface SearchResult<T extends SearchableRecord> {
  record: T;
  score: number;
  matchedFields: string[];
  excerpts: Record<string, string>;
}

export interface SearchOptions {
  fields: string[];           // Which fields to search
  weights?: Record<string, number>; // Field importance multipliers
  limit?: number;
  minScore?: number;
}

// Tokenize a query into lowercase search tokens
export function tokenize(query: string): string[] {
  return query
    .toLowerCase()
    .split(/[\s,;|]+/)
    .map((t) => t.trim())
    .filter((t) => t.length >= 2);
}

// Score a text against a set of query tokens
function scoreText(text: string, tokens: string[], weight = 1): number {
  if (!text || tokens.length === 0) return 0;
  const lower = text.toLowerCase();
  let score = 0;

  for (const token of tokens) {
    const idx = lower.indexOf(token);
    if (idx === -1) continue;

    // Base score per token match
    score += 1 * weight;

    // Bonus for word boundary match
    const before = idx === 0 || /\W/.test(lower[idx - 1]);
    const after =
      idx + token.length >= lower.length ||
      /\W/.test(lower[idx + token.length]);
    if (before && after) score += 0.5 * weight;

    // Bonus for more occurrences (capped at 3)
    const occurrences = (
      lower.match(
        new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")
      ) ?? []
    ).length;
    score += Math.min(occurrences - 1, 3) * 0.2 * weight;

    // Bonus for exact full-field match
    if (lower === token) score += 2 * weight;
  }

  // Penalty if not all tokens match
  const matchedTokens = tokens.filter((t) => lower.includes(t));
  if (matchedTokens.length < tokens.length) {
    score *= matchedTokens.length / tokens.length;
  }

  return score;
}

// Extract a short excerpt around the first match
function extractExcerpt(text: string, tokens: string[], maxLen = 120): string {
  if (!text) return "";
  const lower = text.toLowerCase();
  let firstIdx = -1;
  for (const token of tokens) {
    const idx = lower.indexOf(token);
    if (idx !== -1 && (firstIdx === -1 || idx < firstIdx)) {
      firstIdx = idx;
    }
  }
  if (firstIdx === -1) return text.slice(0, maxLen);
  const start = Math.max(0, firstIdx - 20);
  const end = Math.min(text.length, start + maxLen);
  const excerpt = text.slice(start, end);
  return (start > 0 ? "…" : "") + excerpt + (end < text.length ? "…" : "");
}

// Highlight matched tokens in an excerpt with <mark> tags
export function highlightExcerpt(text: string, tokens: string[]): string {
  if (!text || tokens.length === 0) return text;
  let result = text;
  for (const token of tokens) {
    const regex = new RegExp(
      `(${token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`,
      "gi"
    );
    result = result.replace(regex, "<mark>$1</mark>");
  }
  return result;
}

/**
 * Run a scored full-text search over an array of records.
 * Returns results sorted by relevance (highest score first).
 */
export function searchRecords<T extends SearchableRecord>(
  records: T[],
  query: string,
  options: SearchOptions
): SearchResult<T>[] {
  const tokens = tokenize(query);
  if (tokens.length === 0) return [];

  const { fields, weights = {}, limit = 100, minScore = 0.1 } = options;
  const results: SearchResult<T>[] = [];

  for (const record of records) {
    let totalScore = 0;
    const matchedFields: string[] = [];
    const excerpts: Record<string, string> = {};

    for (const field of fields) {
      const value = record[field];
      if (value == null) continue;
      const text = String(value);
      const weight = weights[field] ?? 1;
      const fieldScore = scoreText(text, tokens, weight);

      if (fieldScore > 0) {
        totalScore += fieldScore;
        matchedFields.push(field);
        excerpts[field] = extractExcerpt(text, tokens);
      }
    }

    if (totalScore >= minScore) {
      results.push({ record, score: totalScore, matchedFields, excerpts });
    }
  }

  return results
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/**
 * Quick DTC search — searches code, description, and module fields
 */
export interface DTCRecord extends SearchableRecord {
  code: string;
  description: string;
  module?: string;
  severity?: string;
}

export function searchDTCs(records: DTCRecord[], query: string, limit = 50): SearchResult<DTCRecord>[] {
  return searchRecords(records, query, {
    fields: ["code", "description", "module", "severity"],
    weights: { code: 3, description: 1.5, module: 1, severity: 0.5 },
    limit,
  });
}

/**
 * Quick BCM parameter search
 */
export interface BCMParamRecord extends SearchableRecord {
  name: string;
  description?: string;
  category?: string;
  did?: string;
}

export function searchBCMParams(records: BCMParamRecord[], query: string, limit = 100): SearchResult<BCMParamRecord>[] {
  return searchRecords(records, query, {
    fields: ["name", "description", "category", "did"],
    weights: { name: 3, description: 1.5, category: 1, did: 2 },
    limit,
  });
}

/**
 * Quick AlphaOBD parameter search across all tables
 */
export interface AlphaOBDRecord extends SearchableRecord {
  name: string;
  description?: string;
  table_name?: string;
  ecu?: string;
  unit?: string;
}

export function searchAlphaOBD(records: AlphaOBDRecord[], query: string, limit = 200): SearchResult<AlphaOBDRecord>[] {
  return searchRecords(records, query, {
    fields: ["name", "description", "table_name", "ecu", "unit"],
    weights: { name: 3, description: 1.5, table_name: 1, ecu: 1, unit: 0.5 },
    limit,
  });
}
