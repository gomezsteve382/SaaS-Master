/**
 * Plugin System — vehicle platform packs
 * Adapted from Claude Code's tool plugin architecture.
 * Each plugin pack adds platform-specific module addresses, DID maps,
 * BCM parameter sets, and known quirks for a specific FCA/Stellantis platform.
 */

export interface ModuleOverride {
  txId: number;
  rxId: number;
  label: string;
  securityAlgo?: string;
  eepromSize?: number;
  vinOffset?: number;
  notes?: string;
}

export interface PlatformPlugin {
  id: string;
  name: string;
  description: string;
  platforms: string[];
  years: string;
  category: "muscle" | "truck" | "suv" | "sedan" | "ev";
  version: string;
  moduleOverrides: ModuleOverride[];
  knownDTCs: { code: string; description: string; severity: "info" | "warning" | "critical" }[];
  bcmPresets: { name: string; params: Record<string, string> }[];
  notes: string[];
}

// ─── Built-in platform packs ──────────────────────────────────────────────────

export const PLATFORM_PLUGINS: PlatformPlugin[] = [
  {
    id: "challenger-srt",
    name: "Challenger SRT / Hellcat / Demon",
    description: "Dodge Challenger SRT8, SRT392, Hellcat, Redeye, Demon, Jailbreak — all variants",
    platforms: ["LC", "LD"],
    years: "2008–2023",
    category: "muscle",
    version: "1.0.0",
    moduleOverrides: [
      { txId: 0x7E0, rxId: 0x7E8, label: "PCM (SRT)", securityAlgo: "NGC4", notes: "Hellcat uses extended 0x02 session for SRT params" },
      { txId: 0x7B0, rxId: 0x7B8, label: "BCM (SRT)", securityAlgo: "CDA6_L4" },
      { txId: 0x6E0, rxId: 0x6E8, label: "Active Exhaust (SRT)", notes: "Hellcat/Demon only — controls valve timing" },
      { txId: 0x6F0, rxId: 0x6F8, label: "Launch Control (Demon)", notes: "Demon/Jailbreak only" },
    ],
    knownDTCs: [
      { code: "P0340", description: "Camshaft Position Sensor A Circuit (Bank 1)", severity: "critical" },
      { code: "P0128", description: "Coolant Temperature Below Thermostat Regulating Temperature", severity: "warning" },
      { code: "P0562", description: "System Voltage Low — check alternator on Hellcat", severity: "critical" },
      { code: "P0420", description: "Catalyst System Efficiency Below Threshold (Bank 1)", severity: "warning" },
      { code: "U0100", description: "Lost Communication with ECM/PCM — check CAN bus", severity: "critical" },
    ],
    bcmPresets: [
      {
        name: "SRT Track Mode",
        params: {
          "HORN_CHIRP_ON_LOCK": "DISABLED",
          "PASSIVE_ENTRY": "ENABLED",
          "AUTO_HEADLAMPS": "ENABLED",
          "DAYTIME_RUNNING_LAMPS": "DISABLED",
          "REMOTE_START": "DISABLED",
        },
      },
      {
        name: "Demon Drag Strip",
        params: {
          "TRACTION_CONTROL_DEFAULT": "OFF",
          "STABILITY_CONTROL_DEFAULT": "OFF",
          "LAUNCH_CONTROL": "ENABLED",
          "LINE_LOCK": "ENABLED",
          "TRANS_BRAKE": "ENABLED",
        },
      },
    ],
    notes: [
      "Hellcat (707hp) uses same PCM address as SRT392 but different calibration",
      "Demon requires Demon Crate key fob for full 840hp mode — BCM checks key ID",
      "Jailbreak removes 168mph speed limiter via PCM calibration change",
      "Active exhaust valve position stored in BCM DID 0xFD20",
    ],
  },
  {
    id: "charger-srt",
    name: "Charger SRT / Hellcat / Redeye",
    description: "Dodge Charger SRT8, SRT392, Hellcat, Redeye — LD platform",
    platforms: ["LD"],
    years: "2006–2023",
    category: "sedan",
    version: "1.0.0",
    moduleOverrides: [
      { txId: 0x7E0, rxId: 0x7E8, label: "PCM (SRT)", securityAlgo: "NGC4" },
      { txId: 0x7B0, rxId: 0x7B8, label: "BCM (SRT)", securityAlgo: "CDA6_L4" },
      { txId: 0x720, rxId: 0x728, label: "IPC (SRT)", notes: "SRT cluster has additional DID 0xFD30 for track timer" },
    ],
    knownDTCs: [
      { code: "P0340", description: "Camshaft Position Sensor A Circuit", severity: "critical" },
      { code: "P0700", description: "Transmission Control System MIL Request", severity: "warning" },
    ],
    bcmPresets: [
      {
        name: "SRT Daily Driver",
        params: {
          "HORN_CHIRP_ON_LOCK": "ENABLED",
          "AUTO_HEADLAMPS": "ENABLED",
          "DAYTIME_RUNNING_LAMPS": "ENABLED",
        },
      },
    ],
    notes: [
      "Redeye uses same platform as Hellcat but with upgraded supercharger",
      "4-door Charger uses same BCM address as 2-door Challenger",
    ],
  },
  {
    id: "ram-1500-dt",
    name: "RAM 1500 (DT Platform)",
    description: "RAM 1500 DT platform — 2019+ including TRX and 1500 Classic",
    platforms: ["DT", "DS"],
    years: "2009–2024",
    category: "truck",
    version: "1.0.0",
    moduleOverrides: [
      { txId: 0x7E0, rxId: 0x7E8, label: "PCM (RAM)", securityAlgo: "NGC4" },
      { txId: 0x7B0, rxId: 0x7B8, label: "BCM (RAM)", securityAlgo: "CDA6_L6" },
      { txId: 0x6A0, rxId: 0x6A8, label: "Transfer Case (RAM)", notes: "4WD/AWD variants only" },
      { txId: 0x6D0, rxId: 0x6D8, label: "Air Suspension (RAM)", notes: "Active-Level 4C only" },
    ],
    knownDTCs: [
      { code: "P0456", description: "Evaporative Emission System Leak Detected (Very Small Leak)", severity: "warning" },
      { code: "U0401", description: "Invalid Data Received From ECM/PCM", severity: "warning" },
    ],
    bcmPresets: [
      {
        name: "TRX Off-Road",
        params: {
          "AUTO_HEADLAMPS": "ENABLED",
          "TRACTION_CONTROL_DEFAULT": "OFF",
          "HILL_DESCENT_CONTROL": "ENABLED",
        },
      },
    ],
    notes: [
      "TRX uses Hellcat engine (702hp) with same PCM base as Challenger",
      "Air suspension module requires separate security access sequence",
    ],
  },
  {
    id: "jeep-grand-cherokee-wl",
    name: "Jeep Grand Cherokee (WL/4xe)",
    description: "2021+ Jeep Grand Cherokee WL and 4xe hybrid variants",
    platforms: ["WL"],
    years: "2021–2024",
    category: "suv",
    version: "1.0.0",
    moduleOverrides: [
      { txId: 0x7E0, rxId: 0x7E8, label: "PCM (WL)", securityAlgo: "NGC4" },
      { txId: 0x7B0, rxId: 0x7B8, label: "BCM (WL)", securityAlgo: "CDA6_L6" },
      { txId: 0x640, rxId: 0x648, label: "Battery Charger (4xe)", notes: "4xe hybrid only" },
      { txId: 0x641, rxId: 0x649, label: "Battery Mgmt (4xe)", notes: "4xe hybrid only" },
      { txId: 0x642, rxId: 0x64A, label: "Motor Controller (4xe)", notes: "4xe hybrid only" },
    ],
    knownDTCs: [
      { code: "P0A0F", description: "Drive Motor A Performance", severity: "critical" },
      { code: "P1A00", description: "High Voltage Battery Pack Charge Level", severity: "warning" },
    ],
    bcmPresets: [
      {
        name: "4xe E-Save Mode",
        params: {
          "HYBRID_MODE_DEFAULT": "E_SAVE",
          "REGEN_BRAKING": "MAX",
        },
      },
    ],
    notes: [
      "4xe requires special high-voltage safety procedures before EEPROM work",
      "Battery modules use extended addressing — standard 7-bit CAN IDs may not work",
    ],
  },
  {
    id: "durango-srt",
    name: "Dodge Durango SRT / Hellcat",
    description: "Dodge Durango SRT 392 and Hellcat — WD platform",
    platforms: ["WD"],
    years: "2011–2024",
    category: "suv",
    version: "1.0.0",
    moduleOverrides: [
      { txId: 0x7E0, rxId: 0x7E8, label: "PCM (Durango SRT)", securityAlgo: "NGC4" },
      { txId: 0x7B0, rxId: 0x7B8, label: "BCM (Durango SRT)", securityAlgo: "CDA6_L4" },
    ],
    knownDTCs: [
      { code: "P0340", description: "Camshaft Position Sensor A Circuit", severity: "critical" },
    ],
    bcmPresets: [
      {
        name: "SRT Performance",
        params: {
          "TRACTION_CONTROL_DEFAULT": "OFF",
          "AUTO_HEADLAMPS": "ENABLED",
        },
      },
    ],
    notes: [
      "Durango Hellcat (2021) is the most powerful 3-row SUV ever produced",
      "Same Hellcat PCM as Challenger/Charger — calibration differs by platform code",
    ],
  },
  {
    id: "chrysler-300-lx",
    name: "Chrysler 300 / 300C SRT",
    description: "Chrysler 300 and 300C SRT8 — LX/LD platform",
    platforms: ["LX", "LD"],
    years: "2005–2023",
    category: "sedan",
    version: "1.0.0",
    moduleOverrides: [
      { txId: 0x7E0, rxId: 0x7E8, label: "PCM (300)", securityAlgo: "NGC3" },
      { txId: 0x7B0, rxId: 0x7B8, label: "BCM (300)", securityAlgo: "CDA6_L4" },
    ],
    knownDTCs: [],
    bcmPresets: [],
    notes: [
      "Early LX platform (2005-2010) uses NGC3 security — different from NGC4",
      "300C SRT8 6.4L uses same PCM as Challenger SRT392",
    ],
  },
];

// ─── Plugin registry ──────────────────────────────────────────────────────────

class PluginRegistry {
  private installed: Set<string> = new Set();
  private listeners: ((plugins: PlatformPlugin[]) => void)[] = [];

  getAll(): PlatformPlugin[] {
    return PLATFORM_PLUGINS;
  }

  getInstalled(): PlatformPlugin[] {
    return PLATFORM_PLUGINS.filter((p) => this.installed.has(p.id));
  }

  isInstalled(id: string): boolean {
    return this.installed.has(id);
  }

  install(id: string): void {
    this.installed.add(id);
    this.persist();
    this.notify();
  }

  uninstall(id: string): void {
    this.installed.delete(id);
    this.persist();
    this.notify();
  }

  subscribe(cb: (plugins: PlatformPlugin[]) => void): () => void {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== cb);
    };
  }

  private notify(): void {
    const installed = this.getInstalled();
    this.listeners.forEach((l) => l(installed));
  }

  private persist(): void {
    try {
      localStorage.setItem("srtlab_plugins", JSON.stringify(Array.from(this.installed)));
    } catch { /* ignore */ }
  }

  load(): void {
    try {
      const saved = localStorage.getItem("srtlab_plugins");
      if (saved) {
        const ids: string[] = JSON.parse(saved);
        ids.forEach((id) => this.installed.add(id));
      }
    } catch { /* ignore */ }
  }
}

export const pluginRegistry = new PluginRegistry();

// Load persisted state on module init
if (typeof window !== "undefined") {
  pluginRegistry.load();
}
