/**
 * SSE Streaming hook — adapted from Claude Code's useStream.ts
 * Manages a long-lived Server-Sent Events connection with auto-reconnect.
 * Used to stream live UDS traffic log frames from the server during
 * long-running OBD operations (ECM flash, module clone, BCM write).
 */

import { useRef, useEffect, useCallback } from "react";

export interface SSEStreamOptions {
  enabled?: boolean;
  maxReconnects?: number;
  reconnectDelayMs?: number;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onEvent: (data: unknown) => void;
  onError?: (error: Error) => void;
}

export interface SSEStreamReturn {
  connect: () => void;
  disconnect: () => void;
}

class SSEConnection {
  private es: EventSource | null = null;
  private reconnectCount = 0;
  private disconnected = false;

  constructor(
    private readonly url: string,
    private readonly opts: SSEStreamOptions
  ) {}

  connect(): void {
    if (this.disconnected) return;
    this.es = new EventSource(this.url);

    this.es.onopen = () => {
      this.reconnectCount = 0;
      this.opts.onConnect?.();
    };

    this.es.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        this.opts.onEvent(data);
      } catch {
        this.opts.onEvent(e.data);
      }
    };

    this.es.onerror = () => {
      this.es?.close();
      this.es = null;
      this.opts.onDisconnect?.();

      const maxReconnects = this.opts.maxReconnects ?? 5;
      if (!this.disconnected && this.reconnectCount < maxReconnects) {
        this.reconnectCount++;
        const delay = Math.min(
          (this.opts.reconnectDelayMs ?? 1000) * this.reconnectCount,
          10000
        );
        setTimeout(() => this.connect(), delay);
      } else {
        this.opts.onError?.(new Error("SSE connection failed after max reconnects"));
      }
    };
  }

  disconnect(): void {
    this.disconnected = true;
    this.es?.close();
    this.es = null;
  }
}

/**
 * Hook that manages a long-lived SSE connection.
 * Connection is established when `enabled` is true (default) and url is non-null.
 * Torn down automatically on unmount or when `enabled` becomes false.
 */
export function useSSEStream(
  url: string | null,
  opts: SSEStreamOptions
): SSEStreamReturn {
  const connRef = useRef<SSEConnection | null>(null);
  // Keep callbacks in a ref so connect/disconnect don't re-create on inline arrow functions
  const optsRef = useRef(opts);
  optsRef.current = opts;

  const disconnect = useCallback(() => {
    connRef.current?.disconnect();
    connRef.current = null;
  }, []);

  const connect = useCallback(() => {
    if (!url) return;
    disconnect();
    const conn = new SSEConnection(url, {
      onEvent: (d) => optsRef.current.onEvent(d),
      onError: (e) => optsRef.current.onError?.(e),
      onConnect: () => optsRef.current.onConnect?.(),
      onDisconnect: () => optsRef.current.onDisconnect?.(),
      maxReconnects: optsRef.current.maxReconnects,
      reconnectDelayMs: optsRef.current.reconnectDelayMs,
    });
    conn.connect();
    connRef.current = conn;
  }, [url, disconnect]);

  useEffect(() => {
    if (opts.enabled === false || !url) {
      disconnect();
      return;
    }
    connect();
    return disconnect;
  }, [url, opts.enabled, connect, disconnect]);

  return { connect, disconnect };
}
