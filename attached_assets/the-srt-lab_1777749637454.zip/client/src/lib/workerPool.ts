/**
 * Lightweight Web Worker pool — adapted from Claude Code's worker-pool.ts
 * Keeps a fixed number of workers alive and queues tasks when all are busy.
 * Used for CRC computation, EEPROM parsing, and hex diff on large binary files
 * without blocking the UI thread.
 */

interface WorkerTask<T> {
  payload: unknown;
  resolve: (value: T) => void;
  reject: (reason: unknown) => void;
  transferables?: Transferable[];
}

interface WorkerSlot {
  worker: Worker;
  busy: boolean;
}

export class WorkerPool<T = unknown> {
  private slots: WorkerSlot[] = [];
  private queue: WorkerTask<T>[] = [];
  private readonly size: number;
  private readonly workerFactory: () => Worker;

  constructor(
    workerFactory: () => Worker,
    size = Math.min(navigator.hardwareConcurrency ?? 2, 4)
  ) {
    this.workerFactory = workerFactory;
    this.size = size;
  }

  private createSlot(): WorkerSlot {
    const worker = this.workerFactory();
    return { worker, busy: false };
  }

  private getFreeSlot(): WorkerSlot | null {
    return this.slots.find((s) => !s.busy) ?? null;
  }

  private ensureSlots(): void {
    while (this.slots.length < this.size) {
      this.slots.push(this.createSlot());
    }
  }

  run(payload: unknown, transferables?: Transferable[]): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.ensureSlots();
      const task: WorkerTask<T> = { payload, resolve, reject, transferables };
      const slot = this.getFreeSlot();
      if (slot) {
        this.dispatch(slot, task);
      } else {
        this.queue.push(task);
      }
    });
  }

  private dispatch(slot: WorkerSlot, task: WorkerTask<T>): void {
    slot.busy = true;

    const handleMessage = (e: MessageEvent) => {
      slot.worker.removeEventListener("message", handleMessage);
      slot.worker.removeEventListener("error", handleError);
      slot.busy = false;
      task.resolve(e.data as T);
      this.dequeue();
    };

    const handleError = (e: ErrorEvent) => {
      slot.worker.removeEventListener("message", handleMessage);
      slot.worker.removeEventListener("error", handleError);
      slot.busy = false;
      task.reject(new Error(e.message));
      this.dequeue();
    };

    slot.worker.addEventListener("message", handleMessage);
    slot.worker.addEventListener("error", handleError);

    if (task.transferables?.length) {
      slot.worker.postMessage(task.payload, task.transferables);
    } else {
      slot.worker.postMessage(task.payload);
    }
  }

  private dequeue(): void {
    if (this.queue.length === 0) return;
    const slot = this.getFreeSlot();
    if (!slot) return;
    const task = this.queue.shift()!;
    this.dispatch(slot, task);
  }

  terminate(): void {
    for (const slot of this.slots) {
      slot.worker.terminate();
    }
    this.slots = [];
    this.queue = [];
  }
}

/**
 * CRC Worker message types
 */
export type CRCWorkerRequest =
  | { type: "crc16"; data: Uint8Array; start: number; end: number }
  | { type: "crc32"; data: Uint8Array; start: number; end: number }
  | { type: "hexDiff"; oldData: Uint8Array; newData: Uint8Array }
  | { type: "parseHex"; text: string };

export type CRCWorkerResponse =
  | { type: "crc16"; result: number }
  | { type: "crc32"; result: number }
  | { type: "hexDiff"; changes: Array<{ offset: number; oldVal: number; newVal: number }> }
  | { type: "parseHex"; bytes: Uint8Array; error?: string };
