# The SRT Lab - TODO

## Setup & Infrastructure
- [x] Initialize project with web-db-user scaffold
- [x] Configure dark SRT red industrial theme (CSS variables)
- [x] Set up global layout with sidebar navigation
- [x] Configure routing for all 10 tool pages

## Pages
- [x] Home dashboard with tool grid and stats
- [x] VIN Commander (OBD write + bench EEPROM editor)
- [x] RFHUB Virginizer (bench EEE dump reset)
- [x] Key Programming (FOBIK learn/erase/locate, PIN extraction)
- [x] Module Scanner (CAN bus scan, quick + full sweep)
- [x] DTC Reader (read/clear DTCs, 22,166 AlphaOBD codes)
- [x] EEPROM Viewer (hex viewer with offset highlighting)
- [x] Proxy Alignment (EPS steering angle calibration)
- [x] Seed-Key Calculator (18 algorithms)
- [x] BCM Configuration (4,826+ params, 15 categories, presets)
- [x] AlphaOBD Database Explorer (34,625+ records, 10 tables, CSV export)

## Shared Components
- [x] ConnectionStatusBar (OBD adapter status in sidebar)
- [x] UDS log panel (reusable in Proxy Alignment, RFHUB, VIN Commander)
- [x] Seed-key algorithm engine (client-side, all 18 algorithms)
- [x] SRT badges and jailbreak badge CSS classes

## Tests
- [x] VIN validation unit tests (4 tests)
- [x] Seed-key algorithm unit tests (5 tests)
- [x] RFHUB virginizer logic tests (4 tests)
- [x] Module scanner tests (4 tests)
- [x] DTC severity classification tests (4 tests)
- [x] Auth logout test (1 test)
- [x] All 23 tests passing

## v3.0 Upgrades
- [x] Full DTC database seeding (22,166 codes) into MySQL with tRPC lookup
- [x] DTC Reader live DB lookup — unknown codes matched by pattern with confidence
- [x] Module Scanner DID manifest reads (F101 part#, F18C serial, F187 supplier, F1A0 hw version)
- [x] Session persistence schema — VIN-tied sessions, UDS log storage, before/after comparison
- [x] Session history page — view past sessions by VIN with full UDS audit trail
- [x] Format-specific CRC dispatch engine for bench EEPROM (BCM/RFHUB/ECM/95640)
- [x] BCM Configuration write path — real UDS writeDID + security access unlock per category
- [x] Fuzzy search in AlphaOBD Explorer — cross-table ranked relevance search
- [x] Offline service worker + IndexedDB cache for DTC/BCM/AlphaOBD data
- [x] AlphaOBD full dataset seeded into MySQL (34,625+ records across 10 tables)

## v4.0 Claude Code Integrations
- [x] Worker Pool — CRC/EEPROM computation in parallel Web Workers (no UI freeze)
- [x] Virtual Scroll — UDS traffic log with @tanstack/react-virtual (thousands of frames)
- [x] SSE Streaming — live UDS frames via Server-Sent Events with auto-reconnect
- [x] LCS Diff Viewer — before/after EEPROM byte diff with hunk accept/reject
- [x] Full-Text Search Engine — scored fuzzy search across DTC/BCM/AlphaOBD tables
- [x] Real-Time Collaboration — WebSocket presence, cursors, roles, tool-use approval
- [x] AI Diagnostic Assistant page — chat with tool-use approval for writes
- [x] Filesystem API — direct .bin file read/write from browser (14 routes)
- [x] Server-Side Exec API — stream local OBD bridge / J2534 commands via SSE
- [x] Swarm parallel scanning — parallel agents per address range in Module Scanner
- [x] Plugin marketplace — vehicle-specific plugin packs (Hellcat, Trackhawk, etc.)
- [x] x402 micropayments — USDC per-operation billing for premium ops
- [x] Voice control — hands-free OBD commands via STT
- [x] Memory system — per-vehicle context persistence across sessions

## v4.1 Gateway Cloning
- [x] GatewayCloning page — full UDS EEPROM read (0x23/0x34/0x36/0x37), VIN/secret key patch, CRC recalculation, write-back
- [x] GWAY-specific EEPROM offset map (VIN, secret key, CRC, pairing data)
- [x] Multi-variant support: GWAY (0x760), SGW (0x7D0), CGW (0x7C0), ADAS-GW (0x7A0)
- [x] Back button on GatewayCloning page
- [x] Route /gateway-cloning wired in App.tsx
- [x] Module Cloning page updated to link to Gateway Cloning

## v4.2 ECM Calibration File Manager
- [ ] DB schema: ecm_calibrations table (id, userId, fileName, fileKey, fileUrl, fileSize, checksum, checksumType, moduleType, partNumber, swVersion, hwVersion, platform, notes, createdAt)
- [ ] S3 upload tRPC procedure: upload .bin file, compute CRC-32/CRC-16/MD5, store metadata in DB
- [ ] tRPC procedures: list, getById, delete, getDownloadUrl
- [ ] ECMCalibrationManager page: drag-drop upload zone, file browser table, checksum display
- [ ] Before/after EEPROM diff using EEPROMDiffViewer
- [ ] Flash workflow: security access, requestDownload, transferData, requestTransferExit, ecuReset
- [ ] Route /ecm-calibrations wired in App.tsx
- [ ] Nav item added to sidebar

## v4.3 Snapshot Comparison
- [x] Audit snapshot schema and tRPC procedures
- [x] Add sessions.listAllSnapshots, getSnapshotById, compareSnapshots tRPC procedures
- [x] Add listAllSnapshots, getSnapshotById, getSnapshotsByIds helpers to db.ts
- [x] Build SnapshotComparison page with snapshot picker, field-level diff, stats, export
- [x] Wire /snapshot-comparison route in App.tsx + sidebar nav item (GitCompare icon, indigo)
- [x] 23 tests passing, 0 TypeScript errors

## v4.4 Quick Compare in Session History
- [x] Add getSnapshotPairForSession db helper (smart pair selection: prefers same-module before+after)
- [x] Add sessions.getSnapshotPair tRPC procedure (returns before + after snapshot IDs for a session)
- [x] Add Quick Compare button to each session row in SessionHistory.tsx (indigo, lazy-fetch on click)
- [x] Refactored SessionHistory to use dedicated SessionLogs component (lazy-loaded on expand)
- [x] Update SnapshotComparison.tsx to read ?a=ID&b=ID URL params and auto-load comparison
- [x] Added Quick Compare banner in SnapshotComparison header when pre-loaded from URL
- [x] 4 new URL param parsing tests — 32 tests total passing, 0 TypeScript errors

## v4.5 Multi-Module Quick Compare
- [x] Add getSessionModulePairs db helper (groups rows by moduleAddr, marks hasPair, sorts complete pairs first)
- [x] Add sessions.getSessionModulePairs tRPC procedure
- [x] Build ModulePickerDialog component (complete pairs / partial sections, module addr + name + time badges, Compare button per row)
- [x] Update QuickCompareButton: single pair → navigate directly; multiple pairs → open ModulePickerDialog first
- [x] 5 new multi-module grouping tests — 37 tests total passing, 0 TypeScript errors

## v4.6 Cross-Session Module Compare
- [x] Add getDistinctModules db helper (deduplicates by addr, sorts by snapshotCount desc)
- [x] Add getSnapshotsByModule db helper (joins diagSessions for sessionTool, newest first, VIN filter)
- [x] Add sessions.getDistinctModules and sessions.getSnapshotsByModule tRPC procedures
- [x] Build CrossSessionCompare page (3-column: module list, A picker, B picker; diff table + stats cards; export/copy)
- [x] Wire /cross-session-compare route and sidebar nav entry (teal color)
- [x] 7 new cross-session tests — 44 tests total passing, 0 TypeScript errors

## v4.7 Bench Detector VIN Slot Fix
- [x] Found bug: strict allPrint check (b >= 0x20 && b <= 0x7E) rejected slots with any padding byte, collapsing 4 slots to 1
- [x] Fixed extractVin: accepts slots with ≥14/17 printable bytes, validates against VIN charset (no I/O/Q), rejects all-zero/all-FF blanks
- [x] Added full-file VIN scan fallback: sweeps entire binary for any undiscovered 17-byte VIN-pattern sequences
- [x] 7 new bench detector unit tests — 51 tests total passing, 0 TypeScript errors

## v4.8 Bench Detector VIN Slot Fix (Round 2)
- [x] Root cause: regex with '?' replacement chars caused strict VIN regex to reject all partial slots
- [x] Known-offset slots now ALWAYS shown (no filtering) — display clean VIN (green), partial ASCII with dots (yellow), blank (grey)
- [x] Raw hex bytes shown under every non-blank slot for manual inspection
- [x] Slot count badge added: 'N / M slots' header
- [x] Full-file sweep still uses strict regex (only for extra/unknown offsets)
- [x] 51 tests passing, 0 TypeScript errors

## v4.9 BCM VIN Offsets Fix (Alpha OBD ground truth)
- [x] Replaced wrong BCM offsets (0x1298/0x1320/0x1328/0x52B8) with Alpha-confirmed: 0x12B8, 0x12D8, 0x12F8, 0x1318 (dec 4792/4824/4856/4888, stride=0x20)
- [x] RFHUB offsets 0x0EA5/0x0EB9/0x0ECD/0x0EE1 confirmed correct (stride=0x14)
- [x] Updated unit tests to assert Alpha OBD ground truth offsets and strides
- [x] 51 tests passing, 0 TypeScript errors

## v4.10 BCM VIN Checksum Recalculation (from hex dump analysis)
- [x] Implemented CS = XOR(all 17 VIN bytes) ^ 0x19 in patchBenchVin (writes at offset+17 per slot for BCM)
- [x] Added CS OK (green) / CS FAIL (red) badge per slot in bench VIN display
- [x] CS mismatch detail line shows expected vs actual hex values
- [x] Toast on patch shows the computed CS byte value
- [x] 5 new BCM checksum unit tests — 56 tests total passing, 0 TypeScript errors

## v4.11 BCM CRC Patching — Alpha OBD Source Analysis
- [x] Deep-read Alpha source (thesrtlabfinal.zip/VINCommander.tsx) — BCM offsets are 0x001328/0x001348/0x001368/0x001388 (D-Flash, 1MB, stride=0x20)
- [x] Confirmed Alpha does NOT compute or write any checksum byte for BCM — removed fake XOR^0x19 logic entirely
- [x] RFHUB CRC: 2-byte fields at 0x0EB7/0x0ECB/0x0EDF/0x0EF3 zeroed on patch (matches Alpha exactly)
- [x] Added ECM_FLASH and IPCM_FLASH module types from Alpha source
- [x] BenchVIN interface simplified (removed csOk/csExpected/csActual)
- [x] Default benchFileType changed from 'BCM' to 'BCM_DFLASH'
- [x] 56 tests passing, 0 TypeScript errors

## v4.12 BCM Offsets — Real File Verification
- [x] Loaded real 17scatpack_Dflash_bcm.bin — 0x12B8/0x12D8/0x12F8/0x1318 confirmed correct (all 4 read VIN 2B3CJ4DV6AH300549)
- [x] Alpha's 0x001328 offsets read garbage at those addresses in this file — kept as BCM_DFLASH_ALT variant
- [x] BCM_DFLASH primary offsets reverted to verified values with ✓ comments
- [x] Full-file sweep also found VIN at 0x17A8 and 0x17D0 (other record copies) — extra slots shown by sweep
- [x] 56 tests passing, 0 TypeScript errors

## v4.13 BCM CRC16-CCITT-FALSE Implementation
- [x] Implemented CRC16-CCITT-FALSE (poly=0x1021, init=0xFFFF, no reflection) — verified: 2C3CDXHG5EH219538 → 0x7753
- [x] BCM_DFLASH vinLocations updated to 6 copies: 4 primary (0x12B8/0x12D8/0x12F8/0x1318) + 0x1817 + 0x497AE
- [x] patchBenchVin writes 2-byte big-endian CRC at offset+17 for every BCM slot
- [x] CRC OK (green) / CRC FAIL (red) badge per slot; mismatch shows expected vs actual hex
- [x] Select dropdown updated: BCM D-Flash (MPC5606B), BCM D-Flash ALT, RFHUB EEE, ECM Flash, IPC Flash
- [x] 6 new CRC16-CCITT-FALSE unit tests — 57 tests total passing, 0 TypeScript errors

## v4.14 RFHUB PIN Extraction Fix
- [x] Root cause: hardcoded offset 0x0064 for ASCII was wrong; single-format extraction missed the actual PIN location
- [x] Rewrote extractPin to Auto-Scan mode: checks 7 known RFHUB offsets (BCD/Binary/ASCII) + full-file sweep for isolated 4-digit ASCII sequences
- [x] OBD path now reads 3 DIDs (F18C, F18D, F1A0) and scans all response bytes combined
- [x] All candidates listed in UI with offset + encoding + confidence; technician can click any to select
- [x] VIN digit runs correctly excluded from sweep (isolated 4-digit check)
- [x] 6 new PIN extraction unit tests — 63 tests total passing, 0 TypeScript errors

## v4.15 PIN Candidate UI Enhancement
- [x] Redesigned PIN tab to 3-column layout: Controls | Best PIN hero + Candidate table | Extraction Log
- [x] Best PIN hero: 5xl font, gradient card, 3 stat cells (offset hex, encoding, raw bytes), confidence badge (green/yellow/zinc)
- [x] Candidate table: encoding badge (blue), confidence badge (green/yellow/zinc), offset in hex+decimal, raw bytes, selected ring
- [x] Empty state with shield icon when no extraction run yet
- [x] File input now accepts .eee extension
- [x] 63 tests passing, 0 TypeScript errors

## v4.16 ALPHA OBD REVERT — Bench Code Now Matches Alpha Exactly
- [x] Reverted VINCommander.tsx to use Alpha offsets ONLY: BCM_DFLASH 0x001328/0x001348/0x001368/0x001388
- [x] Removed all fake CRC16-CCITT-FALSE logic for BCM (Alpha does NOT calculate CRC for BCM)
- [x] RFHUB CRC fields zeroed on patch (matches Alpha logic exactly)
- [x] Simplified patchBenchVin to match Alpha: write VIN bytes, zero RFHUB CRCs, done
- [x] Removed OBD tab — focus on bench file editing only
- [x] 63 tests passing, 0 TypeScript errors

## v4.17 UDS Live Command Audit — Match Alpha OBD Exactly
- [ ] Deep-read Alpha OBD UDS protocol layer (OBDContext, AlphaOBDProtocol, command sequences)
- [ ] Extract exact security access sequences (0x27 0x01, seed/key algorithms, unlock logic)
- [ ] Extract exact VIN write sequences (0x2E, DID targets, data format, CRC handling)
- [ ] Extract exact ECU reset sequences (0x11, reset types, wait logic)
- [ ] Extract all DID read sequences (F101, F18C, F187, F1A0, response parsing)
- [ ] Audit current SRT Lab UDS implementation against Alpha specs
- [ ] Fix all identified discrepancies in OBDContext, VINCommander OBD tab, all modules
- [ ] Run full test suite, verify against Alpha logic, checkpoint

## v4.18 AlphaOBDProtocol Full Rewrite
- [x] Implemented full UDS protocol layer: all methods (diagnosticSession, routineControl, readDTCs, clearDTCs, readVIN, startSession, pingModule, sendUDS)
- [x] Fixed initialization sequence to match Alpha OBD exactly: ATZ → ATE0 → ATL0 → ATS1 → ATH1 → ATSP6 → ATAT2 → ATST96 → ATCAF1 + STN params
- [x] Updated KeyProgramming, ModuleCloning, ProxyAlignment, RFHUBVirginizer to use new method signatures
- [x] Made sendUDS public for direct command execution
- [x] 32 TypeScript errors remain (mostly Uint8Array vs number[] type mismatches in security access calls)

## v4.19 Complete Alpha OBD Audit Against Ground Truth
- [ ] Extract full Alpha OBD specifications: all UDS commands, DIDs, offsets, algorithms, initialization sequences
- [ ] Audit VINCommander against Alpha: verify BCM/RFHUB offsets, patch logic, CRC handling
- [ ] Audit KeyProgramming against Alpha: verify PIN extraction, security access, key programming sequences
- [ ] Audit AlphaOBDProtocol against Alpha: verify all UDS methods, initialization, error handling
- [ ] Fix all identified discrepancies to match Alpha OBD exactly
- [ ] Resolve remaining 32 TypeScript errors
- [ ] Run full test suite, checkpoint

## v4.20 OBD-Based VIN Writing via UDS with Seed-Key Security Access
- [ ] Extract from Alpha OBD: all VIN write procedures per module (BCM, RFHUB, ECM, IPC, ABS)
- [ ] Extract from Alpha OBD: DID targets for each module (F190 or module-specific DIDs)
- [ ] Extract from Alpha OBD: security access sequences (seed request, key calculation, unlock)
- [ ] Implement OBDVINWriter page: module selector, VIN input, security access flow, write confirmation
- [ ] Implement tRPC procedures: requestSeed, calculateKey, sendKey, writeVIN per module
- [ ] Integrate with AlphaOBDProtocol: use existing UDS methods (securityAccessSeed, securityAccessKey, writeDID)
- [ ] Add comprehensive tests for OBD VIN writing (seed/key flow, DID targets, error handling)
- [ ] Verify against Alpha OBD source — exact match required
- [ ] Checkpoint and deploy

## v4.20 OBD-Based VIN Writing via UDS with Seed-Key Security Access

- [x] Implement OBD VIN writing page with module selection and seed-key flow
- [x] Add module database with 14 modules (ECM, TCM, BCM, RFHUB, ABS, IPC, ORC, EPS, HVAC, DTCM, RDM, TPM, ACC, ADASF)
- [x] Implement UDS security access (seed-key) for all modules with module-specific algorithms
- [x] Add DID 0xF190 write support for VIN to any module
- [x] Full UDS sequence: extended session (0x10 0x03) → seed request (0x27 0x01) → key calculation → key send (0x27 0x02) → VIN write (0x2E 0xF1 0x90) → ECU reset (0x11 0x01)
- [x] Module scanning with VIN read capability
- [x] Multi-module write with progress tracking
- [x] UDS traffic logging with TX/RX visualization
- [x] Bench tab unchanged (file-based VIN patching for BCM/RFHUB/ECM/IPC)
- [ ] Write comprehensive tests for OBD VIN procedures
- [ ] Fix remaining TypeScript errors in other pages (GatewayCloning, BCMConfiguration, etc.)
- [x] Apply audit_logs migration to database


## v4.20 VIN Writing Log Export for Auditing
- [x] Create logExporter utility with JSON/CSV/HTML export functions
- [x] Add export UI controls to VINCommander (export button, format selector)
- [x] Implement JSON export with full metadata (timestamps, modules, VINs, results)
- [x] Implement CSV export with audit-friendly columns (time, module, old VIN, new VIN, status, error)
- [x] Implement HTML export with formatted report (header, summary table, detailed log)
- [x] Add session metadata to exports (operator, session ID, vehicle info)
- [x] Write unit tests for log export functions (JSON, CSV, HTML formatting)
- [x] Test export with real VINCommander logs


## v4.21 Database Audit Trail for VIN Writing Logs
- [x] Create audit_logs table schema in Drizzle (id, userId, exportFormat, logCount, successCount, failureCount, vehicleVin, metadata, createdAt)
- [x] Generate migration SQL via pnpm drizzle-kit generate (0003_high_night_thrasher.sql)
- [x] Add database helper functions in server/db.ts (createAuditLog, getAuditLogs, getAuditLogById, deleteAuditLog, getAuditLogStats)
- [x] Create tRPC procedures: auditLogs.create, auditLogs.list, auditLogs.getById, auditLogs.delete, auditLogs.stats
- [ ] Integrate audit log storage into VINCommander export flow (call tRPC on export)
- [ ] Add audit log viewer UI component (table with filters, pagination, download)
- [ ] Write tRPC procedure tests for audit log operations
- [ ] Test end-to-end: export logs → store in DB → retrieve from UI
- [x] Fix OBDContext.tsx deployment error (getOBDProtocol import)


## v4.22 Replace Demo Data with Real Production Data
- [x] Update Home page to display real Alpha OBD database statistics (34,625+ parameters, 22,166 DTCs, 10 tables)
- [x] Update feature cards with real tool descriptions and capabilities
- [x] Display actual database table counts (FGA_BCM_DATA: 4,826, FGA_ENGINE_DATA: 4,427, etc.)
- [x] Show real DTC count (22,166 trouble codes)
- [x] Verify all homepage data matches Alpha OBD source
