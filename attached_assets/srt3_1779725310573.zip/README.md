# UDS Session Analyzer

Tells you **why a UDS command isn't working** from a J2534 / CAN trace. This is
the live-session tool — it reads the actual traffic your software logs, not
binary dumps.

## Run it

```bash
cd uds-analyzer
python3 analyze_session.py your_session.log
# try the included example:
python3 analyze_session.py example_session.log
```

## What it does

1. Parses CAN frames / UDS trace lines (auto-detects common formats).
2. Strips ISO-TP single-frame PCI, assembles service-level messages.
3. Pairs each request with its response.
4. Decodes negative responses (full NRC table with plain-English causes).
5. Detects the **ResponsePending (0x78) → silence** timeout pattern.
6. Tracks SecurityAccess state and flags out-of-order procedures.
7. Emits a session-level diagnosis + actionable next steps.

## Failure modes it distinguishes (all validated)

| Symptom in log | Diagnosis | Fix direction |
|---|---|---|
| 0x78 repeated, then silence | ECU working, tool timed out early | extend P2*/timeout; or bench can't provide needed network state |
| No response at all, no 0x78 | link/addressing problem | check CAN IDs, wiring/termination, session open, TesterPresent |
| 0x33 securityAccessDenied | not unlocked / wrong level | complete SecurityAccess in same session at right level |
| 0x35 invalidKey | seed→key calc wrong | verify key algorithm/secret for this variant |
| 0x36 / 0x37 | locked out / delay timer | wait out lockout, retry |
| 0x22 conditionsNotCorrect | precondition missing | session/ignition/voltage/other modules |
| 0x24 requestSequenceError | step out of order | session → SecurityAccess → routine |
| 0x31 requestOutOfRange | bad DID/RID for module | confirm identifier matches variant |
| 0x72 generalProgrammingFailure | write failed | voltage; module secure state |

## Adapting to your log format

If `messages parsed: 0` or it misses lines, your tool's format differs. The only
thing to adjust is `parsers/uds_parser.py` → `parse_line` (the regexes for
timestamp / direction / CAN-ID) and `to_uds` (service-level extraction). Send me
a sample of your real log and I'll tune the parser to it exactly.

## Limit

First pass does single-frame ISO-TP. Multi-frame reassembly (FirstFrame +
ConsecutiveFrames for long payloads) is stubbed — most diagnostic requests are
single-frame, but a long RoutineControl payload split across frames won't fully
assemble yet. Flag it if your routine uses multi-frame and I'll add reassembly.
