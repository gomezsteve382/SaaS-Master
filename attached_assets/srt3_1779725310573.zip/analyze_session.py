#!/usr/bin/env python3
"""
UDS Session Analyzer — CLI.

Usage:
  python3 analyze_session.py <session.log>

Paste/save your J2534 or CAN trace to a text file and run it. The analyzer
pairs UDS requests with responses, decodes negative responses, detects the
ResponsePending timeout pattern, and tells you where the procedure breaks.

If parsing misses your format, the per-line regexes live in
parsers/uds_parser.py:parse_line — that's the only thing to adjust.
"""
import sys
from uds_analyze import analyze_text


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    with open(sys.argv[1], "r", errors="replace") as f:
        out = analyze_text(f.read())

    print(f"\n=== UDS SESSION ANALYSIS: {sys.argv[1]} ===")
    print(f"messages parsed: {out['messages_parsed']}\n")

    print("EXCHANGES:")
    for e in out["exchanges"]:
        mark = {"ok": " OK ", "warn": "WARN", "fail": "FAIL"}[e["severity"]]
        print(f"  [{mark}] {e['verdict']}")
        print(f"         req={e['req']} | {e['detail']}")

    d = out["diagnosis"]
    print(f"\nSecurityAccess seen: {d['security_access_seen']} | unlocked: {d['security_unlocked']}")
    print(f"First failure: {d['first_failure']}")
    print("\nDIAGNOSIS:")
    for f in d["findings"]:
        print(f"  - {f}")
    if d["recommended_next_steps"]:
        print("\nRECOMMENDED NEXT STEPS:")
        for n in d["recommended_next_steps"]:
            print(f"  - {n}")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
