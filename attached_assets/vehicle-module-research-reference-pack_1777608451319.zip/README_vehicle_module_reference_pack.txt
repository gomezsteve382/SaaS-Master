Vehicle Module Research Reference Pack

Included:
- Surgical scrape reports
- UDS matrices and workflows
- CAN ID pattern references
- Failure diagnosis flow
- AlfaOBD module inventories
- Checksum/CVN evidence reports

Not included:
- Proprietary recovered source-code dumps
- License bypass or activation material
- Original uploaded executables/DLLs/archives

Purpose:
Research, troubleshooting reference, and audit trail for extracted observations only.
