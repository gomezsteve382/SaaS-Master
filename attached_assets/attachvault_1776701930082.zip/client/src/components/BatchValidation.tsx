import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Upload, Download, CheckCircle2, AlertCircle, Loader2, FileStack, FileText } from 'lucide-react';

export default function BatchValidation() {

  const [files, setFiles] = useState<File[]>([]);
  const [validating, setValidating] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [error, setError] = useState('');

  const batchValidate = trpc.rfhub.batchValidateFiles.useMutation();
  const generateReport = trpc.rfhub.generateValidationReport.useMutation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    
    // Validate file sizes
    const invalidFiles = selectedFiles.filter(f => f.size !== 4096);
    if (invalidFiles.length > 0) {
      setError(`${invalidFiles.length} file(s) have invalid size. All files must be exactly 4096 bytes.`);
      return;
    }
    
    setFiles(selectedFiles);
    setError('');
    setResults(null);
  };

  const handleValidate = async () => {
    if (files.length === 0) {
      setError('Please select at least one file to validate');
      return;
    }

    setValidating(true);
    setError('');

    try {
      // Convert files to base64
      const filesData = await Promise.all(
        files.map(async (file) => {
          const arrayBuffer = await file.arrayBuffer();
          const uint8Array = new Uint8Array(arrayBuffer);
          let binary = '';
          for (let i = 0; i < uint8Array.length; i++) {
            binary += String.fromCharCode(uint8Array[i]);
          }
          return {
            name: file.name,
            dataBase64: btoa(binary),
          };
        })
      );

      const result = await batchValidate.mutateAsync({ files: filesData });
      setResults(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Validation failed');
    } finally {
      setValidating(false);
    }
  };

  const handleExportCSV = async () => {
    if (!results) return;

    try {
      const reportResult = await generateReport.mutateAsync({ results: results.results });
      
      // Download CSV
      const blob = new Blob([reportResult.csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `rfhub-validation-${results.batchId}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed');
    }
  };

  const handleExportJSON = () => {
    if (!results) return;

    const json = JSON.stringify(results, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rfhub-validation-${results.batchId}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleClear = () => {
    setFiles([]);
    setResults(null);
    setError('');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileStack className="h-5 w-5" />
            Batch Validation
          </CardTitle>
          <CardDescription>
            Upload multiple RFHUB files to validate CRC-16 checksums in bulk
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Upload */}
          <div className="space-y-2">
            <label htmlFor="batch-files" className="block text-sm font-medium">
              Select RFHUB Files (4096 bytes each)
            </label>
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  id="batch-files"
                  type="file"
                  accept=".eee,.bin"
                  multiple
                  onChange={handleFileChange}
                  disabled={validating}
                />
              </div>
              {files.length > 0 && (
                <Button variant="outline" onClick={handleClear} disabled={validating}>
                  Clear
                </Button>
              )}
            </div>
            {files.length > 0 && (
              <p className="text-sm text-muted-foreground">
                {files.length} file(s) selected
              </p>
            )}
          </div>

          {/* Error Alert */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Validate Button */}
          <Button
            onClick={handleValidate}
            disabled={files.length === 0 || validating}
            className="w-full"
          >
            {validating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Validating {files.length} files...
              </>
            ) : (
              <>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Validate {files.length} File{files.length !== 1 ? 's' : ''}
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {results && (
        <>
          {/* Summary Card */}
          <Card>
            <CardHeader>
              <CardTitle>Validation Summary</CardTitle>
              <CardDescription>Batch ID: {results.batchId}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">{results.totalFiles}</div>
                  <div className="text-sm text-muted-foreground">Total Files</div>
                </div>
                <div className="text-center p-4 bg-green-500/10 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{results.validFiles}</div>
                  <div className="text-sm text-muted-foreground">Valid</div>
                </div>
                <div className="text-center p-4 bg-red-500/10 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{results.invalidFiles}</div>
                  <div className="text-sm text-muted-foreground">Invalid</div>
                </div>
                <div className="text-center p-4 bg-yellow-500/10 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">{results.errorFiles}</div>
                  <div className="text-sm text-muted-foreground">Errors</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-2">
                  <span>Success Rate</span>
                  <span className="font-medium">
                    {((results.validFiles / results.totalFiles) * 100).toFixed(1)}%
                  </span>
                </div>
                <Progress 
                  value={(results.validFiles / results.totalFiles) * 100} 
                  className="h-2"
                />
              </div>

              {/* Export Buttons */}
              <div className="flex gap-2 mt-4">
                <Button onClick={handleExportCSV} variant="outline" className="flex-1">
                  <FileText className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
                <Button onClick={handleExportJSON} variant="outline" className="flex-1">
                  <Download className="mr-2 h-4 w-4" />
                  Export JSON
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results Table */}
          <Card>
            <CardHeader>
              <CardTitle>Validation Results</CardTitle>
              <CardDescription>
                Detailed validation results for each file
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>File Name</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>VIN Found</TableHead>
                      <TableHead>CRC Match</TableHead>
                      <TableHead>Algorithm</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {results.results.map((result: any, index: number) => (
                      <TableRow key={index}>
                        <TableCell className="font-mono text-sm">
                          {result.fileName}
                        </TableCell>
                        <TableCell>
                          {result.error ? (
                            <Badge variant="destructive">
                              <AlertCircle className="mr-1 h-3 w-3" />
                              Error
                            </Badge>
                          ) : result.isValid ? (
                            <Badge variant="default" className="bg-green-600">
                              <CheckCircle2 className="mr-1 h-3 w-3" />
                              Valid
                            </Badge>
                          ) : (
                            <Badge variant="destructive">
                              <AlertCircle className="mr-1 h-3 w-3" />
                              Invalid
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {result.vinFound || 'N/A'}
                        </TableCell>
                        <TableCell>
                          {result.crcMatch ? (
                            <Badge variant="outline" className="text-green-600 border-green-600">
                              Match
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-red-600 border-red-600">
                              Mismatch
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {result.algorithmUsed ? (
                            <div className="flex items-center gap-1">
                              {result.algorithmUsed}
                              {result.isBruteForced && (
                                <Badge variant="secondary" className="text-xs">
                                  Brute-forced
                                </Badge>
                              )}
                            </div>
                          ) : (
                            'N/A'
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
