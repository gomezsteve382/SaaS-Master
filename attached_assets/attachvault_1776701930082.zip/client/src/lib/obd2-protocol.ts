export type HardwareType = 'elm327' | 'j2534' | 'arduino';

declare global {
  interface Navigator {
    serial: {
      requestPort(): Promise<SerialPort>;
      getPorts(): Promise<SerialPort[]>;
    };
  }
  
  interface SerialPort {
    open(options: { baudRate: number }): Promise<void>;
    close(): Promise<void>;
    readable: ReadableStream<Uint8Array> | null;
    writable: WritableStream<Uint8Array> | null;
  }
}

/**
 * Safely open a serial port - handles "port already open" errors by closing and reopening
 * Properly releases reader/writer streams before closing
 */
async function safeOpenPort(port: SerialPort, baudRate: number): Promise<void> {
  // Check if port appears to be open (has readable stream)
  if (port.readable !== null || port.writable !== null) {
    console.log('Port appears to be open, releasing streams and closing...');
    try {
      // Force-release the reader stream - MUST await cancel before releaseLock
      if (port.readable !== null) {
        try {
          const reader = port.readable.getReader();
          await reader.cancel(); // MUST await cancel
          reader.releaseLock();
        } catch (e) {
          // Stream already released, continue
          console.log('Reader release error (ignored):', e);
        }
      }
      
      // Force-release the writer stream - MUST await abort before releaseLock
      if (port.writable !== null) {
        try {
          const writer = port.writable.getWriter();
          await writer.abort(); // MUST await abort
          writer.releaseLock();
        } catch (e) {
          // Stream already released, continue
          console.log('Writer release error (ignored):', e);
        }
      }
      
      // Now try to close the port
      await port.close();
      // Small delay to ensure port is fully released
      await new Promise(resolve => setTimeout(resolve, 150));
    } catch (closeError) {
      console.log('Port close during safe open:', closeError);
      // Continue anyway - the open might still work
    }
  }
  
  try {
    await port.open({ baudRate });
  } catch (e) {
    const err = e as any;
    const errorMsg = err.message || String(err);
    
    // If port is already open, try to close and reopen
    if (errorMsg.includes('already open') || errorMsg.includes('InvalidStateError') || errorMsg.includes('locked stream')) {
      console.log('Port already open error, attempting close and reopen...');
      try {
        // Try to release streams again - MUST await
        if (port.readable !== null) {
          try {
            const reader = port.readable.getReader();
            await reader.cancel();
            reader.releaseLock();
          } catch (e) {
            console.log('Reader retry release error (ignored):', e);
          }
        }
        if (port.writable !== null) {
          try {
            const writer = port.writable.getWriter();
            await writer.abort();
            writer.releaseLock();
          } catch (e) {
            console.log('Writer retry release error (ignored):', e);
          }
        }
        
        await port.close();
        await new Promise(resolve => setTimeout(resolve, 300));
        await port.open({ baudRate });
        console.log('Port reopened successfully');
        return;
      } catch (retryError) {
        console.error('Failed to reopen port:', retryError);
        throw retryError;
      }
    }
    
    throw e;
  }
}

export interface OBD2Connection {
  type: HardwareType;
  port: SerialPort | null;
  connected: boolean;
  deviceName: string;
}

export interface CANMessage {
  id: number;
  data: Uint8Array;
  timestamp: number;
}

export interface DiscoveredModule {
  name: string;
  code: string;
  txId: number;
  rxId: number;
  vin: string | null;
  vinOffset: number | null;
  status: 'found' | 'no_response' | 'error' | 'vin_read' | 'vin_written';
  lastResponse: Uint8Array | null;
}

const UDS_SERVICES = {
  READ_DATA_BY_ID: 0x22,
  WRITE_DATA_BY_ID: 0x2E,
  SECURITY_ACCESS: 0x27,
  DIAGNOSTIC_SESSION: 0x10,
  TESTER_PRESENT: 0x3E,
  ROUTINE_CONTROL: 0x31,
};

// Routine Control Sub-Functions
const ROUTINE_SUB = {
  START: 0x01,
  STOP: 0x02,
  REQUEST_RESULTS: 0x03,
};

// Known EOL Routine IDs (from CDA reverse engineering)
export const EOL_ROUTINE_IDS = {
  RFHUB_VIRGINIZE: 0x00A5,    // High value target - RFHUB memory wipe
  EOL_ROUTINE_1: 0x0100,      // EOL/Debug routine
  EOL_ROUTINE_2: 0xDE01,      // EOL/Debug routine
  EOL_ROUTINE_3: 0xFF0A,      // EOL/Debug routine
};

// Calibration and Module Info DIDs
export const CALIBRATION_DIDS = {
  VIN: 0xF190,                    // Vehicle Identification Number
  ECU_SERIAL_NUMBER: 0xF18C,      // ECU Serial Number (CSN) - 5 bytes
  HARDWARE_PART_NUMBER: 0xF191,   // ECU Hardware Part Number
  SOFTWARE_VERSION: 0xF195,       // ECU Software Version
  CALIBRATION_VERSION: 0xF193,    // ECU Calibration Version
  CALIBRATION_DATE: 0xF187,       // Calibration Date
  SUPPLIER_INFO: 0xF18A,          // Supplier Identification
  ECU_NAME: 0xF197,               // System Name or ECU Name
  BOOTLOADER_VERSION: 0xF180,     // Bootloader Software ID
  APPLICATION_ID: 0xF181,         // Application Software ID
  DATA_ID: 0xF182,                // Application Data ID
  FINGERPRINT: 0xF184,            // Boot Software Fingerprint
  DIAG_SESSION: 0xF186,           // Active Diagnostic Session
  PROGRAMMING_DATE: 0xF199,       // Programming Date
  TESTER_SERIAL: 0xF198,          // Tester Serial Number (last programmer)
  ODOMETER: 0xF1A0,               // Odometer reading (some modules)
};

export interface CalibrationInfo {
  did: number;
  name: string;
  value: string;
  rawBytes: Uint8Array;
}

export function parseCalibrationResponse(did: number, response: Uint8Array): CalibrationInfo | null {
  if (response[0] !== 0x62) return null;
  
  const responseDid = (response[1] << 8) | response[2];
  if (responseDid !== did) return null;
  
  const data = response.slice(3);
  let value = '';
  
  if (data.every(b => b >= 0x20 && b <= 0x7E)) {
    for (let i = 0; i < data.length; i++) {
      value += String.fromCharCode(data[i]);
    }
    value = value.trim();
  } else {
    value = Array.from(data)
      .map(b => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ');
  }
  
  const didNames: Record<number, string> = {
    [CALIBRATION_DIDS.VIN]: 'VIN',
    [CALIBRATION_DIDS.ECU_SERIAL_NUMBER]: 'ECU Serial (CSN)',
    [CALIBRATION_DIDS.HARDWARE_PART_NUMBER]: 'Hardware Part Number',
    [CALIBRATION_DIDS.SOFTWARE_VERSION]: 'Software Version',
    [CALIBRATION_DIDS.CALIBRATION_VERSION]: 'Calibration Version',
    [CALIBRATION_DIDS.CALIBRATION_DATE]: 'Calibration Date',
    [CALIBRATION_DIDS.SUPPLIER_INFO]: 'Supplier Info',
    [CALIBRATION_DIDS.ECU_NAME]: 'ECU Name',
    [CALIBRATION_DIDS.BOOTLOADER_VERSION]: 'Bootloader Version',
    [CALIBRATION_DIDS.APPLICATION_ID]: 'Application ID',
    [CALIBRATION_DIDS.DATA_ID]: 'Data ID',
    [CALIBRATION_DIDS.FINGERPRINT]: 'Boot Fingerprint',
    [CALIBRATION_DIDS.DIAG_SESSION]: 'Diagnostic Session',
    [CALIBRATION_DIDS.PROGRAMMING_DATE]: 'Programming Date',
    [CALIBRATION_DIDS.TESTER_SERIAL]: 'Last Programmer',
    [CALIBRATION_DIDS.ODOMETER]: 'Odometer',
  };
  
  return {
    did,
    name: didNames[did] || `DID 0x${did.toString(16).toUpperCase()}`,
    value,
    rawBytes: data,
  };
}

export interface RoutineResult {
  success: boolean;
  routineId: number;
  routineName?: string;
  statusRecord?: Uint8Array;
  nrc?: number;
  nrcDescription?: string;
  txBytes?: Uint8Array;
  rxBytes?: Uint8Array;
  elapsedMs?: number;
  verdict?: string;
}

// Extended NRC (Negative Response Code) descriptions for detailed logging
export const NRC_DESCRIPTIONS: Record<number, { short: string; detail: string; actionable: string }> = {
  0x10: { short: 'General Reject', detail: 'ECU rejected the request without specific reason', actionable: 'Try a different session mode or verify module compatibility' },
  0x11: { short: 'Service Not Supported', detail: 'This UDS service is not implemented in the ECU', actionable: 'Module does not support routine control (0x31)' },
  0x12: { short: 'Sub-Function Not Supported', detail: 'The sub-function (start/stop/result) is not supported', actionable: 'Try a different sub-function type' },
  0x13: { short: 'Incorrect Message Length', detail: 'Request frame has wrong byte count', actionable: 'Check routine option parameters' },
  0x14: { short: 'Response Too Long', detail: 'ECU response exceeds transport buffer', actionable: 'Normal for complex routines - check flow control' },
  0x21: { short: 'Busy Repeat Request', detail: 'ECU is busy processing another request', actionable: 'Wait and retry after 100-500ms' },
  0x22: { short: 'Conditions Not Correct', detail: 'Preconditions not met (wrong session/security/state)', actionable: 'Enter programming session or unlock security first' },
  0x24: { short: 'Request Sequence Error', detail: 'Commands sent in wrong order', actionable: 'Follow proper UDS sequence: Session → Security → Routine' },
  0x25: { short: 'No Response From Subnet', detail: 'Gateway could not reach target module', actionable: 'Check CAN wiring and module power' },
  0x26: { short: 'Failure Prevents Execution', detail: 'Internal ECU error prevents routine execution', actionable: 'Module may have fault codes - clear DTCs first' },
  0x31: { short: 'Request Out Of Range', detail: 'Routine ID not recognized or parameter invalid', actionable: 'Routine ID not supported by this module' },
  0x33: { short: 'Security Access Denied', detail: 'Routine requires higher security level', actionable: 'Unlock with Level 0x05 (Bootloader) required' },
  0x35: { short: 'Invalid Key', detail: 'Security key calculation was wrong', actionable: 'Algorithm mismatch - verify CDA constants' },
  0x36: { short: 'Exceeded Number of Attempts', detail: 'Too many failed security attempts', actionable: 'Wait 10 seconds or power cycle module' },
  0x37: { short: 'Required Time Delay Not Expired', detail: 'Security lockout timer still active', actionable: 'Wait for lockout period (typically 10s)' },
  0x70: { short: 'Upload/Download Not Accepted', detail: 'Transfer request rejected', actionable: 'Enter programming session first' },
  0x71: { short: 'Transfer Data Suspended', detail: 'Data transfer interrupted', actionable: 'Restart transfer sequence' },
  0x72: { short: 'General Programming Failure', detail: 'Flash/EEPROM write failed', actionable: 'Check power supply and memory integrity' },
  0x73: { short: 'Wrong Block Sequence Counter', detail: 'Transfer block out of sequence', actionable: 'Restart from block 1' },
  0x78: { short: 'Response Pending', detail: 'ECU needs more time to process', actionable: 'Wait for final response (normal for long routines)' },
  0x7E: { short: 'Sub-Function Not Supported In Active Session', detail: 'Current session does not allow this sub-function', actionable: 'Switch to extended or programming session' },
  0x7F: { short: 'Service Not Supported In Active Session', detail: 'Current session does not allow routine control', actionable: 'Enter extended diagnostic session (0x03)' },
};

// Routine verdict generator for clear actionable feedback
export function getRoutineVerdict(result: RoutineResult, routineName: string): string {
  if (result.success) {
    if (routineName.includes('VIRGINIZE')) {
      return 'SUCCESS HIT! VVDI-Equivalent Virginize command ACCEPTED. Ready for memory wipe payload.';
    }
    if (routineName.includes('PROXI') || routineName.includes('Align')) {
      return 'SUCCESS HIT! SRT Lab-Equivalent PROXI alignment routine found.';
    }
    return `SUCCESS! Routine executed - check status record for result data.`;
  }
  
  const nrc = result.nrc || 0x10;
  const nrcInfo = NRC_DESCRIPTIONS[nrc];
  
  if (nrc === 0x33) {
    return 'BLOCKED: Security access required. Unlock with Level 0x05 first.';
  }
  if (nrc === 0x31) {
    return 'REJECTED: Routine ID not supported by this module.';
  }
  if (nrc === 0x22) {
    return 'BLOCKED: Preconditions not met. Check session mode and security level.';
  }
  if (nrc === 0x7F) {
    return 'BLOCKED: Wrong session. Enter extended/programming session first.';
  }
  
  return nrcInfo?.actionable || `FAILED: NRC 0x${nrc.toString(16).toUpperCase()}`;
}

// Format bytes as hex string for logging
export function formatHexBytes(bytes: Uint8Array | number[]): string {
  return Array.from(bytes).map(b => b.toString(16).toUpperCase().padStart(2, '0')).join(' ');
}

// EOL Fuzzer Routine Configuration
export const EOL_FUZZER_ROUTINES = [
  { id: 0x00A5, name: 'RFHUB Virginize', description: 'Memory wipe / key learning reset' },
  { id: 0x0100, name: 'EOL Routine 1', description: 'End-of-line debug routine' },
  { id: 0xDE01, name: 'EOL Routine 2', description: 'Dealer options routine' },
  { id: 0xFF0A, name: 'EOL Routine 3', description: 'Factory programming routine' },
  { id: 0xAA00, name: 'Proxi Alignment', description: 'Module synchronization routine' },
];

export type FuzzerVerdict = 'SUCCESS' | 'SOFT_HIT' | 'REJECTED' | 'SECURITY_DENIED' | 'NO_RESPONSE';

export interface FuzzerResult {
  routineId: number;
  routineName: string;
  verdict: FuzzerVerdict;
  nrc?: number;
  nrcDescription?: string;
  txBytes?: Uint8Array;
  rxBytes?: Uint8Array;
  elapsedMs?: number;
}

// Get verdict class for UI styling
export function getFuzzerVerdictClass(verdict: FuzzerVerdict): string {
  switch (verdict) {
    case 'SUCCESS': return 'text-green-500 bg-green-500/10';
    case 'SOFT_HIT': return 'text-yellow-500 bg-yellow-500/10';
    case 'SECURITY_DENIED': return 'text-orange-500 bg-orange-500/10';
    case 'REJECTED': return 'text-red-500 bg-red-500/10';
    case 'NO_RESPONSE': return 'text-gray-500 bg-gray-500/10';
    default: return 'text-gray-500';
  }
}

// Get verdict emoji for display
export function getFuzzerVerdictEmoji(verdict: FuzzerVerdict): string {
  switch (verdict) {
    case 'SUCCESS': return '🟢';
    case 'SOFT_HIT': return '🟡';
    case 'SECURITY_DENIED': return '🟠';
    case 'REJECTED': return '🔴';
    case 'NO_RESPONSE': return '⚫';
    default: return '❓';
  }
}

// Convert RoutineResult to FuzzerResult with verdict classification
export function classifyRoutineResult(result: RoutineResult, routineName: string): FuzzerResult {
  let verdict: FuzzerVerdict;
  
  if (result.success) {
    verdict = 'SUCCESS';
  } else if (!result.rxBytes || result.rxBytes.length === 0) {
    verdict = 'NO_RESPONSE';
  } else if (result.nrc === 0x33) {
    verdict = 'SECURITY_DENIED';
  } else if (result.nrc === 0x22) {
    verdict = 'SOFT_HIT'; // Conditions not correct - routine exists but needs preconditions
  } else {
    verdict = 'REJECTED';
  }
  
  return {
    routineId: result.routineId,
    routineName,
    verdict,
    nrc: result.nrc,
    nrcDescription: result.nrcDescription,
    txBytes: result.txBytes,
    rxBytes: result.rxBytes,
    elapsedMs: result.elapsedMs,
  };
}

// DID for CSN (Control Serial Number) - used in Atlantis 5-byte algorithm
export const CSN_DID = 0xF18C;

// ═══════════════════════════════════════════════════════════════════════════
// SEED/KEY CAPTURE SYSTEM - For algorithm reverse engineering
// ═══════════════════════════════════════════════════════════════════════════

export interface SeedKeyCapture {
  id: string;
  timestamp: string;
  moduleCode: string;
  moduleName: string;
  txId: number;
  rxId: number;
  securityLevel: number;
  seedBytes: Uint8Array;
  keyBytes: Uint8Array;
  seedHex: string;
  keyHex: string;
  csnBytes?: Uint8Array;
  csnHex?: string;
  success: boolean;
  notes?: string;
}

// Global capture mode state
let captureMode = false;
const capturedSamples: SeedKeyCapture[] = [];

export function setCaptureMode(enabled: boolean): void {
  captureMode = enabled;
  console.log(`[CAPTURE] Mode ${enabled ? 'ENABLED' : 'DISABLED'}`);
}

export function isCaptureMode(): boolean {
  return captureMode;
}

export function addCapture(capture: Omit<SeedKeyCapture, 'id' | 'timestamp'>): SeedKeyCapture {
  const fullCapture: SeedKeyCapture = {
    ...capture,
    id: `cap_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: new Date().toISOString(),
  };
  capturedSamples.push(fullCapture);
  
  // Also save to localStorage for persistence
  try {
    const stored = localStorage.getItem('seedkey_captures') || '[]';
    const existing = JSON.parse(stored);
    existing.push({
      ...fullCapture,
      seedBytes: Array.from(fullCapture.seedBytes),
      keyBytes: Array.from(fullCapture.keyBytes),
      csnBytes: fullCapture.csnBytes ? Array.from(fullCapture.csnBytes) : undefined,
    });
    localStorage.setItem('seedkey_captures', JSON.stringify(existing));
  } catch (e) {
    console.error('[CAPTURE] Failed to save to localStorage:', e);
  }
  
  console.log(`[CAPTURE] Added sample #${capturedSamples.length}: ${capture.moduleCode} Level ${capture.securityLevel}`);
  console.log(`  Seed: ${capture.seedHex}`);
  console.log(`  Key:  ${capture.keyHex}`);
  if (capture.csnHex) console.log(`  CSN:  ${capture.csnHex}`);
  
  return fullCapture;
}

export function getCapturedSamples(): SeedKeyCapture[] {
  // Always load from localStorage to ensure persistence across page reloads
  // This merges in-memory captures (from current session) with persisted ones
  const fromStorage = loadCapturesFromStorage();
  
  // Merge: storage is authoritative, but add any in-memory ones not yet saved
  const storageIds = new Set(fromStorage.map(c => c.id));
  const unsaved = capturedSamples.filter(c => !storageIds.has(c.id));
  
  return [...fromStorage, ...unsaved];
}

export function loadCapturesFromStorage(): SeedKeyCapture[] {
  try {
    const stored = localStorage.getItem('seedkey_captures') || '[]';
    const parsed = JSON.parse(stored);
    return parsed.map((c: any) => ({
      ...c,
      seedBytes: new Uint8Array(c.seedBytes),
      keyBytes: new Uint8Array(c.keyBytes),
      csnBytes: c.csnBytes ? new Uint8Array(c.csnBytes) : undefined,
    }));
  } catch (e) {
    console.error('[CAPTURE] Failed to load from localStorage:', e);
    return [];
  }
}

// Initialize in-memory cache from localStorage on module load
function initializeCapturesFromStorage(): void {
  const stored = loadCapturesFromStorage();
  capturedSamples.length = 0;
  capturedSamples.push(...stored);
}

// Auto-initialize on module load (browser environment)
if (typeof window !== 'undefined') {
  initializeCapturesFromStorage();
}

export function clearCaptures(): void {
  capturedSamples.length = 0;
  try {
    localStorage.removeItem('seedkey_captures');
  } catch (e) {
    console.error('[CAPTURE] Failed to clear localStorage:', e);
  }
  console.log('[CAPTURE] All samples cleared');
}

export function exportCapturesToJSON(): string {
  const allCaptures = loadCapturesFromStorage();
  const exportData = {
    exportDate: new Date().toISOString(),
    tool: 'THAT ECM GUY - Seed/Key Capture',
    version: '1.0',
    sampleCount: allCaptures.length,
    samples: allCaptures.map(c => ({
      id: c.id,
      timestamp: c.timestamp,
      module: {
        code: c.moduleCode,
        name: c.moduleName,
        txId: `0x${c.txId.toString(16).toUpperCase()}`,
        rxId: `0x${c.rxId.toString(16).toUpperCase()}`,
      },
      security: {
        level: c.securityLevel,
        levelHex: `0x${c.securityLevel.toString(16).toUpperCase().padStart(2, '0')}`,
      },
      seed: {
        hex: c.seedHex,
        bytes: Array.from(c.seedBytes),
        length: c.seedBytes.length,
      },
      key: {
        hex: c.keyHex,
        bytes: Array.from(c.keyBytes),
        length: c.keyBytes.length,
      },
      csn: c.csnHex ? {
        hex: c.csnHex,
        bytes: c.csnBytes ? Array.from(c.csnBytes) : [],
      } : null,
      success: c.success,
      notes: c.notes,
    })),
  };
  return JSON.stringify(exportData, null, 2);
}

const VIN_DID = 0xF190;

/**
 * Parse VIN bytes from UDS response, filtering null bytes and non-printable characters
 * VIN should be exactly 17 alphanumeric characters (no I, O, Q)
 */
export function parseVINBytes(vinBytes: Uint8Array | number[]): string | null {
  let vin = '';
  for (let i = 0; i < Math.min(vinBytes.length, 20); i++) {
    const byte = typeof vinBytes[i] === 'number' ? vinBytes[i] : 0;
    // Only keep valid VIN characters: 0-9, A-Z (except I, O, Q)
    if (byte >= 0x30 && byte <= 0x39) {
      // Digits 0-9
      vin += String.fromCharCode(byte);
    } else if (byte >= 0x41 && byte <= 0x5A) {
      // Uppercase A-Z
      vin += String.fromCharCode(byte);
    } else if (byte >= 0x61 && byte <= 0x7A) {
      // Lowercase a-z - convert to uppercase
      vin += String.fromCharCode(byte - 32);
    }
    // Skip null bytes (0x00), padding (0xFF), and other non-printable chars
  }
  
  // VIN should be exactly 17 characters, but return partial VINs for debugging
  // This helps identify modules that respond with VIN data even if incomplete
  if (vin.length >= 10) {
    // Return VINs that are at least 10 characters (likely valid but truncated)
    console.log(`[parseVINBytes] Parsed VIN: "${vin}" (length: ${vin.length})`);
    return vin;
  } else if (vin.length > 0) {
    // Log partial VINs for debugging
    console.log(`[parseVINBytes] Partial VIN detected: "${vin}" (length: ${vin.length}) - too short, returning null`);
    return null;
  }
  
  // Return what we got if it's partial (for debugging)
  if (vin.length > 0) {
    console.log(`[VIN] Parsed VIN has ${vin.length} chars instead of 17: "${vin}"`);
    return vin;
  }
  
  return null;
}

const ISOTP_FRAME_TYPES = {
  SINGLE_FRAME: 0x00,
  FIRST_FRAME: 0x10,
  CONSECUTIVE_FRAME: 0x20,
  FLOW_CONTROL: 0x30,
};

const ISOTP_SINGLE_FRAME_MAX_DATA = 7;
const ISOTP_FIRST_FRAME_DATA = 6;
const ISOTP_CONSECUTIVE_FRAME_DATA = 7;
const CAN_FRAME_SIZE = 8;

export interface SerialPortInfo {
  port: SerialPort;
  info: {
    usbVendorId?: number;
    usbProductId?: number;
  };
  displayName: string;
}

// USB Vendor ID catalogs for auto-detection
export const ELM327_VENDOR_IDS = [
  0x0403,  // FTDI (most common for OBDLink EX, SX, MX+)
  0x067B,  // Prolific (common cheap clones)
  0x10C4,  // Silicon Labs (CP2102/CP2104)
  0x1A86,  // CH340/CH341 (cheap clones)
  0x0D28,  // OBDLink official
  0x0483,  // STMicroelectronics (some OBD adapters)
];

export const ARDUINO_VENDOR_IDS = [
  0x2341,  // Arduino official
  0x1A86,  // CH340 (Arduino clones)
  0x0403,  // FTDI (some Arduino boards)
  0x10C4,  // Silicon Labs (some Arduino boards)
];

export type AutoDetectResult = {
  status: 'found' | 'multiple' | 'none';
  port?: SerialPort;
  ports?: SerialPortInfo[];
  message: string;
};

// Auto-detect a device by hardware type
export async function autoDetectDevice(hardwareType: 'elm327' | 'arduino'): Promise<AutoDetectResult> {
  if (!('serial' in navigator)) {
    return { status: 'none', message: 'WebSerial not supported in this browser' };
  }

  try {
    const allPorts = await getPairedPorts();
    const vendorIds = hardwareType === 'elm327' ? ELM327_VENDOR_IDS : ARDUINO_VENDOR_IDS;
    
    // Filter ports by matching vendor IDs
    const matchingPorts = allPorts.filter(p => 
      p.info.usbVendorId && vendorIds.includes(p.info.usbVendorId)
    );

    if (matchingPorts.length === 0) {
      // No paired ports match - try to request a new one with filters
      console.log(`No paired ${hardwareType} devices found, requesting new port...`);
      try {
        const filters = vendorIds.map(vendorId => ({ usbVendorId: vendorId }));
        const newPort = await (navigator as any).serial.requestPort({ filters });
        if (newPort) {
          return { 
            status: 'found', 
            port: newPort, 
            message: `Found ${hardwareType.toUpperCase()} device` 
          };
        }
      } catch (e) {
        // User cancelled or no device found
        return { status: 'none', message: `No ${hardwareType.toUpperCase()} device found. Plug in your device and try again.` };
      }
      return { status: 'none', message: `No ${hardwareType.toUpperCase()} device found` };
    }

    if (matchingPorts.length === 1) {
      // Exactly one match - auto-connect
      console.log(`Auto-detected ${hardwareType}: ${matchingPorts[0].displayName}`);
      return { 
        status: 'found', 
        port: matchingPorts[0].port, 
        message: `Auto-detected: ${matchingPorts[0].displayName}` 
      };
    }

    // Multiple matches - need user to choose
    console.log(`Multiple ${hardwareType} devices found:`, matchingPorts.map(p => p.displayName));
    return { 
      status: 'multiple', 
      ports: matchingPorts, 
      message: `Found ${matchingPorts.length} devices - select one` 
    };
  } catch (e) {
    console.error('Auto-detect error:', e);
    return { status: 'none', message: 'Auto-detection failed' };
  }
}

// Get all already-paired ports
export async function getPairedPorts(): Promise<SerialPortInfo[]> {
  if (!('serial' in navigator)) return [];
  
  try {
    const ports = await (navigator as any).serial.getPorts();
    return ports.map((port: SerialPort, index: number) => {
      const info = (port as any).getInfo?.() || {};
      let displayName = `Port ${index + 1}`;
      
      // Try to identify common devices by USB IDs
      if (info.usbVendorId === 0x0403) displayName = `FTDI Device (Port ${index + 1})`;
      else if (info.usbVendorId === 0x067B) displayName = `Prolific (Port ${index + 1})`;
      else if (info.usbVendorId === 0x10C4) displayName = `Silicon Labs (Port ${index + 1})`;
      else if (info.usbVendorId === 0x1A86) displayName = `CH340 (Port ${index + 1})`;
      else if (info.usbVendorId === 0x2341) displayName = `Arduino (Port ${index + 1})`;
      else if (info.usbVendorId === 0x0D28) displayName = `OBDLink (Port ${index + 1})`;
      else if (info.usbVendorId) displayName = `USB ${info.usbVendorId.toString(16).toUpperCase()}:${(info.usbProductId || 0).toString(16).toUpperCase()} (Port ${index + 1})`;
      
      return { port, info, displayName };
    });
  } catch (e) {
    console.error('Failed to get paired ports:', e);
    return [];
  }
}

// Request a new port from user (triggers browser picker)
export async function requestNewPort(): Promise<SerialPort | null> {
  if (!('serial' in navigator)) return null;
  
  try {
    return await navigator.serial.requestPort();
  } catch (e) {
    console.log('Port request cancelled or failed:', e);
    return null;
  }
}

// Forget all paired ports
export async function forgetAllPorts(): Promise<number> {
  if (!('serial' in navigator)) return 0;
  
  try {
    const ports = await (navigator as any).serial.getPorts();
    let forgotten = 0;
    for (const port of ports) {
      try {
        await port.forget();
        forgotten++;
      } catch (e) {
        console.log('Could not forget port:', e);
      }
    }
    return forgotten;
  } catch (e) {
    console.error('Failed to forget ports:', e);
    return 0;
  }
}

export class ELM327Protocol {
  private port: SerialPort | null = null;
  private reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
  private writer: WritableStreamDefaultWriter<Uint8Array> | null = null;
  private lastError: string = '';
  private detectedProtocol: string = '';
  private protocolName: string = '';
  private keepaliveTimer: number | null = null;
  private keepaliveCanId: number = 0x7E0; // Default to PCM
  
  static isSupported(): boolean {
    return 'serial' in navigator;
  }
  private responseBuffer = '';
  
  getLastError(): string {
    return this.lastError;
  }

  // Connect to a specific port (bypasses browser picker)
  async connectToPort(port: SerialPort): Promise<boolean> {
    this.lastError = '';
    console.log('[ELM327] connectToPort: Starting connection...');
    try {
      // Clean up any existing connection first
      await this.disconnect();
      
      this.port = port;
      console.log('[ELM327] connectToPort: Port assigned, opening...');
      
      try {
        await safeOpenPort(this.port, 115200);
        console.log('[ELM327] connectToPort: Port opened successfully');
      } catch (e) {
        const err = e as any;
        this.lastError = `Port open failed: ${err.message || err}`;
        console.error('[ELM327] connectToPort: Failed to open port:', err.message || err);
        return false;
      }

      if (!this.port.readable || !this.port.writable) {
        this.lastError = 'Port streams not available after open';
        console.error('[ELM327] connectToPort: Port streams not available');
        return false;
      }

      this.reader = this.port.readable.getReader();
      this.writer = this.port.writable.getWriter();
      console.log('[ELM327] connectToPort: Reader and writer assigned');
      
      // CRITICAL: Verify reader/writer are actually set
      if (!this.reader || !this.writer) {
        console.error('[ELM327] connectToPort: CRITICAL - reader/writer are null after assignment!');
        this.lastError = 'Failed to create reader/writer';
        return false;
      }
      console.log('[ELM327] connectToPort: Reader/writer verified, initializing...');

      try {
        await this.initialize();
        console.log('[ELM327] connectToPort: ELM327 initialized successfully');
        console.log('[ELM327] connectToPort: Final check - reader:', !!this.reader, 'writer:', !!this.writer);
        return true;
      } catch (e) {
        const err = e as any;
        this.lastError = `ELM327 init failed: ${err.message || err}`;
        console.error('[ELM327] connectToPort: ELM327 initialization failed:', err.message || err);
        // DON'T disconnect on init failure - keep the port open!
        // await this.disconnect();
        return false;
      }
    } catch (error) {
      const err = error as any;
      this.lastError = `Connection error: ${err.message || err}`;
      console.error('ELM327 connection failed:', err.message || err);
      return false;
    }
  }
  
  async connect(): Promise<boolean> {
    this.lastError = '';
    try {
      if (!ELM327Protocol.isSupported()) {
        this.lastError = 'WebSerial not supported in this browser';
        console.error('WebSerial not supported in this browser');
        return false;
      }

      // Clean up any existing connection first
      await this.disconnect();

      try {
        this.port = await navigator.serial.requestPort();
      } catch (e) {
        const err = e as any;
        if (err.name === 'NotFoundError' || err.message?.includes('User cancelled')) {
          this.lastError = 'Port selection cancelled';
          console.log('User cancelled port selection');
        } else {
          this.lastError = `Port request failed: ${err.message || err}`;
          console.error('Port request failed:', err.message || err);
        }
        return false;
      }

      try {
        await safeOpenPort(this.port!, 115200);
      } catch (e) {
        const err = e as any;
        this.lastError = `Port open failed: ${err.message || err}`;
        console.error('Failed to open port:', err.message || err);
        return false;
      }

      if (!this.port!.readable || !this.port!.writable) {
        this.lastError = 'Port streams not available after open';
        console.error('Port streams not available');
        return false;
      }

      this.reader = this.port!.readable.getReader();
      this.writer = this.port!.writable.getWriter();

      try {
        await this.initialize();
        console.log('ELM327 initialized successfully');
        return true;
      } catch (e) {
        const err = e as any;
        this.lastError = `ELM327 init failed: ${err.message || err}`;
        console.error('ELM327 initialization failed:', err.message || err);
        await this.disconnect();
        return false;
      }
    } catch (error) {
      const err = error as any;
      this.lastError = `Connection error: ${err.message || err}`;
      console.error('ELM327 connection failed:', err.message || err);
      return false;
    }
  }
  
  async disconnect(): Promise<void> {
    // Stop keepalive first
    this.stopKeepalive();
    
    try {
      if (this.reader) {
        try {
          await this.reader.cancel();
          this.reader.releaseLock();
        } catch (e) {
          console.log('Reader cleanup error (ignored):', e);
        }
      }
      if (this.writer) {
        try {
          await this.writer.close();
        } catch (e) {
          console.log('Writer cleanup error (ignored):', e);
        }
      }
      if (this.port) {
        try {
          await this.port.close();
        } catch (e) {
          console.log('Port close error (ignored):', e);
        }
      }
    } catch (e) {
      console.log('Disconnect error (ignored):', e);
    } finally {
      this.port = null;
      this.reader = null;
      this.writer = null;
    }
  }
  
  async ping(): Promise<boolean> {
    if (!this.port || !this.writer || !this.reader) {
      return false;
    }
    
    try {
      const response = await this.sendCommand('ATI');
      return response.includes('ELM') || response.includes('STN') || response.length > 0;
    } catch {
      return false;
    }
  }
  
  private async initialize(): Promise<void> {
    await this.sendCommand('ATZ');      // Reset ELM327
    await this.delay(1000);
    await this.sendCommand('ATE0');     // Echo off
    await this.sendCommand('ATL0');     // Linefeeds off
    await this.sendCommand('ATS1');     // Spaces ON - required for response parsing!
    await this.sendCommand('ATH1');     // Headers on (show CAN IDs in response)
    await this.sendCommand('ATSP6');    // Protocol 6 = ISO 15765-4 CAN (11 bit, 500 kbps)
    await this.sendCommand('ATAT1');    // Adaptive timing auto
    await this.sendCommand('ATST64');   // Set timeout to 100 * 4ms = 400ms
    await this.sendCommand('ATCAF0');   // CAN Auto Formatting OFF - we handle ISO-TP framing manually
    
    // Query detected protocol
    const protocol = await this.sendCommand('ATDPN');
    this.detectedProtocol = protocol.trim();
    this.protocolName = this.getProtocolName(this.detectedProtocol);
    console.log('ELM327 initialized: Protocol 6 (CAN 500kbps), Spaces ON, Headers ON, CAF OFF');
  }
  
  private getProtocolName(protocolNum: string): string {
    const protocols: Record<string, string> = {
      '0': 'Auto',
      '1': 'SAE J1850 PWM',
      '2': 'SAE J1850 VPW',
      '3': 'ISO 9141-2',
      '4': 'ISO 14230-4 KWP (5 baud init)',
      '5': 'ISO 14230-4 KWP (fast init)',
      '6': 'ISO 15765-4 CAN (11-bit 500kbps)',
      '7': 'ISO 15765-4 CAN (29-bit 500kbps)',
      '8': 'ISO 15765-4 CAN (11-bit 250kbps)',
      '9': 'ISO 15765-4 CAN (29-bit 250kbps)',
      'A': 'SAE J1939 CAN',
      'B': 'USER1 CAN',
      'C': 'USER2 CAN'
    };
    return protocols[protocolNum] || `Unknown (${protocolNum})`;
  }
  
  getProtocolInfo(): { number: string; name: string } {
    return {
      number: this.detectedProtocol,
      name: this.protocolName
    };
  }
  
  async testCommunication(): Promise<{ success: boolean; message: string; responseTime: number }> {
    const startTime = Date.now();
    try {
      // Send Mode 01 PID 00 (Supported PIDs 01-20)
      const response = await this.sendCommand('0100');
      const responseTime = Date.now() - startTime;
      
      if (response.includes('NO DATA') || response.includes('?') || response.includes('ERROR')) {
        return {
          success: false,
          message: `ELM327 responding but vehicle not communicating: ${response}`,
          responseTime
        };
      }
      
      if (response.includes('41 00')) {
        return {
          success: true,
          message: `Vehicle responding on ${this.protocolName}`,
          responseTime
        };
      }
      
      return {
        success: true,
        message: `Response received: ${response.substring(0, 50)}`,
        responseTime
      };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      return {
        success: false,
        message: `Communication failed: ${error instanceof Error ? error.message : String(error)}`,
        responseTime
      };
    }
  }
  
  async sendCommand(cmd: string): Promise<string> {
    if (!this.writer || !this.reader) {
      throw new Error('Not connected');
    }
    
    const encoder = new TextEncoder();
    await this.writer.write(encoder.encode(cmd + '\r'));
    
    return this.readResponse();
  }
  
  private async readResponse(): Promise<string> {
    if (!this.reader) throw new Error('No reader');
    
    const decoder = new TextDecoder();
    let response = '';
    const timeout = Date.now() + 2000; // Balanced timeout for scanning
    
    while (Date.now() < timeout) {
      const { value, done } = await this.reader.read();
      if (done) break;
      
      response += decoder.decode(value);
      if (response.includes('>')) {
        return response.replace(/>/g, '').trim();
      }
    }
    
    return response.trim();
  }
  
  async setHeader(txId: number): Promise<void> {
    const header = txId.toString(16).toUpperCase().padStart(3, '0');
    await this.sendCommand(`ATSH${header}`);
  }
  
  async setReceiveAddress(rxId: number): Promise<void> {
    const addr = rxId.toString(16).toUpperCase().padStart(3, '0');
    await this.sendCommand(`ATCRA${addr}`);
  }

  buildISOTPSingleFrame(data: number[]): number[] {
    if (data.length > ISOTP_SINGLE_FRAME_MAX_DATA) {
      throw new Error(`Data too long for single frame: ${data.length} > ${ISOTP_SINGLE_FRAME_MAX_DATA}`);
    }
    const frame: number[] = [];
    frame.push(ISOTP_FRAME_TYPES.SINGLE_FRAME | data.length);
    frame.push(...data);
    while (frame.length < CAN_FRAME_SIZE) {
      frame.push(0x00);
    }
    return frame;
  }

  buildISOTPMultiFrame(data: number[]): number[][] {
    const frames: number[][] = [];
    const totalLength = data.length;

    const firstFrame: number[] = [];
    firstFrame.push(ISOTP_FRAME_TYPES.FIRST_FRAME | ((totalLength >> 8) & 0x0F));
    firstFrame.push(totalLength & 0xFF);
    const firstFrameData = data.slice(0, ISOTP_FIRST_FRAME_DATA);
    firstFrame.push(...firstFrameData);
    while (firstFrame.length < CAN_FRAME_SIZE) {
      firstFrame.push(0x00);
    }
    frames.push(firstFrame);

    let remainingData = data.slice(ISOTP_FIRST_FRAME_DATA);
    let sequenceNumber = 1;

    while (remainingData.length > 0) {
      const cfFrame: number[] = [];
      cfFrame.push(ISOTP_FRAME_TYPES.CONSECUTIVE_FRAME | (sequenceNumber & 0x0F));
      const chunk = remainingData.slice(0, ISOTP_CONSECUTIVE_FRAME_DATA);
      cfFrame.push(...chunk);
      while (cfFrame.length < CAN_FRAME_SIZE) {
        cfFrame.push(0x00);
      }
      frames.push(cfFrame);
      
      remainingData = remainingData.slice(ISOTP_CONSECUTIVE_FRAME_DATA);
      sequenceNumber = (sequenceNumber + 1) & 0x0F;
    }

    return frames;
  }

  parseISOTPResponse(rawBytes: number[]): number[] {
    if (rawBytes.length === 0) return [];
    
    const pciType = rawBytes[0] & 0xF0;
    
    if (pciType === ISOTP_FRAME_TYPES.SINGLE_FRAME) {
      const length = rawBytes[0] & 0x0F;
      return rawBytes.slice(1, 1 + length);
    }
    
    if (pciType === ISOTP_FRAME_TYPES.FIRST_FRAME) {
      const length = ((rawBytes[0] & 0x0F) << 8) | rawBytes[1];
      return rawBytes.slice(2, 2 + Math.min(length, rawBytes.length - 2));
    }
    
    if (pciType === ISOTP_FRAME_TYPES.CONSECUTIVE_FRAME) {
      return rawBytes.slice(1);
    }
    
    return rawBytes;
  }

  async waitForFlowControl(txId: number, rxId: number): Promise<{ blockSize: number; stMin: number } | null> {
    await this.setHeader(txId);
    await this.setReceiveAddress(rxId);
    
    const response = await this.readMultipleResponses(1000);
    if (!response || response.length === 0) return null;
    
    const lines = response.split('\n').filter(l => l.trim().length > 0);
    for (const line of lines) {
      const bytes = line.split(/\s+/)
        .filter(s => /^[0-9A-Fa-f]{2}$/.test(s))
        .map(s => parseInt(s, 16));
      
      if (bytes.length > 0 && (bytes[0] & 0xF0) === ISOTP_FRAME_TYPES.FLOW_CONTROL) {
        const flowStatus = bytes[0] & 0x0F;
        if (flowStatus === 0) {
          return {
            blockSize: bytes[1] || 0,
            stMin: bytes[2] || 0,
          };
        }
        if (flowStatus === 1) {
          await this.delay(50);
          return this.waitForFlowControl(txId, rxId);
        }
        return null;
      }
    }
    
    return null;
  }

  private async readMultipleResponses(timeoutMs: number): Promise<string> {
    if (!this.reader) throw new Error('No reader');
    
    const decoder = new TextDecoder();
    let response = '';
    const timeout = Date.now() + timeoutMs;
    let lastDataTime = Date.now();
    const interFrameTimeout = 500; // Wait 500ms after last data for all consecutive frames (increased for slower modules)
    let promptSeen = false;
    
    while (Date.now() < timeout) {
      const { value, done } = await this.reader.read();
      if (done) break;
      
      if (value && value.length > 0) {
        const chunk = decoder.decode(value);
        response += chunk;
        lastDataTime = Date.now();
        
        // Track if we've seen the prompt
        if (chunk.includes('>')) {
          promptSeen = true;
        }
      }
      
      // Only return after we've seen the prompt AND waited for inter-frame timeout
      // This ensures all consecutive frames (0x21, 0x22, 0x23) have arrived
      if (promptSeen && (Date.now() - lastDataTime) > interFrameTimeout) {
        return response.replace(/>/g, '').trim();
      }
      
      // Small delay to allow more frames to arrive
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    
    return response.trim();
  }

  async readMultiFrameResponse(rxId: number, expectedLength: number): Promise<number[]> {
    const allData: number[] = [];
    let framesReceived = 0;
    const maxFrames = Math.ceil((expectedLength - ISOTP_FIRST_FRAME_DATA) / ISOTP_CONSECUTIVE_FRAME_DATA) + 1;
    
    while (allData.length < expectedLength && framesReceived < maxFrames) {
      const response = await this.readMultipleResponses(1000);
      if (!response) break;
      
      const lines = response.split('\n').filter(l => l.trim().length > 0);
      for (const line of lines) {
        const bytes = line.split(/\s+/)
          .filter(s => /^[0-9A-Fa-f]{2}$/.test(s))
          .map(s => parseInt(s, 16));
        
        if (bytes.length === 0) continue;
        
        const pciType = bytes[0] & 0xF0;
        
        if (pciType === ISOTP_FRAME_TYPES.CONSECUTIVE_FRAME) {
          allData.push(...bytes.slice(1));
          framesReceived++;
        }
      }
    }
    
    return allData.slice(0, expectedLength);
  }
  
  async sendUDS(txId: number, rxId: number, data: number[], retries: number = 3): Promise<Uint8Array | null> {
    console.log(`[ELM327] sendUDS called with ${retries} retries`);
    for (let attempt = 0; attempt <= retries; attempt++) {
      console.log(`[ELM327] Starting attempt ${attempt}/${retries}`);
      try {
        // Exponential backoff: longer delays for BCM communication
        const baseDelay = 300; // Increased from 150ms
        const retryDelay = baseDelay * Math.pow(2, attempt); // 300ms, 600ms, 1200ms, 2400ms
        
        if (attempt > 0) {
          console.log(`[ELM327] Retry attempt ${attempt}/${retries} with ${retryDelay}ms delay`);
          // Just add a delay between retries - no expensive reset for scanning
          await new Promise(resolve => setTimeout(resolve, retryDelay));
        }
        
        await this.setHeader(txId);
        await new Promise(resolve => setTimeout(resolve, 50)); // Minimal delay after header
        await this.setReceiveAddress(rxId);
        await new Promise(resolve => setTimeout(resolve, 50)); // Minimal delay after receive address
        
        return await this.sendUDSInternal(data);
      } catch (error) {
        console.log(`[ELM327] Caught error in sendUDS:`, error);
        const errorMsg = error instanceof Error ? error.message : String(error);
        console.log(`[ELM327] Error message: ${errorMsg}, attempt: ${attempt}, retries: ${retries}`);
        if ((errorMsg.includes('FRAMING') || errorMsg.includes('ERROR') || errorMsg.includes('NO DATA')) && attempt < retries) {
          console.log(`[ELM327] Communication error (${errorMsg}), will retry ${attempt + 1}/${retries}`);
          continue;
        }
        console.log(`[ELM327] Throwing error - no more retries`);
        throw error;
      }
    }
    return null;
  }
  
  private async sendUDSInternal(data: number[]): Promise<Uint8Array | null> {
    const startTime = Date.now();
    
    let hexData: string;
    
    // With ATCAF1, send raw UDS data - ELM327 handles ISO-TP framing automatically
    // Just convert the data bytes to hex string
    hexData = data.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
    
    // CRITICAL FIX: ELM327 does NOT automatically send flow control for multi-frame responses
    // We must manually send 0x30 (flow control) after receiving first frame (0x10)
    
    console.log(`[HW-TEST] ========== UDS REQUEST START ==========`);
    console.log(`[HW-TEST] TX Data: ${hexData} (${data.length} bytes)`);
    console.log(`[HW-TEST] Timestamp: ${new Date().toISOString()}`);
    
    const response = await this.sendCommand(hexData);
    const txTime = Date.now() - startTime;
    
    console.log(`[HW-TEST] RX Response: "${response}"`);
    console.log(`[HW-TEST] TX->RX Time: ${txTime}ms`);
    console.log(`[HW-TEST] Response Length: ${response.length} chars`);
    
    if (response.includes('NO DATA') || response.includes('?')) {
      console.log(`[HW-TEST] NO DATA received`);
      throw new Error(`NO DATA`);
    }
    
    if (response.includes('ERROR') || response.includes('FRAMING')) {
      console.log(`[HW-TEST] ELM327 error: ${response}`);
      throw new Error(`ELM327 error: ${response}`);
    }
    
    // Check if this is a multi-frame response that's INCOMPLETE
    // The ELM327 with ATH1 may return all frames together OR just the first frame
    // Frames can be separated by newlines OR spaces, with CAN IDs marking frame boundaries
    
    // Split response into tokens (spaces and newlines)
    const allTokens = response.split(/[\s\n]+/).filter(t => t.length > 0);
    console.log(`[HW-TEST] Total Tokens in Response: ${allTokens.length}`);
    
    // Find all CAN ID positions (3-digit hex: 7E8, 7E9, 4C0, etc.)
    const canIdPattern = /^[0-9A-Fa-f]{3}$/;
    const frameStarts: number[] = [];
    allTokens.forEach((token, idx) => {
      if (canIdPattern.test(token)) {
        frameStarts.push(idx);
      }
    });
    
    console.log(`[HW-TEST] Found ${frameStarts.length} CAN frames at positions: [${frameStarts.join(', ')}]`);
    
    // Extract individual frames
    const allFrames: string[][] = [];
    for (let i = 0; i < frameStarts.length; i++) {
      const start = frameStarts[i];
      const end = i + 1 < frameStarts.length ? frameStarts[i + 1] : allTokens.length;
      const frameTokens = allTokens.slice(start, end);
      allFrames.push(frameTokens);
    }
    
    console.log(`[HW-TEST] Parsed ${allFrames.length} complete frames`);
    
    // Check if we have consecutive frames already (0x21, 0x22, 0x23)
    const hasConsecutiveFrames = allFrames.some(frameTokens => {
      if (frameTokens.length >= 2) {
        const firstByte = parseInt(frameTokens[1], 16);
        const pciType = (firstByte & 0xF0) >> 4;
        return pciType === 0x02; // 0x21, 0x22, 0x23 = consecutive frames
      }
      return false;
    });
    
    console.log(`[HW-TEST] Consecutive frames already present: ${hasConsecutiveFrames}`);
    
    if (allFrames.length > 0) {
      const firstFrame = allFrames[0];
      console.log(`[HW-TEST] First Frame: [${firstFrame.join(' ')}]`);
      
      if (firstFrame.length >= 2) {
        const firstByte = parseInt(firstFrame[1], 16);
        const pciType = (firstByte & 0xF0) >> 4;
        const dataLength = firstByte & 0x0F;
        
        console.log(`[HW-TEST] First Byte: 0x${firstByte.toString(16).toUpperCase().padStart(2, '0')}`);
        console.log(`[HW-TEST] PCI Type: 0x${pciType.toString(16)} (${pciType === 0x00 ? 'Single Frame' : pciType === 0x01 ? 'First Frame' : pciType === 0x02 ? 'Consecutive Frame' : pciType === 0x03 ? 'Flow Control' : 'Unknown'})`);
        console.log(`[HW-TEST] Data Length: ${dataLength} bytes`);
        
        // Only send flow control if this is a first frame AND consecutive frames are NOT already present
        if (pciType === 0x01 && !hasConsecutiveFrames) {
          // Multi-frame response detected but incomplete - send flow control
          console.log(`[HW-TEST] Multi-frame detected WITHOUT consecutive frames, sending flow control...`);
          
          const fcStartTime = Date.now();
          // Send flow control: 0x30 0x00 0x00 (continue to send, no delay)
          const encoder = new TextEncoder();
          if (!this.writer) throw new Error('No writer');
          await this.writer.write(encoder.encode('300000\r'));
          
          // Wait longer for all consecutive frames to arrive (500ms inter-frame timeout)
          const flowControlResponse = await this.readMultipleResponses(3000); // 3 second total timeout
          const fcTime = Date.now() - fcStartTime;
          
          console.log(`[HW-TEST] Flow Control Sent: 0x300000`);
          console.log(`[HW-TEST] FC RX Response: "${flowControlResponse}"`);
          console.log(`[HW-TEST] FC Time: ${fcTime}ms`);
          
          // Log consecutive frames for debugging
          const fcLines = flowControlResponse.split('\n').filter(l => l.trim().length > 0);
          console.log(`[HW-TEST] Consecutive Frame Lines Received: ${fcLines.length}`);
          fcLines.forEach((line, idx) => {
            console.log(`[HW-TEST]   CF[${idx}]: "${line}"`);
          });
          
          // Combine original response with flow control response
          const combinedResponse = response + '\n' + flowControlResponse;
          
          console.log(`[HW-TEST] Combined Response Length: ${combinedResponse.length} chars`);
          console.log(`[HW-TEST] Total Time: ${Date.now() - startTime}ms`);
          console.log(`[HW-TEST] ========== UDS REQUEST END ==========`);
          
          return this.parseELM327Response(combinedResponse);
        } else if (pciType === 0x01 && hasConsecutiveFrames) {
          // Multi-frame response but all frames already present - no flow control needed
          console.log(`[HW-TEST] Multi-frame response complete (all frames already present)`);
          console.log(`[HW-TEST] Total Time: ${Date.now() - startTime}ms`);
          console.log(`[HW-TEST] ========== UDS REQUEST END ==========`);
          
          return this.parseELM327Response(response);
        }
      }
    }
    
    console.log(`[HW-TEST] Single frame response`);
    console.log(`[HW-TEST] Total Time: ${Date.now() - startTime}ms`);
    console.log(`[HW-TEST] ========== UDS REQUEST END ==========`);
    
    // Single frame or already complete - parse normally
    return this.parseELM327Response(response);
  }
  
  /**
   * Parse ELM327 response with CAN headers (single or multi-frame)
   * Handles both newline-separated AND space-separated frame formats
   */
  private parseELM327Response(response: string): Uint8Array | null {
    // Parse response that may have frames separated by newlines OR spaces
    // Example formats:
    // Format 1 (newline-separated): "7E8 10 14 62 F1 90\n7E8 21 43 44 58\n7E8 22 48 35 39"
    // Format 2 (space-separated):   "7E8 10 14 62 F1 90 7E8 21 43 44 58 7E8 22 48 35 39"
    
    // Split into tokens and find CAN ID boundaries
    const allTokens = response.split(/[\s\n]+/).filter(t => t.length > 0);
    const canIdPattern = /^[0-9A-Fa-f]{3}$/;
    const frameStarts: number[] = [];
    
    allTokens.forEach((token, idx) => {
      if (canIdPattern.test(token)) {
        frameStarts.push(idx);
      }
    });
    
    // Extract frames as byte arrays
    const allFrames: number[][] = [];
    for (let i = 0; i < frameStarts.length; i++) {
      const start = frameStarts[i];
      const end = i + 1 < frameStarts.length ? frameStarts[i + 1] : allTokens.length;
      // Skip CAN ID (first token), take only data bytes
      const dataBytes = allTokens.slice(start + 1, end)
        .filter(s => /^[0-9A-Fa-f]{2}$/.test(s))
        .map(s => parseInt(s, 16));
      
      if (dataBytes.length > 0) {
        allFrames.push(dataBytes);
      }
    }
    
    if (allFrames.length === 0) return null;
    
    // Check if this is a multi-frame ISO-TP response
    const firstFrame = allFrames[0];
    if (firstFrame.length === 0) return null;
    
    const pciType = (firstFrame[0] & 0xF0) >> 4;
    
    console.log(`[parseELM327] Processing ${allFrames.length} frames, first PCI type: 0x${pciType.toString(16)}`);
    
    if (pciType === 0x01) {
      // Multi-frame response: 0x10 = first frame
      // Format: [10 LL DD DD DD DD DD DD] where LL = total length
      const totalLength = ((firstFrame[0] & 0x0F) << 8) | firstFrame[1];
      const allData: number[] = [];
      
      console.log(`[parseELM327] Multi-frame response, total length: ${totalLength} bytes`);
      
      // First frame data starts at byte 2
      allData.push(...firstFrame.slice(2));
      console.log(`[parseELM327] First frame data: ${firstFrame.slice(2).length} bytes`);
      
      // Process consecutive frames (0x21, 0x22, 0x23, ...)
      for (let i = 1; i < allFrames.length; i++) {
        const frame = allFrames[i];
        const framePci = (frame[0] & 0xF0) >> 4;
        
        console.log(`[parseELM327] Frame ${i}: PCI=0x${framePci.toString(16)}, bytes=${frame.length}`);
        
        if (framePci === 0x02) {
          // Consecutive frame: data starts at byte 1
          allData.push(...frame.slice(1));
          console.log(`[parseELM327] Added ${frame.slice(1).length} bytes from consecutive frame`);
        }
      }
      
      console.log(`[parseELM327] Total data collected: ${allData.length} bytes, trimming to ${totalLength}`);
      
      // Trim to exact length
      return new Uint8Array(allData.slice(0, totalLength));
    } else if (pciType === 0x00) {
      // Single frame response: 0x0L where L = length
      const length = firstFrame[0] & 0x0F;
      console.log(`[parseELM327] Single frame response, length: ${length} bytes`);
      return new Uint8Array(firstFrame.slice(1, 1 + length));
    } else {
      // Unknown PCI type or already stripped by ATCAF1
      console.log(`[parseELM327] Unknown PCI type, returning raw frame data`);
      return new Uint8Array(firstFrame);
    }
  }
  
  async readVIN(txId: number, rxId: number): Promise<string | null> {
    const request = [UDS_SERVICES.READ_DATA_BY_ID, (VIN_DID >> 8) & 0xFF, VIN_DID & 0xFF];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response || response.length < 4) return null;
    
    if (response[0] === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
      // Use the parseVINBytes helper to properly filter null bytes and non-printable chars
      const vinBytes = response.slice(3);
      return parseVINBytes(vinBytes);
    }
    
    return null;
  }
  
  async writeVIN(txId: number, rxId: number, vin: string): Promise<boolean> {
    if (vin.length !== 17) return false;
    
    const vinBytes: number[] = [];
    for (let i = 0; i < vin.length; i++) {
      vinBytes.push(vin.charCodeAt(i));
    }
    const request = [UDS_SERVICES.WRITE_DATA_BY_ID, (VIN_DID >> 8) & 0xFF, VIN_DID & 0xFF].concat(vinBytes);
    
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) return false;
    
    return response[0] === (UDS_SERVICES.WRITE_DATA_BY_ID + 0x40);
  }
  
  /**
   * Complete VIN programming flow with security access
   * @param txId - CAN TX ID
   * @param rxId - CAN RX ID  
   * @param newVIN - 17-character VIN to write
   * @param onProgress - Progress callback with status updates
   * @param options - Optional configuration (securityLevel, programmingTimeout)
   * @returns Success status and detailed result
   */
  async programVIN(
    txId: number,
    rxId: number,
    newVIN: string,
    onProgress?: (step: string, progress: number) => void,
    options?: { securityLevel?: number; programmingTimeout?: number }
  ): Promise<{ success: boolean; message: string; details?: any }> {
    try {
      // Check hardware connection FIRST
      if (!this.port || !this.isConnected) {
        return { 
          success: false, 
          message: 'No hardware connected - please connect OBD2 adapter first' 
        };
      }
      
      // Validate VIN
      if (newVIN.length !== 17) {
        return { success: false, message: 'VIN must be exactly 17 characters' };
      }
      
      // Auto-detect BCM address if standard BCM IDs are provided
      let detectedTxId = txId;
      let detectedRxId = rxId;
      let addressName = 'Provided';
      
      // If user provided a standard BCM address, try all 3 to find which one responds
      const isBCMAddress = [0x6B0, 0x750, 0x7E0].includes(txId);
      if (isBCMAddress) {
        onProgress?.('Auto-detecting BCM address...', 5);
        const BCM_ADDRESSES = [
          { tx: 0x6B0, rx: 0x6B8, name: 'CAN-IHS (Original SRT Lab Toolkit)' },
          { tx: 0x750, rx: 0x758, name: 'CAN-C (Shared DB)' },
          { tx: 0x7E0, rx: 0x7E8, name: 'OBD2 Standard' },
        ];
        
        console.log(`[VIN Programming] Testing all 3 BCM addresses...`);
        for (const addr of BCM_ADDRESSES) {
          try {
            const testVIN = await this.readVIN(addr.tx, addr.rx);
            if (testVIN && testVIN.length === 17) {
              detectedTxId = addr.tx;
              detectedRxId = addr.rx;
              addressName = addr.name;
              console.log(`[VIN Programming] BCM found at 0x${addr.tx.toString(16).toUpperCase()} (${addr.name})`);
              break;
            }
          } catch (err) {
            console.log(`[VIN Programming] No response at 0x${addr.tx.toString(16).toUpperCase()}`);
          }
        }
        
        if (detectedTxId === txId && detectedRxId === rxId) {
          return { success: false, message: 'BCM not responding at any of the 3 known addresses' };
        }
      }
      
      onProgress?.(`Reading current VIN (at 0x${detectedTxId.toString(16).toUpperCase()} - ${addressName})...`, 10);
      const currentVIN = await this.readVIN(detectedTxId, detectedRxId);
      console.log(`[VIN Programming] Current VIN: ${currentVIN || 'Not readable'}`);
      
      // Use detected address for all subsequent operations
      txId = detectedTxId;
      rxId = detectedRxId;
      
      // Step 1: Start Extended Diagnostic Session (0x10 03)
      onProgress?.('Starting diagnostic session...', 20);
      const sessionStarted = await this.startDiagnosticSession(txId, rxId, 0x03);
      if (!sessionStarted) {
        return { success: false, message: 'Failed to start diagnostic session' };
      }
      console.log(`[VIN Programming] Diagnostic session started`);
      
      // Step 2: Request Seed (Service 27 01/05 based on module configuration)
      onProgress?.('Requesting security seed...', 30);
      const seedLevel = options?.securityLevel ?? 0x01; // Use module-specific level or default to Level 1
      console.log(`[VIN Programming] Using Security Access Level: 0x${seedLevel.toString(16).padStart(2, '0')}`);
      const seedRequest = [UDS_SERVICES.SECURITY_ACCESS, seedLevel];
      const seedResponse = await this.sendUDS(txId, rxId, seedRequest);
      
      if (!seedResponse || seedResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
        return { success: false, message: 'Failed to get security seed', details: { seedResponse } };
      }
      
      const seed = seedResponse.slice(2); // Skip service byte and level byte
      console.log(`[VIN Programming] Received seed: ${Array.from(seed).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
      
      // Step 3: Calculate Key using AlphaOBD algorithms
      onProgress?.('Calculating security key...', 50);
      
      let key: Uint8Array | null = null;
      let algorithm = 'Unknown';
      
      // Check if this is RFHUB (CAN IDs 0x740/0x748 or 0x75F/0x767 or 0x742/0x74A)
      const isRFHUB = (txId === 0x740 || txId === 0x75F || txId === 0x767 || txId === 0x742);
      
      // Try Shift-XOR algorithm for RFHUB (4-byte seed)
      if (isRFHUB && seed.length === 4) {
        console.log(`[HW-TEST] 🔑 Detected RFHUB module - using Shift-XOR algorithm (4-byte seed)...`);
        const { calculateRFHUBShiftXOR, getRFHUBSecurityConstant } = await import('../../../shared/fca-keygen');
        
        // Read current VIN to determine security constant
        // For blank RFHUB (VIN = 00000000000000000), use constant = 0
        const vinBytes = await this.readVIN(txId, rxId);
        const vin = vinBytes ? new TextDecoder().decode(vinBytes) : '00000000000000000';
        const constant = getRFHUBSecurityConstant(vin);
        
        console.log(`[HW-TEST] RFHUB VIN: ${vin}`);
        console.log(`[HW-TEST] Security Constant: 0x${constant.toString(16).padStart(8, '0')}`);
        
        key = calculateRFHUBShiftXOR(seed, constant);
        algorithm = `Shift-XOR (32-bit, constant=0x${constant.toString(16).padStart(8, '0')})`;
        console.log(`[HW-TEST] Shift-XOR Key: ${Array.from(key).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
      }
      // Try ROL5+XOR (most common for 2010-2017)
      else if (seed.length === 2) {
        console.log(`[HW-TEST] 🔑 Trying ROL5+XOR algorithm (2-byte seed)...`);
        const CDA_CONSTANT = 0x4B92; // Level 1 constant for CDA Engineering
        const seedValue = (seed[0] << 8) | seed[1];
        const rotated = ((seedValue << 5) | (seedValue >> 11)) & 0xFFFF;
        const keyValue = rotated ^ CDA_CONSTANT;
        key = new Uint8Array([(keyValue >> 8) & 0xFF, keyValue & 0xFF]);
        algorithm = 'ROL5+XOR (Legacy 2010-2017)';
        console.log(`[HW-TEST] ROL5+XOR Key: ${Array.from(key).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
      }
      // Try Atlantis algorithm (2018+)
      else if (seed.length === 4 || seed.length === 5) {
        console.log(`[HW-TEST] 🔑 Trying Atlantis algorithm (${seed.length}-byte seed)...`);
        
        // Read CSN (Control Serial Number) for Atlantis
        console.log(`[HW-TEST] Reading CSN (DID 0xF18C)...`);
        const csn = await this.readCSN(txId, rxId);
        
        if (csn && csn.length === 5) {
          console.log(`[HW-TEST] CSN: ${Array.from(csn).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
          
          // Import Atlantis algorithm
          const { calculateAtlantisKey } = await import('../../../shared/seed-key-algorithms');
          
          // Atlantis uses 4-byte seed + 5-byte CSN
          const seed4 = seed.length === 5 ? seed.slice(0, 4) : seed;
          key = calculateAtlantisKey(seed4, csn);
          algorithm = 'Atlantis AES-128 (2018-2024)';
          console.log(`[HW-TEST] Atlantis Key: ${Array.from(key).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
        } else {
          console.log(`[HW-TEST] ⚠️ CSN read failed, falling back to ROL5+XOR`);
          // Fallback to ROL5+XOR with first 2 bytes
          const CDA_CONSTANT = 0x4B92;
          const seedValue = (seed[0] << 8) | seed[1];
          const rotated = ((seedValue << 5) | (seedValue >> 11)) & 0xFFFF;
          const keyValue = rotated ^ CDA_CONSTANT;
          key = new Uint8Array([(keyValue >> 8) & 0xFF, keyValue & 0xFF]);
          algorithm = 'ROL5+XOR (Fallback)';
          console.log(`[HW-TEST] Fallback Key: ${Array.from(key).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
        }
      }
      
      if (!key) {
        return { 
          success: false, 
          message: `Unsupported seed length: ${seed.length} bytes`, 
          details: { seed } 
        };
      }
      
      console.log(`[VIN Programming] Algorithm: ${algorithm}`);
      console.log(`[VIN Programming] Calculated key: ${Array.from(key).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
      
      // Step 4: Send Key (Service 27 02/06 based on seed level)
      onProgress?.(`Sending security key (${algorithm})...`, 60);
      const keyLevel = seedLevel + 1; // Response level is seed level + 1
      const keyRequest = [UDS_SERVICES.SECURITY_ACCESS, keyLevel, ...Array.from(key)];
      const keyResponse = await this.sendUDS(txId, rxId, keyRequest);
      
      if (!keyResponse) {
        console.log(`[HW-TEST] No response received`);
        return { 
          success: false, 
          message: 'No response from module', 
          details: { algorithm, seed, key } 
        };
      }
      
      console.log(`[HW-TEST] Security Key Response: ${Array.from(keyResponse).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
      
      if (keyResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
        // Check for negative response
        if (keyResponse && keyResponse[0] === 0x7F) {
          const nrc = keyResponse[2];
          const nrcMessages: Record<number, string> = {
            0x12: 'SubFunctionNotSupported',
            0x13: 'IncorrectMessageLengthOrInvalidFormat',
            0x22: 'ConditionsNotCorrect',
            0x24: 'RequestSequenceError',
            0x31: 'RequestOutOfRange',
            0x33: 'SecurityAccessDenied',
            0x35: 'InvalidKey',
            0x36: 'ExceededNumberOfAttempts',
            0x37: 'RequiredTimeDelayNotExpired'
          };
          const nrcMsg = nrcMessages[nrc] || `Unknown NRC 0x${nrc.toString(16)}`;
          console.log(`[HW-TEST] Negative Response Code: ${nrcMsg}`);
          
          return { 
            success: false, 
            message: `Security access denied: ${nrcMsg}`, 
            details: { algorithm, seed, key, nrc, keyResponse } 
          };
        }
        
        return { 
          success: false, 
          message: 'Security access denied - invalid key', 
          details: { algorithm, seed, key, keyResponse } 
        };
      }
      
      console.log(`[VIN Programming] Security access granted using ${algorithm}`);
      
      // Step 5: Write VIN (Service 2E F190 + VIN bytes)
      onProgress?.(`Writing new VIN (secured with ${algorithm})...`, 80);
      const writeSuccess = await this.writeVIN(txId, rxId, newVIN);
      
      if (!writeSuccess) {
        return { success: false, message: 'VIN write failed' };
      }
      
      console.log(`[VIN Programming] VIN write successful`);
      
      // Step 6: Verify VIN
      onProgress?.('Verifying VIN...', 90);
      await new Promise(resolve => setTimeout(resolve, 500)); // Give module time to save
      const verifyVIN = await this.readVIN(txId, rxId);
      
      if (verifyVIN !== newVIN) {
        return { 
          success: false, 
          message: `VIN verification failed: Expected ${newVIN}, got ${verifyVIN}`,
          details: { written: newVIN, readBack: verifyVIN }
        };
      }
      
      onProgress?.('Complete!', 100);
      return { 
        success: true, 
        message: `VIN successfully programmed: ${newVIN}`,
        details: { oldVIN: currentVIN, newVIN: verifyVIN }
      };
      
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      console.error(`[VIN Programming] Error:`, error);
      return { success: false, message: `Programming failed: ${errorMsg}` };
    }
  }
  
  // Read CSN (Control Serial Number) for Atlantis 2018+ 5-byte algorithm
  async readCSN(txId: number, rxId: number): Promise<Uint8Array | null> {
    const request = [UDS_SERVICES.READ_DATA_BY_ID, (CSN_DID >> 8) & 0xFF, CSN_DID & 0xFF];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) return null;
    
    // Positive response: 0x62 [DID High] [DID Low] [CSN bytes...]
    if (response[0] === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
      // CSN is typically 5 bytes starting after DID
      return response.slice(3);
    }
    
    return null;
  }
  
  async securityAccess(txId: number, rxId: number, level: number, keyCalculator: (seed: Uint8Array) => Uint8Array, retries: number = 3, moduleInfo?: { code: string; name: string }): Promise<boolean> {
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        // Ensure we're in extended diagnostic session first
        if (attempt > 0) {
          await this.startDiagnosticSession(txId, rxId, 0x03);
          await this.delay(100);
        }
        
        // Request seed
        const seedRequest = [UDS_SERVICES.SECURITY_ACCESS, level];
        const seedResponse = await this.sendUDS(txId, rxId, seedRequest);
        
        if (!seedResponse) {
          if (attempt < retries - 1) await this.delay(500);
          continue;
        }
        
        // Check for negative response (0x7F)
        if (seedResponse[0] === 0x7F) {
          const errorCode = seedResponse[2];
          // NRC 0x78 = Response Pending - wait longer and retry
          if (errorCode === 0x78) { 
            await this.delay(1000); 
            continue; 
          }
          // NRC 0x24 = Request Sequence Error - restart session and retry
          if (errorCode === 0x24) { 
            await this.startDiagnosticSession(txId, rxId, 0x03);
            await this.delay(500);
            continue; 
          }
          // NRC 0x35 = Invalid Key - wrong algorithm, no point retrying
          // NRC 0x37 = Required Time Delay - wait and retry
          if (errorCode === 0x37) {
            await this.delay(10000); // 10 second penalty
            continue;
          }
          return false;
        }
        
        // Check for positive response (0x67 = SECURITY_ACCESS + 0x40)
        if (seedResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
          return false;
        }
        
        // Extract seed (skip service ID and sub-function)
        const seed = seedResponse.slice(2);
        const key = keyCalculator(seed);
        
        // Build key response
        const keyArray: number[] = [];
        for (let i = 0; i < key.length; i++) keyArray.push(key[i]);
        const keyRequest = [UDS_SERVICES.SECURITY_ACCESS, level + 1].concat(keyArray);
        const keyResponse = await this.sendUDS(txId, rxId, keyRequest);
        
        if (!keyResponse) {
          if (attempt < retries - 1) await this.delay(500);
          continue;
        }
        
        // Check for successful key acceptance
        const success = keyResponse[0] === (UDS_SERVICES.SECURITY_ACCESS + 0x40);
        
        // CAPTURE MODE: Log seed/key pair for algorithm analysis
        if (isCaptureMode() && moduleInfo) {
          // Try to read CSN for Atlantis vehicles
          let csnBytes: Uint8Array | undefined;
          let csnHex: string | undefined;
          try {
            const csn = await this.readCSN(txId, rxId);
            if (csn) {
              csnBytes = csn;
              csnHex = formatHexBytes(csn).replace(/ /g, '');
            }
          } catch {
            // CSN read failed - not all modules support it
          }
          
          addCapture({
            moduleCode: moduleInfo.code,
            moduleName: moduleInfo.name,
            txId,
            rxId,
            securityLevel: level,
            seedBytes: seed,
            keyBytes: key,
            seedHex: formatHexBytes(seed).replace(/ /g, ''),
            keyHex: formatHexBytes(key).replace(/ /g, ''),
            csnBytes,
            csnHex,
            success,
            notes: success ? 'Key accepted' : `Key rejected (NRC 0x${keyResponse[2]?.toString(16).toUpperCase() || '??'})`,
          });
        }
        
        if (success) {
          return true;
        }
        
        // Key rejected - check error code
        if (keyResponse[0] === 0x7F && keyResponse[2] === 0x35) {
          return false; // Invalid key, algorithm mismatch
        }
        
        if (attempt < retries - 1) await this.delay(500);
      } catch {
        if (attempt < retries - 1) await this.delay(500);
      }
    }
    return false;
  }
  
  async startDiagnosticSession(txId: number, rxId: number, session: number = 0x03): Promise<boolean> {
    const request = [UDS_SERVICES.DIAGNOSTIC_SESSION, session];
    const response = await this.sendUDS(txId, rxId, request);
    
    return response !== null && response[0] === (UDS_SERVICES.DIAGNOSTIC_SESSION + 0x40);
  }

  /**
   * Read DTCs from module using UDS Service 0x19 (Read DTC Information)
   * Sub-function 0x02: Report DTC By Status Mask
   */
  async readDTCs(txId: number, rxId: number): Promise<{ dtcCount: number; dtcs: Array<{ code: string; status: number }> }> {
    // UDS Service 0x19 0x02 (Read DTC by status mask, all DTCs)
    const request = [0x19, 0x02, 0xFF]; // 0xFF = all status masks
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response || response[0] === 0x7F) {
      return { dtcCount: 0, dtcs: [] };
    }
    
    // Positive response: 0x59 0x02 [status availability mask] [DTC format] [DTCs...]
    if (response[0] !== 0x59 || response.length < 4) {
      return { dtcCount: 0, dtcs: [] };
    }
    
    const dtcs: Array<{ code: string; status: number }> = [];
    
    // Parse DTCs (each DTC is 4 bytes: 3 bytes code + 1 byte status)
    for (let i = 4; i < response.length; i += 4) {
      if (i + 3 >= response.length) break;
      
      const dtcBytes = (response[i] << 16) | (response[i + 1] << 8) | response[i + 2];
      const status = response[i + 3];
      
      // Convert DTC bytes to P/C/B/U code format
      const dtcCode = this.parseDTCCode(dtcBytes);
      dtcs.push({ code: dtcCode, status });
    }
    
    return { dtcCount: dtcs.length, dtcs };
  }

  /**
   * Parse DTC bytes to standard format (P0420, C1234, etc.)
   */
  private parseDTCCode(dtcBytes: number): string {
    const firstByte = (dtcBytes >> 16) & 0xFF;
    const secondByte = (dtcBytes >> 8) & 0xFF;
    const thirdByte = dtcBytes & 0xFF;
    
    // First 2 bits determine prefix
    const prefix = (firstByte >> 6) & 0x03;
    const prefixChar = ['P', 'C', 'B', 'U'][prefix];
    
    // Next 2 bits are first digit
    const firstDigit = (firstByte >> 4) & 0x03;
    
    // Remaining 12 bits are hex digits
    const remainingBits = ((firstByte & 0x0F) << 8) | secondByte;
    
    return `${prefixChar}${firstDigit}${remainingBits.toString(16).toUpperCase().padStart(3, '0')}`;
  }

  // UDS Routine Control (0x31) - Start Routine with timing
  async routineStart(txId: number, rxId: number, routineId: number, options: number[] = []): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.START, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF,
      ...options
    ];
    const txBytes = new Uint8Array(request);
    const startTime = performance.now();
    const response = await this.sendUDS(txId, rxId, request);
    const elapsedMs = Math.round(performance.now() - startTime);
    
    if (!response) {
      return { 
        success: false, 
        routineId, 
        nrc: 0x10, 
        nrcDescription: 'No Response',
        txBytes,
        elapsedMs
      };
    }
    
    const rxBytes = new Uint8Array(response);
    
    // Positive response: 0x71
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { 
        success: true, 
        routineId,
        statusRecord: response.slice(4),
        txBytes,
        rxBytes,
        elapsedMs
      };
    }
    
    // Negative response: 0x7F
    if (response[0] === 0x7F) {
      const nrc = response[2];
      return { 
        success: false, 
        routineId, 
        nrc,
        nrcDescription: this.getNRCDescription(nrc),
        txBytes,
        rxBytes,
        elapsedMs
      };
    }
    
    return { 
      success: false, 
      routineId, 
      nrc: 0x10, 
      nrcDescription: 'Unknown Response',
      txBytes,
      rxBytes,
      elapsedMs
    };
  }

  // UDS Routine Control (0x31) - Stop Routine
  async routineStop(txId: number, rxId: number, routineId: number): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.STOP, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF
    ];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response' };
    }
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4) };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]) };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response' };
  }

  // UDS Routine Control (0x31) - Request Routine Results
  async routineResults(txId: number, rxId: number, routineId: number): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.REQUEST_RESULTS, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF
    ];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response' };
    }
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4) };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]) };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response' };
  }

  private getNRCDescription(nrc: number): string {
    return NRC_DESCRIPTIONS[nrc]?.short || `Unknown NRC (0x${nrc.toString(16).toUpperCase()})`;
  }
  
  async scanForModules(moduleDatabase: Array<{code: string, name: string, tx: number, rx: number}>): Promise<DiscoveredModule[]> {
    const discovered: DiscoveredModule[] = [];
    
    // Step 1: Wake up all modules with broadcast TesterPresent
    console.log('[SCAN] Sending wakeup broadcast to 0x7DF...');
    await this.setHeader(0x7DF);
    await this.sendCommand('ATCRA');  // Clear receive address filter
    const wakeupFrame = this.buildISOTPSingleFrame([UDS_SERVICES.TESTER_PRESENT, 0x00]);
    const wakeupHex = wakeupFrame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
    try {
      await this.sendCommand(wakeupHex);
      await this.delay(100);  // Give modules time to wake up
    } catch (e) {
      // Ignore errors on broadcast
    }
    
    // Use longer timeout for scanning (200ms instead of 52ms)
    await this.sendCommand('ATST32');  // 50 * 4ms = 200ms timeout
    
    for (const mod of moduleDatabase) {
      try {
        await this.setHeader(mod.tx);
        await this.setReceiveAddress(mod.rx);
        
        // With ATCAF0, send proper ISO-TP frame: 02 3E 00 00 00 00 00 00
        const frame = this.buildISOTPSingleFrame([UDS_SERVICES.TESTER_PRESENT, 0x00]);
        const hexData = frame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
        
        const response = await this.sendCommandFast(hexData, 250);
        
        // ANY response means module is present (positive or NRC error)
        if (response && !response.includes('NO DATA') && !response.includes('ERROR') && !response.includes('?')) {
          const bytes = response.split(/\s+/)
            .filter(s => /^[0-9A-Fa-f]{2}$/.test(s))
            .map(s => parseInt(s, 16));
          
          if (bytes.length > 0) {
            console.log(`[SCAN] Found ${mod.code} - response: ${response.substring(0, 50)}`);
            discovered.push({
              name: mod.name,
              code: mod.code,
              txId: mod.tx,
              rxId: mod.rx,
              vin: null,
              vinOffset: null,
              status: 'found',
              lastResponse: new Uint8Array(bytes),
            });
          }
        }
      } catch {
        // No response, continue to next module
      }
    }
    
    // Restore normal timeout
    await this.sendCommand('ATST64');  // 100 * 4ms = 400ms timeout
    
    return discovered;
  }
  
  // Fast command with short timeout for scanning
  private async sendCommandFast(cmd: string, timeoutMs: number): Promise<string> {
    if (!this.writer || !this.reader) {
      throw new Error('Not connected');
    }
    
    const encoder = new TextEncoder();
    await this.writer.write(encoder.encode(cmd + '\r'));
    
    return this.readResponseFast(timeoutMs);
  }
  
  private async readResponseFast(timeoutMs: number): Promise<string> {
    // Just use the regular readResponse - the ELM327 ATST command controls actual timeout
    // This ensures we always wait for the ">" prompt properly
    return this.readResponse();
  }

  /**
   * Discover all modules on CAN bus (2018+ Chrysler/FCA/Stellantis)
   * Uses MODULE_DATABASE for verified addresses instead of hardcoded arrays.
   * 
   * WITH SGW BYPASS CABLE (bypassMode=true):
   * - Bypass shorts out gateway authentication on CAN-C pins 6/14
   * - ALL modules (powertrain + body) are routed through CAN-C (500kbps)
   * - No bus switching needed
   * 
   * WITHOUT BYPASS CABLE (bypassMode=false):
   * - CAN-C (500kbps, pins 6/14): Powertrain modules - ECM 0x7E0, TCM 0x7E1
   * - CAN-IHS (125kbps, pins 3/11): Body modules - BCM, RFHUB, ABS, IPC, etc.
   * - Requires bus switching via STP61/ATSP7
   */
  async discoverModules(
    onProgress?: (current: number, total: number, found: number) => void,
    onFound?: (txId: number, rxId: number) => void,
    bypassMode: boolean = true  // True = SGW bypass cable installed
  ): Promise<Array<{txId: number, rxId: number}>> {
    const discovered: Array<{txId: number, rxId: number}> = [];
    const foundAddresses = new Set<string>();
    
    // Import module database - use verified addresses from professional diagnostic tool/dealership diagnostic system research
    const { MODULE_DATABASE } = await import('./module-database');
    
    // Get all modules for scanning
    const allModules = MODULE_DATABASE.map(m => ({ tx: m.tx, rx: m.rx, name: m.code, bus: m.bus }));
    const powertrainModules = allModules.filter(m => m.bus === 'CAN-C');
    const bodyModules = allModules.filter(m => m.bus === 'CAN-IHS' || m.bus === 'both' || !m.bus);
    
    console.log(`[DISCOVER] Using MODULE_DATABASE: ${allModules.length} total modules`);
    if (bypassMode) {
      console.log(`[DISCOVER] SGW BYPASS MODE - All modules on CAN-C (500kbps), no bus switching`);
    } else {
      console.log(`[DISCOVER] DUAL-BUS MODE - CAN-C (powertrain) + CAN-IHS (body modules)`);
      console.log(`[DISCOVER] CAN-C modules: ${powertrainModules.length}, CAN-IHS modules: ${bodyModules.length}`);
    }
    
    const totalModules = bypassMode ? allModules.length : powertrainModules.length + bodyModules.length;
    let scanned = 0;
    
    // Build wakeup frame once
    const wakeupFrame = this.buildISOTPSingleFrame([UDS_SERVICES.TESTER_PRESENT, 0x00]);
    const wakeupHex = wakeupFrame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
    
    // ============================================================
    // PHASE 1: Setup CAN-C (500kbps, pins 6/14)
    // ============================================================
    console.log('[DISCOVER] ========================================');
    console.log('[DISCOVER] PHASE 1: CAN-C (500kbps) Scan');
    console.log('[DISCOVER] ========================================');
    
    await this.sendCommand('ATSP6');    // ISO 15765-4 CAN 500kbps 11-bit
    try {
      await this.sendCommand('STP60');  // OBDLink: CAN-C (500kbps, pins 6/14)
      console.log('[DISCOVER] STP60 OK - Using OBDLink CAN-C mode');
    } catch (e) {
      console.log('[DISCOVER] STP60 not supported, using ATSP6 only');
    }
    await this.delay(150);
    
    // Wake up CAN-C modules
    console.log('[DISCOVER] Sending CAN-C wakeup broadcast...');
    await this.sendCommand('ATCRA');  // Clear receive filter
    await this.sendCommand('ATH1');   // Headers on
    await this.setHeader(0x7DF);
    try {
      await this.sendCommand(wakeupHex);
      await this.delay(200);
    } catch (e) { }
    
    // Set timeout for discovery
    await this.sendCommand('ATST3E');  // 248ms timeout
    
    // ============================================================
    // Scan modules on CAN-C
    // ============================================================
    let modulesToScanOnCAN_C = bypassMode ? allModules : powertrainModules;
    console.log(`[DISCOVER] Probing ${modulesToScanOnCAN_C.length} modules on CAN-C...`);
    
    for (const mod of modulesToScanOnCAN_C) {
      scanned++;
      const result = await this.probeAddress(mod.tx, mod.rx);
      
      if (result.found) {
        const key = `${mod.tx}:${mod.rx}`;
        if (!foundAddresses.has(key)) {
          foundAddresses.add(key);
          discovered.push({ txId: mod.tx, rxId: mod.rx });
          console.log(`[DISCOVER] FOUND ${mod.name} at TX=0x${mod.tx.toString(16).toUpperCase()} RX=0x${mod.rx.toString(16).toUpperCase()} (${result.responseType})`);
          onFound?.(mod.tx, mod.rx);
        }
      }
      onProgress?.(scanned, totalModules, discovered.length);
    }
    
    const canCFound = discovered.length;
    console.log(`[DISCOVER] CAN-C scan complete. Found ${canCFound} modules.`);
    
    // ============================================================
    // PHASE 2: CAN-IHS (125kbps, pins 3/11) - Body modules (only if NOT bypass mode)
    // ============================================================
    if (!bypassMode && bodyModules.length > 0) {
      console.log('[DISCOVER] ========================================');
      console.log('[DISCOVER] PHASE 2: CAN-IHS (125kbps) - Body modules');
      console.log('[DISCOVER] ========================================');
      
      // Switch to CAN-IHS - try multiple methods
      let canIhsSwitchSuccess = false;
      let switchMethod = '';
      
      // Method 1: OBDLink STP61 (CAN-IHS 125kbps, pins 3/11) - PREFERRED
      try {
        console.log('[DISCOVER] Trying STP61 (OBDLink CAN-IHS, pins 3/11)...');
        const stpResponse = await this.sendCommand('STP61');
        console.log(`[DISCOVER] STP61 response: "${stpResponse.trim()}"`);
        if (stpResponse.includes('OK') || (!stpResponse.includes('?') && !stpResponse.includes('ERROR') && stpResponse.trim().length > 0)) {
          canIhsSwitchSuccess = true;
          switchMethod = 'STP61';
          console.log('[DISCOVER] SUCCESS: Switched to CAN-IHS via STP61 (pins 3/11)');
        }
      } catch (e) {
        console.log('[DISCOVER] STP61 failed (not OBDLink device)');
      }
      
      // Method 2: Standard ELM327 ATSP7 (ISO 15765-4 CAN 125kbps)
      if (!canIhsSwitchSuccess) {
        try {
          console.log('[DISCOVER] Trying ATSP7 (ELM327 CAN 125kbps)...');
          const sp7Response = await this.sendCommand('ATSP7');
          console.log(`[DISCOVER] ATSP7 response: "${sp7Response.trim()}"`);
          if (sp7Response.includes('OK') || (!sp7Response.includes('?') && !sp7Response.includes('ERROR'))) {
            canIhsSwitchSuccess = true;
            switchMethod = 'ATSP7';
            console.log('[DISCOVER] SUCCESS: Switched to CAN 125kbps via ATSP7');
          }
        } catch (e) {
          console.log('[DISCOVER] ATSP7 failed');
        }
      }
      
      // Method 3: OBDLink STPBR (programmable baud rate)
      if (!canIhsSwitchSuccess) {
        try {
          console.log('[DISCOVER] Trying STPBR 125000 (OBDLink programmable baud)...');
          const stpbrResponse = await this.sendCommand('STPBR 125000');
          console.log(`[DISCOVER] STPBR response: "${stpbrResponse.trim()}"`);
          if (stpbrResponse.includes('OK') || (!stpbrResponse.includes('?') && !stpbrResponse.includes('ERROR'))) {
            canIhsSwitchSuccess = true;
            switchMethod = 'STPBR';
            console.log('[DISCOVER] SUCCESS: Set 125kbps via STPBR');
          }
        } catch (e) {
          console.log('[DISCOVER] STPBR failed');
        }
      }
      
      if (!canIhsSwitchSuccess) {
        console.log('[DISCOVER] WARNING: Could not switch to CAN-IHS (125kbps)!');
        console.log('[DISCOVER] Body modules will NOT be discovered.');
        console.log('[DISCOVER] Your adapter may not support CAN-IHS/low-speed CAN.');
      } else {
        console.log(`[DISCOVER] Bus switch successful using ${switchMethod}`);
        
        // CRITICAL: Allow adapter to settle after protocol change
        await this.delay(300);
        
        // After STP61, explicitly set protocol to ensure correct baud/mode
        if (switchMethod === 'STP61') {
          try {
            await this.sendCommand('ATSP7');  // Ensure ATSP7 is set for 125kbps after STP61
            console.log('[DISCOVER] ATSP7 set for CAN-IHS protocol');
          } catch (e) { }
        }
        
        // Re-configure for CAN-IHS scanning
        console.log('[DISCOVER] Configuring for CAN-IHS scan...');
        await this.sendCommand('ATCRA');    // Clear receive filter
        await this.sendCommand('ATH1');     // Headers on
        await this.sendCommand('ATST50');   // 320ms timeout (body modules can be slower)
        await this.setHeader(0x7DF);        // Broadcast header
        
        // Wake up body modules with TesterPresent
        console.log('[DISCOVER] Sending CAN-IHS wakeup broadcast...');
        try {
          await this.sendCommand(wakeupHex);
          await this.delay(300);
        } catch (e) { }
        
        // Scan body modules on CAN-IHS using VIN read (0x22 F190) instead of TesterPresent
        // Body modules respond more reliably to DID reads than TesterPresent
        console.log(`[DISCOVER] Probing ${bodyModules.length} body modules (using VIN read)...`);
        for (const mod of bodyModules) {
          scanned++;
          const result = await this.probeAddressVIA(mod.tx, mod.rx);
          
          if (result.found) {
            const key = `${mod.tx}:${mod.rx}`;
            if (!foundAddresses.has(key)) {
              foundAddresses.add(key);
              discovered.push({ txId: mod.tx, rxId: mod.rx });
              console.log(`[DISCOVER] FOUND ${mod.name} at TX=0x${mod.tx.toString(16).toUpperCase()} RX=0x${mod.rx.toString(16).toUpperCase()} (${result.responseType})`);
              onFound?.(mod.tx, mod.rx);
            }
          }
          onProgress?.(scanned, totalModules, discovered.length);
        }
        
        console.log(`[DISCOVER] CAN-IHS scan complete. Found ${discovered.length - canCFound} body modules.`);
      }
      
      // ============================================================
      // PHASE 3: Restore CAN-C for subsequent operations
      // ============================================================
      console.log('[DISCOVER] Restoring CAN-C (500kbps)...');
      try {
        await this.sendCommand('ATSP6');  // ISO 15765-4 CAN 500kbps
        await this.sendCommand('STP60');  // OBDLink: CAN-C
      } catch (e) { }
      await this.delay(100);
      await this.sendCommand('ATST64');  // 400ms timeout
    }
    
    console.log('[DISCOVER] ========================================');
    console.log(`[DISCOVER] COMPLETE! Found ${discovered.length} modules total.`);
    if (bypassMode) {
      console.log('[DISCOVER] (All on CAN-C via SGW bypass)');
    } else {
      console.log(`[DISCOVER] (${canCFound} powertrain on CAN-C + ${discovered.length - canCFound} body on CAN-IHS)`);
    }
    console.log('[DISCOVER] ========================================');
    
    return discovered;
  }
  
  
  /**
   * Probe a single address to check if a module responds
   */
  private async probeAddress(txId: number, rxId: number): Promise<{found: boolean, responseType: string}> {
    try {
      // CRITICAL: Clear receive filter FIRST before setting new address
      // This prevents leftover filter state from blocking responses
      await this.sendCommand('ATCRA');  // Clear receive address filter
      await this.setHeader(txId);
      await this.setReceiveAddress(rxId);
      
      // Send TesterPresent (0x3E 0x00)
      const frame = this.buildISOTPSingleFrame([UDS_SERVICES.TESTER_PRESENT, 0x00]);
      const hexData = frame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
      
      const response = await this.sendCommand(hexData);
      
      // Log the raw response for debugging
      const txHex = txId.toString(16).toUpperCase().padStart(3, '0');
      const rxHex = rxId.toString(16).toUpperCase().padStart(3, '0');
      console.log(`[PROBE] TX=0x${txHex} RX=0x${rxHex} raw response: "${response}"`);
      
      // If NO DATA, "?", or explicit error, module not present
      // "?" is ELM327's way of saying "NO DATA" (timeout waiting for response)
      if (response.includes('NO DATA') || response.trim() === '?' || response.includes('CAN ERROR')) {
        return { found: false, responseType: 'none' };
      }
      
      // Parse response bytes - filter for valid hex pairs
      const bytes = response.split(/\s+/)
        .filter(s => /^[0-9A-Fa-f]{2}$/.test(s))
        .map(s => parseInt(s, 16));
      
      console.log(`[PROBE] TX=0x${txHex} parsed bytes: [${bytes.map(b => b.toString(16).padStart(2, '0')).join(', ')}]`);
      
      // If we got ANY response bytes, module is present
      if (bytes.length > 0) {
        // Try to identify response type
        if (bytes.length >= 2) {
          const pciType = bytes[0] & 0xF0;
          const serviceId = bytes[1];
          
          if (pciType === ISOTP_FRAME_TYPES.SINGLE_FRAME) {
            if (serviceId === (UDS_SERVICES.TESTER_PRESENT + 0x40)) {
              console.log(`[PROBE] TX=0x${txHex} - FOUND (positive TesterPresent response)`);
              return { found: true, responseType: 'positive' };
            }
            if (serviceId === 0x7F) {
              console.log(`[PROBE] TX=0x${txHex} - FOUND (negative response)`);
              return { found: true, responseType: 'negative' };
            }
          }
        }
        
        // Any other response = module is present
        console.log(`[PROBE] TX=0x${txHex} - FOUND (raw response)`);
        return { found: true, responseType: 'other' };
      }
      
    } catch (e) {
      const txHex = txId.toString(16).toUpperCase().padStart(3, '0');
      console.log(`[PROBE] TX=0x${txHex} exception: ${e}`);
    }
    
    return { found: false, responseType: 'none' };
  }
  
  /**
   * Probe using ReadDataByIdentifier (VIN 0xF190) for body modules on CAN-IHS
   * Body modules respond more reliably to DID reads than TesterPresent
   */
  private async probeAddressVIA(txId: number, rxId: number): Promise<{found: boolean, responseType: string}> {
    try {
      // CRITICAL: Clear receive filter FIRST before setting new address
      await this.sendCommand('ATCRA');  // Clear receive address filter
      await this.setHeader(txId);
      await this.setReceiveAddress(rxId);
      
      // Send ReadDataByIdentifier (0x22 F1 90) for VIN DID
      const frame = this.buildISOTPSingleFrame([UDS_SERVICES.READ_DATA_BY_ID, 0xF1, 0x90]);
      const hexData = frame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
      
      const response = await this.sendCommand(hexData);
      
      // Log the raw response for debugging
      const txHex = txId.toString(16).toUpperCase().padStart(3, '0');
      const rxHex = rxId.toString(16).toUpperCase().padStart(3, '0');
      console.log(`[PROBE-VIA] TX=0x${txHex} RX=0x${rxHex} raw response: "${response}"`);
      
      // If NO DATA or explicit error, module not present
      if (response.includes('NO DATA') || response.includes('CAN ERROR')) {
        return { found: false, responseType: 'none' };
      }
      
      // Parse response bytes - filter for valid hex pairs
      const bytes = response.split(/\s+/)
        .filter(s => /^[0-9A-Fa-f]{2}$/.test(s))
        .map(s => parseInt(s, 16));
      
      console.log(`[PROBE-VIA] TX=0x${txHex} parsed bytes: [${bytes.map(b => b.toString(16).padStart(2, '0')).join(', ')}]`);
      
      // If we got ANY response bytes, module is present
      if (bytes.length > 0) {
        // Try to identify response type
        if (bytes.length >= 2) {
          const pciType = bytes[0] & 0xF0;
          const serviceId = bytes[1];
          
          if (pciType === ISOTP_FRAME_TYPES.SINGLE_FRAME) {
            if (serviceId === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
              console.log(`[PROBE-VIA] TX=0x${txHex} - FOUND (positive ReadDataById response)`);
              return { found: true, responseType: 'positive' };
            }
            if (serviceId === 0x7F) {
              console.log(`[PROBE-VIA] TX=0x${txHex} - FOUND (negative response)`);
              return { found: true, responseType: 'negative' };
            }
          }
        }
        
        // Any other response = module is present
        console.log(`[PROBE-VIA] TX=0x${txHex} - FOUND (raw response)`);
        return { found: true, responseType: 'other' };
      }
      
    } catch (e) {
      const txHex = txId.toString(16).toUpperCase().padStart(3, '0');
      console.log(`[PROBE-VIA] TX=0x${txHex} exception: ${e}`);
    }
    
    return { found: false, responseType: 'none' };
  }
  
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  /**
   * Start sending Tester Present (0x3E) keepalive messages
   * Prevents modules from timing out during long operations
   * @param canId - CAN ID to send keepalive to (default: 0x7E0 for PCM)
   * @param intervalMs - Interval in milliseconds (default: 3000ms = 3 seconds)
   */
  startKeepalive(canId: number = 0x7E0, intervalMs: number = 3000): void {
    this.stopKeepalive(); // Clear any existing timer
    this.keepaliveCanId = canId;
    
    console.log(`[ELM327] Starting keepalive to 0x${canId.toString(16).toUpperCase()} every ${intervalMs}ms`);
    
    this.keepaliveTimer = window.setInterval(async () => {
      try {
        // Send Tester Present (0x3E) with suppress positive response (0x80)
        // This tells the module "I'm still here" without expecting a response
        const rxId = canId + 0x08; // Standard: RX = TX + 8
        await this.sendUDS(canId, rxId, [0x3E, 0x80], 0); // 0 retries - fire and forget
      } catch (e) {
        // Ignore errors - keepalive is best-effort
        console.log('[ELM327] Keepalive error (ignored):', e);
      }
    }, intervalMs);
  }
  
  /**
   * Stop sending keepalive messages
   */
  stopKeepalive(): void {
    if (this.keepaliveTimer !== null) {
      console.log('[ELM327] Stopping keepalive');
      clearInterval(this.keepaliveTimer);
      this.keepaliveTimer = null;
    }
  }
  
  isConnected(): boolean {
    return this.port !== null;
  }
}

export class J2534Protocol {
  private wsConnection: WebSocket | null = null;
  private channelId: number = 0;
  private connected = false;
  
  async connect(serverUrl: string = 'ws://localhost:8765'): Promise<boolean> {
    return new Promise((resolve) => {
      try {
        this.wsConnection = new WebSocket(serverUrl);
        
        this.wsConnection.onopen = async () => {
          const initResult = await this.sendJ2534Command('PassThruOpen', {});
          if (initResult.success) {
            const connectResult = await this.sendJ2534Command('PassThruConnect', {
              protocol: 6,
              flags: 0,
              baudRate: 500000,
            });
            if (connectResult.success && connectResult.channelId !== undefined) {
              this.channelId = connectResult.channelId;
              this.connected = true;
              resolve(true);
            }
          }
          resolve(false);
        };
        
        this.wsConnection.onerror = () => resolve(false);
        this.wsConnection.onclose = () => {
          this.connected = false;
        };
      } catch {
        resolve(false);
      }
    });
  }
  
  async disconnect(): Promise<void> {
    if (this.wsConnection) {
      await this.sendJ2534Command('PassThruDisconnect', { channelId: this.channelId });
      await this.sendJ2534Command('PassThruClose', {});
      this.wsConnection.close();
      this.wsConnection = null;
      this.connected = false;
    }
  }
  
  private sendJ2534Command(command: string, params: Record<string, unknown>): Promise<{ success: boolean; channelId?: number; data?: number[]; canId?: number }> {
    return new Promise((resolve) => {
      if (!this.wsConnection) {
        resolve({ success: false });
        return;
      }
      
      const messageHandler = (event: MessageEvent) => {
        try {
          const response = JSON.parse(event.data);
          this.wsConnection?.removeEventListener('message', messageHandler);
          resolve(response);
        } catch {
          resolve({ success: false });
        }
      };
      
      this.wsConnection.addEventListener('message', messageHandler);
      this.wsConnection.send(JSON.stringify({ command, ...params }));
      
      setTimeout(() => {
        this.wsConnection?.removeEventListener('message', messageHandler);
        resolve({ success: false });
      }, 5000);
    });
  }
  
  /**
   * Fast combined send and receive - used for quick module scanning
   * The bridge handles flow control setup, send, and receive in one call
   */
  async sendAndReceiveFast(txId: number, rxId: number, data: number[], timeout: number = 200): Promise<number[] | null> {
    const result = await this.sendJ2534Command('SendAndReceive', {
      txId,
      rxId,
      data,
      timeout,
    });
    
    if (result.success && result.data) {
      return result.data;
    }
    return null;
  }
  
  /**
   * Fast module discovery using J2534 - much faster than ELM327
   */
  async discoverModules(
    onProgress?: (current: number, total: number, found: number) => void,
    onFound?: (txId: number, rxId: number) => void
  ): Promise<Array<{txId: number, rxId: number}>> {
    const discovered: Array<{txId: number, rxId: number}> = [];
    
    // Chrysler address ranges to scan
    const ranges = [
      { start: 0x600, end: 0x6FF },  // Body modules
      { start: 0x700, end: 0x7FF },  // Powertrain modules
    ];
    
    let totalAddresses = 0;
    for (const range of ranges) {
      totalAddresses += (range.end - range.start + 1);
    }
    
    let scanned = 0;
    
    // TesterPresent request: 3E 00
    const testerPresentData = [UDS_SERVICES.TESTER_PRESENT, 0x00];
    
    for (const range of ranges) {
      for (let txId = range.start; txId <= range.end; txId++) {
        scanned++;
        const rxId = txId + 8;
        
        try {
          // Use fast combined send/receive - J2534 handles flow control internally
          const response = await this.sendAndReceiveFast(txId, rxId, testerPresentData, 50);
          
          if (response && response.length >= 1) {
            // Check for positive TesterPresent response (0x7E)
            if (response[0] === (UDS_SERVICES.TESTER_PRESENT + 0x40)) {
              discovered.push({ txId, rxId });
              console.log(`[J2534 DISCOVER] Found module at TX=0x${txId.toString(16).toUpperCase()} RX=0x${rxId.toString(16).toUpperCase()}`);
              onFound?.(txId, rxId);
            }
          }
        } catch {
          // No response, continue
        }
        
        onProgress?.(scanned, totalAddresses, discovered.length);
      }
    }
    
    return discovered;
  }

  buildISOTPSingleFrame(data: number[]): number[] {
    if (data.length > ISOTP_SINGLE_FRAME_MAX_DATA) {
      throw new Error(`Data too long for single frame: ${data.length} > ${ISOTP_SINGLE_FRAME_MAX_DATA}`);
    }
    const frame: number[] = [];
    frame.push(ISOTP_FRAME_TYPES.SINGLE_FRAME | data.length);
    frame.push(...data);
    while (frame.length < CAN_FRAME_SIZE) {
      frame.push(0x00);
    }
    return frame;
  }

  buildISOTPMultiFrame(data: number[]): number[][] {
    const frames: number[][] = [];
    const totalLength = data.length;

    const firstFrame: number[] = [];
    firstFrame.push(ISOTP_FRAME_TYPES.FIRST_FRAME | ((totalLength >> 8) & 0x0F));
    firstFrame.push(totalLength & 0xFF);
    const firstFrameData = data.slice(0, ISOTP_FIRST_FRAME_DATA);
    firstFrame.push(...firstFrameData);
    while (firstFrame.length < CAN_FRAME_SIZE) {
      firstFrame.push(0x00);
    }
    frames.push(firstFrame);

    let remainingData = data.slice(ISOTP_FIRST_FRAME_DATA);
    let sequenceNumber = 1;

    while (remainingData.length > 0) {
      const cfFrame: number[] = [];
      cfFrame.push(ISOTP_FRAME_TYPES.CONSECUTIVE_FRAME | (sequenceNumber & 0x0F));
      const chunk = remainingData.slice(0, ISOTP_CONSECUTIVE_FRAME_DATA);
      cfFrame.push(...chunk);
      while (cfFrame.length < CAN_FRAME_SIZE) {
        cfFrame.push(0x00);
      }
      frames.push(cfFrame);
      
      remainingData = remainingData.slice(ISOTP_CONSECUTIVE_FRAME_DATA);
      sequenceNumber = (sequenceNumber + 1) & 0x0F;
    }

    return frames;
  }

  parseISOTPResponse(rawBytes: number[]): number[] {
    if (rawBytes.length === 0) return [];
    
    const pciType = rawBytes[0] & 0xF0;
    
    if (pciType === ISOTP_FRAME_TYPES.SINGLE_FRAME) {
      const length = rawBytes[0] & 0x0F;
      return rawBytes.slice(1, 1 + length);
    }
    
    if (pciType === ISOTP_FRAME_TYPES.FIRST_FRAME) {
      const length = ((rawBytes[0] & 0x0F) << 8) | rawBytes[1];
      return rawBytes.slice(2, 2 + Math.min(length, rawBytes.length - 2));
    }
    
    if (pciType === ISOTP_FRAME_TYPES.CONSECUTIVE_FRAME) {
      return rawBytes.slice(1);
    }
    
    return rawBytes;
  }
  
  async sendUDS(txId: number, rxId: number, data: number[]): Promise<Uint8Array | null> {
    if (data.length <= ISOTP_SINGLE_FRAME_MAX_DATA) {
      const frame = this.buildISOTPSingleFrame(data);
      
      const result = await this.sendJ2534Command('PassThruWriteMsgs', {
        channelId: this.channelId,
        txId,
        data: frame,
      });
      
      if (!result.success) return null;
      
      const readResult = await this.sendJ2534Command('PassThruReadMsgs', {
        channelId: this.channelId,
        rxId,
        timeout: 1000,
      });
      
      if (!readResult.data) return null;
      
      const udsData = this.parseISOTPResponse(readResult.data);
      return udsData.length > 0 ? new Uint8Array(udsData) : null;
    }

    const frames = this.buildISOTPMultiFrame(data);
    
    const ffResult = await this.sendJ2534Command('PassThruWriteMsgs', {
      channelId: this.channelId,
      txId,
      data: frames[0],
    });
    
    if (!ffResult.success) return null;
    
    const fcResult = await this.sendJ2534Command('PassThruReadMsgs', {
      channelId: this.channelId,
      rxId,
      timeout: 1000,
    });
    
    if (!fcResult.data) return null;
    
    const fcPci = fcResult.data[0] & 0xF0;
    if (fcPci !== ISOTP_FRAME_TYPES.FLOW_CONTROL) return null;
    
    const flowStatus = fcResult.data[0] & 0x0F;
    if (flowStatus !== 0) return null;
    
    const blockSize = fcResult.data[1] || 0;
    const stMin = fcResult.data[2] || 0;
    
    for (let i = 1; i < frames.length; i++) {
      if (stMin > 0) {
        await this.delay(stMin);
      }
      
      const cfResult = await this.sendJ2534Command('PassThruWriteMsgs', {
        channelId: this.channelId,
        txId,
        data: frames[i],
      });
      
      if (!cfResult.success) return null;
      
      if (blockSize > 0 && i % blockSize === 0 && i < frames.length - 1) {
        const nextFc = await this.sendJ2534Command('PassThruReadMsgs', {
          channelId: this.channelId,
          rxId,
          timeout: 1000,
        });
        
        if (!nextFc.data || (nextFc.data[0] & 0xF0) !== ISOTP_FRAME_TYPES.FLOW_CONTROL) {
          return null;
        }
      }
    }
    
    const responseResult = await this.sendJ2534Command('PassThruReadMsgs', {
      channelId: this.channelId,
      rxId,
      timeout: 3000,
    });
    
    if (!responseResult.data) return null;
    
    const pciType = responseResult.data[0] & 0xF0;
    
    if (pciType === ISOTP_FRAME_TYPES.FIRST_FRAME) {
      const totalLength = ((responseResult.data[0] & 0x0F) << 8) | responseResult.data[1];
      const allData: number[] = [...responseResult.data.slice(2)];
      
      const fcSend = await this.sendJ2534Command('PassThruWriteMsgs', {
        channelId: this.channelId,
        txId,
        data: [ISOTP_FRAME_TYPES.FLOW_CONTROL, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
      });
      
      if (!fcSend.success) return null;
      
      while (allData.length < totalLength) {
        const cfRead = await this.sendJ2534Command('PassThruReadMsgs', {
          channelId: this.channelId,
          rxId,
          timeout: 1000,
        });
        
        if (!cfRead.data) break;
        
        if ((cfRead.data[0] & 0xF0) === ISOTP_FRAME_TYPES.CONSECUTIVE_FRAME) {
          allData.push(...cfRead.data.slice(1));
        }
      }
      
      return new Uint8Array(allData.slice(0, totalLength));
    }
    
    const udsData = this.parseISOTPResponse(responseResult.data);
    return udsData.length > 0 ? new Uint8Array(udsData) : null;
  }
  
  async readVIN(txId: number, rxId: number): Promise<string | null> {
    const request = [UDS_SERVICES.READ_DATA_BY_ID, (VIN_DID >> 8) & 0xFF, VIN_DID & 0xFF];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response || response.length < 4) return null;
    
    if (response[0] === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
      // Use the parseVINBytes helper to properly filter null bytes and non-printable chars
      const vinBytes = response.slice(3);
      return parseVINBytes(vinBytes);
    }
    
    return null;
  }
  
  async writeVIN(txId: number, rxId: number, vin: string): Promise<boolean> {
    if (vin.length !== 17) return false;
    
    const vinBytes: number[] = [];
    for (let i = 0; i < vin.length; i++) {
      vinBytes.push(vin.charCodeAt(i));
    }
    const request = [UDS_SERVICES.WRITE_DATA_BY_ID, (VIN_DID >> 8) & 0xFF, VIN_DID & 0xFF].concat(vinBytes);
    
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) return false;
    
    return response[0] === (UDS_SERVICES.WRITE_DATA_BY_ID + 0x40);
  }

  // Read CSN (Control Serial Number) for Atlantis 2018+ 5-byte algorithm (J2534)
  async readCSN(txId: number, rxId: number): Promise<Uint8Array | null> {
    const request = [UDS_SERVICES.READ_DATA_BY_ID, (CSN_DID >> 8) & 0xFF, CSN_DID & 0xFF];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) return null;
    
    if (response[0] === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
      return response.slice(3);
    }
    
    return null;
  }

  async startDiagnosticSession(txId: number, rxId: number, session: number = 0x03): Promise<boolean> {
    const request = [UDS_SERVICES.DIAGNOSTIC_SESSION, session];
    const response = await this.sendUDS(txId, rxId, request);
    
    return response !== null && response[0] === (UDS_SERVICES.DIAGNOSTIC_SESSION + 0x40);
  }

  /**
   * Read DTCs from module using UDS Service 0x19 (Read DTC Information)
   * Sub-function 0x02: Report DTC By Status Mask
   */
  async readDTCs(txId: number, rxId: number): Promise<{ dtcCount: number; dtcs: Array<{ code: string; status: number }> }> {
    // UDS Service 0x19 0x02 (Read DTC by status mask, all DTCs)
    const request = [0x19, 0x02, 0xFF]; // 0xFF = all status masks
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response || response[0] === 0x7F) {
      return { dtcCount: 0, dtcs: [] };
    }
    
    // Positive response: 0x59 0x02 [status availability mask] [DTC format] [DTCs...]
    if (response[0] !== 0x59 || response.length < 4) {
      return { dtcCount: 0, dtcs: [] };
    }
    
    const dtcs: Array<{ code: string; status: number }> = [];
    
    // Parse DTCs (each DTC is 4 bytes: 3 bytes code + 1 byte status)
    for (let i = 4; i < response.length; i += 4) {
      if (i + 3 >= response.length) break;
      
      const dtcBytes = (response[i] << 16) | (response[i + 1] << 8) | response[i + 2];
      const status = response[i + 3];
      
      // Convert DTC bytes to P/C/B/U code format
      const dtcCode = this.parseDTCCode(dtcBytes);
      dtcs.push({ code: dtcCode, status });
    }
    
    return { dtcCount: dtcs.length, dtcs };
  }

  /**
   * Parse DTC bytes to standard format (P0420, C1234, etc.)
   */
  private parseDTCCode(dtcBytes: number): string {
    const firstByte = (dtcBytes >> 16) & 0xFF;
    const secondByte = (dtcBytes >> 8) & 0xFF;
    const thirdByte = dtcBytes & 0xFF;
    
    // First 2 bits determine prefix
    const prefix = (firstByte >> 6) & 0x03;
    const prefixChar = ['P', 'C', 'B', 'U'][prefix];
    
    // Next 2 bits are first digit
    const firstDigit = (firstByte >> 4) & 0x03;
    
    // Remaining 12 bits are hex digits
    const remainingBits = ((firstByte & 0x0F) << 8) | secondByte;
    
    return `${prefixChar}${firstDigit}${remainingBits.toString(16).toUpperCase().padStart(3, '0')}`;
  }

  async securityAccess(txId: number, rxId: number, level: number, keyCalculator: (seed: Uint8Array) => Uint8Array, retries: number = 3, moduleInfo?: { code: string; name: string }): Promise<boolean> {
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        // Ensure we're in extended diagnostic session first
        if (attempt > 0) {
          await this.startDiagnosticSession(txId, rxId, 0x03);
          await this.delay(100);
        }
        
        // Request seed
        const seedRequest = [UDS_SERVICES.SECURITY_ACCESS, level];
        const seedResponse = await this.sendUDS(txId, rxId, seedRequest);
        
        if (!seedResponse) {
          if (attempt < retries - 1) await this.delay(500);
          continue;
        }
        
        // Check for negative response (0x7F)
        if (seedResponse[0] === 0x7F) {
          const errorCode = seedResponse[2];
          if (errorCode === 0x78) { await this.delay(1000); continue; }
          if (errorCode === 0x24) { 
            await this.startDiagnosticSession(txId, rxId, 0x03);
            await this.delay(500);
            continue; 
          }
          if (errorCode === 0x37) { await this.delay(10000); continue; }
          return false;
        }
        
        // Check for positive response (0x67 = SECURITY_ACCESS + 0x40)
        if (seedResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
          return false;
        }
        
        // Extract seed (skip service ID and sub-function)
        const seed = seedResponse.slice(2);
        const key = keyCalculator(seed);
        
        // Build key response
        const keyArray: number[] = [];
        for (let i = 0; i < key.length; i++) keyArray.push(key[i]);
        const keyRequest = [UDS_SERVICES.SECURITY_ACCESS, level + 1].concat(keyArray);
        const keyResponse = await this.sendUDS(txId, rxId, keyRequest);
        
        if (!keyResponse) {
          if (attempt < retries - 1) await this.delay(500);
          continue;
        }
        
        // Check for successful key acceptance
        const success = keyResponse[0] === (UDS_SERVICES.SECURITY_ACCESS + 0x40);
        
        // CAPTURE MODE: Log seed/key pair for algorithm analysis (J2534)
        if (isCaptureMode() && moduleInfo) {
          let csnBytes: Uint8Array | undefined;
          let csnHex: string | undefined;
          try {
            const csn = await this.readCSN(txId, rxId);
            if (csn) { csnBytes = csn; csnHex = formatHexBytes(csn).replace(/ /g, ''); }
          } catch { /* CSN read failed */ }
          
          addCapture({
            moduleCode: moduleInfo.code,
            moduleName: moduleInfo.name,
            txId,
            rxId,
            securityLevel: level,
            seedBytes: seed,
            keyBytes: key,
            seedHex: formatHexBytes(seed).replace(/ /g, ''),
            keyHex: formatHexBytes(key).replace(/ /g, ''),
            csnBytes,
            csnHex,
            success,
            notes: success ? 'Key accepted' : `Key rejected (NRC 0x${keyResponse[2]?.toString(16).toUpperCase() || '??'})`,
          });
        }
        
        if (success) { return true; }
        
        // Key rejected - check error code
        if (keyResponse[0] === 0x7F && keyResponse[2] === 0x35) {
          return false; // Invalid key, algorithm mismatch
        }
        
        if (attempt < retries - 1) await this.delay(500);
      } catch {
        if (attempt < retries - 1) await this.delay(500);
      }
    }
    return false;
  }

  // UDS Routine Control (0x31) - Start Routine with timing (J2534)
  async routineStart(txId: number, rxId: number, routineId: number, options: number[] = []): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.START, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF,
      ...options
    ];
    const txBytes = new Uint8Array(request);
    const startTime = performance.now();
    const response = await this.sendUDS(txId, rxId, request);
    const elapsedMs = Math.round(performance.now() - startTime);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response', txBytes, elapsedMs };
    }
    
    const rxBytes = new Uint8Array(response);
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4), txBytes, rxBytes, elapsedMs };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]), txBytes, rxBytes, elapsedMs };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response', txBytes, rxBytes, elapsedMs };
  }

  async routineStop(txId: number, rxId: number, routineId: number): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.STOP, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF
    ];
    const txBytes = new Uint8Array(request);
    const startTime = performance.now();
    const response = await this.sendUDS(txId, rxId, request);
    const elapsedMs = Math.round(performance.now() - startTime);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response', txBytes, elapsedMs };
    }
    
    const rxBytes = new Uint8Array(response);
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4), txBytes, rxBytes, elapsedMs };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]), txBytes, rxBytes, elapsedMs };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response', txBytes, rxBytes, elapsedMs };
  }

  async routineResults(txId: number, rxId: number, routineId: number): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.REQUEST_RESULTS, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF
    ];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response' };
    }
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4) };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]) };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response' };
  }

  private getNRCDescription(nrc: number): string {
    return NRC_DESCRIPTIONS[nrc]?.short || `Unknown NRC (0x${nrc.toString(16).toUpperCase()})`;
  }

  async scanForModules(moduleDatabase: Array<{code: string, name: string, tx: number, rx: number}>): Promise<DiscoveredModule[]> {
    const discovered: DiscoveredModule[] = [];
    
    for (const mod of moduleDatabase) {
      const response = await this.sendUDS(mod.tx, mod.rx, [UDS_SERVICES.TESTER_PRESENT, 0x00]);
      
      if (response && response[0] === (UDS_SERVICES.TESTER_PRESENT + 0x40)) {
        discovered.push({
          name: mod.name,
          code: mod.code,
          txId: mod.tx,
          rxId: mod.rx,
          vin: null,
          vinOffset: null,
          status: 'found',
          lastResponse: response,
        });
      }
    }
    
    return discovered;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  isConnected(): boolean {
    return this.connected;
  }
}

export class ArduinoCANProtocol {
  private port: SerialPort | null = null;
  private reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
  private writer: WritableStreamDefaultWriter<Uint8Array> | null = null;
  private responseBuffer = '';
  private lastError: string = '';
  
  static isSupported(): boolean {
    return 'serial' in navigator;
  }

  getLastError(): string {
    return this.lastError;
  }

  // Connect to a specific port (bypasses browser picker)
  async connectToPort(port: SerialPort): Promise<boolean> {
    this.lastError = '';
    try {
      // Clean up any existing connection first
      await this.disconnect();
      
      this.port = port;
      
      try {
        await safeOpenPort(this.port, 115200);
      } catch (e) {
        const err = e as any;
        this.lastError = `Port open failed: ${err.message || err}`;
        console.error('Failed to open port:', err.message || err);
        return false;
      }

      if (!this.port.readable || !this.port.writable) {
        this.lastError = 'Port streams not available after open';
        console.error('Port streams not available');
        return false;
      }

      this.reader = this.port.readable.getReader();
      this.writer = this.port.writable.getWriter();

      await this.delay(500);
      
      try {
        await this.sendCommand('INIT');
        await this.readResponse(500).catch(() => '');
      } catch (e) {
        // Init is optional
      }

      console.log('Arduino CAN connected successfully at 115200 baud');
      return true;
    } catch (error) {
      const err = error as any;
      this.lastError = `Connection error: ${err.message || err}`;
      console.error('Arduino CAN connection failed:', err.message || err);
      return false;
    }
  }
  
  async connect(): Promise<boolean> {
    this.lastError = '';
    try {
      if (!ArduinoCANProtocol.isSupported()) {
        this.lastError = 'WebSerial not supported in this browser';
        console.error('WebSerial not supported in this browser');
        return false;
      }
      
      // Clean up any existing connection first
      await this.disconnect();
      
      try {
        this.port = await navigator.serial.requestPort();
      } catch (e) {
        const err = e as any;
        if (err.name === 'NotFoundError' || err.message?.includes('User cancelled')) {
          this.lastError = 'Port selection cancelled';
          console.log('User cancelled port selection');
        } else {
          this.lastError = `Port request failed: ${err.message || err}`;
          console.error('Port request failed:', err.message || err);
        }
        return false;
      }
      
      try {
        await safeOpenPort(this.port!, 115200);
      } catch (e) {
        const err = e as any;
        this.lastError = `Port open failed: ${err.message || err}`;
        console.error('Failed to open port:', err.message || err);
        return false;
      }
      
      if (!this.port!.readable || !this.port!.writable) {
        this.lastError = 'Port streams not available after open';
        console.error('Port streams not available');
        return false;
      }
      
      this.reader = this.port!.readable.getReader();
      this.writer = this.port!.writable.getWriter();
      
      await this.delay(500);
      
      try {
        await this.sendCommand('INIT');
        const response = await this.readResponse(500).catch(() => '');
        console.log('Arduino init response:', response);
      } catch (e) {
        console.log('Arduino init message skipped (may not be implemented)');
      }
      
      console.log('Arduino CAN connected successfully at 115200 baud');
      return true;
    } catch (error) {
      const err = error as any;
      this.lastError = `Connection error: ${err.message || err}`;
      console.error('Arduino CAN connection failed:', err.message || err);
      return false;
    }
  }
  
  async disconnect(): Promise<void> {
    try {
      if (this.reader) {
        try {
          await this.reader.cancel();
          this.reader.releaseLock();
        } catch (e) {
          console.log('Arduino reader cleanup error (ignored):', e);
        }
      }
      if (this.writer) {
        try {
          await this.writer.close();
        } catch (e) {
          console.log('Arduino writer cleanup error (ignored):', e);
        }
      }
      if (this.port) {
        try {
          await this.port.close();
        } catch (e) {
          console.log('Arduino port close error (ignored):', e);
        }
      }
    } catch (error) {
      console.log('Arduino disconnect error (ignored):', error);
    } finally {
      this.port = null;
      this.reader = null;
      this.writer = null;
    }
  }
  
  async ping(): Promise<boolean> {
    if (!this.port || !this.writer || !this.reader) {
      return false;
    }
    
    try {
      await this.sendCommand('PING');
      const response = await this.readResponse(500).catch(() => '');
      return response.length > 0 || this.port !== null;
    } catch {
      return this.port !== null && this.writer !== null;
    }
  }
  
  private async sendCommand(cmd: string): Promise<void> {
    if (!this.writer) throw new Error('Not connected');
    const encoder = new TextEncoder();
    await this.writer.write(encoder.encode(cmd + '\r\n'));
  }
  
  private async readResponse(timeoutMs: number = 1000): Promise<string> {
    if (!this.reader) throw new Error('No reader');
    
    const decoder = new TextDecoder();
    const timeout = Date.now() + timeoutMs;
    
    while (Date.now() < timeout) {
      try {
        const readPromise = this.reader.read();
        const timeoutPromise = new Promise<{value: undefined, done: true}>((resolve) => 
          setTimeout(() => resolve({value: undefined, done: true}), 50)
        );
        
        const { value, done } = await Promise.race([readPromise, timeoutPromise]);
        
        if (done) throw new Error('Reader closed');
        if (!value) continue;
        
        this.responseBuffer += decoder.decode(value);
        
        if (this.responseBuffer.includes('\n')) {
          const lines = this.responseBuffer.split('\n');
          const response = lines[0].trim();
          this.responseBuffer = lines.slice(1).join('\n');
          if (response.length > 0) return response;
        }
      } catch (e) {
        if (e instanceof Error && e.message === 'Reader closed') throw e;
        continue;
      }
    }
    
    const remaining = this.responseBuffer.trim();
    this.responseBuffer = '';
    if (!remaining) throw new Error('No response');
    return remaining;
  }
  
  async sendCANFrame(txId: number, data: number[]): Promise<string | null> {
    const txHex = txId.toString(16).toUpperCase().padStart(3, '0');
    const dataHex = data.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
    
    await this.sendCommand(`${txHex}:${dataHex}`);
    
    const response = await this.readResponse(1000);
    return response || null;
  }
  
  async sendUDS(txId: number, rxId: number, data: number[]): Promise<Uint8Array | null> {
    try {
      let frameData: number[];
      
      if (data.length <= 7) {
        frameData = [data.length, ...data];
        while (frameData.length < 8) frameData.push(0x00);
      } else {
        frameData = [0x10 | ((data.length >> 8) & 0x0F), data.length & 0xFF, ...data.slice(0, 6)];
      }
      
      const response = await this.sendCANFrame(txId, frameData);
      
      if (!response) return null;
      
      const parts = response.split(':');
      if (parts.length < 2) return null;
      
      const respId = parseInt(parts[0], 16);
      if (respId !== rxId) return null;
      
      const respData = parts[1].match(/.{1,2}/g)?.map(b => parseInt(b, 16)) || [];
      
      const pciType = respData[0] & 0xF0;
      if (pciType === 0x00) {
        const len = respData[0] & 0x0F;
        return new Uint8Array(respData.slice(1, 1 + len));
      }
      
      return new Uint8Array(respData);
    } catch (error) {
      console.error('Arduino sendUDS error:', error);
      return null;
    }
  }
  
  async readVIN(txId: number, rxId: number): Promise<string | null> {
    const request = [UDS_SERVICES.READ_DATA_BY_ID, (VIN_DID >> 8) & 0xFF, VIN_DID & 0xFF];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response || response.length < 4) return null;
    
    if (response[0] === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
      // Use the parseVINBytes helper to properly filter null bytes and non-printable chars
      const vinBytes = response.slice(3);
      return parseVINBytes(vinBytes);
    }
    
    return null;
  }
  
  async writeVIN(txId: number, rxId: number, vin: string): Promise<boolean> {
    if (vin.length !== 17) return false;
    
    const vinBytes: number[] = [];
    for (let i = 0; i < vin.length; i++) {
      vinBytes.push(vin.charCodeAt(i));
    }
    const request = [UDS_SERVICES.WRITE_DATA_BY_ID, (VIN_DID >> 8) & 0xFF, VIN_DID & 0xFF, ...vinBytes];
    
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) return false;
    
    return response[0] === (UDS_SERVICES.WRITE_DATA_BY_ID + 0x40);
  }
  
  // Read CSN (Control Serial Number) for Atlantis 2018+ 5-byte algorithm (Arduino)
  async readCSN(txId: number, rxId: number): Promise<Uint8Array | null> {
    const request = [UDS_SERVICES.READ_DATA_BY_ID, (CSN_DID >> 8) & 0xFF, CSN_DID & 0xFF];
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response) return null;
    
    if (response[0] === (UDS_SERVICES.READ_DATA_BY_ID + 0x40)) {
      return response.slice(3);
    }
    
    return null;
  }
  
  async startDiagnosticSession(txId: number, rxId: number, session: number = 0x03): Promise<boolean> {
    const request = [UDS_SERVICES.DIAGNOSTIC_SESSION, session];
    const response = await this.sendUDS(txId, rxId, request);
    
    return response !== null && response[0] === (UDS_SERVICES.DIAGNOSTIC_SESSION + 0x40);
  }

  /**
   * Read DTCs from module using UDS Service 0x19 (Read DTC Information)
   * Sub-function 0x02: Report DTC By Status Mask
   */
  async readDTCs(txId: number, rxId: number): Promise<{ dtcCount: number; dtcs: Array<{ code: string; status: number }> }> {
    // UDS Service 0x19 0x02 (Read DTC by status mask, all DTCs)
    const request = [0x19, 0x02, 0xFF]; // 0xFF = all status masks
    const response = await this.sendUDS(txId, rxId, request);
    
    if (!response || response[0] === 0x7F) {
      return { dtcCount: 0, dtcs: [] };
    }
    
    // Positive response: 0x59 0x02 [status availability mask] [DTC format] [DTCs...]
    if (response[0] !== 0x59 || response.length < 4) {
      return { dtcCount: 0, dtcs: [] };
    }
    
    const dtcs: Array<{ code: string; status: number }> = [];
    
    // Parse DTCs (each DTC is 4 bytes: 3 bytes code + 1 byte status)
    for (let i = 4; i < response.length; i += 4) {
      if (i + 3 >= response.length) break;
      
      const dtcBytes = (response[i] << 16) | (response[i + 1] << 8) | response[i + 2];
      const status = response[i + 3];
      
      // Convert DTC bytes to P/C/B/U code format
      const dtcCode = this.parseDTCCode(dtcBytes);
      dtcs.push({ code: dtcCode, status });
    }
    
    return { dtcCount: dtcs.length, dtcs };
  }

  /**
   * Parse DTC bytes to standard format (P0420, C1234, etc.)
   */
  private parseDTCCode(dtcBytes: number): string {
    const firstByte = (dtcBytes >> 16) & 0xFF;
    const secondByte = (dtcBytes >> 8) & 0xFF;
    const thirdByte = dtcBytes & 0xFF;
    
    // First 2 bits determine prefix
    const prefix = (firstByte >> 6) & 0x03;
    const prefixChar = ['P', 'C', 'B', 'U'][prefix];
    
    // Next 2 bits are first digit
    const firstDigit = (firstByte >> 4) & 0x03;
    
    // Remaining 12 bits are hex digits
    const remainingBits = ((firstByte & 0x0F) << 8) | secondByte;
    
    return `${prefixChar}${firstDigit}${remainingBits.toString(16).toUpperCase().padStart(3, '0')}`;
  }
  
  async securityAccess(txId: number, rxId: number, level: number, keyCalculator: (seed: Uint8Array) => Uint8Array, moduleInfo?: { code: string; name: string }): Promise<boolean> {
    const seedRequest = [UDS_SERVICES.SECURITY_ACCESS, level];
    const seedResponse = await this.sendUDS(txId, rxId, seedRequest);
    
    if (!seedResponse || seedResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
      return false;
    }
    
    const seed = seedResponse.slice(2);
    const key = keyCalculator(seed);
    
    const keyArray: number[] = [];
    for (let i = 0; i < key.length; i++) keyArray.push(key[i]);
    const keyRequest = [UDS_SERVICES.SECURITY_ACCESS, level + 1, ...keyArray];
    const keyResponse = await this.sendUDS(txId, rxId, keyRequest);
    
    const success = keyResponse !== null && keyResponse[0] === (UDS_SERVICES.SECURITY_ACCESS + 0x40);
    
    // CAPTURE MODE: Log seed/key pair for algorithm analysis (Arduino)
    if (isCaptureMode() && moduleInfo) {
      let csnBytes: Uint8Array | undefined;
      let csnHex: string | undefined;
      try {
        const csn = await this.readCSN(txId, rxId);
        if (csn) { csnBytes = csn; csnHex = formatHexBytes(csn).replace(/ /g, ''); }
      } catch { /* CSN read failed */ }
      
      addCapture({
        moduleCode: moduleInfo.code,
        moduleName: moduleInfo.name,
        txId,
        rxId,
        securityLevel: level,
        seedBytes: seed,
        keyBytes: key,
        seedHex: formatHexBytes(seed).replace(/ /g, ''),
        keyHex: formatHexBytes(key).replace(/ /g, ''),
        csnBytes,
        csnHex,
        success,
        notes: success ? 'Key accepted' : `Key rejected (NRC 0x${keyResponse?.[2]?.toString(16).toUpperCase() || '??'})`,
      });
    }
    
    return success;
  }

  // UDS Routine Control (0x31) - Start Routine with timing (Arduino)
  async routineStart(txId: number, rxId: number, routineId: number, options: number[] = []): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.START, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF,
      ...options
    ];
    const txBytes = new Uint8Array(request);
    const startTime = performance.now();
    const response = await this.sendUDS(txId, rxId, request);
    const elapsedMs = Math.round(performance.now() - startTime);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response', txBytes, elapsedMs };
    }
    
    const rxBytes = new Uint8Array(response);
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4), txBytes, rxBytes, elapsedMs };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]), txBytes, rxBytes, elapsedMs };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response', txBytes, rxBytes, elapsedMs };
  }

  async routineStop(txId: number, rxId: number, routineId: number): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.STOP, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF
    ];
    const txBytes = new Uint8Array(request);
    const startTime = performance.now();
    const response = await this.sendUDS(txId, rxId, request);
    const elapsedMs = Math.round(performance.now() - startTime);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response', txBytes, elapsedMs };
    }
    
    const rxBytes = new Uint8Array(response);
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4), txBytes, rxBytes, elapsedMs };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]), txBytes, rxBytes, elapsedMs };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response', txBytes, rxBytes, elapsedMs };
  }

  async routineResults(txId: number, rxId: number, routineId: number): Promise<RoutineResult> {
    const request = [
      UDS_SERVICES.ROUTINE_CONTROL, 
      ROUTINE_SUB.REQUEST_RESULTS, 
      (routineId >> 8) & 0xFF, 
      routineId & 0xFF
    ];
    const txBytes = new Uint8Array(request);
    const startTime = performance.now();
    const response = await this.sendUDS(txId, rxId, request);
    const elapsedMs = Math.round(performance.now() - startTime);
    
    if (!response) {
      return { success: false, routineId, nrc: 0x10, nrcDescription: 'No Response', txBytes, elapsedMs };
    }
    
    const rxBytes = new Uint8Array(response);
    
    if (response[0] === (UDS_SERVICES.ROUTINE_CONTROL + 0x40)) {
      return { success: true, routineId, statusRecord: response.slice(4), txBytes, rxBytes, elapsedMs };
    }
    
    if (response[0] === 0x7F) {
      return { success: false, routineId, nrc: response[2], nrcDescription: this.getNRCDescription(response[2]), txBytes, rxBytes, elapsedMs };
    }
    
    return { success: false, routineId, nrc: 0x10, nrcDescription: 'Unknown Response', txBytes, rxBytes, elapsedMs };
  }

  private getNRCDescription(nrc: number): string {
    return NRC_DESCRIPTIONS[nrc]?.short || `Unknown NRC (0x${nrc.toString(16).toUpperCase()})`;
  }
  
  async scanForModules(moduleDatabase: Array<{code: string, name: string, tx: number, rx: number}>): Promise<DiscoveredModule[]> {
    const discovered: DiscoveredModule[] = [];
    
    for (const mod of moduleDatabase) {
      const response = await this.sendUDS(mod.tx, mod.rx, [UDS_SERVICES.TESTER_PRESENT, 0x00]);
      
      if (response && response[0] === (UDS_SERVICES.TESTER_PRESENT + 0x40)) {
        discovered.push({
          name: mod.name,
          code: mod.code,
          txId: mod.tx,
          rxId: mod.rx,
          vin: null,
          vinOffset: null,
          status: 'found',
          lastResponse: response,
        });
      }
    }
    
    return discovered;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  isConnected(): boolean {
    return this.port !== null;
  }
}

export function createOBD2Protocol(type: HardwareType): ELM327Protocol | J2534Protocol | ArduinoCANProtocol {
  switch (type) {
    case 'elm327':
      return new ELM327Protocol();
    case 'arduino':
      return new ArduinoCANProtocol();
    case 'j2534':
      return new J2534Protocol();
    default:
      return new ELM327Protocol();
  }
}

// ========== CAN SNIFFER TYPES ==========

export interface SniffedFrame {
  id: string;
  timestamp: number;
  canId: number;
  canIdHex: string;
  data: Uint8Array;
  dataHex: string;
  direction: 'rx';
  frameType: SniffedFrameType;
  udsService?: number;
  udsServiceName?: string;
  parsed?: ParsedUDSFrame;
}

export type SniffedFrameType = 
  | 'security_seed'      // 67 01/03/05 XX XX XX... (seed response)
  | 'security_key'       // 27 02/04/06 XX XX XX... (key request)
  | 'security_success'   // 67 02/04/06 (key accepted)
  | 'security_reject'    // 7F 27 35/36/37 (key rejected)
  | 'csn_response'       // 62 F1 8C XX XX XX XX XX (CSN data)
  | 'vin_response'       // 62 F1 90 XX... (VIN data)
  | 'negative_response'  // 7F XX XX
  | 'uds_request'        // Any UDS request
  | 'uds_response'       // Any positive UDS response
  | 'unknown';           // Non-UDS or unrecognized

export interface ParsedUDSFrame {
  service: number;
  serviceName: string;
  subFunction?: number;
  did?: number;
  didName?: string;
  seed?: Uint8Array;
  key?: Uint8Array;
  csn?: Uint8Array;
  vin?: string;
  nrc?: number;
  nrcDescription?: string;
  securityLevel?: number;
}

export interface SecurityCapture {
  id: string;
  timestamp: number;
  canId: number;
  seedFrame?: SniffedFrame;
  keyFrame?: SniffedFrame;
  resultFrame?: SniffedFrame;
  csnFrame?: SniffedFrame;
  securityLevel?: number;
  seed?: Uint8Array;
  key?: Uint8Array;
  csn?: Uint8Array;
  success?: boolean;
}

// UDS Service names for logging
const UDS_SERVICE_NAMES: Record<number, string> = {
  0x10: 'DiagnosticSessionControl',
  0x11: 'ECUReset',
  0x14: 'ClearDiagnosticInfo',
  0x19: 'ReadDTCInfo',
  0x22: 'ReadDataByIdentifier',
  0x23: 'ReadMemoryByAddress',
  0x24: 'ReadScalingDataByIdentifier',
  0x27: 'SecurityAccess',
  0x28: 'CommunicationControl',
  0x2A: 'ReadDataByPeriodicIdentifier',
  0x2C: 'DynamicallyDefineDataIdentifier',
  0x2E: 'WriteDataByIdentifier',
  0x2F: 'IOControlByIdentifier',
  0x31: 'RoutineControl',
  0x34: 'RequestDownload',
  0x35: 'RequestUpload',
  0x36: 'TransferData',
  0x37: 'RequestTransferExit',
  0x3D: 'WriteMemoryByAddress',
  0x3E: 'TesterPresent',
  0x85: 'ControlDTCSetting',
  0x87: 'LinkControl',
};

// Known DIDs
const KNOWN_DIDS: Record<number, string> = {
  0xF190: 'VIN',
  0xF18C: 'CSN (Control Serial Number)',
  0xF100: 'PartNumber',
  0xF187: 'SparePartNumber',
  0xF189: 'VehicleManufacturerECUSoftwareNumber',
  0xF18A: 'SystemSupplierIdentifier',
  0xF191: 'VehicleManufacturerECUHardwareNumber',
  0xF193: 'SystemSupplierECUSoftwareVersionNumber',
  0xF195: 'SystemNameOrEngineType',
  0xF197: 'SystemSupplierECUHardwareNumber',
  0xF199: 'ProgrammingDate',
  0xF19D: 'ECUInstallationDate',
  0x4000: 'BCMConfigBlock',
  0x1000: 'ConfigBlock1',
  0x2000: 'ConfigBlock2',
  0xDE00: 'FeatureConfigBlock',
};

/**
 * Parse a raw CAN data payload as a UDS frame
 */
export function parseUDSFrame(canId: number, rawData: Uint8Array): { frameType: SniffedFrameType; parsed?: ParsedUDSFrame } {
  if (rawData.length < 2) {
    return { frameType: 'unknown' };
  }

  // Extract ISO-TP payload (skip PCI byte for single-frame)
  const pciType = rawData[0] & 0xF0;
  let data: Uint8Array;
  
  if (pciType === 0x00) {
    // Single frame
    const len = rawData[0] & 0x0F;
    data = rawData.slice(1, 1 + len);
  } else if (pciType === 0x10) {
    // First frame of multi-frame (take what's available)
    data = rawData.slice(2);
  } else if (pciType === 0x20) {
    // Consecutive frame - skip for now
    return { frameType: 'unknown' };
  } else if (pciType === 0x30) {
    // Flow control - skip
    return { frameType: 'unknown' };
  } else {
    // Not ISO-TP formatted, try raw
    data = rawData;
  }

  if (data.length < 1) {
    return { frameType: 'unknown' };
  }

  const serviceId = data[0];
  const isResponse = (serviceId & 0x40) !== 0;
  const baseService = isResponse ? (serviceId - 0x40) : serviceId;
  const serviceName = UDS_SERVICE_NAMES[baseService] || `Unknown(0x${baseService.toString(16).toUpperCase()})`;

  // Check for Negative Response
  if (serviceId === 0x7F && data.length >= 3) {
    const rejectedService = data[1];
    const nrc = data[2];
    const nrcInfo = NRC_DESCRIPTIONS[nrc];
    
    // Security access rejection
    if (rejectedService === 0x27) {
      return {
        frameType: 'security_reject',
        parsed: {
          service: rejectedService,
          serviceName: 'SecurityAccess',
          nrc,
          nrcDescription: nrcInfo?.short || `NRC 0x${nrc.toString(16).toUpperCase()}`,
        }
      };
    }
    
    return {
      frameType: 'negative_response',
      parsed: {
        service: rejectedService,
        serviceName: UDS_SERVICE_NAMES[rejectedService] || `Unknown(0x${rejectedService.toString(16).toUpperCase()})`,
        nrc,
        nrcDescription: nrcInfo?.short || `NRC 0x${nrc.toString(16).toUpperCase()}`,
      }
    };
  }

  // Security Access (0x27 request, 0x67 response)
  if (baseService === 0x27) {
    if (data.length >= 2) {
      const subFunction = data[1];
      const isOddLevel = (subFunction % 2) === 1;
      
      if (isResponse) {
        // 0x67 response
        if (isOddLevel && data.length >= 3) {
          // Seed response (67 01/03/05 + seed bytes)
          const seed = data.slice(2);
          return {
            frameType: 'security_seed',
            parsed: {
              service: 0x27,
              serviceName: 'SecurityAccess',
              subFunction,
              securityLevel: subFunction,
              seed,
            }
          };
        } else {
          // Key accepted response (67 02/04/06)
          return {
            frameType: 'security_success',
            parsed: {
              service: 0x27,
              serviceName: 'SecurityAccess',
              subFunction,
              securityLevel: subFunction - 1,
            }
          };
        }
      } else {
        // 0x27 request
        if (!isOddLevel && data.length >= 3) {
          // Key submission (27 02/04/06 + key bytes)
          const key = data.slice(2);
          return {
            frameType: 'security_key',
            parsed: {
              service: 0x27,
              serviceName: 'SecurityAccess',
              subFunction,
              securityLevel: subFunction - 1,
              key,
            }
          };
        }
        // Seed request (27 01/03/05)
        return {
          frameType: 'uds_request',
          parsed: {
            service: 0x27,
            serviceName: 'SecurityAccess',
            subFunction,
            securityLevel: subFunction,
          }
        };
      }
    }
  }

  // Read Data By Identifier (0x22 request, 0x62 response)
  if (baseService === 0x22) {
    if (data.length >= 3) {
      const did = (data[1] << 8) | data[2];
      const didName = KNOWN_DIDS[did] || `DID 0x${did.toString(16).toUpperCase()}`;
      
      if (isResponse) {
        // Positive response with data
        if (did === 0xF18C && data.length >= 8) {
          // CSN response
          const csn = data.slice(3, 8);
          return {
            frameType: 'csn_response',
            parsed: {
              service: 0x22,
              serviceName: 'ReadDataByIdentifier',
              did,
              didName,
              csn,
            }
          };
        }
        if (did === 0xF190 && data.length >= 20) {
          // VIN response
          const vinBytes = data.slice(3, 20);
          let vin = '';
          for (let i = 0; i < vinBytes.length; i++) {
            vin += String.fromCharCode(vinBytes[i]);
          }
          return {
            frameType: 'vin_response',
            parsed: {
              service: 0x22,
              serviceName: 'ReadDataByIdentifier',
              did,
              didName,
              vin,
            }
          };
        }
        return {
          frameType: 'uds_response',
          parsed: {
            service: 0x22,
            serviceName: 'ReadDataByIdentifier',
            did,
            didName,
          }
        };
      }
      return {
        frameType: 'uds_request',
        parsed: {
          service: 0x22,
          serviceName: 'ReadDataByIdentifier',
          did,
          didName,
        }
      };
    }
  }

  // Generic UDS
  return {
    frameType: isResponse ? 'uds_response' : 'uds_request',
    parsed: {
      service: baseService,
      serviceName,
    }
  };
}

/**
 * Get color class for sniffed frame type
 */
export function getSnifferFrameColor(frameType: SniffedFrameType): string {
  switch (frameType) {
    case 'security_seed':
      return 'text-green-400 bg-green-500/10';
    case 'security_key':
      return 'text-yellow-400 bg-yellow-500/10';
    case 'security_success':
      return 'text-emerald-400 bg-emerald-500/10';
    case 'security_reject':
      return 'text-red-400 bg-red-500/10';
    case 'csn_response':
      return 'text-blue-400 bg-blue-500/10';
    case 'vin_response':
      return 'text-purple-400 bg-purple-500/10';
    case 'negative_response':
      return 'text-orange-400 bg-orange-500/10';
    case 'uds_request':
      return 'text-gray-300';
    case 'uds_response':
      return 'text-gray-400';
    default:
      return 'text-gray-500';
  }
}

/**
 * Get emoji for sniffed frame type
 */
export function getSnifferFrameEmoji(frameType: SniffedFrameType): string {
  switch (frameType) {
    case 'security_seed':
      return '🌱';
    case 'security_key':
      return '🔑';
    case 'security_success':
      return 'OK';
    case 'security_reject':
      return 'FAIL';
    case 'csn_response':
      return '🔢';
    case 'vin_response':
      return '🚗';
    case 'negative_response':
      return '⚠️';
    case 'uds_request':
      return '📤';
    case 'uds_response':
      return '📥';
    default:
      return '📦';
  }
}

// ========== CAN SNIFFER PROTOCOL (ELM327 + ARDUINO) ==========

export class CANSnifferProtocol {
  private port: SerialPort | null = null;
  private reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
  private writer: WritableStreamDefaultWriter<Uint8Array> | null = null;
  private running = false;
  private frameBuffer = '';
  private onFrameCallback: ((frame: SniffedFrame) => void) | null = null;
  private lastError: string = '';
  private isELM327 = false;

  static isSupported(): boolean {
    return 'serial' in navigator;
  }

  getLastError(): string {
    return this.lastError;
  }
  
  private async sendCommand(cmd: string): Promise<void> {
    if (!this.writer) return;
    const encoder = new TextEncoder();
    await this.writer.write(encoder.encode(cmd + '\r'));
    await new Promise(r => setTimeout(r, 50));
  }
  
  private async initELM327(): Promise<boolean> {
    console.log('Sniffer: Initializing ELM327 for CAN monitor mode...');
    
    try {
      // Reset
      await this.sendCommand('ATZ');
      await new Promise(r => setTimeout(r, 1000));
      
      // Drain any pending data
      await this.drainReader();
      
      // Echo off
      await this.sendCommand('ATE0');
      await new Promise(r => setTimeout(r, 100));
      await this.drainReader();
      
      // Headers on (show CAN IDs)
      await this.sendCommand('ATH1');
      await new Promise(r => setTimeout(r, 100));
      await this.drainReader();
      
      // Spaces ON for readable output
      await this.sendCommand('ATS1');
      await new Promise(r => setTimeout(r, 100));
      await this.drainReader();
      
      // Set protocol to CAN 500kbps (protocol 6)
      await this.sendCommand('ATSP6');
      await new Promise(r => setTimeout(r, 100));
      await this.drainReader();
      
      // CAN auto formatting off for raw output
      await this.sendCommand('ATCAF0');
      await new Promise(r => setTimeout(r, 100));
      await this.drainReader();
      
      // Hide DLC (Data Length Code) for cleaner parsing
      await this.sendCommand('ATD0');
      await new Promise(r => setTimeout(r, 100));
      await this.drainReader();
      
      console.log('Sniffer: ELM327 initialized, ready for monitor mode');
      this.isELM327 = true;
      return true;
    } catch (e) {
      console.error('Sniffer: ELM327 init failed:', e);
      return false;
    }
  }
  
  private async drainReader(): Promise<void> {
    if (!this.reader) return;
    // Read and discard any pending data
    const decoder = new TextDecoder();
    try {
      // Use a short timeout read
      const result = await Promise.race([
        this.reader.read(),
        new Promise<{value: undefined, done: true}>((resolve) => 
          setTimeout(() => resolve({value: undefined, done: true}), 100)
        )
      ]);
      if (result.value) {
        const text = decoder.decode(result.value);
        console.log('Sniffer drain:', text.substring(0, 100));
      }
    } catch (e) {
      // ignore
    }
  }

  async connectToPort(port: SerialPort): Promise<boolean> {
    this.lastError = '';
    try {
      // Clean up any existing connection first
      await this.disconnect();
      
      this.port = port;
      
      // AGGRESSIVE: Force port recovery - close any existing locks
      console.log('CAN Sniffer: Attempting aggressive port recovery...');
      
      // Try to forcefully close the port multiple times
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          console.log(`Sniffer: Force close attempt ${attempt + 1}...`);
          
          // Try to release any reader/writer that might still exist
          if (this.port.readable !== null) {
            try {
              const reader = this.port.readable.getReader();
              await reader.cancel().catch(() => {});
              reader.releaseLock();
            } catch (e) {}
          }
          
          if (this.port.writable !== null) {
            try {
              const writer = this.port.writable.getWriter();
              await writer.abort().catch(() => {});
              writer.releaseLock();
            } catch (e) {}
          }
          
          // Try to close
          try {
            await this.port.close();
            console.log('Sniffer: Port force-closed successfully');
            break;
          } catch (e) {
            console.log(`Sniffer: Force close attempt ${attempt + 1} failed (will retry):`, e);
            await new Promise(resolve => setTimeout(resolve, 100 * (attempt + 1)));
          }
        } catch (e) {
          console.log(`Sniffer: Force recovery attempt ${attempt + 1} error:`, e);
        }
      }
      
      // Now try to open
      await new Promise(resolve => setTimeout(resolve, 200));
      
      try {
        await safeOpenPort(this.port, 115200);
      } catch (e) {
        const err = e as any;
        this.lastError = `Port open failed: ${err.message || err}`;
        console.error('Sniffer: Failed to open port:', err.message || err);
        return false;
      }

      if (!this.port.readable || !this.port.writable) {
        this.lastError = 'Port not readable/writable after open';
        console.error('Sniffer: Port not readable/writable');
        return false;
      }

      this.reader = this.port.readable.getReader();
      this.writer = this.port.writable.getWriter();
      
      // Initialize ELM327 for monitoring
      const elmInit = await this.initELM327();
      if (!elmInit) {
        console.log('Sniffer: Not ELM327 or init failed, assuming Arduino mode');
        this.isELM327 = false;
      }
      
      console.log(`CAN Sniffer connected - ${this.isELM327 ? 'ELM327' : 'Arduino'} mode`);
      return true;
    } catch (error) {
      const err = error as any;
      this.lastError = `Connection error: ${err.message || err}`;
      console.error('CAN Sniffer connection failed:', error);
      return false;
    }
  }

  async disconnect(): Promise<void> {
    this.running = false;
    try {
      // For ELM327, send a character to stop ATMA
      if (this.isELM327 && this.writer) {
        try {
          const encoder = new TextEncoder();
          await this.writer.write(encoder.encode('\r'));
        } catch (e) {}
      }
      
      if (this.reader) {
        try {
          await this.reader.cancel();
          this.reader.releaseLock();
        } catch (e) {
          console.log('Sniffer reader cleanup error (ignored):', e);
        }
      }
      if (this.writer) {
        try {
          await this.writer.close();
        } catch (e) {
          console.log('Sniffer writer cleanup error (ignored):', e);
        }
      }
      if (this.port) {
        try {
          await this.port.close();
        } catch (e) {
          console.log('Sniffer port close error (ignored):', e);
        }
      }
    } catch (error) {
      console.log('Sniffer disconnect error (ignored):', error);
    } finally {
      this.reader = null;
      this.writer = null;
      this.port = null;
      this.isELM327 = false;
    }
  }

  /**
   * Start passive sniffing - reads all incoming CAN frames
   * For ELM327: Sends ATMA command to start CAN monitor mode
   * For Arduino: Just starts reading incoming frames
   */
  async startSniffing(onFrame: (frame: SniffedFrame) => void): Promise<void> {
    if (!this.reader) {
      console.error('Sniffer: Not connected');
      return;
    }

    this.onFrameCallback = onFrame;
    this.running = true;
    
    // For ELM327, send ATMA to start monitoring all CAN traffic
    if (this.isELM327 && this.writer) {
      console.log('Sniffer: Sending ATMA to start CAN monitor...');
      await this.sendCommand('ATMA');
    }
    
    this.sniffLoop();
  }

  async stopSniffing(): Promise<void> {
    this.running = false;
    this.onFrameCallback = null;
    
    // For ELM327, send any character to stop ATMA
    if (this.isELM327 && this.writer) {
      try {
        const encoder = new TextEncoder();
        await this.writer.write(encoder.encode('\r'));
        console.log('Sniffer: Sent stop command to ELM327');
      } catch (e) {
        console.log('Sniffer: Stop command error (ignored):', e);
      }
    }
  }

  private async sniffLoop(): Promise<void> {
    const decoder = new TextDecoder();
    let bytesReceived = 0;
    let linesProcessed = 0;
    
    console.log('Sniffer: Starting sniff loop...');
    console.log('Sniffer: onFrameCallback is:', this.onFrameCallback ? 'SET' : 'NULL');
    
    while (this.running && this.reader) {
      try {
        const { value, done } = await this.reader.read();
        
        if (done) {
          console.log('Sniffer: Reader closed');
          break;
        }
        
        if (!value) continue;
        
        bytesReceived += value.length;
        const chunk = decoder.decode(value);
        this.frameBuffer += chunk;
        
        // Log raw data periodically
        if (bytesReceived % 500 < value.length) {
          console.log(`Sniffer: ${bytesReceived} bytes received, buffer: "${this.frameBuffer.substring(0, 100)}..."`);
        }
        
        // Also process on carriage return (ELM327 uses \r)
        while (this.frameBuffer.includes('\n') || this.frameBuffer.includes('\r')) {
          let newlineIndex = this.frameBuffer.indexOf('\n');
          const crIndex = this.frameBuffer.indexOf('\r');
          
          if (crIndex >= 0 && (newlineIndex < 0 || crIndex < newlineIndex)) {
            newlineIndex = crIndex;
          }
          
          if (newlineIndex < 0) break;
          
          const line = this.frameBuffer.substring(0, newlineIndex).trim();
          this.frameBuffer = this.frameBuffer.substring(newlineIndex + 1);
          
          if (line.length > 0) {
            linesProcessed++;
            if (linesProcessed <= 20 || linesProcessed % 100 === 0) {
              console.log(`Sniffer line ${linesProcessed}: "${line}"`);
            }
            try {
              this.processLine(line);
            } catch (e) {
              console.error(`Sniffer processLine error on line "${line}":`, e);
            }
          }
        }
      } catch (e) {
        if (this.running) {
          console.error('Sniffer read error:', e);
        }
        break;
      }
    }
    
    console.log(`Sniffer: Loop ended. Total bytes: ${bytesReceived}, lines: ${linesProcessed}`);
  }

  private processLine(line: string): void {
    console.log(`Sniffer processLine called with: "${line}"`);
    
    // Skip ELM327 noise lines
    if (line.startsWith('>') || line.startsWith('OK') || line.startsWith('SEARCHING') ||
        line.startsWith('ELM') || line.startsWith('AT') || line === 'NO DATA' ||
        line === 'STOPPED' || line === 'CAN ERROR' || line === '?') {
      console.log(`Sniffer processLine: Skipping noise line`);
      return;
    }
    
    let canId: number = 0;
    let dataBytes: number[] = [];
    let dataHex: string = '';
    
    // Check for Arduino format: "XXX:YYYYYYYYYYYY"
    if (line.includes(':')) {
      const parts = line.split(':');
      if (parts.length < 2) return;
      
      canId = parseInt(parts[0], 16);
      if (isNaN(canId)) return;
      
      dataHex = parts[1];
      dataBytes = dataHex.match(/.{1,2}/g)?.map(b => parseInt(b, 16)) || [];
    } else {
      // ELM327 format: "144 8 20 DD 04 00 00 02 DC 18" 
      // = CAN_ID DLC DATA_BYTES...
      const parts = line.split(/\s+/).filter(p => p.length > 0);
      if (parts.length < 3) return;
      
      // First part is CAN ID (3 hex chars for 11-bit)
      canId = parseInt(parts[0], 16);
      if (isNaN(canId)) return;
      
      // Second part is DLC (data length) - use it to know how many bytes to read
      const dlc = parseInt(parts[1], 10);
      if (isNaN(dlc) || dlc < 1 || dlc > 8) {
        // If second part isn't a valid DLC (1-8), treat it as data
        for (let i = 1; i < parts.length; i++) {
          const byte = parseInt(parts[i], 16);
          if (!isNaN(byte)) {
            dataBytes.push(byte);
          }
        }
      } else {
        // Skip DLC (parts[1]), read data bytes starting from parts[2]
        for (let i = 2; i < parts.length && dataBytes.length < dlc; i++) {
          const byte = parseInt(parts[i], 16);
          if (!isNaN(byte)) {
            dataBytes.push(byte);
          }
        }
      }
      
      dataHex = dataBytes.map(b => b.toString(16).toUpperCase().padStart(2, '0')).join('');
    }
    
    if (dataBytes.length === 0) return;
    
    const data = new Uint8Array(dataBytes);
    
    // Parse UDS content
    const { frameType, parsed } = parseUDSFrame(canId, data);
    
    const frame: SniffedFrame = {
      id: Math.random().toString(36).substring(7),
      timestamp: Date.now(),
      canId,
      canIdHex: canId.toString(16).toUpperCase().padStart(3, '0'),
      data,
      dataHex: dataHex.toUpperCase(),
      direction: 'rx',
      frameType,
      udsService: parsed?.service,
      udsServiceName: parsed?.serviceName,
      parsed,
    };
    
    console.log(`Sniffer FRAME: ${frame.canIdHex} -> ${frame.dataHex} (${dataBytes.length} bytes)`);
    
    if (this.onFrameCallback) {
      console.log('Sniffer: Invoking onFrameCallback...');
      this.onFrameCallback(frame);
    } else {
      console.log('Sniffer: onFrameCallback is NULL!');
    }
  }

  isConnected(): boolean {
    return this.port !== null;
  }

  isSniffing(): boolean {
    return this.running;
  }
}

// ========== SNIFFER CAPTURE MANAGEMENT ==========

const SNIFFER_STORAGE_KEY = 'can_sniffer_captures';

let snifferCaptures: SecurityCapture[] = [];
let pendingSecurityExchanges: Map<number, Partial<SecurityCapture>> = new Map();

/**
 * Process a sniffed frame and build security capture pairs
 */
export function processSniffedFrame(frame: SniffedFrame): SecurityCapture | null {
  if (!frame.parsed) return null;
  
  const canId = frame.canId;
  
  // Track security access exchanges
  if (frame.frameType === 'security_seed') {
    // Start of a security exchange
    const capture: Partial<SecurityCapture> = {
      id: Math.random().toString(36).substring(7),
      timestamp: frame.timestamp,
      canId,
      seedFrame: frame,
      securityLevel: frame.parsed.securityLevel,
      seed: frame.parsed.seed,
    };
    pendingSecurityExchanges.set(canId, capture);
    return null;
  }
  
  if (frame.frameType === 'security_key') {
    const pending = pendingSecurityExchanges.get(canId - 8) || pendingSecurityExchanges.get(canId);
    if (pending) {
      pending.keyFrame = frame;
      pending.key = frame.parsed.key;
    }
    return null;
  }
  
  if (frame.frameType === 'security_success' || frame.frameType === 'security_reject') {
    // Look for pending exchange (response ID is usually request ID + 8)
    const requestId = canId - 8;
    const pending = pendingSecurityExchanges.get(requestId);
    
    if (pending) {
      pending.resultFrame = frame;
      pending.success = frame.frameType === 'security_success';
      
      // Complete capture
      const complete: SecurityCapture = {
        id: pending.id || Math.random().toString(36).substring(7),
        timestamp: pending.timestamp || frame.timestamp,
        canId: requestId,
        seedFrame: pending.seedFrame,
        keyFrame: pending.keyFrame,
        resultFrame: frame,
        securityLevel: pending.securityLevel,
        seed: pending.seed,
        key: pending.key,
        success: pending.success,
      };
      
      snifferCaptures.push(complete);
      pendingSecurityExchanges.delete(requestId);
      saveSnifferCaptures();
      
      return complete;
    }
  }
  
  if (frame.frameType === 'csn_response') {
    // Try to attach CSN to most recent pending or completed capture for this module
    const requestId = canId - 8;
    const pending = pendingSecurityExchanges.get(requestId);
    if (pending) {
      pending.csnFrame = frame;
      pending.csn = frame.parsed.csn;
    }
  }
  
  return null;
}

export function getSnifferCaptures(): SecurityCapture[] {
  return [...snifferCaptures];
}

export function clearSnifferCaptures(): void {
  snifferCaptures = [];
  pendingSecurityExchanges.clear();
  saveSnifferCaptures();
}

export function loadSnifferCaptures(): void {
  try {
    const stored = localStorage.getItem(SNIFFER_STORAGE_KEY);
    if (stored) {
      snifferCaptures = JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load sniffer captures:', e);
  }
}

function saveSnifferCaptures(): void {
  try {
    localStorage.setItem(SNIFFER_STORAGE_KEY, JSON.stringify(snifferCaptures));
  } catch (e) {
    console.error('Failed to save sniffer captures:', e);
  }
}

export function exportSnifferCapturesToJSON(): string {
  const exports = snifferCaptures.map(c => ({
    timestamp: new Date(c.timestamp).toISOString(),
    canId: c.canId,
    canIdHex: '0x' + c.canId.toString(16).toUpperCase(),
    securityLevel: c.securityLevel,
    seedHex: c.seed ? formatHexBytes(c.seed).replace(/ /g, '') : undefined,
    keyHex: c.key ? formatHexBytes(c.key).replace(/ /g, '') : undefined,
    csnHex: c.csn ? formatHexBytes(c.csn).replace(/ /g, '') : undefined,
    success: c.success,
  }));
  
  return JSON.stringify({
    exportDate: new Date().toISOString(),
    captureCount: exports.length,
    captures: exports,
  }, null, 2);
}

// =============================================================================
// CONNECTION MANAGER - Auto-reconnect and connection health monitoring
// =============================================================================

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'reconnecting' | 'error';

export interface ConnectionEvent {
  type: 'connected' | 'disconnected' | 'reconnecting' | 'reconnected' | 'error';
  message?: string;
  timestamp: number;
}

export type ConnectionEventCallback = (event: ConnectionEvent) => void;

interface SavedConnectionSettings {
  hardwareType: HardwareType;
  baudRate: number;
  lastConnected: string;
}

export class ConnectionManager {
  private protocol: ELM327Protocol | J2534Protocol | ArduinoCANProtocol | null = null;
  private hardwareType: HardwareType | null = null;
  private port: SerialPort | null = null;
  private state: ConnectionState = 'disconnected';
  private listeners: ConnectionEventCallback[] = [];
  private healthCheckInterval: number | null = null;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectDelayMs: number = 2000;
  private lastHealthCheck: number = 0;
  private healthCheckIntervalMs: number = 5000;
  private readonly STORAGE_KEY = 'obd2_connection_settings';
  
  getState(): ConnectionState {
    return this.state;
  }
  
  getProtocol(): ELM327Protocol | J2534Protocol | ArduinoCANProtocol | null {
    return this.protocol;
  }
  
  getHardwareType(): HardwareType | null {
    return this.hardwareType;
  }

  /**
   * Save connection settings to localStorage
   */
  private saveSettings(baudRate: number): void {
    if (!this.hardwareType) return;
    
    const settings: SavedConnectionSettings = {
      hardwareType: this.hardwareType,
      baudRate,
      lastConnected: new Date().toISOString()
    };
    
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save connection settings:', e);
    }
  }

  /**
   * Load saved connection settings from localStorage
   */
  getSavedSettings(): SavedConnectionSettings | null {
    try {
      const saved = localStorage.getItem(this.STORAGE_KEY);
      if (!saved) return null;
      return JSON.parse(saved) as SavedConnectionSettings;
    } catch (e) {
      console.error('Failed to load connection settings:', e);
      return null;
    }
  }

  /**
   * Clear saved connection settings
   */
  clearSavedSettings(): void {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
    } catch (e) {
      console.error('Failed to clear connection settings:', e);
    }
  }

  /**
   * Attempt to reconnect using saved settings
   * Returns true if reconnection was attempted (regardless of success)
   * 
   * NOTE: Web Serial API requires user gesture for requestPort().
   * This method will only work if the port was previously granted permission.
   * If permission is needed, it will fail silently and return false.
   */
  async autoReconnect(): Promise<boolean> {
    const saved = this.getSavedSettings();
    if (!saved) {
      return false;
    }

    // Don't auto-reconnect if already connected
    if (this.state === 'connected' || this.state === 'connecting') {
      return false;
    }

    console.log(`Attempting auto-reconnect to ${saved.hardwareType}...`);
    
    try {
      // For Web Serial, check if we have previously granted ports
      if ('serial' in navigator) {
        const ports = await navigator.serial.getPorts();
        if (ports.length === 0) {
          // No previously granted ports - cannot auto-reconnect without user gesture
          console.log('No previously granted serial ports. User must manually connect.');
          return false; // Did not attempt
        }
      }
      
      const success = await this.connect(saved.hardwareType);
      return true; // Attempted reconnection
    } catch (e) {
      // Check if this is a permission error
      const errorMsg = String(e);
      if (errorMsg.includes('user gesture') || errorMsg.includes('permission')) {
        console.log('Auto-reconnect requires user gesture. User must manually connect.');
        return false; // Did not actually attempt due to permission
      }
      
      console.error('Auto-reconnect failed:', e);
      return true; // Attempted but failed for other reasons
    }
  }
  
  onConnectionEvent(callback: ConnectionEventCallback): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }
  
  private emit(event: ConnectionEvent): void {
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (e) {
        console.error('Connection event listener error:', e);
      }
    }
  }
  
  private setState(state: ConnectionState): void {
    this.state = state;
  }
  
  async connect(type: HardwareType, port?: SerialPort): Promise<boolean> {
    this.setState('connecting');
    this.hardwareType = type;
    this.port = port || null;
    
    try {
      if (type === 'elm327') {
        this.protocol = new ELM327Protocol();
        const success = port 
          ? await this.protocol.connectToPort(port)
          : await this.protocol.connect();
        
        if (success) {
          this.setState('connected');
          this.emit({ type: 'connected', timestamp: Date.now() });
          // DISABLED: Health check interferes with active scanning
          // this.startHealthCheck();
          this.reconnectAttempts = 0;
          this.saveSettings(38400); // Default ELM327 baud rate
          return true;
        }
      } else if (type === 'j2534') {
        this.protocol = new J2534Protocol();
        const success = await this.protocol.connect();
        
        if (success) {
          this.setState('connected');
          this.emit({ type: 'connected', timestamp: Date.now() });
          // DISABLED: Health check interferes with active scanning
          // this.startHealthCheck();
          this.reconnectAttempts = 0;
          this.saveSettings(500000); // J2534 default
          return true;
        }
      } else if (type === 'arduino') {
        this.protocol = new ArduinoCANProtocol();
        const success = port
          ? await this.protocol.connectToPort(port)
          : await this.protocol.connect();
        
        if (success) {
          this.setState('connected');
          this.emit({ type: 'connected', timestamp: Date.now() });
          // DISABLED: Health check interferes with active scanning
          // this.startHealthCheck();
          this.reconnectAttempts = 0;
          this.saveSettings(500000); // Arduino CAN default
          return true;
        }
      }
      
      this.setState('error');
      this.emit({ type: 'error', message: 'Connection failed', timestamp: Date.now() });
      return false;
    } catch (error) {
      const err = error as any;
      this.setState('error');
      this.emit({ type: 'error', message: err.message || 'Connection error', timestamp: Date.now() });
      return false;
    }
  }
  
  async disconnect(): Promise<void> {
    this.stopHealthCheck();
    
    if (this.protocol) {
      try {
        await this.protocol.disconnect();
      } catch (e) {
        console.log('Disconnect error (ignored):', e);
      }
    }
    
    this.protocol = null;
    this.setState('disconnected');
    this.emit({ type: 'disconnected', timestamp: Date.now() });
  }
  
  private startHealthCheck(): void {
    this.stopHealthCheck();
    
    this.healthCheckInterval = window.setInterval(async () => {
      if (this.state !== 'connected' && this.state !== 'reconnecting') {
        return;
      }
      
      const now = Date.now();
      if (now - this.lastHealthCheck < this.healthCheckIntervalMs) {
        return;
      }
      this.lastHealthCheck = now;
      
      const isHealthy = await this.checkConnectionHealth();
      
      if (!isHealthy && this.state === 'connected') {
        console.log('Connection health check failed, attempting reconnect...');
        this.emit({ type: 'disconnected', message: 'Connection lost', timestamp: Date.now() });
        await this.attemptReconnect();
      }
    }, 2000);
  }
  
  private stopHealthCheck(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }
  
  private async checkConnectionHealth(): Promise<boolean> {
    if (!this.protocol) return false;
    
    try {
      if (this.protocol instanceof ELM327Protocol) {
        return await this.protocol.ping();
      } else if (this.protocol instanceof J2534Protocol) {
        return this.protocol.isConnected();
      } else if (this.protocol instanceof ArduinoCANProtocol) {
        return await this.protocol.ping();
      }
      return false;
    } catch {
      return false;
    }
  }
  
  private async attemptReconnect(): Promise<boolean> {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('Max reconnect attempts reached');
      this.setState('error');
      this.emit({ type: 'error', message: 'Max reconnect attempts reached', timestamp: Date.now() });
      this.stopHealthCheck();
      return false;
    }
    
    this.setState('reconnecting');
    this.reconnectAttempts++;
    
    const backoffDelay = this.reconnectDelayMs * Math.pow(1.5, this.reconnectAttempts - 1);
    const cappedDelay = Math.min(backoffDelay, 30000);
    
    this.emit({ 
      type: 'reconnecting', 
      message: `Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} (waiting ${Math.round(cappedDelay / 1000)}s)`, 
      timestamp: Date.now() 
    });
    
    await new Promise(r => setTimeout(r, cappedDelay));
    
    if (this.state !== 'reconnecting') {
      console.log('Reconnect cancelled - state changed');
      return false;
    }
    
    try {
      if (this.hardwareType && this.port) {
        if (this.protocol) {
          try {
            await this.protocol.disconnect();
          } catch {
          }
          this.protocol = null;
        }
        
        const success = await this.connect(this.hardwareType, this.port);
        if (success) {
          console.log('Reconnected successfully');
          this.emit({ type: 'reconnected', timestamp: Date.now() });
          this.reconnectAttempts = 0;
          return true;
        }
      }
    } catch (e) {
      console.log('Reconnect attempt failed:', e);
    }
    
    if (this.reconnectAttempts < this.maxReconnectAttempts && this.state === 'reconnecting') {
      return this.attemptReconnect();
    }
    
    this.setState('error');
    this.stopHealthCheck();
    return false;
  }
  
  resetReconnectAttempts(): void {
    this.reconnectAttempts = 0;
  }
  
  setMaxReconnectAttempts(max: number): void {
    this.maxReconnectAttempts = max;
  }
  
  setReconnectDelay(delayMs: number): void {
    this.reconnectDelayMs = delayMs;
  }
  
  setHealthCheckInterval(intervalMs: number): void {
    this.healthCheckIntervalMs = intervalMs;
  }
}
