/**
 * J2534 VIN Programming Module
 * Professional-grade VIN programming using J2534 PassThru devices (MicroPod, Autel, etc.)
 * 
 * This module provides the comprehensive programVIN method for J2534Protocol
 * with proper timing, security access, and error handling.
 */

import { J2534Protocol } from './obd2-protocol';
import { calculateKey, getSecurityLevel, SECURITY_NRC_DESCRIPTIONS } from './fca-keygen';

const UDS_SERVICES = {
  DIAGNOSTIC_SESSION_CONTROL: 0x10,
  SECURITY_ACCESS: 0x27,
  READ_DATA_BY_ID: 0x22,
  WRITE_DATA_BY_ID: 0x2E,
  TESTER_PRESENT: 0x3E,
};

const VIN_DID = 0xF190;

interface ProgramVINOptions {
  securityLevel?: number;
  programmingTimeout?: number;
}

interface ProgramVINResult {
  success: boolean;
  message: string;
  details?: {
    oldVIN?: string;
    newVIN: string;
    securityLevel?: number;
    algorithm?: string;
  };
}

/**
 * Program VIN using J2534 PassThru device with comprehensive security access
 * 
 * This method implements the full VIN programming workflow:
 * 1. Read current VIN
 * 2. Start Extended Diagnostic Session (0x10 03)
 * 3. Request Security Seed (0x27 01/05)
 * 4. Calculate Key using FCA algorithms
 * 5. Send Security Key (0x27 02/06)
 * 6. Write new VIN (0x2E F190)
 * 7. Verify VIN was written correctly
 * 
 * @param protocol - J2534Protocol instance
 * @param txId - Transmit CAN ID
 * @param rxId - Receive CAN ID
 * @param newVIN - 17-character VIN to write
 * @param onProgress - Progress callback
 * @param options - Security level and timeout options
 */
export async function programVINWithJ2534(
  protocol: J2534Protocol,
  txId: number,
  rxId: number,
  newVIN: string,
  onProgress?: (step: string, progress: number) => void,
  options?: ProgramVINOptions
): Promise<ProgramVINResult> {
  try {
    // Validate VIN
    if (newVIN.length !== 17) {
      return { success: false, message: 'VIN must be exactly 17 characters' };
    }

    // Step 1: Read current VIN
    onProgress?.('Reading current VIN...', 10);
    const currentVIN = await protocol.readVIN(txId, rxId);
    console.log(`[J2534 VIN Programming] Current VIN: ${currentVIN || 'Not readable'}`);

    // Step 2: Start Extended Diagnostic Session (0x10 03)
    onProgress?.('Starting extended diagnostic session...', 20);
    const sessionResponse = await protocol.sendUDS(txId, rxId, [
      UDS_SERVICES.DIAGNOSTIC_SESSION_CONTROL,
      0x03, // Extended Diagnostic Session
    ]);

    if (!sessionResponse || sessionResponse[0] !== (UDS_SERVICES.DIAGNOSTIC_SESSION_CONTROL + 0x40)) {
      return { 
        success: false, 
        message: `Failed to start diagnostic session: ${sessionResponse ? `NRC 0x${sessionResponse[2]?.toString(16).padStart(2, '0')}` : 'No response'}` 
      };
    }
    console.log(`[J2534 VIN Programming] Diagnostic session started`);

    // Wait for module to settle (J2534 devices need proper timing)
    await delay(100);

    // Step 3: Request Security Seed
    onProgress?.('Requesting security seed...', 30);
    const seedLevel = options?.securityLevel ?? 0x01;
    console.log(`[J2534 VIN Programming] Using Security Access Level: 0x${seedLevel.toString(16).padStart(2, '0')}`);

    const seedRequest = [UDS_SERVICES.SECURITY_ACCESS, seedLevel];
    const seedResponse = await protocol.sendUDS(txId, rxId, seedRequest);

    if (!seedResponse || seedResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
      const nrc = seedResponse?.[2];
      const nrcDesc = nrc ? SECURITY_NRC_DESCRIPTIONS[nrc] || `Unknown NRC 0x${nrc.toString(16)}` : 'No response';
      return { 
        success: false, 
        message: `Security seed request failed: ${nrcDesc}` 
      };
    }

    // Extract seed (skip service ID + level response byte)
    const seed = Array.from(seedResponse.slice(2));
    console.log(`[J2534 VIN Programming] Seed received: ${seed.map(b => b.toString(16).padStart(2, '0')).join(' ')}`);

    // Check if already unlocked (seed = 0x00 0x00 0x00 0x00)
    const isAlreadyUnlocked = seed.every(b => b === 0x00);
    if (isAlreadyUnlocked) {
      console.log(`[J2534 VIN Programming] Module already unlocked (zero seed)`);
      onProgress?.('Module already unlocked, writing VIN...', 60);
    } else {
      // Step 4: Calculate Key
      onProgress?.('Calculating security key...', 40);
      const securityConfig = getSecurityLevel(seedLevel);
      if (!securityConfig) {
        return { 
          success: false, 
          message: `Unknown security level: 0x${seedLevel.toString(16)}` 
        };
      }

      const key = calculateKey(seed, securityConfig.algorithm);
      console.log(`[J2534 VIN Programming] Key calculated using ${securityConfig.algorithm}: ${key.map(b => b.toString(16).padStart(2, '0')).join(' ')}`);

      // Step 5: Send Security Key
      onProgress?.('Sending security key...', 50);
      await delay(50); // Small delay before sending key

      const keyRequest = [UDS_SERVICES.SECURITY_ACCESS, seedLevel + 1, ...key];
      const keyResponse = await protocol.sendUDS(txId, rxId, keyRequest);

      if (!keyResponse || keyResponse[0] !== (UDS_SERVICES.SECURITY_ACCESS + 0x40)) {
        const nrc = keyResponse?.[2];
        const nrcDesc = nrc ? SECURITY_NRC_DESCRIPTIONS[nrc] || `Unknown NRC 0x${nrc.toString(16)}` : 'No response';
        return { 
          success: false, 
          message: `Security key rejected: ${nrcDesc}` 
        };
      }

      console.log(`[J2534 VIN Programming] Security access granted`);
      onProgress?.('Security access granted, writing VIN...', 60);
    }

    // Wait before writing (critical for some modules like ADM/EPS)
    await delay(200);

    // Step 6: Write new VIN (0x2E F190 + VIN bytes)
    onProgress?.('Writing new VIN...', 70);
    const vinBytes = Array.from(newVIN).map(c => c.charCodeAt(0));
    const writeRequest = [
      UDS_SERVICES.WRITE_DATA_BY_ID,
      (VIN_DID >> 8) & 0xFF,
      VIN_DID & 0xFF,
      ...vinBytes,
    ];

    const writeTimeout = options?.programmingTimeout ?? 5000;
    console.log(`[J2534 VIN Programming] Writing VIN with ${writeTimeout}ms timeout...`);

    const writeResponse = await protocol.sendUDS(txId, rxId, writeRequest);

    if (!writeResponse || writeResponse[0] !== (UDS_SERVICES.WRITE_DATA_BY_ID + 0x40)) {
      const nrc = writeResponse?.[2];
      const nrcDesc = nrc ? SECURITY_NRC_DESCRIPTIONS[nrc] || `Unknown NRC 0x${nrc.toString(16)}` : 'No response';
      return { 
        success: false, 
        message: `VIN write failed: ${nrcDesc}` 
      };
    }

    console.log(`[J2534 VIN Programming] VIN write successful`);

    // Wait for EEPROM write to complete
    await delay(500);

    // Step 7: Verify VIN
    onProgress?.('Verifying new VIN...', 90);
    const verifyVIN = await protocol.readVIN(txId, rxId);

    if (verifyVIN !== newVIN) {
      return { 
        success: false, 
        message: `VIN verification failed: Read back "${verifyVIN}" instead of "${newVIN}"` 
      };
    }

    onProgress?.('VIN programming complete!', 100);
    console.log(`[J2534 VIN Programming] SUCCESS - VIN changed from ${currentVIN || 'unknown'} to ${newVIN}`);

    return {
      success: true,
      message: 'VIN programmed successfully',
      details: {
        oldVIN: currentVIN || undefined,
        newVIN,
        securityLevel: seedLevel,
        algorithm: getSecurityLevel(seedLevel)?.algorithm,
      },
    };

  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error(`[J2534 VIN Programming] Error:`, error);
    return { 
      success: false, 
      message: `Programming error: ${errorMsg}` 
    };
  }
}

/**
 * Helper: Delay function
 */
function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
