import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ConnectionProvider } from "./contexts/ConnectionContext";
import Home from "./pages/Home";
import VINPatcher from "./pages/VINPatcher";
import VINDecoder from "./pages/VINDecoder";
import LiveProgrammer from "./pages/LiveProgrammer";
import ModuleScanner from "./pages/ModuleScanner";
import ConnectionDiagnostic from "./pages/ConnectionDiagnostic";
import ModuleDatabase from "./pages/ModuleDatabase";
import J2534Sniffer from "./pages/J2534Sniffer";
import DTCReader from "./pages/dtc-reader";
import BCMConfig from "./pages/bcm-config";
import GatewayBypass from "./pages/gateway-bypass";
import RadioCodes from "./pages/radio-codes";
import RFHUBTool from "./pages/rfhub-tool";
import SecurityAccessManager from "./pages/SecurityAccessManager";
import Scripts from "./pages/Scripts";
import AIAssistant from "@/pages/AIAssistant";
import J2534Tester from "@/pages/J2534Tester";
import BatchVINProgrammer from "@/pages/BatchVINProgrammer";
import ModulePairingValidator from "@/pages/ModulePairingValidator";
import VINHistoryTracker from "@/pages/VINHistoryTracker";
import FlashDumpTool from "@/pages/FlashDumpTool";
import DiagnosticReportGenerator from "@/pages/DiagnosticReportGenerator";
import SessionHistory from "@/pages/SessionHistory";
import ModuleCloner from "@/pages/ModuleCloner";
import PinExtraction from "@/pages/PinExtraction";
import SecurityByteSync from "@/pages/SecurityByteSync";
import XTEACalculator from "@/pages/XTEACalculator";
import ModuleComparison from "@/pages/ModuleComparison";
import BatchVINPatcherFiles from "@/pages/BatchVINPatcherFiles";
import SecurityAccessHistory from "./pages/SecurityAccessHistory";
import DTCDatabase from "./pages/DTCDatabase";
import ModulePresets from "./pages/ModulePresets";
import CANSniffer from "./pages/CANSniffer";
import LiveVINProgrammer from "@/pages/LiveVINProgrammer";
import BlankRFHUBWizard from "@/pages/BlankRFHUBWizard";
import HardwareIntegration from "./pages/HardwareIntegration";
import EEPROMViewer from "./pages/EEPROMViewer";
import KnowledgeBase from "./pages/KnowledgeBase";
import VINBatchPatcher from "./pages/VINBatchPatcher";
import VINProgrammingWizard from "./pages/VINProgrammingWizard";
import ModuleFlasher from "./pages/ModuleFlasher";
import VehicleSelector from "./pages/VehicleSelector";
import AlgorithmTester from "./pages/AlgorithmTester";
import SAVParser from "./pages/SAVParser";
import AlgorithmRecommendationEngine from "./pages/AlgorithmRecommendationEngine";
import ModuleDatabaseImporter from "./pages/ModuleDatabaseImporter";
import SeedKeyLearningMode from "./pages/SeedKeyLearningMode";
import ECMBenchProgramming from "./pages/ECMBenchProgramming";
import ActiveDampingProgrammer from "./pages/ActiveDampingProgrammer";
import HardwareDetectionWizard from "./pages/HardwareDetectionWizard";
import HardwareRecommendations from "./pages/HardwareRecommendations";
import VehicleTopologyMap from '@/pages/VehicleTopologyMap';
import BCMConfigEditor from '@/pages/BCMConfigEditor';
import RFHUBPINExtractor from "./pages/RFHUBPINExtractor";
import PSAAlgorithmTester from "./pages/PSAAlgorithmTester";
import SeedKeyOracle from "./pages/SeedKeyOracle";
import EEPROMForensicsAI from "./pages/EEPROMForensicsAI";
import DiagnosticTroubleshooter from "./pages/DiagnosticTroubleshooter";
import VINGhostWriterAI from "./pages/VINGhostWriterAI";
import ModuleCompatibilityOracle from "./pages/ModuleCompatibilityOracle";
import SecurityByteGenerator from "./pages/SecurityByteGenerator";
import NaturalLanguageQuery from "./pages/NaturalLanguageQuery";
import ReverseEngineeringAssistant from "./pages/ReverseEngineeringAssistant";
import AtlantisSecurityAccess from "./pages/AtlantisSecurityAccess";
import HardwareIntegrationDashboard from "./pages/HardwareIntegrationDashboard";
import BatchOperationsSuite from "./pages/BatchOperationsSuite";
import DiagnosticSessionRecording from "./pages/DiagnosticSessionRecording";
import ECUUnlockManager from "./pages/ECUUnlockManager";
import FlashProgrammingManager from "./pages/FlashProgrammingManager";
import J2534FlashAvailability from "./pages/J2534FlashAvailability";
import SecurityGatewayManager from "./pages/SecurityGatewayManager";
import CalibrationManager from "./pages/CalibrationManager";
import AutomatedVINProgrammingWizard from "./pages/AutomatedVINProgrammingWizard";
import EEPROMMapViewer from "./pages/EEPROMMapViewer";
import ModuleBackupRestore from "./pages/ModuleBackupRestore";
import ModuleSwapWizard from "./pages/ModuleSwapWizard";
import QuickModuleClone from "./pages/QuickModuleClone";
import HardwareConnectionWizard from "./pages/HardwareConnectionWizard";
import RealTimeCANMonitor from "./pages/RealTimeCANMonitor";
import VINProgrammingHistory from "./pages/VINProgrammingHistory";
import CloneHistoryAnalytics from "./pages/CloneHistoryAnalytics";
import LLMTest from './pages/LLMTest';
import { LiveDataMonitor } from './pages/LiveDataMonitor';
import { ConnectionStatusBar } from './components/ConnectionStatusBar';
import { ConnectionStatusHeader } from './components/ConnectionStatusHeader';
import { useState } from 'react';
import { ConnectionManager } from './lib/obd2-protocol';
import HardwareWizard from './pages/HardwareWizard';
import SRTLabToolkit from './pages/SRTLabToolkit';
import SessionReplay from './pages/SessionReplay';
import GuidedWorkflows from './pages/GuidedWorkflows';
import ProgrammingTemplates from './pages/ProgrammingTemplates';
import ServiceResets from './pages/ServiceResets';
import CalibrationProcedures from './pages/CalibrationProcedures';
import SpecialFunctions from './pages/SpecialFunctions';
import ProcedureHistory from './pages/ProcedureHistory';
import SRTLabExplorer from './pages/SRTLabExplorer';
import SeedKeyCalculator from './pages/SeedKeyCalculator';
import AlgorithmAutoDetection from './pages/AlgorithmAutoDetection';
import BackupRestore from './pages/BackupRestore';
import LiveDataDecoder from './pages/LiveDataDecoder';
import ScanHistory from './pages/ScanHistory';
import VINCRCCalculator from './pages/VINCRCCalculator';
import BatchFirmwareProcessor from './pages/BatchFirmwareProcessor';
import FirmwareAnalyzer from './pages/FirmwareAnalyzer';
import ECUCommGenerator from './pages/ECUCommGenerator';
import BCMConfigTool from './pages/BCMConfigTool';
import ParamCompatibility from './pages/ParamCompatibility';
import RoutineControlExecutor from './pages/RoutineControlExecutor';
import FreezeFrameAnalyzer from './pages/FreezeFrameAnalyzer';
import DieselEngineDashboard from './pages/DieselEngineDashboard';
import AlgorithmTestBench from './pages/AlgorithmTestBench';
import AgenticDiagnosticAssistant from './pages/AgenticDiagnosticAssistant';
import UniversalProgrammer from './pages/UniversalProgrammer';
import VideoTutorials from './pages/VideoTutorials';
import ModuleCloningHub from './pages/ModuleCloningHub';
import DIDExplorer from './pages/DIDExplorer';
import GatewayCloneTool from './pages/GatewayCloneTool';
import ModuleCloneTool from './pages/ModuleCloneTool';
import RFHUBVINPatcher from './pages/RFHUBVINPatcher';
import ValidationHistory from './pages/ValidationHistory';
import RFHUBSKREEMExtractor from '@/pages/RFHUBSKREEMExtractor';
import BCMRecovery from '@/pages/BCMRecovery';
import SkreemKeyDatabase from '@/pages/SkreemKeyDatabase';
import EEPROMStructureViewer from './pages/EEPROMStructureViewer';
import J2534Bridge from './pages/J2534Bridge';
import OfflineVINPatcher from './pages/OfflineVINPatcher';
import BCMValidator from './pages/BCMValidator';
import BCMBatchValidator from './pages/BCMBatchValidator';

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/vin-patcher"} component={VINPatcher} />
      <Route path={"/offline-vin-patcher"} component={OfflineVINPatcher} />
      <Route path={'/vin-decoder'} component={VINDecoder} />
      <Route path={'/algorithm-auto-detection'} component={AlgorithmAutoDetection} />
      <Route path={"/live-programmer"} component={LiveProgrammer} />
      <Route path={"/module-scanner"} component={ModuleScanner} />
      <Route path={"/connection-diagnostic"} component={ConnectionDiagnostic} />
      <Route path={"/module-database"} component={ModuleDatabase} />
      <Route path={"/can-sniffer"} component={CANSniffer} />
      <Route path={"/j2534-sniffer"} component={J2534Sniffer} />
      <Route path={"/dtc-reader"} component={DTCReader} />
      <Route path={"/bcm-coder"} component={BCMConfig} />
      <Route path={"/gateway-bypass"} component={GatewayBypass} />
      <Route path={"/radio-codes"} component={RadioCodes} />
      <Route path={"/rfhub-tool"} component={RFHUBTool} />
      <Route path={"/security-access"} component={SecurityAccessManager} />
      <Route path={"/scripts"} component={Scripts} />
      <Route path="/ai-assistant" component={AIAssistant} />
      <Route path="/j2534-tester" component={J2534Tester} />
      <Route path="/batch-vin" component={BatchVINProgrammer} />
      <Route path="/pairing-validator" component={ModulePairingValidator} />
      <Route path="/vin-history" component={VINHistoryTracker} />
      <Route path="/flash-dump" component={FlashDumpTool} />
      <Route path="/diagnostic-report" component={DiagnosticReportGenerator} />
      <Route path="/session-history" component={SessionHistory} />
      <Route path="/module-cloner" component={ModuleCloner} />
      <Route path="/pin-extraction" component={PinExtraction} />
      <Route path="/security-byte-sync" component={SecurityByteSync} />
      <Route path="/xtea-calculator" component={XTEACalculator} />
      <Route path="/module-comparison" component={ModuleComparison} />
      <Route path="/batch-vin-patcher" component={BatchVINPatcherFiles} />
        <Route path="/security-access-history" component={SecurityAccessHistory} />
        <Route path="/dtc-database" component={DTCDatabase} />
        <Route path="/module-presets" component={ModulePresets} />
        <Route path="/can-sniffer" component={CANSniffer} />
        <Route path="/live-vin-programmer" component={LiveVINProgrammer} />
        <Route path="/blank-rfhub-wizard" component={BlankRFHUBWizard} />
        <Route path="/hardware-integration" component={HardwareIntegration} />
        <Route path="/eeprom-viewer" component={EEPROMViewer} />
        <Route path="/knowledge-base" component={KnowledgeBase} />
        <Route path="/vin-batch-patcher" component={VINBatchPatcher} />
        <Route path="/eeprom-structure-viewer" component={EEPROMStructureViewer} />
        <Route path="/j2534-bridge" component={J2534Bridge} />
        <Route path="/vin-programming-wizard" component={VINProgrammingWizard} />
        <Route path="/module-flasher" component={ModuleFlasher} />
        <Route path="/vehicle-selector" component={VehicleSelector} />
        <Route path="/algorithm-tester" component={AlgorithmTester} />
        <Route path="/sav-parser" component={SAVParser} />
        <Route path="/algorithm-recommendation" component={AlgorithmRecommendationEngine} />
        <Route path="/module-database-importer" component={ModuleDatabaseImporter} />
        <Route path="/seed-key-learning" component={SeedKeyLearningMode} />
        <Route path="/hardware-detection" component={HardwareDetectionWizard} />
        <Route path="/hardware-recommendations" component={HardwareRecommendations} />
        <Route path="/vehicle-topology-map" component={VehicleTopologyMap} />
        <Route path="/bcm-config-editor" component={BCMConfigEditor} />
        <Route path="/rfhub-pin-extractor" component={RFHUBPINExtractor} />
      <Route path="/rfhub-vin-patcher" component={RFHUBVINPatcher} />
        <Route path="/validation-history" component={ValidationHistory} />
        <Route path="/rfhub-skreem-extractor" component={RFHUBSKREEMExtractor} />
        <Route path="/skreem-key-database" component={SkreemKeyDatabase} />
        <Route path="/bcm-recovery" component={BCMRecovery} />
        <Route path="/psa-algorithm-tester" component={PSAAlgorithmTester} />
        <Route path="/seed-key-oracle" component={SeedKeyOracle} />
        <Route path="/eeprom-forensics" component={EEPROMForensicsAI} />
        <Route path="/diagnostic-troubleshooter" component={DiagnosticTroubleshooter} />
        <Route path="/vin-ghost-writer" component={VINGhostWriterAI} />
        <Route path="/module-compatibility" component={ModuleCompatibilityOracle} />
        <Route path="/security-byte-generator" component={SecurityByteGenerator} />
        <Route path="/natural-language-query" component={NaturalLanguageQuery} />
        <Route path="/reverse-engineering" component={ReverseEngineeringAssistant} />
        <Route path="/atlantis-security-access" component={AtlantisSecurityAccess} />
        <Route path="/hardware-integration-dashboard" component={HardwareIntegrationDashboard} />
        <Route path="/batch-operations-suite" component={BatchOperationsSuite} />
        <Route path="/diagnostic-session-recording" component={DiagnosticSessionRecording} />
        <Route path="/ecu-unlock-manager" component={ECUUnlockManager} />
        <Route path="/flash-programming-manager" component={FlashProgrammingManager} />
        <Route path="/j2534-flash-availability" component={J2534FlashAvailability} />
        <Route path="/security-gateway-manager" component={SecurityGatewayManager} />
        <Route path="/calibration-manager" component={CalibrationManager} />
        <Route path="/automated-vin-programming" component={AutomatedVINProgrammingWizard} />
        <Route path="/eeprom-map-viewer" component={EEPROMMapViewer} />
        <Route path="/module-backup-restore" component={ModuleBackupRestore} />
        <Route path="/module-swap-wizard" component={ModuleSwapWizard} />
        <Route path="/quick-module-clone" component={QuickModuleClone} />
        <Route path="/hardware-connection-wizard" component={HardwareConnectionWizard} />
        <Route path="/realtime-can-monitor" component={RealTimeCANMonitor} />
        <Route path="/vin-programming-history" component={VINProgrammingHistory} />
        <Route path="/clone-history-analytics" component={CloneHistoryAnalytics} />
        <Route path="/llm-test" component={LLMTest} />
        <Route path="/live-data-monitor" component={LiveDataMonitor} />
        <Route path="/module-scanner" component={ModuleScanner} />
      <Route path="/scan-history" component={ScanHistory} />
      <Route path="/hardware-wizard" component={HardwareWizard} />
      <Route path="/cda6-toolkit" component={SRTLabToolkit} />
      <Route path="/session-replay" component={SessionReplay} />
      <Route path="/guided-workflows" component={GuidedWorkflows} />
      <Route path="/programming-templates" component={ProgrammingTemplates} />
      <Route path="/service-resets" component={ServiceResets} />
      <Route path="/calibration-procedures" component={CalibrationProcedures} />
      <Route path="/special-functions" component={SpecialFunctions} />
      <Route path="/procedure-history" component={ProcedureHistory} />
      <Route path="/alphaobd-explorer" component={SRTLabExplorer} />
      <Route path="/seed-key-calculator" component={SeedKeyCalculator} />
      <Route path="/backup-restore" component={BackupRestore} />
      <Route path="/live-data-decoder" component={LiveDataDecoder} />
      <Route path="/vin-crc-calculator" component={VINCRCCalculator} />
      <Route path="/firmware-analyzer" component={FirmwareAnalyzer} />
      <Route path="/batch-firmware-processor" component={BatchFirmwareProcessor} />
      <Route path="/ecu-comm-generator" component={ECUCommGenerator} />
      <Route path="/bcm-config-tool" component={BCMConfigTool} />
      <Route path="/param-compatibility" component={ParamCompatibility} />
      <Route path="/routine-control-executor" component={RoutineControlExecutor} />
      <Route path="/freeze-frame-analyzer" component={FreezeFrameAnalyzer} />
      <Route path="/bcm-validator" component={BCMValidator} />
      <Route path="/bcm-batch-validator" component={BCMBatchValidator} />
      <Route path="/diesel-engine-dashboard" component={DieselEngineDashboard} />
      <Route path="/algorithm-test-bench" component={AlgorithmTestBench} />
          <Route path="/agentic-assistant" component={AgenticDiagnosticAssistant} />
      <Route path="/video-tutorials" component={VideoTutorials} />
      <Route path="/universal-programmer" component={UniversalProgrammer} />
      <Route path="/module-cloning-hub" component={ModuleCloningHub} />
      <Route path="/clone/did-explorer" component={DIDExplorer} />
      <Route path="/clone/gateway" component={GatewayCloneTool} />
      <Route path="/clone/:type" component={ModuleCloneTool} />
      <Route path="/ecm-bench" component={ECMBenchProgramming} />
      <Route path="/active-damping-programmer" component={ActiveDampingProgrammer} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [connectionManager] = useState(() => new ConnectionManager());

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <ConnectionProvider>
          <TooltipProvider>
            <div className="flex flex-col min-h-screen">
              <ConnectionStatusHeader />
              <div className="flex-1">
                <Toaster />
                <Router />
              </div>
              <ConnectionStatusBar connectionManager={connectionManager} />
            </div>
          </TooltipProvider>
        </ConnectionProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
