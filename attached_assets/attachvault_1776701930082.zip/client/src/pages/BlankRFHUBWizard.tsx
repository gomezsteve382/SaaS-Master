import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, XCircle, Loader2, AlertTriangle, Info, Zap } from "lucide-react";
import { useConnection } from "@/contexts/ConnectionContext";
import { toast } from "sonner";
import { BackButton } from "@/components/BackButton";

interface WorkflowStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'running' | 'success' | 'error';
  progress?: number;
  details?: string;
  error?: string;
}

export default function BlankRFHUBWizard() {
  const { connectionManager, isConnected } = useConnection();
  const protocol = isConnected ? connectionManager.getProtocol() : null;
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [newVIN, setNewVIN] = useState("");
  const [detectedModule, setDetectedModule] = useState<{ canId: number; rxId: number } | null>(null);
  const [currentVIN, setCurrentVIN] = useState("");
  const [isBlank, setIsBlank] = useState(false);
  const [securityConstant, setSecurityConstant] = useState<number | null>(null);
  
  const [steps, setSteps] = useState<WorkflowStep[]>([
    {
      id: 'detect',
      title: 'Detect RFHUB Module',
      description: 'Scanning CAN bus for RFHUB module at known addresses',
      status: 'pending'
    },
    {
      id: 'read_vin',
      title: 'Read Current VIN',
      description: 'Reading existing VIN to determine if module is blank',
      status: 'pending'
    },
    {
      id: 'validate_blank',
      title: 'Validate Blank Status',
      description: 'Verifying module is factory-blank (VIN = 00000000000000000)',
      status: 'pending'
    },
    {
      id: 'input_vin',
      title: 'Input New VIN',
      description: 'Enter the 17-character VIN to program',
      status: 'pending'
    },
    {
      id: 'security_access',
      title: 'Security Access',
      description: 'Performing security access with Shift-XOR algorithm (constant=0)',
      status: 'pending'
    },
    {
      id: 'write_vin',
      title: 'Write VIN',
      description: 'Programming new VIN to RFHUB module',
      status: 'pending'
    },
    {
      id: 'verify',
      title: 'Verify Programming',
      description: 'Reading VIN back to confirm successful programming',
      status: 'pending'
    },
    {
      id: 'complete',
      title: 'Complete',
      description: 'RFHUB programming completed successfully',
      status: 'pending'
    }
  ]);

  const updateStep = (
    stepId: string,
    status: 'pending' | 'running' | 'success' | 'error',
    details?: string,
    error?: string,
    progress?: number
  ) => {
    setSteps(prev => prev.map(step => 
      step.id === stepId 
        ? { ...step, status, details, error, progress }
        : step
    ));
    
    if (status === 'running') {
      const stepIndex = steps.findIndex(s => s.id === stepId);
      setCurrentStep(stepIndex);
    }
  };

  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const detectRFHUB = async () => {
    updateStep('detect', 'running', 'Probing CAN addresses...');
    
    if (!protocol) {
      updateStep('detect', 'error', undefined, 'No hardware connection');
      return false;
    }

    // Known RFHUB CAN addresses
    const rfhubAddresses = [
      { tx: 0x740, rx: 0x748, name: 'RFHUB Primary (0x740/0x748)' },
      { tx: 0x75F, rx: 0x767, name: 'RFHUB Secondary (0x75F/0x767)' },
      { tx: 0x742, rx: 0x74A, name: 'RFHUB Tertiary (0x742/0x74A)' }
    ];

    for (const addr of rfhubAddresses) {
      try {
        updateStep('detect', 'running', `Trying ${addr.name}...`);
        
        // Try to read VIN (UDS 0x22 F190)
        const response = await protocol.sendUDS(addr.tx, addr.rx, [0x22, 0xF1, 0x90]);
        
        // Check for positive response (0x62)
        if (response && response.length > 0 && response[0] === 0x62) {
          setDetectedModule({ canId: addr.tx, rxId: addr.rx });
          updateStep('detect', 'success', `Found RFHUB at ${addr.name}`);
          return true;
        }
      } catch (error) {
        // Module not responding at this address, try next
        continue;
      }
    }

    updateStep('detect', 'error', undefined, 'No RFHUB module found on CAN bus');
    return false;
  };

  const readVIN = async () => {
    if (!protocol || !detectedModule) return false;

    updateStep('read_vin', 'running', 'Reading VIN from RFHUB...');
    
    try {
      // UDS 0x22 F190 (Read VIN)
      const response = await protocol.sendUDS(
        detectedModule.canId,
        detectedModule.rxId,
        [0x22, 0xF1, 0x90]
      );
      
      // Check for positive response (0x62 F1 90 + 17 bytes VIN)
      if (!response || response.length < 20 || response[0] !== 0x62) {
        updateStep('read_vin', 'error', undefined, 'Failed to read VIN from module');
        return false;
      }

      // Extract VIN bytes (skip 0x62 F1 90 header)
      const vinBytes = response.slice(3, 20);
      
      // Convert to ASCII string
      const vin = String.fromCharCode(...vinBytes);
      setCurrentVIN(vin);
      
      updateStep('read_vin', 'success', `Current VIN: ${vin}`);
      return true;
    } catch (error) {
      updateStep('read_vin', 'error', undefined, error instanceof Error ? error.message : 'Unknown error');
      return false;
    }
  };

  const validateBlank = async () => {
    updateStep('validate_blank', 'running', 'Checking if module is blank...');
    
    // Blank RFHUB has VIN = "00000000000000000" (17 zeros)
    const blank = currentVIN === '00000000000000000' || 
                  currentVIN === '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00';
    
    setIsBlank(blank);
    
    if (blank) {
      updateStep('validate_blank', 'success', 'Module is factory-blank (constant=0 will be used)');
      setSecurityConstant(0);
      return true;
    } else {
      updateStep('validate_blank', 'error', undefined, 
        `Module is NOT blank (VIN: ${currentVIN}). This wizard is only for blank RFHUB modules.`);
      return false;
    }
  };

  const performSecurityAccess = async () => {
    if (!protocol || !detectedModule) return false;

    updateStep('security_access', 'running', 'Requesting security seed...');
    
    try {
      // Step 1: Request seed (UDS 0x27 0x01)
      const seedResponse = await protocol.sendUDS(
        detectedModule.canId,
        detectedModule.rxId,
        [0x27, 0x01]
      );
      
      // Check for positive response (0x67 0x01 + seed bytes)
      if (!seedResponse || seedResponse.length < 6 || seedResponse[0] !== 0x67) {
        updateStep('security_access', 'error', undefined, 'Failed to request security seed');
        return false;
      }

      // Extract seed (4 bytes for RFHUB)
      const seed = (seedResponse[2] << 24) | (seedResponse[3] << 16) | 
                   (seedResponse[4] << 8) | seedResponse[5];

      updateStep('security_access', 'running', 
        `Seed received: 0x${seed.toString(16).toUpperCase().padStart(8, '0')}. Calculating key with constant=0...`);

      // For blank RFHUB, constant is always 0
      // Shift-XOR algorithm: key = seed ^ constant
      const key = seed ^ 0;

      updateStep('security_access', 'running', 
        `Key calculated: 0x${key.toString(16).toUpperCase().padStart(8, '0')}. Sending key...`);

      // Step 2: Send key (UDS 0x27 0x02 + 4-byte key)
      const keyBytes = [
        0x27, 0x02,
        (key >> 24) & 0xFF,
        (key >> 16) & 0xFF,
        (key >> 8) & 0xFF,
        key & 0xFF
      ];
      
      const keyResponse = await protocol.sendUDS(
        detectedModule.canId,
        detectedModule.rxId,
        keyBytes
      );

      // Check for positive response (0x67 0x02)
      if (!keyResponse || keyResponse.length < 2 || 
          keyResponse[0] !== 0x67 || keyResponse[1] !== 0x02) {
        updateStep('security_access', 'error', undefined, 'Security access rejected - incorrect key');
        return false;
      }

      updateStep('security_access', 'success', 'Security access granted with Shift-XOR (constant=0)');
      return true;
    } catch (error) {
      updateStep('security_access', 'error', undefined, 
        error instanceof Error ? error.message : 'Unknown error');
      return false;
    }
  };

  const writeVIN = async () => {
    if (!protocol || !detectedModule || !newVIN) return false;

    updateStep('write_vin', 'running', `Writing VIN: ${newVIN}...`);
    
    try {
      // Validate VIN length
      if (newVIN.length !== 17) {
        updateStep('write_vin', 'error', undefined, 
          `Invalid VIN length: ${newVIN.length} (expected 17)`);
        return false;
      }

      // Convert VIN to bytes
      const vinBytes = Array.from(newVIN).map(c => c.charCodeAt(0));

      // UDS 0x2E F190 + 17-byte VIN
      const writeCommand = [0x2E, 0xF1, 0x90, ...vinBytes];
      
      const response = await protocol.sendUDS(
        detectedModule.canId,
        detectedModule.rxId,
        writeCommand
      );

      // Check for positive response (0x6E F1 90)
      if (!response || response.length < 3 || 
          response[0] !== 0x6E || response[1] !== 0xF1 || response[2] !== 0x90) {
        updateStep('write_vin', 'error', undefined, 'VIN write rejected by module');
        return false;
      }

      updateStep('write_vin', 'success', `VIN written successfully: ${newVIN}`);
      return true;
    } catch (error) {
      updateStep('write_vin', 'error', undefined, 
        error instanceof Error ? error.message : 'Unknown error');
      return false;
    }
  };

  const verifyVIN = async () => {
    if (!protocol || !detectedModule || !newVIN) return false;

    updateStep('verify', 'running', 'Reading VIN back for verification...');
    
    try {
      // UDS 0x22 F190 (Read VIN)
      const response = await protocol.sendUDS(
        detectedModule.canId,
        detectedModule.rxId,
        [0x22, 0xF1, 0x90]
      );
      
      // Check for positive response
      if (!response || response.length < 20 || response[0] !== 0x62) {
        updateStep('verify', 'error', undefined, 'Failed to read VIN for verification');
        return false;
      }

      // Extract VIN bytes
      const vinBytes = response.slice(3, 20);
      const actualVIN = String.fromCharCode(...vinBytes);

      if (actualVIN !== newVIN) {
        updateStep('verify', 'error', undefined, 
          `VIN mismatch: expected "${newVIN}", got "${actualVIN}"`);
        return false;
      }

      updateStep('verify', 'success', `VIN verified successfully: ${actualVIN}`);
      return true;
    } catch (error) {
      updateStep('verify', 'error', undefined, 
        error instanceof Error ? error.message : 'Unknown error');
      return false;
    }
  };

  const runWorkflow = async () => {
    if (!isConnected || !protocol) {
      toast.error("No hardware connection. Please connect your device first.");
      return;
    }

    if (!newVIN || newVIN.length !== 17) {
      toast.error("Please enter a valid 17-character VIN");
      return;
    }

    setIsRunning(true);

    try {
      // Step 1: Detect RFHUB
      if (!await detectRFHUB()) {
        setIsRunning(false);
        return;
      }
      await delay(500);

      // Step 2: Read current VIN
      if (!await readVIN()) {
        setIsRunning(false);
        return;
      }
      await delay(500);

      // Step 3: Validate blank status
      if (!await validateBlank()) {
        setIsRunning(false);
        return;
      }
      await delay(500);

      // Step 4: Input VIN (already done)
      updateStep('input_vin', 'success', `New VIN entered: ${newVIN}`);
      await delay(500);

      // Step 5: Security access
      if (!await performSecurityAccess()) {
        setIsRunning(false);
        return;
      }
      await delay(500);

      // Step 6: Write VIN
      if (!await writeVIN()) {
        setIsRunning(false);
        return;
      }
      await delay(500);

      // Step 7: Verify
      if (!await verifyVIN()) {
        setIsRunning(false);
        return;
      }
      await delay(500);

      // Step 8: Complete
      updateStep('complete', 'success', 'RFHUB programming completed successfully!');
      toast.success("RFHUB programmed successfully!");
      
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Workflow failed");
    } finally {
      setIsRunning(false);
    }
  };

  const resetWorkflow = () => {
    setSteps(prev => prev.map(step => ({ ...step, status: 'pending' as const, details: undefined, error: undefined, progress: undefined })));
    setCurrentStep(0);
    setDetectedModule(null);
    setCurrentVIN("");
    setIsBlank(false);
    setSecurityConstant(null);
    setNewVIN("");
  };

  const getStepIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'running':
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      default:
        return <div className="h-5 w-5 rounded-full border-2 border-gray-300" />;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <BackButton />
      
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Zap className="h-8 w-8 text-blue-500" />
          <h1 className="text-3xl font-bold">Blank RFHUB Programming Wizard</h1>
        </div>
        <p className="text-muted-foreground">
          Automated workflow for programming factory-blank RFHUB modules with VINs
        </p>
      </div>

      {/* Warning Alert */}
      <Alert className="mb-6 border-amber-500 bg-amber-50">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-900">
          <strong>Important:</strong> This wizard is designed specifically for factory-blank RFHUB modules 
          (VIN = 00000000000000000). For already-programmed modules, use the standard Live VIN Programmer.
        </AlertDescription>
      </Alert>

      {/* Info Alert */}
      <Alert className="mb-6 border-blue-500 bg-blue-50">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>Algorithm:</strong> This wizard uses the Shift-XOR security algorithm with constant=0 
          for blank RFHUB modules. The workflow is fully automated - just enter the VIN and click Start.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Workflow Steps */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Workflow Progress</CardTitle>
              <CardDescription>
                {isRunning ? `Step ${currentStep + 1} of ${steps.length}` : 'Ready to start'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {steps.map((step, index) => (
                  <div key={step.id} className="flex items-start gap-3">
                    <div className="mt-1">
                      {getStepIcon(step.status)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{step.title}</h3>
                        {step.status === 'success' && (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Complete
                          </Badge>
                        )}
                        {step.status === 'running' && (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            Running
                          </Badge>
                        )}
                        {step.status === 'error' && (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            Failed
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{step.description}</p>
                      {step.details && (
                        <p className="text-sm text-blue-600 mt-1">{step.details}</p>
                      )}
                      {step.error && (
                        <p className="text-sm text-red-600 mt-1">❌ {step.error}</p>
                      )}
                      {step.progress !== undefined && (
                        <Progress value={step.progress} className="mt-2" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right: Controls */}
        <div className="space-y-6">
          {/* VIN Input */}
          <Card>
            <CardHeader>
              <CardTitle>New VIN</CardTitle>
              <CardDescription>Enter the 17-character VIN to program</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="newVIN">VIN</Label>
                  <Input
                    id="newVIN"
                    value={newVIN}
                    onChange={(e) => setNewVIN(e.target.value.toUpperCase())}
                    placeholder="2C3CDXHG4MH591631"
                    maxLength={17}
                    disabled={isRunning}
                    className="font-mono"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {newVIN.length}/17 characters
                  </p>
                </div>

                <Button
                  onClick={runWorkflow}
                  disabled={isRunning || !isConnected || newVIN.length !== 17}
                  className="w-full"
                  size="lg"
                >
                  {isRunning ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Running Workflow...
                    </>
                  ) : (
                    <>
                      <Zap className="mr-2 h-4 w-4" />
                      Start Automated Programming
                    </>
                  )}
                </Button>

                {!isRunning && steps.some(s => s.status !== 'pending') && (
                  <Button
                    onClick={resetWorkflow}
                    variant="outline"
                    className="w-full"
                  >
                    Reset Workflow
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Status Summary */}
          {detectedModule && (
            <Card>
              <CardHeader>
                <CardTitle>Module Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">CAN Address:</span>
                  <span className="font-mono">0x{detectedModule.canId.toString(16).toUpperCase()}</span>
                </div>
                {currentVIN && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Current VIN:</span>
                    <span className="font-mono text-xs">{currentVIN}</span>
                  </div>
                )}
                {isBlank !== null && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <Badge variant={isBlank ? "default" : "destructive"}>
                      {isBlank ? "Blank" : "Programmed"}
                    </Badge>
                  </div>
                )}
                {securityConstant !== null && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Constant:</span>
                    <span className="font-mono">0x{securityConstant.toString(16).toUpperCase().padStart(8, '0')}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
