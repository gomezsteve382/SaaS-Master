/**
 * Active Damping Programmer Page
 * User interface for programming active damping functionality on suspension control modules
 * Based on AlphaOBD protocol analysis
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle2, XCircle, ArrowLeft, Play, Terminal } from 'lucide-react';
import { useLocation } from 'wouter';

export default function ActiveDampingProgrammer() {
  const [, setLocation] = useLocation();
  const [selectedModuleId, setSelectedModuleId] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<any>(null);

  // Fetch available modules
  const { data: modules, isLoading: modulesLoading } = trpc.activeDamping.getModules.useQuery();

  // Execute routine mutation
  const executeRoutine = trpc.activeDamping.executeRoutine.useMutation({
    onSuccess: (result) => {
      setExecutionResult(result);
      setIsExecuting(false);
    },
    onError: (error) => {
      setExecutionResult({ success: false, error: error.message });
      setIsExecuting(false);
    },
  });

  const handleExecute = async () => {
    if (!selectedModuleId) return;

    setIsExecuting(true);
    setExecutionResult(null);

    // Execute routine 0x0312 (Enable Active Damping)
    executeRoutine.mutate({
      moduleId: selectedModuleId,
      routineId: 0x0312,
    });
  };

  const selectedModule = modules?.find((m) => m.id === selectedModuleId);

  return (
    <div className="container mx-auto py-8 max-w-5xl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" size="icon" onClick={() => setLocation('/')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Active Damping Programmer</h1>
          <p className="text-muted-foreground">
            Enable active damping functionality on suspension control modules
          </p>
        </div>
      </div>

      {/* Module Selection */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Select Module</CardTitle>
          <CardDescription>
            Choose the active damping or air suspension control module variant for your vehicle
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {modulesLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              <Select value={selectedModuleId} onValueChange={setSelectedModuleId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select module variant..." />
                </SelectTrigger>
                <SelectContent>
                  {modules?.map((module) => (
                    <SelectItem key={module.id} value={module.id}>
                      {module.name} - {module.modelYear} ({module.networkType})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedModule && (
                <div className="bg-muted p-4 rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">Module:</span>
                    <span>{selectedModule.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">Model Year:</span>
                    <span>{selectedModule.modelYear}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">Network:</span>
                    <Badge variant="outline">{selectedModule.networkType}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">CAN IDs:</span>
                    <span className="font-mono text-sm">
                      Request: 0x{selectedModule.canId.request.toString(16).toUpperCase()} / Response: 0x
                      {selectedModule.canId.response.toString(16).toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">Security:</span>
                    <Badge variant={selectedModule.requiresSecurityAccess ? 'destructive' : 'secondary'}>
                      {selectedModule.requiresSecurityAccess ? 'Required' : 'Not Required'}
                    </Badge>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Execute Button */}
      {selectedModule && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Programming</CardTitle>
            <CardDescription>Execute the active damping enable routine</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleExecute}
              disabled={isExecuting || !selectedModuleId}
              className="w-full"
              size="lg"
            >
              {isExecuting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Programming...
                </>
              ) : (
                <>
                  <Play className="mr-2 h-5 w-5" />
                  Enable Active Damping
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Execution Log */}
      {executionResult && (
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              <CardTitle>Execution Log</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Result Status */}
            <Alert variant={executionResult.success ? 'default' : 'destructive'}>
              <div className="flex items-center gap-2">
                {executionResult.success ? (
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600" />
                )}
                <AlertDescription className="font-semibold">
                  {executionResult.success
                    ? 'Active damping programming completed successfully'
                    : `Programming failed: ${executionResult.error}`}
                </AlertDescription>
              </div>
            </Alert>

            {/* Progress Log */}
            {executionResult.progressLog && executionResult.progressLog.length > 0 && (
              <div className="bg-black text-green-400 font-mono text-sm p-4 rounded-lg space-y-2 max-h-96 overflow-y-auto">
                {executionResult.progressLog.map((log: any, index: number) => (
                  <div key={index} className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-gray-500">
                        [{new Date(log.timestamp).toLocaleTimeString()}]
                      </span>
                      <Badge
                        variant="outline"
                        className="text-xs border-green-600 text-green-400 bg-transparent"
                      >
                        {log.stage.toUpperCase()}
                      </Badge>
                      <span>{log.message}</span>
                    </div>
                    {log.command && (
                      <div className="ml-8 text-cyan-400">
                        <span className="text-gray-500">Tx:</span> {log.command}
                      </div>
                    )}
                    {log.response && (
                      <div className="ml-8 text-yellow-400">
                        <span className="text-gray-500">Rx:</span> {log.response}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Command Details */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <span className="text-sm font-semibold text-muted-foreground">Routine ID</span>
                <div className="font-mono">0x{executionResult.routineId?.toString(16).toUpperCase()}</div>
              </div>
              <div className="space-y-1">
                <span className="text-sm font-semibold text-muted-foreground">Routine Name</span>
                <div>{executionResult.routineName}</div>
              </div>
              <div className="space-y-1">
                <span className="text-sm font-semibold text-muted-foreground">Command</span>
                <div className="font-mono text-sm">{executionResult.command}</div>
              </div>
              <div className="space-y-1">
                <span className="text-sm font-semibold text-muted-foreground">Response</span>
                <div className="font-mono text-sm">{executionResult.response || 'N/A'}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Information */}
      <Card>
        <CardHeader>
          <CardTitle>About Active Damping Programming</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm text-muted-foreground">
          <p>
            This tool enables active damping functionality on Jeep Grand Cherokee WK2 suspension control modules
            using UDS Routine Control (Service 0x31).
          </p>
          <p>
            The programming sequence includes:
          </p>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Entering Extended Diagnostic Session (0x10 0x03)</li>
            <li>Security access if required (0x27 seed/key)</li>
            <li>Executing routine 0x0312 (Enable Active Damping)</li>
            <li>Verifying successful completion</li>
          </ul>
          <p className="font-semibold">
            Note: Ensure your hardware adapter is connected and the vehicle ignition is on before programming.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
