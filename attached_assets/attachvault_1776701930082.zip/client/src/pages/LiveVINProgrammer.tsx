import { useState, useCallback, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { BackButton } from "@/components/BackButton";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { getDemoVehicle } from "@shared/demo-vehicles";
import { DemoModeBanner } from "@/components/DemoModeBanner";
import * as DemoSim from "@/lib/demo-mode-simulator";
import { 
  Shield, Usb, Bluetooth, Wifi, Cable, 
  ScanLine, FileEdit, CheckCircle2, XCircle, AlertTriangle,
  ArrowLeft, RefreshCw, Download, Loader2, Radio, Zap,
  Car, Cpu, Eye, Pencil, ExternalLink, Plus, Sparkles
} from "lucide-react";
import { getAllModules } from "@/lib/module-database";
import { isValidVIN, getVINInfo, validateVIN } from "@/lib/vin-validator";
import { 
  ELM327Protocol, J2534Protocol, ArduinoCANProtocol, 
  DiscoveredModule, HardwareType, createOBD2Protocol,
  getPairedPorts, requestNewPort, forgetAllPorts as forgetAllPortsUtil,
  SerialPortInfo, EOL_ROUTINE_IDS, RoutineResult,
  NRC_DESCRIPTIONS, formatHexBytes, getRoutineVerdict,
  EOL_FUZZER_ROUTINES, FuzzerResult, FuzzerVerdict,
  getFuzzerVerdictClass, getFuzzerVerdictEmoji, classifyRoutineResult, CSN_DID,
  SeedKeyCapture, isCaptureMode, setCaptureMode, getCapturedSamples, clearCaptures, exportCapturesToJSON,
  autoDetectDevice, AutoDetectResult
} from "@/lib/obd2-protocol";
import { 
  calculateKey, 
  getAlgorithmWaterfall, 
  getKeyCalculator, 
  getSecurityLevel, 
  rememberAlgorithm, 
  getLockoutWaitTime,
  SECURITY_NRC_DESCRIPTIONS,
  SecurityAlgorithm
} from "@/lib/fca-keygen";
import { createBackup, createAuditLog, bytesToHex } from "@/lib/api-client";
import { programVINWithJ2534 } from "@/lib/j2534-vin-programmer";
import { cn } from "@/lib/utils";

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';
type ScanStatus = 'idle' | 'scanning' | 'complete' | 'error';

interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'error' | 'warning' | 'tx' | 'rx';
  message: string;
}

export default function OBD2Live() {
  const { isDemoMode, currentVehicle } = useDemoMode();
  const [hardwareType, setHardwareType] = useState<HardwareType>('elm327');
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [scanStatus, setScanStatus] = useState<ScanStatus>('idle');
  const [scanProgress, setScanProgress] = useState(0);
  const [protocol, setProtocol] = useState<ELM327Protocol | J2534Protocol | ArduinoCANProtocol | null>(null);
  
  const [discoveredModules, setDiscoveredModules] = useState<DiscoveredModule[]>([]);
  const [selectedModules, setSelectedModules] = useState<Set<string>>(new Set());
  const [targetVIN, setTargetVIN] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  const [isWriting, setIsWriting] = useState(false);
  const [writeProgress, setWriteProgress] = useState(0);
  const [isInIframe, setIsInIframe] = useState(false);
  const [serialSupported, setSerialSupported] = useState(true);
  const [availablePorts, setAvailablePorts] = useState<SerialPortInfo[]>([]);
  const [selectedPortIndex, setSelectedPortIndex] = useState<number>(-1);
  
  // EOL Fuzzer State
  const [isFuzzing, setIsFuzzing] = useState(false);
  const [fuzzProgress, setFuzzProgress] = useState(0);
  const [fuzzResults, setFuzzResults] = useState<FuzzerResult[]>([]);
  const [selectedFuzzModule, setSelectedFuzzModule] = useState<string>('');
  
  // Discovery Scan State
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [discoveryProgress, setDiscoveryProgress] = useState(0);
  const [discoveredAddresses, setDiscoveredAddresses] = useState<Array<{txId: number, rxId: number}>>([]);
  
  
  // Seed/Key Capture Mode State (for 2018+ Atlantis algorithm reverse engineering)
  const [captureEnabled, setCaptureEnabled] = useState(false);
  const [captures, setCaptures] = useState<SeedKeyCapture[]>([]);
  const [captureFlash, setCaptureFlash] = useState(false);
  
  const lastCaptureCount = useRef(0);
  
  const moduleDatabase = getAllModules();

  const refreshPorts = useCallback(async () => {
    try {
      const ports = await getPairedPorts();
      setAvailablePorts(ports);
      if (ports.length > 0 && selectedPortIndex === -1) {
        setSelectedPortIndex(0);
      }
    } catch (error) {
      console.warn('WebSerial API not available:', error);
      setAvailablePorts([]);
      // Don't show error toast - this is expected in iframe/preview environments
    }
  }, [selectedPortIndex]);

  useEffect(() => {
    const inIframe = window !== window.top;
    setIsInIframe(inIframe);
    const hasSerial = 'serial' in navigator;
    setSerialSupported(hasSerial);
    
    // Only try to refresh ports if WebSerial is available
    if (hasSerial && !inIframe) {
      refreshPorts();
    }
    // Load persisted captures on mount
    const storedCaptures = getCapturedSamples();
    setCaptures(storedCaptures);
    lastCaptureCount.current = storedCaptures.length;
  }, []);

  const openInNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  const handlePairNewPort = async () => {
    const port = await requestNewPort();
    if (port) {
      await refreshPorts();
      addLog('info', 'New port paired successfully');
    }
  };

  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    const entry: LogEntry = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString().split('T')[1].slice(0, 12),
      type,
      message,
    };
    setLogs(prev => [...prev.slice(-99), entry]);
  }, []);

  const forgetAllPorts = async () => {
    const count = await forgetAllPortsUtil();
    setAvailablePorts([]);
    setSelectedPortIndex(-1);
    addLog('info', `Cleared ${count} paired port(s). Pair your device again.`);
  };

  // Seed/Key Capture Mode handlers
  const handleToggleCaptureMode = useCallback((checked?: boolean) => {
    const newState = checked !== undefined ? checked : !captureEnabled;
    setCaptureMode(newState);
    setCaptureEnabled(newState);
    if (newState) {
      addLog('info', 'Capture Mode ENABLED - Security access attempts will be logged');
    } else {
      addLog('info', 'Capture Mode DISABLED');
    }
  }, [captureEnabled, addLog]);

  const handleRefreshCaptures = useCallback(() => {
    const storedCaptures = getCapturedSamples();
    if (storedCaptures.length > lastCaptureCount.current) {
      setCaptureFlash(true);
      setTimeout(() => setCaptureFlash(false), 1000);
      addLog('success', `New capture! Total: ${storedCaptures.length}`);
    }
    lastCaptureCount.current = storedCaptures.length;
    setCaptures(storedCaptures);
  }, [addLog]);

  const handleClearCaptures = useCallback(() => {
    clearCaptures();
    setCaptures([]);
    lastCaptureCount.current = 0;
    addLog('info', 'Cleared all captured seed/key samples');
  }, [addLog]);

  const handleExportCaptures = useCallback(() => {
    const storedCaptures = getCapturedSamples();
    const json = exportCapturesToJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `seed_key_captures_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    addLog('success', `Exported ${storedCaptures.length} capture(s) to JSON`);
  }, [addLog]);

  // Auto-refresh captures when capture mode is enabled
  useEffect(() => {
    if (!captureEnabled) return;
    const interval = setInterval(() => {
      handleRefreshCaptures();
    }, 1000);
    return () => clearInterval(interval);
  }, [captureEnabled, handleRefreshCaptures]);

  const handleConnect = async () => {
    setConnectionStatus('connecting');
    addLog('info', `Connecting to ${hardwareType.toUpperCase()} device...`);
    
    try {
      const newProtocol = createOBD2Protocol(hardwareType);
      
      if (hardwareType === 'j2534') {
        const j2534 = newProtocol as J2534Protocol;
        const success = await j2534.connect();
        if (success) {
          setProtocol(newProtocol);
          setConnectionStatus('connected');
          addLog('success', 'J2534 PassThru device connected');
        } else {
          setConnectionStatus('error');
          addLog('error', 'J2534 connection failed - ensure PassThru server is running');
        }
      } else if (hardwareType === 'arduino') {
        const arduino = newProtocol as ArduinoCANProtocol;
        let success = false;
        
        // Use selected port if available, otherwise request new port
        if (selectedPortIndex >= 0 && availablePorts[selectedPortIndex]) {
          const portInfo = availablePorts[selectedPortIndex];
          addLog('info', `Using paired port: ${portInfo.displayName}`);
          success = await arduino.connectToPort(portInfo.port);
        } else {
          success = await arduino.connect();
        }
        
        if (success) {
          setProtocol(newProtocol);
          setConnectionStatus('connected');
          addLog('success', 'Arduino CAN device connected via WebSerial');
        } else {
          setConnectionStatus('error');
          const errorDetail = arduino.getLastError();
          addLog('error', `Arduino connection failed: ${errorDetail || 'Unknown error'}`);
        }
      } else {
        const elm = newProtocol as ELM327Protocol;
        let success = false;
        
        // Use selected port if available, otherwise request new port
        if (selectedPortIndex >= 0 && availablePorts[selectedPortIndex]) {
          const portInfo = availablePorts[selectedPortIndex];
          addLog('info', `Using paired port: ${portInfo.displayName}`);
          success = await elm.connectToPort(portInfo.port);
        } else {
          success = await elm.connect();
        }
        
        if (success) {
          setProtocol(newProtocol);
          setConnectionStatus('connected');
          addLog('success', `${hardwareType.toUpperCase()} device connected via WebSerial`);
        } else {
          setConnectionStatus('error');
          const errorDetail = elm.getLastError();
          addLog('error', `ELM327 connection failed: ${errorDetail || 'Unknown error'}`);
        }
      }
    } catch (error) {
      setConnectionStatus('error');
      addLog('error', `Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const handleDisconnect = async () => {
    if (protocol) {
      if ('disconnect' in protocol) {
        await protocol.disconnect();
      }
      setProtocol(null);
    }
    setConnectionStatus('disconnected');
    setDiscoveredModules([]);
    setScanStatus('idle');
    // Refresh ports to get fresh references for reconnecting
    await refreshPorts();
    addLog('info', 'Disconnected from device');
  };

  const handleScan = async () => {
    if (!protocol) return;
    
    setScanStatus('scanning');
    setScanProgress(0);
    setDiscoveredModules([]);
    addLog('info', 'Starting fast module scan (30 modules)...');
    
    try {
      let discovered: DiscoveredModule[] = [];
      
      // Call scanForModules ONCE with all modules - much faster than individual calls
      if (protocol instanceof ELM327Protocol) {
        discovered = await protocol.scanForModules(moduleDatabase);
      } else if (protocol instanceof J2534Protocol) {
        discovered = await protocol.scanForModules(moduleDatabase);
      } else if (protocol instanceof ArduinoCANProtocol) {
        discovered = await protocol.scanForModules(moduleDatabase);
      }
      
      // Log what we found
      for (const mod of discovered) {
        addLog('rx', `Found: ${mod.code} - ${mod.name}`);
      }
      
      setDiscoveredModules(discovered);
      setScanProgress(100);
      setScanStatus('complete');
      addLog('success', `Scan complete. Found ${discovered.length} modules.`);
    } catch (error) {
      addLog('error', `Scan failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setScanStatus('error');
    }
  };

  const handleDiscoverModules = async () => {
    if (!protocol || !(protocol instanceof ELM327Protocol)) {
      addLog('error', 'Discovery requires ELM327 connection');
      return;
    }
    
    setIsDiscovering(true);
    setDiscoveryProgress(0);
    setDiscoveredAddresses([]);
    addLog('info', 'Starting dual-bus module discovery (CAN-C + CAN-IHS)...');
    addLog('info', 'Scanning all modules from verified database...');
    
    try {
      const found = await protocol.discoverModules(
        (current, total, foundCount) => {
          setDiscoveryProgress(Math.round((current / total) * 100));
        },
        (txId, rxId) => {
          addLog('rx', `Found module at TX=0x${txId.toString(16).toUpperCase()} RX=0x${rxId.toString(16).toUpperCase()}`);
          setDiscoveredAddresses(prev => [...prev, { txId, rxId }]);
        }
      );
      
      addLog('success', `Discovery complete! Found ${found.length} responding addresses.`);
      
      // Convert discovered addresses to DiscoveredModule format
      const newModules: DiscoveredModule[] = found.map(addr => ({
        name: `Unknown (0x${addr.txId.toString(16).toUpperCase()})`,
        code: `0x${addr.txId.toString(16).toUpperCase()}`,
        txId: addr.txId,
        rxId: addr.rxId,
        vin: null,
        vinOffset: null,
        status: 'found',
        lastResponse: null,
      }));
      
      setDiscoveredModules(newModules);
      setScanStatus('complete');
    } catch (error) {
      addLog('error', `Discovery failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsDiscovering(false);
      setDiscoveryProgress(0);
    }
  };

  const handleReadVINs = async () => {
    if (!protocol) return;
    
    addLog('info', 'Reading VINs from discovered modules...');
    
    const updated = [...discoveredModules];
    
    for (let i = 0; i < updated.length; i++) {
      const mod = updated[i];
      addLog('tx', `Reading VIN from ${mod.code}...`);
      
      try {
        let vin: string | null = null;
        
        if (protocol instanceof ELM327Protocol) {
          vin = await protocol.readVIN(mod.txId, mod.rxId);
        } else if (protocol instanceof J2534Protocol) {
          vin = await protocol.readVIN(mod.txId, mod.rxId);
        } else if (protocol instanceof ArduinoCANProtocol) {
          vin = await protocol.readVIN(mod.txId, mod.rxId);
        }
        
        if (vin) {
          updated[i] = { ...mod, vin, status: 'vin_read' };
          addLog('rx', `${mod.code} VIN: ${vin}`);
        } else {
          addLog('warning', `No VIN response from ${mod.code}`);
        }
      } catch {
        addLog('error', `Failed to read VIN from ${mod.code}`);
      }
      
      setDiscoveredModules([...updated]);
    }
    
    addLog('success', 'VIN reading complete');
  };

  const executeWriteVINs = async () => {
    if (!protocol || !targetVIN || selectedModules.size === 0) return;
    
    if (!isValidVIN(targetVIN)) {
      addLog('error', 'Invalid VIN - check format and try again');
      return;
    }
    
    setIsWriting(true);
    setWriteProgress(0);
    
    const modulesToWrite = discoveredModules.filter(m => selectedModules.has(m.code));
    
    if (modulesToWrite.length === 0) {
      addLog('error', 'No modules selected to write');
      setIsWriting(false);
      return;
    }
    
    addLog('warning', `Writing VIN ${targetVIN} to ${modulesToWrite.length} modules...`);
    
    for (let i = 0; i < modulesToWrite.length; i++) {
      const mod = modulesToWrite[i];
      setWriteProgress(Math.round((i / modulesToWrite.length) * 100));
      
      addLog('tx', `Writing VIN to ${mod.code}...`);
      
      // AUTO-BACKUP: Save original VIN before write
      if (mod.vin) {
        await createBackup({
          vin: mod.vin,
          moduleCode: mod.code,
          moduleName: mod.name,
          txId: mod.txId,
          rxId: mod.rxId,
          operationType: 'vin_write',
          did: 0xF190,
          originalData: mod.vin,
          originalDataLength: 17,
          newData: targetVIN,
          notes: `VIN change: ${mod.vin} → ${targetVIN}`,
        });
      }
      
      try {
        let result: { success: boolean; message: string; details?: any } | null = null;
        
        if (protocol instanceof ELM327Protocol) {
          // Use comprehensive programVIN with security access
          // Look up module-specific configuration from module database
          const { getModule } = await import('@shared/module-database');
          const moduleConfig = getModule(mod.code);
          const securityLevel = moduleConfig?.securityLevel;
          const programmingTimeout = moduleConfig?.programmingTimeout;
          
          addLog('info', `Starting VIN programming for ${mod.code} with security access${securityLevel ? ` (Level ${securityLevel})` : ''}...`);
          result = await protocol.programVIN(
            mod.txId,
            mod.rxId,
            targetVIN,
            (step, progress) => {
              addLog('info', `${mod.code}: ${step}`);
              setWriteProgress(((i / modulesToWrite.length) * 100) + (progress / modulesToWrite.length));
            },
            { securityLevel, programmingTimeout }
          );
        } else if (protocol instanceof J2534Protocol) {
          // Use comprehensive J2534 programVIN with security access
          const { getModule } = await import('@shared/module-database');
          const moduleConfig = getModule(mod.code);
          const securityLevel = moduleConfig?.securityLevel;
          const programmingTimeout = moduleConfig?.programmingTimeout;
          
          addLog('info', `Starting J2534 VIN programming for ${mod.code} with security access${securityLevel ? ` (Level ${securityLevel})` : ''}...`);
          result = await programVINWithJ2534(
            protocol,
            mod.txId,
            mod.rxId,
            targetVIN,
            (step, progress) => {
              addLog('info', `${mod.code}: ${step}`);
              setWriteProgress(((i / modulesToWrite.length) * 100) + (progress / modulesToWrite.length));
            },
            { securityLevel, programmingTimeout }
          );
        } else if (protocol instanceof ArduinoCANProtocol) {
          // Fallback to old method for Arduino
          await protocol.startDiagnosticSession(mod.txId, mod.rxId, 0x03);
          const success = await protocol.writeVIN(mod.txId, mod.rxId, targetVIN);
          result = { success, message: success ? 'VIN written' : 'Write failed' };
        }
        
        if (result?.success) {
          setDiscoveredModules(prev => prev.map(m => 
            m.code === mod.code ? { ...m, vin: targetVIN, status: 'vin_written' } : m
          ));
          addLog('success', `${mod.code}: ${result.message}`);
          if (result.details) {
            addLog('info', `Old VIN: ${result.details.oldVIN || 'unknown'}, New VIN: ${result.details.newVIN}`);
          }
          
          // AUDIT LOG: Record successful VIN write
          await createAuditLog({
            vin: targetVIN,
            moduleCode: mod.code,
            moduleName: mod.name,
            txId: mod.txId,
            rxId: mod.rxId,
            operation: 'vin_write',
            details: `VIN changed from ${mod.vin || 'unknown'} to ${targetVIN} using Atlantis security access`,
            success: true,
            hardwareType: hardwareType,
          });
        } else {
          addLog('error', `${mod.code}: ${result?.message || 'Unknown error'}`);
          
          // AUDIT LOG: Record failed VIN write
          await createAuditLog({
            moduleCode: mod.code,
            moduleName: mod.name,
            txId: mod.txId,
            rxId: mod.rxId,
            operation: 'vin_write',
            details: `Failed: ${result?.message || 'Unknown error'}`,
            success: false,
            hardwareType: hardwareType,
          });
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        addLog('error', `${mod.code}: ${errorMsg}`);
      }
    }
    
    setWriteProgress(100);
    setIsWriting(false);
    addLog('success', 'VIN write operation complete');
  };

  const handleWriteVINs = async () => {
    if (!protocol || !targetVIN || selectedModules.size === 0) return;
    await executeWriteVINs();
  };

  const toggleModuleSelection = (code: string) => {
    setSelectedModules(prev => {
      const next = new Set(prev);
      if (next.has(code)) {
        next.delete(code);
      } else {
        next.add(code);
      }
      return next;
    });
  };

  const selectAllModules = () => {
    setSelectedModules(new Set(discoveredModules.map(m => m.code)));
  };

  // EOL Routine Fuzzer - Attempts bootloader unlock and tests EOL routines
  // Enhanced with detailed TX/RX logging, timing, NRC descriptions, and verdicts
  const handleFuzzRoutines = async () => {
    if (!protocol || !selectedFuzzModule) {
      addLog('error', 'Select a module to fuzz');
      return;
    }
    
    const targetMod = discoveredModules.find(m => m.code === selectedFuzzModule);
    if (!targetMod) {
      addLog('error', 'Target module not found');
      return;
    }
    
    setIsFuzzing(true);
    setFuzzProgress(0);
    setFuzzResults([]);
    
    const routineConfigs = EOL_FUZZER_ROUTINES;
    const results: FuzzerResult[] = [];
    let securityLevel: string = 'NONE';
    
    // ═══════════════════════════════════════════════════════════════════
    // FUZZER HEADER BANNER
    // ═══════════════════════════════════════════════════════════════════
    addLog('info', '═══════════════════════════════════════════════════');
    addLog('info', `[0x${targetMod.txId.toString(16).toUpperCase()}] ${targetMod.code} - EOL ROUTINE FUZZER`);
    addLog('info', '═══════════════════════════════════════════════════');
    addLog('info', `Target: TX=0x${targetMod.txId.toString(16).toUpperCase()} RX=0x${targetMod.rxId.toString(16).toUpperCase()}`);
    
    // Step 1: Enter Extended Diagnostic Session
    addLog('tx', 'TX: 10 03 (Diagnostic Session Control - Extended)');
    let sessionOk = false;
    
    if (protocol instanceof ELM327Protocol) {
      sessionOk = await protocol.startDiagnosticSession(targetMod.txId, targetMod.rxId, 0x03);
    } else if (protocol instanceof J2534Protocol) {
      sessionOk = await protocol.startDiagnosticSession(targetMod.txId, targetMod.rxId, 0x03);
    } else if (protocol instanceof ArduinoCANProtocol) {
      sessionOk = await protocol.startDiagnosticSession(targetMod.txId, targetMod.rxId, 0x03);
    }
    
    if (sessionOk) {
      addLog('rx', 'RX: 50 03 (Positive Response)');
      addLog('success', 'Session: EXTENDED DIAGNOSTIC active');
    } else {
      addLog('warning', 'RX: 7F 10 xx (Negative Response) - Continuing anyway...');
    }
    
    // Step 2: Smart Security Access - Auto-selects best algorithm
    addLog('info', '───────────────────────────────────────────────────');
    addLog('info', 'SMART UNLOCK: Auto-detecting best algorithm...');
    
    const moduleInfo = { code: targetMod.code, name: targetMod.name };
    const algorithmWaterfall = getAlgorithmWaterfall(targetMod.code, 'bootloader');
    let securityOk = false;
    let winningAlgorithm: SecurityAlgorithm | null = null;
    let csn: Uint8Array | null = null;
    
    // Try each algorithm in waterfall order until one succeeds
    for (const algorithm of algorithmWaterfall) {
      if (algorithm === 'manual') {
        addLog('warning', 'Manual key entry required - skipping for auto-unlock');
        continue;
      }
      
      // For Atlantis, we need CSN first
      if (algorithm === 'atlantis' && !csn) {
        addLog('tx', 'TX: 22 F1 8C (Read CSN for Atlantis algorithm)');
        if (protocol instanceof ELM327Protocol || protocol instanceof J2534Protocol || protocol instanceof ArduinoCANProtocol) {
          csn = await protocol.readCSN(targetMod.txId, targetMod.rxId);
        }
        if (csn) {
          const csnHex = Array.from(csn).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
          addLog('rx', `RX: CSN = ${csnHex}`);
        } else {
          addLog('warning', 'CSN read failed - Atlantis algorithm may not work');
        }
      }
      
      const level = getSecurityLevel(algorithm);
      const keyCalc = getKeyCalculator(algorithm, undefined, csn || undefined);
      const levelName = algorithm === 'cda_bootloader' ? 'BOOTLOADER' : 
                       algorithm === 'cda_engineering' ? 'ENGINEERING' : 
                       algorithm === 'atlantis' ? 'ATLANTIS' : 'UNKNOWN';
      
      addLog('tx', `TX: 27 ${level.toString(16).padStart(2, '0')} (Security Access - ${levelName} algorithm)`);
      
      try {
        if (protocol instanceof ELM327Protocol) {
          securityOk = await protocol.securityAccess(targetMod.txId, targetMod.rxId, level, keyCalc, 3, moduleInfo);
        } else if (protocol instanceof J2534Protocol) {
          securityOk = await protocol.securityAccess(targetMod.txId, targetMod.rxId, level, keyCalc, 3, moduleInfo);
        } else if (protocol instanceof ArduinoCANProtocol) {
          securityOk = await protocol.securityAccess(targetMod.txId, targetMod.rxId, level, keyCalc, moduleInfo);
        }
        
        if (securityOk) {
          addLog('rx', `RX: 67 ${(level + 1).toString(16).padStart(2, '0')} (Security Access Granted)`);
          addLog('success', `*** ${levelName} ACCESS GRANTED (Level 0x${level.toString(16).padStart(2, '0')}) ***`);
          addLog('success', `Algorithm: ${algorithm.toUpperCase()} - Remembering for future use`);
          winningAlgorithm = algorithm;
          rememberAlgorithm(targetMod.code, algorithm);
          securityLevel = `${levelName} (0x${level.toString(16).padStart(2, '0')})`;
          break;
        } else {
          addLog('warning', `RX: 7F 27 xx (${levelName} denied - trying next algorithm...)`);
        }
      } catch (err) {
        addLog('warning', `Algorithm ${algorithm} failed with error - trying next...`);
      }
      
      // Small delay between attempts
      await new Promise(r => setTimeout(r, 100));
    }
    
    if (!securityOk) {
      addLog('warning', 'All algorithms exhausted - No security access obtained');
      addLog('warning', 'Fuzzing without unlock (limited functionality)...');
      securityLevel = 'NONE (Locked)';
    }
    
    // ═══════════════════════════════════════════════════════════════════
    // SECURITY STATUS BANNER
    // ═══════════════════════════════════════════════════════════════════
    addLog('info', '───────────────────────────────────────────────────');
    addLog('info', `SECURITY LEVEL: ${securityLevel}`);
    addLog('info', '───────────────────────────────────────────────────');
    
    // Step 3: Fuzz EOL Routine IDs with detailed logging
    addLog('info', `Starting EOL Routine Scan (${routineConfigs.length} targets)...`);
    addLog('info', '');
    
    for (let i = 0; i < routineConfigs.length; i++) {
      const { id: routineId, name, description } = routineConfigs[i];
      const routineIdHex = routineId.toString(16).toUpperCase().padStart(4, '0');
      setFuzzProgress(Math.round(((i + 1) / routineConfigs.length) * 100));
      
      addLog('info', `[${String(i + 1).padStart(3, '0')}] 0x${routineIdHex} ${name} (${description})`);
      
      let result: RoutineResult | null = null;
      
      if (protocol instanceof ELM327Protocol) {
        result = await protocol.routineStart(targetMod.txId, targetMod.rxId, routineId);
      } else if (protocol instanceof J2534Protocol) {
        result = await protocol.routineStart(targetMod.txId, targetMod.rxId, routineId);
      } else if (protocol instanceof ArduinoCANProtocol) {
        result = await protocol.routineStart(targetMod.txId, targetMod.rxId, routineId);
      }
      
      if (result) {
        // Convert to FuzzerResult with verdict classification
        const fuzzerResult = classifyRoutineResult(result, name);
        results.push(fuzzerResult);
        
        // Log TX bytes
        if (result.txBytes) {
          addLog('tx', `  TX: ${formatHexBytes(result.txBytes)}`);
        }
        
        // Log RX bytes with timing
        if (result.rxBytes) {
          const timing = result.elapsedMs ? ` (${result.elapsedMs}ms)` : '';
          addLog('rx', `  RX: ${formatHexBytes(result.rxBytes)}${timing}`);
        } else if (result.elapsedMs) {
          addLog('rx', `  RX: NO RESPONSE (${result.elapsedMs}ms timeout)`);
        }
        
        // Log verdict with emoji
        const verdictEmoji = getFuzzerVerdictEmoji(fuzzerResult.verdict);
        if (fuzzerResult.verdict === 'SUCCESS') {
          addLog('success', `  -> ${verdictEmoji} SUCCESS HIT: Routine executed successfully`);
        } else if (fuzzerResult.verdict === 'SOFT_HIT') {
          addLog('warning', `  -> ${verdictEmoji} SOFT HIT: Routine exists but preconditions not met (NRC 0x22)`);
          addLog('info', `     Action: Enter programming session or unlock higher security level`);
        } else if (fuzzerResult.verdict === 'SECURITY_DENIED') {
          addLog('warning', `  -> ${verdictEmoji} SECURITY DENIED: Needs higher security level (NRC 0x33)`);
          addLog('info', `     Action: Unlock with Level 0x05 (Bootloader) required`);
        } else if (fuzzerResult.verdict === 'REJECTED') {
          const nrc = fuzzerResult.nrc || 0x31;
          const nrcInfo = NRC_DESCRIPTIONS[nrc];
          if (nrcInfo) {
            addLog('info', `  -> ${verdictEmoji} REJECTED: ${nrcInfo.short} (NRC 0x${nrc.toString(16).toUpperCase()})`);
          } else {
            addLog('info', `  -> ${verdictEmoji} REJECTED: NRC 0x${nrc.toString(16).toUpperCase()}`);
          }
        } else {
          addLog('info', `  -> ${verdictEmoji} NO RESPONSE: Module timed out`);
        }
        
        addLog('info', '');
      }
      
      await new Promise(r => setTimeout(r, 200));
    }
    
    setFuzzResults(results);
    setFuzzProgress(100);
    setIsFuzzing(false);
    
    // ═══════════════════════════════════════════════════════════════════
    // SUMMARY REPORT
    // ═══════════════════════════════════════════════════════════════════
    addLog('info', '═══════════════════════════════════════════════════');
    addLog('info', 'FUZZER SUMMARY REPORT');
    addLog('info', '═══════════════════════════════════════════════════');
    
    const hits = results.filter(r => r.verdict === 'SUCCESS');
    const softHits = results.filter(r => r.verdict === 'SOFT_HIT');
    const blocked = results.filter(r => r.verdict === 'SECURITY_DENIED');
    const rejected = results.filter(r => r.verdict === 'REJECTED');
    const noResponse = results.filter(r => r.verdict === 'NO_RESPONSE');
    
    addLog('info', `Module: ${targetMod.code} (${targetMod.name})`);
    addLog('info', `Security: ${securityLevel}`);
    addLog('info', `Total Tested: ${results.length} routines`);
    addLog('info', '');
    
    if (hits.length > 0) {
      addLog('success', `🟢 SUCCESS HITS: ${hits.length}`);
      for (const hit of hits) {
        const routineIdHex = hit.routineId.toString(16).toUpperCase().padStart(4, '0');
        addLog('success', `  - 0x${routineIdHex} ${hit.routineName}`);
      }
    } else {
      addLog('warning', '🟢 SUCCESS HITS: 0');
    }
    
    if (softHits.length > 0) {
      addLog('warning', `🟡 SOFT HITS: ${softHits.length} (need preconditions)`);
      for (const hit of softHits) {
        const routineIdHex = hit.routineId.toString(16).toUpperCase().padStart(4, '0');
        addLog('warning', `  - 0x${routineIdHex} ${hit.routineName}`);
      }
    }
    
    addLog('info', `🟠 Security Denied: ${blocked.length}`);
    addLog('info', `🔴 Rejected: ${rejected.length}`);
    addLog('info', `⚫ No Response: ${noResponse.length}`);
    addLog('info', '═══════════════════════════════════════════════════');
    
    if (hits.length > 0) {
      addLog('success', `*** FUZZING COMPLETE: Found ${hits.length} working routine(s) ***`);
      addLog('success', 'Next: Send memory wipe payload to execute routine');
    } else {
      addLog('warning', 'Fuzzing complete. No working routines found at current security level.');
      if (securityLevel.includes('NONE')) {
        addLog('info', 'Tip: Try connecting with different hardware for security unlock');
      }
    }
  };

  const vinInfo = targetVIN.length === 17 ? getVINInfo(targetVIN) : null;

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <BackButton />
      <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-white/70 hover:text-white" data-testid="button-back">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="w-px h-6 bg-white/20" />
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <Radio className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="font-mono font-bold text-lg leading-none" data-testid="text-page-title">
                OBD2 LIVE SCANNER
              </h1>
              <span className="text-[10px] text-primary uppercase tracking-widest">Real-Time Module Programming</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Demo Mode Toggle */}
            <div 
              className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all",
                isDemoMode 
                  ? "bg-blue-500/20 border-blue-500/50" 
                  : "bg-card/50 border-white/10"
              )}
              data-testid="demo-mode-toggle"
            >
              <span className={cn("text-xs font-mono", isDemoMode ? "text-blue-400" : "text-white/50")}>
                {isDemoMode ? 'DEMO MODE ACTIVE' : 'HARDWARE MODE'}
              </span>
            </div>
            
            {/* Prominent Capture Mode Toggle */}
            <div 
              className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all",
                captureEnabled 
                  ? "bg-amber-500/20 border-amber-500/50" 
                  : "bg-card/50 border-white/10",
                captureFlash && "animate-pulse ring-2 ring-amber-400"
              )}
              data-testid="capture-mode-toggle"
            >
              <Radio className={cn("w-4 h-4", captureEnabled ? "text-amber-400" : "text-white/50")} />
              <span className={cn("text-xs font-mono", captureEnabled ? "text-amber-400" : "text-white/50")}>
                CAPTURE
              </span>
              <Switch
                checked={captureEnabled}
                onCheckedChange={handleToggleCaptureMode}
                className="data-[state=checked]:bg-amber-500"
                data-testid="switch-capture-mode"
              />
              {captures.length > 0 && (
                <Badge 
                  variant="secondary" 
                  className={cn(
                    "ml-1 h-5 min-w-5 px-1.5 font-mono text-[10px]",
                    captureFlash ? "bg-amber-500 text-black" : "bg-amber-500/20 text-amber-400"
                  )}
                  data-testid="badge-capture-count"
                >
                  {captures.length}
                </Badge>
              )}
            </div>

            <div className="relative group">
              <Badge 
                variant={connectionStatus === 'connected' ? 'default' : 'secondary'}
                className={cn(
                  "font-mono cursor-help",
                  connectionStatus === 'connected' && "bg-green-500/20 text-green-400 border-green-500/30",
                  connectionStatus === 'connecting' && "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
                  connectionStatus === 'error' && "bg-red-500/20 text-red-400 border-red-500/30"
                )}
                data-testid="badge-connection-status"
              >
                {connectionStatus === 'connected' ? (
                  <><CheckCircle2 className="w-3 h-3 mr-1" /> CONNECTED · {hardwareType.toUpperCase()}</>
                ) : connectionStatus === 'connecting' ? (
                  <><Loader2 className="w-3 h-3 mr-1 animate-spin" /> CONNECTING · {hardwareType.toUpperCase()}</>
                ) : connectionStatus === 'error' ? (
                  <><XCircle className="w-3 h-3 mr-1" /> ERROR · {hardwareType.toUpperCase()}</>
                ) : (
                  <><Cable className="w-3 h-3 mr-1" /> DISCONNECTED</>
                )}
              </Badge>
              
              {/* Tooltip with connection details */}
              <div className="absolute top-full right-0 mt-2 w-64 p-3 bg-black/95 border border-white/10 rounded-lg shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                <p className="text-xs font-semibold text-white mb-2">Connection Details</p>
                <div className="space-y-1 text-xs text-white/70">
                  <div className="flex justify-between">
                    <span>Hardware:</span>
                    <span className="font-mono text-white">{hardwareType.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <span className="font-mono text-white">{connectionStatus.toUpperCase()}</span>
                  </div>
                  {connectionStatus === 'connected' && selectedPortIndex >= 0 && availablePorts[selectedPortIndex] && (
                    <>
                      <div className="flex justify-between">
                        <span>Port:</span>
                        <span className="font-mono text-white">{availablePorts[selectedPortIndex].displayName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Baud Rate:</span>
                        <span className="font-mono text-white">38400</span>
                      </div>
                    </>
                  )}
                  {connectionStatus === 'disconnected' && (
                    <p className="text-white/50 mt-2">Click Connect to establish hardware connection</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-6">
        {/* Demo Mode Banner */}
        <DemoModeBanner />
        
        {(isInIframe || !serialSupported) && (
          <Alert variant="destructive" className="mb-6 border-yellow-500/50 bg-yellow-500/10">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle className="text-yellow-400">WebSerial Access Blocked</AlertTitle>
            <AlertDescription className="text-yellow-300/80">
              {isInIframe ? (
                <>
                  WebSerial cannot work inside the Replit preview iframe. 
                  <strong> Open this page in a new browser tab</strong> to connect to your OBD2 hardware.
                </>
              ) : (
                <>
                  Your browser doesn't support WebSerial. Use <strong>Chrome</strong>, <strong>Edge</strong>, or <strong>Opera</strong> on desktop.
                </>
              )}
              <Button 
                variant="outline" 
                size="sm" 
                className="ml-4 border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20"
                onClick={openInNewTab}
                data-testid="button-open-new-tab"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Open in New Tab
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-4 space-y-6">
            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Usb className="w-4 h-4" />
                  HARDWARE CONNECTION
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={hardwareType === 'elm327' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setHardwareType('elm327')}
                    disabled={connectionStatus === 'connected'}
                    className="flex flex-col h-auto py-2"
                    data-testid="button-select-elm327"
                  >
                    <Usb className="w-4 h-4 mb-1" />
                    <span className="text-[9px] font-bold">OBDLink</span>
                    <span className="text-[7px] text-white/50">ELM327</span>
                  </Button>
                  <Button
                    variant={hardwareType === 'j2534' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setHardwareType('j2534')}
                    disabled={connectionStatus === 'connected'}
                    className="flex flex-col h-auto py-2"
                    data-testid="button-select-j2534"
                  >
                    <Cable className="w-4 h-4 mb-1" />
                    <span className="text-[9px]">J2534</span>
                    <span className="text-[7px] text-white/50">PassThru</span>
                  </Button>
                  <Button
                    variant={hardwareType === 'arduino' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setHardwareType('arduino')}
                    disabled={connectionStatus === 'connected'}
                    className="flex flex-col h-auto py-2"
                    data-testid="button-select-arduino"
                  >
                    <Cpu className="w-4 h-4 mb-1" />
                    <span className="text-[9px]">Arduino</span>
                    <span className="text-[7px] text-white/50">CAN Bus</span>
                  </Button>
                </div>
                
                {connectionStatus === 'connected' ? (
                  <Button 
                    variant="destructive" 
                    className="w-full"
                    onClick={handleDisconnect}
                    data-testid="button-disconnect"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Disconnect
                  </Button>
                ) : (
                  <Button 
                    className="w-full"
                    onClick={handleConnect}
                    disabled={connectionStatus === 'connecting' || (hardwareType !== 'j2534' && (isInIframe || !serialSupported))}
                    data-testid="button-connect"
                  >
                    {connectionStatus === 'connecting' ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Usb className="w-4 h-4 mr-2" />
                    )}
                    {(hardwareType !== 'j2534' && (isInIframe || !serialSupported)) 
                      ? 'WebSerial Blocked' 
                      : `Connect ${hardwareType.toUpperCase()}`}
                  </Button>
                )}
                
                {hardwareType === 'elm327' && (
                  <p className="text-xs text-white/50 text-center">
                    OBDLink EX, SX, MX+ and ELM327 USB/Bluetooth
                  </p>
                )}
                {hardwareType === 'j2534' && (
                  <div className="space-y-2">
                    <p className="text-xs text-white/50 text-center">
                      <span className="text-emerald-400 font-semibold">⚡ MicroPod II</span>, Autel, Drew Tech
                    </p>
                    <p className="text-[10px] text-white/40 text-center leading-tight">
                      Professional-grade PassThru • No timeouts • Full security access
                    </p>
                  </div>
                )}
                {hardwareType === 'arduino' && (
                  <p className="text-xs text-white/50 text-center">
                    Arduino + MCP2515 CAN shield via WebSerial
                  </p>
                )}

                {/* Port Selector for WebSerial devices */}
                {hardwareType !== 'j2534' && connectionStatus !== 'connected' && (
                  <div className="pt-3 border-t border-white/10 space-y-2">
                    {(isInIframe || !serialSupported) ? (
                      <p className="text-xs text-red-400/80 text-center py-2">
                        WebSerial unavailable - open in a standalone browser tab to connect hardware
                      </p>
                    ) : (
                      <>
                        <div className="flex items-center gap-2">
                          <Select 
                            value={selectedPortIndex.toString()} 
                            onValueChange={(val) => setSelectedPortIndex(parseInt(val))}
                          >
                            <SelectTrigger 
                              className="flex-1 h-8 text-xs"
                              data-testid="select-port"
                            >
                              <SelectValue placeholder="Select a paired port..." />
                            </SelectTrigger>
                            <SelectContent>
                              {availablePorts.length === 0 ? (
                                <SelectItem value="-1" disabled>No paired ports</SelectItem>
                              ) : (
                                availablePorts.map((portInfo, idx) => (
                                  <SelectItem key={idx} value={idx.toString()}>
                                    {portInfo.displayName}
                                  </SelectItem>
                                ))
                              )}
                            </SelectContent>
                          </Select>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="h-8 px-2"
                            onClick={handlePairNewPort}
                            data-testid="button-pair-new"
                            title="Pair New Device"
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="h-8 px-2"
                            onClick={refreshPorts}
                            data-testid="button-refresh-ports"
                            title="Refresh Port List"
                          >
                            <RefreshCw className="w-3 h-3" />
                          </Button>
                        </div>
                        {availablePorts.length === 0 ? (
                          <p className="text-xs text-yellow-400/70 text-center">
                            Click + to pair your USB device first
                          </p>
                        ) : (
                          <p className="text-xs text-white/40 text-center">
                            {availablePorts.length} paired port{availablePorts.length !== 1 ? 's' : ''} available
                          </p>
                        )}
                        {availablePorts.length > 0 && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="w-full text-xs text-white/40 hover:text-white h-6"
                            onClick={forgetAllPorts}
                            data-testid="button-forget-ports"
                          >
                            Clear All Paired Ports
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <ScanLine className="w-4 h-4" />
                  MODULE SCAN
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    className="w-full"
                    onClick={handleScan}
                    disabled={connectionStatus !== 'connected' || scanStatus === 'scanning' || isDiscovering}
                    data-testid="button-scan-modules"
                  >
                    {scanStatus === 'scanning' ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <ScanLine className="w-4 h-4 mr-2" />
                    )}
                    Known
                  </Button>
                  
                  <Button 
                    variant="secondary"
                    className="w-full"
                    onClick={handleDiscoverModules}
                    disabled={connectionStatus !== 'connected' || isDiscovering || scanStatus === 'scanning'}
                    data-testid="button-discover-modules"
                  >
                    {isDiscovering ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Radio className="w-4 h-4 mr-2" />
                    )}
                    Discover
                  </Button>
                </div>
                
                <p className="text-xs text-white/40 text-center">
                  Known = scan preset addresses | Discover = find all modules on CAN bus
                </p>
                
                {(scanStatus === 'scanning' || isDiscovering) && (
                  <div className="space-y-2">
                    <Progress value={isDiscovering ? discoveryProgress : scanProgress} className="h-2" />
                    <p className="text-xs text-white/50 text-center">
                      {isDiscovering ? `Discovering: ${discoveryProgress}%` : `${scanProgress}% complete`}
                    </p>
                  </div>
                )}
                
                {discoveredModules.length > 0 && (
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={handleReadVINs}
                      data-testid="button-read-vins"
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      Read VINs
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={selectAllModules}
                      data-testid="button-select-all"
                    >
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Select All
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Pencil className="w-4 h-4" />
                  VIN PROGRAMMING
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs text-white/70">Target VIN</Label>
                  <Input
                    value={targetVIN}
                    onChange={(e) => setTargetVIN(e.target.value.toUpperCase())}
                    placeholder="Enter 17-character VIN"
                    maxLength={17}
                    className="font-mono text-sm"
                    data-testid="input-target-vin"
                  />
                </div>
                
                {vinInfo && (
                  <>
                    <div className="bg-card/50 rounded-lg p-3 text-xs space-y-1">
                      <div className="flex justify-between">
                        <span className="text-white/50">Manufacturer:</span>
                        <span className="font-mono">{vinInfo.manufacturer}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50">Year:</span>
                        <span className="font-mono">{vinInfo.modelYear || 'Unknown'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50">Check Digit:</span>
                        <Badge variant={vinInfo.checkDigitValid ? 'default' : 'destructive'} className="text-[10px]">
                          {vinInfo.checkDigitValid ? 'VALID' : 'INVALID'}
                        </Badge>
                      </div>
                    </div>
                    
                    {!vinInfo.valid && vinInfo.errors.length > 0 && (
                      <Alert variant="destructive" className="py-2">
                        <AlertTriangle className="h-3 w-3" />
                        <AlertTitle className="text-xs">Invalid VIN</AlertTitle>
                        <AlertDescription className="text-xs">
                          {vinInfo.errors.map((err, i) => (
                            <div key={i}>• {err}</div>
                          ))}
                        </AlertDescription>
                      </Alert>
                    )}
                  </>
                )}
                
                <Button 
                  className="w-full"
                  onClick={handleWriteVINs}
                  disabled={
                    connectionStatus !== 'connected' || 
                    selectedModules.size === 0 || 
                    targetVIN.length !== 17 ||
                    (vinInfo && !vinInfo.valid) ||
                    isWriting
                  }
                  data-testid="button-write-vins"
                >
                  {isWriting ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4 mr-2" />
                  )}
                  Program {selectedModules.size} Module{selectedModules.size !== 1 ? 's' : ''}
                </Button>
                
                {isWriting && (
                  <Progress value={writeProgress} className="h-2" />
                )}
              </CardContent>
            </Card>

            {/* EOL Routine Fuzzer Card */}
            <Card className="border-white/10 border-red-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2 text-red-400">
                  <Zap className="w-4 h-4" />
                  EOL ROUTINE FUZZER
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-red-500/10 border-red-500/30">
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                  <AlertTitle className="text-xs text-red-400">Advanced Feature</AlertTitle>
                  <AlertDescription className="text-xs text-white/60">
                    Tests EOL routines (0x31) with bootloader access. Use with caution.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label className="text-xs text-white/70">Target Module</Label>
                  <Select 
                    value={selectedFuzzModule} 
                    onValueChange={setSelectedFuzzModule}
                    disabled={discoveredModules.length === 0}
                  >
                    <SelectTrigger 
                      className="text-xs"
                      data-testid="select-fuzz-module"
                    >
                      <SelectValue placeholder="Select module to fuzz..." />
                    </SelectTrigger>
                    <SelectContent>
                      {discoveredModules.map((mod) => (
                        <SelectItem key={mod.code} value={mod.code}>
                          {mod.code} - {mod.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="bg-card/50 rounded-lg p-3 text-xs space-y-1">
                  <p className="text-white/50 mb-2">Target Routine IDs:</p>
                  {Object.entries(EOL_ROUTINE_IDS).map(([name, id]) => (
                    <div key={name} className="flex justify-between font-mono">
                      <span className="text-white/70">{name}</span>
                      <span className="text-primary">0x{id.toString(16).toUpperCase().padStart(4, '0')}</span>
                    </div>
                  ))}
                </div>

                <Button 
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={handleFuzzRoutines}
                  disabled={
                    connectionStatus !== 'connected' || 
                    !selectedFuzzModule ||
                    isFuzzing
                  }
                  data-testid="button-fuzz-routines"
                >
                  {isFuzzing ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4 mr-2" />
                  )}
                  {isFuzzing ? 'Fuzzing...' : 'Start Fuzzer'}
                </Button>
                
                {isFuzzing && (
                  <div className="space-y-2">
                    <Progress value={fuzzProgress} className="h-2" />
                    <p className="text-xs text-white/50 text-center">{fuzzProgress}% complete</p>
                  </div>
                )}

                {fuzzResults.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-xs text-white/70">Results:</Label>
                    <div className="bg-card/30 rounded-lg p-2 max-h-40 overflow-y-auto space-y-1">
                      {fuzzResults.map((result, idx) => (
                        <div 
                          key={idx} 
                          className={cn(
                            "text-xs font-mono py-1 px-2 rounded flex justify-between items-center",
                            getFuzzerVerdictClass(result.verdict)
                          )}
                        >
                          <span className="flex items-center gap-2">
                            <span>{getFuzzerVerdictEmoji(result.verdict)}</span>
                            <span>0x{result.routineId.toString(16).toUpperCase().padStart(4, '0')}</span>
                            <span className="text-white/70">{result.routineName}</span>
                          </span>
                          <span className="font-semibold">{result.verdict.replace('_', ' ')}</span>
                        </div>
                      ))}
                    </div>
                    <div className="text-xs text-white/50 text-center">
                      {fuzzResults.filter(r => r.verdict === 'SUCCESS').length} SUCCESS | 
                      {' '}{fuzzResults.filter(r => r.verdict === 'SOFT_HIT').length} SOFT HIT |
                      {' '}{fuzzResults.filter(r => r.verdict === 'REJECTED').length} REJECTED
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Seed/Key Capture Mode Panel */}
            <Card className="border-amber-500/30">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2 text-amber-400">
                  <Radio className="w-4 h-4" />
                  SEED/KEY CAPTURE MODE
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-amber-500/10 border-amber-500/30">
                  <Radio className="h-4 w-4 text-amber-400" />
                  <AlertTitle className="text-xs text-amber-400">Algorithm Research Tool</AlertTitle>
                  <AlertDescription className="text-xs text-white/60">
                    Captures seed/key pairs from security access attempts for 2018+ Atlantis algorithm reverse engineering.
                  </AlertDescription>
                </Alert>

                <div className="flex items-center justify-between p-3 bg-card/50 rounded-lg">
                  <div>
                    <p className="text-xs font-semibold text-white/80">Capture Mode</p>
                    <p className="text-[10px] text-white/50">Log all security access attempts</p>
                  </div>
                  <Button
                    variant={captureEnabled ? "destructive" : "outline"}
                    size="sm"
                    onClick={() => handleToggleCaptureMode()}
                    data-testid="button-toggle-capture"
                    className="min-w-[80px]"
                  >
                    {captureEnabled ? 'STOP' : 'START'}
                  </Button>
                </div>

                {captureEnabled && (
                  <div className="flex items-center gap-2 py-2 px-3 bg-amber-500/10 rounded-lg">
                    <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
                    <span className="text-xs text-amber-400 font-mono">CAPTURING...</span>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 text-xs"
                    onClick={handleRefreshCaptures}
                    data-testid="button-refresh-captures"
                  >
                    <RefreshCw className="w-3 h-3 mr-1" />
                    Refresh
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 text-xs"
                    onClick={handleExportCaptures}
                    disabled={captures.length === 0}
                    data-testid="button-export-captures"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs text-red-400 hover:text-red-300"
                    onClick={handleClearCaptures}
                    disabled={captures.length === 0}
                    data-testid="button-clear-captures"
                  >
                    Clear
                  </Button>
                </div>

                {captures.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-xs text-white/70">Captured Samples ({captures.length}):</Label>
                    <div className="bg-card/30 rounded-lg p-2 max-h-48 overflow-y-auto space-y-2">
                      {captures.map((capture) => (
                        <div
                          key={capture.id}
                          className={cn(
                            "text-xs font-mono p-2 rounded border",
                            capture.success
                              ? "bg-green-500/10 border-green-500/30"
                              : "bg-red-500/10 border-red-500/30"
                          )}
                        >
                          <div className="flex justify-between items-start mb-1">
                            <span className="font-bold">{capture.moduleCode}</span>
                            <span className={cn(
                              "text-[10px] px-1 rounded",
                              capture.success ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                            )}>
                              {capture.success ? 'ACCEPTED' : 'REJECTED'}
                            </span>
                          </div>
                          <div className="text-[10px] text-white/60 space-y-0.5">
                            <div>Level: 0x{capture.securityLevel.toString(16).toUpperCase().padStart(2, '0')}</div>
                            <div>Seed: <span className="text-amber-400">{capture.seedHex}</span></div>
                            <div>Key: <span className="text-primary">{capture.keyHex}</span></div>
                            {capture.csnHex && (
                              <div>CSN: <span className="text-cyan-400">{capture.csnHex}</span></div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {captures.length === 0 && (
                  <div className="text-center py-4 text-white/40">
                    <Radio className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">No captures yet</p>
                    <p className="text-[10px] mt-1">Enable capture mode and attempt security access</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="col-span-5">
            <Card className="border-white/10 h-full">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Car className="w-4 h-4" />
                    DISCOVERED MODULES
                  </div>
                  <Badge variant="secondary" className="font-mono">
                    {discoveredModules.length} FOUND
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[calc(100vh-300px)]">
                  {discoveredModules.length === 0 ? (
                    <div className="text-center py-12 text-white/50">
                      <Car className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p className="text-sm">No modules discovered yet</p>
                      <p className="text-xs mt-1">Connect hardware and scan to find modules</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {discoveredModules.map((mod) => (
                        <div
                          key={mod.code}
                          className={cn(
                            "p-3 rounded-lg border transition-all cursor-pointer",
                            selectedModules.has(mod.code) 
                              ? "bg-primary/10 border-primary/50" 
                              : "bg-card/50 border-white/10 hover:border-white/20"
                          )}
                          onClick={() => toggleModuleSelection(mod.code)}
                          data-testid={`module-card-${mod.code}`}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <Checkbox 
                                checked={selectedModules.has(mod.code)}
                                className="mt-0.5"
                              />
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-bold text-sm">{mod.code}</span>
                                  {mod.status === 'vin_written' && (
                                    <Badge className="bg-green-500/20 text-green-400 text-[10px]">
                                      <CheckCircle2 className="w-2 h-2 mr-1" />
                                      WRITTEN
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-xs text-white/50">{mod.name}</p>
                                <p className="text-[10px] text-white/30 font-mono mt-1">
                                  TX: 0x{mod.txId.toString(16).toUpperCase()} | RX: 0x{mod.rxId.toString(16).toUpperCase()}
                                </p>
                              </div>
                            </div>
                            {mod.vin && (
                              <div className="text-right">
                                <span className="text-[10px] text-white/50 block">VIN:</span>
                                <span className="font-mono text-xs text-primary">{mod.vin}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          <div className="col-span-3">
            <Card className="border-white/10 h-full">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    ACTIVITY LOG
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setLogs([])}
                    className="h-6 px-2 text-[10px]"
                    data-testid="button-clear-logs"
                  >
                    Clear
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[calc(100vh-300px)]">
                  <div className="space-y-1 font-mono text-xs">
                    {logs.length === 0 ? (
                      <p className="text-white/30 text-center py-4">No activity yet</p>
                    ) : (
                      logs.map((log) => {
                        // Detect algorithm mentions for special highlighting
                        const isAlgorithmMessage = log.message.includes('SKIM') || 
                                                   log.message.includes('Atlantis') || 
                                                   log.message.includes('ROL5+XOR');
                        const algorithmMatch = log.message.match(/(SKIM[^)]*|Atlantis[^)]*|ROL5\+XOR[^)]*)/);
                        
                        return (
                          <div 
                            key={log.id}
                            className={cn(
                              "py-1 px-2 rounded",
                              isAlgorithmMessage && "bg-cyan-500/10 border-l-2 border-cyan-500/50",
                              log.type === 'success' && "text-green-400",
                              log.type === 'error' && "text-red-400",
                              log.type === 'warning' && "text-amber-400",
                              log.type === 'tx' && "text-blue-400",
                              log.type === 'rx' && "text-purple-400",
                              log.type === 'info' && "text-white/70"
                            )}
                          >
                            <span className="text-white/30 mr-2">{log.timestamp}</span>
                            <span className="text-white/50 mr-1">
                              {log.type === 'tx' ? '→' : log.type === 'rx' ? '←' : '•'}
                            </span>
                            {isAlgorithmMessage && algorithmMatch ? (
                              <>
                                {log.message.substring(0, algorithmMatch.index)}
                                <span className="font-bold text-cyan-400 px-1 rounded bg-cyan-500/20">
                                  {algorithmMatch[1]}
                                </span>
                                {log.message.substring((algorithmMatch.index || 0) + algorithmMatch[1].length)}
                              </>
                            ) : (
                              log.message
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

    </div>
  );
}
