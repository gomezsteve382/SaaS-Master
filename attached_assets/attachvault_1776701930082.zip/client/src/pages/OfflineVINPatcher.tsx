import { useState } from 'react';
import { Upload, FileCheck, CheckCircle2, XCircle, Download, HardDrive, Shield, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export default function OfflineVINPatcher() {
  const [file, setFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string>('');
  const [newVIN, setNewVIN] = useState('');
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    setFile(uploadedFile);
    setResult(null);

    // Convert to base64
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      setFileBase64(base64);
      
      // Auto-detect VIN
      detectVIN(base64);
    };
    reader.readAsDataURL(uploadedFile);
  };

  const detectVIN = async (base64: string) => {
    try {
      const vinResult = await trpc.offlineTools.findVINInDump.query({ fileBase64: base64 });
      
      if (vinResult.found) {
        toast.success(`VIN detected: ${vinResult.vin} at offset 0x${vinResult.location?.toString(16).toUpperCase()}`);
      } else {
        toast.warning('No VIN found in dump file');
      }
    } catch (error: any) {
      toast.error(`Detection failed: ${error.message}`);
    }
  };

  const processFile = async () => {
    if (!file || !fileBase64 || !newVIN) {
      toast.error('Please upload a file and enter a new VIN');
      return;
    }

    setProcessing(true);
    setResult(null);

    try {
      const processResult = await trpc.offlineTools.processRFHubBCM.mutate({
        fileBase64,
        newVIN,
      });

      setResult(processResult);

      if (processResult.vinPatch.success) {
        toast.success('VIN patched successfully!');
      } else {
        toast.error(processResult.vinPatch.message);
      }
    } catch (error: any) {
      toast.error(`Processing failed: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const downloadPatchedFile = () => {
    if (!result?.finalDataBase64) return;

    const binaryData = atob(result.finalDataBase64);
    const bytes = new Uint8Array(binaryData.length);
    for (let i = 0; i < binaryData.length; i++) {
      bytes[i] = binaryData.charCodeAt(i);
    }

    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file?.name.replace(/\.bin$/, '_PATCHED.bin') || 'patched.bin';
    a.click();
    URL.revokeObjectURL(url);

    toast.success('Patched file downloaded!');
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Offline VIN Patcher</h1>
        <p className="text-muted-foreground">
          Patch VIN in RFHUB/BCM dumps with automatic CRC validation and PIN extraction
        </p>
      </div>

      {/* File Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload RFHUB/BCM Dump
          </CardTitle>
          <CardDescription>
            Supports Continental, Marelli, Bosch, Valeo, Delphi, TRW, Siemens VDO BCM types
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Input
              type="file"
              accept=".bin,.eep,.dump"
              onChange={handleFileUpload}
              className="cursor-pointer"
            />
            {file && (
              <div className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                <FileCheck className="w-4 h-4" />
                {file.name} ({(file.size / 1024).toFixed(2)} KB)
              </div>
            )}
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">New VIN (17 characters)</label>
            <Input
              type="text"
              placeholder="1C4RJFBG5FC123456"
              value={newVIN}
              onChange={(e) => setNewVIN(e.target.value.toUpperCase())}
              maxLength={17}
              className="font-mono"
            />
            <p className="text-xs text-muted-foreground mt-1">
              VIN must be 17 alphanumeric characters (no I, O, Q)
            </p>
          </div>

          <Button
            onClick={processFile}
            disabled={!file || !newVIN || processing}
            className="w-full"
            size="lg"
          >
            {processing ? (
              <>Processing...</>
            ) : (
              <>
                <Shield className="w-4 h-4 mr-2" />
                Patch VIN & Fix Checksum
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {result && (
        <div className="space-y-4">
          {/* VIN Patch Result */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {result.vinPatch.success ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
                VIN Patching
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Alert variant={result.vinPatch.success ? 'default' : 'destructive'}>
                <AlertDescription>{result.vinPatch.message}</AlertDescription>
              </Alert>

              {result.vinPatch.success && (
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Original VIN:</span>
                    <div className="font-mono font-bold">{result.vinPatch.originalVIN}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">New VIN:</span>
                    <div className="font-mono font-bold text-green-600">{result.vinPatch.newVIN}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">VIN Location:</span>
                    <div className="font-mono">0x{result.vinPatch.vinLocation?.toString(16).toUpperCase().padStart(4, '0')}</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* PIN Extraction */}
          {result.pinExtraction.success && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-blue-500" />
                  PIN Extraction
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Alert>
                  <AlertDescription>{result.pinExtraction.message}</AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">PIN Code:</span>
                    <div className="font-mono font-bold text-2xl text-blue-600">{result.pinExtraction.pin}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">PIN Type:</span>
                    <Badge variant={result.pinExtraction.pinType === 'encrypted' ? 'default' : 'secondary'}>
                      {result.pinExtraction.pinType}
                    </Badge>
                  </div>
                  <div>
                    <span className="text-muted-foreground">PIN Location:</span>
                    <div className="font-mono">0x{result.pinExtraction.pinLocation?.toString(16).toUpperCase().padStart(4, '0')}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Checksum Validation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {result.checksum.isValid ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <Shield className="w-5 h-5 text-yellow-500" />
                )}
                Checksum Validation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Alert variant={result.checksum.isValid ? 'default' : 'destructive'}>
                <AlertDescription>{result.checksum.message}</AlertDescription>
              </Alert>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Checksum Type:</span>
                  <Badge>{result.checksum.checksumType}</Badge>
                </div>
                <div>
                  <span className="text-muted-foreground">Status:</span>
                  <Badge variant={result.checksum.isValid ? 'default' : 'destructive'}>
                    {result.checksum.isValid ? 'Valid' : 'Fixed'}
                  </Badge>
                </div>
                <div>
                  <span className="text-muted-foreground">Original:</span>
                  <div className="font-mono">{result.checksum.originalChecksum}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Calculated:</span>
                  <div className="font-mono text-green-600">{result.checksum.calculatedChecksum}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Checksum Location:</span>
                  <div className="font-mono">0x{result.checksum.checksumLocation?.toString(16).toUpperCase().padStart(4, '0')}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Download Button */}
          {result.vinPatch.success && (
            <Card className="bg-green-50 dark:bg-green-950">
              <CardContent className="pt-6">
                <Button onClick={downloadPatchedFile} size="lg" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Download Patched File
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Info Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            Supported Module Types
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
            {[
              'Continental RF Hub',
              'Marelli BCM',
              'Bosch BCM',
              'Valeo BCM',
              'Delphi BCM',
              'TRW BCM',
              'Siemens VDO BCM',
              'Generic BCM',
            ].map((type) => (
              <Badge key={type} variant="outline">
                {type}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
