export default function BlankRFHUBWizardTest() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold">Blank RFHUB Programming Wizard</h1>
      <p>Test page loaded successfully!</p>
    </div>
  );
}
