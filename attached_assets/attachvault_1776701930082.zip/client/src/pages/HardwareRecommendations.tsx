import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { trpc } from '@/lib/trpc';
import { Loader2, CheckCircle2, AlertCircle, Info, Settings, Clock, Database, Shield, Zap } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { BackButton } from '@/components/BackButton';

type HardwareType = 'elm327' | 'j2534' | 'arduino';

interface HardwareCapabilities {
  type: HardwareType;
  available: boolean;
  maxTimeout: number;
  maxBufferSize: number;
  supportsISO_TP: boolean;
  supportsSecurityAccess: boolean;
  supportsProgrammingSession: boolean;
  supportsTimingControl: boolean;
  responseTime: number;
  reliability: number;
}

interface HardwareRecommendation {
  recommended: HardwareType;
  score: number;
  reason: string;
  alternatives: Array<{
    type: HardwareType;
    score: number;
    warnings: string[];
  }>;
}

export default function HardwareRecommendations() {
  const [selectedModule, setSelectedModule] = useState<string>('');
  const [showDetails, setShowDetails] = useState(false);

  const detectAllQuery = trpc.hardwareDetector.detectAll.useQuery();
  const allRequirementsQuery = trpc.hardwareDetector.getAllModuleRequirements.useQuery();
  const recommendForModuleQuery = trpc.hardwareDetector.recommendForModule.useQuery(
    { moduleType: selectedModule },
    { enabled: !!selectedModule }
  );

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    if (score >= 50) return 'text-orange-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 90) return 'bg-green-100 text-green-800 border-green-300';
    if (score >= 70) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    if (score >= 50) return 'bg-orange-100 text-orange-800 border-orange-300';
    return 'bg-red-100 text-red-800 border-red-300';
  };

  const formatHardwareName = (type: HardwareType) => {
    switch (type) {
      case 'elm327': return 'ELM327';
      case 'j2534': return 'J2534 PassThru';
      case 'arduino': return 'Arduino CAN';
      default: return type;
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Hardware Recommendations</h1>
          <p className="text-muted-foreground">
            Get hardware recommendations for each module type based on capabilities and requirements
          </p>
        </div>

        {/* Hardware Detection Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Available Hardware</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDetails(!showDetails)}
              >
                {showDetails ? 'Hide' : 'Show'} Details
              </Button>
            </CardTitle>
            <CardDescription>
              {detectAllQuery.isLoading ? (
                <span className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Detecting hardware...
                </span>
              ) : detectAllQuery.data ? (
                `Found ${detectAllQuery.data.hardware.filter(h => h.available).length} available adapter(s)`
              ) : (
                'Click to detect hardware'
              )}
            </CardDescription>
          </CardHeader>
          {showDetails && detectAllQuery.data && (
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Hardware</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Timeout</TableHead>
                    <TableHead>Buffer</TableHead>
                    <TableHead>ISO-TP</TableHead>
                    <TableHead>Security</TableHead>
                    <TableHead>Programming</TableHead>
                    <TableHead>Timing</TableHead>
                    <TableHead>Response</TableHead>
                    <TableHead>Reliability</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detectAllQuery.data.hardware.map((hw) => (
                    <TableRow key={hw.type}>
                      <TableCell className="font-medium">{formatHardwareName(hw.type)}</TableCell>
                      <TableCell>
                        {hw.available ? (
                          <Badge className="bg-green-100 text-green-800 border-green-300">Available</Badge>
                        ) : (
                          <Badge variant="outline" className="text-muted-foreground">Not Found</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm">
                          <Clock className="mr-1 h-3 w-3" />
                          {hw.maxTimeout}ms
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm">
                          <Database className="mr-1 h-3 w-3" />
                          {hw.maxBufferSize}B
                        </div>
                      </TableCell>
                      <TableCell>
                        {hw.supportsISO_TP ? (
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-600" />
                        )}
                      </TableCell>
                      <TableCell>
                        {hw.supportsSecurityAccess ? (
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-600" />
                        )}
                      </TableCell>
                      <TableCell>
                        {hw.supportsProgrammingSession ? (
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-600" />
                        )}
                      </TableCell>
                      <TableCell>
                        {hw.supportsTimingControl ? (
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-600" />
                        )}
                      </TableCell>
                      <TableCell className="text-sm">{hw.responseTime}ms</TableCell>
                      <TableCell className="text-sm">{hw.reliability}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          )}
        </Card>

        {/* Module Selection */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Select Module Type</CardTitle>
            <CardDescription>
              Choose a module to see hardware recommendations based on its specific requirements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {allRequirementsQuery.data && Object.keys(allRequirementsQuery.data.requirements).map((module) => (
                <Button
                  key={module}
                  variant={selectedModule === module ? 'default' : 'outline'}
                  onClick={() => setSelectedModule(module)}
                  className="h-auto py-3"
                >
                  {module}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recommendations */}
        {selectedModule && recommendForModuleQuery.data?.recommendation && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{selectedModule} Recommendation</span>
                  <Badge className={getScoreBadge(recommendForModuleQuery.data.recommendation.score)}>
                    Score: {recommendForModuleQuery.data.recommendation.score}/100
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Recommended Hardware */}
                <div className="border-l-4 border-green-500 bg-green-50 p-4 rounded">
                  <div className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold text-green-900 mb-1">
                        Recommended: {formatHardwareName(recommendForModuleQuery.data.recommendation.recommended)}
                      </h3>
                      <p className="text-sm text-green-800">
                        {recommendForModuleQuery.data.recommendation.reason}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Module Requirements */}
                {allRequirementsQuery.data && (
                  <div>
                    <h3 className="font-semibold mb-3 flex items-center">
                      <Settings className="mr-2 h-4 w-4" />
                      {selectedModule} Requirements
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {(() => {
                        const req = allRequirementsQuery.data.requirements[selectedModule];
                        return (
                          <>
                            <div className="text-sm">
                              <div className="text-muted-foreground">Min Timeout</div>
                              <div className="font-medium">{req.minTimeout}ms</div>
                            </div>
                            <div className="text-sm">
                              <div className="text-muted-foreground">Min Buffer</div>
                              <div className="font-medium">{req.minBufferSize}B</div>
                            </div>
                            <div className="text-sm">
                              <div className="text-muted-foreground">Operation Type</div>
                              <div className="font-medium capitalize">{req.operationType}</div>
                            </div>
                            <div className="text-sm">
                              <div className="text-muted-foreground">Security Level</div>
                              <div className="font-medium">
                                {req.requiresSecurityAccess ? 'Required' : 'Optional'}
                              </div>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* Alternative Hardware */}
                {recommendForModuleQuery.data.recommendation.alternatives.length > 0 && (
                  <div>
                    <h3 className="font-semibold mb-3">Alternative Hardware</h3>
                    <div className="space-y-3">
                      {recommendForModuleQuery.data.recommendation.alternatives.map((alt) => (
                        <div
                          key={alt.type}
                          className={`border-l-4 p-4 rounded ${
                            alt.score >= 70
                              ? 'border-yellow-500 bg-yellow-50'
                              : 'border-orange-500 bg-orange-50'
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center mb-2">
                                <span className="font-medium mr-2">
                                  {formatHardwareName(alt.type)}
                                </span>
                                <Badge className={getScoreBadge(alt.score)}>
                                  {alt.score}/100
                                </Badge>
                              </div>
                              {alt.warnings.length > 0 && (
                                <ul className="text-sm space-y-1">
                                  {alt.warnings.map((warning, idx) => (
                                    <li key={idx} className="flex items-start">
                                      <AlertCircle className="h-3 w-3 mr-2 mt-0.5 flex-shrink-0" />
                                      {warning}
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Reference Guide */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Info className="mr-2 h-5 w-5" />
                  Quick Reference Guide
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <Zap className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Hardware Selection Tips:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li><strong>J2534 PassThru:</strong> Best for all operations, especially programming. Supports all modules with full timing control.</li>
                      <li><strong>ELM327:</strong> Good for diagnostics and basic VIN reading. Limited programming support due to timeout and buffer constraints.</li>
                      <li><strong>Arduino CAN:</strong> Experimental support. Best for custom CAN monitoring and development.</li>
                    </ul>
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2 text-green-600">✓ Use J2534 For:</h4>
                    <ul className="text-sm space-y-1">
                      <li>• VIN programming (all modules)</li>
                      <li>• Security access operations</li>
                      <li>• Programming sessions</li>
                      <li>• Modules requiring &gt;2s timeout</li>
                      <li>• Large data transfers (&gt;512 bytes)</li>
                    </ul>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2 text-yellow-600">⚠ Use ELM327 For:</h4>
                    <ul className="text-sm space-y-1">
                      <li>• VIN reading (diagnostics)</li>
                      <li>• DTC reading and clearing</li>
                      <li>• Live data monitoring</li>
                      <li>• Basic module scanning</li>
                      <li>• Quick diagnostics</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {!selectedModule && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Select a module type above to see hardware recommendations based on its specific requirements.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
}
