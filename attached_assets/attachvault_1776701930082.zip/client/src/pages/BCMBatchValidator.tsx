import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, XCircle, Upload, Loader2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BCMBatchValidator() {
  const [files, setFiles] = useState<File[]>([]);
  const [results, setResults] = useState<any>(null);
  const [isValidating, setIsValidating] = useState(false);
  const { toast } = useToast();

  const batchValidateMutation = trpc.bcmValidator.batchValidate.useMutation({
    onSuccess: (data) => {
      setResults(data);
      setIsValidating(false);
      toast({
        title: "Batch Validation Complete",
        description: `${data.summary.passed}/${data.summary.total} files passed validation`,
      });
    },
    onError: (error) => {
      setIsValidating(false);
      toast({
        title: "Validation Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
      setResults(null);
    }
  };

  const handleBatchValidate = async () => {
    if (files.length === 0) {
      toast({
        title: "No Files Selected",
        description: "Please select BCM files to validate",
        variant: "destructive",
      });
      return;
    }

    setIsValidating(true);

    const fileDataArray = await Promise.all(
      files.map(
        (file) =>
          new Promise<{ fileData: string; filename: string }>((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => {
              const arrayBuffer = e.target?.result as ArrayBuffer;
              const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
              resolve({ fileData: base64, filename: file.name });
            };
            reader.readAsArrayBuffer(file);
          })
      )
    );

    batchValidateMutation.mutate({ files: fileDataArray });
  };

  const handleExportCSV = () => {
    if (!results) return;

    const headers = ["Filename", "VIN", "Status", "Checksum Type", "VIN Location", "Checksum Valid"];
    const rows = results.results.map((r: any) => [
      r.filename,
      r.vin || "N/A",
      r.isValid ? "Valid" : "Invalid",
      r.checksumType,
      `0x${r.vinLocation.toString(16).toUpperCase()}`,
      r.checksumValid ? "Yes" : "No",
    ]);

    const csv = [headers, ...rows].map((row) => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bcm-batch-validation-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">BCM Batch Validator</h1>
        <p className="text-muted-foreground">
          Validate multiple BCM EEPROM dumps at once and export results
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload BCM Files</CardTitle>
          <CardDescription>Select multiple BCM EEPROM dump files (.bin)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                type="file"
                accept=".bin"
                multiple
                onChange={handleFilesChange}
                disabled={isValidating}
                className="flex-1 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
              />
              <Button onClick={handleBatchValidate} disabled={files.length === 0 || isValidating}>
                {isValidating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Validating...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Validate All
                  </>
                )}
              </Button>
            </div>
          </div>

          {files.length > 0 && (
            <div className="text-sm text-muted-foreground">
              Selected {files.length} file{files.length !== 1 ? "s" : ""} (
              {(files.reduce((acc, f) => acc + f.size, 0) / 1024).toFixed(2)} KB total)
            </div>
          )}
        </CardContent>
      </Card>

      {results && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Validation Summary</CardTitle>
              <CardDescription>
                {results.summary.passed} of {results.summary.total} files passed validation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Pass Rate</span>
                  <span className="font-bold">{results.summary.passRate.toFixed(1)}%</span>
                </div>
                <Progress value={results.summary.passRate} className="h-2" />
              </div>

              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold">{results.summary.total}</div>
                  <div className="text-sm text-muted-foreground">Total Files</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">{results.summary.passed}</div>
                  <div className="text-sm text-muted-foreground">Passed</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">{results.summary.failed}</div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
              </div>

              <Button onClick={handleExportCSV} variant="outline" className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export Results as CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Validation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {results.results.map((result: any, index: number) => (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      result.isValid ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {result.isValid ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                      <div>
                        <div className="font-medium">{result.filename}</div>
                        <div className="text-sm text-muted-foreground">
                          {result.vinFound ? `VIN: ${result.vin}` : "VIN not found"} •{" "}
                          {result.checksumType}
                        </div>
                      </div>
                    </div>
                    <div className="text-sm">
                      {result.checksumValid ? (
                        <span className="text-green-600 font-medium">Checksum Valid</span>
                      ) : (
                        <span className="text-red-600 font-medium">Checksum Invalid</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
