import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { DemoModeToggle } from "@/components/DemoModeToggle";
import { DemoModeBanner } from "@/components/DemoModeBanner";
import {
  Zap,
  ArrowRight,
  Wrench,
  Database,
  Play,
  History,
  TrendingUp,
  Activity,
  CheckCircle2,
  Usb,
  Code,
  Settings,
  FileText,
  Cpu,
  Gauge,
  RefreshCw,
  Sparkles,
  Copy
} from "lucide-react";

export default function Home() {
  const { data: sessionsCount } = trpc.sessionReplay.getSessions.useQuery();

  const categories = [
    {
      title: "Hardware & Connection",
      icon: Usb,
      color: "blue",
      tools: [
        { name: "Connection Diagnostic", path: "/connection-diagnostic", description: "Diagnose hardware connection issues", badge: "NEW" },
        { name: "Hardware Wizard", path: "/hardware-wizard", description: "Auto-detect and configure OBD2 adapters" },
        { name: "Hardware Integration", path: "/hardware-integration", description: "Manage connected devices" },
        { name: "J2534 Tester", path: "/j2534-tester", description: "Test J2534 PassThru devices" },
      ]
    },
    {
      title: "VIN Programming",
      icon: Code,
      color: "red",
      tools: [
        { name: "J2534 Flash Programming", path: "/j2534-flash-availability", description: "1,164 FCA flash calibrations with supersedence validation", badge: "NEW" },
        { name: "Firmware File Analyzer", path: "/firmware-analyzer", description: "Parse .flpart/.fms files, extract UDS commands, export CSV", badge: "NEW" },
        { name: "Batch Firmware Processor", path: "/batch-firmware-processor", description: "Upload 50+ files, supersedence chains, compatibility matrix", badge: "NEW" },
        { name: "Live VIN Programmer", path: "/live-vin-programmer", description: "Real-time VIN programming via UDS" },
        { name: "Blank RFHUB Wizard", path: "/blank-rfhub-wizard", description: "Automated workflow for factory-blank RFHUB modules", badge: "NEW" },
        { name: "VIN Patcher with CRC Calculator", path: "/vin-patcher", description: "Patch VIN in BCM/RFHUB dumps with real-time checksum calculation", badge: "NEW" },
        { name: "VIN Decoder", path: "/vin-decoder", description: "Decode VINs to reveal manufacturer, year, engine, and assembly plant info", badge: "NEW" },
        { name: "Batch VIN Programmer", path: "/batch-vin", description: "Program multiple modules" },
        { name: "Programming Templates", path: "/programming-templates", description: "Pre-configured workflows for BCM/RFHUB replacement", badge: "NEW" },
        { name: "Guided Workflows", path: "/guided-workflows", description: "Step-by-step programming wizards" },
        { name: "ECM Bench Programming", path: "/ecm-bench", description: "Program ECMs on bench via OBD2, BDM, or JTAG", badge: "NEW" },
        { name: "Active Damping Programmer", path: "/active-damping-programmer", description: "Enable active damping on WK2 suspension modules", badge: "NEW" },
      ]
    },
    {
      title: "Diagnostics & Analysis",
      icon: Activity,
      color: "green",
      tools: [
        { name: "Module Scanner", path: "/module-scanner", description: "Scan CAN bus for modules" },
        { name: "DTC Database", path: "/dtc-database", description: "Search diagnostic trouble codes" },
        { name: "CAN Sniffer", path: "/can-sniffer", description: "Monitor CAN bus traffic" },
        { name: "Session Replay", path: "/session-replay", description: "Review recorded diagnostic sessions" },
      ]
    },
    {
      title: "SRT Lab Database",
      icon: Database,
      color: "purple",
      tools: [
        { name: "🚀 Universal Module & Key Programmer", path: "/universal-programmer", description: "ALL 60 SRT Lab Toolkit scripts - program ANY module, key, firmware", badge: "🔥" },
        { name: "SRT Lab Database Explorer", path: "/alphaobd-explorer", description: "22,166 DTCs + 4,757 parameters (DECRYPTED)", badge: "🔥" },
        { name: "Seed-Key Calculator", path: "/seed-key-calculator", description: "9 FCA/Stellantis algorithms", badge: "NEW" },
        { name: "Algorithm Auto-Detection", path: "/algorithm-auto-detection", description: "Identify algorithms from captured seed/key pairs", badge: "NEW" },
        { name: "Live Data Decoder", path: "/live-data-decoder", description: "Decode UDS with FGA formulas", badge: "NEW" },
        { name: "VIN CRC Calculator", path: "/vin-crc-calculator", description: "RFHUB + BCM checksums", badge: "NEW" },
        { name: "ECU Comm Generator", path: "/ecu-comm-generator", description: "468 ECU configs → ELM327/J2534/Arduino", badge: "🔥" },
        { name: "BCM Config Tool", path: "/bcm-config-tool", description: "4,826 BCM parameters → UDS commands", badge: "🔥" },
        { name: "Param Compatibility", path: "/param-compatibility", description: "15,393 device-parameter mappings", badge: "🔥" },
        { name: "Routine Control Executor", path: "/routine-control-executor", description: "232 special routines (proxy, TPMS, activation)", badge: "🔥" },
        { name: "Freeze Frame Analyzer", path: "/freeze-frame-analyzer", description: "9,967 snapshot parameters at fault time", badge: "🔥" },
        { name: "Diesel Engine Dashboard", path: "/diesel-engine-dashboard", description: "4,596 diesel parameters (injection, turbo, DPF)", badge: "🔥" },
        { name: "Algorithm Test Bench", path: "/algorithm-test-bench", description: "Test 431 seed-key algorithms with real-time generation", badge: "🔥" },
        { name: "🤖 AI Diagnostic Assistant", path: "/agentic-assistant", description: "Natural language diagnostics - just tell it what you need", badge: "🚀" },
        { name: "Module Database Importer", path: "/module-database-importer", description: "Import ECU definitions" },
        { name: "DTC Database", path: "/dtc-database", description: "Search diagnostic trouble codes" },
        { name: "SRT Lab Toolkit", path: "/cda6-toolkit", description: "317 Chrysler modules" },
        { name: "Service Resets", path: "/service-resets", description: "Oil service & maintenance procedures" },
        { name: "Calibrations", path: "/calibration-procedures", description: "Sensor & system calibrations" },
        { name: "Special Functions", path: "/special-functions", description: "TPMS, throttle adaptation, etc." },
      ]
    },
    {
      title: "Module Cloning",
      icon: Copy,
      color: "pink",
      tools: [
        { name: "Module Cloning Hub", path: "/module-cloning-hub", description: "Professional module cloning suite", badge: "NEW" },
        { name: "Gateway Clone Tool", path: "/clone/gateway", description: "GPEC4 Gateway with SGW manager" },
        { name: "DID Explorer", path: "/clone/did-explorer", description: "Manual DID read/write operations" },
        { name: "ECM Clone", path: "/clone/ecm", description: "Engine Control Module cloning" },
        { name: "BCM Clone", path: "/clone/bcm", description: "Body Control Module cloning" },
        { name: "RFHUB Clone", path: "/clone/rfhub", description: "RF Hub (TPMS) cloning" },
      ]
    },
    {
      title: "Advanced Tools",
      icon: Settings,
      color: "orange",
      tools: [
        { name: "ECU Unlock Manager", path: "/ecu-unlock-manager", description: "Seed/key generation" },
        { name: "Knowledge Base", path: "/knowledge-base", description: "Browse documentation and guides" },
        { name: "BCM Config Editor", path: "/bcm-config-editor", description: "Edit BCM parameters" },
        { name: "RFHUB PIN Extractor", path: "/rfhub-pin-extractor", description: "Extract RFHUB PIN codes" },
        { name: "RFHUB VIN Patcher", path: "/rfhub-vin-patcher", description: "Patch RFHUB VIN with 10 CRC algorithms", badge: "NEW" },
        { name: "RFHUB SKREEM Extractor", path: "/rfhub-skreem-extractor", description: "Extract security keys with entropy analysis", badge: "NEW" },
        { name: "BCM Recovery Suite", path: "/bcm-recovery", description: "Diagnose and recover bricked BCMs", badge: "NEW" },
        { name: "Module Pairing Validator", path: "/pairing-validator", description: "Validate module pairing" },
        { name: "J2534 Bridge", path: "/j2534-bridge", description: "Connect professional PassThru devices", badge: "NEW" },
      ]
    },
    {
      title: "Calibration Files",
      icon: FileText,
      color: "teal",
      tools: [
        { name: "Calibration Browser", path: "/batch-vin-patcher", description: "Browse 33 BCM/RFHUB dumps" },
        { name: "EEPROM Viewer", path: "/eeprom-viewer", description: "Hex viewer with VIN highlighting" },
        { name: "EEPROM Structure Viewer", path: "/eeprom-structure-viewer", description: "Professional hex analysis with VIN/CRC validation", badge: "NEW" },
        { name: "Module Comparison", path: "/module-comparison", description: "Compare calibration files" },
      ]
    },
  ];

  const colorClasses = {
    blue: "from-blue-50 to-blue-100 border-blue-200 text-blue-600",
    red: "from-red-50 to-red-100 border-red-200 text-red-600",
    green: "from-green-50 to-green-100 border-green-200 text-green-600",
    purple: "from-purple-50 to-purple-100 border-purple-200 text-purple-600",
    orange: "from-orange-50 to-orange-100 border-orange-200 text-orange-600",
    teal: "from-teal-50 to-teal-100 border-teal-200 text-teal-600",
    pink: "from-pink-50 to-pink-100 border-pink-200 text-pink-600",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Demo Mode Toggle */}
      <div className="bg-white border-b border-gray-200 py-3">
        <div className="container">
          <DemoModeToggle />
        </div>
      </div>
      {/* Hero Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-black via-gray-900 to-red-950 text-white">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30"></div>
        <div className="container relative py-16 md:py-24">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 bg-red-600/20 border border-red-600 px-4 py-2 rounded-full mb-6 animate-pulse">
              <Zap className="w-4 h-4 text-red-500" />
              <span className="text-sm font-bold uppercase tracking-wide">System Ready</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tight mb-4 bg-gradient-to-r from-white via-red-200 to-red-600 bg-clip-text text-transparent">
              THE SRT LAB
            </h1>
            <p className="text-xl md:text-2xl font-bold text-red-500 mb-6 uppercase tracking-wide">
              WHERE BUILT NOT BOUGHT BEGINS
            </p>
            <p className="text-lg text-gray-300 mb-8 max-w-2xl">
              Professional automotive VIN programming and diagnostic platform for Chrysler/FCA/Stellantis vehicles. 
              Direct OBD2 communication, module scanning, CAN bus analysis, and advanced feature coding.
            </p>
          </div>
        </div>
        <div className="red-divider"></div>
      </div>

      {/* Demo Mode Banner */}
      <div className="container pt-8">
        <DemoModeBanner />
      </div>

      {/* Quick Stats */}
      <div className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600">Sessions Recorded</p>
                  <p className="text-3xl font-bold text-blue-900">{sessionsCount?.length || 0}</p>
                </div>
                <History className="h-10 w-10 text-blue-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600">SRT Lab Modules</p>
                  <p className="text-3xl font-bold text-green-900">317</p>
                </div>
                <Database className="h-10 w-10 text-green-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600">Calibration Files</p>
                  <p className="text-3xl font-bold text-purple-900">33</p>
                </div>
                <Activity className="h-10 w-10 text-purple-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-600">SRT Lab ECUs</p>
                  <p className="text-3xl font-bold text-orange-900">1000+</p>
                </div>
                <TrendingUp className="h-10 w-10 text-orange-500 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Organized Tool Categories */}
      <div className="container pb-16 space-y-12">
        {categories.map((category) => {
          const Icon = category.icon;
          const colorClass = colorClasses[category.color as keyof typeof colorClasses];
          
          return (
            <div key={category.title}>
              <div className="flex items-center gap-3 mb-6">
                <div className={`p-3 rounded-lg bg-gradient-to-br ${colorClass}`}>
                  <Icon className="h-6 w-6" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">{category.title}</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.tools.map((tool) => (
                  <Link key={tool.path} href={tool.path}>
                    <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-lg">{tool.name}</CardTitle>
                          {tool.badge && (
                            <Badge variant="default" className="bg-green-600">
                              <Sparkles className="h-3 w-3 mr-1" />
                              {tool.badge}
                            </Badge>
                          )}
                        </div>
                        <CardDescription>{tool.description}</CardDescription>
                      </CardHeader>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
