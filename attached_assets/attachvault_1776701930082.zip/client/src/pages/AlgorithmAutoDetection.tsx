import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { Search, Upload, FileText, CheckCircle, AlertCircle, Info, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { trpc } from "@/lib/trpc";

interface AlgorithmMatch {
  algorithm: string;
  confidence: number;
  matches: number;
  total: number;
}

export default function AlgorithmAutoDetection() {
  const [logText, setLogText] = useState<string>("");
  const [detectedPairs, setDetectedPairs] = useState<Array<{ seed: string; key: string }>>([]);
  const [matches, setMatches] = useState<AlgorithmMatch[]>([]);
  const [minConfidence, setMinConfidence] = useState<number>(80);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const parseLogMutation = trpc.offlineTools.parseSeedKeyLog.useMutation();
  const detectAlgorithmMutation = trpc.offlineTools.detectAlgorithm.useMutation();

  const handleParseLog = async () => {
    if (!logText.trim()) {
      toast({
        title: "Error",
        description: "Please enter log text",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await parseLogMutation.mutateAsync({ logText });
      
      if (result.count === 0) {
        toast({
          title: "No Pairs Found",
          description: "Could not find any seed/key pairs in the log text",
          variant: "destructive",
        });
        return;
      }

      setDetectedPairs(result.pairs);
      toast({
        title: "Success",
        description: `Found ${result.count} seed/key pair(s)`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to parse log",
        variant: "destructive",
      });
    }
  };

  const handleDetectAlgorithm = async () => {
    if (detectedPairs.length === 0) {
      toast({
        title: "Error",
        description: "Please parse log text first to extract seed/key pairs",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    try {
      const result = await detectAlgorithmMutation.mutateAsync({
        pairs: detectedPairs,
        minConfidence,
      });

      if (!result.success) {
        toast({
          title: "Error",
          description: result.message,
          variant: "destructive",
        });
        return;
      }

      setMatches(result.matches);
      
      if (result.matches.length === 0) {
        toast({
          title: "No Matches",
          description: `No algorithms found with confidence >= ${minConfidence}%`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Detection Complete",
          description: `Found ${result.matches.length} matching algorithm(s)`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to detect algorithm",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please upload a file smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    // Check file type
    const validTypes = ['.txt', '.log', '.csv'];
    const fileExt = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (!validTypes.includes(fileExt)) {
      toast({
        title: "Invalid File Type",
        description: "Please upload a .txt, .log, or .csv file",
        variant: "destructive",
      });
      return;
    }

    try {
      const text = await file.text();
      setLogText(text);
      setUploadedFile(file);
      toast({
        title: "File Uploaded",
        description: `${file.name} (${(file.size / 1024).toFixed(1)} KB) loaded successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to read file",
        variant: "destructive",
      });
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleClearFile = () => {
    setUploadedFile(null);
    setLogText("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleLoadExample = () => {
    const exampleLog = `[2024-01-15 10:23:45] TX: 27 01
[2024-01-15 10:23:45] RX: 67 01 12 34 56 78
[2024-01-15 10:23:46] TX: 27 02 AB CD EF 01
[2024-01-15 10:23:46] RX: 67 02
[2024-01-15 10:24:12] TX: 27 01
[2024-01-15 10:24:12] RX: 67 01 98 76 54 32
[2024-01-15 10:24:13] TX: 27 02 FE DC BA 98
[2024-01-15 10:24:13] RX: 67 02`;
    
    setLogText(exampleLog);
    setUploadedFile(null);
    toast({
      title: "Example Loaded",
      description: "Sample diagnostic log loaded",
    });
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence === 100) return "bg-green-500";
    if (confidence >= 90) return "bg-green-400";
    if (confidence >= 80) return "bg-yellow-400";
    return "bg-orange-400";
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Algorithm Auto-Detection</h1>
        <p className="text-muted-foreground">
          Analyze seed/key pairs from diagnostic logs to automatically identify the correct algorithm
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Log Input
              </CardTitle>
              <CardDescription>
                Paste diagnostic log containing seed/key exchanges
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* File Upload Zone */}
              <div
                className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                  isDragging
                    ? "border-primary bg-primary/5"
                    : "border-gray-300 dark:border-gray-700"
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.log,.csv"
                  onChange={handleFileInputChange}
                  className="hidden"
                />
                {uploadedFile ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="h-5 w-5 text-green-500" />
                      <div className="text-left">
                        <p className="text-sm font-medium">{uploadedFile.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(uploadedFile.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearFile}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div>
                    <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm font-medium mb-1">
                      Drag and drop log file here
                    </p>
                    <p className="text-xs text-muted-foreground mb-3">
                      or click to browse (.txt, .log, .csv)
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Choose File
                    </Button>
                  </div>
                )}
              </div>

              {/* Log Text Input */}
              <div className="space-y-2">
                <Label>Diagnostic Log</Label>
                <Textarea
                  placeholder="Paste log text here or upload a file above..."
                  value={logText}
                  onChange={(e) => setLogText(e.target.value)}
                  className="font-mono text-sm h-64"
                />
                <p className="text-xs text-muted-foreground">
                  Supported formats: UDS traces (27 01/67 01), plain text (Seed: 0x..., Key: 0x...)
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button onClick={handleParseLog} className="flex-1">
                  <Search className="h-4 w-4 mr-2" />
                  Parse Log
                </Button>
                <Button onClick={handleLoadExample} variant="outline">
                  <FileText className="h-4 w-4 mr-2" />
                  Load Example
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Detected Pairs */}
          {detectedPairs.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Extracted Pairs ({detectedPairs.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {detectedPairs.map((pair, index) => (
                    <div
                      key={index}
                      className="p-3 bg-gray-50 dark:bg-gray-900 rounded border text-sm font-mono"
                    >
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Seed:</span>
                        <span>0x{pair.seed.toUpperCase()}</span>
                      </div>
                      <div className="flex justify-between mt-1">
                        <span className="text-muted-foreground">Key:</span>
                        <span>0x{pair.key.toUpperCase()}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Detection Settings */}
                <div className="mt-4 space-y-2">
                  <Label>Minimum Confidence (%)</Label>
                  <div className="flex gap-2">
                    <input
                      type="range"
                      min="50"
                      max="100"
                      step="5"
                      value={minConfidence}
                      onChange={(e) => setMinConfidence(parseInt(e.target.value))}
                      className="flex-1"
                    />
                    <span className="text-sm font-medium w-12 text-right">{minConfidence}%</span>
                  </div>
                </div>

                <Button
                  onClick={handleDetectAlgorithm}
                  className="w-full mt-4"
                  disabled={isAnalyzing}
                >
                  {isAnalyzing ? (
                    <>Analyzing 372 algorithms...</>
                  ) : (
                    <>
                      <Search className="h-4 w-4 mr-2" />
                      Detect Algorithm
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {/* Info Card */}
          <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Info className="h-5 w-5" />
                How It Works
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p>
                1. <strong>Parse Log:</strong> Extract seed/key pairs from diagnostic traces
              </p>
              <p>
                2. <strong>Test Algorithms:</strong> Try all 372 AlphaOBD algorithms against your pairs
              </p>
              <p>
                3. <strong>Rank Results:</strong> Algorithms are ranked by confidence (% of matching pairs)
              </p>
              <p className="text-muted-foreground mt-4">
                <strong>Tip:</strong> More seed/key pairs = higher accuracy. Capture at least 3-5 pairs for reliable detection.
              </p>
            </CardContent>
          </Card>

          {/* Results */}
          {matches.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Matching Algorithms ({matches.length})
                </CardTitle>
                <CardDescription>
                  Sorted by confidence (highest first)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {matches.map((match, index) => (
                    <div
                      key={index}
                      className="p-4 bg-white dark:bg-gray-900 rounded-lg border"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="font-mono">
                            {match.algorithm}
                          </Badge>
                          {index === 0 && match.confidence === 100 && (
                            <Badge className="bg-green-500">Best Match</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">
                            {match.matches}/{match.total} pairs
                          </span>
                        </div>
                      </div>

                      {/* Confidence Bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Confidence</span>
                          <span className="font-medium">{match.confidence.toFixed(1)}%</span>
                        </div>
                        <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${getConfidenceColor(match.confidence)} transition-all`}
                            style={{ width: `${match.confidence}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Export Button */}
                {matches.length > 0 && (
                  <Button
                    variant="outline"
                    className="w-full mt-4"
                    onClick={() => {
                      const csv = [
                        "Algorithm,Confidence,Matches,Total",
                        ...matches.map(m => `${m.algorithm},${m.confidence},${m.matches},${m.total}`)
                      ].join("\n");
                      
                      const blob = new Blob([csv], { type: "text/csv" });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = "algorithm-detection-results.csv";
                      a.click();
                      URL.revokeObjectURL(url);
                      
                      toast({
                        title: "Exported",
                        description: "Results exported to CSV",
                      });
                    }}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Export Results (CSV)
                  </Button>
                )}
              </CardContent>
            </Card>
          )}

          {/* No Results Message */}
          {detectedPairs.length > 0 && matches.length === 0 && !isAnalyzing && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                No algorithms found with confidence {'>'}= {minConfidence}%. Try lowering the confidence threshold or capturing more seed/key pairs.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>
    </div>
  );
}
