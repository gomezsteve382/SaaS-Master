/**
 * AI Diagnostic Assistant
 * Powered by Z.AI GLM-4.7 for intelligent vehicle diagnostics
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Bot, 
  Send, 
  Loader2, 
  AlertCircle, 
  Image as ImageIcon,
  FileText,
  Search,
  Sparkles
} from "lucide-react";
import Streamdown from "streamdown";

interface Message {
  role: "user" | "assistant";
  content: string;
  reasoning?: string;
}

export default function AIDiagnostic() {
  const [activeTab, setActiveTab] = useState("chat");
  
  // Chat state
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [vehicleContext, setVehicleContext] = useState({
    vin: "",
    make: "",
    model: "",
    year: "",
    mileage: "",
    dtcs: "",
  });

  // DTC Explanation state
  const [dtcCode, setDtcCode] = useState("");
  const [dtcVehicleInfo, setDtcVehicleInfo] = useState({
    make: "",
    model: "",
    year: "",
    vin: "",
  });

  // Photo Analysis state
  const [photoUrl, setPhotoUrl] = useState("");
  const [photoQuestion, setPhotoQuestion] = useState("");

  // Repair Procedure state
  const [repairIssue, setRepairIssue] = useState("");
  const [repairVehicleInfo, setRepairVehicleInfo] = useState({
    make: "",
    model: "",
    year: "",
    vin: "",
  });

  // TSB Search state
  const [tsbVehicleInfo, setTsbVehicleInfo] = useState({
    make: "",
    model: "",
    year: "",
    vin: "",
  });
  const [tsbIssue, setTsbIssue] = useState("");

  // Mutations
  const chatMutation = trpc.zaiDiagnostic.chat.useMutation();
  const explainDTCMutation = trpc.zaiDiagnostic.explainDTC.useMutation();
  const analyzePhotoMutation = trpc.zaiDiagnostic.analyzePhoto.useMutation();
  const generateProcedureMutation = trpc.zaiDiagnostic.generateRepairProcedure.useMutation();
  const searchTSBsMutation = trpc.zaiDiagnostic.searchTSBs.useMutation();

  // Chat handlers
  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      role: "user",
      content: inputMessage,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");

    try {
      const context = {
        vin: vehicleContext.vin || undefined,
        make: vehicleContext.make || undefined,
        model: vehicleContext.model || undefined,
        year: vehicleContext.year ? parseInt(vehicleContext.year) : undefined,
        mileage: vehicleContext.mileage ? parseInt(vehicleContext.mileage) : undefined,
        dtcs: vehicleContext.dtcs ? vehicleContext.dtcs.split(",").map(d => d.trim()) : undefined,
      };

      const result = await chatMutation.mutateAsync({
        messages: messages.map((m) => ({
          role: m.role,
          content: m.content,
        })).concat([{ role: "user", content: inputMessage }]),
        vehicleContext: context,
      });

      const assistantMessage: Message = {
        role: "assistant",
        content: result.response,
        reasoning: result.reasoning,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: "assistant",
        content: `Error: ${error instanceof Error ? error.message : "Failed to get response"}`,
      };
      setMessages((prev) => [...prev, errorMessage]);
    }
  };

  // DTC Explanation handler
  const handleExplainDTC = async () => {
    if (!dtcCode.trim()) return;

    try {
      const vehicleInfo = {
        make: dtcVehicleInfo.make || undefined,
        model: dtcVehicleInfo.model || undefined,
        year: dtcVehicleInfo.year ? parseInt(dtcVehicleInfo.year) : undefined,
        vin: dtcVehicleInfo.vin || undefined,
      };

      await explainDTCMutation.mutateAsync({
        dtc: dtcCode.toUpperCase(),
        vehicleInfo,
      });
    } catch (error) {
      console.error("Failed to explain DTC:", error);
    }
  };

  // Photo Analysis handler
  const handleAnalyzePhoto = async () => {
    if (!photoUrl.trim()) return;

    try {
      await analyzePhotoMutation.mutateAsync({
        imageUrl: photoUrl,
        question: photoQuestion || undefined,
      });
    } catch (error) {
      console.error("Failed to analyze photo:", error);
    }
  };

  // Repair Procedure handler
  const handleGenerateProcedure = async () => {
    if (!repairIssue.trim() || !repairVehicleInfo.make || !repairVehicleInfo.model || !repairVehicleInfo.year) {
      return;
    }

    try {
      await generateProcedureMutation.mutateAsync({
        issue: repairIssue,
        vehicleInfo: {
          make: repairVehicleInfo.make,
          model: repairVehicleInfo.model,
          year: parseInt(repairVehicleInfo.year),
          vin: repairVehicleInfo.vin || undefined,
        },
      });
    } catch (error) {
      console.error("Failed to generate procedure:", error);
    }
  };

  // TSB Search handler
  const handleSearchTSBs = async () => {
    if (!tsbVehicleInfo.make || !tsbVehicleInfo.model || !tsbVehicleInfo.year) {
      return;
    }

    try {
      await searchTSBsMutation.mutateAsync({
        vehicleInfo: {
          make: tsbVehicleInfo.make,
          model: tsbVehicleInfo.model,
          year: parseInt(tsbVehicleInfo.year),
          vin: tsbVehicleInfo.vin || undefined,
        },
        issue: tsbIssue || undefined,
      });
    } catch (error) {
      console.error("Failed to search TSBs:", error);
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">AI Diagnostic Assistant</h1>
          <p className="text-muted-foreground">Powered by Z.AI GLM-4.7 for intelligent vehicle diagnostics</p>
        </div>
      </div>

      <Alert>
        <Bot className="h-4 w-4" />
        <AlertDescription>
          This AI assistant can explain DTCs, analyze photos, generate repair procedures, search TSBs, and provide diagnostic guidance.
        </AlertDescription>
      </Alert>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="chat">
            <Bot className="w-4 h-4 mr-2" />
            Chat
          </TabsTrigger>
          <TabsTrigger value="dtc">
            <AlertCircle className="w-4 h-4 mr-2" />
            DTC Lookup
          </TabsTrigger>
          <TabsTrigger value="photo">
            <ImageIcon className="w-4 h-4 mr-2" />
            Photo Analysis
          </TabsTrigger>
          <TabsTrigger value="procedure">
            <FileText className="w-4 h-4 mr-2" />
            Repair Procedure
          </TabsTrigger>
          <TabsTrigger value="tsb">
            <Search className="w-4 h-4 mr-2" />
            TSB Search
          </TabsTrigger>
        </TabsList>

        {/* Chat Tab */}
        <TabsContent value="chat" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Diagnostic Chat</CardTitle>
              <CardDescription>
                Have a conversation with the AI assistant about vehicle diagnostics
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Vehicle Context */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4 bg-muted rounded-lg">
                <div>
                  <Label htmlFor="chat-vin" className="text-xs">VIN</Label>
                  <Input
                    id="chat-vin"
                    placeholder="VIN"
                    value={vehicleContext.vin}
                    onChange={(e) => setVehicleContext({ ...vehicleContext, vin: e.target.value })}
                    className="h-8"
                  />
                </div>
                <div>
                  <Label htmlFor="chat-make" className="text-xs">Make</Label>
                  <Input
                    id="chat-make"
                    placeholder="Make"
                    value={vehicleContext.make}
                    onChange={(e) => setVehicleContext({ ...vehicleContext, make: e.target.value })}
                    className="h-8"
                  />
                </div>
                <div>
                  <Label htmlFor="chat-model" className="text-xs">Model</Label>
                  <Input
                    id="chat-model"
                    placeholder="Model"
                    value={vehicleContext.model}
                    onChange={(e) => setVehicleContext({ ...vehicleContext, model: e.target.value })}
                    className="h-8"
                  />
                </div>
                <div>
                  <Label htmlFor="chat-year" className="text-xs">Year</Label>
                  <Input
                    id="chat-year"
                    type="number"
                    placeholder="Year"
                    value={vehicleContext.year}
                    onChange={(e) => setVehicleContext({ ...vehicleContext, year: e.target.value })}
                    className="h-8"
                  />
                </div>
                <div>
                  <Label htmlFor="chat-mileage" className="text-xs">Mileage</Label>
                  <Input
                    id="chat-mileage"
                    type="number"
                    placeholder="Mileage"
                    value={vehicleContext.mileage}
                    onChange={(e) => setVehicleContext({ ...vehicleContext, mileage: e.target.value })}
                    className="h-8"
                  />
                </div>
                <div>
                  <Label htmlFor="chat-dtcs" className="text-xs">DTCs (comma-separated)</Label>
                  <Input
                    id="chat-dtcs"
                    placeholder="P0420, P0171"
                    value={vehicleContext.dtcs}
                    onChange={(e) => setVehicleContext({ ...vehicleContext, dtcs: e.target.value })}
                    className="h-8"
                  />
                </div>
              </div>

              {/* Chat Messages */}
              <div className="space-y-4 min-h-[400px] max-h-[600px] overflow-y-auto p-4 border rounded-lg">
                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-[400px] text-center text-muted-foreground">
                    <Bot className="w-16 h-16 mb-4 opacity-20" />
                    <p className="text-lg font-medium">Start a conversation</p>
                    <p className="text-sm">Ask about DTCs, symptoms, diagnostic procedures, or repairs</p>
                  </div>
                )}

                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <div className="flex items-start gap-2 mb-2">
                        {message.role === "assistant" && <Bot className="w-5 h-5 mt-0.5" />}
                        <Badge variant={message.role === "user" ? "secondary" : "default"}>
                          {message.role === "user" ? "You" : "AI Assistant"}
                        </Badge>
                      </div>
                      <div className="prose prose-sm dark:prose-invert max-w-none">
                        <Streamdown>{message.content}</Streamdown>
                      </div>
                      {message.reasoning && (
                        <details className="mt-3 text-xs opacity-70">
                          <summary className="cursor-pointer font-medium">Show reasoning</summary>
                          <div className="mt-2 p-2 bg-background/50 rounded">
                            {message.reasoning}
                          </div>
                        </details>
                      )}
                    </div>
                  </div>
                ))}

                {chatMutation.isPending && (
                  <div className="flex justify-start">
                    <div className="bg-muted rounded-lg p-4">
                      <Loader2 className="w-5 h-5 animate-spin" />
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <div className="flex gap-2">
                <Input
                  placeholder="Ask about diagnostics, DTCs, symptoms, or repairs..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  disabled={chatMutation.isPending}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || chatMutation.isPending}
                >
                  {chatMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* DTC Lookup Tab */}
        <TabsContent value="dtc" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>DTC Explanation</CardTitle>
              <CardDescription>
                Get detailed explanations of diagnostic trouble codes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dtc-code">DTC Code *</Label>
                  <Input
                    id="dtc-code"
                    placeholder="P0420"
                    value={dtcCode}
                    onChange={(e) => setDtcCode(e.target.value.toUpperCase())}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dtc-vin">VIN (Optional)</Label>
                  <Input
                    id="dtc-vin"
                    placeholder="VIN"
                    value={dtcVehicleInfo.vin}
                    onChange={(e) => setDtcVehicleInfo({ ...dtcVehicleInfo, vin: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dtc-make">Make (Optional)</Label>
                  <Input
                    id="dtc-make"
                    placeholder="Dodge"
                    value={dtcVehicleInfo.make}
                    onChange={(e) => setDtcVehicleInfo({ ...dtcVehicleInfo, make: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dtc-model">Model (Optional)</Label>
                  <Input
                    id="dtc-model"
                    placeholder="Charger"
                    value={dtcVehicleInfo.model}
                    onChange={(e) => setDtcVehicleInfo({ ...dtcVehicleInfo, model: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dtc-year">Year (Optional)</Label>
                  <Input
                    id="dtc-year"
                    type="number"
                    placeholder="2016"
                    value={dtcVehicleInfo.year}
                    onChange={(e) => setDtcVehicleInfo({ ...dtcVehicleInfo, year: e.target.value })}
                  />
                </div>
              </div>

              <Button
                onClick={handleExplainDTC}
                disabled={!dtcCode.trim() || explainDTCMutation.isPending}
                className="w-full"
              >
                {explainDTCMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Explain DTC
                  </>
                )}
              </Button>

              {explainDTCMutation.data && (
                <div className="mt-4 p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="outline" className="font-mono">
                      {explainDTCMutation.data.dtc}
                    </Badge>
                  </div>
                  <Separator className="my-3" />
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <Streamdown>{explainDTCMutation.data.explanation}</Streamdown>
                  </div>
                </div>
              )}

              {explainDTCMutation.isError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {explainDTCMutation.error instanceof Error
                      ? explainDTCMutation.error.message
                      : "Failed to explain DTC"}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Photo Analysis Tab */}
        <TabsContent value="photo" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Photo Analysis</CardTitle>
              <CardDescription>
                Analyze vehicle photos for damage, wear, or issues
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="photo-url">Image URL *</Label>
                <Input
                  id="photo-url"
                  type="url"
                  placeholder="https://example.com/vehicle-photo.jpg"
                  value={photoUrl}
                  onChange={(e) => setPhotoUrl(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="photo-question">Specific Question (Optional)</Label>
                <Textarea
                  id="photo-question"
                  placeholder="What issues do you see in this engine bay?"
                  value={photoQuestion}
                  onChange={(e) => setPhotoQuestion(e.target.value)}
                  rows={3}
                />
              </div>

              <Button
                onClick={handleAnalyzePhoto}
                disabled={!photoUrl.trim() || analyzePhotoMutation.isPending}
                className="w-full"
              >
                {analyzePhotoMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Analyze Photo
                  </>
                )}
              </Button>

              {analyzePhotoMutation.data && (
                <div className="mt-4 space-y-4">
                  {photoUrl && (
                    <img
                      src={photoUrl}
                      alt="Vehicle"
                      className="w-full rounded-lg border"
                    />
                  )}
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-3">Analysis Results</h3>
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <Streamdown>{analyzePhotoMutation.data.analysis}</Streamdown>
                    </div>
                  </div>
                </div>
              )}

              {analyzePhotoMutation.isError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {analyzePhotoMutation.error instanceof Error
                      ? analyzePhotoMutation.error.message
                      : "Failed to analyze photo"}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Repair Procedure Tab */}
        <TabsContent value="procedure" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Generate Repair Procedure</CardTitle>
              <CardDescription>
                Create detailed repair procedures for specific issues
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="repair-issue">Issue/Repair Description *</Label>
                <Textarea
                  id="repair-issue"
                  placeholder="Replace catalytic converter"
                  value={repairIssue}
                  onChange={(e) => setRepairIssue(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="repair-make">Make *</Label>
                  <Input
                    id="repair-make"
                    placeholder="Dodge"
                    value={repairVehicleInfo.make}
                    onChange={(e) => setRepairVehicleInfo({ ...repairVehicleInfo, make: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="repair-model">Model *</Label>
                  <Input
                    id="repair-model"
                    placeholder="Charger"
                    value={repairVehicleInfo.model}
                    onChange={(e) => setRepairVehicleInfo({ ...repairVehicleInfo, model: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="repair-year">Year *</Label>
                  <Input
                    id="repair-year"
                    type="number"
                    placeholder="2016"
                    value={repairVehicleInfo.year}
                    onChange={(e) => setRepairVehicleInfo({ ...repairVehicleInfo, year: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="repair-vin">VIN (Optional)</Label>
                  <Input
                    id="repair-vin"
                    placeholder="VIN"
                    value={repairVehicleInfo.vin}
                    onChange={(e) => setRepairVehicleInfo({ ...repairVehicleInfo, vin: e.target.value })}
                  />
                </div>
              </div>

              <Button
                onClick={handleGenerateProcedure}
                disabled={
                  !repairIssue.trim() ||
                  !repairVehicleInfo.make ||
                  !repairVehicleInfo.model ||
                  !repairVehicleInfo.year ||
                  generateProcedureMutation.isPending
                }
                className="w-full"
              >
                {generateProcedureMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Procedure
                  </>
                )}
              </Button>

              {generateProcedureMutation.data && (
                <div className="mt-4 p-4 border rounded-lg">
                  <h3 className="font-semibold mb-3">Repair Procedure</h3>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <Streamdown>{generateProcedureMutation.data.procedure}</Streamdown>
                  </div>
                </div>
              )}

              {generateProcedureMutation.isError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {generateProcedureMutation.error instanceof Error
                      ? generateProcedureMutation.error.message
                      : "Failed to generate procedure"}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TSB Search Tab */}
        <TabsContent value="tsb" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>TSB & Recall Search</CardTitle>
              <CardDescription>
                Search for Technical Service Bulletins and recalls
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tsb-make">Make *</Label>
                  <Input
                    id="tsb-make"
                    placeholder="Dodge"
                    value={tsbVehicleInfo.make}
                    onChange={(e) => setTsbVehicleInfo({ ...tsbVehicleInfo, make: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tsb-model">Model *</Label>
                  <Input
                    id="tsb-model"
                    placeholder="Charger"
                    value={tsbVehicleInfo.model}
                    onChange={(e) => setTsbVehicleInfo({ ...tsbVehicleInfo, model: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tsb-year">Year *</Label>
                  <Input
                    id="tsb-year"
                    type="number"
                    placeholder="2016"
                    value={tsbVehicleInfo.year}
                    onChange={(e) => setTsbVehicleInfo({ ...tsbVehicleInfo, year: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tsb-vin">VIN (Optional)</Label>
                  <Input
                    id="tsb-vin"
                    placeholder="VIN"
                    value={tsbVehicleInfo.vin}
                    onChange={(e) => setTsbVehicleInfo({ ...tsbVehicleInfo, vin: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tsb-issue">Specific Issue (Optional)</Label>
                <Textarea
                  id="tsb-issue"
                  placeholder="Transmission shift issues"
                  value={tsbIssue}
                  onChange={(e) => setTsbIssue(e.target.value)}
                  rows={3}
                />
              </div>

              <Button
                onClick={handleSearchTSBs}
                disabled={
                  !tsbVehicleInfo.make ||
                  !tsbVehicleInfo.model ||
                  !tsbVehicleInfo.year ||
                  searchTSBsMutation.isPending
                }
                className="w-full"
              >
                {searchTSBsMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Search TSBs & Recalls
                  </>
                )}
              </Button>

              {searchTSBsMutation.data && (
                <div className="mt-4 p-4 border rounded-lg">
                  <h3 className="font-semibold mb-3">Search Results</h3>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <Streamdown>{searchTSBsMutation.data.results}</Streamdown>
                  </div>
                </div>
              )}

              {searchTSBsMutation.isError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {searchTSBsMutation.error instanceof Error
                      ? searchTSBsMutation.error.message
                      : "Failed to search TSBs"}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
