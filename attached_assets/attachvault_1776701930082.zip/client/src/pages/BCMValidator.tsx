import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, XCircle, Upload, Loader2, FileCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BCMValidator() {
  const [file, setFile] = useState<File | null>(null);
  const [validationResult, setValidationResult] = useState<any>(null);
  const [isValidating, setIsValidating] = useState(false);
  const { toast } = useToast();

  const validateMutation = trpc.bcmValidator.validateFile.useMutation({
    onSuccess: (data) => {
      setValidationResult(data);
      setIsValidating(false);
      toast({
        title: data.isValid ? "✅ Valid BCM File" : "❌ Invalid BCM File",
        description: data.message,
        variant: data.isValid ? "default" : "destructive",
      });
    },
    onError: (error) => {
      setIsValidating(false);
      toast({
        title: "Validation Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setValidationResult(null);
    }
  };

  const handleValidate = async () => {
    if (!file) {
      toast({
        title: "No File Selected",
        description: "Please select a BCM file to validate",
        variant: "destructive",
      });
      return;
    }

    setIsValidating(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
      const arrayBuffer = e.target?.result as ArrayBuffer;
      const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));

      validateMutation.mutate({
        fileData: base64,
        filename: file.name,
      });
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">BCM File Validator</h1>
        <p className="text-muted-foreground">
          Validate BCM EEPROM dumps for VIN integrity, checksum correctness, and PIN extraction
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload BCM File</CardTitle>
          <CardDescription>
            Select a BCM EEPROM dump file (.bin) to validate
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="bcm-file">BCM File</Label>
            <div className="flex gap-2">
              <Input
                id="bcm-file"
                type="file"
                accept=".bin"
                onChange={handleFileChange}
                disabled={isValidating}
              />
              <Button
                onClick={handleValidate}
                disabled={!file || isValidating}
                className="min-w-[120px]"
              >
                {isValidating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Validating...
                  </>
                ) : (
                  <>
                    <FileCheck className="mr-2 h-4 w-4" />
                    Validate
                  </>
                )}
              </Button>
            </div>
          </div>

          {file && (
            <div className="text-sm text-muted-foreground">
              Selected: {file.name} ({(file.size / 1024).toFixed(2)} KB)
            </div>
          )}
        </CardContent>
      </Card>

      {validationResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {validationResult.isValid ? (
                <>
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                  Validation Passed
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-500" />
                  Validation Failed
                </>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant={validationResult.isValid ? "default" : "destructive"}>
              <AlertDescription>{validationResult.message}</AlertDescription>
            </Alert>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold mb-2">VIN Information</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">VIN Found:</span>
                    <span className="font-mono">
                      {validationResult.vinFound ? (
                        <span className="text-green-600">✓ Yes</span>
                      ) : (
                        <span className="text-red-600">✗ No</span>
                      )}
                    </span>
                  </div>
                  {validationResult.vinFound && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">VIN:</span>
                        <span className="font-mono font-bold">{validationResult.vin}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Location:</span>
                        <span className="font-mono">
                          0x{validationResult.vinLocation.toString(16).toUpperCase()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Type:</span>
                        <span>{validationResult.vinType}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Checksum Information</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Checksum Valid:</span>
                    <span className="font-mono">
                      {validationResult.checksumValid ? (
                        <span className="text-green-600">✓ Valid</span>
                      ) : (
                        <span className="text-red-600">✗ Invalid</span>
                      )}
                    </span>
                  </div>
                  {validationResult.checksumType !== "Unknown" && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Type:</span>
                        <span className="font-mono">{validationResult.checksumType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Location:</span>
                        <span className="font-mono">
                          0x{validationResult.checksumLocation.toString(16).toUpperCase()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Original:</span>
                        <span className="font-mono">{validationResult.originalChecksum}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Calculated:</span>
                        <span className="font-mono">{validationResult.calculatedChecksum}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">PIN Information</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">PIN Found:</span>
                    <span className="font-mono">
                      {validationResult.pinFound ? (
                        <span className="text-green-600">✓ Yes</span>
                      ) : (
                        <span className="text-red-600">✗ No</span>
                      )}
                    </span>
                  </div>
                  {validationResult.pinFound && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">PIN:</span>
                        <span className="font-mono font-bold">{validationResult.pin}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Location:</span>
                        <span className="font-mono">
                          0x{validationResult.pinLocation.toString(16).toUpperCase()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Type:</span>
                        <span>{validationResult.pinType}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">File Information</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Filename:</span>
                    <span className="font-mono">{validationResult.filename}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Size:</span>
                    <span className="font-mono">
                      {(validationResult.fileSize / 1024).toFixed(2)} KB
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
