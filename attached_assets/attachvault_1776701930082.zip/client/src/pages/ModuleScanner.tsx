import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2, Scan, CheckCircle2, XCircle, Download, AlertTriangle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FirmwareBrowser } from "@/components/FirmwareBrowser";
import { useToast } from "@/hooks/use-toast";
import { BackButton } from "@/components/BackButton";
import { ConnectionManager, type DiscoveredModule, parseVINBytes } from "@/lib/obd2-protocol";
import { TopographicalModuleView } from "@/components/TopographicalModuleView";
import { VINCorrectionWizard } from "@/components/VINCorrectionWizard";
import { BatchVINProgramming } from "@/components/BatchVINProgramming";
import { trpc } from "@/lib/trpc";
import { getModuleName } from "@/../../shared/module-names";
import { ALPHAOBD_MODULES, getQuickScanAddresses } from "@/../../shared/alphaobd-can-addresses";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { getDemoVehicle } from "@shared/demo-vehicles";
import { DemoModeBanner } from "@/components/DemoModeBanner";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Helper to determine security algorithm for a module
function getModuleAlgorithm(module: DiscoveredModule): { name: string; color: string; tooltip: string } | null {
  const canId = module.code.toLowerCase();
  
  // RFHUB modules use Shift-XOR
  if (canId === '0x742' || canId === '0x762' || canId === '0x75f') {
    const isBlank = module.vin === '00000000000000000' || !module.vin || module.vin.match(/^0+$/);
    return {
      name: 'Shift-XOR',
      color: 'bg-blue-500',
      tooltip: isBlank ? 'Shift-XOR (constant=0, blank RFHUB)' : 'Shift-XOR (VIN-derived polynomial)'
    };
  }
  
  // SKIM/WCM modules use SKIM algorithm
  if (canId === '0x767') {
    return {
      name: 'SKIM',
      color: 'bg-purple-500',
      tooltip: 'SKIM algorithm (ROL13 * 0x4D ^ 0x6B8A9C2E)'
    };
  }
  
  // Atlantis modules (dealer-level)
  if (canId === '0x7e0' || canId === '0x7e8') {
    return {
      name: 'Atlantis',
      color: 'bg-red-500',
      tooltip: 'Atlantis (advanced dealer-level access)'
    };
  }
  
  // Most other modules use ROL5+XOR
  const rol5Modules = ['0x7a0', '0x7a8', '0x7b0', '0x7b8', '0x7c0', '0x7c8', '0x7d0', '0x7d8'];
  if (rol5Modules.includes(canId)) {
    return {
      name: 'ROL5+XOR',
      color: 'bg-green-500',
      tooltip: 'ROL5+XOR (standard FCA algorithm)'
    };
  }
  
  return null;
}

export default function ModuleScanner() {
  const { toast } = useToast();
  const { isDemoMode, currentVehicle } = useDemoMode();
  const [connectionManager] = useState(() => new ConnectionManager());
  const [scanning, setScanning] = useState(false);
  const [modules, setModules] = useState<DiscoveredModule[]>([]);
  const [totalScanned, setTotalScanned] = useState(0);
  const [currentScanAddress, setCurrentScanAddress] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState<{ current: number; total: number; range: string } | null>(null);
  const [connected, setConnected] = useState(false);
  const [bcmReading, setBcmReading] = useState(false);
  const [bcmVin, setBcmVin] = useState<string | null>(null);
  const [retryLog, setRetryLog] = useState<string[]>([]);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{success: boolean; message: string; responseTime: number} | null>(null);
  const [primaryVIN, setPrimaryVIN] = useState<string | null>(null);
  const [vinMismatches, setVinMismatches] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"table" | "topographical">("table");
  const [correctionModule, setCorrectionModule] = useState<DiscoveredModule | null>(null);
  const [showBatchProgramming, setShowBatchProgramming] = useState(false);
  const [dtcModule, setDtcModule] = useState<DiscoveredModule | null>(null);
  const [dtcResults, setDtcResults] = useState<string[]>([]);
  const [partNumberModule, setPartNumberModule] = useState<DiscoveredModule | null>(null);
  const [partNumber, setPartNumber] = useState<string | null>(null);
  const [softwareModule, setSoftwareModule] = useState<DiscoveredModule | null>(null);
  const [softwareVersion, setSoftwareVersion] = useState<string | null>(null);
  
  const saveScanMutation = trpc.moduleScanHistory.saveScan.useMutation();

  const handleConnect = async () => {
    if (!('serial' in navigator)) {
      toast({
        title: "Web Serial Not Supported",
        description: "Please use Chrome, Edge, or Opera browser",
        variant: "destructive",
      });
      return;
    }

    try {
      const port = await (navigator.serial as any).requestPort();
      const success = await connectionManager.connect('elm327', port);

      if (success) {
        setConnected(true);
        toast({
          title: "✅ Connected",
          description: "OBDLink adapter ready for scanning",
        });
      } else {
        throw new Error("Connection failed");
      }
    } catch (error: any) {
      toast({
        title: "Connection Failed",
        description: error.message || "Could not connect to OBDLink",
        variant: "destructive",
      });
    }
  };

  const handleTestCommunication = async () => {
    if (!connected) {
      toast({title: "Not Connected", description: "Please connect to OBDLink first", variant: "destructive"});
      return;
    }

    setTesting(true);
    setTestResult(null);

    try {
      const protocol = connectionManager.getProtocol();
      if (!protocol || !('testCommunication' in protocol)) {
        throw new Error("Protocol does not support testing");
      }

      const result = await (protocol as any).testCommunication();
      setTestResult(result);

      toast({
        title: result.success ? "✅ Communication Test Passed" : "❌ Communication Test Failed",
        description: `${result.message} (${result.responseTime}ms)`,
        variant: result.success ? "default" : "destructive",
      });
    } catch (error: any) {
      toast({title: "Test Failed", description: error.message || "Could not test communication", variant: "destructive"});
    } finally {
      setTesting(false);
    }
  };

  const handleDemoQuickScan = async () => {
    // Note: scanning state is already set to true by caller
    setModules([]);
    setTotalScanned(0);

    const vehicle = getDemoVehicle(currentVehicle);
    if (!vehicle) {
      toast({ title: "Error", description: "Demo vehicle not found", variant: "destructive" });
      setScanning(false);
      return;
    }

    toast({
      title: "🎭 Demo Mode - Quick Scan",
      description: `Simulating module discovery for ${vehicle.name}...`,
    });

    // Convert demo modules to DiscoveredModule format (first 6 modules for quick scan)
    const demoModules: DiscoveredModule[] = vehicle.modules.slice(0, 6).map(m => ({
      name: m.name,
      code: m.canId,
      txId: parseInt(m.canId, 16),
      rxId: parseInt(m.canId, 16) + 8, // Simplified RX ID calculation
      vin: m.vin,
      vinOffset: null,
      status: 'vin_read' as const,
      lastResponse: new Uint8Array([0x62, 0xF1, 0x90])
    }));

    // Simulate realistic scan timing
    for (let i = 0; i < demoModules.length; i++) {
      setTotalScanned(i + 1);
      await new Promise(resolve => setTimeout(resolve, 300)); // 300ms per module
      setModules(prev => [...prev, demoModules[i]]);
    }

    setScanning(false);
    toast({
      title: "Demo Scan Complete",
      description: `Found ${demoModules.length} simulated module(s)`,
    });
  };

  const handleDemoFullScan = async () => {
    // Note: scanning state is already set to true by caller
    setModules([]);
    setTotalScanned(0);

    const vehicle = getDemoVehicle(currentVehicle);
    if (!vehicle) {
      toast({ title: "Error", description: "Demo vehicle not found", variant: "destructive" });
      setScanning(false);
      return;
    }

    toast({
      title: "🎭 Demo Mode - Full Scan",
      description: `Simulating full CAN bus scan for ${vehicle.name}...`,
    });

    // Convert ALL demo modules to DiscoveredModule format
    const demoModules: DiscoveredModule[] = vehicle.modules.map(m => ({
      name: m.name,
      code: m.canId,
      txId: parseInt(m.canId, 16),
      rxId: parseInt(m.canId, 16) + 8,
      vin: m.vin,
      vinOffset: null,
      status: 'vin_read' as const,
      lastResponse: new Uint8Array([0x62, 0xF1, 0x90])
    }));

    // Simulate scanning 512 addresses with progress updates
    const totalAddresses = 512;
    for (let i = 0; i < totalAddresses; i++) {
      setTotalScanned(i + 1);
      
      // Add modules at appropriate points
      if (i === 50) setModules([demoModules[0]]);
      if (i === 100) setModules(prev => [...prev, demoModules[1]]);
      if (i === 150) setModules(prev => [...prev, demoModules[2]]);
      if (i === 200) setModules(prev => [...prev, demoModules[3]]);
      if (i === 250) setModules(prev => [...prev, demoModules[4]]);
      if (i === 300) setModules(prev => [...prev, demoModules[5]]);
      if (i === 350) setModules(prev => [...prev, demoModules[6]]);
      if (i === 400) setModules(prev => [...prev, demoModules[7]]);
      
      // Fast simulation (10ms per address = ~5 seconds total)
      await new Promise(resolve => setTimeout(resolve, 10));
    }

    setScanning(false);
    toast({
      title: "Demo Scan Complete",
      description: `Found ${demoModules.length} simulated module(s) in ${totalAddresses} addresses`,
    });
  };

  const handleQuickScan = async () => {
    // CRITICAL: Prevent concurrent scans - only one scan can run at a time
    if (scanning) {
      toast({
        title: "⚠️ Scan Already Running",
        description: "A scan is already in progress. Please wait for it to complete.",
        variant: "destructive",
      });
      return;
    }
    
    // Double-check: if BCM is reading, block scan
    if (bcmReading) {
      toast({
        title: "⚠️ BCM Read in Progress",
        description: "Please wait for BCM read to complete before scanning.",
        variant: "destructive",
      });
      return;
    }
    
    // Demo mode: simulate scan without hardware
    if (isDemoMode) {
      await handleDemoQuickScan();
      return;
    }
    
    if (!connected) {
      setScanning(false); // Release lock
      toast({
        title: "Not Connected",
        description: "Please connect to OBDLink first or enable Demo Mode",
        variant: "destructive",
      });
      return;
    }
    setModules([]);
    setTotalScanned(0);

    try {
      const protocol = connectionManager.getProtocol();
      if (!protocol) {
        throw new Error("No protocol available");
      }

      // Note: Keepalive disabled during scanning to prevent message collisions
      // Constant scanning keeps modules active anyway
      
      toast({
        title: "Quick Scan Started",
        description: "Checking common ECU addresses...",
      });

      // Use AlphaOBD-verified addresses directly from database
      const commonAddresses = ALPHAOBD_MODULES.map(m => ({
        tx: m.txId,
        rx: m.rxId,
        name: m.name
      }));

      const discoveredModules: DiscoveredModule[] = [];
      const totalToScan = commonAddresses.length;
      
      // Determine address range for progress display
      const addressRange = `0x${Math.min(...commonAddresses.map(m => m.tx)).toString(16).toUpperCase()} - 0x${Math.max(...commonAddresses.map(m => m.tx)).toString(16).toUpperCase()}`;
      
      console.log(`[HW-TEST] 🚀 Starting sequential scan to prevent CAN bus overload...`);
      const startTime = Date.now();
      
      // Sequential scanning: process 1 module at a time to prevent CAN bus errors
      const BATCH_SIZE = 1;
      let scannedCount = 0;
      
      for (let batchStart = 0; batchStart < commonAddresses.length; batchStart += BATCH_SIZE) {
        const batch = commonAddresses.slice(batchStart, batchStart + BATCH_SIZE);
        console.log(`[HW-TEST] Processing batch ${Math.floor(batchStart / BATCH_SIZE) + 1}/${Math.ceil(commonAddresses.length / BATCH_SIZE)} (${batch.length} modules)`);
        
        // Scan all modules in batch SEQUENTIALLY (not parallel)
        // CRITICAL FIX: Diagnostic session (0x10 0x03) must be sent RIGHT BEFORE each VIN read
        // Parallel execution causes modules to timeout and exit diagnostic mode
        const batchResults: (DiscoveredModule | null)[] = [];
        
        for (const module of batch) {
          const currentAddr = `0x${module.tx.toString(16).toUpperCase()}`;
          
          try {
            // Step 1: Enter Extended Diagnostic Session (0x10 0x03) - required for most modules
            // PCM responds without this, but BCM/RFHUB/TCM/ABS/IPC need diagnostic session first
            // MUST be sent RIGHT BEFORE VIN read to prevent timeout
            try {
              await (protocol as any).sendUDS(module.tx, module.rx, [0x10, 0x03], 0); // No retries for session init
              await new Promise(resolve => setTimeout(resolve, 300)); // 300ms delay after session init (BCM/RFHUB/ABS/IPC need more time)
            } catch (e) {
              // Ignore session init errors - some modules don't need it (PCM)
            }
            
            // Step 2: Read VIN (0x22 0xF190) - now module should be ready
            const response = await (protocol as any).sendUDS(module.tx, module.rx, [0x22, 0xF1, 0x90], 1);
            
            // DEBUG: Log raw response for diagnosis
            if (response && response.length > 0) {
              console.log(`[Module Scanner] Quick Scan - Module ${module.name} (${currentAddr}) response:`, {
                length: response.length,
                raw: Array.from(response as Uint8Array).map((b: number) => '0x' + b.toString(16).toUpperCase().padStart(2, '0')).join(' '),
                firstByte: '0x' + response[0].toString(16).toUpperCase()
              });
            }
            
            if (response && response.length > 3 && response[0] === 0x62) {
              const vinBytes = response.slice(3);
              console.log(`[Module Scanner] VIN bytes for ${module.name}:`, {
                vinBytesLength: vinBytes.length,
                vinBytesHex: Array.from(vinBytes as Uint8Array).map((b: number) => '0x' + b.toString(16).toUpperCase().padStart(2, '0')).join(' '),
                vinBytesASCII: Array.from(vinBytes as Uint8Array).map((b: number) => (b >= 0x20 && b <= 0x7E) ? String.fromCharCode(b) : '.').join('')
              });
              const vin = parseVINBytes(vinBytes);
              console.log(`[Module Scanner] Parsed VIN for ${module.name}: "${vin}" (length: ${vin?.length || 0})`);
              
              const canIdHex = module.tx.toString(16).toUpperCase();
              batchResults.push({
                name: getModuleName(canIdHex),
                code: canIdHex,
                txId: module.tx,
                rxId: module.rx,
                vin: (vin && vin.length === 17) ? vin : null,
                vinOffset: null,
                status: (vin && vin.length === 17) ? 'vin_read' : 'found',
                lastResponse: response,
              } as DiscoveredModule);
            } else {
              batchResults.push(null);
            }
          } catch (e) {
            // No response - module not present
            batchResults.push(null);
          }
        }
        
        // Add delay between batches to prevent CAN bus overload
        if (batchStart + BATCH_SIZE < commonAddresses.length) {
          await new Promise(resolve => setTimeout(resolve, 100)); // 100ms delay between modules
        }
        
        // Add discovered modules to results
        batchResults.forEach(module => {
          if (module) {
            discoveredModules.push(module);
          }
        });
        
        // Update progress
        scannedCount += batch.length;
        setTotalScanned(scannedCount);
        setCurrentScanAddress(`Batch ${Math.floor(batchStart / BATCH_SIZE) + 1}/${Math.ceil(commonAddresses.length / BATCH_SIZE)}`);
        setScanProgress({
          current: scannedCount,
          total: totalToScan,
          range: addressRange
        });
        
        // Small delay between batches to avoid overwhelming the bus
        await new Promise(resolve => setTimeout(resolve, 50));
      }
      
      const totalTime = Date.now() - startTime;
      console.log(`[HW-TEST] ✅ Parallel scan complete: ${discoveredModules.length} modules found in ${totalTime}ms (${Math.round(totalTime / commonAddresses.length)}ms per module)`);
      console.log(`[HW-TEST] 🚀 Speedup: ~${Math.round((commonAddresses.length * 100) / totalTime * 10) / 10}x faster than sequential`)

      // Determine primary VIN (most common VIN among modules)
      const vinCounts = new Map<string, number>();
      discoveredModules.forEach(m => {
        if (m.vin && m.vin.length === 17) {
          vinCounts.set(m.vin, (vinCounts.get(m.vin) || 0) + 1);
        }
      });
      
      let mostCommonVIN: string | null = null;
      let maxCount = 0;
      vinCounts.forEach((count, vin) => {
        if (count > maxCount) {
          maxCount = count;
          mostCommonVIN = vin;
        }
      });
      
      setPrimaryVIN(mostCommonVIN);
      
      // Identify modules with mismatched VINs
      const mismatches: string[] = [];
      if (mostCommonVIN) {
        discoveredModules.forEach(m => {
          if (m.vin && m.vin.length === 17 && m.vin !== mostCommonVIN) {
            mismatches.push(m.code);
          }
        });
      }
      
      setVinMismatches(mismatches);
      
      setModules(discoveredModules);
      
      // Save scan to history
      saveScanMutation.mutate({
        scanType: "quick",
        primaryVIN: mostCommonVIN || undefined,
        mismatchCount: mismatches.length,
        hardwareType: "elm327",
        modules: discoveredModules.map(m => ({
          canId: m.code,
          moduleName: m.name,
          vin: m.vin || undefined,
          vinMismatch: m.vin ? m.vin !== mostCommonVIN : false,
          isPrimaryVIN: m.vin === mostCommonVIN,
          status: m.status === "vin_read" ? "online" as const : "offline" as const,
        })),
      });
      
      toast({
        title: "Quick Scan Complete",
        description: `Found ${discoveredModules.length} module(s)${mismatches.length > 0 ? ` (⚠️ ${mismatches.length} VIN mismatch${mismatches.length > 1 ? 'es' : ''})` : ''}`,
        variant: mismatches.length > 0 ? "destructive" : "default",
      });
    } catch (error: any) {
      toast({
        title: "Scan Failed",
        description: error.message || "Error during quick scan",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
      setCurrentScanAddress(null);
      setScanProgress(null);
    }
  };

  const handleScan = async () => {
    // CRITICAL: Prevent concurrent scans - only one scan can run at a time
    if (scanning) {
      toast({
        title: "⚠️ Scan Already Running",
        description: "A scan is already in progress. Please wait for it to complete.",
        variant: "destructive",
      });
      return;
    }
    
    // Double-check: if BCM is reading, block scan
    if (bcmReading) {
      toast({
        title: "⚠️ BCM Read in Progress",
        description: "Please wait for BCM read to complete before scanning.",
        variant: "destructive",
      });
      return;
    }
    
    // IMMEDIATELY set scanning=true to lock out other scans
    setScanning(true);
    
    // Demo mode: simulate full scan without hardware
    if (isDemoMode) {
      try {
        await handleDemoFullScan();
      } finally {
        setScanning(false);
      }
      return;
    }
    
    if (!connected) {
      setScanning(false); // Release lock
      toast({
        title: "Not Connected",
        description: "Please connect to OBDLink first or enable Demo Mode",
        variant: "destructive",
      });
      return;
    }
    setModules([]);
    setTotalScanned(0);

    try {
      const protocol = connectionManager.getProtocol();
      if (!protocol) {
        throw new Error("No protocol available");
      }

      // Note: Keepalive disabled during scanning to prevent message collisions
      // Constant scanning keeps modules active anyway
      
      toast({
        title: "Full Scan Started",
        description: "Scanning ALL CAN addresses (0x600-0x7FF)...",
      });

      // Build TX → RX mapping from AlphaOBD database for accurate addressing
      const txToRxMap = new Map<number, number>();
      ALPHAOBD_MODULES.forEach(m => {
        txToRxMap.set(m.txId, m.rxId);
      });

      // Scan FULL Chrysler/FCA range: 0x600-0x7FF (512 addresses)
      // This covers ALL PowerNet and standard OBD2 modules
      const discoveredModules: DiscoveredModule[] = [];
      const startId = 0x600;
      const endId = 0x7FF;
      const totalToScan = endId - startId + 1;
      const addressRange = `0x${startId.toString(16).toUpperCase()} - 0x${endId.toString(16).toUpperCase()}`;
      
      for (let canId = startId; canId <= endId; canId++) {
        const currentAddr = `0x${canId.toString(16).toUpperCase()}`;
        const scannedCount = canId - startId + 1;
        
        setTotalScanned(scannedCount);
        setCurrentScanAddress(currentAddr);
        setScanProgress({
          current: scannedCount,
          total: totalToScan,
          range: addressRange
        });

        try {
          // Use AlphaOBD verified RX address if available, otherwise fall back to TX+8
          // This ensures we use correct addresses for known modules (e.g., BCM 0x620→0x504)
          // while still discovering unknown modules with standard addressing
          const rxId = txToRxMap.get(canId) ?? (canId + 0x08);
          const response = await (protocol as any).sendUDS(canId, rxId, [0x22, 0xF1, 0x90], 1);
          
          // DEBUG: Log response for diagnosis
          if (response && response.length > 0) {
            console.log(`[Module Scanner] Full Scan - CAN ID 0x${canId.toString(16).toUpperCase()} response:`, {
              length: response.length,
              raw: Array.from(response as Uint8Array).map((b: number) => '0x' + b.toString(16).toUpperCase().padStart(2, '0')).join(' '),
              firstByte: '0x' + response[0].toString(16).toUpperCase()
            });
          }
          
          if (response && response.length > 3 && response[0] === 0x62) {
            // Positive response - module found
            const vinBytes = response.slice(3);
            console.log(`[Module Scanner] VIN bytes for 0x${canId.toString(16).toUpperCase()}:`, {
              vinBytesLength: vinBytes.length,
              vinBytesHex: Array.from(vinBytes as Uint8Array).map((b: number) => '0x' + b.toString(16).toUpperCase().padStart(2, '0')).join(' '),
              vinBytesASCII: Array.from(vinBytes as Uint8Array).map((b: number) => (b >= 0x20 && b <= 0x7E) ? String.fromCharCode(b) : '.').join('')
            });
            const vin = parseVINBytes(vinBytes);
            console.log(`[Module Scanner] Parsed VIN for 0x${canId.toString(16).toUpperCase()}: "${vin}" (length: ${vin?.length || 0})`)
            
            const canIdHex = canId.toString(16).toUpperCase();
            discoveredModules.push({
              name: getModuleName(canIdHex),
              code: canIdHex,
              txId: canId,
              rxId: rxId,
              vin: (vin && vin.length === 17) ? vin : null,
              vinOffset: null,
              status: (vin && vin.length === 17) ? 'vin_read' : 'found',
              lastResponse: response,
            });
          }
        } catch (e) {
          // No response or error - module not present at this ID
        }

        // Small delay between scans
        // Minimal delay between modules for fast scanning
        await new Promise(resolve => setTimeout(resolve, 20));
      }

      // Determine primary VIN (most common VIN among modules)
      const vinCounts = new Map<string, number>();
      discoveredModules.forEach(m => {
        if (m.vin && m.vin.length === 17) {
          vinCounts.set(m.vin, (vinCounts.get(m.vin) || 0) + 1);
        }
      });
      
      let mostCommonVIN: string | null = null;
      let maxCount = 0;
      vinCounts.forEach((count, vin) => {
        if (count > maxCount) {
          maxCount = count;
          mostCommonVIN = vin;
        }
      });
      
      setPrimaryVIN(mostCommonVIN);
      
      // Identify modules with mismatched VINs
      const mismatches: string[] = [];
      if (mostCommonVIN) {
        discoveredModules.forEach(m => {
          if (m.vin && m.vin.length === 17 && m.vin !== mostCommonVIN) {
            mismatches.push(m.code);
          }
        });
      }
      
      setVinMismatches(mismatches);
      
      setModules(discoveredModules);
      
      // Save scan to history
      saveScanMutation.mutate({
        scanType: "full",
        primaryVIN: mostCommonVIN || undefined,
        mismatchCount: mismatches.length,
        hardwareType: "elm327",
        modules: discoveredModules.map(m => ({
          canId: m.code,
          moduleName: m.name,
          vin: m.vin || undefined,
          vinMismatch: m.vin ? m.vin !== mostCommonVIN : false,
          isPrimaryVIN: m.vin === mostCommonVIN,
          status: m.status === "vin_read" ? "online" as const : "offline" as const,
        })),
      });
      
      toast({
        title: "Full Scan Complete",
        description: `Found ${discoveredModules.length} modules${mismatches.length > 0 ? ` (⚠️ ${mismatches.length} VIN mismatch${mismatches.length > 1 ? 'es' : ''})` : ''}`,
        variant: mismatches.length > 0 ? "destructive" : "default",
      });
    } catch (error: any) {
      console.error("Scan error:", error);
      toast({
        title: "Scan Failed",
        description: error.message || "Error during module scanning",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
      setCurrentScanAddress(null);
      setScanProgress(null);
    }
  };

  const handleReadBCM = async () => {
    if (!connected) {
      toast({
        title: "Not Connected",
        description: "Please connect to OBDLink first",
        variant: "destructive",
      });
      return;
    }

    setBcmReading(true);
    setBcmVin(null);
    setRetryLog([]);

    const addLog = (msg: string) => {
      const timestamp = new Date().toLocaleTimeString();
      setRetryLog(prev => [...prev, `[${timestamp}] ${msg}`]);
    };

    // Intercept console.log to capture ELM327 retry messages
    const originalLog = console.log;
    console.log = (...args: any[]) => {
      originalLog(...args);
      const message = args.join(' ');
      if (message.includes('[ELM327]')) {
        addLog(message.replace('[ELM327]', '🔧'));
      }
    };

    try {
      const protocol = connectionManager.getProtocol();
      if (!protocol || !('readVIN' in protocol)) {
        throw new Error("Protocol does not support VIN reading");
      }

      // BCM can respond on multiple addresses - try all 3
      const BCM_ADDRESSES = [
        { tx: 0x6B0, rx: 0x6B8, name: "CAN-IHS (Original SRT Lab Toolkit)", bus: "CAN-IHS" },
        { tx: 0x750, rx: 0x758, name: "CAN-C (Shared DB)", bus: "CAN-C" },
        { tx: 0x7E0, rx: 0x7E8, name: "OBD2 Standard", bus: "CAN-C" },
      ];

      addLog("🔄 Testing all 3 BCM addresses...");
      addLog("⏳ Using exponential backoff: 300ms → 600ms → 1200ms → 2400ms");
      
      let successfulAddress = null;
      let successfulVin = null;
      
      for (const addr of BCM_ADDRESSES) {
        addLog(`\n📡 Trying BCM at TX: 0x${addr.tx.toString(16).toUpperCase()}, RX: 0x${addr.rx.toString(16).toUpperCase()} (${addr.name})`);
        
        try {
          const startTime = performance.now();
          
          // Send UDS request 0x22 0xF1 0x90 (Read VIN DID)
          const response = await (protocol as any).sendUDS(addr.tx, addr.rx, [0x22, 0xF1, 0x90], 3);
          const responseTime = Math.round(performance.now() - startTime);
          
          // Log raw response for debugging
          if (response && response.length > 0) {
            const hexDump = Array.from(response as Uint8Array)
              .map((b: number) => '0x' + b.toString(16).toUpperCase().padStart(2, '0'))
              .join(' ');
            addLog(`🔍 Raw response (${response.length} bytes, ${responseTime}ms): ${hexDump}`);
            
            // Verify UDS positive response (0x62 = response to 0x22)
            if (response[0] === 0x62) {
              addLog(`✅ Valid UDS response (0x62 - Positive Response)`);
              
              // Extract VIN from response (skip first 3 bytes: 0x62 0xF1 0x90)
              const vinBytes = response.slice(3);
              const vin = Array.from(vinBytes as Uint8Array)
                .map((b: number) => String.fromCharCode(b))
                .join('')
                .trim();
              
              addLog(`🔢 Extracted VIN: "${vin}" (${vin.length} chars)`);
              
              // Validate VIN format
              const vinValid = vin.length === 17 && /^[A-HJ-NPR-Z0-9]{17}$/.test(vin);
              if (vinValid) {
                const wmi = vin.substring(0, 3);
                addLog(`✅ VIN format valid! WMI: ${wmi}`);
                
                successfulAddress = addr;
                successfulVin = vin;
                addLog(`✅ SUCCESS at 0x${addr.tx.toString(16).toUpperCase()}! VIN: ${vin} (${responseTime}ms)`);
                break; // Found working address
              } else {
                addLog(`⚠️ VIN format invalid (length: ${vin.length}, contains I/O/Q: ${!/^[A-HJ-NPR-Z0-9]+$/.test(vin)})`);
              }
            } else {
              addLog(`❌ Invalid UDS response (expected 0x62, got 0x${response[0].toString(16).toUpperCase()})`);
            }
          } else {
            addLog(`❌ No response from 0x${addr.tx.toString(16).toUpperCase()}`);
          }
        } catch (err: any) {
          addLog(`❌ Failed at 0x${addr.tx.toString(16).toUpperCase()}: ${err.message}`);
        }
      }
      
      if (successfulVin && successfulAddress) {
        setBcmVin(successfulVin);
        toast({
          title: "✅ VIN Read Successfully!",
          description: `BCM VIN: ${successfulVin} (at 0x${successfulAddress.tx.toString(16).toUpperCase()} - ${successfulAddress.name})`,
        });
        return;
      }
      
      throw new Error("Failed to read VIN from BCM at all 3 addresses");
      
    } catch (error: any) {
      addLog(`❌ FAILED: ${error.message}`);
      toast({
        title: "BCM Read Failed",
        description: error.message || "Could not read VIN from BCM",
        variant: "destructive",
      });
    } finally {
      console.log = originalLog; // Restore original console.log
      setBcmReading(false);
    }
  };

  const handleExport = () => {
    const csv = [
      ["CAN ID", "Module Name", "VIN", "Status", "VIN Mismatch"].join(","),
      ...modules.map(m => [
        m.code,
        m.name,
        m.vin || "N/A",
        m.status,
        vinMismatches.includes(m.code) ? "YES" : "NO"
      ].join(","))
    ].join("\\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `module-scan-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Export Complete",
      description: `Exported ${modules.length} modules${vinMismatches.length > 0 ? ` (${vinMismatches.length} with VIN mismatches)` : ''}`,
    });
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <BackButton />
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Module Scanner</h1>
        <p className="text-muted-foreground">
          Discover all ECUs on the vehicle CAN bus and read VINs
        </p>
      </div>

      <Tabs defaultValue="scanner" className="space-y-6">
        <TabsList>
          <TabsTrigger value="scanner">Module Scanner</TabsTrigger>
          <TabsTrigger value="firmware">Firmware Database</TabsTrigger>
        </TabsList>

        <TabsContent value="scanner" className="space-y-6">
      <div className="grid gap-6">
        {/* Connection & Scan Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Scan Controls</CardTitle>
            <CardDescription>
              Connect OBDLink and scan for modules
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Demo Mode Toggle */}
            {/* Demo Mode Banner */}
            <DemoModeBanner />

            {!connected && !isDemoMode ? (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Not connected. Connect your OBDLink or enable Demo Mode to begin scanning.
                </AlertDescription>
              </Alert>
            ) : !isDemoMode ? (
              <Alert className="border-green-500 bg-green-50">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  <strong>OBDLink Connected</strong> - Ready to scan
                </AlertDescription>
              </Alert>
            ) : null}

            <div className="flex gap-3">
              {!connected && !isDemoMode ? (
                <Button onClick={handleConnect} className="flex items-center gap-2">
                  Connect to OBDLink
                </Button>
              ) : (connected || isDemoMode) ? (
                <>
                  <Button
                    onClick={handleTestCommunication}
                    disabled={testing || scanning || bcmReading}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    {testing ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Testing...
                      </>
                    ) : (
                      <>
                        📡 Test Communication
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={handleReadBCM}
                    disabled={bcmReading || scanning}
                    className="flex items-center gap-2 bg-red-600 hover:bg-red-700"
                  >
                    {bcmReading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Reading BCM...
                      </>
                    ) : (
                      <>
                        🚨 Emergency BCM Read
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={handleQuickScan}
                    disabled={scanning || bcmReading}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
                  >
                    {scanning && scanProgress ? (
                      <div className="flex flex-col items-start">
                        <div className="flex items-center gap-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>Scanning {currentScanAddress}...</span>
                        </div>
                        <span className="text-xs opacity-80">
                          {scanProgress.current}/{scanProgress.total} ({Math.round((scanProgress.current / scanProgress.total) * 100)}%) • Range: {scanProgress.range}
                        </span>
                      </div>
                    ) : (
                      <>
                        ⚡ Quick Scan
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={handleScan}
                    disabled={scanning || bcmReading}
                    className="flex items-center gap-2"
                    variant="outline"
                  >
                    {scanning && scanProgress ? (
                      <div className="flex flex-col items-start">
                        <div className="flex items-center gap-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>Scanning {currentScanAddress}...</span>
                        </div>
                        <span className="text-xs opacity-80">
                          {scanProgress.current}/{scanProgress.total} ({Math.round((scanProgress.current / scanProgress.total) * 100)}%) • Range: {scanProgress.range}
                        </span>
                      </div>
                    ) : (
                      <>
                        <Scan className="h-4 w-4" />
                        Full Scan (All 512)
                      </>
                    )}
                  </Button>

                  {modules.length > 0 && (
                    <Button
                      onClick={handleExport}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <Download className="h-4 w-4" />
                      Export CSV
                    </Button>
                  )}
                </>
              ) : null}
            </div>

            {scanning && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Progress</span>
                  <span>{totalScanned} scanned</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-red-600 h-2 rounded-full transition-all animate-pulse"
                    style={{ width: `${Math.min(100, (totalScanned / 30) * 100)}%` }}
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* BCM Retry Log */}
        {retryLog.length > 0 && (
          <Card className="border-red-500">
            <CardHeader>
              <CardTitle className="text-red-600">🚨 BCM Read Log (Live)</CardTitle>
              <CardDescription>
                Watch retry attempts in real-time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-black text-green-400 font-mono text-sm p-4 rounded-lg space-y-1 max-h-64 overflow-y-auto">
                {retryLog.map((log, idx) => (
                  <div key={idx}>{log}</div>
                ))}
              </div>
              {bcmVin && (
                <div className="mt-4 p-4 bg-green-50 border border-green-500 rounded-lg">
                  <div className="font-bold text-green-800">✅ BCM VIN:</div>
                  <div className="font-mono text-2xl text-green-900">{bcmVin}</div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* VIN Mismatch Warning */}
        {vinMismatches.length > 0 && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <div className="font-semibold mb-1">⚠️ VIN Mismatch Detected!</div>
              <div className="text-sm">
                {vinMismatches.length} module{vinMismatches.length > 1 ? 's have' : ' has'} a different VIN than the primary vehicle VIN.
                This indicates the module{vinMismatches.length > 1 ? 's were' : ' was'} likely swapped from another vehicle.
              </div>
              <div className="mt-2 text-sm">
                <strong>Primary VIN:</strong> <span className="font-mono">{primaryVIN}</span>
              </div>
              <div className="mt-1 text-sm">
                <strong>Mismatched modules:</strong> {vinMismatches.map(code => {
                  const module = modules.find(m => m.code === code);
                  return `${module?.name || 'Unknown'} (${code})`;
                }).join(', ')}
              </div>
              <div className="mt-3">
                <Button
                  onClick={() => setShowBatchProgramming(true)}
                  variant="destructive"
                  size="sm"
                >
                  Fix All Mismatches
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Results */}
        {modules.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Discovered Modules ({modules.length})</CardTitle>
                  <CardDescription>
                    ECUs found on CAN bus{primaryVIN && ` • Primary VIN: ${primaryVIN}`}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={viewMode === "table" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("table")}
                  >
                    Table View
                  </Button>
                  <Button
                    variant={viewMode === "topographical" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("topographical")}
                  >
                    Topographical View
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {viewMode === "topographical" ? (
                <TopographicalModuleView
                  modules={modules.map(m => ({
                    canId: m.code,
                    name: m.name,
                    vin: m.vin || undefined,
                    vinMismatch: vinMismatches.includes(m.code),
                    status: m.status === "vin_read" ? "online" : "offline",
                  }))}
                  primaryVIN={primaryVIN || undefined}
                  onModuleClick={(module) => {
                    const fullModule = modules.find(m => m.code === module.canId);
                    if (fullModule && module.vinMismatch) {
                      setCorrectionModule(fullModule);
                    }
                  }}
                  onReadDTCs={async (module) => {
                    const fullModule = modules.find(m => m.code === module.canId);
                    if (!fullModule) return;
                    
                    try {
                      const protocol = connectionManager.getProtocol();
                      if (!protocol) throw new Error("No hardware connection");
                      
                      // UDS 0x19 0x02 0xFF - Read DTCs by status mask
                      const response = await protocol.sendUDS(fullModule.txId, fullModule.rxId, [0x19, 0x02, 0xFF]);
                      if (!response || response[0] !== 0x59) {
                        throw new Error("Failed to read DTCs");
                      }
                      
                      // Parse DTCs from response
                      const dtcCount = response[1];
                      const dtcs: string[] = [];
                      for (let i = 0; i < dtcCount; i++) {
                        const offset = 2 + (i * 3);
                        const dtcHigh = response[offset];
                        const dtcLow = response[offset + 1];
                        const status = response[offset + 2];
                        const dtcCode = `P${((dtcHigh << 8) | dtcLow).toString(16).toUpperCase().padStart(4, '0')}`;
                        dtcs.push(`${dtcCode} (Status: 0x${status.toString(16).toUpperCase()})`);
                      }
                      
                      setDtcModule(fullModule);
                      setDtcResults(dtcs.length > 0 ? dtcs : ["No DTCs found"]);
                      toast({ title: "DTCs Read", description: `Found ${dtcs.length} DTC(s)` });
                    } catch (error) {
                      toast({ title: "Error", description: error instanceof Error ? error.message : "Failed to read DTCs", variant: "destructive" });
                    }
                  }}
                  onViewPartNumber={async (module) => {
                    const fullModule = modules.find(m => m.code === module.canId);
                    if (!fullModule) return;
                    
                    try {
                      const protocol = connectionManager.getProtocol();
                      if (!protocol) throw new Error("No hardware connection");
                      
                      // UDS 0x22 0xF1 0x87 - Read part number
                      const response = await protocol.sendUDS(fullModule.txId, fullModule.rxId, [0x22, 0xF1, 0x87]);
                      if (!response || response[0] !== 0x62) {
                        throw new Error("Failed to read part number");
                      }
                      
                      const partNumberBytes = response.slice(3);
                      const partNum = String.fromCharCode(...Array.from(partNumberBytes)).trim();
                      
                      setPartNumberModule(fullModule);
                      setPartNumber(partNum);
                      toast({ title: "Part Number", description: partNum });
                    } catch (error) {
                      toast({ title: "Error", description: error instanceof Error ? error.message : "Failed to read part number", variant: "destructive" });
                    }
                  }}
                  onCheckSoftwareVersion={async (module) => {
                    const fullModule = modules.find(m => m.code === module.canId);
                    if (!fullModule) return;
                    
                    try {
                      const protocol = connectionManager.getProtocol();
                      if (!protocol) throw new Error("No hardware connection");
                      
                      // UDS 0x22 0xF1 0x95 - Read software version
                      const response = await protocol.sendUDS(fullModule.txId, fullModule.rxId, [0x22, 0xF1, 0x95]);
                      if (!response || response[0] !== 0x62) {
                        throw new Error("Failed to read software version");
                      }
                      
                      const versionBytes = response.slice(3);
                      const version = String.fromCharCode(...Array.from(versionBytes)).trim();
                      
                      setSoftwareModule(fullModule);
                      setSoftwareVersion(version);
                      toast({ title: "Software Version", description: version });
                    } catch (error) {
                      toast({ title: "Error", description: error instanceof Error ? error.message : "Failed to read software version", variant: "destructive" });
                    }
                  }}
                  onClearDTCs={async (module) => {
                    const fullModule = modules.find(m => m.code === module.canId);
                    if (!fullModule) return;
                    
                    // Show confirmation dialog
                    const confirmed = window.confirm(
                      `Clear all DTCs from ${fullModule.name}?\n\n` +
                      `This will erase all diagnostic trouble codes and freeze frame data.\n` +
                      `Make sure you have documented any codes you need before proceeding.`
                    );
                    
                    if (!confirmed) return;
                    
                    try {
                      const protocol = connectionManager.getProtocol();
                      if (!protocol) throw new Error("No hardware connection");
                      
                      // UDS 0x14 0xFF 0xFF 0xFF - Clear all DTCs
                      const response = await protocol.sendUDS(fullModule.txId, fullModule.rxId, [0x14, 0xFF, 0xFF, 0xFF]);
                      if (!response || response[0] !== 0x54) {
                        throw new Error("Failed to clear DTCs");
                      }
                      
                      toast({ 
                        title: "DTCs Cleared", 
                        description: `All DTCs cleared from ${fullModule.name}`,
                        variant: "default"
                      });
                      
                      // Clear DTC results if this module's DTCs were displayed
                      if (dtcModule?.code === fullModule.code) {
                        setDtcModule(null);
                        setDtcResults([]);
                      }
                    } catch (error) {
                      toast({ 
                        title: "Error", 
                        description: error instanceof Error ? error.message : "Failed to clear DTCs", 
                        variant: "destructive" 
                      });
                    }
                  }}
                />
              ) : (
                <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>CAN ID</TableHead>
                    <TableHead>Module Name</TableHead>
                    <TableHead>VIN</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {modules.map((module, idx) => {
                    const isMismatch = vinMismatches.includes(module.code);
                    const isPrimary = module.vin === primaryVIN;
                    
                    return (
                      <TableRow key={idx} className={isMismatch ? "bg-red-50 dark:bg-red-950/20" : ""}>
                        <TableCell className="font-mono">{module.code}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {module.name}
                            {(() => {
                              const algo = getModuleAlgorithm(module);
                              return algo ? (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Badge variant="outline" className={`text-xs ${algo.color} text-white border-0`}>
                                        {algo.name}
                                      </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>{algo.tooltip}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              ) : null;
                            })()}
                            {isMismatch && (
                              <Badge variant="destructive" className="text-xs">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                VIN Mismatch
                              </Badge>
                            )}
                            {isPrimary && module.vin && (
                              <Badge variant="outline" className="text-xs bg-blue-50 dark:bg-blue-950/20 border-blue-500">
                                Primary VIN
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {module.vin || <span className="text-muted-foreground">N/A</span>}
                        </TableCell>
                        <TableCell>
                          {module.status === 'vin_read' ? (
                            <Badge variant="default" className="bg-green-600">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              VIN Read
                            </Badge>
                          ) : module.status === 'found' ? (
                            <Badge variant="secondary">
                              Found
                            </Badge>
                          ) : (
                            <Badge variant="outline">
                              {module.status}
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              )}
            </CardContent>
          </Card>
        )}

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-start gap-3">
              <Badge className="mt-1">1</Badge>
              <div>
                <p className="font-medium">Connect OBDLink</p>
                <p className="text-muted-foreground">
                  Click "Connect to OBDLink" and select your device from the browser's serial port picker
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="mt-1">2</Badge>
              <div>
                <p className="font-medium">Start Scan</p>
                <p className="text-muted-foreground">
                  Scans all CAN IDs (0x700-0x7FF) to discover responding ECUs
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="mt-1">3</Badge>
              <div>
                <p className="font-medium">Review Results</p>
                <p className="text-muted-foreground">
                  View discovered modules with their CAN IDs, names, and VINs (if readable)
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="mt-1">4</Badge>
              <div>
                <p className="font-medium">Export Data</p>
                <p className="text-muted-foreground">
                  Save scan results to CSV for documentation or analysis
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
        </TabsContent>

        <TabsContent value="firmware">
          <FirmwareBrowser />
        </TabsContent>
      </Tabs>
      
      {/* VIN Correction Wizard */}
      <VINCorrectionWizard
        module={correctionModule ? {
          canId: correctionModule.code,
          name: correctionModule.name,
          vin: correctionModule.vin || undefined,
          vinMismatch: vinMismatches.includes(correctionModule.code),
        } : null}
        targetVIN={primaryVIN || ""}
        isOpen={correctionModule !== null}
        onClose={() => setCorrectionModule(null)}
        onCorrect={async (module, targetVIN) => {
          // TODO: Implement actual VIN programming via UDS
          toast({
            title: "VIN Correction",
            description: `Would program ${targetVIN} to ${module.name}`,
          });
        }}
      />
      
      {/* Batch VIN Programming */}
      <BatchVINProgramming
        modules={modules.filter(m => vinMismatches.includes(m.code)).map(m => ({
          canId: m.code,
          name: m.name,
          vin: m.vin || undefined,
          vinMismatch: true,
        }))}
        targetVIN={primaryVIN || ""}
        isOpen={showBatchProgramming}
        onClose={() => setShowBatchProgramming(false)}
        onProgramModule={async (module, targetVIN) => {
          // TODO: Implement actual VIN programming via UDS
          await new Promise(resolve => setTimeout(resolve, 2000));
        }}
      />
    </div>
  );
}
