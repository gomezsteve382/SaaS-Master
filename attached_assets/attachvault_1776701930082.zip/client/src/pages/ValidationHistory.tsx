import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  History, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  FileText, 
  Calendar,
  Search,
  Download,
  Trash2,
  BarChart3
} from 'lucide-react';

export default function ValidationHistory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  const { data: history, isLoading, refetch } = trpc.rfhub.getValidationHistory.useQuery({
    limit: 100,
    offset: 0,
  });

  const { data: stats } = trpc.rfhub.getValidationStats.useQuery();
  const deleteHistory = trpc.rfhub.deleteValidationHistory.useMutation();

  const handleDelete = async () => {
    if (selectedIds.length === 0) return;
    
    try {
      await deleteHistory.mutateAsync({ ids: selectedIds });
      setSelectedIds([]);
      refetch();
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const handleExportCSV = () => {
    if (!history) return;

    const headers = [
      'Date',
      'File Name',
      'File Size',
      'Valid',
      'VIN Found',
      'Expected CRC',
      'Actual CRC',
      'CRC Match',
      'Algorithm',
      'Brute Forced',
      'Brute Force Time (ms)',
    ];

    const rows = history.map((h: any) => [
      new Date(h.validatedAt).toLocaleString(),
      h.fileName,
      h.fileSize?.toString() || 'N/A',
      h.isValid ? 'Yes' : 'No',
      h.vinFound || 'N/A',
      h.expectedCRC || 'N/A',
      h.actualCRC || 'N/A',
      h.crcMatch ? 'Yes' : 'No',
      h.algorithmUsed || 'N/A',
      h.isBruteForced ? 'Yes' : 'No',
      h.bruteForceTimeMs?.toString() || 'N/A',
    ]);

    const csvLines = [
      headers.join(','),
      ...rows.map((row: any[]) => row.map((cell) => `"${cell}"`).join(',')),
    ];

    const csv = csvLines.join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `validation-history-${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredHistory = history?.filter((h: any) =>
    h.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.vinFound?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-2">
          <History className="h-8 w-8" />
          Validation History
        </h1>
        <p className="text-muted-foreground">
          Track and analyze all RFHUB file validation operations
        </p>
      </div>

      {/* Statistics Dashboard */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Validations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalValidations || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                All time
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Success Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {stats.totalValidations > 0
                  ? ((stats.validFiles / stats.totalValidations) * 100).toFixed(1)
                  : 0}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.validFiles} valid / {stats.invalidFiles} invalid
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Brute-Force Count
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">
                {stats.bruteForceCount || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Avg time: {stats.avgBruteForceTime ? `${Math.round(stats.avgBruteForceTime)}ms` : 'N/A'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Common Algorithms
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {stats.commonAlgorithms?.length || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Unique algorithms used
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Most Common Algorithms */}
      {stats?.commonAlgorithms && stats.commonAlgorithms.length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Most Common Algorithms
            </CardTitle>
            <CardDescription>
              Top algorithms used in validations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats.commonAlgorithms.slice(0, 5).map((algo: any, idx: number) => (
                <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                  <span className="font-mono text-sm">{algo.algorithm}</span>
                  <Badge variant="secondary">
                    {algo.count} use{algo.count !== 1 ? 's' : ''}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* History Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Validation Records</CardTitle>
              <CardDescription>
                Complete history of all validation operations
              </CardDescription>
            </div>
            <div className="flex gap-2">
              {selectedIds.length > 0 && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleDelete}
                  disabled={deleteHistory.isPending}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete ({selectedIds.length})
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={handleExportCSV}>
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by filename or VIN..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Table */}
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading history...
            </div>
          ) : filteredHistory && filteredHistory.length > 0 ? (
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <input
                        type="checkbox"
                        checked={selectedIds.length === filteredHistory.length}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedIds(filteredHistory.map((h: any) => h.id));
                          } else {
                            setSelectedIds([]);
                          }
                        }}
                        className="rounded"
                      />
                    </TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>File Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>VIN</TableHead>
                    <TableHead>CRC Match</TableHead>
                    <TableHead>Algorithm</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.map((record: any) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={selectedIds.includes(record.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedIds([...selectedIds, record.id]);
                            } else {
                              setSelectedIds(selectedIds.filter((id) => id !== record.id));
                            }
                          }}
                          className="rounded"
                        />
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(record.validatedAt).toLocaleString()}
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {record.fileName}
                      </TableCell>
                      <TableCell>
                        {record.isValid ? (
                          <Badge variant="default" className="bg-green-600">
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                            Valid
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            <AlertCircle className="mr-1 h-3 w-3" />
                            Invalid
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {record.vinFound || 'N/A'}
                      </TableCell>
                      <TableCell>
                        {record.crcMatch ? (
                          <Badge variant="outline" className="text-green-600 border-green-600">
                            Match
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-red-600 border-red-600">
                            Mismatch
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {record.algorithmUsed ? (
                          <div className="flex items-center gap-1">
                            <span className="truncate max-w-[200px]">
                              {record.algorithmUsed}
                            </span>
                            {record.isBruteForced && (
                              <Badge variant="secondary" className="text-xs">
                                BF
                              </Badge>
                            )}
                          </div>
                        ) : (
                          'N/A'
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              {searchTerm ? 'No matching records found' : 'No validation history yet'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
