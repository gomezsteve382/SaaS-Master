# J2534 Bridge Real Hardware Testing Guide

## Overview

This guide provides comprehensive instructions for testing the AttachVault J2534 Bridge with real PassThru hardware devices on Windows. The J2534 Bridge enables direct communication with vehicle ECUs through industry-standard J2534 PassThru devices.

---

## Supported Hardware

### Verified Compatible Devices

1. **Autel MaxiSys J2534 ECU Programming Device**
   - Driver: Autel J2534 PassThru Driver
   - Protocols: ISO15765, ISO14230, ISO9141, J1850PWM, J1850VPW
   - Status: ✅ Fully tested with Chrysler BCM/RFHUB

2. **Drew Technologies Mongoose Pro**
   - Driver: Drew Tech J2534 Driver
   - Protocols: All major automotive protocols
   - Status: ✅ Verified with multiple vehicle platforms

3. **Tactrix OpenPort 2.0**
   - Driver: OpenPort 2.0 J2534 Driver
   - Protocols: ISO15765, ISO14230, ISO9141, J1850
   - Status: ✅ Community tested

4. **Generic J2534 Devices**
   - Any device with J2534 v04.04 or v05.00 compliant drivers
   - Must support ISO15765-4 (CAN) protocol
   - Status: ⚠️ May require driver-specific adjustments

---

## Prerequisites

### Software Requirements

1. **Windows 10/11** (64-bit recommended)
2. **Python 3.8 or higher**
3. **J2534 Device Drivers** (device-specific, see manufacturer)
4. **Node.js 18+** (for running the web application)
5. **Git** (for cloning the repository)

### Hardware Requirements

1. J2534 PassThru device (see supported devices above)
2. USB cable for device connection
3. OBD-II cable or vehicle-specific adapter
4. Target vehicle or ECU bench setup

---

## Installation Steps

### 1. Install J2534 Device Drivers

**For Autel MaxiSys:**
```
1. Download Autel J2534 Driver from manufacturer website
2. Run installer as Administrator
3. Verify installation in Device Manager (should show "Autel J2534 Device")
4. Note the driver DLL path (typically C:\Program Files\Autel\J2534\J2534.dll)
```

**For Drew Tech Mongoose:**
```
1. Download Drew Tech PassThru Driver
2. Install with default settings
3. Verify in Device Manager under "Drew Technologies Devices"
4. Driver path: C:\Program Files\Drew Technologies\J2534\DrewTechJ2534.dll
```

**For Tactrix OpenPort:**
```
1. Download OpenPort 2.0 drivers
2. Install both J2534 and USB drivers
3. Verify device connection in Device Manager
4. Driver path: C:\Program Files\Tactrix\OpenPort 2.0\openport 2.0.dll
```

### 2. Install Python Dependencies

Open PowerShell or Command Prompt as Administrator:

```powershell
# Navigate to project directory
cd C:\path\to\attachvault

# Install Python dependencies
pip install pywin32 websockets asyncio

# Verify installation
python -c "import win32com.client; print('PyWin32 installed successfully')"
```

### 3. Configure J2534 Bridge

Edit `j2534-bridge/config.json`:

```json
{
  "device": {
    "name": "Autel MaxiSys",
    "dllPath": "C:\\Program Files\\Autel\\J2534\\J2534.dll",
    "protocol": "ISO15765",
    "baudRate": 500000
  },
  "websocket": {
    "host": "localhost",
    "port": 8765
  },
  "logging": {
    "level": "DEBUG",
    "file": "j2534-bridge.log"
  }
}
```

### 4. Start the J2534 Bridge

```powershell
# Navigate to bridge directory
cd j2534-bridge

# Start the bridge server
python j2534_bridge.py

# Expected output:
# [INFO] J2534 Bridge starting...
# [INFO] Loading J2534 DLL: C:\Program Files\Autel\J2534\J2534.dll
# [INFO] WebSocket server started on ws://localhost:8765
# [INFO] Waiting for connections...
```

---

## Testing Procedures

### Test 1: Device Detection

**Objective:** Verify J2534 device is recognized by the system

**Steps:**
1. Connect J2534 device to PC via USB
2. Run device detection script:

```powershell
python test_scripts/detect_device.py
```

**Expected Output:**
```
Scanning for J2534 devices...
Found device: Autel J2534 Device
  - Firmware: v2.1.3
  - Protocols: ISO15765, ISO14230, ISO9141, J1850PWM
  - Status: Ready
```

**Troubleshooting:**
- If no device found, verify driver installation in Device Manager
- Check USB cable connection
- Try different USB port (preferably USB 3.0)

### Test 2: Channel Initialization

**Objective:** Test opening a communication channel

**Steps:**
1. Ensure device is connected
2. Run channel test:

```powershell
python test_scripts/test_channel.py --protocol ISO15765 --baud 500000
```

**Expected Output:**
```
Opening J2534 device...
Device opened successfully: DeviceID=1
Creating channel: Protocol=ISO15765, Baud=500000
Channel created: ChannelID=1
Starting message filtering...
Channel ready for communication
Closing channel...
Test passed ✓
```

**Troubleshooting:**
- Error "Failed to open device": Check if another application is using the device
- Error "Protocol not supported": Verify device supports ISO15765
- Timeout errors: Check physical connection to vehicle/ECU

### Test 3: UDS Communication

**Objective:** Send UDS diagnostic commands to ECU

**Prerequisites:**
- Vehicle connected via OBD-II port OR ECU on bench with power
- Ignition ON (or bench power applied)

**Steps:**
1. Connect J2534 device to vehicle OBD-II port
2. Run UDS test script:

```powershell
python test_scripts/test_uds.py --ecu BCM --vin
```

**Expected Output:**
```
Connecting to BCM (0x728)...
Sending: 10 03 (Diagnostic Session Control - Extended)
Response: 50 03 00 32 01 F4 ✓

Sending: 27 01 (Security Access - Request Seed)
Response: 67 01 12 34 56 78 ✓

Reading VIN (DID 0xF190)...
Sending: 22 F1 90
Response: 62 F1 90 31 43 33 43 44 46 42 42 30 45 44 31 32 33 34 35 36
VIN: 1C3CDFBB0ED123456 ✓

Test passed ✓
```

**Troubleshooting:**
- "No response from ECU": Check physical connections, verify ECU is powered
- "Negative response 0x7F": ECU rejected command, check diagnostic session
- Timeout: Increase timeout in config.json (default 1000ms)

### Test 4: Seed-Key Authentication

**Objective:** Test security access with seed-key algorithm

**Steps:**
1. Run seed-key test:

```powershell
python test_scripts/test_seed_key.py --ecu BCM --algorithm chrysler_rol5
```

**Expected Output:**
```
Requesting seed from BCM...
Seed received: 12 34 56 78
Calculating key using Chrysler ROL5+XOR algorithm...
Key calculated: AB CD EF 01
Sending key to ECU...
Response: 67 02 (Security Access Granted) ✓

Test passed ✓
```

**Troubleshooting:**
- "Invalid key": Verify algorithm matches ECU type
- "Security access denied": ECU may require specific conditions (vehicle speed = 0, etc.)

### Test 5: VIN Programming

**Objective:** Full VIN programming workflow with real hardware

**Steps:**
1. Backup current VIN first (CRITICAL!)
2. Run VIN programming test:

```powershell
python test_scripts/test_vin_programming.py --ecu BCM --new-vin 1C3CDFBB0ED999999 --backup
```

**Expected Output:**
```
Step 1: Reading current VIN...
Current VIN: 1C3CDFBB0ED123456
Backup saved to: backups/BCM_20241212_083045.bin ✓

Step 2: Entering extended diagnostic session...
Session active ✓

Step 3: Security access...
Seed: 12 34 56 78
Key: AB CD EF 01
Access granted ✓

Step 4: Writing new VIN (0xF190)...
Writing: 31 43 33 43 44 46 42 42 30 45 44 39 39 39 39 39 39
Response: 6E F1 90 ✓

Step 5: Verifying new VIN...
Read VIN: 1C3CDFBB0ED999999 ✓

Step 6: Resetting ECU...
Reset command sent ✓

VIN programming completed successfully!
```

**⚠️ WARNING:** VIN programming is PERMANENT. Always backup before testing!

---

## Common UDS Commands Reference

### Diagnostic Session Control (0x10)

```python
# Default session
send_uds([0x10, 0x01])  # Response: 50 01

# Extended diagnostic session
send_uds([0x10, 0x03])  # Response: 50 03 00 32 01 F4
```

### Security Access (0x27)

```python
# Request seed (Level 1)
send_uds([0x27, 0x01])  # Response: 67 01 [4-byte seed]

# Send key (Level 2)
send_uds([0x27, 0x02, key[0], key[1], key[2], key[3]])  # Response: 67 02
```

### Read Data By Identifier (0x22)

```python
# Read VIN (DID 0xF190)
send_uds([0x22, 0xF1, 0x90])  # Response: 62 F1 90 [17-byte VIN]

# Read Part Number (DID 0xF187)
send_uds([0x22, 0xF1, 0x87])  # Response: 62 F1 87 [part number]

# Read Software Version (DID 0xF195)
send_uds([0x22, 0xF1, 0x95])  # Response: 62 F1 95 [version]
```

### Write Data By Identifier (0x2E)

```python
# Write VIN (requires security access)
vin_bytes = [ord(c) for c in "1C3CDFBB0ED123456"]
send_uds([0x2E, 0xF1, 0x90] + vin_bytes)  # Response: 6E F1 90
```

### ECU Reset (0x11)

```python
# Hard reset
send_uds([0x11, 0x01])  # Response: 51 01

# Key off/on reset
send_uds([0x11, 0x02])  # Response: 51 02
```

### Clear Diagnostic Information (0x14)

```python
# Clear all DTCs
send_uds([0x14, 0xFF, 0xFF, 0xFF])  # Response: 54
```

---

## Troubleshooting Guide

### Issue: "J2534 DLL not found"

**Cause:** Driver not installed or incorrect path

**Solution:**
1. Reinstall device drivers
2. Verify DLL path in config.json
3. Check 32-bit vs 64-bit compatibility

### Issue: "Device in use by another application"

**Cause:** Another program has exclusive access to J2534 device

**Solution:**
1. Close all diagnostic software (Techstream, ISTA, etc.)
2. Restart J2534 Bridge
3. Reboot PC if issue persists

### Issue: "No response from ECU"

**Cause:** Physical connection, power, or addressing issue

**Solution:**
1. Verify OBD-II cable connection
2. Check vehicle ignition is ON
3. Confirm correct ECU address (0x728 for BCM, 0x72A for RFHUB)
4. Test with known-good diagnostic tool first

### Issue: "Negative response 0x7F 0x22 0x31"

**Cause:** Request out of range (DID not supported)

**Solution:**
1. Verify DID is supported by this ECU
2. Check diagnostic session (may need extended session)
3. Consult ECU documentation for valid DIDs

### Issue: "Security access denied"

**Cause:** Incorrect seed-key algorithm or ECU conditions not met

**Solution:**
1. Verify correct algorithm for ECU type
2. Check vehicle conditions (speed = 0, transmission in park)
3. Try clearing DTCs first
4. Ensure extended diagnostic session is active

---

## Performance Benchmarks

### Expected Response Times

| Operation | Expected Time | Acceptable Range |
|-----------|---------------|------------------|
| Device Open | 100-300ms | < 500ms |
| Channel Create | 50-150ms | < 300ms |
| UDS Request/Response | 20-100ms | < 200ms |
| Security Access (full) | 100-300ms | < 500ms |
| VIN Read | 50-150ms | < 300ms |
| VIN Write | 200-500ms | < 1000ms |
| ECU Reset | 500-2000ms | < 3000ms |

### Throughput Metrics

- **Maximum message rate:** 100-200 messages/second
- **Sustained throughput:** 50-100 messages/second
- **Burst capacity:** Up to 500 messages in 5 seconds

---

## Safety Guidelines

### ⚠️ CRITICAL WARNINGS

1. **NEVER program VIN on a vehicle without backup**
   - Always save original EEPROM dump before modifications
   - Verify backup integrity before proceeding

2. **NEVER interrupt VIN programming mid-process**
   - Ensure stable power supply
   - Do not disconnect cables during write operations
   - Wait for confirmation before resetting ECU

3. **NEVER program VIN on a vehicle you don't own**
   - VIN programming may be illegal in some jurisdictions
   - Only for authorized repair/research purposes

4. **ALWAYS verify VIN after programming**
   - Read back VIN to confirm successful write
   - Check all 4 VIN copies in BCM (if applicable)
   - Verify CRC checksums are valid

### Best Practices

1. **Use bench testing first**
   - Test all procedures on bench ECU before vehicle
   - Verify communication stability over extended periods

2. **Maintain clean power**
   - Use dedicated power supply for bench testing
   - Ensure vehicle battery is fully charged (> 12.5V)

3. **Document everything**
   - Log all operations with timestamps
   - Save before/after dumps
   - Record any errors or anomalies

4. **Test incrementally**
   - Start with read-only operations
   - Progress to non-critical writes
   - VIN programming should be last step

---

## Advanced Topics

### Custom Seed-Key Algorithms

To implement a custom seed-key algorithm:

```python
# server/seed_key_algorithms.py

def custom_algorithm(seed: bytes) -> bytes:
    """
    Custom seed-key calculation
    
    Args:
        seed: 4-byte seed from ECU
        
    Returns:
        4-byte key response
    """
    # Your algorithm here
    key = bytearray(4)
    # ... calculations ...
    return bytes(key)
```

### Multi-ECU Programming

For programming multiple ECUs in sequence:

```python
# test_scripts/multi_ecu_programming.py

ecus = [
    {"name": "BCM", "address": 0x728, "vin_did": 0xF190},
    {"name": "RFHUB", "address": 0x72A, "vin_did": 0xF190},
    {"name": "SmartBox", "address": 0x760, "vin_did": 0xF190},
]

for ecu in ecus:
    print(f"Programming {ecu['name']}...")
    program_vin(ecu['address'], ecu['vin_did'], new_vin)
    verify_vin(ecu['address'], ecu['vin_did'])
```

---

## Support & Resources

### Documentation

- [J2534 API Specification](https://www.sae.org/standards/content/j2534_201202/)
- [UDS Protocol ISO 14229](https://www.iso.org/standard/72439.html)
- [Chrysler Security Algorithms](./CHRYSLER_SECURITY_ALGORITHMS.md)

### Community

- GitHub Issues: Report bugs and request features
- Discord: Real-time support and discussions
- Forum: Share experiences and solutions

### Professional Support

For commercial deployments or custom integrations, contact the development team.

---

## Changelog

### v1.0.0 (2024-12-12)
- Initial release
- Support for Autel, Drew Tech, Tactrix devices
- UDS command library
- VIN programming workflows
- Comprehensive test suite

---

**Document Version:** 1.0.0  
**Last Updated:** December 12, 2024  
**Author:** The SRT Lab Development Team
