# CAN Bus Integration Guide
## Arduino + Web Application Complete Setup

This guide covers the complete integration of the Arduino CAN Bus Shield with the RFHUB BCM Toolkit web application.

---

## Hardware Setup

### Required Components

1. **Arduino Uno REV3** (ATmega328P)
2. **Seeed Studio CAN-Bus Shield V2** (MCP2515 + MCP2551)
3. **USB Cable** (Type A to Type B)
4. **OBD-II to DB9 Cable** OR **Bench Harness**
5. **12V Power Supply** (for bench testing)
6. **MicroSD Card** (optional, for logging)

### Assembly

```
1. Stack CAN-Bus Shield on top of Arduino Uno
   - Align all pins carefully
   - Press down firmly until seated

2. Insert MicroSD card (optional)
   - Format as FAT32
   - Used for offline logging

3. Connect OBD-II cable
   - CAN-H → Pin 7 (DB9)
   - CAN-L → Pin 2 (DB9)
   - GND → Pin 3 (DB9)

4. Connect USB cable
   - Arduino → Computer
   - Powers Arduino and provides serial communication
```

### Wiring Diagram

```
Vehicle OBD-II Port          DB9 Connector          CAN Shield
┌──────────────────┐        ┌──────────┐           ┌──────────┐
│  Pin 6: CAN-H    │───────→│ Pin 7    │──────────→│ CAN-H    │
│  Pin 14: CAN-L   │───────→│ Pin 2    │──────────→│ CAN-L    │
│  Pin 4,5: GND    │───────→│ Pin 3    │──────────→│ GND      │
│  Pin 16: +12V    │        └──────────┘           │          │
└──────────────────┘                               │ Arduino  │
                                                   │ Uno      │
                    USB Cable                      │          │
Computer ←──────────────────────────────────────→ │ USB Port │
                                                   └──────────┘
```

---

## Software Setup

### Step 1: Install Arduino IDE

1. Download Arduino IDE from https://www.arduino.cc/en/software
2. Install for your operating system
3. Launch Arduino IDE

### Step 2: Install Required Libraries

Open Arduino IDE → Tools → Manage Libraries

Install these libraries:

1. **Seeed CAN Bus Shield** by Seeed Studio
   - Version: Latest
   - Search: "CAN BUS Shield"

2. **ArduinoJson** by Benoit Blanchon
   - Version: 6.x or later
   - Search: "ArduinoJson"

### Step 3: Upload Firmware

1. Open `/arduino/CANBusMonitor/CANBusMonitor.ino`
2. Select board: Tools → Board → Arduino AVR Boards → Arduino Uno
3. Select port: Tools → Port → (your Arduino port)
4. Click Upload (→ button)
5. Wait for "Done uploading" message

### Step 4: Verify Installation

1. Open Serial Monitor (Tools → Serial Monitor)
2. Set baud rate to 115200
3. You should see:
   ```
   {"type":"heartbeat","uptime":1000,"rx":0,"tx":0,"errors":0}
   ```

---

## Web Application Integration

### Step 1: Access CAN Bus Monitor

1. Open the RFHUB BCM Toolkit web application
2. Navigate to **CAN Bus Monitor** from the home page
3. Click **"Connect Arduino"** button

### Step 2: Select Serial Port

1. Browser will show serial port selection dialog
2. Select your Arduino (usually shows as "Arduino Uno" or "USB Serial")
3. Click **"Connect"**

### Step 3: Verify Connection

You should see:
- ✅ Status: **Connected**
- ✅ Uptime counter increasing
- ✅ Green indicator light

---

## Using the CAN Bus Monitor

### Live CAN Traffic View

**What it does:**
- Shows all CAN messages in real-time
- Displays timestamp, ID, DLC, and data
- Auto-scrolls to latest messages

**Controls:**
- **Pause/Resume**: Stop/start message capture
- **Filter**: Search by CAN ID or data
- **Clear**: Remove all messages
- **Export**: Download as CSV file
- **Auto-scroll**: Toggle automatic scrolling

### Module Discovery

**What it does:**
- Automatically detects active modules
- Shows module name and CAN address
- Displays online/offline status
- Allows VIN requests per module

**Known Modules:**
- `0x7E0` - ECM (Engine Control Module)
- `0x7E1` - TCM (Transmission Control Module)
- `0x760` - BCM (Body Control Module)
- `0x765` - RFHUB (RF Hub)
- `0x7E4` - HVAC (Climate Control)
- `0x7E5` - ABS/ESP (Anti-lock Brakes)
- `0x7E6` - Airbag Control Module
- `0x7E7` - Instrument Cluster
- `0x2E0` - RFHUB Broadcast

### VIN Scanning

**How to scan:**
1. Connect Arduino to vehicle
2. Turn ignition to ON (don't start engine)
3. Click **"Scan VINs"** button
4. Wait 5 seconds
5. Check **Modules** tab for VIN responses

**What happens:**
- Arduino sends VIN request (Mode $09 PID $02) to all modules
- Modules respond with their stored VINs
- Web app displays VINs in module cards
- Mismatched VINs are highlighted

---

## Command Reference

### Serial Commands

Send these commands via Serial Monitor or web app:

| Command | Description | Example |
|---------|-------------|---------|
| `start` | Start CAN monitoring | `start` |
| `stop` | Stop CAN monitoring | `stop` |
| `scanvin` | Scan all modules for VINs | `scanvin` |
| `getvin:XXX` | Request VIN from specific module | `getvin:7E0` |
| `status` | Get Arduino status | `status` |

### JSON Message Format

**CAN Message:**
```json
{
  "type": "can_message",
  "id": "0x7E8",
  "dlc": 8,
  "data": "49 02 01 31 47 31 4A 43",
  "timestamp": 12345
}
```

**Heartbeat:**
```json
{
  "type": "heartbeat",
  "uptime": 60000,
  "rx": 1234,
  "tx": 56,
  "errors": 0
}
```

**VIN Response:**
```json
{
  "type": "vin_response",
  "module": "0x7E8",
  "vin": "1G1JC5SH4D7123456"
}
```

---

## Workflow Examples

### Example 1: Full Vehicle VIN Swap

**Goal:** Change VIN in all modules

1. **Discovery Phase:**
   - Connect Arduino to vehicle
   - Click "Scan VINs"
   - Note which modules store VINs
   - Export module list

2. **Dump Phase:**
   - Remove modules from vehicle
   - Dump EEPROMs via BDM/programmer
   - Upload dumps to toolkit

3. **Patch Phase:**
   - Use VIN Patcher to change VINs
   - Automatic checksum correction
   - Download patched files

4. **Flash Phase:**
   - Write patched files back to modules
   - Reinstall modules in vehicle

5. **Validation Phase:**
   - Connect Arduino
   - Click "Scan VINs"
   - Verify all modules show new VIN
   - Check for DTC codes

### Example 2: Security Byte Sync with Validation

**Goal:** Match BCM to SKIM security bytes

1. **Pre-Check:**
   - Scan VINs via CAN
   - Note any mismatches

2. **Sync:**
   - Upload SKIM and BCM files
   - Use Security Byte Sync tool
   - Download synced BCM

3. **Flash:**
   - Write synced BCM to module

4. **Validate:**
   - Connect Arduino
   - Monitor CAN for errors
   - Request VIN from BCM
   - Confirm no security faults

### Example 3: Module Compatibility Check

**Goal:** Verify modules will work together before installation

1. **Dump all modules:**
   - ECM EEPROM
   - BCM D-FLASH
   - RFHUB EEE

2. **Upload to Compatibility Checker**

3. **Review results:**
   - VIN matches
   - Security byte compatibility
   - Module pairing status

4. **If incompatible:**
   - Use toolkit to sync
   - Re-validate via CAN

---

## Troubleshooting

### Arduino Not Connecting

**Symptoms:**
- "Connect Arduino" button does nothing
- No serial port selection dialog

**Solutions:**
1. Use Chrome or Edge browser (Web Serial API required)
2. Check USB cable connection
3. Install Arduino drivers
4. Try different USB port
5. Restart browser

### No CAN Messages

**Symptoms:**
- Connected but no messages appear
- RX count stays at 0

**Solutions:**
1. Check OBD-II cable wiring
2. Verify vehicle ignition is ON
3. Check CAN bus speed (try 500kbps and 250kbps)
4. Verify shield is seated properly
5. Check for loose connections

### VIN Scan Returns Nothing

**Symptoms:**
- "Scan VINs" completes but no VINs found

**Solutions:**
1. Some modules don't respond to standard VIN requests
2. Module may be in sleep mode - cycle ignition
3. Try requesting from specific module addresses
4. Check if module stores VIN at all

### High Error Count

**Symptoms:**
- Error count increasing rapidly
- Garbled messages

**Solutions:**
1. Wrong CAN bus speed - try switching
2. Bad connection - check wiring
3. Termination resistor issue
4. Shield defect - try different shield

---

## Advanced Features

### SD Card Logging

If you have an SD card inserted:

1. Messages are automatically logged to `/logs/canXXXX.log`
2. New file created each session
3. CSV format for easy analysis
4. Can be imported into toolkit for offline analysis

### Custom CAN Filters

Edit Arduino code to filter specific IDs:

```cpp
// Only capture ECM messages
CAN.init_Mask(0, 0, 0x7FF);
CAN.init_Filt(0, 0, 0x7E0);
CAN.init_Filt(1, 0, 0x7E8);
```

### Bench Testing Setup

For testing modules on the bench:

```
1. Connect 12V power supply to module
2. Connect CAN-H and CAN-L to shield
3. Add 120Ω termination resistor across CAN-H/CAN-L
4. Ground module chassis to power supply ground
5. Turn on power
6. Module should appear in CAN traffic
```

---

## Safety & Legal

### ⚠️ Important Warnings

1. **Never modify VINs illegally** - This tool is for legitimate repair only
2. **Disconnect battery** before removing modules
3. **Use ESD protection** when handling modules
4. **Verify all connections** before powering on
5. **Keep backups** of all original files

### Legal Use Cases

✅ **Legitimate:**
- Replacing failed modules with used parts
- Repairing modules for your own vehicle
- Research and education
- Authorized repair shop use

❌ **Illegal:**
- VIN cloning for theft
- Odometer fraud
- Selling cloned modules
- Unauthorized dealer operations

---

## Support & Resources

### Documentation
- Arduino firmware: `/arduino/CANBusMonitor/`
- Web app code: `/client/src/pages/CANBusMonitor.tsx`
- Hardware guides: `/MC9S12XE_WIRING_DIAGRAMS.md`

### Community
- Chrysler/Dodge forums
- Arduino CAN bus communities
- Automotive electronics forums

### Tools
- Arduino IDE: https://www.arduino.cc/
- CAN Bus analyzer: SavvyCAN
- Wireshark with SocketCAN plugin

---

## Next Steps

Once you have CAN bus monitoring working:

1. **Expand module support** - Add more module types
2. **Implement DTC reading** - Read/clear diagnostic codes
3. **Live data monitoring** - Real-time sensor values
4. **Module programming** - Flash firmware via CAN
5. **Automated testing** - Batch validation scripts

**You now have a complete professional-grade automotive module toolkit!** 🚀

