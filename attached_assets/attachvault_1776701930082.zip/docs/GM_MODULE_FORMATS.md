# GM Module Formats & Algorithms

## Overview
General Motors (Chevrolet, Cadillac, GMC, Buick) uses different module architectures than Chrysler/FCA. This document outlines the known formats and algorithms.

## Module Types

### BCM (Body Control Module)
- **Processor**: Typically Freescale/NXP (MC9S12, MPC5xxx series)
- **Memory Layout**:
  - Flash: 512KB - 2MB
  - EEPROM: 4KB - 64KB
- **VIN Storage**: 
  - Primary location: EEPROM offset 0x0000-0x0010 (17 bytes ASCII)
  - Backup locations: Multiple copies in Flash
- **Checksum Algorithm**: CRC-32 (Ethernet standard, poly=0x04C11DB7)

### ECM/PCM (Engine/Powertrain Control Module)
- **Processor**: Motorola MPC5xx, Freescale S12X
- **Memory Layout**:
  - Calibration: 512KB - 1MB
  - Operating System: 256KB - 512KB
- **VIN Storage**:
  - EEPROM offset varies by year/model
  - Typically at 0x0400-0x0410
- **Checksum Algorithm**: 
  - Additive 16-bit checksum
  - CRC-16/XMODEM (poly=0x1021, init=0x0000)

### TCM (Transmission Control Module)
- **Processor**: Similar to ECM
- **VIN Storage**: EEPROM, manufacturer-specific offsets
- **Checksum**: CRC-16 or proprietary

## Security Bytes

### GM Security System
- **VATS (Vehicle Anti-Theft System)**: Resistor-based (older models)
- **PassKey/PassKey II**: Transponder-based
- **PassKey III/III+**: Rolling code encryption

### Security Byte Locations
- **BCM**: EEPROM offset 0x0100-0x0110 (16 bytes)
- **ECM**: EEPROM offset 0x0200-0x0210 (16 bytes)
- **Pairing**: BCM and ECM must have matching security seeds

## VIN Format
- **Standard**: 17-character alphanumeric (ISO 3779)
- **GM WMI Codes**:
  - `1G` - Chevrolet (USA)
  - `1GC` - Chevrolet Truck (USA)
  - `1G6` - Cadillac (USA)
  - `1GT` - GMC (USA)
  - `2G` - GM Canada
  - `3G` - GM Mexico

## Checksum Algorithms

### CRC-32 (BCM)
```python
def crc32_gm(data):
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte << 24
        for _ in range(8):
            if crc & 0x80000000:
                crc = (crc << 1) ^ 0x04C11DB7
            else:
                crc <<= 1
            crc &= 0xFFFFFFFF
    return crc ^ 0xFFFFFFFF
```

### CRC-16/XMODEM (ECM)
```python
def crc16_xmodem(data):
    crc = 0x0000
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc
```

### Additive 16-bit (ECM Calibration)
```python
def additive_16bit(data):
    checksum = 0
    for i in range(0, len(data), 2):
        word = (data[i] << 8) | data[i+1]
        checksum = (checksum + word) & 0xFFFF
    return (~checksum + 1) & 0xFFFF  # Two's complement
```

## Known Signatures

### GM BCM Signatures
- `GM` at offset 0x0000 (ASCII)
- `DELCO` at offset 0x0010 (ASCII)
- Part number format: `12345678` (8 digits)

### GM ECM Signatures
- `$0C` or `$0D` at offset 0x0000 (OS identifier)
- Calibration ID: 8-character ASCII at offset 0x0504

## Module Pairing Process

1. **Extract Security Seeds**:
   - Read BCM EEPROM offset 0x0100-0x0110
   - Read ECM EEPROM offset 0x0200-0x0210

2. **Cross-Write**:
   - Write BCM seed to ECM
   - Write ECM seed to BCM

3. **Verify**:
   - Both modules must have matching seeds
   - Checksum must be recalculated after write

## References
- GM Service Programming System (SPS)
- ACDelco TDS (Technical Data System)
- HP Tuners documentation
- EFILive documentation

## Notes
- GM modules typically require dealer-level programming tools for initial pairing
- Security algorithms vary significantly by year (2000-2010 vs 2010+)
- Newer models (2015+) use encrypted communication (harder to reverse engineer)

