# 🔥 third-party diagnostic software Complete Module List - Extracted from Screenshots

**Source:** third-party diagnostic software 2.5.6.0  
**Vehicle:** Dodge Challenger (LA)  
**Date:** October 28, 2025

---

## 📋 Complete Module List (20 Modules)

From Screenshot #5 - Function/ECUs dropdown:

| # | Module Code | Full Name | Function |
|---|-------------|-----------|----------|
| 1 | **ABS** | Anti-lock Brake System | Brake control |
| 2 | **AIRBAG** | Occupant Restraint Controller (ORC) | Airbag system |
| 3 | **BODY COMPUTER** | Body Control Module (BCM) | Body electronics |
| 4 | **CLIMATE CONTROL** | Climate Control Module (CCM/HVAC) | A/C and heating |
| 5 | **CRUISE CONTROL** | Adaptive Cruise Control | Speed control |
| 6 | **DRIVER DOOR** | Driver Door Module (DDM) | Driver door functions |
| 7 | **PASSENGER DOOR** | Passenger Door Module (PDM) | Passenger door functions |
| 8 | **ELECTRONIC SHIFTER** | Electronic Shifter Module | Transmission shifter |
| 9 | **ENGINE** | Engine Control Module (ECM/PCM) | Engine management |
| 10 | **INSTRUMENT PANEL** | Instrument Panel Cluster Module (IPCM) | Gauges and displays |
| 11 | **OBJECT DETECTION** | Park Assist Module (PAM) | Parking sensors |
| 12 | **PARKING** | Parking Brake Module | Electronic parking brake |
| 13 | **RADIO FREQUENCY HUB (RFH)** | RF Hub / SKIM | Key fob and immobilizer |
| 14 | **RADIO** | Radio / Infotainment | Audio system |
| 15 | **STEERING** | Power Steering Module (EPS) | Electric power steering |
| 16 | **STEERING COLUMN CONTROL MODULE** | Steering Column Control Module (SCCM) | Column functions |
| 17 | **SUSPENSION** | Active Dampening Module (ADM/SDM) | Adaptive suspension |
| 18 | **TRANSMISSION** | Transmission Control Module (TCM) | Transmission control |
| 19 | **FOUR-WHEEL DRIVE** | Transfer Case Control Module (TCCM) | 4WD system |
| 20 | **TIRE CONTROL** | Tire Pressure Monitoring System (TPMS) | Tire pressure |
| 21 | **SECURITY GATEWAY MODULE (SGW)** | Security Gateway Module | CAN gateway security |

---

## 🔑 Key Functions Discovered

### **RFHUB/SKIM Functions (Screenshot #6):**

**Actuator Tests:**
- Antenna power
- KIN LED control
- ESCL 12 Volt feed control
- Door handle power control
- Clutch signal to ECM output control
- Redundant ignition RUN/START feed output control
- BTSI (Brake Transmission Shift Interlock) output control

**Diagnostic Tests:**
- View Ignition (IGNM/KIN) Part Information
- Door Handle Verification Test
- Immobilizer Antenna Test
- LF Antenna Verification Test
- Remote Start Antenna Test
- Locate Learned Keys
- Sensor Rolls Test

**Programming Functions:**
- Clear Multi-Module VIN Handshake Immobilizer Failure
- Program Tire Sensor Identifications
- RF-HUB Reset/Replace
- Program Ignition FOBIKs Baseline System
- Lock Ignition FOBIKs Baseline System
- Program Ignition FOBIKs Highline System
- Program Ignition FOBIKs
- Erase ignition FOBIKs
- **BCM Replaced** (Screenshot #7) - Creates BCM backup of secret key from RF-HUB
- ELV/ESCL (Electric Steering Column Lock) replaced
- Perform ESCL Re-Marriage Procedure
- Check FOBIK product type
- Loop test for immobilizer system
- Clear TPM Sensor Audit
- **Read PIN** (Screenshot #8) - Reads PIN from RFH memory
- Reset ECU

---

## 🎯 Critical Discoveries

### **1. BCM Replaced Function**
**Description:** "RAM only. Use this function when the BCM has been replaced. It will create the BCM backup of the secret key value stored in the RF-HUB."

**What this means:**
- third-party diagnostic software can **sync security keys** between BCM and RFHUB
- Required after BCM replacement
- Reads secret key from RFHUB
- Writes it to new BCM
- **This is the module pairing/marriage procedure!**

### **2. Read PIN Function**
**Description:** "This procedure reads the PIN from the RFH memory. If the procedure terminates with an error retry with the ignition set to OFF or Lock position."

**What this means:**
- third-party diagnostic software can **extract SKIM PIN code**
- PIN is stored in RFHUB memory
- Used for key programming
- **This is what DARKVIN LABS PIN Extractor does!**

### **3. FOBIK Programming**
**Multiple functions:**
- Program Ignition FOBIKs Baseline System
- Program Ignition FOBIKs Highline System  
- Lock/Erase FOBIKs
- Locate Learned Keys

**What this means:**
- third-party diagnostic software can **program new key fobs**
- Supports both Baseline and Highline systems
- Can lock out old keys
- Can inventory programmed keys

---

## 📊 Module Comparison

| Module | DARKVIN LABS (Before) | third-party diagnostic software (Extracted) | Status |
|--------|----------------------|---------------------|--------|
| BCM | ✅ | ✅ | Match |
| ECM | ✅ | ✅ ENGINE | Match |
| TCM | ✅ | ✅ TRANSMISSION | Match |
| RFHUB | ✅ | ✅ RADIO FREQUENCY HUB | Match |
| ABS | ✅ | ✅ | Match |
| CCM | ✅ | ✅ CLIMATE CONTROL | Match |
| ADM/SDM | ✅ | ✅ SUSPENSION | Match |
| IPCM | ❌ | ✅ INSTRUMENT PANEL | **Need to add** |
| ORC | ❌ | ✅ AIRBAG | **Need to add** |
| DDM | ❌ | ✅ DRIVER DOOR | **Need to add** |
| PDM | ❌ | ✅ PASSENGER DOOR | **Need to add** |
| EPS | ❌ | ✅ STEERING | **Need to add** |
| SCCM | ❌ | ✅ STEERING COLUMN CONTROL | **Need to add** |
| PAM | ❌ | ✅ OBJECT DETECTION | **Need to add** |
| TCCM | ❌ | ✅ FOUR-WHEEL DRIVE | **Need to add** |
| TPMS | ❌ | ✅ TIRE CONTROL | **Need to add** |
| SGW | ❌ | ✅ SECURITY GATEWAY MODULE | **Need to add** |
| ACC | ❌ | ✅ CRUISE CONTROL | **Need to add** |
| ESM | ❌ | ✅ ELECTRONIC SHIFTER | **Need to add** |
| EPB | ❌ | ✅ PARKING | **Need to add** |
| RADIO | ❌ | ✅ | **Need to add** |

**Current:** 8 modules  
**third-party diagnostic software:** 21 modules  
**Missing:** 13 modules

---

## 🚀 Next Steps

### **Immediate Actions:**

1. **Add 13 missing modules to DARKVIN LABS**
   - IPCM, ORC, DDM, PDM, EPS, SCCM, PAM, TCCM, TPMS, SGW, ACC, ESM, EPB, RADIO

2. **Research CAN addresses for new modules**
   - Use standard automotive CAN address patterns
   - Test with module scanner
   - Verify on real vehicle

3. **Implement BCM Replaced function**
   - Read secret key from RFHUB
   - Write to new BCM
   - Module marriage/pairing

4. **Implement Read PIN function**
   - Extract SKIM PIN from RFHUB
   - Already have this in PIN Extractor
   - Add to OBD2 live interface

5. **Implement FOBIK programming**
   - Program new key fobs
   - Lock/erase old keys
   - Locate learned keys

---

## 💡 Key Insights

### **What third-party diagnostic software Can Do (That We Need):**

1. **Module Marriage/Pairing**
   - BCM ↔ RFHUB secret key sync
   - ESCL re-marriage
   - Multi-module VIN handshake

2. **Key Fob Programming**
   - Program new FOBIKs
   - Erase old FOBIKs
   - Locate learned keys
   - Baseline vs. Highline systems

3. **Security Functions**
   - Read PIN from RFHUB
   - Clear immobilizer failures
   - Check FOBIK product type

4. **Configuration Coding**
   - Special packages (70th Anniversary, 300S, BEATS, Super Bee, Mopar/Sport, Hellcat, Scat Pack, etc.)
   - Performance features
   - Vehicle-specific options

---

## 📋 third-party diagnostic software vs DARKVIN LABS

### **What third-party diagnostic software Has (That We Don't):**

✅ 21 modules (vs our 8)  
✅ BCM replacement procedure  
✅ Key fob programming  
✅ PIN extraction (we have this in toolkit, need in web UI)  
✅ Configuration coding (special packages)  
✅ Module marriage/pairing  
✅ ESCL re-marriage  

### **What DARKVIN LABS Has (That third-party diagnostic software Doesn't):**

✅ Automated VIN programming script  
✅ Batch processing  
✅ Module scanner (building)  
✅ CAN bus sniffer  
✅ Web interface  
✅ Arduino support  
✅ Open source  
✅ Free  

---

## 🎯 Implementation Priority

### **High Priority (Add Now):**

1. **IPCM** - Instrument Panel Cluster
2. **ORC** - Airbag/Occupant Restraint
3. **SGW** - Security Gateway (critical for multi-module access)
4. **EPS** - Electric Power Steering
5. **SCCM** - Steering Column Control

### **Medium Priority:**

6. **DDM/PDM** - Door modules
7. **PAM** - Park assist
8. **TPMS** - Tire pressure
9. **ACC** - Adaptive cruise control
10. **ESM** - Electronic shifter

### **Low Priority:**

11. **TCCM** - Transfer case (4WD only)
12. **EPB** - Electronic parking brake
13. **RADIO** - Infotainment

---

## 📸 Screenshot Summary

1. **Car configuration change** - BCM coding options
2. **Special packages dropdown** - Vehicle-specific configurations
3. **More special packages** - SRT, Hellcat, Trackhawk variants
4. **Even more packages** - Challenger/Charger SRT variants
5. **MODULE LIST** - Complete 21-module function dropdown ⭐
6. **RFHUB functions** - Actuator tests and diagnostics
7. **BCM Replaced** - Module marriage procedure
8. **Read PIN** - SKIM PIN extraction

---

**This is GOLD! We now have the complete third-party diagnostic software module list and key functions!** 🔥

Next: Add all 13 missing modules to DARKVIN LABS and implement BCM replacement + key programming features!

