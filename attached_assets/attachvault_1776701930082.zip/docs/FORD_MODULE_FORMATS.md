# Ford Module Formats & Algorithms

## Overview
Ford Motor Company (Ford, Lincoln, Mercury) uses PATS (Passive Anti-Theft System) and later GEM/BCM architectures. This document outlines known formats and algorithms.

## Module Types

### BCM/GEM (Generic Electronic Module)
- **Processor**: Motorola HC12, Freescale S12X
- **Memory Layout**:
  - Flash: 256KB - 1MB
  - EEPROM: 2KB - 32KB
- **VIN Storage**:
  - Primary: EEPROM offset 0x0010-0x0020 (17 bytes ASCII)
  - Backup: Flash offset varies by model
- **Checksum Algorithm**: CRC-16/MODBUS (poly=0x8005, init=0xFFFF)

### PCM (Powertrain Control Module)
- **Processor**: Motorola MPC5xx, Freescale MPC5xxx
- **Memory Layout**:
  - Calibration: 512KB - 2MB
  - Operating System: 256KB - 512KB
- **VIN Storage**:
  - EEPROM offset 0x0100-0x0110
- **Checksum Algorithm**:
  - CRC-32 (poly=0x04C11DB7)
  - Additive 32-bit checksum

### PATS Module (Passive Anti-Theft System)
- **Processor**: Dedicated security processor
- **Memory**: 93C46/93C56 EEPROM (128-256 bytes)
- **Key Storage**: Encrypted transponder keys
- **VIN Storage**: Offset 0x0000-0x0010

## Security Systems

### PATS (1996-2010)
- **Transponder Types**: 
  - H-chip (40-bit)
  - H+ chip (80-bit)
  - 4D (128-bit encrypted)
- **Key Programming**: Requires two programmed keys or dealer tool
- **Security Bytes**: 8-byte seed at EEPROM offset 0x0020

### SecuriCode (2011+)
- **Rolling Code**: 128-bit AES encryption
- **Key Fob**: RF + transponder
- **Security Bytes**: 16-byte seed at offset 0x0040

## VIN Format
- **Standard**: 17-character alphanumeric (ISO 3779)
- **Ford WMI Codes**:
  - `1FA` - Ford (USA)
  - `1FM` - Ford Truck (USA)
  - `1FT` - Ford Truck (USA)
  - `1LN` - Lincoln (USA)
  - `2FA` - Ford Canada
  - `3FA` - Ford Mexico

## Checksum Algorithms

### CRC-16/MODBUS (BCM/GEM)
```python
def crc16_modbus(data):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc
```

### CRC-32 (PCM)
```python
def crc32_ford(data):
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x00000001:
                crc = (crc >> 1) ^ 0xEDB88320
            else:
                crc >>= 1
    return crc ^ 0xFFFFFFFF
```

### Additive 32-bit (PCM Calibration)
```python
def additive_32bit(data):
    checksum = 0
    for i in range(0, len(data), 4):
        dword = (data[i] << 24) | (data[i+1] << 16) | (data[i+2] << 8) | data[i+3]
        checksum = (checksum + dword) & 0xFFFFFFFF
    return (~checksum + 1) & 0xFFFFFFFF  # Two's complement
```

## Known Signatures

### Ford BCM/GEM Signatures
- `FORD` at offset 0x0000 (ASCII)
- Part number format: `XXXXX-XXXXX-XX` (e.g., `7T4T-14B321-AA`)
- Hardware version at offset 0x0020

### Ford PCM Signatures
- Strategy code: 8-character ASCII at offset 0x0000
- Calibration ID: 8-character ASCII at offset 0x0010
- `EEC-V` or `EEC-VI` identifier

### PATS Signatures
- `PATS` at offset 0x0000
- Transponder count at offset 0x0010 (1 byte)
- Key type identifier at offset 0x0011

## Module Pairing Process

### PATS Programming
1. **Extract Security Seed**:
   - Read PATS module EEPROM offset 0x0020-0x0027 (8 bytes)

2. **Cross-Write to PCM**:
   - Write PATS seed to PCM EEPROM offset 0x0100-0x0107

3. **Program Transponder Keys**:
   - Requires two existing programmed keys OR
   - Dealer-level tool (IDS/FDRS)

### BCM/PCM Pairing
1. **Extract VIN from BCM**
2. **Write VIN to PCM**
3. **Verify checksums match**
4. **Program configuration blocks**

## PATS Key Types

### Type 1 (H-Chip)
- **Frequency**: 125 kHz
- **Encryption**: 40-bit fixed code
- **Years**: 1996-2000
- **Programming**: Two-key method

### Type 2 (H+ Chip)
- **Frequency**: 125 kHz
- **Encryption**: 80-bit rolling code
- **Years**: 2001-2007
- **Programming**: Two-key method or dealer tool

### Type 3 (4D Chip)
- **Frequency**: 125 kHz
- **Encryption**: 128-bit AES
- **Years**: 2008-2010
- **Programming**: Dealer tool required

### Type 4 (SecuriCode)
- **Frequency**: 315/433 MHz RF + 125 kHz transponder
- **Encryption**: 128-bit AES rolling code
- **Years**: 2011+
- **Programming**: Dealer tool required

## OBD-II Programming

### Ford IDS (Integrated Diagnostic Software)
- **Protocol**: ISO 15765 (CAN)
- **Security Access**: Level 1 (read), Level 2 (write)
- **Services**:
  - 0x10: Diagnostic Session Control
  - 0x27: Security Access
  - 0x31: Routine Control
  - 0x34/0x36: Request Download/Transfer Data

### FDRS (Ford Diagnostic and Repair System)
- **Successor to IDS**: 2017+
- **Cloud-based**: Requires internet connection
- **Module Programming**: Full reflash capability

## References
- Ford Service Manual (FSM)
- Ford IDS/FDRS documentation
- SCT/Diablosport tuning documentation
- HP Tuners Ford support
- ForScan tool documentation

## Notes
- PATS programming typically requires two existing programmed keys
- Dealer tools (IDS/FDRS) required for 2011+ models
- Security algorithms significantly changed in 2011 (SecuriCode)
- Some modules require "as-built" configuration data from Ford servers

