# 🔥 HARDWARE INTEGRATION GUIDE

**Connect Real CAN Hardware to DARKVIN LABS Toolkit**

---

## 📋 OVERVIEW

The toolkit now supports **real CAN communication** with vehicles via:
- **SocketCAN** (Linux native, Raspberry Pi)
- **ELM327** (USB/Bluetooth adapters)
- **J2534 PassThru** (Professional diagnostic tools)

---

## 🚀 QUICK START

### **1. Install python-can (Raspberry Pi / Linux)**

```bash
# On Raspberry Pi or Linux
sudo apt update
sudo apt install -y python3-pip can-utils
pip3 install python-can python-can[serial]

# Verify installation
python3 -c "import can; print('python-can installed!')"
```

### **2. Test CAN Interface**

```bash
cd /home/pi/rfhub-bcm-toolkit/toolkit

# Test with mock mode (no hardware)
python3 can_interface.py --interface mock

# Test with real SocketCAN
python3 can_interface.py --interface socketcan --channel can0

# Test with ELM327
python3 can_interface.py --interface elm327 --channel /dev/ttyUSB0
```

---

## 🔌 HARDWARE SETUP

### **Option 1: SocketCAN (Recommended for Raspberry Pi)**

**Hardware:**
- Waveshare RS485/CAN HAT
- MCP2515 CAN controller
- SPI interface

**Setup:**

```bash
# Enable SPI
sudo raspi-config
# Interface Options → SPI → Enable

# Configure device tree overlay
sudo nano /boot/config.txt

# Add these lines:
dtparam=spi=on
dtoverlay=mcp2515-can0,oscillator=12000000,interrupt=25
dtoverlay=spi-bcm2835-overlay

# Reboot
sudo reboot

# Configure CAN interface
sudo ip link set can0 type can bitrate 500000
sudo ip link set can0 up

# Verify
ifconfig can0
candump can0
```

**Auto-start on boot:**

```bash
# Create network config
sudo nano /etc/network/interfaces.d/can0

# Add:
auto can0
iface can0 inet manual
    pre-up /sbin/ip link set can0 type can bitrate 500000
    up /sbin/ifconfig can0 up
    down /sbin/ifconfig can0 down
```

---

### **Option 2: ELM327 Adapter**

**Hardware:**
- ELM327 USB adapter
- ELM327 Bluetooth adapter
- Compatible with OBD2 port

**USB Setup:**

```bash
# Find device
ls /dev/ttyUSB*
# Usually /dev/ttyUSB0

# Test connection
python3 can_interface.py --interface elm327 --channel /dev/ttyUSB0
```

**Bluetooth Setup:**

```bash
# Pair device
bluetoothctl
scan on
pair XX:XX:XX:XX:XX:XX
trust XX:XX:XX:XX:XX:XX
connect XX:XX:XX:XX:XX:XX

# Create serial port
sudo rfcomm bind 0 XX:XX:XX:XX:XX:XX

# Test connection
python3 can_interface.py --interface elm327 --channel /dev/rfcomm0
```

---

### **Option 3: J2534 PassThru (Professional)**

**Hardware:**
- Kvaser Leaf Light HS
- PEAK PCAN-USB
- Drew Technologies Mongoose
- Any J2534-compatible device

**Setup:**

```bash
# Install device drivers (vendor-specific)
# Example for PEAK PCAN:
wget https://www.peak-system.com/fileadmin/media/linux/files/peak-linux-driver-8.16.0.tar.gz
tar -xzf peak-linux-driver-8.16.0.tar.gz
cd peak-linux-driver-8.16.0
make
sudo make install

# Load kernel module
sudo modprobe peak_usb

# Verify
lsusb | grep PEAK
```

---

## 🔧 USAGE EXAMPLES

### **Read VIN from BCM**

```bash
cd /home/pi/rfhub-bcm-toolkit/toolkit

# Using SocketCAN
python3 can_interface.py \
  --interface socketcan \
  --channel can0 \
  --tx 0x7E0 \
  --rx 0x7E8

# Using ELM327
python3 can_interface.py \
  --interface elm327 \
  --channel /dev/ttyUSB0 \
  --tx 0x7E0 \
  --rx 0x7E8
```

**Expected Output:**

```
============================================================
CAN INTERFACE TEST
============================================================
Interface: socketcan
Channel: can0
TX ID: 0x7E0
RX ID: 0x7E8
============================================================

[✓] Connected to SocketCAN: can0

[1/5] Enter programming session...
[TX] 7E0: 10 02
[RX] 7E8: 50 02 00 00 00 00 00 00
[✓] Entered diagnostic session: 0x02

[2/5] Request security seed...
[TX] 7E0: 27 01
[RX] 7E8: 67 01 2E 2A 00 00 00 00
[✓] Security seed: 0x2E2A

[3/5] Calculate security key...
[✓] Calculated key: 0x48C0 (SBEC algorithm)

[4/5] Send security key...
[TX] 7E0: 27 02 48 C0
[RX] 7E8: 67 02 00 00 00 00 00 00
[✓] Security access granted

[5/5] Read VIN...
[TX] 7E0: 22 F1 90
[RX] 7E8: 62 F1 90 32 43 33 43 43 41 47 47 30 47 48 31 36 37 39 33 35
[✓] VIN: 2C3CCAGG0GH167935

============================================================
TEST COMPLETE
============================================================
[✓] Disconnected
```

---

## 🎯 MODULE CAN IDS

| Module | TX ID | RX ID | Description |
|--------|-------|-------|-------------|
| **BCM** | 0x7E0 | 0x7E8 | Body Control Module |
| **ECM** | 0x7E0 | 0x7E8 | Engine Control Module |
| **TCM** | 0x7E1 | 0x7E9 | Transmission Control Module |
| **ABS** | 0x7E2 | 0x7EA | Anti-lock Braking System |
| **RFHUB** | 0x742 | 0x762 | RF Hub (Wireless Control) |
| **CCM** | 0x743 | 0x763 | Clock/Compass Module |
| **SKIM** | 0x744 | 0x764 | Sentry Key Immobilizer |

---

## 🔍 TROUBLESHOOTING

### **CAN Interface Not Found**

```bash
# Check if interface exists
ifconfig can0

# Check kernel modules
lsmod | grep can

# Load modules manually
sudo modprobe can
sudo modprobe can_raw
sudo modprobe mcp251x
```

### **No Response from ECU**

```bash
# Check CAN bus activity
candump can0

# Check bitrate
ip -details link show can0

# Try different bitrate
sudo ip link set can0 down
sudo ip link set can0 type can bitrate 250000
sudo ip link set can0 up
```

### **Permission Denied**

```bash
# Add user to dialout group (for serial devices)
sudo usermod -a -G dialout $USER

# Reboot or re-login
sudo reboot
```

### **ELM327 Not Responding**

```bash
# Test with screen
screen /dev/ttyUSB0 38400

# Send AT commands
ATZ          # Reset
ATE0         # Echo off
ATL0         # Linefeeds off
ATSP6        # Set protocol to ISO 15765-4 CAN (500kbps)
0100         # Request supported PIDs

# Exit screen: Ctrl+A, then K
```

---

## 📊 PYTHON API USAGE

### **Basic Example**

```python
from toolkit.can_interface import CANInterface, UDSClient

# Connect to CAN
can = CANInterface("socketcan", "can0")
can.connect()

# Create UDS client
uds = UDSClient(can, tx_id=0x7E0, rx_id=0x7E8)

# Enter programming session
uds.diagnostic_session_control(0x02)

# Request security access
seed = uds.security_access_request_seed(0x01)
key = uds.calculate_security_key(seed, "sbec")
uds.security_access_send_key(0x02, key)

# Read VIN
vin = uds.read_vin()
print(f"VIN: {vin}")

# Write new VIN
uds.write_vin("2B3CJ5DT2BH590794")

# Disconnect
can.disconnect()
```

### **Advanced Example: Full VIN Programming**

```python
from toolkit.can_interface import CANInterface, UDSClient
import time

def program_vin(interface, channel, tx_id, rx_id, new_vin):
    """Complete VIN programming sequence"""
    
    # Connect
    can = CANInterface(interface, channel)
    if not can.connect():
        return False
    
    uds = UDSClient(can, tx_id, rx_id)
    
    try:
        # Step 1: Enter programming session
        print("[1/9] Enter programming session...")
        uds.diagnostic_session_control(0x02)
        time.sleep(0.5)
        
        # Step 2: Start TesterPresent
        print("[2/9] Start TesterPresent...")
        can.start_tester_present()
        
        # Step 3: Request security seed
        print("[3/9] Request security seed...")
        seed = uds.security_access_request_seed(0x01)
        if not seed:
            return False
        
        # Step 4: Calculate key
        print("[4/9] Calculate security key...")
        key = uds.calculate_security_key(seed, "sbec")
        
        # Step 5: Send key
        print("[5/9] Send security key...")
        if not uds.security_access_send_key(0x02, key):
            return False
        time.sleep(0.5)
        
        # Step 6: Write VIN
        print("[6/9] Write VIN...")
        if not uds.write_vin(new_vin):
            return False
        time.sleep(0.5)
        
        # Step 7: Calculate checksum
        print("[7/9] Calculate checksum...")
        uds.routine_control(0x0203, 0x01)
        time.sleep(0.5)
        
        # Step 8: Reset ECU
        print("[8/9] Reset ECU...")
        uds.ecu_reset(0x01)
        time.sleep(2.0)
        
        # Step 9: Verify VIN
        print("[9/9] Verify VIN...")
        read_vin = uds.read_vin()
        if read_vin == new_vin:
            print(f"[✓] SUCCESS: VIN programmed to {new_vin}")
            return True
        else:
            print(f"[✗] FAILED: VIN mismatch")
            return False
            
    finally:
        can.stop_tester_present()
        can.disconnect()

# Usage
program_vin("socketcan", "can0", 0x7E0, 0x7E8, "2B3CJ5DT2BH590794")
```

---

## ⚠️ SAFETY WARNINGS

1. **Always disconnect battery** before connecting CAN hardware
2. **Never write VIN to wrong module** - verify module ID first
3. **Keep ignition ON** during programming (engine OFF)
4. **Don't interrupt programming** - can brick module
5. **Backup original VIN** before writing new one
6. **Test on bench** before installing in vehicle
7. **Use proper 12V power supply** (not USB power)
8. **Check CAN termination** (120Ω resistor)

---

## 📚 ADDITIONAL RESOURCES

**CAN Bus:**
- [SocketCAN Documentation](https://www.kernel.org/doc/html/latest/networking/can.html)
- [python-can Documentation](https://python-can.readthedocs.io/)
- [CAN Bus Explained](https://www.csselectronics.com/pages/can-bus-simple-intro-tutorial)

**UDS Protocol:**
- [ISO 14229 Standard](https://www.iso.org/standard/72439.html)
- [UDS Protocol Tutorial](https://automotive.wiki/index.php/ISO_14229)
- [OBD2 DTC Codes](https://www.obd-codes.com/)

**Hardware:**
- [Waveshare CAN HAT](https://www.waveshare.com/wiki/RS485_CAN_HAT)
- [ELM327 Commands](https://www.elmelectronics.com/wp-content/uploads/2017/01/ELM327DS.pdf)
- [J2534 API](https://www.drewtech.com/support/passthru.html)

---

## 🔥 NEXT STEPS

1. **Test on bench** - Connect CAN hardware to module on workbench
2. **Read VIN** - Verify communication with `read_vin()`
3. **Backup data** - Save original VIN and security bytes
4. **Test write** - Program VIN to test module
5. **Verify** - Read back and confirm VIN matches
6. **Deploy** - Install in vehicle for field use

---

**DARKVIN LABS - REAL HARDWARE, REAL POWER!** 🔥

