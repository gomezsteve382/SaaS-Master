# Critical VIN Patcher Bug Fix - December 1, 2025

## Bug Summary

The production VIN patcher was writing VINs to **wrong offsets**, causing VIN patching to fail silently. The patcher reported success but the VINs were not actually changed in the file.

## Root Cause

**File:** `toolkit/production_vin_patcher.py`  
**Line:** 163  
**Issue:** Incorrect boolean logic in BCM variant detection

### Original Code (BROKEN)
```python
if data[0x4097] == 0xFF or data[0x4098:0x40A0] != b'\xFF' * 8:
    # Extended or DFLASH BCM
```

This condition uses **OR**, which means:
- If `data[0x4097] == 0xFF` → TRUE → enters Extended/DFLASH branch
- Even if the file is Extended Standard BCM (Variant A/B)

### Fixed Code
```python
if data[0x4097] != 0xFF or data[0x4098:0x40A0] != b'\xFF' * 8:
    # Extended or DFLASH BCM
```

Changed `==` to `!=` so the logic correctly identifies:
- **Extended/DFLASH BCM:** Has data at 0x4098 (not all 0xFF)
- **Extended Standard BCM:** Has 0xFF at both 0x4097 and 0x4098-0x409F

## Impact

### Before Fix
- Extended Standard BCM files (Variant A/B) were misidentified as Extended/DFLASH BCM
- VINs were written to wrong offsets (0x5328, 0x5348, 0x5368, 0x5388)
- Actual VIN locations (0x1298, 0x12B8, 0x12D8, 0x12F8) were not patched
- Patcher reported success but VINs remained unchanged

### After Fix
- Extended Standard BCM files correctly identified as Variant A
- VINs written to correct offsets (0x1298, 0x12B8, 0x12D8, 0x12F8)
- All 4 VIN locations successfully patched
- CRC checksums correctly calculated and fixed

## Test Results

### Test File
- **File:** BCMDFLASH16CHALL6.2_OG.bin (64KB)
- **Original VIN:** 2C3CDZC98GH157477
- **Target VIN:** 2C3CDXGJ3KH753775

### Verification
```bash
# Before fix
VIN at 0x1298: 2C3CDZC98GH157477  ← NOT CHANGED
VIN at 0x12b8: 2C3CDZC98GH157477  ← NOT CHANGED
VIN at 0x12d8: 2C3CDZC98GH157477  ← NOT CHANGED
VIN at 0x12f8: 2C3CDZC98GH157477  ← NOT CHANGED

# After fix
VIN at 0x1298: 2C3CDXGJ3KH753775  ✅ PATCHED
VIN at 0x12b8: 2C3CDXGJ3KH753775  ✅ PATCHED
VIN at 0x12d8: 2C3CDXGJ3KH753775  ✅ PATCHED
VIN at 0x12f8: 2C3CDXGJ3KH753775  ✅ PATCHED
```

## BCM Variant Detection Logic

### Extended Standard BCM (Variant A)
- **Detection:** `data[0x4097] == 0xFF` AND `data[0x4098:0x40A0] == b'\xFF' * 8` AND `data[0x1298] != 0xFF`
- **VIN Offsets:** 0x1298, 0x12B8, 0x12D8, 0x12F8
- **Example:** BCMDFLASH16CHALL6.2_OG.bin

### Extended Standard BCM (Variant B)
- **Detection:** `data[0x4097] == 0xFF` AND `data[0x4098:0x40A0] == b'\xFF' * 8` AND `data[0x1328] != 0xFF`
- **VIN Offsets:** 0x1328, 0x1348, 0x1368, 0x1388

### Extended/DFLASH BCM
- **Detection:** `data[0x4097] != 0xFF` OR `data[0x4098:0x40A0] != b'\xFF' * 8`
- **VIN Offsets:** 0x52B8, 0x52D8, 0x52F8, 0x5318 (DFLASH) or 0x5328, 0x5348, 0x5368, 0x5388 (Extended)

## Recommendation

This fix should be applied to ALL production VIN patcher implementations to ensure correct VIN patching across all BCM variants.
