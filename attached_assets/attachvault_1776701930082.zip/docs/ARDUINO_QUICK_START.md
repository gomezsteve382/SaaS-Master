# Arduino CAN Bus - Quick Start Guide
## Get Up and Running in 15 Minutes

This guide will get your Arduino CAN Bus Shield connected and monitoring your vehicle in 15 minutes.

---

## What You Need

✅ Arduino Uno REV3  
✅ Seeed Studio CAN-Bus Shield V2  
✅ USB Cable (Type A to B)  
✅ OBD-II to DB9 cable OR bench harness  
✅ Computer with Chrome or Edge browser  

---

## Step 1: Hardware Assembly (2 minutes)

1. **Stack the shield on Arduino**
   - Align all pins
   - Press down firmly
   - Should sit flush

2. **Connect USB cable**
   - Arduino → Computer
   - Wait for driver installation (Windows)

---

## Step 2: Software Setup (5 minutes)

### Install Arduino IDE

1. Download from https://www.arduino.cc/en/software
2. Install and launch

### Install Libraries

1. Open: **Tools → Manage Libraries**
2. Search and install:
   - `Seeed CAN Bus Shield` (by Seeed Studio)
   - `ArduinoJson` (by Benoit Blanchon, version 6.x)

---

## Step 3: Upload Firmware (3 minutes)

1. **Open sketch:**
   - File → Open → `/arduino/CANBusMonitor/CANBusMonitor.ino`

2. **Select board:**
   - Tools → Board → Arduino AVR Boards → **Arduino Uno**

3. **Select port:**
   - Tools → Port → (your Arduino, usually `/dev/ttyACM0` or `COM3`)

4. **Upload:**
   - Click the **→** (Upload) button
   - Wait for "Done uploading"

5. **Verify:**
   - Tools → Serial Monitor
   - Set baud rate to **115200**
   - You should see JSON heartbeat messages

---

## Step 4: Connect to Vehicle (2 minutes)

### Option A: Via OBD-II Port

```
1. Locate OBD-II port (usually under steering wheel)
2. Plug in OBD-II to DB9 cable
3. Connect DB9 to CAN shield
4. Turn ignition to ON (don't start engine)
```

### Option B: Bench Testing

```
1. Connect module to 12V power supply
2. Wire CAN-H and CAN-L to shield
3. Add 120Ω resistor across CAN-H/CAN-L
4. Connect grounds
5. Power on
```

---

## Step 5: Web App Connection (3 minutes)

1. **Open toolkit:**
   - Navigate to RFHUB BCM Toolkit
   - Click **"CAN Bus Monitor"**

2. **Connect Arduino:**
   - Click **"Connect Arduino"** button
   - Select your Arduino from the list
   - Click **"Connect"**

3. **Verify:**
   - Status should show **"Connected"**
   - Green indicator light
   - Uptime counter increasing

---

## You're Done! 🎉

You should now see:
- ✅ Live CAN messages scrolling
- ✅ Modules being discovered
- ✅ Real-time traffic statistics

---

## Quick Actions

### Scan for VINs

```
1. Click "Scan VINs" button
2. Wait 5 seconds
3. Check "Modules" tab
4. VINs will appear in module cards
```

### Export CAN Log

```
1. Click "Export" button
2. CSV file downloads automatically
3. Open in Excel or import to toolkit
```

### Filter Messages

```
1. Type CAN ID in filter box (e.g., "7E0")
2. Only matching messages show
3. Clear filter to see all
```

---

## Troubleshooting

### Can't Connect to Arduino

- ✅ Use Chrome or Edge browser (not Firefox/Safari)
- ✅ Check USB cable is connected
- ✅ Try different USB port
- ✅ Restart browser

### No CAN Messages

- ✅ Turn ignition ON
- ✅ Check OBD-II cable wiring
- ✅ Verify shield is seated properly
- ✅ Try different CAN speed (edit Arduino code)

### High Error Count

- ✅ Wrong CAN speed - try 250kbps instead of 500kbps
- ✅ Bad connection - check wiring
- ✅ Add termination resistor (120Ω)

---

## Next Steps

Now that you're connected:

1. **Scan all modules** - See what's in your vehicle
2. **Compare VINs** - Check for mismatches
3. **Patch files** - Use VIN Patcher with checksum correction
4. **Validate** - Re-scan after patching to verify

---

## Full Documentation

For complete details, see:
- **CAN_BUS_INTEGRATION_GUIDE.md** - Complete setup and usage
- **ARDUINO_SETUP.md** - Library installation details
- **MC9S12XE_WIRING_DIAGRAMS.md** - Hardware wiring diagrams

---

## Support

Having issues? Check:
1. Arduino IDE Serial Monitor for error messages
2. Browser console (F12) for web app errors
3. Verify all connections are secure
4. Try the example sketches from Seeed CAN library first

**Happy monitoring!** 🚗⚡

