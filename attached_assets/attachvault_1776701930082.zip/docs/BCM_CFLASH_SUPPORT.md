# BCM C-FLASH Support

## Overview

The DARKVIN LABS toolkit now supports **BCM C-FLASH** (Code Flash / Program Memory) files in addition to the existing D-FLASH (Data Flash / Calibration) support.

## What is C-FLASH?

**C-FLASH (Code Flash)** contains the executable program code that runs on the BCM microcontroller. This is different from D-FLASH which contains calibration data, VINs, and configuration.

### BCM Memory Architecture

Most modern BCM modules use a dual-flash architecture:

| Memory Type | Size | Purpose | Contains |
|-------------|------|---------|----------|
| **D-FLASH** | 64KB - 128KB | Calibration Data | VINs, Security Bytes, Configuration, Calibration Tables |
| **C-FLASH** | 512KB - 1MB | Program Code | Executable firmware, Operating System, Control Logic |

### Typical BCM Configuration

**Example: Chrysler BCM (68105155AF)**
- C-FLASH: 512KB (0x80000 bytes) - Program memory
- D-FLASH: 64KB (0x10000 bytes) - Calibration/VIN data

## File Detection

The toolkit automatically detects C-FLASH files based on:

1. **File Size**: 512KB (524,288 bytes) is typical for BCM C-FLASH
2. **Content Analysis**: High density of `0x00` and `0xFF` bytes (unused code space)
3. **Filename Hints**: Files containing "cflash", "code", or "program"

### Detection Logic

```python
if file_size == 524288:
    code_density = count(0x00 and 0xFF patterns) / file_size
    if code_density > 0.3:
        return CFLASH
    else:
        return PFLASH
```

## Use Cases

### 1. Full BCM Backup
When backing up a BCM, you should read **both** memories:
- **BCM_CFLASH.bin** (512KB) - Program code
- **BCM_DFLASH.bin** (64KB) - VIN and calibration

### 2. BCM Cloning
To clone a BCM to another vehicle:
1. Read C-FLASH and D-FLASH from donor BCM
2. Patch VIN in D-FLASH using VIN Patcher tool
3. Flash both C-FLASH and D-FLASH to recipient BCM

### 3. Firmware Updates
- C-FLASH can be updated to change BCM firmware version
- D-FLASH typically stays the same (preserves VIN/config)

### 4. Module Repair
- Corrupted C-FLASH = BCM won't boot
- Corrupted D-FLASH = BCM boots but wrong VIN/config

## Supported Operations

### ✅ Currently Supported
- **Upload C-FLASH files** - Drag & drop 512KB BCM program files
- **Auto-detection** - Toolkit identifies C-FLASH vs D-FLASH automatically
- **File storage** - C-FLASH files saved to database with proper type
- **Module identification** - Detects BCM from C-FLASH content

### ⏳ Planned Features
- **C-FLASH + D-FLASH pairing** - Validate matching firmware versions
- **Firmware version extraction** - Read software version from C-FLASH
- **Part number validation** - Ensure C-FLASH matches BCM hardware
- **Checksum verification** - Validate C-FLASH integrity before flashing

## File Upload

### Web Interface
1. Go to **Upload Modules** page
2. Select your BCM C-FLASH file (512KB .bin file)
3. Toolkit automatically detects it as "BCM C-FLASH"
4. File is stored and ready for operations

### AI Agent
```
User: "I have a BCM C-FLASH file"
AI: "Great! I detected a 512KB BCM C-FLASH (program memory). 
     This contains the executable firmware. 
     Do you also have the D-FLASH file for VIN operations?"
```

## Technical Details

### Memory Layout (Typical BCM)

**C-FLASH (512KB)**
```
0x00000000 - 0x000003FF: Interrupt Vector Table
0x00000400 - 0x0007FFFF: Program Code
0x00080000 - 0x0008FFFF: Unused (0xFF filled)
```

**D-FLASH (64KB)**
```
0x00000000 - 0x0000FFFF: Calibration Data
  - VIN locations: Multiple offsets
  - Security bytes: Various offsets
  - Configuration tables
```

### File Format
- **Format**: Raw binary dump
- **Endianness**: Big-endian (Freescale/NXP MCUs)
- **Checksum**: CRC-16 or CRC-32 (varies by BCM model)

### Common BCM Microcontrollers
- **Freescale MC9S12XEP100** (older BCMs)
- **NXP S32K** (newer BCMs)
- **Infineon TC27x** (some models)

## Database Schema

C-FLASH files are stored with the following attributes:

```typescript
{
  moduleType: "bcm",
  memoryType: "cflash",  // NEW: Added C-FLASH support
  fileName: "BCM_68105155AF_CFLASH.bin",
  fileSize: 524288,
  // VIN extraction not applicable for C-FLASH
  vin: null,
  vinReversed: false,
  securityBytesExtracted: false
}
```

## Best Practices

### ✅ DO:
- Always backup both C-FLASH and D-FLASH before modifications
- Verify file size matches expected BCM memory size
- Keep C-FLASH and D-FLASH files paired (same BCM)
- Label files clearly (e.g., "BCM_CFLASH_512KB.bin")

### ❌ DON'T:
- Don't flash C-FLASH from different BCM part numbers
- Don't modify C-FLASH unless you know what you're doing
- Don't flash C-FLASH without matching D-FLASH
- Don't attempt VIN patching on C-FLASH (VINs are in D-FLASH)

## Troubleshooting

### "File detected as P-FLASH instead of C-FLASH"
- Rename file to include "cflash" in the name
- Check file size (should be exactly 524,288 bytes)
- File may actually be P-FLASH (different architecture)

### "Can't find VIN in C-FLASH"
- **This is normal!** VINs are stored in D-FLASH, not C-FLASH
- Upload the corresponding D-FLASH file for VIN operations

### "Checksum error after flashing C-FLASH"
- C-FLASH may require recalculation of master checksum
- Use professional flash tools (J2534, JTAG) for C-FLASH programming
- Toolkit currently focuses on D-FLASH operations

## Safety Warning

⚠️ **IMPORTANT**: Flashing incorrect C-FLASH can **brick your BCM**!

- C-FLASH contains the operating system
- Wrong C-FLASH = BCM won't boot = expensive repair
- Always verify part numbers match before flashing
- Use professional tools for C-FLASH programming
- This toolkit is designed primarily for D-FLASH operations

## Future Enhancements

### Planned C-FLASH Features:
1. **Firmware version extraction** - Read SW version from C-FLASH
2. **Part number validation** - Ensure compatibility
3. **C-FLASH + D-FLASH pairing** - Validate they belong together
4. **Checksum calculation** - Verify C-FLASH integrity
5. **Firmware comparison** - Diff two C-FLASH files
6. **Bootloader detection** - Identify bootloader version

### Advanced Features (Future):
- **Firmware patching** - Modify C-FLASH code (expert mode)
- **Feature unlocking** - Enable hidden BCM features
- **Diagnostic code removal** - Clear DTCs from C-FLASH
- **Immobilizer bypass** - Modify security routines (for repair)

## Examples

### Example 1: Full BCM Backup
```
Files needed:
- BCM_68105155AF_CFLASH_512KB.bin (program code)
- BCM_68105155AF_DFLASH_64KB.bin (VIN/config)

Upload both to toolkit for complete BCM backup.
```

### Example 2: VIN Change
```
1. Upload BCM_DFLASH_64KB.bin
2. Use VIN Patcher to change VIN
3. Download patched D-FLASH
4. Flash only D-FLASH to BCM (C-FLASH unchanged)
```

### Example 3: BCM Clone
```
Donor BCM:
- Read C-FLASH (512KB)
- Read D-FLASH (64KB)

Recipient BCM:
- Flash donor C-FLASH (512KB) - copies firmware
- Patch D-FLASH with new VIN
- Flash patched D-FLASH (64KB)

Result: Recipient BCM has donor's firmware + new VIN
```

## Conclusion

C-FLASH support expands the toolkit's capabilities to handle complete BCM backups and firmware-level operations. While D-FLASH operations (VIN patching, security sync) remain the primary focus, C-FLASH support enables professional-grade BCM cloning and repair workflows.

**Remember**: 
- **D-FLASH** = VIN, security, calibration (safe to modify)
- **C-FLASH** = Program code (modify with extreme caution)

---

*"WE DON'T TUNE CARS. WE REWRITE IDENTITIES."* - DARKVIN LABS

