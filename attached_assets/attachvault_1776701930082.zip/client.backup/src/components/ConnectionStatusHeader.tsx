import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Wifi, WifiOff, Car, Cpu } from 'lucide-react';
import { ConnectionManager } from '@/lib/obd2-protocol';

interface ConnectionStatus {
  connected: boolean;
  deviceType?: string;
  deviceName?: string;
  vin?: string;
  protocol?: string;
}

export function ConnectionStatusHeader() {
  const [status, setStatus] = useState<ConnectionStatus>({ connected: false });
  const [connMgr] = useState(() => new ConnectionManager());

  useEffect(() => {
    const checkConnection = async () => {
      try {
        const state = connMgr.getState();
        const protocol = connMgr.getProtocol();
        
        if (state === 'connected' && protocol) {
          // Try to read VIN
          let vin: string | undefined;
          try {
            const vinResp = await protocol.sendUDS(0x7E0, 0x7E8, [0x22, 0xF1, 0x90]);
            if (vinResp && vinResp[0] === 0x62) {
              vin = String.fromCharCode(...Array.from(vinResp.slice(3, 20)));
            }
          } catch (error) {
            // VIN read failed, continue without it
          }

          setStatus({
            connected: true,
            deviceType: 'OBDLink',
            deviceName: 'Hardware Connected',
            vin,
            protocol: 'ISO15765-4'
          });
        } else {
          setStatus({ connected: false });
        }
      } catch (error) {
        setStatus({ connected: false });
      }
    };

    // Check immediately
    checkConnection();

    // Check every 5 seconds
    const interval = setInterval(checkConnection, 5000);

    return () => clearInterval(interval);
  }, [connMgr]);

  if (!status.connected) {
    return (
      <div className="bg-gray-800 border-b border-gray-700 px-4 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <WifiOff className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-400">No hardware connected</span>
          </div>
          <Badge variant="outline" className="bg-gray-700 text-gray-300 border-gray-600">
            Offline
          </Badge>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 border-b border-green-500/30 px-4 py-2">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Wifi className="h-4 w-4 text-green-500" />
            <span className="text-sm text-green-400 font-medium">{status.deviceName}</span>
          </div>
          
          {status.vin && (
            <div className="flex items-center gap-2 pl-4 border-l border-gray-700">
              <Car className="h-4 w-4 text-blue-400" />
              <span className="text-sm text-blue-300 font-mono">{status.vin}</span>
            </div>
          )}

          <div className="flex items-center gap-2 pl-4 border-l border-gray-700">
            <Cpu className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-purple-300">{status.protocol}</span>
          </div>
        </div>

        <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
          🟢 Connected
        </Badge>
      </div>
    </div>
  );
}
