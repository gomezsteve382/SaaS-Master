import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, XCircle, AlertTriangle, Loader2 } from "lucide-react";
import { ConnectionManager } from "@/lib/obd2-protocol";
import { toast } from "sonner";

interface Module {
  canId: string;
  name: string;
  vin?: string;
  vinMismatch: boolean;
}

interface VINCorrectionWizardProps {
  module: Module | null;
  targetVIN: string;
  isOpen: boolean;
  onClose: () => void;
  onCorrect: (module: Module, targetVIN: string) => Promise<void>;
}

type Step = "confirm" | "backup" | "security" | "write" | "verify" | "complete" | "error";

export function VINCorrectionWizard({ module, targetVIN, isOpen, onClose, onCorrect }: VINCorrectionWizardProps) {
  const [currentStep, setCurrentStep] = useState<Step>("confirm");
  const [progress, setProgress] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [backupCreated, setBackupCreated] = useState(false);

  const steps: { id: Step; label: string; description: string }[] = [
    { id: "confirm", label: "Confirm", description: "Review VIN correction details" },
    { id: "backup", label: "Backup", description: "Create module backup" },
    { id: "security", label: "Security Access", description: "Unlock module for writing" },
    { id: "write", label: "Write VIN", description: "Program new VIN to module" },
    { id: "verify", label: "Verify", description: "Confirm VIN was written correctly" },
    { id: "complete", label: "Complete", description: "VIN correction successful" },
  ];

  const handleStartCorrection = async () => {
    if (!module) return;

    try {
      const connectionManager = new ConnectionManager();
      const protocol = connectionManager.getProtocol();
      if (!protocol) {
        throw new Error("No hardware connection. Please connect OBDLink/J2534 adapter first.");
      }

      // Step 1: Backup - Read current VIN
      setCurrentStep("backup");
      setProgress(20);
      const txId = parseInt(module.canId, 16);
      const rxId = txId + 0x08;
      const currentVIN = await protocol.readVIN(txId, rxId);
      console.log(`[VIN Correction] Backup VIN: ${currentVIN}`);
      setBackupCreated(true);

      // Step 2: Security Access
      setCurrentStep("security");
      setProgress(40);
      // Request seed (UDS 0x27 0x01)
      const seedResponse = await protocol.sendUDS(txId, rxId, [0x27, 0x01]);
      if (!seedResponse || seedResponse[0] !== 0x67) {
        throw new Error("Security access seed request failed");
      }
      const seed = (seedResponse[2] << 8) | seedResponse[3];
      console.log(`[VIN Correction] Seed: 0x${seed.toString(16).padStart(4, '0')}`);
      
      // Calculate key (using FCA algorithm)
      const key = ((seed * 5) & 0xFFFF) ^ 0x4B92;
      console.log(`[VIN Correction] Key: 0x${key.toString(16).padStart(4, '0')}`);
      
      // Send key (UDS 0x27 0x02)
      const keyResponse = await protocol.sendUDS(txId, rxId, [0x27, 0x02, (key >> 8) & 0xFF, key & 0xFF]);
      if (!keyResponse || keyResponse[0] !== 0x67) {
        throw new Error("Security access key verification failed");
      }

      // Step 3: Write VIN
      setCurrentStep("write");
      setProgress(60);
      // UDS 0x2E F190 + VIN bytes
      const vinBytes = Array.from(targetVIN).map(c => c.charCodeAt(0));
      const writeCommand = [0x2E, 0xF1, 0x90, ...vinBytes];
      const writeResponse = await protocol.sendUDS(txId, rxId, writeCommand);
      if (!writeResponse || writeResponse[0] !== 0x6E) {
        throw new Error("VIN write failed");
      }
      console.log(`[VIN Correction] VIN written: ${targetVIN}`);

      // Step 4: Verify
      setCurrentStep("verify");
      setProgress(80);
      const verifyVIN = await protocol.readVIN(txId, rxId);
      if (verifyVIN !== targetVIN) {
        throw new Error(`VIN verification failed. Expected: ${targetVIN}, Got: ${verifyVIN}`);
      }
      console.log(`[VIN Correction] VIN verified: ${verifyVIN}`);

      // Step 5: Complete
      setCurrentStep("complete");
      setProgress(100);
      toast.success(`VIN corrected successfully for ${module.name}`);
      
      // Call the onCorrect callback to update UI
      await onCorrect(module, targetVIN);
    } catch (error) {
      setCurrentStep("error");
      const errorMsg = error instanceof Error ? error.message : "VIN correction failed";
      setErrorMessage(errorMsg);
      toast.error(errorMsg);
      console.error("[VIN Correction] Error:", error);
    }
  };

  const handleClose = () => {
    setCurrentStep("confirm");
    setProgress(0);
    setErrorMessage(null);
    setBackupCreated(false);
    onClose();
  };

  if (!module) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>VIN Correction Wizard</DialogTitle>
          <DialogDescription>
            Correct VIN mismatch for {module.name} ({module.canId})
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress bar */}
          {currentStep !== "confirm" && currentStep !== "error" && (
            <div className="space-y-2">
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                {steps.slice(1, -1).map((step) => (
                  <span
                    key={step.id}
                    className={currentStep === step.id ? "text-primary font-semibold" : ""}
                  >
                    {step.label}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Confirm step */}
          {currentStep === "confirm" && (
            <div className="space-y-4">
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Warning:</strong> This operation will modify the VIN stored in the module. A backup will be created automatically.
                </AlertDescription>
              </Alert>

              <div className="space-y-3 p-4 bg-muted rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Module</div>
                    <div className="font-semibold">{module.name}</div>
                    <div className="text-xs text-muted-foreground">{module.canId}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Status</div>
                    <Badge variant="destructive">VIN Mismatch</Badge>
                  </div>
                </div>

                <div className="border-t pt-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Current VIN</div>
                      <div className="font-mono text-sm">{module.vin || "Unknown"}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Target VIN</div>
                      <div className="font-mono text-sm text-green-600">{targetVIN}</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button onClick={handleStartCorrection}>
                  Start Correction
                </Button>
              </div>
            </div>
          )}

          {/* Backup step */}
          {currentStep === "backup" && (
            <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <div>
                <div className="font-semibold">Creating module backup...</div>
                <div className="text-sm text-muted-foreground">
                  Reading current module configuration
                </div>
              </div>
            </div>
          )}

          {/* Security Access step */}
          {currentStep === "security" && (
            <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <div>
                <div className="font-semibold">Requesting security access...</div>
                <div className="text-sm text-muted-foreground">
                  Calculating seed-key response
                </div>
              </div>
            </div>
          )}

          {/* Write VIN step */}
          {currentStep === "write" && (
            <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <div>
                <div className="font-semibold">Writing VIN to module...</div>
                <div className="text-sm text-muted-foreground">
                  Programming {targetVIN}
                </div>
              </div>
            </div>
          )}

          {/* Verify step */}
          {currentStep === "verify" && (
            <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <div>
                <div className="font-semibold">Verifying VIN...</div>
                <div className="text-sm text-muted-foreground">
                  Reading back programmed VIN
                </div>
              </div>
            </div>
          )}

          {/* Complete step */}
          {currentStep === "complete" && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                <CheckCircle2 className="h-6 w-6 text-green-600" />
                <div>
                  <div className="font-semibold text-green-600">VIN Correction Successful!</div>
                  <div className="text-sm text-muted-foreground">
                    Module {module.name} now has VIN {targetVIN}
                  </div>
                </div>
              </div>

              {backupCreated && (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>
                    A backup was created before modification. You can restore it from the Module Backup page if needed.
                  </AlertDescription>
                </Alert>
              )}

              <div className="flex gap-2 justify-end">
                <Button onClick={handleClose}>Close</Button>
              </div>
            </div>
          )}

          {/* Error step */}
          {currentStep === "error" && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                <XCircle className="h-6 w-6 text-red-600" />
                <div>
                  <div className="font-semibold text-red-600">VIN Correction Failed</div>
                  <div className="text-sm text-muted-foreground">
                    {errorMessage || "An unknown error occurred"}
                  </div>
                </div>
              </div>

              {backupCreated && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    A backup was created before the error occurred. The module was not modified.
                  </AlertDescription>
                </Alert>
              )}

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={handleClose}>
                  Close
                </Button>
                <Button onClick={() => setCurrentStep("confirm")}>
                  Try Again
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
