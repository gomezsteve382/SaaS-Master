import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wifi, WifiOff, RefreshCw, Activity } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface HardwareDevice {
  type: string;
  port: string;
  baudRate: number;
  protocol: string;
  connected: boolean;
}

export function HardwareConnectionPanel() {
  const [devices, setDevices] = useState<HardwareDevice[]>([]);
  const [selectedDevice, setSelectedDevice] = useState<string>("");
  const [connected, setConnected] = useState(false);
  const [detecting, setDetecting] = useState(false);

  const [shouldFetch, setShouldFetch] = useState(false);
  const detectDevicesMutation = trpc.hardware.detectDevices.useQuery(undefined, { enabled: shouldFetch });
  
  const detectDevices = async () => {
    setDetecting(true);
    const result = await detectDevicesMutation.refetch();
    if (result.data) {
      setDevices(result.data.devices.map(d => ({
        type: d.type,
        port: d.port,
        baudRate: 38400,
        protocol: "ISO 15765-4 CAN",
        connected: false,
      })));
      toast.success(`Found ${result.data.devices.length} device(s)`);
    }
    setDetecting(false);
  };

  const connectMutation = trpc.hardware.connect.useMutation();
  
  const connectDevice = async () => {
    if (!selectedDevice) return;
    const result = await connectMutation.mutateAsync({ deviceId: "simulator" });
    if (result.success) {
      setConnected(true);
      toast.success(result.message);
    }
  };

  const disconnectDevice = () => {
    setConnected(false);
    toast.info("Disconnected from hardware");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {connected ? <Wifi className="h-5 w-5 text-green-500" /> : <WifiOff className="h-5 w-5 text-gray-400" />}
          Hardware Connection
        </CardTitle>
        <CardDescription>
          Connect to ELM327 or J2534 adapter for real vehicle communication
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button onClick={detectDevices} disabled={detecting} variant="outline" className="flex-1">
            <RefreshCw className={`h-4 w-4 mr-2 ${detecting ? "animate-spin" : ""}`} />
            Detect Devices
          </Button>
          {connected ? (
            <Button onClick={disconnectDevice} variant="destructive" className="flex-1">
              Disconnect
            </Button>
          ) : (
            <Button onClick={connectDevice} disabled={!selectedDevice} className="flex-1">
              Connect
            </Button>
          )}
        </div>

        {devices.length > 0 && (
          <Select value={selectedDevice} onValueChange={setSelectedDevice}>
            <SelectTrigger>
              <SelectValue placeholder="Select CAN adapter" />
            </SelectTrigger>
            <SelectContent>
              {devices.map((device, idx) => (
                <SelectItem key={idx} value={device.port}>
                  {device.type} - {device.port} ({device.protocol})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {connected && (
          <div className="border rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Status</span>
              <Badge variant="default" className="bg-green-500">
                <Activity className="h-3 w-3 mr-1" />
                Connected
              </Badge>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Messages/sec</span>
              <span className="font-mono">127</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Errors</span>
              <span className="font-mono">0</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
