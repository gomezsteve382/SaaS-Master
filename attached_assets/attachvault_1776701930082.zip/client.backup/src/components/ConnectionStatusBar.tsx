import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Wifi, WifiOff, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ConnectionStatusBarProps {
  connectionManager?: any; // ConnectionManager instance
}

export function ConnectionStatusBar({ connectionManager }: ConnectionStatusBarProps) {
  const { toast } = useToast();
  const [connected, setConnected] = useState(false);
  const [vin, setVin] = useState<string | null>(null);
  const [baudRate, setBaudRate] = useState<number | null>(null);
  const [protocolInfo, setProtocolInfo] = useState<{number: string, name: string} | null>(null);
  const [statusLog, setStatusLog] = useState<Array<{time: string, message: string, type: 'info' | 'error' | 'success'}>>([]);

  useEffect(() => {
    if (!connectionManager) return;

    // Capture console.log messages for retry status
    const originalLog = console.log;
    console.log = (...args: any[]) => {
      originalLog(...args);
      const message = args.join(' ');
      if (message.includes('[ELM327]')) {
        const time = new Date().toLocaleTimeString();
        const type = message.includes('error') || message.includes('ERROR') ? 'error' : 
                     message.includes('Retry') ? 'info' : 'success';
        setStatusLog(prev => [...prev.slice(-4), { time, message: message.replace('[ELM327]', '').trim(), type }]);
      }
    };

    // Check connection status periodically
    const interval = setInterval(() => {
      const state = connectionManager.getState();
      const isConnected = state === 'connected';
      setConnected(isConnected);

      if (isConnected) {
        const protocol = connectionManager.getProtocol();
        if (protocol) {
          // Get protocol info
          if ('getProtocolInfo' in protocol) {
            const info = (protocol as any).getProtocolInfo();
            if (info && info.number) {
              setProtocolInfo(info);
            }
          }
          // Try to get VIN if not already set
          if (!vin && 'readVIN' in protocol) {
            (protocol as any).readVIN().then((readVin: string | null) => {
              if (readVin) setVin(readVin);
            }).catch(() => {});
          }
        }
      } else {
        setVin(null);
        setBaudRate(null);
        setProtocolInfo(null);
      }
    }, 2000);

    return () => {
      clearInterval(interval);
      console.log = originalLog; // Restore original console.log
    };
  }, [connectionManager, vin]);

  const handleReconnect = async () => {
    if (!connectionManager) return;

    try {
      if (!('serial' in navigator)) {
        toast({
          title: "Web Serial Not Supported",
          description: "Please use Chrome, Edge, or Opera browser",
          variant: "destructive",
        });
        return;
      }

      const port = await (navigator.serial as any).requestPort();
      const success = await connectionManager.connect('elm327', port);

      if (success) {
        setConnected(true);
        toast({
          title: "✅ Reconnected",
          description: "OBDLink adapter ready",
        });
      } else {
        throw new Error("Connection failed");
      }
    } catch (error: any) {
      toast({
        title: "Reconnection Failed",
        description: error.message || "Could not reconnect to OBDLink",
        variant: "destructive",
      });
    }
  };

  if (!connectionManager) return null;

  return (
    <div className="border-t bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {/* Connection Status */}
            <div className="flex items-center gap-2">
              {connected ? (
                <>
                  <Wifi className="h-4 w-4 text-green-600" />
                  <Badge variant="default" className="bg-green-600">
                    Connected
                  </Badge>
                </>
              ) : (
                <>
                  <WifiOff className="h-4 w-4 text-gray-400" />
                  <Badge variant="outline" className="text-gray-500">
                    Disconnected
                  </Badge>
                </>
              )}
            </div>

            {/* VIN */}
            {vin && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground">VIN:</span>
                <span className="font-mono font-medium">{vin}</span>
              </div>
            )}

            {/* Baud Rate */}
            {connected && baudRate && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>{baudRate} baud</span>
              </div>
            )}
            
            {/* Protocol Info */}
            {connected && protocolInfo && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground">Protocol:</span>
                <Badge variant="outline" className="font-mono">
                  {protocolInfo.number}
                </Badge>
                <span className="text-xs text-muted-foreground">{protocolInfo.name}</span>
              </div>
            )}
            
            {/* Status Log - Show last message */}
            {statusLog.length > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground">[{statusLog[statusLog.length - 1].time}]</span>
                <span className={statusLog[statusLog.length - 1].type === 'error' ? 'text-red-600' : 
                                 statusLog[statusLog.length - 1].type === 'success' ? 'text-green-600' : 
                                 'text-blue-600'}>
                  {statusLog[statusLog.length - 1].message}
                </span>
              </div>
            )}
          </div>

          {/* Reconnect Button */}
          {!connected && (
            <Button
              onClick={handleReconnect}
              size="sm"
              variant="outline"
              className="flex items-center gap-2"
            >
              <RefreshCw className="h-3 w-3" />
              Reconnect
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
