/**
 * VIN Decoder Panel Component
 * Displays comprehensive VIN breakdown with manufacturer, plant, year, engine info
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle2, XCircle, AlertTriangle, Search, Globe, Factory, Calendar, Cog, Car } from "lucide-react";

interface VINDecoderPanelProps {
  initialVIN?: string;
  onVINChange?: (vin: string) => void;
  compact?: boolean;
}

export function VINDecoderPanel({ initialVIN = "", onVINChange, compact = false }: VINDecoderPanelProps) {
  const [vin, setVIN] = useState(initialVIN);
  const [decodedVIN, setDecodedVIN] = useState<string>("");
  
  const decodeMutation = trpc.vinDecoder.decode.useMutation({
    onSuccess: (data) => {
      setDecodedVIN(data.vin);
    },
  });
  
  const handleDecode = () => {
    if (vin.length === 17) {
      decodeMutation.mutate({ vin });
      onVINChange?.(vin);
    }
  };
  
  const handleVINInput = (value: string) => {
    const normalized = value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 17);
    setVIN(normalized);
    
    // Auto-decode when 17 characters entered
    if (normalized.length === 17) {
      setTimeout(() => {
        decodeMutation.mutate({ vin: normalized });
        onVINChange?.(normalized);
      }, 300);
    }
  };
  
  const result = decodeMutation.data;
  
  if (compact && result) {
    return (
      <Card className="bg-muted/30">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">VIN Decoder</CardTitle>
            {result.isValid ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Valid
              </Badge>
            ) : (
              <Badge variant="destructive">
                <XCircle className="w-3 h-3 mr-1" />
                Invalid
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {result.summary && (
            <p className="text-muted-foreground">{result.summary}</p>
          )}
          
          {result.wmi.manufacturer && (
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-muted-foreground" />
              <span className="font-medium">{result.wmi.manufacturer}</span>
              <span className="text-muted-foreground">({result.wmi.country})</span>
            </div>
          )}
          
          {result.vis.modelYear.year && (
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span>{result.vis.modelYear.year} Model Year</span>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-4">
      {/* VIN Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            VIN Decoder
          </CardTitle>
          <CardDescription>
            Enter a 17-character VIN to decode manufacturer, year, engine, and assembly plant information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter VIN (17 characters)"
              value={vin}
              onChange={(e) => handleVINInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleDecode()}
              className="font-mono text-lg tracking-wider"
              maxLength={17}
            />
            <Button 
              onClick={handleDecode}
              disabled={vin.length !== 17 || decodeMutation.isPending}
            >
              {decodeMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Decoding...
                </>
              ) : (
                "Decode"
              )}
            </Button>
          </div>
          
          {vin.length > 0 && vin.length < 17 && (
            <p className="text-sm text-muted-foreground">
              {17 - vin.length} characters remaining
            </p>
          )}
        </CardContent>
      </Card>
      
      {/* Decode Results */}
      {result && (
        <div className="space-y-4">
          {/* Validation Status */}
          <Card className={result.isValid ? "border-green-500" : "border-red-500"}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Validation Status</CardTitle>
                {result.isValid ? (
                  <Badge variant="default" className="bg-green-500">
                    <CheckCircle2 className="w-4 h-4 mr-1" />
                    Valid VIN
                  </Badge>
                ) : (
                  <Badge variant="destructive">
                    <XCircle className="w-4 h-4 mr-1" />
                    Invalid VIN
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* VIN Display */}
              <div className="font-mono text-2xl tracking-widest text-center py-2 bg-muted rounded">
                {result.vin}
              </div>
              
              {/* Summary */}
              {result.summary && (
                <p className="text-center text-muted-foreground">{result.summary}</p>
              )}
              
              {/* Check Digit */}
              <div className="flex items-center justify-center gap-4 pt-2 border-t">
                <span className="text-sm text-muted-foreground">Check Digit:</span>
                <code className="text-lg font-mono">
                  {result.checkDigit.provided}
                </code>
                {result.checkDigit.isValid ? (
                  <Badge variant="default" className="bg-green-500">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Valid
                  </Badge>
                ) : (
                  <Badge variant="destructive">
                    <XCircle className="w-3 h-3 mr-1" />
                    Expected: {result.checkDigit.calculated}
                  </Badge>
                )}
              </div>
              
              {/* Errors */}
              {result.errors.length > 0 && (
                <Alert variant="destructive">
                  <XCircle className="w-4 h-4" />
                  <AlertDescription>
                    <ul className="list-disc list-inside space-y-1">
                      {result.errors.map((error, i) => (
                        <li key={i}>{error}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
              
              {/* Warnings */}
              {result.warnings.length > 0 && (
                <Alert>
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription>
                    <ul className="list-disc list-inside space-y-1">
                      {result.warnings.map((warning, i) => (
                        <li key={i}>{warning}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
          
          {/* Manufacturer Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Manufacturer Information
              </CardTitle>
              <CardDescription>World Manufacturer Identifier (WMI) - Positions 1-3</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">WMI Code</p>
                  <p className="text-lg font-mono">{result.wmi.code}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Manufacturer</p>
                  <p className="text-lg font-semibold">{result.wmi.manufacturer || "Unknown"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Country</p>
                  <p className="text-lg">{result.wmi.country || "Unknown"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Region</p>
                  <p className="text-lg">{result.wmi.region || "Unknown"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Vehicle Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="w-5 h-5" />
                Vehicle Information
              </CardTitle>
              <CardDescription>Vehicle Descriptor Section (VDS) - Positions 4-8</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Vehicle Line</p>
                  <p className="text-lg font-mono">{result.vds.vehicleLine}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Series</p>
                  <p className="text-lg font-mono">{result.vds.series}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm text-muted-foreground">Body Style</p>
                  <p className="text-lg">
                    {result.vds.bodyStyle.style || `Code: ${result.vds.bodyStyle.code}`}
                    {result.vds.bodyStyle.doors && ` (${result.vds.bodyStyle.doors} doors)`}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Restraint System</p>
                  <p className="text-lg font-mono">{result.vds.restraintSystem}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Engine Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cog className="w-5 h-5" />
                Engine Information
              </CardTitle>
              <CardDescription>Position 8</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Engine Code</p>
                  <p className="text-lg font-mono">{result.vds.engine.code}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Engine Type</p>
                  <p className="text-lg font-semibold">{result.vds.engine.engine || "Unknown"}</p>
                </div>
                {result.vds.engine.displacement && (
                  <div>
                    <p className="text-sm text-muted-foreground">Displacement</p>
                    <p className="text-lg">{result.vds.engine.displacement}</p>
                  </div>
                )}
                {result.vds.engine.cylinders && (
                  <div>
                    <p className="text-sm text-muted-foreground">Cylinders</p>
                    <p className="text-lg">{result.vds.engine.cylinders}</p>
                  </div>
                )}
                {result.vds.engine.fuelType && (
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Fuel Type</p>
                    <p className="text-lg">{result.vds.engine.fuelType}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Production Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Factory className="w-5 h-5" />
                Production Information
              </CardTitle>
              <CardDescription>Vehicle Identifier Section (VIS) - Positions 10-17</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Model Year Code</p>
                  <p className="text-lg font-mono">{result.vis.modelYear.code}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Model Year</p>
                  <p className="text-lg font-semibold">{result.vis.modelYear.year || "Unknown"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Plant Code</p>
                  <p className="text-lg font-mono">{result.vis.assemblyPlant.code}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Assembly Plant</p>
                  <p className="text-lg">{result.vis.assemblyPlant.plant || "Unknown"}</p>
                </div>
                {result.vis.assemblyPlant.city && (
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="text-lg">
                      {result.vis.assemblyPlant.city}
                      {result.vis.assemblyPlant.state && `, ${result.vis.assemblyPlant.state}`}
                      {result.vis.assemblyPlant.country && ` - ${result.vis.assemblyPlant.country}`}
                    </p>
                  </div>
                )}
                <div className="col-span-2">
                  <p className="text-sm text-muted-foreground">Sequential Number</p>
                  <p className="text-lg font-mono">{result.vis.sequentialNumber}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
