import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Search, Download, AlertTriangle, CheckCircle, FileText, Cpu } from 'lucide-react';

export function FirmwareBrowser() {
  const [selectedModuleType, setSelectedModuleType] = useState<string>('');
  const [searchYear, setSearchYear] = useState<string>('');
  const [searchBody, setSearchBody] = useState<string>('');

  const { data: stats, isLoading: statsLoading } = trpc.firmware.getFirmwareStats.useQuery();
  const { data: firmware, isLoading: firmwareLoading } = trpc.firmware.findCompatibleFirmware.useQuery({
    moduleType: selectedModuleType || undefined,
    year: searchYear || undefined,
    body: searchBody || undefined,
  });

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold">Firmware Database</h2>
        <p className="text-muted-foreground">
          Browse and search official Stellantis firmware files
        </p>
      </div>

      {/* Statistics */}
      {statsLoading ? (
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin" />
          </CardContent>
        </Card>
      ) : stats ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Firmware Files</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.total_files}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {formatFileSize(stats.total_size)} total
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Module Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.module_types.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.module_types.join(', ')}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {stats.by_type?.map((type) => (
                  <div key={type.type} className="flex justify-between text-sm">
                    <span className="font-medium">{type.type}</span>
                    <span className="text-muted-foreground">{type.count} files</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}

      {/* Search Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search Firmware</CardTitle>
          <CardDescription>
            Filter by module type, year, and body code
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Module Type</label>
              <Select value={selectedModuleType} onValueChange={setSelectedModuleType}>
                <SelectTrigger>
                  <SelectValue placeholder="All modules" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All modules</SelectItem>
                  <SelectItem value="PCM">PCM (Engine)</SelectItem>
                  <SelectItem value="TCM">TCM (Transmission)</SelectItem>
                  <SelectItem value="SGW">SGW (Gateway)</SelectItem>
                  <SelectItem value="BCM">BCM (Body)</SelectItem>
                  <SelectItem value="ABS">ABS (Brakes)</SelectItem>
                  <SelectItem value="RFHUB">RFHUB (Key Fob)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Year</label>
              <Input
                placeholder="e.g., 2020"
                value={searchYear}
                onChange={(e) => setSearchYear(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Body Code</label>
              <Input
                placeholder="e.g., WD, WK, LD"
                value={searchBody}
                onChange={(e) => setSearchBody(e.target.value.toUpperCase())}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card>
        <CardHeader>
          <CardTitle>Firmware Files</CardTitle>
          <CardDescription>
            {firmware ? `${firmware.length} file(s) found` : 'Loading...'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {firmwareLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : firmware && firmware.length > 0 ? (
            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {firmware.map((fw: any, index: number) => (
                  <Card key={index} className="border-l-4 border-l-blue-500">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Cpu className="h-5 w-5" />
                            {fw.part_number}
                            <Badge variant="outline">{fw.module_type}</Badge>
                          </CardTitle>
                          <CardDescription className="text-sm">
                            {fw.calibration}
                          </CardDescription>
                        </div>
                        <Button size="sm" variant="outline">
                          <FileText className="h-4 w-4 mr-2" />
                          Details
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {/* File Info */}
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">File:</span>{' '}
                          <span className="font-mono">{fw.filename}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Size:</span>{' '}
                          <span>{formatFileSize(fw.file_size)}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Checksum:</span>{' '}
                          <span className="font-mono">{fw.checksum}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Module ID:</span>{' '}
                          <span>{fw.module_id}</span>
                        </div>
                      </div>

                      {/* Applications */}
                      {fw.applications && fw.applications.length > 0 && (
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Compatible Vehicles:</div>
                          <div className="flex flex-wrap gap-2">
                            {fw.applications.slice(0, 3).map((app: any, idx: number) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {app.year} {app.body} - {app.engine}
                              </Badge>
                            ))}
                            {fw.applications.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{fw.applications.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Supersedes */}
                      {fw.supersedes && fw.supersedes.length > 0 && (
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Supersedes:</div>
                          <div className="flex flex-wrap gap-2">
                            {fw.supersedes.map((old: any, idx: number) => (
                              <Badge key={idx} variant="outline" className="text-xs font-mono">
                                {old.part_number}
                                {old.generic && ' (Generic)'}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Warning */}
                      <div className="flex items-start gap-2 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-md">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5" />
                        <div className="text-xs text-muted-foreground">
                          <strong>Warning:</strong> Flashing incorrect firmware can brick your module.
                          Always verify part number compatibility and have a backup.
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No firmware files found. Try adjusting your search filters.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
