import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface HexChange {
  offset: number;
  original: string;
  patched: string;
  type: 'vin' | 'checksum';
}

interface HexComparisonViewerProps {
  changes: HexChange[];
  title?: string;
}

export function HexComparisonViewer({ changes, title = "Hex Dump Comparison" }: HexComparisonViewerProps) {
  // Group changes by type
  const vinChanges = changes.filter(c => c.type === 'vin');
  const checksumChanges = changes.filter(c => c.type === 'checksum');

  return (
    <Card className="aggressive-card">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>{title}</span>
          <Badge variant="outline">{changes.length} changes</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] w-full">
          <div className="space-y-4">
            {/* VIN Changes */}
            {vinChanges.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="bg-blue-600">VIN Changes</Badge>
                  <span className="text-sm text-muted-foreground">{vinChanges.length} bytes</span>
                </div>
                <div className="hex-viewer p-4 rounded">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="text-left py-2 text-gray-400">Offset</th>
                        <th className="text-left py-2 text-gray-400">Original</th>
                        <th className="text-left py-2 text-gray-400">Patched</th>
                        <th className="text-left py-2 text-gray-400">ASCII</th>
                      </tr>
                    </thead>
                    <tbody>
                      {vinChanges.map((change, idx) => (
                        <tr key={idx} className="border-b border-gray-800">
                          <td className="py-1 text-yellow-400">
                            0x{change.offset.toString(16).toUpperCase().padStart(4, '0')}
                          </td>
                          <td className="py-1 text-red-400">{change.original}</td>
                          <td className="py-1 text-green-400">{change.patched}</td>
                          <td className="py-1 text-gray-400">
                            {String.fromCharCode(parseInt(change.original, 16))} → {String.fromCharCode(parseInt(change.patched, 16))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Checksum Changes */}
            {checksumChanges.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="bg-purple-600">Checksum Changes</Badge>
                  <span className="text-sm text-muted-foreground">{checksumChanges.length} bytes</span>
                </div>
                <div className="hex-viewer p-4 rounded">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="text-left py-2 text-gray-400">Offset</th>
                        <th className="text-left py-2 text-gray-400">Original</th>
                        <th className="text-left py-2 text-gray-400">Patched</th>
                      </tr>
                    </thead>
                    <tbody>
                      {checksumChanges.map((change, idx) => (
                        <tr key={idx} className="border-b border-gray-800">
                          <td className="py-1 text-yellow-400">
                            0x{change.offset.toString(16).toUpperCase().padStart(4, '0')}
                          </td>
                          <td className="py-1 text-red-400">{change.original}</td>
                          <td className="py-1 text-green-400">{change.patched}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {changes.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No changes detected
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Legend */}
        <div className="mt-4 pt-4 border-t border-gray-200 flex flex-wrap gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-400 rounded"></div>
            <span>Original Value</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-400 rounded"></div>
            <span>Patched Value</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-yellow-400 rounded"></div>
            <span>Memory Offset</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
