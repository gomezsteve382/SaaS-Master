import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';
import { useDemoMode } from '@/contexts/DemoModeContext';
import { DEMO_VEHICLES } from '@shared/demo-vehicles';

export function DemoModeBanner() {
  const { isDemoMode, currentVehicle } = useDemoMode();

  if (!isDemoMode) return null;

  const vehicle = DEMO_VEHICLES[currentVehicle];
  const vehicleName = vehicle ? vehicle.name : 'Demo Vehicle';

  return (
    <Alert className="bg-blue-50 border-blue-200 mb-4">
      <Info className="h-4 w-4 text-blue-600" />
      <AlertDescription className="text-blue-900">
        <strong>DEMO MODE ACTIVE</strong> - Simulating {vehicleName}. All operations use simulated data. No real hardware connection required.
      </AlertDescription>
    </Alert>
  );
}
