import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
  ContextMenuSeparator,
} from "@/components/ui/context-menu";
import { FileText, AlertCircle, Code, Wrench, Trash2 } from "lucide-react";

interface Module {
  canId: string;
  name: string;
  vin?: string;
  vinMismatch: boolean;
  status: "online" | "offline" | "error";
  partNumber?: string;
  softwareVersion?: string;
  hardwareVersion?: string;
  responseTime?: number;
}

interface TopographicalModuleViewProps {
  modules: Module[];
  primaryVIN?: string;
  onModuleClick?: (module: Module) => void;
  onReadDTCs?: (module: Module) => void;
  onViewPartNumber?: (module: Module) => void;
  onCheckSoftwareVersion?: (module: Module) => void;
  onClearDTCs?: (module: Module) => void;
}

// Comprehensive module position mapping (x%, y% from top-left)
// Based on AlphaOBD database and typical Chrysler/FCA/Stellantis vehicle layout
const MODULE_POSITIONS: Record<string, { x: number; y: number; zone: string }> = {
  // ===== ENGINE BAY (Front) =====
  // Standard OBD2 ECM/PCM
  "0x7E0": { x: 50, y: 15, zone: "engine" }, // ECM/PCM - Center front
  "0x7E1": { x: 55, y: 18, zone: "engine" }, // TCM alternate
  "0x7E8": { x: 50, y: 15, zone: "engine" }, // ECM/PCM response
  "0x7DF": { x: 50, y: 15, zone: "engine" }, // Broadcast
  "0x7E7": { x: 45, y: 18, zone: "engine" }, // Battery Pack Control (Hybrid)
  
  // Power Steering & Lighting
  "0x75A": { x: 30, y: 20, zone: "engine" }, // Electric Power Steering (EPS)
  "0x4DA": { x: 30, y: 20, zone: "engine" }, // EPS response
  "0x768": { x: 70, y: 20, zone: "engine" }, // Adaptive Front Lighting (AFLS)
  "0x4E8": { x: 70, y: 20, zone: "engine" }, // AFLS response
  "0x710": { x: 65, y: 22, zone: "engine" }, // Automatic High Beam (AHBM)
  "0x522": { x: 65, y: 22, zone: "engine" }, // AHBM response
  
  // ===== TRANSMISSION (Under vehicle, center) =====
  "0x7E2": { x: 50, y: 45, zone: "transmission" }, // TCM
  "0x7E9": { x: 50, y: 45, zone: "transmission" }, // TCM response
  "0x74B": { x: 48, y: 47, zone: "transmission" }, // Drive Train Control (DTCM)
  "0x4CB": { x: 48, y: 47, zone: "transmission" }, // DTCM response
  "0x74C": { x: 52, y: 47, zone: "transmission" }, // Final Drive Control (FDCM)
  "0x4CC": { x: 52, y: 47, zone: "transmission" }, // FDCM response
  "0x6C2": { x: 54, y: 49, zone: "transmission" }, // Electronic Limited Slip Diff (ELSD)
  
  // ===== DASHBOARD (Center) =====
  // Body Control Module (BCM)
  "0x620": { x: 50, y: 35, zone: "dash" }, // BCM - Center dash (CAN-C)
  "0x504": { x: 50, y: 35, zone: "dash" }, // BCM response
  "0x731": { x: 50, y: 35, zone: "dash" }, // BCM alternate
  
  // RFHUB & Wireless
  "0x740": { x: 35, y: 35, zone: "dash" }, // RFHUB - Left dash
  "0x4C0": { x: 35, y: 35, zone: "dash" }, // RFHUB response
  "0x600": { x: 32, y: 37, zone: "dash" }, // Wireless Control Module (WCM)
  "0x500": { x: 32, y: 37, zone: "dash" }, // WCM response
  
  // Instrument Cluster
  "0x742": { x: 50, y: 28, zone: "dash" }, // Instrument Panel Cluster (IPC)
  "0x4C2": { x: 50, y: 28, zone: "dash" }, // IPC response
  "0x6A0": { x: 50, y: 28, zone: "dash" }, // Instrument Cluster (CCN)
  "0x514": { x: 50, y: 28, zone: "dash" }, // CCN response
  
  // Radio & Navigation
  "0x6B0": { x: 60, y: 35, zone: "dash" }, // Radio Navigator
  "0x516": { x: 60, y: 35, zone: "dash" }, // Radio response
  
  // HVAC
  "0x688": { x: 50, y: 40, zone: "dash" }, // HVAC Module
  "0x511": { x: 50, y: 40, zone: "dash" }, // HVAC response
  "0x733": { x: 50, y: 40, zone: "dash" }, // HVAC alternate
  
  // Steering Column
  "0x763": { x: 45, y: 32, zone: "dash" }, // Steering Column Control (SCCM)
  "0x4E3": { x: 45, y: 32, zone: "dash" }, // SCCM response
  "0x622": { x: 43, y: 34, zone: "dash" }, // Steering Angle Sensor (SAS)
  "0x761": { x: 47, y: 34, zone: "dash" }, // Steering Assist Module (SAM)
  "0x4E1": { x: 47, y: 34, zone: "dash" }, // SAM response
  
  // Passive Entry & Security
  "0x628": { x: 38, y: 32, zone: "dash" }, // Passive Entry Module (PEM)
  "0x505": { x: 38, y: 32, zone: "dash" }, // PEM response
  "0x748": { x: 40, y: 30, zone: "dash" }, // Electronic Steering Lock (ESL)
  "0x4C8": { x: 40, y: 30, zone: "dash" }, // ESL response
  "0x47E": { x: 55, y: 32, zone: "dash" }, // Security Gateway (SGW)
  
  // Shifter & Sunroof
  "0x749": { x: 52, y: 38, zone: "dash" }, // Electronic Shifter Module (ESM)
  "0x4C9": { x: 52, y: 38, zone: "dash" }, // ESM response
  "0x638": { x: 48, y: 25, zone: "dash" }, // Sunroof Module
  "0x507": { x: 48, y: 25, zone: "dash" }, // Sunroof response
  
  // ===== CHASSIS (ABS, Airbag, Suspension) =====
  // ABS/ESP
  "0x7E3": { x: 20, y: 25, zone: "chassis" }, // ABS
  "0x7E4": { x: 20, y: 25, zone: "chassis" }, // ABS alternate
  "0x7EB": { x: 20, y: 25, zone: "chassis" }, // ABS response
  "0x747": { x: 22, y: 27, zone: "chassis" }, // ABS PowerNet
  "0x4C7": { x: 22, y: 27, zone: "chassis" }, // ABS PowerNet response
  
  // Airbag/Restraints
  "0x744": { x: 50, y: 32, zone: "chassis" }, // Occupant Restraint Module (Airbag)
  "0x4C4": { x: 50, y: 32, zone: "chassis" }, // Airbag response
  "0x6E0": { x: 50, y: 32, zone: "chassis" }, // Airbag CAN-C
  "0x51C": { x: 50, y: 32, zone: "chassis" }, // Airbag CAN-C response
  "0x75E": { x: 52, y: 34, zone: "chassis" }, // Occupant Classification (OCM)
  "0x4DE": { x: 52, y: 34, zone: "chassis" }, // OCM response
  "0x6E8": { x: 52, y: 34, zone: "chassis" }, // OCM CAN-C
  "0x51D": { x: 52, y: 34, zone: "chassis" }, // OCM CAN-C response
  
  // Suspension & Sway Bar
  "0x766": { x: 25, y: 50, zone: "chassis" }, // Air Suspension Control (ASCM)
  "0x4E6": { x: 25, y: 50, zone: "chassis" }, // ASCM response
  "0x754": { x: 28, y: 52, zone: "chassis" }, // Active Damping Control (ADCM)
  "0x757": { x: 28, y: 52, zone: "chassis" }, // ADCM alternate
  "0x4D7": { x: 28, y: 52, zone: "chassis" }, // ADCM response alternate
  "0x74A": { x: 30, y: 48, zone: "chassis" }, // Automatic Sway Bar System (ASBS)
  "0x4CA": { x: 30, y: 48, zone: "chassis" }, // ASBS response
  
  // ===== ADAS (Advanced Driver Assistance) =====
  // Adaptive Cruise & Collision
  "0x753": { x: 50, y: 20, zone: "adas" }, // Adaptive Cruise Control (ACC)
  "0x4D3": { x: 50, y: 20, zone: "adas" }, // ACC response
  "0x764": { x: 55, y: 22, zone: "adas" }, // Forward Facing Camera (FFCM) / Radio
  "0x4E4": { x: 55, y: 22, zone: "adas" }, // FFCM response
  "0x75F": { x: 52, y: 24, zone: "adas" }, // Electronic Pedestrian Protection
  "0x4DF": { x: 52, y: 24, zone: "adas" }, // EPP response
  
  // Blind Spot & Parking
  "0x690": { x: 15, y: 55, zone: "adas" }, // Left Blind Spot Sensor (LBSS)
  "0x512": { x: 15, y: 55, zone: "adas" }, // LBSS response
  "0x6B8": { x: 85, y: 55, zone: "adas" }, // Right Blind Spot Sensor (RBSS)
  "0x517": { x: 85, y: 55, zone: "adas" }, // RBSS response
  "0x762": { x: 50, y: 80, zone: "adas" }, // Parktronics (PTS)
  "0x698": { x: 50, y: 80, zone: "adas" }, // Parktronics CAN-C
  "0x4E2": { x: 50, y: 80, zone: "adas" }, // PTS response
  "0x513": { x: 50, y: 80, zone: "adas" }, // PTS CAN-C response
  
  // ===== DOORS =====
  // Front Doors
  "0x640": { x: 15, y: 50, zone: "door" }, // Driver Door Module (DDM)
  "0x508": { x: 15, y: 50, zone: "door" }, // DDM response
  "0x650": { x: 85, y: 50, zone: "door" }, // Passenger Door Module (PDM)
  "0x50A": { x: 85, y: 50, zone: "door" }, // PDM response
  
  // Rear Doors
  "0x648": { x: 15, y: 60, zone: "door" }, // Rear Left Door Module (DMRL)
  "0x509": { x: 15, y: 60, zone: "door" }, // DMRL response
  "0x658": { x: 85, y: 60, zone: "door" }, // Rear Right Door Module (DMRR)
  "0x50B": { x: 85, y: 60, zone: "door" }, // DMRR response
  
  // Sliding Doors (Minivan)
  "0x678": { x: 12, y: 65, zone: "door" }, // Rear Left Power Sliding Door
  "0x50F": { x: 12, y: 65, zone: "door" }, // Left Sliding Door response
  "0x680": { x: 88, y: 65, zone: "door" }, // Rear Right Power Sliding Door
  "0x510": { x: 88, y: 65, zone: "door" }, // Right Sliding Door response
  
  // ===== SEATS & COMFORT =====
  "0x660": { x: 20, y: 45, zone: "comfort" }, // Memory Seat Driver (MSMD)
  "0x50C": { x: 20, y: 45, zone: "comfort" }, // MSMD response
  "0x6D8": { x: 25, y: 47, zone: "comfort" }, // Heated Seat Module (HSM)
  "0x51B": { x: 25, y: 47, zone: "comfort" }, // HSM response
  
  // ===== REAR MODULES =====
  "0x7A2": { x: 50, y: 75, zone: "rear" }, // Rear Fuse Box (RFH)
  "0x7A3": { x: 30, y: 80, zone: "rear" }, // Park Assist (PLM)
  "0x728": { x: 50, y: 82, zone: "rear" }, // Power LiftGate Module (PLGM)
  "0x525": { x: 50, y: 82, zone: "rear" }, // PLGM response
  "0x7A4": { x: 70, y: 80, zone: "rear" }, // Rear Camera (RCM)
  
  // ===== TRAILER & TOWING =====
  "0x743": { x: 50, y: 85, zone: "trailer" }, // Tire Pressure Monitoring (TPMS)
  "0x4C3": { x: 50, y: 85, zone: "trailer" }, // TPMS response
  "0x758": { x: 55, y: 87, zone: "trailer" }, // Trailer Tire Pressure
  "0x4D8": { x: 55, y: 87, zone: "trailer" }, // Trailer TPMS response
  "0x767": { x: 45, y: 87, zone: "trailer" }, // Trailer Interface Module (TIM)
  "0x4E7": { x: 45, y: 87, zone: "trailer" }, // TIM response
  "0x746": { x: 50, y: 90, zone: "trailer" }, // Trailer Reverse Steering
  "0x4C6": { x: 50, y: 90, zone: "trailer" }, // Trailer Steering response
  "0x4D4": { x: 52, y: 89, zone: "trailer" }, // Integrated Trailer Brake (ITBM) / ADCM
  
  // Default position for unknown modules (will be overridden by dynamic positioning)
  "default": { x: 50, y: 60, zone: "unknown" },
};

const ZONE_COLORS = {
  engine: "bg-red-500/20 border-red-500",
  transmission: "bg-orange-500/20 border-orange-500",
  dash: "bg-blue-500/20 border-blue-500",
  chassis: "bg-green-500/20 border-green-500",
  adas: "bg-cyan-500/20 border-cyan-500",
  rear: "bg-purple-500/20 border-purple-500",
  door: "bg-yellow-500/20 border-yellow-500",
  comfort: "bg-pink-500/20 border-pink-500",
  trailer: "bg-amber-500/20 border-amber-500",
  unknown: "bg-gray-500/20 border-gray-500",
};

const STATUS_COLORS = {
  online: "bg-green-500",
  offline: "bg-gray-500",
  error: "bg-red-500",
};

export function TopographicalModuleView({ 
  modules, 
  primaryVIN, 
  onModuleClick,
  onReadDTCs,
  onViewPartNumber,
  onCheckSoftwareVersion,
  onClearDTCs
}: TopographicalModuleViewProps) {
  const [hoveredModule, setHoveredModule] = useState<string | null>(null);

  const getModulePosition = (canId: string, index: number, total: number) => {
    // If module has a known position, use it
    if (MODULE_POSITIONS[canId]) {
      return MODULE_POSITIONS[canId];
    }
    
    // For unknown modules, distribute them dynamically in a grid pattern
    // to avoid stacking all at the same default position
    const cols = Math.ceil(Math.sqrt(total));
    const row = Math.floor(index / cols);
    const col = index % cols;
    
    // Place unknown modules in the lower section (60-85% height)
    // with horizontal spacing across the width
    const x = 20 + (col * (60 / cols)); // Spread across 20-80% width
    const y = 60 + (row * 8); // Stack vertically with 8% spacing
    
    return { x, y, zone: "unknown" };
  };

  return (
    <div className="relative w-full h-[600px] bg-gradient-to-b from-slate-900 to-slate-800 rounded-lg border border-slate-700 overflow-hidden">
      {/* Vehicle outline */}
      <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
        {/* Car body outline */}
        <path
          d="M 30 10 L 70 10 L 75 20 L 75 80 L 70 90 L 30 90 L 25 80 L 25 20 Z"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.5"
          className="text-slate-400"
        />
        {/* Windshield */}
        <path d="M 35 25 L 65 25 L 60 30 L 40 30 Z" fill="none" stroke="currentColor" strokeWidth="0.3" className="text-slate-400" />
        {/* Hood */}
        <path d="M 30 10 L 70 10 L 70 20 L 30 20 Z" fill="none" stroke="currentColor" strokeWidth="0.3" className="text-slate-400" />
        {/* Doors */}
        <line x1="25" y1="40" x2="25" y2="60" stroke="currentColor" strokeWidth="0.3" className="text-slate-400" />
        <line x1="75" y1="40" x2="75" y2="60" stroke="currentColor" strokeWidth="0.3" className="text-slate-400" />
      </svg>

      {/* Zone labels */}
      <div className="absolute top-2 left-2 text-xs text-slate-400 font-mono">ENGINE BAY</div>
      <div className="absolute top-1/3 left-2 text-xs text-slate-400 font-mono">DASHBOARD</div>
      <div className="absolute bottom-20 left-2 text-xs text-slate-400 font-mono">REAR</div>

      {/* CAN bus backbone (visual representation) */}
      <div className="absolute left-1/2 top-[10%] bottom-[10%] w-1 bg-gradient-to-b from-cyan-500/30 via-cyan-500/50 to-cyan-500/30 -translate-x-1/2" />

      <TooltipProvider>
        {/* Module nodes */}
        {modules.map((module, index) => {
          const position = getModulePosition(module.canId, index, modules.length);
          const isHovered = hoveredModule === module.canId;
          const zoneColor = ZONE_COLORS[position.zone as keyof typeof ZONE_COLORS] || ZONE_COLORS.unknown;
          const statusColor = STATUS_COLORS[module.status];

          return (
            <ContextMenu key={module.canId}>
              <ContextMenuTrigger asChild>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div
                      className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 ${
                        isHovered ? "scale-125 z-20" : "z-10"
                      }`}
                      style={{
                        left: `${position.x}%`,
                        top: `${position.y}%`,
                      }}
                      onMouseEnter={() => setHoveredModule(module.canId)}
                      onMouseLeave={() => setHoveredModule(null)}
                      onClick={() => onModuleClick?.(module)}
                    >
                  {/* Connection line to CAN bus */}
                  <svg
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                    style={{
                      width: `${Math.abs(50 - position.x)}%`,
                      height: "2px",
                      left: position.x > 50 ? "auto" : "50%",
                      right: position.x > 50 ? "50%" : "auto",
                    }}
                  >
                    <line
                      x1="0"
                      y1="1"
                      x2="100%"
                      y2="1"
                      stroke="currentColor"
                      strokeWidth="1"
                      className="text-cyan-500/30"
                      strokeDasharray="2,2"
                    />
                  </svg>

                  {/* Module node */}
                  <div className={`relative w-12 h-12 rounded-lg border-2 ${zoneColor} backdrop-blur-sm flex items-center justify-center`}>
                    {/* Status indicator */}
                    <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${statusColor} border-2 border-slate-900`} />

                    {/* VIN mismatch indicator */}
                    {module.vinMismatch && (
                      <div className="absolute -top-1 -left-1 w-3 h-3 rounded-full bg-yellow-500 border-2 border-slate-900 animate-pulse" />
                    )}

                    {/* Module icon/label */}
                    <div className="text-[8px] font-mono text-white text-center leading-tight">
                      {module.name.split(" ")[0]}
                      <div className="text-[6px] text-slate-400">{module.canId}</div>
                    </div>
                  </div>

                    {/* Module label (shown on hover) */}
                    {isHovered && (
                      <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white whitespace-nowrap">
                        {module.name}
                      </div>
                    )}
                  </div>
                </TooltipTrigger>
              <TooltipContent side="right" className="max-w-xs">
                <div className="space-y-1">
                  <div className="font-semibold">{module.name}</div>
                  <div className="text-xs text-muted-foreground">CAN ID: {module.canId}</div>
                  {module.vin && (
                    <div className="text-xs">
                      VIN: <span className="font-mono">{module.vin}</span>
                      {module.vinMismatch && <Badge variant="destructive" className="ml-2 text-[10px]">MISMATCH</Badge>}
                    </div>
                  )}
                  {module.partNumber && <div className="text-xs">P/N: {module.partNumber}</div>}
                  {module.softwareVersion && <div className="text-xs">SW: {module.softwareVersion}</div>}
                  {module.hardwareVersion && <div className="text-xs">HW: {module.hardwareVersion}</div>}
                  {module.responseTime && <div className="text-xs">Response: {module.responseTime}ms</div>}
                  <div className="flex items-center gap-2 pt-1">
                    <div className={`w-2 h-2 rounded-full ${statusColor}`} />
                    <span className="text-xs capitalize">{module.status}</span>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </ContextMenuTrigger>
          <ContextMenuContent className="w-56">
            <ContextMenuItem onClick={() => onModuleClick?.(module)}>
              <FileText className="mr-2 h-4 w-4" />
              View Details
            </ContextMenuItem>
            <ContextMenuSeparator />
            <ContextMenuItem 
              onClick={() => onReadDTCs?.(module)}
              disabled={module.status !== "online"}
            >
              <AlertCircle className="mr-2 h-4 w-4" />
              Read DTCs
            </ContextMenuItem>
            <ContextMenuItem 
              onClick={() => onViewPartNumber?.(module)}
              disabled={module.status !== "online"}
            >
              <Code className="mr-2 h-4 w-4" />
              View Part Number
            </ContextMenuItem>
            <ContextMenuItem 
              onClick={() => onCheckSoftwareVersion?.(module)}
              disabled={module.status !== "online"}
            >
              <Wrench className="mr-2 h-4 w-4" />
              Check Software Version
            </ContextMenuItem>
            <ContextMenuSeparator />
            <ContextMenuItem 
              onClick={() => onClearDTCs?.(module)}
              disabled={module.status !== "online"}
              className="text-red-500 focus:text-red-500"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Clear DTCs
            </ContextMenuItem>
          </ContextMenuContent>
        </ContextMenu>
          );
        })}
      </TooltipProvider>

      {/* Legend */}
      <Card className="absolute bottom-4 right-4 p-3 bg-slate-900/90 backdrop-blur border-slate-700">
        <div className="text-xs font-semibold mb-2">Status</div>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-xs">Online</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
            <span className="text-xs">VIN Mismatch</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-gray-500" />
            <span className="text-xs">Offline</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500" />
            <span className="text-xs">Error</span>
          </div>
        </div>
      </Card>

      {/* Primary VIN display */}
      {primaryVIN && (
        <div className="absolute top-4 right-4 px-3 py-2 bg-slate-900/90 backdrop-blur border border-slate-700 rounded">
          <div className="text-xs text-slate-400">Primary VIN</div>
          <div className="font-mono text-sm text-white">{primaryVIN}</div>
        </div>
      )}
    </div>
  );
}
