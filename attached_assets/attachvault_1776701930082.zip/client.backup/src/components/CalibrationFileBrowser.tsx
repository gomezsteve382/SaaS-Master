import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Download, Upload, Trash2, FileText } from 'lucide-react';
import { toast } from 'sonner';

interface CalibrationFileBrowserProps {
  onSelectFile?: (filename: string, data: ArrayBuffer) => void;
}

export default function CalibrationFileBrowser({ onSelectFile }: CalibrationFileBrowserProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'size' | 'type'>('name');

  const { data: files, refetch } = trpc.vinPatcher.listCalibrationFiles.useQuery();
  const [selectedFilename, setSelectedFilename] = useState<string | null>(null);
  
  // Download file query (enabled only when selectedFilename is set)
  const { data: downloadedFile, refetch: refetchDownload } = trpc.vinPatcher.downloadCalibrationFile.useQuery(
    { filename: selectedFilename || '' },
    { enabled: !!selectedFilename }
  );

  const handleLoadFile = async (filename: string) => {
    try {
      setSelectedFilename(filename);
      const result = await refetchDownload();
      
      if (!result.data) {
        throw new Error('Failed to download file');
      }
      
      // Convert base64 to ArrayBuffer
      const binaryString = atob(result.data.data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      if (onSelectFile) {
        onSelectFile(filename, bytes.buffer);
      }
      
      toast.success(`Loaded ${filename}`);
    } catch (error: any) {
      toast.error(`Failed to load file: ${error.message}`);
    }
  };

  const handleDownloadFile = async (filename: string) => {
    try {
      setSelectedFilename(filename);
      const result = await refetchDownload();
      
      if (!result.data) {
        throw new Error('Failed to download file');
      }
      
      // Convert base64 to blob
      const binaryString = atob(result.data.data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      const blob = new Blob([bytes]);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success(`Downloaded ${filename}`);
    } catch (error: any) {
      toast.error(`Failed to download: ${error.message}`);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  };

  const getModuleTypeBadgeColor = (type: string): string => {
    switch (type) {
      case 'BCM':
        return 'bg-blue-500';
      case 'RFHUB':
        return 'bg-purple-500';
      case 'ECM':
        return 'bg-green-500';
      case 'TCM':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  // Filter and sort files
  const filteredFiles = files?.filter(file =>
    file.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (file.moduleType && file.moduleType.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (file.vin && file.vin.toLowerCase().includes(searchQuery.toLowerCase()))
  ) || [];

  const sortedFiles = [...filteredFiles].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.filename.localeCompare(b.filename);
      case 'size':
        return b.size - a.size;
      case 'type':
        return (a.moduleType || '').localeCompare(b.moduleType || '');
      default:
        return 0;
    }
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Calibration File Library</CardTitle>
        <CardDescription>
          Browse and manage {files?.length || 0} calibration files
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search and Controls */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by filename, module type, or VIN..."
              className="pl-10"
            />
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'name' | 'size' | 'type')}
            className="px-3 py-2 border rounded-md"
          >
            <option value="name">Sort by Name</option>
            <option value="size">Sort by Size</option>
            <option value="type">Sort by Type</option>
          </select>
        </div>

        {/* File Table */}
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Filename</TableHead>
                <TableHead>Module Type</TableHead>
                <TableHead>VIN</TableHead>
                <TableHead>Size</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedFiles.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground">
                    {searchQuery ? 'No files match your search' : 'No calibration files found'}
                  </TableCell>
                </TableRow>
              ) : (
                sortedFiles.map((file) => (
                  <TableRow key={file.filename} className="hover:bg-muted/50">
                    <TableCell className="font-mono text-sm">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        {file.filename}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getModuleTypeBadgeColor(file.moduleType || 'UNKNOWN')}>
                        {file.moduleType || 'UNKNOWN'}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {file.vin || <span className="text-muted-foreground">N/A</span>}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatFileSize(file.size)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex gap-2 justify-end">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleLoadFile(file.filename)}
                        >
                          Load
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownloadFile(file.filename)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Summary */}
        <div className="flex gap-4 text-sm text-muted-foreground">
          <span>{sortedFiles.length} files shown</span>
          {searchQuery && <span>• Filtered from {files?.length || 0} total</span>}
        </div>
      </CardContent>
    </Card>
  );
}
