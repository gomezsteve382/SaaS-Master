import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useDemoMode } from '@/contexts/DemoModeContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { getAllDemoVehicles } from '@shared/demo-vehicles';

export function DemoModeToggle() {
  const { isDemoMode, setDemoMode, currentVehicle, setCurrentVehicle } = useDemoMode();
  const vehicles = getAllDemoVehicles();

  return (
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-2">
        <Switch
          id="demo-mode"
          checked={isDemoMode}
          onCheckedChange={setDemoMode}
        />
        <Label htmlFor="demo-mode" className="cursor-pointer">
          Demo Mode
        </Label>
      </div>

      {isDemoMode && (
        <Select value={currentVehicle} onValueChange={setCurrentVehicle}>
          <SelectTrigger className="w-[240px]">
            <SelectValue placeholder="Select vehicle" />
          </SelectTrigger>
          <SelectContent>
            {vehicles.map((vehicle) => (
              <SelectItem key={vehicle.id} value={vehicle.id}>
                {vehicle.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}
