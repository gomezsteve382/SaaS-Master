import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Search, Download } from 'lucide-react';

interface HexViewerProps {
  data: ArrayBuffer | null;
  vinOffsets?: {
    primary_vin_offset: string;
    backup_vin_offset?: string;
    primary_crc_offset: string;
    backup_crc_offset?: string;
    rfhub_secret_key_offset?: string;
    b_number_offset?: string;
  };
  moduleType?: string;
}

interface HighlightRegion {
  start: number;
  end: number;
  color: string;
  label: string;
}

export default function HexViewer({ data, vinOffsets, moduleType }: HexViewerProps) {
  const [jumpOffset, setJumpOffset] = useState('');
  const [highlightRegions, setHighlightRegions] = useState<HighlightRegion[]>([]);
  const [bytes, setBytes] = useState<Uint8Array | null>(null);

  useEffect(() => {
    if (!data) {
      setBytes(null);
      return;
    }

    const byteArray = new Uint8Array(data);
    setBytes(byteArray);

    // Calculate highlight regions from VIN offsets
    if (vinOffsets) {
      const regions: HighlightRegion[] = [];

      // Primary VIN (green)
      if (vinOffsets.primary_vin_offset) {
        const offset = parseInt(vinOffsets.primary_vin_offset, 16);
        regions.push({
          start: offset,
          end: offset + 17,
          color: 'bg-green-200/50 border-green-500',
          label: 'Primary VIN',
        });
      }

      // Backup VIN (yellow)
      if (vinOffsets.backup_vin_offset) {
        const offset = parseInt(vinOffsets.backup_vin_offset, 16);
        regions.push({
          start: offset,
          end: offset + 17,
          color: 'bg-yellow-200/50 border-yellow-500',
          label: 'Backup VIN',
        });
      }

      // Primary CRC (blue)
      if (vinOffsets.primary_crc_offset) {
        const offset = parseInt(vinOffsets.primary_crc_offset, 16);
        regions.push({
          start: offset,
          end: offset + 2,
          color: 'bg-blue-200/50 border-blue-500',
          label: 'Primary CRC',
        });
      }

      // Backup CRC (cyan)
      if (vinOffsets.backup_crc_offset) {
        const offset = parseInt(vinOffsets.backup_crc_offset, 16);
        regions.push({
          start: offset,
          end: offset + 2,
          color: 'bg-cyan-200/50 border-cyan-500',
          label: 'Backup CRC',
        });
      }

      // RFHUB Secret Key (red)
      if (vinOffsets.rfhub_secret_key_offset) {
        const offset = parseInt(vinOffsets.rfhub_secret_key_offset, 16);
        regions.push({
          start: offset,
          end: offset + 16,
          color: 'bg-red-200/50 border-red-500',
          label: 'RFHUB Secret Key',
        });
      }

      // B-Number (purple)
      if (vinOffsets.b_number_offset) {
        const offset = parseInt(vinOffsets.b_number_offset, 16);
        regions.push({
          start: offset,
          end: offset + 16,
          color: 'bg-purple-200/50 border-purple-500',
          label: 'B-Number',
        });
      }

      setHighlightRegions(regions);
    }
  }, [data, vinOffsets]);

  const handleJumpToOffset = () => {
    if (!jumpOffset) return;
    
    try {
      const offset = parseInt(jumpOffset, 16);
      const element = document.getElementById(`byte-${offset}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        element.classList.add('ring-2', 'ring-red-500');
        setTimeout(() => {
          element.classList.remove('ring-2', 'ring-red-500');
        }, 2000);
      }
    } catch (error) {
      console.error('Invalid offset:', error);
    }
  };

  const getHighlightForByte = (offset: number): HighlightRegion | null => {
    return highlightRegions.find(region => offset >= region.start && offset < region.end) || null;
  };

  const downloadHexDump = () => {
    if (!bytes) return;

    let hexDump = '';
    for (let i = 0; i < bytes.length; i += 16) {
      const offsetStr = i.toString(16).padStart(8, '0').toUpperCase();
      const hexBytes = Array.from(bytes.slice(i, i + 16))
        .map(b => b.toString(16).padStart(2, '0').toUpperCase())
        .join(' ');
      const asciiBytes = Array.from(bytes.slice(i, i + 16))
        .map(b => (b >= 32 && b <= 126) ? String.fromCharCode(b) : '.')
        .join('');
      
      hexDump += `${offsetStr}  ${hexBytes.padEnd(48, ' ')}  ${asciiBytes}\\n`;
    }

    const blob = new Blob([hexDump], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hexdump_${moduleType || 'module'}_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!bytes) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-muted-foreground">No data to display</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Controls */}
      <Card>
        <CardHeader>
          <CardTitle>Hex Viewer</CardTitle>
          <CardDescription>
            Byte-level view with VIN, checksum, and key highlighting
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Jump to offset */}
          <div className="flex gap-2">
            <div className="flex-1">
              <Label htmlFor="jumpOffset">Jump to Offset (hex)</Label>
              <Input
                id="jumpOffset"
                value={jumpOffset}
                onChange={(e) => setJumpOffset(e.target.value)}
                placeholder="0x0100"
                className="font-mono"
              />
            </div>
            <Button onClick={handleJumpToOffset} className="mt-6">
              <Search className="h-4 w-4 mr-2" />
              Jump
            </Button>
            <Button onClick={downloadHexDump} variant="outline" className="mt-6">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-2">
            {highlightRegions.map((region, index) => (
              <Badge
                key={index}
                variant="outline"
                className={`${region.color} border`}
              >
                {region.label}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Hex Dump */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-auto max-h-[600px] font-mono text-xs">
            <div className="p-4 space-y-1">
              {Array.from({ length: Math.ceil(bytes.length / 16) }).map((_, rowIndex) => {
                const offset = rowIndex * 16;
                const rowBytes = bytes.slice(offset, offset + 16);
                
                return (
                  <div key={offset} className="flex gap-4 hover:bg-muted/50">
                    {/* Offset */}
                    <div className="text-muted-foreground w-20 flex-shrink-0">
                      {offset.toString(16).padStart(8, '0').toUpperCase()}
                    </div>

                    {/* Hex bytes */}
                    <div className="flex gap-1 flex-1">
                      {Array.from(rowBytes).map((byte, byteIndex) => {
                        const byteOffset = offset + byteIndex;
                        const highlight = getHighlightForByte(byteOffset);
                        
                        return (
                          <span
                            key={byteIndex}
                            id={`byte-${byteOffset}`}
                            className={`px-1 rounded transition-all ${
                              highlight ? `${highlight.color} border` : ''
                            }`}
                            title={highlight ? `${highlight.label} (0x${byteOffset.toString(16).toUpperCase()})` : undefined}
                          >
                            {byte.toString(16).padStart(2, '0').toUpperCase()}
                          </span>
                        );
                      })}
                      {/* Padding for incomplete rows */}
                      {Array.from({ length: 16 - rowBytes.length }).map((_, i) => (
                        <span key={`pad-${i}`} className="px-1 opacity-0">00</span>
                      ))}
                    </div>

                    {/* ASCII */}
                    <div className="text-muted-foreground w-32 flex-shrink-0">
                      {Array.from(rowBytes).map((byte, byteIndex) => {
                        const char = byte >= 32 && byte <= 126 ? String.fromCharCode(byte) : '.';
                        const byteOffset = offset + byteIndex;
                        const highlight = getHighlightForByte(byteOffset);
                        
                        return (
                          <span
                            key={byteIndex}
                            className={highlight ? 'font-bold text-foreground' : ''}
                          >
                            {char}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
