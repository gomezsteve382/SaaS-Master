/**
 * Flash File Versions Component
 * 
 * Version history with rollback capability
 */

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  History, 
  Upload, 
  Download, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle,
  Calendar,
  User,
  FileText,
  Loader2
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface FlashFileVersionsProps {
  calibrationId: number;
  calibrationName: string;
}

export function FlashFileVersions({ calibrationId, calibrationName }: FlashFileVersionsProps) {
  const [showUpload, setShowUpload] = useState(false);
  const [versionNumber, setVersionNumber] = useState('');
  const [versionTag, setVersionTag] = useState('');
  const [changelog, setChangelog] = useState('');
  const [uploadedBy, setUploadedBy] = useState('');
  const [setAsActive, setSetAsActive] = useState(false);
  const { toast } = useToast();

  const { data: versions, isLoading, refetch } = trpc.j2534.getFlashVersions.useQuery({
    calibrationId,
  });

  const uploadVersion = trpc.j2534.uploadFlashVersion.useMutation({
    onSuccess: () => {
      toast({
        title: "✅ Version Uploaded",
        description: "New flash file version created successfully",
      });
      refetch();
      setShowUpload(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "❌ Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const rollback = trpc.j2534.rollbackToVersion.useMutation({
    onSuccess: (data) => {
      toast({
        title: "✅ Rollback Successful",
        description: `Activated version ${data.version.versionNumber}`,
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "❌ Rollback Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setVersionNumber('');
    setVersionTag('');
    setChangelog('');
    setUploadedBy('');
    setSetAsActive(false);
  };

  const handleFileUpload = async (file: File) => {
    if (!versionNumber) {
      toast({
        title: "❌ Version Number Required",
        description: "Please enter a version number",
        variant: "destructive",
      });
      return;
    }

    // Read file as base64
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64Data = e.target?.result as string;
      const base64 = base64Data.split(',')[1];

      const fileExt = file.name.substring(file.name.lastIndexOf('.') + 1).toLowerCase();

      await uploadVersion.mutateAsync({
        calibrationId,
        versionNumber,
        versionTag: versionTag || undefined,
        fileData: base64,
        fileName: file.name,
        fileType: fileExt as 'hex' | 'bin' | 'cal',
        changelog: changelog || undefined,
        uploadedBy: uploadedBy || undefined,
        setAsActive,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleRollback = (versionId: number, versionNumber: string) => {
    if (confirm(`Rollback to version ${versionNumber}? This will make it the active version.`)) {
      rollback.mutate({ versionId });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <Loader2 className="h-8 w-8 mx-auto mb-2 animate-spin text-muted-foreground" />
          <p className="text-muted-foreground">Loading version history...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Flash File Versions
            </CardTitle>
            <CardDescription>
              {calibrationName} - {versions?.length || 0} version{versions?.length !== 1 ? 's' : ''}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            onClick={() => setShowUpload(!showUpload)}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload New Version
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Upload Form */}
        {showUpload && (
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-base">Upload New Version</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium mb-1 block">Version Number *</label>
                  <Input
                    placeholder="e.g., 1.0.0, 2024-01-15"
                    value={versionNumber}
                    onChange={(e) => setVersionNumber(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Version Tag</label>
                  <Input
                    placeholder="e.g., production, beta, hotfix"
                    value={versionTag}
                    onChange={(e) => setVersionTag(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Uploaded By</label>
                <Input
                  placeholder="Your name or technician ID"
                  value={uploadedBy}
                  onChange={(e) => setUploadedBy(e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Changelog</label>
                <Textarea
                  placeholder="What changed in this version?"
                  value={changelog}
                  onChange={(e) => setChangelog(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="set-active"
                  checked={setAsActive}
                  onChange={(e) => setSetAsActive(e.target.checked)}
                  className="rounded"
                />
                <label htmlFor="set-active" className="text-sm font-medium cursor-pointer">
                  Set as active version (will update main calibration record)
                </label>
              </div>

              <div className="flex gap-2">
                <label className="flex-1">
                  <input
                    type="file"
                    accept=".hex,.bin,.cal"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                  />
                  <Button
                    variant="default"
                    className="w-full"
                    disabled={uploadVersion.isPending}
                    onClick={(e) => {
                      e.preventDefault();
                      (e.currentTarget.previousElementSibling as HTMLInputElement)?.click();
                    }}
                  >
                    {uploadVersion.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Select File
                      </>
                    )}
                  </Button>
                </label>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowUpload(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Version List */}
        {versions && versions.length > 0 ? (
          <div className="space-y-3">
            {versions.map((version: any) => (
              <Card
                key={version.id}
                className={`border-2 ${
                  version.isActive
                    ? 'border-green-500 bg-green-50'
                    : version.isDeprecated
                    ? 'border-gray-300 bg-gray-50'
                    : 'border-muted'
                }`}
              >
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-lg">v{version.versionNumber}</h4>
                        {version.versionTag && (
                          <Badge variant="outline">{version.versionTag}</Badge>
                        )}
                        {version.isActive && (
                          <Badge className="bg-green-500">ACTIVE</Badge>
                        )}
                        {version.isDeprecated && (
                          <Badge variant="secondary">DEPRECATED</Badge>
                        )}
                      </div>
                      {version.changelog && (
                        <p className="text-sm text-muted-foreground mb-2">
                          {version.changelog}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      <span>{new Date(version.uploadedAt).toLocaleString()}</span>
                    </div>
                    {version.uploadedBy && (
                      <div className="flex items-center gap-2">
                        <User className="h-3 w-3 text-muted-foreground" />
                        <span>{version.uploadedBy}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <FileText className="h-3 w-3 text-muted-foreground" />
                      <span>{(version.flashFileSize / 1024).toFixed(1)} KB</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono text-xs">
                      <CheckCircle2 className="h-3 w-3 text-green-500" />
                      <span className="truncate">{version.flashFileChecksum.substring(0, 12)}...</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(version.flashFileUrl, '_blank')}
                    >
                      <Download className="mr-2 h-3 w-3" />
                      Download
                    </Button>
                    {!version.isActive && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRollback(version.id, version.versionNumber)}
                        disabled={rollback.isPending}
                      >
                        <RotateCcw className="mr-2 h-3 w-3" />
                        Rollback
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              No versions uploaded yet. Upload the first version to start tracking changes.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
