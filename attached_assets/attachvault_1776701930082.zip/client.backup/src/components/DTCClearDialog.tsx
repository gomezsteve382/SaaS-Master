import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DTCClearDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function DTCClearDialog({ open, onOpenChange, onSuccess }: DTCClearDialogProps) {
  const [confirmed, setConfirmed] = useState(false);
  const [reason, setReason] = useState('');
  const { toast } = useToast();

  const clearMutation = trpc.dtc.clearDTCs.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: 'DTCs Cleared',
          description: data.message,
        });
        onOpenChange(false);
        setConfirmed(false);
        setReason('');
        onSuccess?.();
      } else {
        toast({
          title: 'Clear Failed',
          description: data.error || 'Failed to clear DTCs',
          variant: 'destructive',
        });
      }
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleClear = () => {
    if (!confirmed) {
      toast({
        title: 'Confirmation Required',
        description: 'Please confirm that you understand the implications of clearing DTCs',
        variant: 'destructive',
      });
      return;
    }

    clearMutation.mutate({ confirmed, reason });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-yellow-500" />
            Clear Diagnostic Trouble Codes
          </DialogTitle>
          <DialogDescription>
            This action will clear all DTCs from the vehicle's ECU and reset the Check Engine Light (MIL).
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Warning */}
          <div className="rounded-lg border border-yellow-500/50 bg-yellow-500/10 p-4">
            <h4 className="font-semibold text-yellow-600 dark:text-yellow-400 mb-2">⚠️ Important Warnings</h4>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
              <li>DTCs should only be cleared AFTER diagnosing and repairing the root cause</li>
              <li>Clearing codes without repair will cause them to return</li>
              <li>Some vehicles require a drive cycle to complete readiness monitors</li>
              <li>Emissions testing may fail if readiness monitors are not complete</li>
              <li>This action is logged for compliance and audit purposes</li>
            </ul>
          </div>

          {/* Reason */}
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Clearing (Optional)</Label>
            <Textarea
              id="reason"
              placeholder="e.g., Replaced oxygen sensor, cleared after repair verification"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
          </div>

          {/* Confirmation */}
          <div className="flex items-start space-x-2">
            <Checkbox
              id="confirm"
              checked={confirmed}
              onCheckedChange={(checked) => setConfirmed(checked as boolean)}
            />
            <Label
              htmlFor="confirm"
              className="text-sm font-normal leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              I confirm that I have diagnosed and repaired the root cause of the DTCs, and I understand that this action will be logged for audit purposes.
            </Label>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={clearMutation.isPending}
          >
            Cancel
          </Button>
          <Button
            onClick={handleClear}
            disabled={!confirmed || clearMutation.isPending}
            variant="destructive"
          >
            {clearMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Clear DTCs
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
