/**
 * BackupManager Component
 * 
 * Manages module backups and restore operations with one-click functionality
 */

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Download,
  HardDrive,
  RefreshCw,
  Search,
  Shield,
  Trash2,
  XCircle,
  Database,
  ArrowUpDown,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

const STATUS_COLORS = {
  completed: "bg-green-500/20 text-green-500 border-green-500",
  partial: "bg-yellow-500/20 text-yellow-500 border-yellow-500",
  failed: "bg-red-500/20 text-red-500 border-red-500",
  in_progress: "bg-blue-500/20 text-blue-500 border-blue-500",
};

const BACKUP_TYPE_LABELS = {
  manual: "Manual",
  pre_template: "Pre-Template",
  scheduled: "Scheduled",
  emergency: "Emergency",
};

interface BackupManagerProps {
  moduleCode?: string;
  vin?: string;
  onBackupCreated?: (backupId: number) => void;
  onRestoreCompleted?: (restoreId: number) => void;
}

export function BackupManager({ moduleCode, vin, onBackupCreated, onRestoreCompleted }: BackupManagerProps) {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBackup, setSelectedBackup] = useState<any>(null);
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [showCompareDialog, setShowCompareDialog] = useState(false);
  const [compareBackup1, setCompareBackup1] = useState<number | null>(null);
  const [compareBackup2, setCompareBackup2] = useState<number | null>(null);
  const [restoreOptions, setRestoreOptions] = useState({
    skipVIN: true,
    verificationEnabled: true,
    selectedDIDs: [] as string[],
  });

  // Query backups
  const { data: backups, isLoading, refetch } = trpc.backupRestore.listBackups.useQuery({
    moduleCode,
    vin,
    limit: 100,
  });

  // Get backup details
  const { data: backupDetails, isLoading: loadingDetails } = trpc.backupRestore.getBackup.useQuery(
    { backupId: selectedBackup?.id || 0 },
    { enabled: !!selectedBackup }
  );

  // Delete backup mutation
  const deleteBackupMutation = trpc.backupRestore.deleteBackup.useMutation({
    onSuccess: () => {
      toast({
        title: "Backup Deleted",
        description: "Backup has been deleted successfully",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Compare backups mutation
  const compareBackupsMutation = trpc.backupRestore.compareBackups.useMutation({
    onSuccess: (data) => {
      toast({
        title: "Comparison Complete",
        description: `Found ${data.differentDIDs} differences out of ${data.totalDIDs} DIDs`,
      });
      // Show comparison results
      console.log("Comparison results:", data);
    },
    onError: (error) => {
      toast({
        title: "Comparison Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleViewDetails = (backup: any) => {
    setSelectedBackup(backup);
    setShowDetailsDialog(true);
  };

  const handleRestore = (backup: any) => {
    setSelectedBackup(backup);
    setShowRestoreDialog(true);
  };

  const handleDeleteBackup = async (backupId: number) => {
    if (!confirm("Are you sure you want to delete this backup? This action cannot be undone.")) {
      return;
    }
    await deleteBackupMutation.mutateAsync({ backupId });
  };

  const handleCompareBackups = () => {
    if (!compareBackup1 || !compareBackup2) {
      toast({
        title: "Selection Required",
        description: "Please select two backups to compare",
        variant: "destructive",
      });
      return;
    }
    compareBackupsMutation.mutate({
      backup1Id: compareBackup1,
      backup2Id: compareBackup2,
    });
  };

  const filteredBackups = backups?.filter((backup) => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      backup.name.toLowerCase().includes(search) ||
      backup.moduleCode.toLowerCase().includes(search) ||
      backup.moduleName.toLowerCase().includes(search) ||
      backup.vin?.toLowerCase().includes(search)
    );
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
            <span className="ml-2 text-muted-foreground">Loading backups...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Module Backups
              </CardTitle>
              <CardDescription>
                View and manage module backups with one-click restore capability
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowCompareDialog(true)}
                disabled={!backups || backups.length < 2}
              >
                <ArrowUpDown className="h-4 w-4 mr-2" />
                Compare
              </Button>
              <Button variant="outline" size="sm" onClick={() => refetch()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search backups by name, module, or VIN..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Backups Table */}
          {filteredBackups && filteredBackups.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Module</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>DIDs</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBackups.map((backup) => (
                    <TableRow key={backup.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{backup.name}</div>
                          {backup.description && (
                            <div className="text-sm text-muted-foreground">{backup.description}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{backup.moduleName}</div>
                          <div className="text-sm text-muted-foreground">{backup.moduleCode}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {BACKUP_TYPE_LABELS[backup.backupType as keyof typeof BACKUP_TYPE_LABELS]}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={STATUS_COLORS[backup.status as keyof typeof STATUS_COLORS]}>
                          {backup.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div className="text-green-500">{backup.successCount} success</div>
                          {backup.failureCount > 0 && (
                            <div className="text-red-500">{backup.failureCount} failed</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm text-muted-foreground">
                          {backup.createdAt && formatDistanceToNow(new Date(backup.createdAt), { addSuffix: true })}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewDetails(backup)}
                          >
                            <HardDrive className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRestore(backup)}
                            disabled={backup.status !== "completed"}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteBackup(backup.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              <Database className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>No backups found</p>
              {searchTerm && <p className="text-sm">Try adjusting your search terms</p>}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Backup Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Backup Details</DialogTitle>
            <DialogDescription>
              View all DIDs captured in this backup
            </DialogDescription>
          </DialogHeader>
          {loadingDetails ? (
            <div className="py-8 text-center">
              <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Loading details...</p>
            </div>
          ) : backupDetails ? (
            <div className="space-y-4">
              {/* Summary */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Module</Label>
                  <p className="text-sm">{backupDetails.moduleName} ({backupDetails.moduleCode})</p>
                </div>
                <div>
                  <Label>VIN</Label>
                  <p className="text-sm">{backupDetails.vin || "N/A"}</p>
                </div>
                <div>
                  <Label>Duration</Label>
                  <p className="text-sm">{backupDetails.duration ? `${(backupDetails.duration / 1000).toFixed(1)}s` : "N/A"}</p>
                </div>
                <div>
                  <Label>Status</Label>
                  <Badge className={STATUS_COLORS[backupDetails.status as keyof typeof STATUS_COLORS]}>
                    {backupDetails.status}
                  </Badge>
                </div>
              </div>

              {/* DIDs Table */}
              <div>
                <Label className="mb-2 block">DIDs ({backupDetails.dids.length})</Label>
                <div className="rounded-md border max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>DID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Value</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {backupDetails.dids.map((did: any) => (
                        <TableRow key={did.id}>
                          <TableCell className="font-mono text-sm">{did.did}</TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium">{did.didName}</div>
                              {did.isCritical && (
                                <Badge variant="outline" className="text-xs mt-1">
                                  <Shield className="h-3 w-3 mr-1" />
                                  Critical
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-mono text-xs">
                              {did.decodedValue || did.rawValue}
                            </div>
                          </TableCell>
                          <TableCell>
                            {did.success ? (
                              <CheckCircle2 className="h-4 w-4 text-green-500" />
                            ) : (
                              <XCircle className="h-4 w-4 text-red-500" />
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* Restore Dialog */}
      <Dialog open={showRestoreDialog} onOpenChange={setShowRestoreDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restore Module Backup</DialogTitle>
            <DialogDescription>
              Configure restore options and execute
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Alert className="border-yellow-500/50 bg-yellow-500/10">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <div className="ml-2">
                <p className="text-sm font-medium">Warning</p>
                <p className="text-sm text-muted-foreground">
                  This will overwrite the current module configuration. Make sure you have a backup of the current state.
                </p>
              </div>
            </Alert>

            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="skipVIN"
                  checked={restoreOptions.skipVIN}
                  onCheckedChange={(checked) =>
                    setRestoreOptions({ ...restoreOptions, skipVIN: checked as boolean })
                  }
                />
                <Label htmlFor="skipVIN" className="text-sm">
                  Skip VIN restore (recommended for safety)
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="verification"
                  checked={restoreOptions.verificationEnabled}
                  onCheckedChange={(checked) =>
                    setRestoreOptions({ ...restoreOptions, verificationEnabled: checked as boolean })
                  }
                />
                <Label htmlFor="verification" className="text-sm">
                  Enable verification (read back after write)
                </Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRestoreDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                toast({
                  title: "Restore Started",
                  description: "Module restore operation has been initiated",
                });
                setShowRestoreDialog(false);
                // TODO: Implement actual restore logic
              }}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Start Restore
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Compare Dialog */}
      <Dialog open={showCompareDialog} onOpenChange={setShowCompareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Compare Backups</DialogTitle>
            <DialogDescription>
              Select two backups to compare their DIDs
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>First Backup</Label>
              <select
                className="w-full rounded-md border p-2"
                value={compareBackup1 || ""}
                onChange={(e) => setCompareBackup1(Number(e.target.value))}
              >
                <option value="">Select backup...</option>
                {backups?.map((backup) => (
                  <option key={backup.id} value={backup.id}>
                    {backup.name} - {backup.moduleName}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Second Backup</Label>
              <select
                className="w-full rounded-md border p-2"
                value={compareBackup2 || ""}
                onChange={(e) => setCompareBackup2(Number(e.target.value))}
              >
                <option value="">Select backup...</option>
                {backups?.map((backup) => (
                  <option key={backup.id} value={backup.id}>
                    {backup.name} - {backup.moduleName}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCompareDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCompareBackups}>
              <ArrowUpDown className="h-4 w-4 mr-2" />
              Compare
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Alert({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={`rounded-lg border p-4 ${className}`}>{children}</div>;
}
