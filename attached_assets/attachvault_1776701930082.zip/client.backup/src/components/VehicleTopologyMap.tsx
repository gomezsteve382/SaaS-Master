/**
 * Vehicle Topology Map
 * Visual representation of all vehicle modules with real-time status
 * Modules light up based on communication status and fault codes
 */

import { useEffect, useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { trpc } from '@/lib/trpc';

/**
 * Module status
 */
export type ModuleStatus = 'active' | 'fault' | 'warning' | 'offline' | 'communicating';

/**
 * Vehicle module definition
 */
export interface VehicleModule {
  id: string;
  name: string;
  code: string; // ECM, BCM, TCM, etc.
  canId?: number;
  rxId?: number;
  status: ModuleStatus;
  dtcCount: number;
  vin?: string;
  partNumber?: string;
  softwareVersion?: string;
  position: { x: number; y: number }; // Position on the map (percentage)
}

/**
 * Module icon component
 */
function ModuleIcon({ module, onClick }: { module: VehicleModule; onClick: () => void }) {
  const getStatusColor = () => {
    switch (module.status) {
      case 'active':
        return 'bg-green-500/20 border-green-500 shadow-green-500/50';
      case 'fault':
        return 'bg-red-500/20 border-red-500 shadow-red-500/50 animate-pulse';
      case 'warning':
        return 'bg-yellow-500/20 border-yellow-500 shadow-yellow-500/50';
      case 'communicating':
        return 'bg-blue-500/20 border-blue-500 shadow-blue-500/50 animate-pulse';
      case 'offline':
      default:
        return 'bg-gray-500/10 border-gray-600';
    }
  };

  const getIcon = () => {
    switch (module.code) {
      case 'ECM':
      case 'PCM':
        return '🔧'; // Engine
      case 'TCM':
        return '⚙️'; // Transmission
      case 'BCM':
        return '🚗'; // Body
      case 'ABS':
      case 'ESP':
        return '🛑'; // Brakes
      case 'Radio':
      case 'Uconnect':
        return '📻'; // Radio
      case 'Cluster':
      case 'IPC':
        return '📊'; // Gauges
      case 'SKIM':
      case 'RFHUB':
      case 'WCM':
        return '🔑'; // Security
      case 'ORC':
      case 'ACM':
        return '🎈'; // Airbag
      case 'HVAC':
        return '❄️'; // Climate
      case 'Gateway':
        return '🌐'; // Network
      default:
        return '📦'; // Generic module
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={onClick}
            className={`
              relative flex flex-col items-center justify-center
              w-20 h-20 rounded-lg border-2 transition-all duration-300
              hover:scale-110 cursor-pointer
              ${getStatusColor()}
              ${module.status !== 'offline' ? 'shadow-lg' : ''}
            `}
            style={{
              position: 'absolute',
              left: `${module.position.x}%`,
              top: `${module.position.y}%`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            <div className="text-2xl mb-1">{getIcon()}</div>
            <div className="text-xs font-bold text-white">{module.code}</div>
            {module.dtcCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs"
              >
                {module.dtcCount}
              </Badge>
            )}
          </button>
        </TooltipTrigger>
        <TooltipContent side="right" className="max-w-sm">
          <div className="space-y-1">
            <div className="font-bold">{module.name}</div>
            <div className="text-xs text-muted-foreground">
              CAN ID: 0x{module.canId?.toString(16).toUpperCase() || 'N/A'}
            </div>
            {module.vin && (
              <div className="text-xs">VIN: {module.vin}</div>
            )}
            {module.partNumber && (
              <div className="text-xs">Part: {module.partNumber}</div>
            )}
            <div className="text-xs">
              Status: <span className={`font-bold ${
                module.status === 'active' ? 'text-green-500' :
                module.status === 'fault' ? 'text-red-500' :
                module.status === 'warning' ? 'text-yellow-500' :
                'text-gray-500'
              }`}>
                {module.status.toUpperCase()}
              </span>
            </div>
            {module.dtcCount > 0 && (
              <div className="text-xs text-red-500 font-bold">
                {module.dtcCount} Fault{module.dtcCount > 1 ? 's' : ''}
              </div>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

/**
 * Default module layout for Dodge Charger/Challenger
 */
const DEFAULT_MODULE_LAYOUT: Omit<VehicleModule, 'status' | 'dtcCount'>[] = [
  // Top tier - Gateway
  { id: 'gateway', name: 'CAN Gateway', code: 'Gateway', position: { x: 50, y: 10 } },
  
  // Second tier - Primary control modules
  { id: 'ecm', name: 'Engine Control Module', code: 'ECM', canId: 0x7E0, rxId: 0x7E8, position: { x: 20, y: 25 } },
  { id: 'tcm', name: 'Transmission Control Module', code: 'TCM', canId: 0x7E1, rxId: 0x7E9, position: { x: 50, y: 25 } },
  { id: 'bcm', name: 'Body Control Module', code: 'BCM', canId: 0x6B0, rxId: 0x6B8, position: { x: 80, y: 25 } },
  
  // Third tier - Secondary modules
  { id: 'abs', name: 'ABS/ESP Module', code: 'ABS', canId: 0x760, rxId: 0x768, position: { x: 15, y: 45 } },
  { id: 'cluster', name: 'Instrument Cluster', code: 'Cluster', canId: 0x720, rxId: 0x728, position: { x: 35, y: 45 } },
  { id: 'radio', name: 'Radio/Uconnect', code: 'Radio', canId: 0x7C0, rxId: 0x7C8, position: { x: 50, y: 45 } },
  { id: 'rfhub', name: 'RF Hub / SKIM', code: 'RFHUB', canId: 0x742, rxId: 0x762, position: { x: 65, y: 45 } },
  { id: 'orc', name: 'Airbag Control Module', code: 'ORC', canId: 0x738, rxId: 0x758, position: { x: 85, y: 45 } },
  
  // Fourth tier - Comfort/convenience
  { id: 'hvac', name: 'HVAC Control', code: 'HVAC', canId: 0x7A0, rxId: 0x7A8, position: { x: 25, y: 65 } },
  { id: 'tpms', name: 'Tire Pressure Monitor', code: 'TPMS', canId: 0x7B0, rxId: 0x7B8, position: { x: 50, y: 65 } },
  { id: 'pscm', name: 'Power Seat Control', code: 'PSCM', canId: 0x7D0, rxId: 0x7D8, position: { x: 75, y: 65 } },
  
  // Fifth tier - Additional modules
  { id: 'dtcm', name: 'Drive Train Control', code: 'DTCM', canId: 0x7F0, rxId: 0x7F8, position: { x: 35, y: 85 } },
  { id: 'sccm', name: 'Steering Column Control', code: 'SCCM', canId: 0x7A8, rxId: 0x7B0, position: { x: 65, y: 85 } },
];

export interface VehicleTopologyMapProps {
  scannedModules?: any[]; // From Module Scanner
  onModuleClick?: (module: VehicleModule) => void;
  onScanRequest?: () => void;
}

export function VehicleTopologyMap({ 
  scannedModules = [], 
  onModuleClick,
  onScanRequest 
}: VehicleTopologyMapProps) {
  const [modules, setModules] = useState<VehicleModule[]>([]);
  const [selectedModule, setSelectedModule] = useState<VehicleModule | null>(null);

  // Initialize modules with default layout
  useEffect(() => {
    const initialModules: VehicleModule[] = DEFAULT_MODULE_LAYOUT.map(layout => ({
      ...layout,
      status: 'offline' as ModuleStatus,
      dtcCount: 0,
    }));
    setModules(initialModules);
  }, []);

  // Update modules based on scan results
  useEffect(() => {
    if (scannedModules.length === 0) return;

    setModules(prev => prev.map(module => {
      // Find matching scanned module by CAN ID or name
      const scanned = scannedModules.find(s => 
        s.txId === module.canId || 
        s.name?.toUpperCase().includes(module.code) ||
        s.code === module.code
      );

      if (scanned) {
        return {
          ...module,
          status: scanned.dtcCount > 0 ? 'fault' : 'active',
          dtcCount: scanned.dtcCount || 0,
          vin: scanned.vin,
          partNumber: scanned.partNumber,
          softwareVersion: scanned.softwareVersion,
        };
      }

      return module;
    }));
  }, [scannedModules]);

  const handleModuleClick = (module: VehicleModule) => {
    setSelectedModule(module);
    onModuleClick?.(module);
  };

  const activeCount = modules.filter(m => m.status === 'active' || m.status === 'fault' || m.status === 'warning').length;
  const faultCount = modules.filter(m => m.status === 'fault').length;
  const totalDTCs = modules.reduce((sum, m) => sum + m.dtcCount, 0);

  return (
    <Card className="p-6 bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white">Vehicle Topology Map</h2>
          <p className="text-sm text-gray-400">Real-time module status visualization</p>
        </div>
        <div className="flex gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500">{activeCount}</div>
            <div className="text-xs text-gray-400">Active</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-500">{faultCount}</div>
            <div className="text-xs text-gray-400">Faults</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-500">{totalDTCs}</div>
            <div className="text-xs text-gray-400">DTCs</div>
          </div>
        </div>
      </div>

      {/* Topology Map */}
      <div className="relative w-full h-[600px] bg-gray-950/50 rounded-lg border border-gray-700 overflow-hidden">
        {/* CAN Bus lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
          {/* Main CAN-C bus (horizontal line through middle) */}
          <line 
            x1="10%" y1="25%" x2="90%" y2="25%" 
            stroke="#3b82f6" 
            strokeWidth="2" 
            strokeDasharray="5,5"
            opacity="0.3"
          />
          {/* Vertical connections */}
          {modules.filter(m => m.status !== 'offline').map(module => (
            <line
              key={module.id}
              x1={`${module.position.x}%`}
              y1="25%"
              x2={`${module.position.x}%`}
              y2={`${module.position.y}%`}
              stroke={module.status === 'fault' ? '#ef4444' : '#3b82f6'}
              strokeWidth="1"
              opacity="0.2"
            />
          ))}
        </svg>

        {/* Modules */}
        <div className="relative w-full h-full" style={{ zIndex: 1 }}>
          {modules.map(module => (
            <ModuleIcon
              key={module.id}
              module={module}
              onClick={() => handleModuleClick(module)}
            />
          ))}
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 flex gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-green-500/50 border border-green-500"></div>
            <span>Active</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-red-500/50 border border-red-500"></div>
            <span>Fault</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-yellow-500/50 border border-yellow-500"></div>
            <span>Warning</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-gray-500/20 border border-gray-600"></div>
            <span>Offline</span>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2 mt-4">
        <Button onClick={onScanRequest} className="flex-1">
          🔍 Scan All Modules
        </Button>
        <Button variant="outline" onClick={() => setModules(prev => prev.map(m => ({ ...m, status: 'offline', dtcCount: 0 })))}>
          Clear
        </Button>
      </div>
    </Card>
  );
}
