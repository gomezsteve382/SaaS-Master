/**
 * Post-Flash Routines Component
 * 
 * Displays and executes automated post-flash procedures
 */

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { RoutineExecutionModal } from './RoutineExecutionModal';
import { 
  CheckCircle2, 
  Clock, 
  Play, 
  AlertTriangle, 
  FileText, 
  Zap,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface PostFlashRoutinesProps {
  ecuType: string;
  tsbNumbers?: string[];
  vin?: string;
  calibrationId?: number;
  onComplete?: () => void;
}

export function PostFlashRoutines({ ecuType, tsbNumbers, vin, calibrationId, onComplete }: PostFlashRoutinesProps) {
  const [selectedRoutines, setSelectedRoutines] = useState<number[]>([]);
  const [expandedRoutine, setExpandedRoutine] = useState<number | null>(null);
  const [executionId, setExecutionId] = useState<number | null>(null);
  const [executingRoutine, setExecutingRoutine] = useState<string>('');
  const [showExecutionModal, setShowExecutionModal] = useState(false);
  const [vinInput, setVinInput] = useState(vin || '');
  const { toast } = useToast();

  const { data: routines, isLoading } = trpc.j2534.getPostFlashRoutines.useQuery({
    ecuType,
    tsbNumbers,
  });

  const startExecution = trpc.j2534.startRoutineExecution.useMutation({
    onSuccess: (data) => {
      setExecutionId(data.executionId);
      setShowExecutionModal(true);
      toast({
        title: "🚀 Execution Started",
        description: `${data.totalSteps} steps queued for execution`,
      });
    },
    onError: (error) => {
      toast({
        title: "❌ Execution Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleRoutine = (routineId: number) => {
    setSelectedRoutines(prev =>
      prev.includes(routineId)
        ? prev.filter(id => id !== routineId)
        : [...prev, routineId]
    );
  };

  const toggleExpand = (routineId: number) => {
    setExpandedRoutine(prev => prev === routineId ? null : routineId);
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 9) return 'text-red-600 bg-red-50 border-red-200';
    if (priority >= 7) return 'text-orange-600 bg-orange-50 border-orange-200';
    if (priority >= 5) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-blue-600 bg-blue-50 border-blue-200';
  };

  const getPriorityLabel = (priority: number) => {
    if (priority >= 9) return 'CRITICAL';
    if (priority >= 7) return 'HIGH';
    if (priority >= 5) return 'MEDIUM';
    return 'LOW';
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <Clock className="h-8 w-8 mx-auto mb-2 animate-pulse text-muted-foreground" />
          <p className="text-muted-foreground">Loading post-flash routines...</p>
        </CardContent>
      </Card>
    );
  }

  if (!routines || routines.length === 0) {
    return (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          No post-flash routines found for {ecuType}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Post-Flash Routines Required
          </CardTitle>
          <CardDescription>
            {routines.length} procedure{routines.length > 1 ? 's' : ''} recommended for {ecuType} after flash
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {routines.map((routine: any) => (
            <Card 
              key={routine.id} 
              className={`border-2 ${getPriorityColor(routine.priority)}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <Checkbox
                      checked={selectedRoutines.includes(routine.id)}
                      onCheckedChange={() => toggleRoutine(routine.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <CardTitle className="text-base">{routine.routineName}</CardTitle>
                        <Badge variant="outline" className="text-xs">
                          {routine.routineCode}
                        </Badge>
                      </div>
                      <CardDescription className="text-sm">
                        {routine.description}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getPriorityColor(routine.priority)}>
                      {getPriorityLabel(routine.priority)}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleExpand(routine.id)}
                    >
                      {expandedRoutine === routine.id ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </CardHeader>

              {expandedRoutine === routine.id && (
                <CardContent className="pt-0 space-y-4">
                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Duration:</span>
                      <div className="font-mono font-semibold flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {Math.floor(routine.estimatedDuration / 60)} min {routine.estimatedDuration % 60} sec
                      </div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Requirements:</span>
                      <div className="font-semibold">
                        {routine.requiresVehicleRunning ? '🚗 Engine Running' : '🔑 Ignition ON'}
                      </div>
                    </div>
                  </div>

                  {/* TSB References */}
                  {routine.relatedTsbs && routine.relatedTsbs.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Related TSBs
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {routine.relatedTsbs.map((tsb: string, idx: number) => (
                          <Badge key={idx} variant="outline" className="font-mono">
                            {tsb}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* UDS Commands */}
                  {routine.udsCommands && routine.udsCommands.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold mb-2">Automated UDS Sequence</h4>
                      <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                        {routine.udsCommands.map((cmd: any, idx: number) => (
                          <div key={idx} className="flex items-start gap-2 text-xs">
                            <Badge variant="secondary" className="font-mono shrink-0">
                              {idx + 1}
                            </Badge>
                            <div className="flex-1">
                              <div className="font-mono font-semibold">
                                {cmd.service} {cmd.subfunction || cmd.did || cmd.routine || ''}
                              </div>
                              <div className="text-muted-foreground">{cmd.description}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Manual Steps */}
                  {routine.manualSteps && routine.manualSteps.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold mb-2">Manual Procedure</h4>
                      <ol className="space-y-2 text-sm">
                        {routine.manualSteps.map((step: string, idx: number) => (
                          <li key={idx} className="flex gap-2">
                            <span className="font-semibold text-muted-foreground">{idx + 1}.</span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-2">
        <Button
          variant="default"
          className="flex-1"
          disabled={selectedRoutines.length === 0 || startExecution.isPending}
          onClick={() => {
            if (selectedRoutines.length === 0) return;
            
            // Execute first selected routine
            const routineId = selectedRoutines[0];
            const routine = routines?.find((r: any) => r.id === routineId);
            
            if (routine) {
              setExecutingRoutine(routine.routineName);
              startExecution.mutate({
                routineId,
                ecuType,
                vin: vinInput || undefined,
                calibrationId,
                executionMode: 'automatic',
              });
            }
          }}
        >
          <Play className="mr-2 h-4 w-4" />
          {startExecution.isPending ? 'Starting...' : `Execute Selected (${selectedRoutines.length})`}
        </Button>
        <Button
          variant="outline"
          onClick={() => setSelectedRoutines(routines.map((r: any) => r.id))}
        >
          <CheckCircle2 className="mr-2 h-4 w-4" />
          Select All
        </Button>
      </div>

      {/* VIN Input */}
      {selectedRoutines.length > 0 && (
        <div className="space-y-2">
          <label className="text-sm font-medium">VIN (Optional)</label>
          <Input
            placeholder="Enter VIN for VIN programming routines"
            value={vinInput}
            onChange={(e) => setVinInput(e.target.value.toUpperCase())}
            maxLength={17}
          />
        </div>
      )}

      <Alert className="bg-yellow-50 border-yellow-200">
        <AlertTriangle className="h-4 w-4 text-yellow-600" />
        <AlertDescription className="text-yellow-900">
          <strong>Important:</strong> Always perform post-flash routines in the order shown (highest priority first). 
          Skipping critical routines may result in drivability issues or DTCs.
        </AlertDescription>
      </Alert>

      {/* Execution Modal */}
      <RoutineExecutionModal
        open={showExecutionModal}
        onClose={() => {
          setShowExecutionModal(false);
          setExecutionId(null);
          if (onComplete) onComplete();
        }}
        executionId={executionId}
        routineName={executingRoutine}
      />
    </div>
  );
}
