/**
 * Batch Flash Upload Component
 * 
 * Multi-file drag-and-drop upload with progress tracking
 */

import { useState, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, X, CheckCircle2, AlertCircle, FileIcon, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface FileWithMeta {
  file: File;
  calibrationId?: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  progress: number;
  error?: string;
}

export function BatchFlashUpload() {
  const [files, setFiles] = useState<FileWithMeta[]>([]);
  const [batchName, setBatchName] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  const uploadFlashFile = trpc.j2534.uploadFlashFile.useMutation();
  const createBatch = trpc.j2534.createBatchUpload.useMutation();
  const updateBatch = trpc.j2534.updateBatchProgress.useMutation();

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    const validFiles = droppedFiles.filter(file => {
      const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
      return ['.hex', '.bin', '.cal'].includes(ext);
    });

    if (validFiles.length < droppedFiles.length) {
      toast({
        title: "⚠️ Some files skipped",
        description: "Only .hex, .bin, and .cal files are supported",
        variant: "destructive",
      });
    }

    const newFiles: FileWithMeta[] = validFiles.map(file => ({
      file,
      status: 'pending',
      progress: 0,
    }));

    setFiles(prev => [...prev, ...newFiles]);
  }, [toast]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const newFiles: FileWithMeta[] = selectedFiles.map(file => ({
      file,
      status: 'pending',
      progress: 0,
    }));
    setFiles(prev => [...prev, ...newFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadBatch = async () => {
    if (files.length === 0) return;

    // Create batch operation
    const batch = await createBatch.mutateAsync({
      batchName: batchName || `Batch Upload ${new Date().toLocaleString()}`,
      fileCount: files.length,
    });

    const batchId = batch.batchId;
    let successCount = 0;
    let failureCount = 0;

    // Update batch status to in_progress
    await updateBatch.mutateAsync({
      batchId,
      progress: 0,
      status: 'in_progress',
    });

    // Upload files sequentially
    for (let i = 0; i < files.length; i++) {
      const fileWithMeta = files[i];
      
      // Update file status
      setFiles(prev => prev.map((f, idx) => 
        idx === i ? { ...f, status: 'uploading' as const } : f
      ));

      try {
        // Read file as base64
        const base64Data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            const result = e.target?.result as string;
            resolve(result.split(',')[1]);
          };
          reader.onerror = reject;
          reader.readAsDataURL(fileWithMeta.file);
        });

        // Extract calibration ID from filename if present
        // Format: "calibrationId_filename.ext" or just "filename.ext"
        const fileNameParts = fileWithMeta.file.name.split('_');
        const calibrationId = fileNameParts.length > 1 && !isNaN(Number(fileNameParts[0]))
          ? Number(fileNameParts[0])
          : 1; // Default to ID 1 if not specified

        const fileExt = fileWithMeta.file.name.substring(fileWithMeta.file.name.lastIndexOf('.') + 1).toLowerCase();

        // Upload file
        await uploadFlashFile.mutateAsync({
          calibrationId,
          fileData: base64Data,
          fileName: fileWithMeta.file.name,
          fileType: fileExt as 'hex' | 'bin' | 'cal',
        });

        // Update file status to success
        setFiles(prev => prev.map((f, idx) => 
          idx === i ? { ...f, status: 'success' as const, progress: 100 } : f
        ));

        successCount++;
      } catch (error: any) {
        // Update file status to error
        setFiles(prev => prev.map((f, idx) => 
          idx === i ? { ...f, status: 'error' as const, error: error.message } : f
        ));

        failureCount++;
      }

      // Update batch progress
      const progress = Math.round(((i + 1) / files.length) * 100);
      await updateBatch.mutateAsync({
        batchId,
        progress,
        successCount,
        failureCount,
      });
    }

    // Mark batch as completed
    await updateBatch.mutateAsync({
      batchId,
      progress: 100,
      successCount,
      failureCount,
      status: failureCount === 0 ? 'completed' : 'failed',
    });

    toast({
      title: "✅ Batch Upload Complete",
      description: `${successCount} succeeded, ${failureCount} failed`,
    });
  };

  const totalSize = files.reduce((sum, f) => sum + f.file.size, 0);
  const pendingCount = files.filter(f => f.status === 'pending').length;
  const successCount = files.filter(f => f.status === 'success').length;
  const errorCount = files.filter(f => f.status === 'error').length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Batch Flash Upload
        </CardTitle>
        <CardDescription>
          Upload multiple flash files at once with progress tracking
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Batch Name */}
        <div>
          <label className="text-sm font-medium mb-2 block">Batch Name (optional)</label>
          <Input
            placeholder="e.g., 2024 Charger PCM Updates"
            value={batchName}
            onChange={(e) => setBatchName(e.target.value)}
          />
        </div>

        {/* Drop Zone */}
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging
              ? 'border-blue-500 bg-blue-50'
              : 'border-muted-foreground/25 hover:border-muted-foreground/50'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-lg font-semibold mb-2">Drop flash files here</p>
          <p className="text-sm text-muted-foreground mb-4">
            or click to browse (.hex, .bin, .cal files)
          </p>
          <input
            type="file"
            multiple
            accept=".hex,.bin,.cal"
            className="hidden"
            id="batch-file-input"
            onChange={handleFileSelect}
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('batch-file-input')?.click()}
          >
            Browse Files
          </Button>
        </div>

        {/* File List */}
        {files.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold">
                Files ({files.length}) - {(totalSize / 1024 / 1024).toFixed(2)} MB
              </h4>
              <div className="flex gap-2">
                <Badge variant="secondary">{successCount} ✓</Badge>
                {errorCount > 0 && <Badge variant="destructive">{errorCount} ✗</Badge>}
              </div>
            </div>

            <div className="max-h-64 overflow-y-auto space-y-2 border rounded-lg p-2">
              {files.map((fileWithMeta, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-2 bg-muted/50 rounded-lg"
                >
                  <FileIcon className="h-4 w-4 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{fileWithMeta.file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(fileWithMeta.file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                  {fileWithMeta.status === 'pending' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                  {fileWithMeta.status === 'uploading' && (
                    <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
                  )}
                  {fileWithMeta.status === 'success' && (
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  )}
                  {fileWithMeta.status === 'error' && (
                    <AlertCircle className="h-4 w-4 text-red-500" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        {files.length > 0 && (
          <div className="flex gap-2">
            <Button
              className="flex-1"
              onClick={uploadBatch}
              disabled={pendingCount === 0 || uploadFlashFile.isPending}
            >
              {uploadFlashFile.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Upload {pendingCount} File{pendingCount > 1 ? 's' : ''}
                </>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => setFiles([])}
              disabled={uploadFlashFile.isPending}
            >
              Clear All
            </Button>
          </div>
        )}

        {/* Instructions */}
        <Alert>
          <AlertDescription className="text-sm">
            <strong>File Naming Convention:</strong> Name files as <code>calibrationId_filename.ext</code> to auto-link to calibration records. 
            Example: <code>123_PCM_Update.hex</code> will link to calibration ID 123.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
