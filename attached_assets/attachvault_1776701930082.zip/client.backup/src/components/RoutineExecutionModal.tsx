/**
 * Routine Execution Modal
 * 
 * Real-time progress tracking for automated routine execution
 */

import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Play,
  Pause,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Clock,
  Terminal,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface RoutineExecutionModalProps {
  open: boolean;
  onClose: () => void;
  executionId: number | null;
  routineName: string;
}

export function RoutineExecutionModal({
  open,
  onClose,
  executionId,
  routineName,
}: RoutineExecutionModalProps) {
  const { toast } = useToast();
  const [pollingEnabled, setPollingEnabled] = useState(true);

  const { data: execution, refetch } = trpc.j2534.getExecutionStatus.useQuery(
    { executionId: executionId || 0 },
    {
      enabled: open && executionId !== null && pollingEnabled,
      refetchInterval: 1000, // Poll every second
    }
  );

  const cancelExecution = trpc.j2534.cancelExecution.useMutation({
    onSuccess: () => {
      toast({
        title: "⏹️ Execution Cancelled",
        description: "Routine execution stopped",
      });
      setPollingEnabled(false);
      refetch();
    },
  });

  useEffect(() => {
    // Stop polling when execution completes
    if (execution && ['completed', 'failed', 'cancelled'].includes(execution.status)) {
      setPollingEnabled(false);
    }
  }, [execution?.status]);

  const handleCancel = () => {
    if (executionId && execution?.status === 'running') {
      cancelExecution.mutate({ executionId });
    }
  };

  const handleClose = () => {
    setPollingEnabled(false);
    onClose();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      case 'running':
        return 'bg-blue-500';
      case 'cancelled':
        return 'bg-gray-500';
      default:
        return 'bg-yellow-500';
    }
  };

  const getStepStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'running':
        return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  if (!execution) {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent>
          <div className="py-8 text-center">
            <Loader2 className="h-8 w-8 mx-auto mb-2 animate-spin text-muted-foreground" />
            <p className="text-muted-foreground">Loading execution status...</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const isRunning = execution.status === 'running';
  const isCompleted = execution.status === 'completed';
  const isFailed = execution.status === 'failed';

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            {routineName}
          </DialogTitle>
          <DialogDescription>
            Automated UDS command execution via J2534 bridge
          </DialogDescription>
        </DialogHeader>

        {/* Status Header */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor(execution.status)}>
                {execution.status.toUpperCase()}
              </Badge>
              <span className="text-sm text-muted-foreground">
                Step {execution.currentStep} / {execution.totalSteps}
              </span>
            </div>
            <div className="text-sm font-mono">
              {execution.progress}%
            </div>
          </div>

          <Progress value={execution.progress} className="h-2" />

          {/* Timing */}
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="h-3 w-3" />
              Started: {new Date(execution.startedAt).toLocaleTimeString()}
            </div>
            {execution.completedAt && (
              <div>
                Completed: {new Date(execution.completedAt).toLocaleTimeString()}
              </div>
            )}
            {!execution.completedAt && execution.estimatedCompletionAt && (
              <div>
                ETA: {new Date(execution.estimatedCompletionAt).toLocaleTimeString()}
              </div>
            )}
          </div>
        </div>

        {/* Error Message */}
        {execution.errorMessage && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{execution.errorMessage}</AlertDescription>
          </Alert>
        )}

        {/* Steps */}
        <div className="space-y-2">
          <h4 className="font-semibold text-sm">Execution Steps</h4>
          <div className="space-y-2 max-h-96 overflow-y-auto border rounded-lg p-3 bg-muted/30">
            {execution.steps.map((step: any) => (
              <div
                key={step.id}
                className={`p-3 rounded-lg border ${
                  step.status === 'running'
                    ? 'border-blue-500 bg-blue-50'
                    : step.status === 'completed'
                    ? 'border-green-200 bg-green-50'
                    : step.status === 'failed'
                    ? 'border-red-200 bg-red-50'
                    : 'border-muted bg-background'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getStepStatusIcon(step.status)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="font-mono text-xs">
                        #{step.stepNumber}
                      </Badge>
                      <span className="font-medium text-sm">{step.stepName}</span>
                    </div>

                    {/* UDS Command */}
                    {step.requestData && (
                      <div className="mt-2 space-y-1">
                        <div className="text-xs text-muted-foreground">Request:</div>
                        <div className="font-mono text-xs bg-background/50 p-2 rounded border">
                          {step.requestData}
                        </div>
                      </div>
                    )}

                    {/* Response */}
                    {step.responseData && (
                      <div className="mt-2 space-y-1">
                        <div className="text-xs text-muted-foreground">Response:</div>
                        <div className="font-mono text-xs bg-background/50 p-2 rounded border">
                          {step.responseData}
                        </div>
                      </div>
                    )}

                    {/* Error */}
                    {step.errorMessage && (
                      <div className="mt-2">
                        <Alert variant="destructive" className="py-2">
                          <AlertDescription className="text-xs">
                            {step.errorMessage}
                          </AlertDescription>
                        </Alert>
                      </div>
                    )}

                    {/* Timing */}
                    {step.durationMs && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        Duration: {step.durationMs}ms
                        {step.retryCount > 0 && ` (${step.retryCount} retries)`}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Summary */}
        {(isCompleted || isFailed) && (
          <Alert className={isCompleted ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}>
            {isCompleted ? (
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription className={isCompleted ? 'text-green-900' : 'text-red-900'}>
              <strong>{isCompleted ? 'Success!' : 'Failed'}</strong>
              {' '}
              {execution.successfulSteps} of {execution.totalSteps} steps completed successfully
              {(execution.failedSteps || 0) > 0 && ` (${execution.failedSteps} failed)`}
            </AlertDescription>
          </Alert>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          {isRunning && (
            <Button
              variant="destructive"
              onClick={handleCancel}
              disabled={cancelExecution.isPending}
            >
              {cancelExecution.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Cancelling...
                </>
              ) : (
                <>
                  <X className="mr-2 h-4 w-4" />
                  Cancel Execution
                </>
              )}
            </Button>
          )}
          <Button
            variant="outline"
            onClick={handleClose}
            className="flex-1"
          >
            {isRunning ? 'Run in Background' : 'Close'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
