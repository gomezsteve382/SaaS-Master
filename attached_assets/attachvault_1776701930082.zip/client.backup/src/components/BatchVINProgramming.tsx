import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle2, XCircle, AlertTriangle, Loader2, Pause, Play } from "lucide-react";
import { ConnectionManager } from "@/lib/obd2-protocol";
import { toast } from "sonner";

interface Module {
  canId: string;
  name: string;
  vin?: string;
  vinMismatch: boolean;
}

interface BatchVINProgrammingProps {
  modules: Module[];
  targetVIN: string;
  isOpen: boolean;
  onClose: () => void;
  onProgramModule: (module: Module, targetVIN: string) => Promise<void>;
}

interface ModuleStatus {
  module: Module;
  status: "pending" | "processing" | "success" | "error";
  error?: string;
  startTime?: number;
  endTime?: number;
}

// Module priority order (critical modules first)
const MODULE_PRIORITY: Record<string, number> = {
  "0x731": 1, // BCM - highest priority
  "0x641": 2, // RFHUB/WCM
  "0x7E0": 3, // ECM/PCM
  "0x7E1": 3, // ECM/PCM alternate
  "0x7E2": 4, // TCM
  "0x742": 5, // SKIM
  "0x720": 6, // IPC
  // All others default to 10
};

export function BatchVINProgramming({ modules, targetVIN, isOpen, onClose, onProgramModule }: BatchVINProgrammingProps) {
  const [moduleStatuses, setModuleStatuses] = useState<ModuleStatus[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentModuleIndex, setCurrentModuleIndex] = useState(0);
  const [continueOnError, setContinueOnError] = useState(true);

  const sortedModules = [...modules].sort((a, b) => {
    const priorityA = MODULE_PRIORITY[a.canId] || 10;
    const priorityB = MODULE_PRIORITY[b.canId] || 10;
    return priorityA - priorityB;
  });

  const totalModules = sortedModules.length;
  const completedModules = moduleStatuses.filter((s) => s.status === "success" || s.status === "error").length;
  const successCount = moduleStatuses.filter((s) => s.status === "success").length;
  const errorCount = moduleStatuses.filter((s) => s.status === "error").length;
  const progress = totalModules > 0 ? (completedModules / totalModules) * 100 : 0;

  const handleStart = async () => {
    setIsRunning(true);
    setIsPaused(false);
    setCurrentModuleIndex(0);

    // Initialize statuses
    const initialStatuses: ModuleStatus[] = sortedModules.map((module) => ({
      module,
      status: "pending",
    }));
    setModuleStatuses(initialStatuses);

    // Process modules sequentially
    for (let i = 0; i < sortedModules.length; i++) {
      if (isPaused) {
        setCurrentModuleIndex(i);
        break;
      }

      const module = sortedModules[i];
      setCurrentModuleIndex(i);

      // Update status to processing
      setModuleStatuses((prev) =>
        prev.map((s, idx) =>
          idx === i ? { ...s, status: "processing", startTime: Date.now() } : s
        )
      );

      try {
        // Real UDS VIN programming
        const connectionManager = new ConnectionManager();
        const protocol = connectionManager.getProtocol();
        if (!protocol) {
          throw new Error("No hardware connection");
        }

        const txId = parseInt(module.canId, 16);
        const rxId = txId + 0x08;

        // Security access
        const seedResponse = await protocol.sendUDS(txId, rxId, [0x27, 0x01]);
        if (!seedResponse || seedResponse[0] !== 0x67) {
          throw new Error("Security access failed");
        }
        const seed = (seedResponse[2] << 8) | seedResponse[3];
        const key = ((seed * 5) & 0xFFFF) ^ 0x4B92;
        const keyResponse = await protocol.sendUDS(txId, rxId, [0x27, 0x02, (key >> 8) & 0xFF, key & 0xFF]);
        if (!keyResponse || keyResponse[0] !== 0x67) {
          throw new Error("Security key verification failed");
        }

        // Write VIN
        const vinBytes = Array.from(targetVIN).map(c => c.charCodeAt(0));
        const writeCommand = [0x2E, 0xF1, 0x90, ...vinBytes];
        const writeResponse = await protocol.sendUDS(txId, rxId, writeCommand);
        if (!writeResponse || writeResponse[0] !== 0x6E) {
          throw new Error("VIN write failed");
        }

        // Verify
        const verifyVIN = await protocol.readVIN(txId, rxId);
        if (verifyVIN !== targetVIN) {
          throw new Error(`Verification failed. Expected: ${targetVIN}, Got: ${verifyVIN}`);
        }

        console.log(`[Batch VIN] ${module.name} programmed successfully`);
        
        // Call the callback to update UI
        await onProgramModule(module, targetVIN);

        // Success
        setModuleStatuses((prev) =>
          prev.map((s, idx) =>
            idx === i ? { ...s, status: "success", endTime: Date.now() } : s
          )
        );
      } catch (error) {
        // Error
        const errorMessage = error instanceof Error ? error.message : "Programming failed";
        setModuleStatuses((prev) =>
          prev.map((s, idx) =>
            idx === i ? { ...s, status: "error", error: errorMessage, endTime: Date.now() } : s
          )
        );

        if (!continueOnError) {
          break;
        }
      }

      // Small delay between modules
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    setIsRunning(false);
  };

  const handlePause = () => {
    setIsPaused(true);
    setIsRunning(false);
  };

  const handleResume = async () => {
    setIsPaused(false);
    setIsRunning(true);

    // Continue from current index
    for (let i = currentModuleIndex; i < sortedModules.length; i++) {
      if (isPaused) {
        setCurrentModuleIndex(i);
        break;
      }

      const module = sortedModules[i];
      const currentStatus = moduleStatuses[i];

      // Skip already processed modules
      if (currentStatus.status === "success" || currentStatus.status === "error") {
        continue;
      }

      setCurrentModuleIndex(i);

      setModuleStatuses((prev) =>
        prev.map((s, idx) =>
          idx === i ? { ...s, status: "processing", startTime: Date.now() } : s
        )
      );

      try {
        await onProgramModule(module, targetVIN);
        setModuleStatuses((prev) =>
          prev.map((s, idx) =>
            idx === i ? { ...s, status: "success", endTime: Date.now() } : s
          )
        );
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Programming failed";
        setModuleStatuses((prev) =>
          prev.map((s, idx) =>
            idx === i ? { ...s, status: "error", error: errorMessage, endTime: Date.now() } : s
          )
        );

        if (!continueOnError) {
          break;
        }
      }

      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    setIsRunning(false);
  };

  const handleClose = () => {
    setModuleStatuses([]);
    setIsRunning(false);
    setIsPaused(false);
    setCurrentModuleIndex(0);
    onClose();
  };

  const getStatusIcon = (status: ModuleStatus["status"]) => {
    switch (status) {
      case "pending":
        return <div className="w-5 h-5 rounded-full border-2 border-muted" />;
      case "processing":
        return <Loader2 className="w-5 h-5 animate-spin text-primary" />;
      case "success":
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case "error":
        return <XCircle className="w-5 h-5 text-red-600" />;
    }
  };

  const getStatusBadge = (status: ModuleStatus["status"]) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline">Pending</Badge>;
      case "processing":
        return <Badge className="bg-blue-600">Processing</Badge>;
      case "success":
        return <Badge className="bg-green-600">Success</Badge>;
      case "error":
        return <Badge variant="destructive">Error</Badge>;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Batch VIN Programming</DialogTitle>
          <DialogDescription>
            Program {targetVIN} to {totalModules} module{totalModules !== 1 ? "s" : ""}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Overall progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Overall Progress</span>
              <span className="text-muted-foreground">
                {completedModules} / {totalModules} modules
              </span>
            </div>
            <Progress value={progress} className="h-2" />
            <div className="flex gap-4 text-xs text-muted-foreground">
              <span className="text-green-600">✓ {successCount} successful</span>
              {errorCount > 0 && <span className="text-red-600">✗ {errorCount} failed</span>}
            </div>
          </div>

          {/* Warning */}
          {moduleStatuses.length === 0 && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Warning:</strong> This will program the VIN to {totalModules} modules sequentially.
                Critical modules (BCM, RFHUB, ECM) will be programmed first.
              </AlertDescription>
            </Alert>
          )}

          {/* Module list */}
          <ScrollArea className="h-[300px] border rounded-lg p-4">
            <div className="space-y-2">
              {(moduleStatuses.length > 0 ? moduleStatuses : sortedModules.map((module) => ({ module, status: "pending" as const }))).map(
                (status, index) => {
                  const duration =
                    'startTime' in status && 'endTime' in status && status.startTime && status.endTime
                      ? ((status.endTime - status.startTime) / 1000).toFixed(1)
                      : null;

                  return (
                    <div
                      key={status.module.canId}
                      className={`flex items-center gap-3 p-3 rounded-lg border ${
                        status.status === "processing" ? "bg-blue-500/5 border-blue-500/20" : "bg-muted/50"
                      }`}
                    >
                      {getStatusIcon(status.status)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{status.module.name}</span>
                          <span className="text-xs text-muted-foreground">{status.module.canId}</span>
                          {MODULE_PRIORITY[status.module.canId] && MODULE_PRIORITY[status.module.canId] <= 3 && (
                            <Badge variant="outline" className="text-xs">Priority</Badge>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {status.module.vin ? `Current: ${status.module.vin}` : "No VIN detected"}
                          {duration && ` • ${duration}s`}
                        </div>
                        {'error' in status && status.error && (
                          <div className="text-xs text-red-600 mt-1">Error: {status.error}</div>
                        )}
                      </div>
                      {getStatusBadge(status.status)}
                    </div>
                  );
                }
              )}
            </div>
          </ScrollArea>

          {/* Controls */}
          <div className="flex items-center gap-2 justify-between">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="continueOnError"
                checked={continueOnError}
                onChange={(e) => setContinueOnError(e.target.checked)}
                disabled={isRunning}
                className="rounded"
              />
              <label htmlFor="continueOnError" className="text-sm cursor-pointer">
                Continue on error
              </label>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={handleClose} disabled={isRunning}>
                {completedModules === totalModules ? "Close" : "Cancel"}
              </Button>

              {!isRunning && !isPaused && moduleStatuses.length === 0 && (
                <Button onClick={handleStart}>
                  <Play className="w-4 h-4 mr-2" />
                  Start Programming
                </Button>
              )}

              {isRunning && (
                <Button variant="outline" onClick={handlePause}>
                  <Pause className="w-4 h-4 mr-2" />
                  Pause
                </Button>
              )}

              {isPaused && (
                <Button onClick={handleResume}>
                  <Play className="w-4 h-4 mr-2" />
                  Resume
                </Button>
              )}

              {completedModules === totalModules && completedModules > 0 && (
                <Button onClick={handleClose}>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Done
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
