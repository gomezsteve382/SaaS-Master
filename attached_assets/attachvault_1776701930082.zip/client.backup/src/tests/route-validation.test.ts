import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { join } from 'path';

/**
 * Route Validation Test
 * 
 * This test ensures all navigation links in Home.tsx point to valid routes in App.tsx.
 * Prevents 404 errors from broken navigation links.
 */

describe('Route Validation', () => {
  it('should have all Home.tsx navigation links defined in App.tsx routes', () => {
    // Read Home.tsx
    const homePath = join(__dirname, '../pages/Home.tsx');
    const homeContent = readFileSync(homePath, 'utf-8');

    // Read App.tsx
    const appPath = join(__dirname, '../App.tsx');
    const appContent = readFileSync(appPath, 'utf-8');

    // Extract navigation links from Home.tsx
    // Matches: to="/some-path" or href="/some-path"
    const linkRegex = /(?:to|href)=["']([^"']+)["']/g;
    const homeLinks: string[] = [];
    let match;

    while ((match = linkRegex.exec(homeContent)) !== null) {
      const path = match[1];
      // Only check internal routes (start with /)
      if (path.startsWith('/') && !path.startsWith('http')) {
        homeLinks.push(path);
      }
    }

    // Extract routes from App.tsx
    // Matches: path="/some-path"
    const routeRegex = /path=["']([^"']+)["']/g;
    const appRoutes: string[] = [];

    while ((match = routeRegex.exec(appContent)) !== null) {
      appRoutes.push(match[1]);
    }

    // Find broken links
    const brokenLinks = homeLinks.filter(link => !appRoutes.includes(link));

    // Assert all links are valid
    expect(brokenLinks).toEqual([]);

    // Log stats for visibility
    console.log(`✅ Route Validation Passed`);
    console.log(`   Navigation Links: ${homeLinks.length}`);
    console.log(`   Defined Routes: ${appRoutes.length}`);
    console.log(`   Broken Links: ${brokenLinks.length}`);
  });

  it('should not have duplicate routes in App.tsx', () => {
    const appPath = join(__dirname, '../App.tsx');
    const appContent = readFileSync(appPath, 'utf-8');

    // Extract all routes
    const routeRegex = /path=["']([^"']+)["']/g;
    const routes: string[] = [];
    let match;

    while ((match = routeRegex.exec(appContent)) !== null) {
      routes.push(match[1]);
    }

    // Find duplicates
    const duplicates = routes.filter((route, index) => routes.indexOf(route) !== index);
    const uniqueDuplicates = [...new Set(duplicates)];

    // Assert no duplicates
    expect(uniqueDuplicates).toEqual([]);

    if (uniqueDuplicates.length > 0) {
      console.error(`❌ Duplicate routes found: ${uniqueDuplicates.join(', ')}`);
    }
  });
});
