// No-op authentication hook for single-user mode
export function useAuth() {
  return {
    user: null,
    loading: false,
    error: null,
    isAuthenticated: true, // Always authenticated in single-user mode
    refresh: () => Promise.resolve(),
    logout: () => Promise.resolve(),
  };
}
