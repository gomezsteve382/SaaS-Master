import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface DemoModeContextType {
  isDemoMode: boolean;
  setDemoMode: (enabled: boolean) => void;
  currentVehicle: string;
  setCurrentVehicle: (vehicle: string) => void;
}

const DemoModeContext = createContext<DemoModeContextType | undefined>(undefined);

export function DemoModeProvider({ children }: { children: ReactNode }) {
  const [isDemoMode, setIsDemoMode] = useState(() => {
    // Load from localStorage on init
    const saved = localStorage.getItem('attachvault_demo_mode');
    return saved === 'true';
  });

  const [currentVehicle, setCurrentVehicle] = useState(() => {
    const saved = localStorage.getItem('attachvault_demo_vehicle');
    return saved || '2019_dodge_charger';
  });

  // Persist demo mode state
  useEffect(() => {
    localStorage.setItem('attachvault_demo_mode', isDemoMode.toString());
  }, [isDemoMode]);

  // Persist vehicle selection
  useEffect(() => {
    localStorage.setItem('attachvault_demo_vehicle', currentVehicle);
  }, [currentVehicle]);

  const setDemoMode = (enabled: boolean) => {
    setIsDemoMode(enabled);
    console.log(`[DemoMode] ${enabled ? 'Enabled' : 'Disabled'}`);
  };

  return (
    <DemoModeContext.Provider value={{ isDemoMode, setDemoMode, currentVehicle, setCurrentVehicle }}>
      {children}
    </DemoModeContext.Provider>
  );
}

export function useDemoMode() {
  const context = useContext(DemoModeContext);
  if (context === undefined) {
    throw new Error('useDemoMode must be used within a DemoModeProvider');
  }
  return context;
}
