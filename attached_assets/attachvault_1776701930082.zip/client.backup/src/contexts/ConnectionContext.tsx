import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { ConnectionManager, ConnectionEvent } from '@/lib/obd2-protocol';
import { toast } from 'sonner';

interface ConnectionContextType {
  connectionManager: ConnectionManager;
  isConnected: boolean;
  isConnecting: boolean;
  hardwareType: string | null;
}

const ConnectionContext = createContext<ConnectionContextType | null>(null);

export function ConnectionProvider({ children }: { children: ReactNode }) {
  const [connectionManager] = useState(() => new ConnectionManager());
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [hardwareType, setHardwareType] = useState<string | null>(null);

  useEffect(() => {
    // Listen to connection events
    const unsubscribe = connectionManager.onConnectionEvent((event: ConnectionEvent) => {
      switch (event.type) {
        case 'connected':
          setIsConnected(true);
          setIsConnecting(false);
          setHardwareType(connectionManager.getHardwareType());
          toast.success('Hardware connected successfully!');
          break;
        case 'disconnected':
          setIsConnected(false);
          setIsConnecting(false);
          setHardwareType(null);
          break;
        case 'error':
          setIsConnected(false);
          setIsConnecting(false);
          toast.error(`Connection error: ${event.message}`);
          break;
      }
    });

    // Attempt auto-reconnect on mount
    const attemptAutoReconnect = async () => {
      const saved = connectionManager.getSavedSettings();
      if (saved) {
        // Only show toast if we have permission to attempt reconnect
        // Check if we have previously granted ports (Web Serial API)
        let canAttempt = true;
        if ('serial' in navigator) {
          const ports = await navigator.serial.getPorts();
          canAttempt = ports.length > 0;
        }
        
        if (canAttempt) {
          setIsConnecting(true);
          toast.info(`Reconnecting to ${saved.hardwareType.toUpperCase()}...`, {
            duration: 3000,
          });
        }
        
        const attempted = await connectionManager.autoReconnect();
        
        if (!attempted) {
          setIsConnecting(false);
          // Silent fail - user can manually connect via the Connect button
        }
        // If attempted, the connection event listener will update state
      }
    };

    attemptAutoReconnect();

    return () => {
      unsubscribe();
    };
  }, [connectionManager]);

  return (
    <ConnectionContext.Provider
      value={{
        connectionManager,
        isConnected,
        isConnecting,
        hardwareType,
      }}
    >
      {children}
    </ConnectionContext.Provider>
  );
}

export function useConnection() {
  const context = useContext(ConnectionContext);
  if (!context) {
    throw new Error('useConnection must be used within ConnectionProvider');
  }
  return context;
}
