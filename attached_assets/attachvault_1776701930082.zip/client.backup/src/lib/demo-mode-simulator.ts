/**
 * Demo Mode Simulator
 * Provides realistic simulated responses for all diagnostic operations
 */

import { getDemoVehicle, getDemoModule, type DemoModule } from '@shared/demo-vehicles';

export interface SimulatedUDSResponse {
  success: boolean;
  data?: Uint8Array;
  error?: string;
  delay: number; // Realistic delay in ms
}

/**
 * Simulate security access seed request (0x27 01)
 */
export async function simulateSecuritySeedRequest(
  vehicleId: string,
  canId: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 200));

  // Return seed bytes (4 bytes for most modules, 5 bytes for Atlantis Level 5)
  const seedHex = module.securitySeed || '1A2B3C4D';
  const seedBytes = hexToBytes(seedHex);
  
  // UDS positive response: 67 01 [SEED_BYTES]
  const response = new Uint8Array([0x67, 0x01, ...seedBytes]);

  return { success: true, data: response, delay: 200 };
}

/**
 * Simulate security access key send (0x27 02)
 */
export async function simulateSecurityKeySend(
  vehicleId: string,
  canId: string,
  keyBytes: Uint8Array
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 300));

  // Validate key (in demo mode, we accept any key)
  // UDS positive response: 67 02
  const response = new Uint8Array([0x67, 0x02]);

  return { success: true, data: response, delay: 300 };
}

/**
 * Simulate VIN read (0x22 F1 90)
 */
export async function simulateVINRead(
  vehicleId: string,
  canId: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 250));

  // Convert VIN to bytes
  const vinBytes = new TextEncoder().encode(module.vin);
  
  // UDS positive response: 62 F1 90 [VIN_BYTES]
  const response = new Uint8Array([0x62, 0xF1, 0x90, ...Array.from(vinBytes)]);

  return { success: true, data: response, delay: 250 };
}

/**
 * Simulate VIN write (0x2E F1 90 [VIN])
 */
export async function simulateVINWrite(
  vehicleId: string,
  canId: string,
  newVIN: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Validate VIN format
  if (newVIN.length !== 17) {
    return { success: false, error: 'Invalid VIN length', delay: 100 };
  }

  // Simulate realistic delay (VIN write takes longer)
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Update demo module VIN (in-memory only for demo)
  module.vin = newVIN;

  // UDS positive response: 6E F1 90
  const response = new Uint8Array([0x6E, 0xF1, 0x90]);

  return { success: true, data: response, delay: 2000 };
}

/**
 * Simulate DTC read (0x19 02 AF)
 */
export async function simulateDTCRead(
  vehicleId: string,
  canId: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 300));

  // Convert DTCs to bytes
  const dtcBytes: number[] = [];
  module.dtcs.forEach(dtc => {
    // Convert DTC string (e.g., "P0171") to 2-byte format
    const dtcValue = dtcStringToBytes(dtc);
    dtcBytes.push(...dtcValue);
  });

  // UDS positive response: 59 02 AF [DTC_COUNT] [DTC_BYTES]
  const response = new Uint8Array([0x59, 0x02, 0xAF, module.dtcs.length, ...dtcBytes]);

  return { success: true, data: response, delay: 300 };
}

/**
 * Simulate DTC clear (0x14 FF FF FF)
 */
export async function simulateDTCClear(
  vehicleId: string,
  canId: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Clear DTCs (in-memory only for demo)
  module.dtcs = [];

  // UDS positive response: 54
  const response = new Uint8Array([0x54]);

  return { success: true, data: response, delay: 500 };
}

/**
 * Simulate diagnostic session control (0x10 03)
 */
export async function simulateDiagnosticSession(
  vehicleId: string,
  canId: string,
  sessionType: number
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 150));

  // UDS positive response: 50 [SESSION_TYPE]
  const response = new Uint8Array([0x50, sessionType]);

  return { success: true, data: response, delay: 150 };
}

/**
 * Simulate part number read (0x22 F1 87)
 */
export async function simulatePartNumberRead(
  vehicleId: string,
  canId: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 200));

  // Convert part number to bytes
  const partBytes = new TextEncoder().encode(module.partNumber);
  
  // UDS positive response: 62 F1 87 [PART_NUMBER_BYTES]
  const response = new Uint8Array([0x62, 0xF1, 0x87, ...Array.from(partBytes)]);

  return { success: true, data: response, delay: 200 };
}

/**
 * Simulate software version read (0x22 F1 89)
 */
export async function simulateSoftwareVersionRead(
  vehicleId: string,
  canId: string
): Promise<SimulatedUDSResponse> {
  const module = getDemoModule(vehicleId, canId);
  if (!module) {
    return { success: false, error: 'Module not found', delay: 100 };
  }

  // Simulate realistic delay
  await new Promise(resolve => setTimeout(resolve, 200));

  // Convert software version to bytes
  const swBytes = new TextEncoder().encode(module.softwareVersion);
  
  // UDS positive response: 62 F1 89 [SW_VERSION_BYTES]
  const response = new Uint8Array([0x62, 0xF1, 0x89, ...Array.from(swBytes)]);

  return { success: true, data: response, delay: 200 };
}

// Helper functions

function hexToBytes(hex: string): number[] {
  const bytes: number[] = [];
  for (let i = 0; i < hex.length; i += 2) {
    bytes.push(parseInt(hex.substr(i, 2), 16));
  }
  return bytes;
}

function dtcStringToBytes(dtc: string): number[] {
  // Convert DTC string (e.g., "P0171") to 2-byte format
  // P = 0, C = 1, B = 2, U = 3
  const typeMap: Record<string, number> = { P: 0, C: 1, B: 2, U: 3 };
  const type = typeMap[dtc[0]] || 0;
  const code = parseInt(dtc.substring(1), 16);
  
  const byte1 = (type << 6) | ((code >> 8) & 0x3F);
  const byte2 = code & 0xFF;
  
  return [byte1, byte2, 0x00]; // 3 bytes: DTC + status
}
