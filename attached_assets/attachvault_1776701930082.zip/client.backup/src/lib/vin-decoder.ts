export interface VINInfo {
  vin: string;
  valid: boolean;
  wmi: string;
  vds: string;
  vis: string;
  make: string;
  manufacturer: string;
  modelYear: number;
  modelYearCode: string;
  plantCode: string;
  serialNumber: string;
  checkDigit: string;
  checkDigitValid: boolean;
  region: string;
}

export interface VINCompatibility {
  compatible: boolean;
  makeMatch: boolean;
  yearMatch: boolean;
  warnings: string[];
  errors: string[];
}

const WMI_DATABASE: Record<string, { make: string; manufacturer: string; region: string }> = {
  '1C3': { make: 'Chrysler', manufacturer: 'FCA US LLC', region: 'United States' },
  '1C4': { make: 'Chrysler', manufacturer: 'FCA US LLC', region: 'United States' },
  '1C6': { make: 'Chrysler', manufacturer: 'FCA US LLC', region: 'United States' },
  '2C3': { make: 'Chrysler', manufacturer: 'FCA Canada Inc', region: 'Canada' },
  '2C4': { make: 'Chrysler', manufacturer: 'FCA Canada Inc', region: 'Canada' },
  '3C3': { make: 'Chrysler', manufacturer: 'FCA Mexico', region: 'Mexico' },
  '3C4': { make: 'Chrysler', manufacturer: 'FCA Mexico', region: 'Mexico' },
  '3C6': { make: 'Ram', manufacturer: 'FCA Mexico', region: 'Mexico' },
  '1B3': { make: 'Dodge', manufacturer: 'FCA US LLC', region: 'United States' },
  '2B3': { make: 'Dodge', manufacturer: 'FCA Canada Inc', region: 'Canada' },
  '3B3': { make: 'Dodge', manufacturer: 'FCA Mexico', region: 'Mexico' },
  '1J4': { make: 'Jeep', manufacturer: 'FCA US LLC', region: 'United States' },
  '1J8': { make: 'Jeep', manufacturer: 'FCA US LLC', region: 'United States' },
  '3C7': { make: 'Ram', manufacturer: 'FCA Mexico', region: 'Mexico' },
  '1G1': { make: 'Chevrolet', manufacturer: 'General Motors', region: 'United States' },
  '1G6': { make: 'Cadillac', manufacturer: 'General Motors', region: 'United States' },
  '2G1': { make: 'Chevrolet', manufacturer: 'General Motors Canada', region: 'Canada' },
  '1FA': { make: 'Ford', manufacturer: 'Ford Motor Company', region: 'United States' },
  '1FB': { make: 'Ford', manufacturer: 'Ford Motor Company', region: 'United States' },
  '1FC': { make: 'Ford', manufacturer: 'Ford Motor Company', region: 'United States' },
  '1FD': { make: 'Ford', manufacturer: 'Ford Motor Company', region: 'United States' },
  '1FM': { make: 'Ford', manufacturer: 'Ford Motor Company', region: 'United States' },
  '1FT': { make: 'Ford', manufacturer: 'Ford Motor Company', region: 'United States' },
  '2FA': { make: 'Ford', manufacturer: 'Ford Motor Company of Canada', region: 'Canada' },
  '4T1': { make: 'Toyota', manufacturer: 'Toyota Motor Corporation', region: 'United States' },
  '5TD': { make: 'Toyota', manufacturer: 'Toyota Motor Manufacturing Canada', region: 'Canada' },
  'JT2': { make: 'Toyota', manufacturer: 'Toyota Motor Corporation', region: 'Japan' },
  '1HG': { make: 'Honda', manufacturer: 'Honda', region: 'United States' },
  '2HG': { make: 'Honda', manufacturer: 'Honda Canada', region: 'Canada' },
  'JHM': { make: 'Honda', manufacturer: 'Honda Motor Co., Ltd.', region: 'Japan' },
};

const MODEL_YEAR_CODES_BASE: Record<string, number> = {
  'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4,
  'F': 5, 'G': 6, 'H': 7, 'J': 8, 'K': 9,
  'L': 10, 'M': 11, 'N': 12, 'P': 13, 'R': 14,
  'S': 15, 'T': 16, 'V': 17, 'W': 18, 'X': 19,
  'Y': 20, '1': 21, '2': 22, '3': 23, '4': 24,
  '5': 25, '6': 26, '7': 27, '8': 28, '9': 29,
};

const VIN_TRANSLITERATION: Record<string, number> = {
  'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8,
  'J': 1, 'K': 2, 'L': 3, 'M': 4, 'N': 5, 'P': 7, 'R': 9,
  'S': 2, 'T': 3, 'U': 4, 'V': 5, 'W': 6, 'X': 7, 'Y': 8, 'Z': 9,
  '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9
};

const VIN_WEIGHTS = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];

export function calculateVINCheckDigit(vin: string): string {
  const vinUpper = vin.toUpperCase().replace(/\s/g, '');
  if (vinUpper.length !== 17) return '';
  
  let sum = 0;
  for (let i = 0; i < 17; i++) {
    const char = vinUpper[i];
    const value = VIN_TRANSLITERATION[char];
    if (value === undefined) return '';
    sum += value * VIN_WEIGHTS[i];
  }
  
  const checkDigit = sum % 11;
  return checkDigit === 10 ? 'X' : checkDigit.toString();
}

function validateCheckDigit(vin: string): boolean {
  let sum = 0;
  for (let i = 0; i < 17; i++) {
    const char = vin[i];
    const value = VIN_TRANSLITERATION[char];
    if (value === undefined) return false;
    sum += value * VIN_WEIGHTS[i];
  }

  const checkDigit = sum % 11;
  const expectedChar = checkDigit === 10 ? 'X' : checkDigit.toString();
  return vin[8] === expectedChar;
}

function decodeModelYear(yearCode: string): number {
  const offset = MODEL_YEAR_CODES_BASE[yearCode];
  if (offset === undefined) return 0;

  const currentYear = new Date().getFullYear();
  const cycles = [
    { start: 1980, end: 2009 },
    { start: 2010, end: 2039 },
    { start: 2040, end: 2069 },
  ];
  
  for (const cycle of cycles) {
    const year = cycle.start + offset;
    if (year <= currentYear + 1 && year >= currentYear - 20) {
      return year;
    }
  }
  
  return 2010 + offset;
}

export function decodeVIN(vin: string): VINInfo {
  vin = vin.toUpperCase().replace(/\s/g, '');

  if (vin.length !== 17) {
    return {
      vin,
      valid: false,
      wmi: '',
      vds: '',
      vis: '',
      make: 'Unknown',
      manufacturer: 'Unknown',
      modelYear: 0,
      modelYearCode: '',
      plantCode: '',
      serialNumber: '',
      checkDigit: '',
      checkDigitValid: false,
      region: 'Unknown',
    };
  }

  if (/[IOQ]/.test(vin)) {
    return {
      vin,
      valid: false,
      wmi: vin.substring(0, 3),
      vds: vin.substring(3, 9),
      vis: vin.substring(9, 17),
      make: 'Invalid',
      manufacturer: 'Invalid characters (I, O, Q) in VIN',
      modelYear: 0,
      modelYearCode: '',
      plantCode: '',
      serialNumber: '',
      checkDigit: vin[8],
      checkDigitValid: false,
      region: 'Unknown',
    };
  }

  const wmi = vin.substring(0, 3);
  const vds = vin.substring(3, 9);
  const vis = vin.substring(9, 17);
  const checkDigit = vin[8];
  const modelYearCode = vin[9];
  const plantCode = vin[10];
  const serialNumber = vin.substring(11, 17);

  const checkDigitValid = validateCheckDigit(vin);
  const modelYear = decodeModelYear(modelYearCode);

  const manufacturerInfo = WMI_DATABASE[wmi] || {
    make: 'Unknown',
    manufacturer: 'Unknown',
    region: 'Unknown',
  };

  return {
    vin,
    valid: true,
    wmi,
    vds,
    vis,
    make: manufacturerInfo.make,
    manufacturer: manufacturerInfo.manufacturer,
    modelYear,
    modelYearCode,
    plantCode,
    serialNumber,
    checkDigit,
    checkDigitValid,
    region: manufacturerInfo.region,
  };
}

export function checkVINCompatibility(
  originalVIN: string,
  targetVIN: string
): VINCompatibility {
  const original = decodeVIN(originalVIN);
  const target = decodeVIN(targetVIN);

  const warnings: string[] = [];
  const errors: string[] = [];

  if (!original.checkDigitValid) {
    warnings.push(`Original VIN has invalid check digit (expected: ${calculateVINCheckDigit(originalVIN)})`);
  }
  if (!target.checkDigitValid) {
    warnings.push(`Target VIN has invalid check digit (expected: ${calculateVINCheckDigit(targetVIN)})`);
  }

  const makeMatch = original.make === target.make;
  if (!makeMatch && original.valid && target.valid) {
    errors.push(
      `Make mismatch: Original is ${original.make}, target is ${target.make}`
    );
  }

  const yearMatch = Math.abs(original.modelYear - target.modelYear) <= 3;
  if (!yearMatch && original.valid && target.valid) {
    warnings.push(
      `Model year difference: Original is ${original.modelYear}, target is ${target.modelYear} (${Math.abs(original.modelYear - target.modelYear)} years apart)`
    );
  }

  if (original.region !== target.region && original.valid && target.valid) {
    warnings.push(
      `Region mismatch: Original is ${original.region}, target is ${target.region}`
    );
  }

  const compatible = errors.length === 0;

  return {
    compatible,
    makeMatch,
    yearMatch,
    warnings,
    errors,
  };
}

export function formatVINInfo(info: VINInfo): string {
  if (!info.valid) {
    return `Invalid VIN: ${info.vin}`;
  }

  return `${info.make} ${info.modelYear} (${info.manufacturer}, ${info.region})`;
}

export function reverseVIN(vin: string): string {
  return vin.split('').reverse().join('');
}

export function isValidVIN(vin: string): boolean {
  const cleanVin = vin.toUpperCase().replace(/\s/g, '');
  if (cleanVin.length !== 17) return false;
  if (/[IOQ]/.test(cleanVin)) return false;
  if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(cleanVin)) return false;
  return true;
}
