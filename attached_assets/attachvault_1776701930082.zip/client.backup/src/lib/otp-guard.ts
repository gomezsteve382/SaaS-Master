/**
 * OTP Guard Service
 * Protects against accidental writes to One-Time Programmable (OTP) modules
 * 
 * OTP modules (RFHUB, ORC, SGW) can only be written ONCE.
 * Writing incorrect data permanently bricks the module.
 */

import { getOTPInfo, getRiskLevel, type RiskLevel, type OTPInfo } from './module-database';

export interface BackupRecord {
  moduleCode: string;
  timestamp: number;
  dataHash: string;
  fileName: string;
  fileSize: number;
  vinAtBackup?: string;
}

export interface WriteGuardResult {
  allowed: boolean;
  riskLevel: RiskLevel;
  otpInfo?: OTPInfo;
  requiresConfirmation: boolean;
  confirmationSteps: string[];
  blockReason?: string;
}

export interface WriteConfirmation {
  moduleCode: string;
  acknowledgedRisk: boolean;
  hasBackup: boolean;
  backupVerified: boolean;
  doubleConfirmed: boolean;
  overrideReason?: string;
  timestamp: number;
}

const BACKUP_STORAGE_KEY = 'otp_backup_records';
const CONFIRMATION_LOG_KEY = 'otp_confirmation_log';

export function getBackupRecords(): BackupRecord[] {
  try {
    const stored = localStorage.getItem(BACKUP_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export function saveBackupRecord(record: BackupRecord): void {
  const records = getBackupRecords();
  const existingIdx = records.findIndex(r => 
    r.moduleCode === record.moduleCode && r.dataHash === record.dataHash
  );
  if (existingIdx >= 0) {
    records[existingIdx] = record;
  } else {
    records.push(record);
  }
  localStorage.setItem(BACKUP_STORAGE_KEY, JSON.stringify(records));
}

export function hasRecentBackup(moduleCode: string, maxAgeMs: number = 24 * 60 * 60 * 1000): boolean {
  const records = getBackupRecords();
  const now = Date.now();
  return records.some(r => 
    r.moduleCode === moduleCode && 
    (now - r.timestamp) < maxAgeMs
  );
}

export function getLatestBackup(moduleCode: string): BackupRecord | undefined {
  const records = getBackupRecords();
  const moduleRecords = records.filter(r => r.moduleCode === moduleCode);
  if (moduleRecords.length === 0) return undefined;
  return moduleRecords.sort((a, b) => b.timestamp - a.timestamp)[0];
}

export function logConfirmation(confirmation: WriteConfirmation): void {
  try {
    const stored = localStorage.getItem(CONFIRMATION_LOG_KEY);
    const logs: WriteConfirmation[] = stored ? JSON.parse(stored) : [];
    logs.push(confirmation);
    if (logs.length > 100) {
      logs.splice(0, logs.length - 100);
    }
    localStorage.setItem(CONFIRMATION_LOG_KEY, JSON.stringify(logs));
  } catch {
  }
}

export function checkWriteGuard(moduleCode: string): WriteGuardResult {
  const riskLevel = getRiskLevel(moduleCode);
  const otpInfo = getOTPInfo(moduleCode);
  
  if (riskLevel === 'safe') {
    return {
      allowed: true,
      riskLevel: 'safe',
      requiresConfirmation: false,
      confirmationSteps: [],
    };
  }
  
  if (riskLevel === 'caution') {
    return {
      allowed: true,
      riskLevel: 'caution',
      requiresConfirmation: true,
      confirmationSteps: [
        'Confirm you have a backup of the original data',
        'Acknowledge that this operation may require dealer tools to reverse',
      ],
    };
  }
  
  const hasBackup = hasRecentBackup(moduleCode);
  const confirmationSteps = [
    'Read and understand the OTP warning message',
    'Verify you have a VERIFIED BACKUP of the original module data',
    'Confirm the new VIN is 100% correct (double-check every character)',
    'Acknowledge this operation is IRREVERSIBLE',
    'Type "I UNDERSTAND" to confirm you accept full responsibility',
  ];
  
  if (!hasBackup) {
    return {
      allowed: false,
      riskLevel: 'danger',
      otpInfo,
      requiresConfirmation: true,
      confirmationSteps,
      blockReason: 'No backup record found for this module. You MUST create a backup before attempting any OTP write operation.',
    };
  }
  
  return {
    allowed: true,
    riskLevel: 'danger',
    otpInfo,
    requiresConfirmation: true,
    confirmationSteps,
  };
}

export async function calculateDataHash(data: Uint8Array): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', data as BufferSource);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function createBackupFromData(
  moduleCode: string,
  data: Uint8Array,
  fileName: string,
  vin?: string
): Promise<BackupRecord> {
  return calculateDataHash(data).then(dataHash => {
    const record: BackupRecord = {
      moduleCode,
      timestamp: Date.now(),
      dataHash,
      fileName,
      fileSize: data.length,
      vinAtBackup: vin,
    };
    saveBackupRecord(record);
    return record;
  });
}

export function getRiskBadgeColor(riskLevel: RiskLevel): string {
  switch (riskLevel) {
    case 'safe': return 'bg-green-500/20 text-green-400 border-green-500/30';
    case 'caution': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    case 'danger': return 'bg-red-500/20 text-red-400 border-red-500/30';
    default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  }
}

export function getRiskIcon(riskLevel: RiskLevel): string {
  switch (riskLevel) {
    case 'safe': return '✓';
    case 'caution': return '⚠';
    case 'danger': return '⛔';
    default: return '?';
  }
}
