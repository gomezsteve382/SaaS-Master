import { toHex, fromHex, calculateKey } from './fca-keygen';

export type UDSResponse = {
  positive: boolean;
  serviceId: number;
  data: Uint8Array;
  rawHex: string;
  nrc?: number;
  nrcDescription?: string;
};

export const UDS_SERVICES = {
  DIAGNOSTIC_SESSION_CONTROL: 0x10,
  ECU_RESET: 0x11,
  CLEAR_DIAGNOSTIC_INFO: 0x14,
  READ_DTC_INFO: 0x19,
  READ_DATA_BY_ID: 0x22,
  READ_MEMORY_BY_ADDRESS: 0x23,
  SECURITY_ACCESS: 0x27,
  COMMUNICATION_CONTROL: 0x28,
  WRITE_DATA_BY_ID: 0x2E,
  ROUTINE_CONTROL: 0x31,
  REQUEST_DOWNLOAD: 0x34,
  REQUEST_UPLOAD: 0x35,
  TRANSFER_DATA: 0x36,
  TRANSFER_EXIT: 0x37,
  TESTER_PRESENT: 0x3E,
};

export const DIAGNOSTIC_SESSIONS = {
  DEFAULT: 0x01,
  PROGRAMMING: 0x02,
  EXTENDED: 0x03,
};

export const ROUTINE_CONTROL_TYPES = {
  START: 0x01,
  STOP: 0x02,
  REQUEST_RESULTS: 0x03,
};

export const NRC_CODES: Record<number, string> = {
  0x10: 'generalReject',
  0x11: 'serviceNotSupported',
  0x12: 'subFunctionNotSupported',
  0x13: 'incorrectMessageLengthOrFormat',
  0x14: 'responseTooLong',
  0x21: 'busyRepeatRequest',
  0x22: 'conditionsNotCorrect',
  0x24: 'requestSequenceError',
  0x25: 'noResponseFromSubnetComponent',
  0x26: 'failurePreventsExecution',
  0x31: 'requestOutOfRange',
  0x33: 'securityAccessDenied',
  0x35: 'invalidKey',
  0x36: 'exceededNumberOfAttempts',
  0x37: 'requiredTimeDelayNotExpired',
  0x70: 'uploadDownloadNotAccepted',
  0x71: 'transferDataSuspended',
  0x72: 'generalProgrammingFailure',
  0x73: 'wrongBlockSequenceCounter',
  0x78: 'responsePending',
  0x7E: 'subFunctionNotSupportedInActiveSession',
  0x7F: 'serviceNotSupportedInActiveSession',
};

export function buildDiagnosticSessionControl(session: number): Uint8Array {
  return new Uint8Array([UDS_SERVICES.DIAGNOSTIC_SESSION_CONTROL, session]);
}

export function buildSecurityAccessRequestSeed(level: number): Uint8Array {
  return new Uint8Array([UDS_SERVICES.SECURITY_ACCESS, level]);
}

export function buildSecurityAccessSendKey(level: number, key: Uint8Array): Uint8Array {
  const payload = new Uint8Array(2 + key.length);
  payload[0] = UDS_SERVICES.SECURITY_ACCESS;
  payload[1] = level + 1;
  payload.set(key, 2);
  return payload;
}

export function buildReadMemoryByAddress(address: number, length: number): Uint8Array {
  const alfid = 0x24;
  const payload = new Uint8Array(8);
  payload[0] = UDS_SERVICES.READ_MEMORY_BY_ADDRESS;
  payload[1] = alfid;
  payload[2] = (address >>> 24) & 0xFF;
  payload[3] = (address >>> 16) & 0xFF;
  payload[4] = (address >>> 8) & 0xFF;
  payload[5] = address & 0xFF;
  payload[6] = (length >>> 8) & 0xFF;
  payload[7] = length & 0xFF;
  return payload;
}

export function buildWriteDataById(dataId: number, data: Uint8Array): Uint8Array {
  const payload = new Uint8Array(3 + data.length);
  payload[0] = UDS_SERVICES.WRITE_DATA_BY_ID;
  payload[1] = (dataId >>> 8) & 0xFF;
  payload[2] = dataId & 0xFF;
  payload.set(data, 3);
  return payload;
}

export function buildReadDataById(dataId: number): Uint8Array {
  return new Uint8Array([
    UDS_SERVICES.READ_DATA_BY_ID,
    (dataId >>> 8) & 0xFF,
    dataId & 0xFF,
  ]);
}

export function buildRoutineControl(type: number, routineId: number, args?: Uint8Array): Uint8Array {
  const baseLen = 4;
  const argsLen = args?.length ?? 0;
  const payload = new Uint8Array(baseLen + argsLen);
  payload[0] = UDS_SERVICES.ROUTINE_CONTROL;
  payload[1] = type;
  payload[2] = (routineId >>> 8) & 0xFF;
  payload[3] = routineId & 0xFF;
  if (args) {
    payload.set(args, 4);
  }
  return payload;
}

export function buildTesterPresent(): Uint8Array {
  return new Uint8Array([UDS_SERVICES.TESTER_PRESENT, 0x00]);
}

export function parseUDSResponse(data: Uint8Array): UDSResponse {
  const rawHex = toHex(data);
  
  if (data[0] === 0x7F) {
    const requestedSid = data[1];
    const nrc = data[2];
    return {
      positive: false,
      serviceId: requestedSid,
      data,
      rawHex,
      nrc,
      nrcDescription: NRC_CODES[nrc] || 'unknownNRC',
    };
  }
  
  return {
    positive: true,
    serviceId: data[0] - 0x40,
    data,
    rawHex,
  };
}

export type ECUDefinition = {
  name: string;
  shortName: string;
  txId: number;
  rxId: number;
  description: string;
  protectionLevel: 'none' | 'software' | 'otp';
  memoryMap: {
    boot: { start: number; end: number };
    calibration: { start: number; end: number };
    config: { start: number; end: number };
  };
  routines: { id: number; name: string; description: string }[];
};

export const ECU_DATABASE: ECUDefinition[] = [
  {
    name: 'RFHUB_WCM',
    shortName: 'RFHUB',
    txId: 0x750,
    rxId: 0x758,
    description: 'RF Hub / Wireless Control Module - Key Fob / TPMS',
    protectionLevel: 'otp',
    memoryMap: {
      boot: { start: 0x00000000, end: 0x0000FFFF },
      calibration: { start: 0x00010000, end: 0x0001FFFF },
      config: { start: 0x00020000, end: 0x0002FFFF },
    },
    routines: [
      { id: 0x00A5, name: 'Virginize', description: 'Clear VIN / Key Pairing (OTP Warning!)' },
      { id: 0xF0F0, name: 'TPMS_Reset', description: 'Reset Tire Pressure Sensor IDs' },
    ],
  },
  {
    name: 'BCM_CGW',
    shortName: 'BCM',
    txId: 0x7E3,
    rxId: 0x7EB,
    description: 'Body Control Module / Central Gateway',
    protectionLevel: 'software',
    memoryMap: {
      boot: { start: 0x00100000, end: 0x0010FFFF },
      calibration: { start: 0x00110000, end: 0x0011FFFF },
      config: { start: 0x00120000, end: 0x0012FFFF },
    },
    routines: [
      { id: 0x0100, name: 'Lamp_Test', description: 'Activate all exterior lights' },
      { id: 0x0150, name: 'Horn_Test', description: 'Short horn activation' },
      { id: 0xDE01, name: 'PROXI_Align', description: 'PROXI Configuration Alignment' },
    ],
  },
  {
    name: 'GPEC_PCM',
    shortName: 'PCM',
    txId: 0x7E0,
    rxId: 0x7E8,
    description: 'Powertrain Control Module (GPEC2A/GPEC3)',
    protectionLevel: 'otp',
    memoryMap: {
      boot: { start: 0x00000000, end: 0x0003FFFF },
      calibration: { start: 0x00040000, end: 0x0007FFFF },
      config: { start: 0x00080000, end: 0x0008FFFF },
    },
    routines: [
      { id: 0xFF0A, name: 'Injector_Test', description: 'Individual injector actuation' },
      { id: 0xFF0B, name: 'Spark_Test', description: 'Individual cylinder spark test' },
      { id: 0xF190, name: 'VIN_Write', description: 'Vehicle Identification Number Write (OTP!)' },
    ],
  },
  {
    name: 'TCM_NAG1',
    shortName: 'TCM',
    txId: 0x7E1,
    rxId: 0x7E9,
    description: 'Transmission Control Module (NAG1/722.6)',
    protectionLevel: 'software',
    memoryMap: {
      boot: { start: 0x00000000, end: 0x0001FFFF },
      calibration: { start: 0x00020000, end: 0x0003FFFF },
      config: { start: 0x00040000, end: 0x0004FFFF },
    },
    routines: [
      { id: 0x0200, name: 'Clutch_Adapt', description: 'Clutch adaptation reset' },
      { id: 0x0201, name: 'Line_Pressure_Test', description: 'Line pressure verification' },
    ],
  },
  {
    name: 'ABS_ESP',
    shortName: 'ABS',
    txId: 0x7B0,
    rxId: 0x7B8,
    description: 'ABS / Electronic Stability Program Module',
    protectionLevel: 'software',
    memoryMap: {
      boot: { start: 0x00000000, end: 0x0000FFFF },
      calibration: { start: 0x00010000, end: 0x0001FFFF },
      config: { start: 0x00020000, end: 0x0002FFFF },
    },
    routines: [
      { id: 0x0300, name: 'Bleed_ABS', description: 'ABS brake bleeding routine' },
      { id: 0x0301, name: 'Sensor_Cal', description: 'Wheel speed sensor calibration' },
    ],
  },
];

export function getECUByTxId(txId: number): ECUDefinition | undefined {
  return ECU_DATABASE.find(e => e.txId === txId);
}
