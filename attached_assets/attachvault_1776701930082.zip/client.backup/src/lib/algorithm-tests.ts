/**
 * Test vectors for all supported algorithms
 * These verify correct implementation without real hardware
 */

import { calculateKey } from "./fca-keygen";
import { calculateCrcWithAlgorithm, CRC_ALGORITHMS } from "./crc-detection";

export interface AlgorithmTestResult {
  algorithm: string;
  passed: boolean;
  expected: string;
  calculated: string;
  error?: string;
}

// FCA Security Key Test Vectors - computed from rotate-left-5 + XOR algorithm
// Algorithm: key = rotateLeft32(seed, 5) XOR constant
// Constants: Level 1 = 0x4B92, Level 3 = 0x82F1, Level 5 = 0x1209
export const FCA_KEY_TESTS = [
  {
    name: "Level 1 (0x01) - Engineering Mode",
    level: 0x01,
    seed: "12345678",
    expectedKey: "468A8490",
  },
  {
    name: "Level 3 (0x03) - High Security",
    level: 0x03,
    seed: "ABCDEF01",
    expectedKey: "79BD62C4",
  },
  {
    name: "Level 5 (0x05) - Bootloader",
    level: 0x05,
    seed: "DEADBEEF",
    expectedKey: "D5B7CFF2",
  },
];

// CRC Test Vectors - use standard "123456789" test string for verification
// This is the universally agreed test string for CRC algorithm verification
export const CRC_TEST_VECTORS = [
  {
    name: "Standard check string '123456789'",
    data: new Uint8Array([0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39]),
    expectedCRCs: {
      "CRC-16/MODBUS": 0x4B37,
      "CRC-16/IBM": 0xBB3D,
      "CRC-16/CCITT-FALSE": 0x29B1,
      "CRC-16/XMODEM": 0x31C3,
      "CRC-16/KERMIT": 0x2189,
      "CRC-32": 0xCBF43926,
      "CRC-32/BZIP2": 0xFC891918,
    },
  },
];

export function testFCAKeys(): AlgorithmTestResult[] {
  const results: AlgorithmTestResult[] = [];

  for (const test of FCA_KEY_TESTS) {
    try {
      const seedBytes = new Uint8Array(
        test.seed.match(/.{1,2}/g)?.map((b) => parseInt(b, 16)) || []
      );
      const keyBytes = calculateKey(seedBytes, test.level);
      const calculated = Array.from(keyBytes)
        .map((b) => b.toString(16).padStart(2, "0").toUpperCase())
        .join("");

      results.push({
        algorithm: test.name,
        passed: calculated === test.expectedKey,
        expected: test.expectedKey,
        calculated,
      });
    } catch (error) {
      results.push({
        algorithm: test.name,
        passed: false,
        expected: test.expectedKey,
        calculated: "ERROR",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  return results;
}

export function testCRCAlgorithms(): AlgorithmTestResult[] {
  const results: AlgorithmTestResult[] = [];

  for (const vector of CRC_TEST_VECTORS) {
    for (const algo of CRC_ALGORITHMS) {
      try {
        const calculated = calculateCrcWithAlgorithm(vector.data, algo);
        const expected = vector.expectedCRCs[algo.name as keyof typeof vector.expectedCRCs];
        const passed = calculated === expected;

        results.push({
          algorithm: `${vector.name} - ${algo.name}`,
          passed,
          expected: `0x${expected.toString(16).toUpperCase().padStart(algo.type === "CRC16" ? 4 : 8, "0")}`,
          calculated: `0x${calculated.toString(16).toUpperCase().padStart(algo.type === "CRC16" ? 4 : 8, "0")}`,
        });
      } catch (error) {
        results.push({
          algorithm: `${vector.name} - ${algo.name}`,
          passed: false,
          expected: `0x${vector.expectedCRCs[algo.name as keyof typeof vector.expectedCRCs]
            .toString(16)
            .toUpperCase()}`,
          calculated: "ERROR",
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
  }

  return results;
}

export function runAllTests(): {
  fcaKeys: AlgorithmTestResult[];
  crcAlgorithms: AlgorithmTestResult[];
  summary: { total: number; passed: number; failed: number };
} {
  const fcaKeys = testFCAKeys();
  const crcAlgorithms = testCRCAlgorithms();

  const allTests = [...fcaKeys, ...crcAlgorithms];
  const passed = allTests.filter((t) => t.passed).length;
  const failed = allTests.filter((t) => !t.passed).length;

  return {
    fcaKeys,
    crcAlgorithms,
    summary: {
      total: allTests.length,
      passed,
      failed,
    },
  };
}
