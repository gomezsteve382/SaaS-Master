import { create } from "zustand";

import { calculateKey as fcaCalculateKey, toHex as fcaToHex, SECURITY_CONSTANTS } from './fca-keygen';
import { UDS_SERVICES, NRC_CODES, ECU_DATABASE, getECUByTxId } from './uds-services';
import { MODULE_DATABASE, getAllModules } from './module-database';

export const SID_SECURITY_ACCESS = UDS_SERVICES.SECURITY_ACCESS;
export const SID_ROUTINE_CONTROL = UDS_SERVICES.ROUTINE_CONTROL;
export const SID_POS_RESPONSE = 0x67;
export const NRC_CONDITIONS_NOT_CORRECT = 0x22;
export const NRC_SECURITY_DENIED = 0x33;
export const SID_NEG_RESPONSE = 0x7F;

export { SECURITY_CONSTANTS, ECU_DATABASE, NRC_CODES };

function toHex(bytes: Uint8Array): string {
  return fcaToHex(bytes);
}

export type LogEntry = {
  id: string;
  timestamp: string;
  type: "info" | "success" | "error" | "warning" | "tx" | "rx";
  message: string;
  details?: string;
};

export type ECUState = {
  name: string;
  id: number;
  locked: boolean;
  seed: string | null;
  key: string | null;
  status: "idle" | "scanning" | "unlocked" | "error" | "waiting";
  progress: number;
  foundRoutines: string[];
};

export const calculateKey = fcaCalculateKey;

function buildECUsFromDatabase(): ECUState[] {
  const allModules = getAllModules();
  return allModules.slice(0, 5).map((mod) => ({
    name: mod.code,
    id: mod.tx,
    locked: true,
    seed: null,
    key: null,
    status: "waiting" as const,
    progress: 0,
    foundRoutines: [],
  }));
}

interface UDSStore {
  logs: LogEntry[];
  ecus: ECUState[];
  selectedEcuId: number | null;
  uploadedFile: File | null;
  fileData: Uint8Array | null;
  addLog: (type: LogEntry["type"], message: string, details?: string) => void;
  clearLogs: () => void;
  selectEcu: (id: number) => void;
  updateEcu: (id: number, updates: Partial<ECUState>) => void;
  resetEcu: (id: number) => void;
  setFile: (file: File | null, data: Uint8Array | null) => void;
}

export const useUDSStore = create<UDSStore>((set) => ({
  logs: [],
  ecus: buildECUsFromDatabase(),
  selectedEcuId: null,
  uploadedFile: null,
  fileData: null,

  addLog: (type: LogEntry["type"], message: string, details?: string) =>
    set((state: UDSStore) => {
      const newLog: LogEntry = {
        id: Math.random().toString(36).substring(7),
        timestamp: new Date().toISOString().split("T")[1].slice(0, -1),
        type,
        message,
        details,
      };
      return { logs: [...state.logs.slice(-99), newLog] };
    }),

  clearLogs: () => set({ logs: [] }),

  selectEcu: (id: number) => set({ selectedEcuId: id }),

  updateEcu: (id: number, updates: Partial<ECUState>) =>
    set((state: UDSStore) => ({
      ecus: state.ecus.map((ecu) =>
        ecu.id === id ? { ...ecu, ...updates } : ecu,
      ),
    })),

  resetEcu: (id: number) =>
    set((state: UDSStore) => ({
      ecus: state.ecus.map((ecu) =>
        ecu.id === id
          ? {
              ...ecu,
              locked: true,
              seed: null,
              key: null,
              status: "waiting" as const,
              progress: 0,
              foundRoutines: [],
            }
          : ecu,
      ),
    })),
    
  setFile: (file: File | null, data: Uint8Array | null) =>
    set({ uploadedFile: file, fileData: data }),
}));

export const runUnlockSequence = async (ecuId: number) => {
  const store = useUDSStore.getState();
  const ecu = store.ecus.find((e) => e.id === ecuId);
  if (!ecu) return;

  store.addLog("warning", `[${ecu.name}] Real hardware connection required for security access`);
  store.addLog("info", `[${ecu.name}] Use VIN Patcher for file-based operations`);
};

export const runRoutineFuzzer = async (ecuId: number) => {
  const store = useUDSStore.getState();
  const ecu = store.ecus.find((e) => e.id === ecuId);
  if (!ecu) return;

  store.addLog("warning", `[${ecu.name}] Real hardware connection required for routine execution`);
  store.addLog("info", `[${ecu.name}] Connect via J2534 interface for live routines`);
};
