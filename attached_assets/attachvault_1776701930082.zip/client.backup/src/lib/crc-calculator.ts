export function calculateCRC16CCITT(data: Uint8Array): number {
  const polynomial = 0x1021;
  let crc = 0xFFFF;
  
  for (let j = 0; j < data.length; j++) {
    const byte = data[j];
    crc ^= (byte << 8);
    for (let i = 0; i < 8; i++) {
      if (crc & 0x8000) {
        crc = ((crc << 1) ^ polynomial) & 0xFFFF;
      } else {
        crc = (crc << 1) & 0xFFFF;
      }
    }
  }
  
  return crc;
}

export function verifyCRC(data: Uint8Array, expectedCRC: number): boolean {
  return calculateCRC16CCITT(data) === expectedCRC;
}

export function patchCRC(data: Uint8Array, crcOffset: number): Uint8Array {
  const dataWithoutCRC = new Uint8Array(data.length);
  dataWithoutCRC.set(data);
  
  const newCRC = calculateCRC16CCITT(data.slice(0, crcOffset));
  
  dataWithoutCRC[crcOffset] = (newCRC >> 8) & 0xFF;
  dataWithoutCRC[crcOffset + 1] = newCRC & 0xFF;
  
  return dataWithoutCRC;
}

export function crcToHex(crc: number): string {
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

export function calculateCRCFromHex(hexData: string): string {
  const cleanHex = hexData.replace(/\s/g, '');
  const bytes = new Uint8Array(cleanHex.match(/.{1,2}/g)?.map(b => parseInt(b, 16)) || []);
  const crc = calculateCRC16CCITT(bytes);
  return crcToHex(crc);
}
