export type MemoryType = 'flash' | 'otp' | 'eeprom' | 'mixed';
export type RiskLevel = 'safe' | 'caution' | 'danger';
export type ProtectionLevel = 'software' | 'otp' | 'unknown';
export type CANBus = 'CAN-C' | 'CAN-IHS' | 'both';

export interface OTPInfo {
  memoryType: MemoryType;
  riskLevel: RiskLevel;
  otpRegions?: string;
  chipType?: string;
  requiresBackup: boolean;
  warningMessage: string;
  canReprogram: boolean;
}

export interface ModuleDefinition {
  code: string;
  name: string;
  tx: number;
  rx: number;
  verified: boolean;
  source: string;
  description: string;
  protectionLevel?: ProtectionLevel;
  otpInfo?: OTPInfo;
  bus: CANBus;
}

export interface CustomModule {
  code: string;
  name: string;
  tx: number;
  rx: number;
  description?: string;
}

export const DODGE_VIN_OFFSETS: Record<string, number[]> = {
  // BCM D-FLASH: 64KB file, VINs stored at fixed offsets with prefix markers
  // Format: [Prefix: 2 bytes "FF"/"FV"/"FW"/"FR"] [VIN: 17 bytes] [Suffix: 2 bytes "-V"]
  // The offset points to the PREFIX, VIN starts at offset+2
  bcm_dflash: [0x1328, 0x1348, 0x1368, 0x1388],
  // Legacy BCM offsets for unknown formats
  bcm: [0x0400, 0x0411, 0x0422, 0x0433],
  // RFHUB: Uses reversed VINs with complement checksum (handled separately)
  rfhub: [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1],
  ecm: [0x0400],
  tcm: [0x0400],
  skim: [0x0400],
};

export const MODULE_DATABASE: ModuleDefinition[] = [
  {
    code: "BCM",
    name: "Body Control Module",
    tx: 0x6B0,
    rx: 0x6B8,
    verified: true,
    source: "dealership diagnostic system",
    description: "Central body electronics control - lighting, locks, windows, security",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "ECM",
    name: "Engine Control Module",
    tx: 0x7E0,
    rx: 0x7E8,
    verified: true,
    source: "dealership diagnostic system/OBD-II",
    description: "Engine management - fuel injection, ignition, emissions",
    protectionLevel: 'software',
    bus: 'CAN-C',
  },
  {
    code: "TCM",
    name: "Transmission Control Module",
    tx: 0x7E1,
    rx: 0x7E9,
    verified: true,
    source: "dealership diagnostic system",
    description: "Transmission control - shift points, torque converter",
    protectionLevel: 'software',
    bus: 'CAN-C',
  },
  {
    code: "RFHUB",
    name: "RF Hub / SKIM",
    tx: 0x742,
    rx: 0x762,
    verified: true,
    source: "dealership diagnostic system",
    description: "Key fob receiver and immobilizer - wireless entry, remote start. MCU: Infineon XC2268N-40F80LR (P68245482AD)",
    protectionLevel: 'otp',
    bus: 'CAN-IHS',
    otpInfo: {
      memoryType: 'otp',
      riskLevel: 'danger',
      otpRegions: 'VIN storage, key learning data, immobilizer secrets',
      chipType: '93C66/93C86 EEPROM or eFUSE array',
      requiresBackup: true,
      warningMessage: 'RFHUB VIN is stored in ONE-TIME PROGRAMMABLE memory. Writing an incorrect VIN will permanently brick this module. A replacement RFHUB costs $200-500 and requires dealer programming.',
      canReprogram: false,
    },
  },
  {
    code: "ABS",
    name: "Anti-lock Brake System",
    tx: 0x760,
    rx: 0x768,
    verified: true,
    source: "dealership diagnostic system",
    description: "Brake control - ABS, traction control, stability control",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "CCM",
    name: "Climate Control Module",
    tx: 0x743,
    rx: 0x763,
    verified: true,
    source: "dealership diagnostic system",
    description: "HVAC control - air conditioning, heating, ventilation",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "ADM",
    name: "Active Dampening Module",
    tx: 0x744,
    rx: 0x764,
    verified: true,
    source: "dealership diagnostic system",
    description: "Active suspension control - adaptive dampening",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "SDM",
    name: "Suspension Dampening Module",
    tx: 0x745,
    rx: 0x765,
    verified: true,
    source: "dealership diagnostic system",
    description: "Suspension control - air suspension, ride height",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "IPCM",
    name: "Instrument Panel Cluster Module",
    tx: 0x746,
    rx: 0x766,
    verified: false,
    source: "CAN Scan",
    description: "Gauges and displays - speedometer, tachometer, warning lights",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "ORC",
    name: "Occupant Restraint Controller",
    tx: 0x747,
    rx: 0x767,
    verified: false,
    source: "CAN Scan",
    description: "Airbag system - deployment control, crash sensors",
    protectionLevel: 'otp',
    bus: 'CAN-IHS',
    otpInfo: {
      memoryType: 'otp',
      riskLevel: 'danger',
      otpRegions: 'VIN storage, crash event data, deployment history',
      chipType: 'Internal eFUSE / OTP Flash',
      requiresBackup: true,
      warningMessage: 'ORC (Airbag) module uses ONE-TIME PROGRAMMABLE memory for VIN and crash data. Incorrect writes will permanently disable the airbag system. This is a SAFETY-CRITICAL module - replacement costs $500-1500.',
      canReprogram: false,
    },
  },
  {
    code: "DDM",
    name: "Driver Door Module",
    tx: 0x748,
    rx: 0x768,
    verified: false,
    source: "CAN Scan",
    description: "Driver door functions - locks, windows, mirrors",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "PDM",
    name: "Passenger Door Module",
    tx: 0x749,
    rx: 0x769,
    verified: false,
    source: "CAN Scan",
    description: "Passenger door functions - locks, windows, mirrors",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "EPS",
    name: "Electric Power Steering",
    tx: 0x74A,
    rx: 0x76A,
    verified: false,
    source: "CAN Scan",
    description: "Power steering control - assist level, returnability",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "SCCM",
    name: "Steering Column Control Module",
    tx: 0x74B,
    rx: 0x76B,
    verified: false,
    source: "CAN Scan",
    description: "Steering column functions - tilt, telescope, lock",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "PAM",
    name: "Park Assist Module",
    tx: 0x74C,
    rx: 0x76C,
    verified: false,
    source: "CAN Scan",
    description: "Parking sensors - ultrasonic detection, alerts",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "TCCM",
    name: "Transfer Case Control Module",
    tx: 0x74D,
    rx: 0x76D,
    verified: false,
    source: "CAN Scan",
    description: "4WD/AWD control - transfer case, differential locks",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "TPMS",
    name: "Tire Pressure Monitoring System",
    tx: 0x74E,
    rx: 0x76E,
    verified: false,
    source: "CAN Scan",
    description: "Tire pressure monitoring - sensors, alerts",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "SGW",
    name: "Security Gateway Module",
    tx: 0x74F,
    rx: 0x76F,
    verified: false,
    source: "CAN Scan",
    description: "CAN gateway security - module authentication, firewall",
    protectionLevel: 'otp',
    bus: 'CAN-IHS',
    otpInfo: {
      memoryType: 'otp',
      riskLevel: 'danger',
      otpRegions: 'VIN storage, security certificates, CAN firewall rules',
      chipType: 'Secure Element with eFUSE',
      requiresBackup: true,
      warningMessage: 'SGW (Security Gateway) protects all vehicle CAN networks. Its VIN and security data are stored in ONE-TIME PROGRAMMABLE memory. Corrupting this module will disable ALL diagnostic access to the vehicle. Replacement requires dealer-only programming.',
      canReprogram: false,
    },
  },
  {
    code: "ACC",
    name: "Adaptive Cruise Control",
    tx: 0x750,
    rx: 0x770,
    verified: false,
    source: "CAN Scan",
    description: "Cruise control - adaptive speed, distance keeping",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "ESM",
    name: "Electronic Shifter Module",
    tx: 0x751,
    rx: 0x771,
    verified: false,
    source: "CAN Scan",
    description: "Electronic shifter - gear selection, park lock",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "EPB",
    name: "Electronic Parking Brake",
    tx: 0x752,
    rx: 0x772,
    verified: false,
    source: "CAN Scan",
    description: "Electronic parking brake - apply, release, hill hold",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "RADIO",
    name: "Radio / Infotainment",
    tx: 0x753,
    rx: 0x773,
    verified: false,
    source: "CAN Scan",
    description: "Audio system - radio, navigation, connectivity",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "FDCM",
    name: "Front Distance Control Module",
    tx: 0x754,
    rx: 0x774,
    verified: false,
    source: "CAN Scan",
    description: "Forward radar/camera - collision warning, auto braking",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "LBSS",
    name: "Left Blind Spot Sensor",
    tx: 0x755,
    rx: 0x775,
    verified: false,
    source: "CAN Scan",
    description: "Left side radar - blind spot detection, lane change assist",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "RBSS",
    name: "Right Blind Spot Sensor",
    tx: 0x756,
    rx: 0x776,
    verified: false,
    source: "CAN Scan",
    description: "Right side radar - blind spot detection, lane change assist",
    bus: 'CAN-IHS',
    protectionLevel: 'software',
  },
  {
    code: "LGM",
    name: "Liftgate Module",
    tx: 0x757,
    rx: 0x777,
    verified: false,
    source: "CAN Scan",
    description: "Power liftgate - open, close, height memory",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "HLM",
    name: "Headlamp Leveling Module",
    tx: 0x758,
    rx: 0x778,
    verified: false,
    source: "CAN Scan",
    description: "Automatic headlight aim - load leveling, cornering",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "HSM",
    name: "Heated Seat Module",
    tx: 0x759,
    rx: 0x779,
    verified: false,
    source: "CAN Scan",
    description: "Seat heating and cooling - temperature control, memory",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "FCM",
    name: "Front Camera Module",
    tx: 0x75A,
    rx: 0x77A,
    verified: false,
    source: "CAN Scan",
    description: "ADAS forward camera - lane keeping, traffic sign recognition",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
  {
    code: "RCM",
    name: "Rear Camera Module",
    tx: 0x75B,
    rx: 0x77B,
    verified: false,
    source: "CAN Scan",
    description: "Backup camera - reverse image, parking guidelines",
    protectionLevel: 'software',
    bus: 'CAN-IHS',
  },
];

const CUSTOM_MODULES_KEY = 'darkvin_custom_modules';

export function getCustomModules(): CustomModule[] {
  try {
    const stored = localStorage.getItem(CUSTOM_MODULES_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export function saveCustomModule(module: CustomModule): void {
  const modules = getCustomModules();
  const existingIndex = modules.findIndex(m => m.code === module.code);
  if (existingIndex >= 0) {
    modules[existingIndex] = module;
  } else {
    modules.push(module);
  }
  localStorage.setItem(CUSTOM_MODULES_KEY, JSON.stringify(modules));
}

export function deleteCustomModule(code: string): void {
  const modules = getCustomModules().filter(m => m.code !== code);
  localStorage.setItem(CUSTOM_MODULES_KEY, JSON.stringify(modules));
}

export function getAllModules(): (ModuleDefinition | CustomModule)[] {
  const customModules = getCustomModules();
  const customCodes = new Set(customModules.map(m => m.code));
  const filteredDatabase = MODULE_DATABASE.filter(m => !customCodes.has(m.code));
  return [...filteredDatabase, ...customModules];
}

export function getModuleByCode(code: string): ModuleDefinition | CustomModule | undefined {
  const customModules = getCustomModules();
  const custom = customModules.find(m => m.code === code);
  if (custom) return custom;
  return MODULE_DATABASE.find(m => m.code === code);
}

export function parseHexAddress(hex: string): number {
  const cleaned = hex.replace(/^0x/i, '').trim();
  return parseInt(cleaned, 16) || 0;
}

export function formatHexAddress(num: number): string {
  return '0x' + num.toString(16).toUpperCase().padStart(3, '0');
}

export function isOTPProtected(module: ModuleDefinition | CustomModule): boolean {
  if ('protectionLevel' in module) {
    return module.protectionLevel === 'otp';
  }
  const dbModule = MODULE_DATABASE.find(m => m.code === module.code);
  return dbModule?.protectionLevel === 'otp';
}

export function getOTPInfo(moduleCode: string): OTPInfo | undefined {
  const module = MODULE_DATABASE.find(m => m.code === moduleCode);
  return module?.otpInfo;
}

export function getRiskLevel(moduleCode: string): RiskLevel {
  const module = MODULE_DATABASE.find(m => m.code === moduleCode);
  if (module?.otpInfo) {
    return module.otpInfo.riskLevel;
  }
  if (module?.protectionLevel === 'otp') {
    return 'danger';
  }
  return 'safe';
}

export function getOTPModules(): ModuleDefinition[] {
  return MODULE_DATABASE.filter(m => m.protectionLevel === 'otp');
}

export function getSafeModules(): ModuleDefinition[] {
  return MODULE_DATABASE.filter(m => m.protectionLevel !== 'otp');
}

export function getVinOffsetsForModule(moduleCode: string): number[] {
  const key = moduleCode.toLowerCase();
  return DODGE_VIN_OFFSETS[key] || DODGE_VIN_OFFSETS['bcm'];
}
