export interface BackupData {
  vin?: string;
  moduleCode: string;
  moduleName: string;
  txId: number;
  rxId: number;
  operationType: string;
  did?: number;
  originalData: string;
  originalDataLength: number;
  newData?: string;
  notes?: string;
}

export interface AuditLogData {
  vin?: string;
  moduleCode?: string;
  moduleName?: string;
  txId?: number;
  rxId?: number;
  operation: string;
  details?: string;
  requestData?: string;
  responseData?: string;
  success: boolean;
  errorCode?: number;
  algorithm?: string;
  hardwareType?: string;
}

export async function createBackup(data: BackupData): Promise<void> {
  try {
    await fetch('/api/backups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  } catch (error) {
    console.error('Failed to create backup:', error);
  }
}

export async function createAuditLog(data: AuditLogData): Promise<void> {
  try {
    await fetch('/api/audit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  } catch (error) {
    console.error('Failed to create audit log:', error);
  }
}

export function bytesToHex(bytes: Uint8Array | number[]): string {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0').toUpperCase())
    .join('');
}

export interface VehicleProfile {
  id: string;
  vin: string;
  year?: number;
  make?: string;
  model?: string;
  nickname?: string;
  discoveredModules?: DiscoveredModuleInfo[];
  workingAlgorithms?: Record<string, string>;
  notes?: string;
  lastConnected?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DiscoveredModuleInfo {
  code: string;
  name: string;
  txId: number;
  rxId: number;
  vin?: string;
}

export interface CreateVehicleProfileData {
  vin: string;
  year?: number;
  make?: string;
  model?: string;
  nickname?: string;
  discoveredModules?: DiscoveredModuleInfo[];
  workingAlgorithms?: Record<string, string>;
  notes?: string;
}

export async function listVehicleProfiles(): Promise<VehicleProfile[]> {
  try {
    const response = await fetch('/api/vehicles');
    if (!response.ok) throw new Error('Failed to fetch vehicle profiles');
    return response.json();
  } catch (error) {
    console.error('Failed to list vehicle profiles:', error);
    return [];
  }
}

export async function getVehicleProfile(id: string): Promise<VehicleProfile | null> {
  try {
    const response = await fetch(`/api/vehicles/${id}`);
    if (!response.ok) return null;
    return response.json();
  } catch (error) {
    console.error('Failed to get vehicle profile:', error);
    return null;
  }
}

export async function getVehicleProfileByVin(vin: string): Promise<VehicleProfile | null> {
  try {
    const response = await fetch(`/api/vehicles/vin/${encodeURIComponent(vin)}`);
    if (!response.ok) return null;
    return response.json();
  } catch (error) {
    console.error('Failed to get vehicle profile by VIN:', error);
    return null;
  }
}

export async function createVehicleProfile(data: CreateVehicleProfileData): Promise<VehicleProfile | null> {
  try {
    const response = await fetch('/api/vehicles', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to create vehicle profile');
    return response.json();
  } catch (error) {
    console.error('Failed to create vehicle profile:', error);
    return null;
  }
}

export async function updateVehicleProfile(id: string, data: Partial<CreateVehicleProfileData>): Promise<VehicleProfile | null> {
  try {
    const response = await fetch(`/api/vehicles/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update vehicle profile');
    return response.json();
  } catch (error) {
    console.error('Failed to update vehicle profile:', error);
    return null;
  }
}

export async function deleteVehicleProfile(id: string): Promise<boolean> {
  try {
    const response = await fetch(`/api/vehicles/${id}`, {
      method: 'DELETE',
    });
    return response.ok;
  } catch (error) {
    console.error('Failed to delete vehicle profile:', error);
    return false;
  }
}

export async function saveOrUpdateVehicleProfile(
  vin: string, 
  discoveredModules: DiscoveredModuleInfo[],
  workingAlgorithms: Record<string, string>,
  additionalData?: { year?: number; make?: string; model?: string; nickname?: string; notes?: string }
): Promise<VehicleProfile | null> {
  try {
    const existing = await getVehicleProfileByVin(vin);
    
    if (existing) {
      const mergedAlgorithms = { ...existing.workingAlgorithms, ...workingAlgorithms };
      const mergedModules = discoveredModules.length > 0 ? discoveredModules : (existing.discoveredModules || []);
      
      return await updateVehicleProfile(existing.id, {
        discoveredModules: mergedModules,
        workingAlgorithms: mergedAlgorithms,
        ...additionalData,
      });
    } else {
      return await createVehicleProfile({
        vin,
        discoveredModules,
        workingAlgorithms,
        ...additionalData,
      });
    }
  } catch (error) {
    console.error('Failed to save/update vehicle profile:', error);
    
    const existing = await getVehicleProfileByVin(vin);
    if (existing) {
      const mergedAlgorithms = { ...existing.workingAlgorithms, ...workingAlgorithms };
      return await updateVehicleProfile(existing.id, {
        discoveredModules: discoveredModules.length > 0 ? discoveredModules : existing.discoveredModules,
        workingAlgorithms: mergedAlgorithms,
        ...additionalData,
      });
    }
    return null;
  }
}
