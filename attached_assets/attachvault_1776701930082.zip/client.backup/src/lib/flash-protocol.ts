export const UDS_FLASH_SERVICES = {
  DIAGNOSTIC_SESSION: 0x10,
  ECU_RESET: 0x11,
  SECURITY_ACCESS: 0x27,
  COMMUNICATION_CONTROL: 0x28,
  CONTROL_DTC_SETTING: 0x85,
  REQUEST_DOWNLOAD: 0x34,
  REQUEST_UPLOAD: 0x35,
  TRANSFER_DATA: 0x36,
  TRANSFER_EXIT: 0x37,
  ROUTINE_CONTROL: 0x31,
  WRITE_DATA_BY_ID: 0x2E,
  READ_MEMORY_BY_ADDRESS: 0x23,
  WRITE_MEMORY_BY_ADDRESS: 0x3D,
};

export const SESSION_TYPES = {
  DEFAULT: 0x01,
  PROGRAMMING: 0x02,
  EXTENDED: 0x03,
  SAFETY_SYSTEM: 0x04,
  EOL_DIAGNOSTIC: 0x40,
};

export const RESET_TYPES = {
  HARD_RESET: 0x01,
  KEY_OFF_ON: 0x02,
  SOFT_RESET: 0x03,
};

export const ROUTINE_SUB = {
  START: 0x01,
  STOP: 0x02,
  REQUEST_RESULTS: 0x03,
};

export const FCA_FLASH_ROUTINES = {
  ERASE_MEMORY: 0xFF00,
  CHECK_PROGRAMMING_DEPENDENCIES: 0xFF01,
  CHECK_PROGRAMMING_PRECONDITIONS: 0x0203,
  CHECK_VALID_APPLICATION: 0x0202,
  CHECK_MEMORY: 0x0201,
  ACTIVATE_APPLICATION: 0x0301,
};

export const MEMORY_ADDRESS_LENGTHS = {
  BCM: { addressLength: 4, sizeLength: 4 },
  ECM: { addressLength: 4, sizeLength: 4 },
  TCM: { addressLength: 4, sizeLength: 4 },
  PCM: { addressLength: 4, sizeLength: 4 },
};

export interface FlashProgress {
  phase: 'idle' | 'init' | 'security' | 'erase' | 'download' | 'transfer' | 'exit' | 'verify' | 'reset' | 'complete' | 'error';
  progress: number;
  message: string;
  bytesTransferred?: number;
  totalBytes?: number;
  currentBlock?: number;
  totalBlocks?: number;
  errorCode?: number;
  errorMessage?: string;
}

export interface MemoryRegion {
  name: string;
  startAddress: number;
  endAddress: number;
  size: number;
  dataFormat: number;
}

export interface FlashConfiguration {
  txId: number;
  rxId: number;
  moduleCode: string;
  moduleName: string;
  memoryRegions: MemoryRegion[];
  maxBlockSize: number;
  addressLength: number;
  sizeLength: number;
  dataFormat: number;
}

const BCM_FLASH_CONFIG: FlashConfiguration = {
  txId: 0x720,
  rxId: 0x728,
  moduleCode: 'BCM',
  moduleName: 'Body Control Module',
  memoryRegions: [
    { name: 'Bootloader', startAddress: 0x00000000, endAddress: 0x00003FFF, size: 16384, dataFormat: 0x00 },
    { name: 'Application', startAddress: 0x00004000, endAddress: 0x0001FFFF, size: 114688, dataFormat: 0x00 },
    { name: 'Calibration', startAddress: 0x00020000, endAddress: 0x00027FFF, size: 32768, dataFormat: 0x00 },
    { name: 'EEPROM', startAddress: 0x00100000, endAddress: 0x00100FFF, size: 4096, dataFormat: 0x00 },
  ],
  maxBlockSize: 4080,
  addressLength: 4,
  sizeLength: 4,
  dataFormat: 0x00,
};

const ECM_FLASH_CONFIG: FlashConfiguration = {
  txId: 0x7E0,
  rxId: 0x7E8,
  moduleCode: 'ECM',
  moduleName: 'Engine Control Module',
  memoryRegions: [
    { name: 'Bootloader', startAddress: 0x00000000, endAddress: 0x0000FFFF, size: 65536, dataFormat: 0x00 },
    { name: 'Application', startAddress: 0x00010000, endAddress: 0x0007FFFF, size: 458752, dataFormat: 0x00 },
    { name: 'Calibration', startAddress: 0x00080000, endAddress: 0x000FFFFF, size: 524288, dataFormat: 0x00 },
  ],
  maxBlockSize: 4080,
  addressLength: 4,
  sizeLength: 4,
  dataFormat: 0x00,
};

const TCM_FLASH_CONFIG: FlashConfiguration = {
  txId: 0x7E2,
  rxId: 0x7EA,
  moduleCode: 'TCM',
  moduleName: 'Transmission Control Module',
  memoryRegions: [
    { name: 'Application', startAddress: 0x00000000, endAddress: 0x0003FFFF, size: 262144, dataFormat: 0x00 },
    { name: 'Calibration', startAddress: 0x00040000, endAddress: 0x0007FFFF, size: 262144, dataFormat: 0x00 },
  ],
  maxBlockSize: 4080,
  addressLength: 4,
  sizeLength: 4,
  dataFormat: 0x00,
};

export const FLASH_CONFIGS: Record<string, FlashConfiguration> = {
  BCM: BCM_FLASH_CONFIG,
  ECM: ECM_FLASH_CONFIG,
  TCM: TCM_FLASH_CONFIG,
};

export function buildRequestDownload(
  address: number,
  size: number,
  dataFormat: number = 0x00,
  addressLength: number = 4,
  sizeLength: number = 4
): Uint8Array {
  const addressAndLengthFormat = (sizeLength << 4) | addressLength;
  const request = new Uint8Array(3 + addressLength + sizeLength);
  request[0] = UDS_FLASH_SERVICES.REQUEST_DOWNLOAD;
  request[1] = dataFormat;
  request[2] = addressAndLengthFormat;
  
  for (let i = 0; i < addressLength; i++) {
    request[3 + i] = (address >> (8 * (addressLength - 1 - i))) & 0xFF;
  }
  
  for (let i = 0; i < sizeLength; i++) {
    request[3 + addressLength + i] = (size >> (8 * (sizeLength - 1 - i))) & 0xFF;
  }
  
  return request;
}

export function buildTransferData(blockSequence: number, data: Uint8Array): Uint8Array {
  const request = new Uint8Array(2 + data.length);
  request[0] = UDS_FLASH_SERVICES.TRANSFER_DATA;
  request[1] = blockSequence & 0xFF;
  request.set(data, 2);
  return request;
}

export function buildTransferExit(): Uint8Array {
  return new Uint8Array([UDS_FLASH_SERVICES.TRANSFER_EXIT]);
}

export function buildEraseMemory(
  startAddress: number,
  size: number,
  addressLength: number = 4,
  sizeLength: number = 4
): Uint8Array {
  const routineId = FCA_FLASH_ROUTINES.ERASE_MEMORY;
  const addressAndLengthFormat = (sizeLength << 4) | addressLength;
  const request = new Uint8Array(5 + addressLength + sizeLength);
  
  request[0] = UDS_FLASH_SERVICES.ROUTINE_CONTROL;
  request[1] = ROUTINE_SUB.START;
  request[2] = (routineId >> 8) & 0xFF;
  request[3] = routineId & 0xFF;
  request[4] = addressAndLengthFormat;
  
  for (let i = 0; i < addressLength; i++) {
    request[5 + i] = (startAddress >> (8 * (addressLength - 1 - i))) & 0xFF;
  }
  
  for (let i = 0; i < sizeLength; i++) {
    request[5 + addressLength + i] = (size >> (8 * (sizeLength - 1 - i))) & 0xFF;
  }
  
  return request;
}

export function buildCheckProgrammingDependencies(): Uint8Array {
  const routineId = FCA_FLASH_ROUTINES.CHECK_PROGRAMMING_DEPENDENCIES;
  return new Uint8Array([
    UDS_FLASH_SERVICES.ROUTINE_CONTROL,
    ROUTINE_SUB.START,
    (routineId >> 8) & 0xFF,
    routineId & 0xFF,
  ]);
}

export function buildCheckValidApplication(): Uint8Array {
  const routineId = FCA_FLASH_ROUTINES.CHECK_VALID_APPLICATION;
  return new Uint8Array([
    UDS_FLASH_SERVICES.ROUTINE_CONTROL,
    ROUTINE_SUB.START,
    (routineId >> 8) & 0xFF,
    routineId & 0xFF,
  ]);
}

export function parseRequestDownloadResponse(response: Uint8Array): { maxBlockLength: number } | null {
  if (response[0] !== 0x74) return null;
  
  const lengthFormatId = response[1];
  const numBytes = lengthFormatId >> 4;
  
  let maxBlockLength = 0;
  for (let i = 0; i < numBytes; i++) {
    maxBlockLength = (maxBlockLength << 8) | response[2 + i];
  }
  
  return { maxBlockLength };
}

export function parseEraseMemoryResponse(response: Uint8Array): { success: boolean; statusCode?: number } {
  if (response[0] === 0x71) {
    if (response[1] === ROUTINE_SUB.START) {
      const routineId = (response[2] << 8) | response[3];
      if (routineId === FCA_FLASH_ROUTINES.ERASE_MEMORY) {
        return { success: true, statusCode: response[4] };
      }
    }
  }
  return { success: false };
}

export function calculateFlashChecksum(data: Uint8Array): number {
  let sum = 0;
  for (let i = 0; i < data.length; i += 2) {
    const word = (data[i] << 8) | (data[i + 1] || 0);
    sum = (sum + word) & 0xFFFFFFFF;
  }
  return sum;
}

export function verifyFlashData(original: Uint8Array, programmed: Uint8Array): { match: boolean; differences: number[] } {
  const differences: number[] = [];
  const minLength = Math.min(original.length, programmed.length);
  
  for (let i = 0; i < minLength; i++) {
    if (original[i] !== programmed[i]) {
      differences.push(i);
    }
  }
  
  return {
    match: differences.length === 0 && original.length === programmed.length,
    differences,
  };
}

export const SECURITY_LEVELS = {
  DEFAULT_SEED: 0x01,
  DEFAULT_KEY: 0x02,
  PROGRAMMING_SEED: 0x11,
  PROGRAMMING_KEY: 0x12,
  EXTENDED_SEED: 0x03,
  EXTENDED_KEY: 0x04,
  BOOTLOADER_SEED: 0x05,
  BOOTLOADER_KEY: 0x06,
};

export class FlashProgrammer {
  private protocol: any;
  private config: FlashConfiguration;
  private onProgress: (progress: FlashProgress) => void;
  private aborted: boolean = false;
  private securitySeedLevel: number;
  private securityKeyLevel: number;
  private responsePendingMaxRetries: number = 50;
  private responsePendingDelayMs: number = 100;
  
  constructor(
    protocol: any,
    config: FlashConfiguration,
    onProgress: (progress: FlashProgress) => void,
    options?: {
      securitySeedLevel?: number;
      securityKeyLevel?: number;
    }
  ) {
    this.protocol = protocol;
    this.config = config;
    this.onProgress = onProgress;
    this.securitySeedLevel = options?.securitySeedLevel ?? SECURITY_LEVELS.PROGRAMMING_SEED;
    this.securityKeyLevel = options?.securityKeyLevel ?? SECURITY_LEVELS.PROGRAMMING_KEY;
  }
  
  abort(): void {
    this.aborted = true;
  }
  
  private async sendUDSWithPending(request: Uint8Array): Promise<Uint8Array | null> {
    let response = await this.protocol.sendUDS(this.config.txId, this.config.rxId, Array.from(request));
    
    let retries = 0;
    while (response && response[0] === 0x7F && response[2] === 0x78 && retries < this.responsePendingMaxRetries) {
      await this.delay(this.responsePendingDelayMs);
      response = await this.protocol.receiveUDS(this.config.rxId);
      retries++;
    }
    
    return response;
  }
  
  private async sendUDS(request: Uint8Array): Promise<Uint8Array | null> {
    return this.sendUDSWithPending(request);
  }
  
  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  private updateProgress(phase: FlashProgress['phase'], progress: number, message: string, extra?: Partial<FlashProgress>) {
    this.onProgress({ phase, progress, message, ...extra });
  }
  
  private async handleSecurityLockout(nrc: number): Promise<boolean> {
    if (nrc === 0x36) {
      this.updateProgress('security', 20, 'Exceeded number of security attempts');
      return false;
    }
    if (nrc === 0x37) {
      this.updateProgress('security', 20, 'Security lockout - waiting 10 seconds...');
      await this.delay(10000);
      return true;
    }
    return false;
  }
  
  async enterProgrammingSession(): Promise<boolean> {
    this.updateProgress('init', 5, 'Entering programming session...');
    
    const request = new Uint8Array([
      UDS_FLASH_SERVICES.DIAGNOSTIC_SESSION,
      SESSION_TYPES.PROGRAMMING,
    ]);
    
    const response = await this.sendUDS(request);
    if (!response) return false;
    
    if (response[0] === 0x50 && response[1] === SESSION_TYPES.PROGRAMMING) {
      this.updateProgress('init', 10, 'Programming session active');
      return true;
    }
    
    if (response[0] === 0x7F) {
      this.updateProgress('error', 0, `Session error: NRC 0x${response[2].toString(16)}`, {
        errorCode: response[2],
        errorMessage: this.getNRCDescription(response[2]),
      });
    }
    
    return false;
  }
  
  async disableDTCRecording(): Promise<boolean> {
    this.updateProgress('init', 12, 'Disabling DTC recording...');
    
    const request = new Uint8Array([
      UDS_FLASH_SERVICES.CONTROL_DTC_SETTING,
      0x02,
    ]);
    
    const response = await this.sendUDS(request);
    return response !== null && response[0] === 0xC5;
  }
  
  async disableCommunication(): Promise<boolean> {
    this.updateProgress('init', 15, 'Disabling normal communication...');
    
    const request = new Uint8Array([
      UDS_FLASH_SERVICES.COMMUNICATION_CONTROL,
      0x03,
      0x03,
    ]);
    
    const response = await this.sendUDS(request);
    return response !== null && response[0] === 0x68;
  }
  
  async performSecurityAccess(keyGenerator: (seed: Uint8Array, level: number) => Uint8Array): Promise<boolean> {
    this.updateProgress('security', 20, 'Requesting security access...');
    
    const seedRequest = new Uint8Array([
      UDS_FLASH_SERVICES.SECURITY_ACCESS,
      0x11,
    ]);
    
    const seedResponse = await this.sendUDS(seedRequest);
    if (!seedResponse || seedResponse[0] !== 0x67) {
      this.updateProgress('error', 0, 'Failed to get security seed');
      return false;
    }
    
    const seed = seedResponse.slice(2);
    this.updateProgress('security', 25, `Seed received: ${Array.from(seed).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
    
    const key = keyGenerator(seed, 0x11);
    this.updateProgress('security', 30, 'Sending security key...');
    
    const keyRequest = new Uint8Array(2 + key.length);
    keyRequest[0] = UDS_FLASH_SERVICES.SECURITY_ACCESS;
    keyRequest[1] = 0x12;
    keyRequest.set(key, 2);
    
    const keyResponse = await this.sendUDS(keyRequest);
    if (!keyResponse || keyResponse[0] !== 0x67 || keyResponse[1] !== 0x12) {
      if (keyResponse && keyResponse[0] === 0x7F) {
        const nrc = keyResponse[2];
        this.updateProgress('error', 0, `Security access denied: ${this.getNRCDescription(nrc)}`, {
          errorCode: nrc,
        });
      }
      return false;
    }
    
    this.updateProgress('security', 35, 'Security access granted');
    return true;
  }
  
  async eraseMemory(startAddress: number, size: number): Promise<boolean> {
    this.updateProgress('erase', 40, `Erasing memory: 0x${startAddress.toString(16)} - 0x${(startAddress + size).toString(16)}...`);
    
    const request = buildEraseMemory(startAddress, size);
    const response = await this.sendUDS(request);
    
    if (!response) {
      this.updateProgress('error', 0, 'No response to erase command');
      return false;
    }
    
    const result = parseEraseMemoryResponse(response);
    if (result.success) {
      this.updateProgress('erase', 45, 'Memory erased successfully');
      return true;
    }
    
    if (response[0] === 0x7F) {
      this.updateProgress('error', 0, `Erase failed: ${this.getNRCDescription(response[2])}`, {
        errorCode: response[2],
      });
    }
    
    return false;
  }
  
  async requestDownload(startAddress: number, size: number): Promise<number> {
    this.updateProgress('download', 50, `Requesting download: ${size} bytes at 0x${startAddress.toString(16)}...`);
    
    const request = buildRequestDownload(
      startAddress,
      size,
      this.config.dataFormat,
      this.config.addressLength,
      this.config.sizeLength
    );
    
    const response = await this.sendUDS(request);
    if (!response) {
      this.updateProgress('error', 0, 'No response to download request');
      return 0;
    }
    
    const result = parseRequestDownloadResponse(response);
    if (result) {
      this.updateProgress('download', 55, `Max block size: ${result.maxBlockLength} bytes`);
      return result.maxBlockLength;
    }
    
    if (response[0] === 0x7F) {
      this.updateProgress('error', 0, `Download request failed: ${this.getNRCDescription(response[2])}`, {
        errorCode: response[2],
      });
    }
    
    return 0;
  }
  
  async transferData(data: Uint8Array, maxBlockSize: number): Promise<boolean> {
    const effectiveBlockSize = Math.min(maxBlockSize - 2, this.config.maxBlockSize);
    const totalBlocks = Math.ceil(data.length / effectiveBlockSize);
    let bytesTransferred = 0;
    let blockSequence = 1;
    
    this.updateProgress('transfer', 60, `Transferring ${data.length} bytes in ${totalBlocks} blocks...`, {
      bytesTransferred: 0,
      totalBytes: data.length,
      currentBlock: 0,
      totalBlocks,
    });
    
    for (let offset = 0; offset < data.length && !this.aborted; offset += effectiveBlockSize) {
      const blockData = data.slice(offset, Math.min(offset + effectiveBlockSize, data.length));
      const request = buildTransferData(blockSequence, blockData);
      
      const response = await this.sendUDS(request);
      if (!response || response[0] !== 0x76) {
        if (response && response[0] === 0x7F) {
          this.updateProgress('error', 0, `Transfer failed at block ${blockSequence}: ${this.getNRCDescription(response[2])}`, {
            errorCode: response[2],
          });
        } else {
          this.updateProgress('error', 0, `Transfer failed at block ${blockSequence}: No response`);
        }
        return false;
      }
      
      bytesTransferred += blockData.length;
      const progress = 60 + Math.floor((bytesTransferred / data.length) * 25);
      
      this.updateProgress('transfer', progress, `Block ${blockSequence}/${totalBlocks} transferred`, {
        bytesTransferred,
        totalBytes: data.length,
        currentBlock: blockSequence,
        totalBlocks,
      });
      
      blockSequence = (blockSequence + 1) & 0xFF;
      if (blockSequence === 0) blockSequence = 1;
    }
    
    if (this.aborted) {
      this.updateProgress('error', 0, 'Transfer aborted by user');
      return false;
    }
    
    return true;
  }
  
  async exitTransfer(): Promise<boolean> {
    this.updateProgress('exit', 90, 'Exiting transfer mode...');
    
    const request = buildTransferExit();
    const response = await this.sendUDS(request);
    
    if (!response || response[0] !== 0x77) {
      if (response && response[0] === 0x7F) {
        this.updateProgress('error', 0, `Transfer exit failed: ${this.getNRCDescription(response[2])}`);
      }
      return false;
    }
    
    this.updateProgress('exit', 92, 'Transfer complete');
    return true;
  }
  
  async checkProgrammingDependencies(): Promise<boolean> {
    this.updateProgress('verify', 94, 'Checking programming dependencies...');
    
    const request = buildCheckProgrammingDependencies();
    const response = await this.sendUDS(request);
    
    return response !== null && response[0] === 0x71;
  }
  
  async checkValidApplication(): Promise<boolean> {
    this.updateProgress('verify', 96, 'Verifying application...');
    
    const request = buildCheckValidApplication();
    const response = await this.sendUDS(request);
    
    return response !== null && response[0] === 0x71;
  }
  
  async performECUReset(): Promise<boolean> {
    this.updateProgress('reset', 98, 'Resetting ECU...');
    
    const request = new Uint8Array([
      UDS_FLASH_SERVICES.ECU_RESET,
      RESET_TYPES.HARD_RESET,
    ]);
    
    const response = await this.sendUDS(request);
    
    if (response && response[0] === 0x51) {
      this.updateProgress('complete', 100, 'Flash programming complete');
      return true;
    }
    
    this.updateProgress('complete', 100, 'Reset sent (no confirmation expected)');
    return true;
  }
  
  async flashMemory(
    data: Uint8Array,
    startAddress: number,
    keyGenerator: (seed: Uint8Array, level: number) => Uint8Array
  ): Promise<boolean> {
    this.aborted = false;
    
    if (!await this.enterProgrammingSession()) {
      return false;
    }
    
    await this.disableDTCRecording();
    
    await this.disableCommunication();
    
    if (!await this.performSecurityAccess(keyGenerator)) {
      return false;
    }
    
    if (!await this.eraseMemory(startAddress, data.length)) {
      return false;
    }
    
    const maxBlockSize = await this.requestDownload(startAddress, data.length);
    if (maxBlockSize === 0) {
      return false;
    }
    
    if (!await this.transferData(data, maxBlockSize)) {
      return false;
    }
    
    if (!await this.exitTransfer()) {
      return false;
    }
    
    await this.checkProgrammingDependencies();
    await this.checkValidApplication();
    
    await this.performECUReset();
    
    return true;
  }
  
  private getNRCDescription(nrc: number): string {
    const descriptions: Record<number, string> = {
      0x10: 'General Reject',
      0x11: 'Service Not Supported',
      0x12: 'Sub-Function Not Supported',
      0x13: 'Incorrect Message Length',
      0x14: 'Response Too Long',
      0x21: 'Busy Repeat Request',
      0x22: 'Conditions Not Correct',
      0x24: 'Request Sequence Error',
      0x25: 'No Response From Subnet',
      0x26: 'Failure Prevents Execution',
      0x31: 'Request Out Of Range',
      0x33: 'Security Access Denied',
      0x35: 'Invalid Key',
      0x36: 'Exceeded Number Of Attempts',
      0x37: 'Required Time Delay Not Expired',
      0x70: 'Upload/Download Not Accepted',
      0x71: 'Transfer Data Suspended',
      0x72: 'General Programming Failure',
      0x73: 'Wrong Block Sequence Counter',
      0x78: 'Request Correctly Received - Response Pending',
      0x7E: 'Sub-Function Not Supported In Active Session',
      0x7F: 'Service Not Supported In Active Session',
    };
    return descriptions[nrc] || `Unknown NRC 0x${nrc.toString(16)}`;
  }
}
