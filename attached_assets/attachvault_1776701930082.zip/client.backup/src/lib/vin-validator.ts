/**
 * Comprehensive VIN Validator
 * Validates VIN format, character set, and check digit
 * Based on ISO 3779 and SAE J853 standards
 */

// VIN transliteration values for check digit calculation
const VIN_TRANSLITERATION: { [key: string]: number } = {
  'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8,
  'J': 1, 'K': 2, 'L': 3, 'M': 4, 'N': 5, 'P': 7, 'R': 9,
  'S': 2, 'T': 3, 'U': 4, 'V': 5, 'W': 6, 'X': 7, 'Y': 8, 'Z': 9,
  '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9
};

// Position weights for check digit calculation
const VIN_WEIGHTS = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];

// Common World Manufacturer Identifiers (WMI) for FCA/Stellantis
const KNOWN_WMIS: { [key: string]: string } = {
  '1C3': 'Chrysler (USA)',
  '1C4': 'Chrysler (USA)',
  '1C6': 'Chrysler Trucks (USA)',
  '1C8': 'Chrysler (USA)',
  '1D3': 'Dodge (USA)',
  '1D4': 'Dodge Trucks (USA)',
  '1D7': 'Dodge Trucks (USA)',
  '1D8': 'Dodge Trucks (USA)',
  '1J4': 'Jeep (USA)',
  '1J8': 'Jeep (USA)',
  '2C3': 'Chrysler (Canada)',
  '2C4': 'Chrysler (Canada)',
  '2C8': 'Chrysler (Canada)',
  '2D3': 'Dodge (Canada)',
  '2D4': 'Dodge Trucks (Canada)',
  '2D8': 'Dodge Trucks (Canada)',
  '3C3': 'Chrysler (Mexico)',
  '3C4': 'Chrysler (Mexico)',
  '3C6': 'Chrysler Trucks (Mexico)',
  '3C8': 'Chrysler (Mexico)',
  '3D3': 'Dodge (Mexico)',
  '3D4': 'Dodge Trucks (Mexico)',
  '3D7': 'Dodge Trucks (Mexico)',
  'ZFA': 'Fiat (Italy)',
  'ZFF': 'Ferrari (Italy)',
  'ZAR': 'Alfa Romeo (Italy)',
  'VF1': 'Renault (France)',
  'VF3': 'Peugeot (France)',
  'VF7': 'Citroën (France)',
  'W0L': 'Opel (Germany)',
};

export interface VINValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  vin: string;
  checkDigitValid?: boolean;
  checkDigitExpected?: string;
  checkDigitActual?: string;
  wmi?: string;
  manufacturer?: string;
  modelYear?: number | null;
}

/**
 * Calculate VIN check digit
 */
function calculateCheckDigit(vin: string): string {
  let sum = 0;
  
  for (let i = 0; i < 17; i++) {
    const char = vin[i];
    const value = VIN_TRANSLITERATION[char];
    
    if (value === undefined) {
      return '?'; // Invalid character
    }
    
    sum += value * VIN_WEIGHTS[i];
  }
  
  const remainder = sum % 11;
  return remainder === 10 ? 'X' : remainder.toString();
}

/**
 * Get model year from VIN (10th character)
 */
function getModelYear(vin: string): number | null {
  const yearCode = vin[9];
  
  // Year codes: A=2010, B=2011, ..., Y=2000, 1=2001, ..., 9=2009
  const yearMap: { [key: string]: number } = {
    'A': 2010, 'B': 2011, 'C': 2012, 'D': 2013, 'E': 2014,
    'F': 2015, 'G': 2016, 'H': 2017, 'J': 2018, 'K': 2019,
    'L': 2020, 'M': 2021, 'N': 2022, 'P': 2023, 'R': 2024,
    'S': 2025, 'T': 2026, 'U': 2027, 'V': 2028, 'W': 2029,
    'X': 2030, 'Y': 2000,
    '1': 2001, '2': 2002, '3': 2003, '4': 2004, '5': 2005,
    '6': 2006, '7': 2007, '8': 2008, '9': 2009
  };
  
  return yearMap[yearCode] || null;
}

/**
 * Validate VIN format and check digit
 */
export function validateVIN(vin: string): VINValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  // Normalize VIN
  const normalizedVIN = vin.trim().toUpperCase();
  
  // Check length
  if (normalizedVIN.length !== 17) {
    errors.push(`VIN must be exactly 17 characters (got ${normalizedVIN.length})`);
    return {
      valid: false,
      errors,
      warnings,
      vin: normalizedVIN,
    };
  }
  
  // Check character set (no I, O, Q allowed)
  const invalidChars = normalizedVIN.split('').filter(c => !VIN_TRANSLITERATION[c]);
  if (invalidChars.length > 0) {
    errors.push(`Invalid characters: ${invalidChars.join(', ')} (I, O, Q not allowed in VINs)`);
  }
  
  // Check for all zeros or all same character (likely fake)
  if (/^(.)\1{16}$/.test(normalizedVIN)) {
    errors.push('VIN appears to be fake (all same character)');
  }
  
  // Calculate and verify check digit
  const expectedCheckDigit = calculateCheckDigit(normalizedVIN);
  const actualCheckDigit = normalizedVIN[8];
  const checkDigitValid = expectedCheckDigit === actualCheckDigit;
  
  if (!checkDigitValid && expectedCheckDigit !== '?') {
    errors.push(`Check digit mismatch: expected ${expectedCheckDigit}, got ${actualCheckDigit}`);
  }
  
  // Extract WMI (World Manufacturer Identifier)
  const wmi = normalizedVIN.substring(0, 3);
  const manufacturer = KNOWN_WMIS[wmi];
  
  if (!manufacturer) {
    warnings.push(`Unknown manufacturer code: ${wmi}`);
  }
  
  // Get model year
  const modelYear = getModelYear(normalizedVIN);
  if (!modelYear) {
    warnings.push('Could not determine model year');
  }
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
    vin: normalizedVIN,
    checkDigitValid,
    checkDigitExpected: expectedCheckDigit,
    checkDigitActual: actualCheckDigit,
    wmi,
    manufacturer,
    modelYear,
  };
}

/**
 * Quick validation - returns true/false only
 */
export function isValidVIN(vin: string): boolean {
  const result = validateVIN(vin);
  return result.valid;
}

/**
 * Get detailed VIN info for display
 */
export function getVINInfo(vin: string) {
  const result = validateVIN(vin);
  
  return {
    valid: result.valid,
    vin: result.vin,
    wmi: result.wmi,
    manufacturer: result.manufacturer || 'Unknown',
    modelYear: result.modelYear || undefined,
    checkDigitValid: result.checkDigitValid,
    checkDigit: result.checkDigitActual,
    errors: result.errors,
    warnings: result.warnings,
  };
}
