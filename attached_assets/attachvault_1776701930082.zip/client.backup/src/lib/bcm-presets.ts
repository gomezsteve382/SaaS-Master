export interface FeatureOption {
  label: string;
  value: number;
  description?: string;
}

export interface BCMFeaturePreset {
  id: string;
  name: string;
  category: string;
  description: string;
  did: number;
  byteOffset: number;
  bitMask?: number;
  options: FeatureOption[];
  defaultValue?: number;
  notes?: string;
}

export const BCM_FEATURE_CATEGORIES = [
  'Lighting',
  'Locks & Security',
  'Comfort Features',
  'Horn & Sounds',
  'Wipers',
  'Windows',
  'Mirrors',
  'Engine & Start',
  'Display',
  'Performance & Variant',
  'Other'
] as const;

export type BCMFeatureCategory = typeof BCM_FEATURE_CATEGORIES[number];

export const BCM_FEATURE_PRESETS: BCMFeaturePreset[] = [
  // ============================================
  // LIGHTING FEATURES (DID 0xDE00, Bytes 0x10-0x1F)
  // ============================================
  {
    id: 'drl_mode',
    name: 'Daytime Running Lights (DRL)',
    category: 'Lighting',
    description: 'Control daytime running light behavior',
    did: 0xDE00,
    byteOffset: 0x10,
    options: [
      { label: 'Off', value: 0x00, description: 'DRL disabled' },
      { label: 'Low Beam', value: 0x01, description: 'Use low beams as DRL' },
      { label: 'High Beam Dimmed', value: 0x02, description: 'Use dimmed high beams as DRL' },
      { label: 'LED DRL', value: 0x03, description: 'Use dedicated LED DRL' },
      { label: 'Fog Lights', value: 0x04, description: 'Use fog lights as DRL' },
    ],
    notes: 'Requires headlight switch in AUTO position'
  },
  {
    id: 'headlight_delay',
    name: 'Headlight Off Delay',
    category: 'Lighting',
    description: 'Time headlights stay on after engine off',
    did: 0xDE00,
    byteOffset: 0x11,
    options: [
      { label: 'Off (0 sec)', value: 0x00 },
      { label: '30 seconds', value: 0x1E },
      { label: '60 seconds', value: 0x3C },
      { label: '90 seconds', value: 0x5A },
      { label: '120 seconds', value: 0x78 },
      { label: '180 seconds', value: 0xB4 },
    ]
  },
  {
    id: 'auto_headlights_sensitivity',
    name: 'Auto Headlights Sensitivity',
    category: 'Lighting',
    description: 'Adjust when automatic headlights turn on',
    did: 0xDE00,
    byteOffset: 0x12,
    options: [
      { label: 'Early (More Sensitive)', value: 0x01 },
      { label: 'Medium-Early', value: 0x02 },
      { label: 'Normal', value: 0x03 },
      { label: 'Medium-Late', value: 0x04 },
      { label: 'Late (Less Sensitive)', value: 0x05 },
    ]
  },
  {
    id: 'flash_to_pass',
    name: 'Flash to Pass',
    category: 'Lighting',
    description: 'Enable high beam flash when pulled toward driver',
    did: 0xDE00,
    byteOffset: 0x13,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'cornering_lights',
    name: 'Cornering Lights',
    category: 'Lighting',
    description: 'Fog lights illuminate when turning',
    did: 0xDE00,
    byteOffset: 0x13,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'lights_flash_lock',
    name: 'Lights Flash on Lock',
    category: 'Lighting',
    description: 'Flash exterior lights when locking',
    did: 0xDE00,
    byteOffset: 0x14,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'Single Flash', value: 0x01 },
      { label: 'Double Flash', value: 0x02 },
      { label: 'Triple Flash', value: 0x03 },
    ]
  },
  {
    id: 'welcome_lights',
    name: 'Welcome Lights',
    category: 'Lighting',
    description: 'Illuminate lights when approaching vehicle',
    did: 0xDE00,
    byteOffset: 0x15,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'Exterior Only', value: 0x01 },
      { label: 'Interior Only', value: 0x02 },
      { label: 'Both', value: 0x03 },
    ]
  },
  {
    id: 'fog_light_mode',
    name: 'Fog Light Settings',
    category: 'Lighting',
    description: 'Configure fog light behavior',
    did: 0xDE00,
    byteOffset: 0x16,
    options: [
      { label: 'Manual Only', value: 0x00, description: 'Fog lights only with switch' },
      { label: 'Auto On with Headlights', value: 0x01, description: 'Fog lights on with low beams' },
      { label: 'Auto On with DRL', value: 0x02, description: 'Fog lights on with DRL' },
      { label: 'Auto Off at Speed', value: 0x03, description: 'Turn off fog lights above 45 mph' },
      { label: 'Stay On with High Beams', value: 0x04, description: 'Keep fog lights on with high beams' },
    ],
    notes: 'Some states require fog lights off with high beams'
  },
  {
    id: 'puddle_lamp_duration',
    name: 'Puddle Lamp Duration',
    category: 'Lighting',
    description: 'How long puddle lamps stay illuminated',
    did: 0xDE00,
    byteOffset: 0x17,
    options: [
      { label: 'Off', value: 0x00 },
      { label: '15 seconds', value: 0x0F },
      { label: '30 seconds', value: 0x1E },
      { label: '45 seconds', value: 0x2D },
      { label: '60 seconds', value: 0x3C },
      { label: '90 seconds', value: 0x5A },
    ]
  },
  {
    id: 'puddle_lamp_brightness',
    name: 'Puddle Lamp Brightness',
    category: 'Lighting',
    description: 'Brightness level for puddle lamps',
    did: 0xDE00,
    byteOffset: 0x18,
    options: [
      { label: 'Low (25%)', value: 0x19 },
      { label: 'Medium (50%)', value: 0x32 },
      { label: 'High (75%)', value: 0x4B },
      { label: 'Maximum (100%)', value: 0x64 },
    ]
  },
  {
    id: 'ambient_light_color',
    name: 'Ambient Interior Light Color',
    category: 'Lighting',
    description: 'Color selection for ambient interior lighting',
    did: 0xDE00,
    byteOffset: 0x19,
    options: [
      { label: 'White', value: 0x00 },
      { label: 'Red', value: 0x01 },
      { label: 'Blue', value: 0x02 },
      { label: 'Green', value: 0x03 },
      { label: 'Purple', value: 0x04 },
      { label: 'Orange', value: 0x05 },
      { label: 'Cyan', value: 0x06 },
      { label: 'Yellow', value: 0x07 },
      { label: 'Pink', value: 0x08 },
      { label: 'SRT Red', value: 0x09, description: 'Performance red accent' },
      { label: 'Hellcat Orange', value: 0x0A, description: 'Signature Hellcat color' },
      { label: 'Cycle Mode', value: 0xFF, description: 'Automatic color cycling' },
    ],
    notes: 'Requires ambient lighting package'
  },
  {
    id: 'ambient_light_brightness',
    name: 'Ambient Interior Light Brightness',
    category: 'Lighting',
    description: 'Brightness level for ambient interior lighting',
    did: 0xDE00,
    byteOffset: 0x1A,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'Dim (25%)', value: 0x19 },
      { label: 'Low (50%)', value: 0x32 },
      { label: 'Medium (75%)', value: 0x4B },
      { label: 'High (100%)', value: 0x64 },
    ]
  },
  {
    id: 'ambient_light_zones',
    name: 'Ambient Light Zones',
    category: 'Lighting',
    description: 'Which interior zones use ambient lighting',
    did: 0xDE00,
    byteOffset: 0x1B,
    options: [
      { label: 'All Zones', value: 0x00 },
      { label: 'Front Only', value: 0x01 },
      { label: 'Rear Only', value: 0x02 },
      { label: 'Footwells Only', value: 0x03 },
      { label: 'Door Panels Only', value: 0x04 },
      { label: 'Center Console Only', value: 0x05 },
    ]
  },
  {
    id: 'led_signature_lights',
    name: 'LED Signature Lights',
    category: 'Lighting',
    description: 'Enable LED signature light strips',
    did: 0xDE00,
    byteOffset: 0x1C,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'With DRL', value: 0x01, description: 'On with daytime running lights' },
      { label: 'With Headlights', value: 0x02, description: 'On with headlights' },
      { label: 'Always On (Engine Running)', value: 0x03 },
      { label: 'Parking Lights Only', value: 0x04 },
    ]
  },
  {
    id: 'tail_light_mode',
    name: 'Tail Light Mode',
    category: 'Lighting',
    description: 'Configure tail light behavior and regional mode',
    did: 0xDE00,
    byteOffset: 0x1D,
    options: [
      { label: 'US Standard', value: 0x00, description: 'Red turn signals, standard brightness' },
      { label: 'European Mode', value: 0x01, description: 'Amber turn signals, rear fog' },
      { label: 'Always On (Dim)', value: 0x02, description: 'Tail lights always on when running' },
      { label: 'Sequential Turn', value: 0x03, description: 'Sequential turn signal animation' },
      { label: 'Performance Mode', value: 0x04, description: 'Fast flash rate, bright' },
    ],
    notes: 'Sequential turn may not be legal in all jurisdictions'
  },
  {
    id: 'third_brake_flash',
    name: 'Third Brake Light Flash',
    category: 'Lighting',
    description: 'Enable flashing third brake light on initial brake',
    did: 0xDE00,
    byteOffset: 0x1E,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'third_brake_flash_count',
    name: 'Third Brake Light Flash Count',
    category: 'Lighting',
    description: 'Number of flashes for third brake light',
    did: 0xDE00,
    byteOffset: 0x1E,
    bitMask: 0xF0,
    options: [
      { label: '3 Flashes', value: 0x30 },
      { label: '4 Flashes', value: 0x40 },
      { label: '5 Flashes', value: 0x50 },
      { label: '6 Flashes', value: 0x60 },
    ],
    notes: 'Requires Third Brake Flash to be enabled'
  },
  {
    id: 'brake_flash_hard_braking',
    name: 'Brake Light Flash on Hard Braking',
    category: 'Lighting',
    description: 'Flash all brake lights during emergency braking',
    did: 0xDE00,
    byteOffset: 0x1F,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Flash All Brake Lights', value: 0x01, description: 'All brake lights flash' },
      { label: 'Hazards Activate', value: 0x02, description: 'Hazard lights activate automatically' },
      { label: 'Both', value: 0x03, description: 'Flash and hazards' },
    ],
    notes: 'Activates based on deceleration rate'
  },

  // ============================================
  // LOCKS & SECURITY FEATURES (DID 0xDE00, Bytes 0x20-0x2F)
  // ============================================
  {
    id: 'auto_lock_speed',
    name: 'Auto Lock at Speed',
    category: 'Locks & Security',
    description: 'Automatically lock doors when vehicle reaches speed',
    did: 0xDE00,
    byteOffset: 0x20,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: '8 mph / 13 km/h', value: 0x08 },
      { label: '15 mph / 24 km/h', value: 0x0F },
      { label: '20 mph / 32 km/h', value: 0x14 },
      { label: '25 mph / 40 km/h', value: 0x19 },
    ]
  },
  {
    id: 'auto_unlock_park',
    name: 'Auto Unlock in Park',
    category: 'Locks & Security',
    description: 'Automatically unlock doors when shifted to Park',
    did: 0xDE00,
    byteOffset: 0x21,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'All Doors', value: 0x01 },
      { label: 'Driver Door Only', value: 0x02 },
    ]
  },
  {
    id: 'relock_time',
    name: 'Auto Re-lock Timer',
    category: 'Locks & Security',
    description: 'Re-lock doors if not opened after unlock',
    did: 0xDE00,
    byteOffset: 0x22,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: '30 seconds', value: 0x1E },
      { label: '60 seconds', value: 0x3C },
      { label: '90 seconds', value: 0x5A },
      { label: '120 seconds', value: 0x78 },
      { label: '180 seconds', value: 0xB4 },
    ]
  },
  {
    id: 'first_unlock',
    name: 'First Unlock Press',
    category: 'Locks & Security',
    description: 'Which doors unlock on first key fob press',
    did: 0xDE00,
    byteOffset: 0x23,
    options: [
      { label: 'Driver Door Only', value: 0x00 },
      { label: 'All Doors', value: 0x01 },
    ]
  },
  {
    id: 'passive_entry',
    name: 'Passive Entry',
    category: 'Locks & Security',
    description: 'Unlock doors automatically when fob is near',
    did: 0xDE00,
    byteOffset: 0x24,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Requires Keyless Enter-N-Go package'
  },
  {
    id: 'passive_entry_zones',
    name: 'Passive Entry Zones',
    category: 'Locks & Security',
    description: 'Which zones respond to passive entry',
    did: 0xDE00,
    byteOffset: 0x24,
    bitMask: 0xF0,
    options: [
      { label: 'All Doors', value: 0x00 },
      { label: 'Front Doors Only', value: 0x10 },
      { label: 'Driver Door Only', value: 0x20 },
      { label: 'Driver + Trunk', value: 0x30 },
    ]
  },
  {
    id: 'passive_entry_timeout',
    name: 'Passive Entry Timeout',
    category: 'Locks & Security',
    description: 'Time to wait for door open after passive unlock',
    did: 0xDE00,
    byteOffset: 0x25,
    options: [
      { label: '5 seconds', value: 0x05 },
      { label: '10 seconds', value: 0x0A },
      { label: '15 seconds', value: 0x0F },
      { label: '30 seconds', value: 0x1E },
    ]
  },
  {
    id: 'fob_range_sensitivity',
    name: 'Key Fob Range Sensitivity',
    category: 'Locks & Security',
    description: 'Detection range for key fob',
    did: 0xDE00,
    byteOffset: 0x26,
    options: [
      { label: 'Short (10 ft)', value: 0x01, description: 'More secure, shorter range' },
      { label: 'Medium (25 ft)', value: 0x02, description: 'Balanced range' },
      { label: 'Long (50 ft)', value: 0x03, description: 'Maximum convenience' },
      { label: 'Extended (75 ft)', value: 0x04, description: 'Extended range mode' },
    ]
  },
  {
    id: 'remote_lock_feedback',
    name: 'Remote Lock Feedback',
    category: 'Locks & Security',
    description: 'Confirmation when locking with remote',
    did: 0xDE00,
    byteOffset: 0x27,
    options: [
      { label: 'None', value: 0x00 },
      { label: 'Lights Only', value: 0x01 },
      { label: 'Horn Only', value: 0x02 },
      { label: 'Lights and Horn', value: 0x03 },
    ]
  },
  {
    id: 'door_ajar_threshold',
    name: 'Door Ajar Warning Threshold',
    category: 'Locks & Security',
    description: 'Speed at which door ajar warning activates',
    did: 0xDE00,
    byteOffset: 0x28,
    options: [
      { label: 'Immediate', value: 0x00, description: 'Warn as soon as moving' },
      { label: '3 mph', value: 0x03 },
      { label: '5 mph', value: 0x05 },
      { label: '10 mph', value: 0x0A },
    ]
  },
  {
    id: 'door_ajar_chime',
    name: 'Door Ajar Chime',
    category: 'Locks & Security',
    description: 'Audible warning for door ajar',
    did: 0xDE00,
    byteOffset: 0x29,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Single Chime', value: 0x01 },
      { label: 'Continuous Chime', value: 0x02 },
      { label: 'Escalating Chime', value: 0x03, description: 'Gets louder over time' },
    ]
  },
  {
    id: 'trunk_auto_lock',
    name: 'Trunk/Liftgate Auto-Lock',
    category: 'Locks & Security',
    description: 'Automatically lock trunk after closing',
    did: 0xDE00,
    byteOffset: 0x2A,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Immediate', value: 0x01 },
      { label: 'After 30 seconds', value: 0x1E },
      { label: 'After 60 seconds', value: 0x3C },
      { label: 'With Vehicle Lock', value: 0xFF, description: 'Only when vehicle locks' },
    ]
  },
  {
    id: 'sentry_mode',
    name: 'Sentry Mode',
    category: 'Locks & Security',
    description: 'Enhanced security monitoring when parked',
    did: 0xDE00,
    byteOffset: 0x2B,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01, description: 'Basic sentry monitoring' },
      { label: 'Enabled + Record', value: 0x02, description: 'Record on detection' },
      { label: 'Enabled + Alert', value: 0x03, description: 'Send phone notification' },
    ],
    notes: 'Requires compatible security package'
  },
  {
    id: 'intrusion_motion_sensor',
    name: 'Motion Intrusion Sensor',
    category: 'Locks & Security',
    description: 'Interior motion detection when armed',
    did: 0xDE00,
    byteOffset: 0x2C,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'intrusion_tilt_sensor',
    name: 'Tilt Intrusion Sensor',
    category: 'Locks & Security',
    description: 'Vehicle tilt detection (tow protection)',
    did: 0xDE00,
    byteOffset: 0x2C,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'intrusion_glass_break',
    name: 'Glass Break Sensor',
    category: 'Locks & Security',
    description: 'Window glass break detection',
    did: 0xDE00,
    byteOffset: 0x2C,
    bitMask: 0x04,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x04 },
    ]
  },
  {
    id: 'valet_mode',
    name: 'Valet Mode',
    category: 'Locks & Security',
    description: 'Restrict access to trunk and glove box',
    did: 0xDE00,
    byteOffset: 0x2D,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'secure_idle',
    name: 'Secure Idle',
    category: 'Locks & Security',
    description: 'Allow engine running with doors locked and key removed',
    did: 0xDE00,
    byteOffset: 0x2D,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ],
    notes: 'Useful for remote start security'
  },

  // ============================================
  // HORN & SOUNDS FEATURES (DID 0xDE00, Bytes 0x30-0x3F)
  // ============================================
  {
    id: 'horn_on_lock',
    name: 'Horn Chirp on Lock',
    category: 'Horn & Sounds',
    description: 'Sound horn when locking with key fob',
    did: 0xDE00,
    byteOffset: 0x30,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'Single Chirp', value: 0x01 },
      { label: 'Double Chirp', value: 0x02 },
    ]
  },
  {
    id: 'horn_on_arm',
    name: 'Horn on Security Arm',
    category: 'Horn & Sounds',
    description: 'Sound horn when security system arms',
    did: 0xDE00,
    byteOffset: 0x31,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'chime_volume',
    name: 'Chime Volume',
    category: 'Horn & Sounds',
    description: 'Volume of warning chimes',
    did: 0xDE00,
    byteOffset: 0x32,
    options: [
      { label: 'Low', value: 0x01 },
      { label: 'Medium', value: 0x02 },
      { label: 'High', value: 0x03 },
    ]
  },
  {
    id: 'key_in_ignition_chime',
    name: 'Key in Ignition Chime',
    category: 'Horn & Sounds',
    description: 'Chime when key is left in ignition',
    did: 0xDE00,
    byteOffset: 0x33,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'headlight_on_chime',
    name: 'Headlight On Warning Chime',
    category: 'Horn & Sounds',
    description: 'Chime when headlights left on',
    did: 0xDE00,
    byteOffset: 0x33,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'seatbelt_chime',
    name: 'Seat Belt Warning Chime',
    category: 'Horn & Sounds',
    description: 'Audible reminder for seat belt',
    did: 0xDE00,
    byteOffset: 0x34,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Short (6 chimes)', value: 0x01 },
      { label: 'Standard (30 seconds)', value: 0x02 },
      { label: 'Extended (90 seconds)', value: 0x03 },
      { label: 'Continuous', value: 0x04 },
    ]
  },
  {
    id: 'turn_signal_volume',
    name: 'Turn Signal Click Volume',
    category: 'Horn & Sounds',
    description: 'Volume of turn signal click sound',
    did: 0xDE00,
    byteOffset: 0x35,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'Low', value: 0x01 },
      { label: 'Medium', value: 0x02 },
      { label: 'High', value: 0x03 },
    ]
  },
  {
    id: 'parking_sensor_volume',
    name: 'Parking Sensor Volume',
    category: 'Horn & Sounds',
    description: 'Volume of parking proximity warning',
    did: 0xDE00,
    byteOffset: 0x36,
    options: [
      { label: 'Off', value: 0x00 },
      { label: 'Low', value: 0x01 },
      { label: 'Medium', value: 0x02 },
      { label: 'High', value: 0x03 },
    ]
  },
  {
    id: 'startup_sound',
    name: 'Startup Sound',
    category: 'Horn & Sounds',
    description: 'Sound played when vehicle starts',
    did: 0xDE00,
    byteOffset: 0x37,
    options: [
      { label: 'None', value: 0x00 },
      { label: 'Standard Chime', value: 0x01 },
      { label: 'Performance Tone', value: 0x02, description: 'Aggressive startup tone' },
      { label: 'SRT Growl', value: 0x03, description: 'SRT signature sound' },
      { label: 'Hellcat Roar', value: 0x04, description: 'Supercharger whine simulation' },
    ],
    notes: 'Some sounds require performance package'
  },

  // ============================================
  // WINDOWS FEATURES (DID 0xDE00, Bytes 0x40-0x4F)
  // ============================================
  {
    id: 'comfort_windows_down',
    name: 'One-Touch Windows Down',
    category: 'Windows',
    description: 'Enable one-touch down for all windows',
    did: 0xDE00,
    byteOffset: 0x40,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'comfort_windows_up',
    name: 'One-Touch Windows Up',
    category: 'Windows',
    description: 'Enable one-touch up for all windows',
    did: 0xDE00,
    byteOffset: 0x40,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'remote_windows',
    name: 'Remote Window Control',
    category: 'Windows',
    description: 'Control windows with key fob hold',
    did: 0xDE00,
    byteOffset: 0x41,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Down Only', value: 0x01 },
      { label: 'Up and Down', value: 0x02 },
    ]
  },
  {
    id: 'pinch_protection_sensitivity',
    name: 'Pinch Protection Sensitivity',
    category: 'Windows',
    description: 'Sensitivity of anti-pinch window feature',
    did: 0xDE00,
    byteOffset: 0x42,
    options: [
      { label: 'Low', value: 0x01, description: 'Less sensitive, stronger close' },
      { label: 'Medium', value: 0x02, description: 'Balanced sensitivity' },
      { label: 'High', value: 0x03, description: 'Very sensitive, immediate reverse' },
    ]
  },
  {
    id: 'window_express_driver',
    name: 'Driver Window Express Up/Down',
    category: 'Windows',
    description: 'Express control for driver window',
    did: 0xDE00,
    byteOffset: 0x43,
    options: [
      { label: 'Down Only', value: 0x01 },
      { label: 'Up Only', value: 0x02 },
      { label: 'Both', value: 0x03 },
      { label: 'Disabled', value: 0x00 },
    ]
  },
  {
    id: 'window_express_passenger',
    name: 'Passenger Window Express Up/Down',
    category: 'Windows',
    description: 'Express control for front passenger window',
    did: 0xDE00,
    byteOffset: 0x44,
    options: [
      { label: 'Down Only', value: 0x01 },
      { label: 'Up Only', value: 0x02 },
      { label: 'Both', value: 0x03 },
      { label: 'Disabled', value: 0x00 },
    ]
  },
  {
    id: 'window_express_rear',
    name: 'Rear Windows Express Up/Down',
    category: 'Windows',
    description: 'Express control for rear windows',
    did: 0xDE00,
    byteOffset: 0x45,
    options: [
      { label: 'Down Only', value: 0x01 },
      { label: 'Up Only', value: 0x02 },
      { label: 'Both', value: 0x03 },
      { label: 'Disabled', value: 0x00 },
    ]
  },
  {
    id: 'sunroof_express_open',
    name: 'Sunroof Express Open',
    category: 'Windows',
    description: 'One-touch sunroof open',
    did: 0xDE00,
    byteOffset: 0x46,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'sunroof_express_close',
    name: 'Sunroof Express Close',
    category: 'Windows',
    description: 'One-touch sunroof close',
    did: 0xDE00,
    byteOffset: 0x46,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'rain_close_windows',
    name: 'Rain Close Windows',
    category: 'Windows',
    description: 'Automatically close windows when rain detected',
    did: 0xDE00,
    byteOffset: 0x47,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Windows Only', value: 0x01 },
      { label: 'Sunroof Only', value: 0x02 },
      { label: 'Windows and Sunroof', value: 0x03 },
    ],
    notes: 'Requires rain sensor'
  },
  {
    id: 'window_retained_power',
    name: 'Window Retained Power',
    category: 'Windows',
    description: 'Time windows remain operable after ignition off',
    did: 0xDE00,
    byteOffset: 0x48,
    options: [
      { label: 'None', value: 0x00 },
      { label: '30 seconds', value: 0x1E },
      { label: '60 seconds', value: 0x3C },
      { label: '5 minutes', value: 0xFF, description: 'Extended retained power' },
      { label: 'Until Door Opens', value: 0xFE },
    ]
  },

  // ============================================
  // WIPERS FEATURES (DID 0xDE00, Bytes 0x50-0x5F)
  // ============================================
  {
    id: 'rain_sensing_wipers',
    name: 'Rain Sensing Wipers',
    category: 'Wipers',
    description: 'Enable automatic rain-sensing wiper mode',
    did: 0xDE00,
    byteOffset: 0x50,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'wiper_sensitivity',
    name: 'Rain Sensor Sensitivity',
    category: 'Wipers',
    description: 'Adjust rain sensor sensitivity',
    did: 0xDE00,
    byteOffset: 0x51,
    options: [
      { label: 'Low', value: 0x01 },
      { label: 'Medium-Low', value: 0x02 },
      { label: 'Medium', value: 0x03 },
      { label: 'Medium-High', value: 0x04 },
      { label: 'High', value: 0x05 },
    ]
  },
  {
    id: 'reverse_wipe',
    name: 'Reverse Wiper Activation',
    category: 'Wipers',
    description: 'Single wipe when shifting to reverse',
    did: 0xDE00,
    byteOffset: 0x52,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'wiper_de_ice',
    name: 'Wiper De-Ice Mode',
    category: 'Wipers',
    description: 'Heat windshield wiper zone in cold weather',
    did: 0xDE00,
    byteOffset: 0x53,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Requires heated windshield option'
  },
  {
    id: 'wiper_service_mode',
    name: 'Wiper Service Position',
    category: 'Wipers',
    description: 'Move wipers to service position when ignition off',
    did: 0xDE00,
    byteOffset: 0x54,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Manual Activation', value: 0x01, description: 'Press wiper stalk to activate' },
      { label: 'Auto in Winter', value: 0x02, description: 'Auto when below 40°F' },
    ]
  },
  {
    id: 'wiper_intermittent_speed',
    name: 'Intermittent Wiper Speed',
    category: 'Wipers',
    description: 'Default intermittent wiper delay',
    did: 0xDE00,
    byteOffset: 0x55,
    options: [
      { label: 'Short (2 sec)', value: 0x02 },
      { label: 'Medium (5 sec)', value: 0x05 },
      { label: 'Long (10 sec)', value: 0x0A },
      { label: 'Variable (Auto)', value: 0xFF },
    ]
  },

  // ============================================
  // MIRRORS FEATURES (DID 0xDE00, Bytes 0x60-0x6F)
  // ============================================
  {
    id: 'mirror_fold_lock',
    name: 'Mirror Fold on Lock',
    category: 'Mirrors',
    description: 'Fold mirrors when locking vehicle',
    did: 0xDE00,
    byteOffset: 0x60,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'mirror_dip_reverse',
    name: 'Mirror Dip in Reverse',
    category: 'Mirrors',
    description: 'Passenger mirror dips when reversing',
    did: 0xDE00,
    byteOffset: 0x60,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'auto_dim_sensitivity',
    name: 'Auto-Dim Mirror Sensitivity',
    category: 'Mirrors',
    description: 'How quickly mirrors auto-dim in response to headlights',
    did: 0xDE00,
    byteOffset: 0x61,
    options: [
      { label: 'Low', value: 0x01, description: 'Slow response, less dimming' },
      { label: 'Medium', value: 0x02, description: 'Balanced response' },
      { label: 'High', value: 0x03, description: 'Quick response, aggressive dimming' },
    ]
  },
  {
    id: 'heated_mirror_auto',
    name: 'Heated Mirror Auto-On',
    category: 'Mirrors',
    description: 'Automatically heat mirrors in cold weather',
    did: 0xDE00,
    byteOffset: 0x62,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Below 40°F / 4°C', value: 0x01 },
      { label: 'Below 50°F / 10°C', value: 0x02 },
      { label: 'With Rear Defrost', value: 0x03 },
    ]
  },
  {
    id: 'memory_mirror_driver',
    name: 'Memory Mirror - Driver',
    category: 'Mirrors',
    description: 'Save driver mirror position with memory seat',
    did: 0xDE00,
    byteOffset: 0x63,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'memory_mirror_passenger',
    name: 'Memory Mirror - Passenger',
    category: 'Mirrors',
    description: 'Save passenger mirror position with memory seat',
    did: 0xDE00,
    byteOffset: 0x63,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'approach_light_mirror',
    name: 'Approach Light in Mirror',
    category: 'Mirrors',
    description: 'Illuminate approach/puddle lights in side mirrors',
    did: 0xDE00,
    byteOffset: 0x64,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'On Unlock', value: 0x01 },
      { label: 'On Approach', value: 0x02, description: 'With passive entry' },
      { label: 'Always When Parked', value: 0x03 },
    ]
  },
  {
    id: 'mirror_position_reverse',
    name: 'Mirror Position Memory - Reverse',
    category: 'Mirrors',
    description: 'Remember mirror position when shifting to reverse',
    did: 0xDE00,
    byteOffset: 0x65,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },

  // ============================================
  // COMFORT FEATURES (DID 0xDE00, Bytes 0x70-0x7F)
  // ============================================
  {
    id: 'easy_entry_exit',
    name: 'Easy Entry/Exit',
    category: 'Comfort Features',
    description: 'Seat and steering wheel move for entry/exit',
    did: 0xDE00,
    byteOffset: 0x70,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'memory_seat_fob_link',
    name: 'Memory Seat - Key Fob Link',
    category: 'Comfort Features',
    description: 'Link memory seat position to specific key fob',
    did: 0xDE00,
    byteOffset: 0x71,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Fob 1 = Memory 1', value: 0x01 },
      { label: 'Fob 2 = Memory 2', value: 0x02 },
      { label: 'Auto Detect', value: 0x03, description: 'Auto-assign fob to memory' },
    ]
  },
  {
    id: 'memory_seat_profiles',
    name: 'Memory Seat Profiles',
    category: 'Comfort Features',
    description: 'Number of available memory seat profiles',
    did: 0xDE00,
    byteOffset: 0x72,
    options: [
      { label: '2 Profiles', value: 0x02 },
      { label: '3 Profiles', value: 0x03 },
      { label: '4 Profiles', value: 0x04 },
    ]
  },
  {
    id: 'memory_mirrors_link',
    name: 'Memory Mirrors with Seat',
    category: 'Comfort Features',
    description: 'Include mirror positions in memory seat recall',
    did: 0xDE00,
    byteOffset: 0x73,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'heated_seats_auto',
    name: 'Heated Seats Auto-Start',
    category: 'Comfort Features',
    description: 'Automatically activate heated seats in cold weather',
    did: 0xDE00,
    byteOffset: 0x74,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Below 32°F / 0°C', value: 0x01, description: 'Freezing temperatures' },
      { label: 'Below 40°F / 4°C', value: 0x02 },
      { label: 'Below 50°F / 10°C', value: 0x03 },
      { label: 'With Remote Start', value: 0x04, description: 'Only on remote start' },
    ]
  },
  {
    id: 'heated_steering_auto',
    name: 'Heated Steering Wheel Auto-Start',
    category: 'Comfort Features',
    description: 'Automatically activate heated steering in cold weather',
    did: 0xDE00,
    byteOffset: 0x75,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Below 32°F / 0°C', value: 0x01 },
      { label: 'Below 40°F / 4°C', value: 0x02 },
      { label: 'Below 50°F / 10°C', value: 0x03 },
      { label: 'With Heated Seats', value: 0x04, description: 'Match heated seat setting' },
    ]
  },
  {
    id: 'seatbelt_warning_delay',
    name: 'Seat Belt Warning Delay',
    category: 'Comfort Features',
    description: 'Delay before seat belt warning activates',
    did: 0xDE00,
    byteOffset: 0x76,
    options: [
      { label: 'Immediate', value: 0x00 },
      { label: '5 seconds', value: 0x05 },
      { label: '10 seconds', value: 0x0A },
      { label: '30 seconds', value: 0x1E },
      { label: '60 seconds', value: 0x3C },
    ]
  },
  {
    id: 'power_liftgate_height',
    name: 'Power Liftgate Height',
    category: 'Comfort Features',
    description: 'Maximum open height for power liftgate',
    did: 0xDE00,
    byteOffset: 0x77,
    options: [
      { label: '75%', value: 0x4B },
      { label: '80%', value: 0x50 },
      { label: '85%', value: 0x55 },
      { label: '90%', value: 0x5A },
      { label: '95%', value: 0x5F },
      { label: '100% (Full)', value: 0x64 },
    ]
  },
  {
    id: 'ventilated_seats_auto',
    name: 'Ventilated Seats Auto-Start',
    category: 'Comfort Features',
    description: 'Automatically activate ventilated seats in hot weather',
    did: 0xDE00,
    byteOffset: 0x78,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Above 80°F / 27°C', value: 0x01 },
      { label: 'Above 85°F / 29°C', value: 0x02 },
      { label: 'Above 90°F / 32°C', value: 0x03 },
      { label: 'With Remote Start', value: 0x04 },
    ]
  },
  {
    id: 'steering_wheel_position',
    name: 'Steering Wheel Memory',
    category: 'Comfort Features',
    description: 'Save steering wheel position with memory',
    did: 0xDE00,
    byteOffset: 0x79,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'pedal_position_memory',
    name: 'Adjustable Pedal Memory',
    category: 'Comfort Features',
    description: 'Save pedal position with memory',
    did: 0xDE00,
    byteOffset: 0x79,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ],
    notes: 'Requires adjustable pedals'
  },

  // ============================================
  // ENGINE & START FEATURES (DID 0xDE00, Bytes 0x80-0x8F)
  // ============================================
  {
    id: 'remote_start_runtime',
    name: 'Remote Start Runtime',
    category: 'Engine & Start',
    description: 'How long engine runs on remote start',
    did: 0xDE00,
    byteOffset: 0x80,
    options: [
      { label: '5 minutes', value: 0x05 },
      { label: '10 minutes', value: 0x0A },
      { label: '15 minutes', value: 0x0F },
      { label: '20 minutes', value: 0x14 },
      { label: '25 minutes', value: 0x19 },
    ]
  },
  {
    id: 'keyless_go',
    name: 'Keyless Go (Push Start)',
    category: 'Engine & Start',
    description: 'Enable keyless push-button start',
    did: 0xDE00,
    byteOffset: 0x81,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'idle_shutdown_timer',
    name: 'Idle Shutdown Timer',
    category: 'Engine & Start',
    description: 'Automatically shut off engine after idle time',
    did: 0xDE00,
    byteOffset: 0x82,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: '10 minutes', value: 0x0A },
      { label: '15 minutes', value: 0x0F },
      { label: '20 minutes', value: 0x14 },
      { label: '30 minutes', value: 0x1E },
      { label: '60 minutes', value: 0x3C },
    ]
  },
  {
    id: 'remote_start_climate',
    name: 'Remote Start Climate Settings',
    category: 'Engine & Start',
    description: 'Climate control behavior during remote start',
    did: 0xDE00,
    byteOffset: 0x83,
    options: [
      { label: 'Last Setting', value: 0x00, description: 'Use last climate setting' },
      { label: 'Auto Climate', value: 0x01, description: 'Automatic based on temp' },
      { label: 'Heat Only', value: 0x02 },
      { label: 'Cool Only', value: 0x03 },
      { label: 'Defrost Priority', value: 0x04 },
    ]
  },
  {
    id: 'remote_start_extend',
    name: 'Remote Start Extension',
    category: 'Engine & Start',
    description: 'Allow extending remote start time',
    did: 0xDE00,
    byteOffset: 0x84,
    options: [
      { label: 'No Extension', value: 0x00 },
      { label: '1x Extension', value: 0x01, description: 'Extend once' },
      { label: '2x Extension', value: 0x02, description: 'Extend twice' },
      { label: 'Unlimited', value: 0xFF, description: 'Extend unlimited times' },
    ]
  },
  {
    id: 'stop_start_memory',
    name: 'Stop-Start Disable Memory',
    category: 'Engine & Start',
    description: 'Remember stop-start disable setting',
    did: 0xDE00,
    byteOffset: 0x85,
    options: [
      { label: 'Reset Each Start', value: 0x00, description: 'Stop-start enables each start' },
      { label: 'Remember Setting', value: 0x01, description: 'Keep last setting' },
      { label: 'Always Disabled', value: 0x02, description: 'Permanently disable stop-start' },
    ],
    notes: 'Stop-start feature on supported vehicles'
  },
  {
    id: 'speed_warning_threshold',
    name: 'Speed Warning Threshold',
    category: 'Engine & Start',
    description: 'Speed at which warning chime activates',
    did: 0xDE00,
    byteOffset: 0x86,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: '55 mph / 89 km/h', value: 0x37 },
      { label: '65 mph / 105 km/h', value: 0x41 },
      { label: '70 mph / 113 km/h', value: 0x46 },
      { label: '75 mph / 121 km/h', value: 0x4B },
      { label: '80 mph / 129 km/h', value: 0x50 },
      { label: '85 mph / 137 km/h', value: 0x55 },
    ]
  },
  {
    id: 'remote_start_heated_features',
    name: 'Remote Start Heated Features',
    category: 'Engine & Start',
    description: 'Heated features to activate on remote start',
    did: 0xDE00,
    byteOffset: 0x87,
    options: [
      { label: 'None', value: 0x00 },
      { label: 'Seats Only', value: 0x01 },
      { label: 'Steering Only', value: 0x02 },
      { label: 'Seats + Steering', value: 0x03 },
      { label: 'All Heated Features', value: 0x04 },
    ]
  },
  {
    id: 'engine_run_accessory',
    name: 'Engine Run with Door Open',
    category: 'Engine & Start',
    description: 'Allow engine to run with door open',
    did: 0xDE00,
    byteOffset: 0x88,
    bitMask: 0x01,
    options: [
      { label: 'Auto Shut-off', value: 0x00, description: 'Engine shuts off if door opens' },
      { label: 'Keep Running', value: 0x01, description: 'Engine continues running' },
    ]
  },

  // ============================================
  // DISPLAY FEATURES (DID 0xDE00, Bytes 0x90-0x9F)
  // ============================================
  {
    id: 'tire_pressure_units',
    name: 'Tire Pressure Display Units',
    category: 'Display',
    description: 'Units for tire pressure display',
    did: 0xDE00,
    byteOffset: 0x90,
    options: [
      { label: 'PSI', value: 0x00 },
      { label: 'kPa', value: 0x01 },
      { label: 'Bar', value: 0x02 },
    ]
  },
  {
    id: 'speed_units',
    name: 'Speed Display Units',
    category: 'Display',
    description: 'Units for speedometer display',
    did: 0xDE00,
    byteOffset: 0x91,
    options: [
      { label: 'MPH', value: 0x00 },
      { label: 'KM/H', value: 0x01 },
    ]
  },
  {
    id: 'temperature_units',
    name: 'Temperature Display Units',
    category: 'Display',
    description: 'Units for temperature display',
    did: 0xDE00,
    byteOffset: 0x92,
    options: [
      { label: 'Fahrenheit (°F)', value: 0x00 },
      { label: 'Celsius (°C)', value: 0x01 },
    ]
  },
  {
    id: 'distance_units',
    name: 'Distance Display Units',
    category: 'Display',
    description: 'Units for odometer and trip display',
    did: 0xDE00,
    byteOffset: 0x93,
    options: [
      { label: 'Miles', value: 0x00 },
      { label: 'Kilometers', value: 0x01 },
    ]
  },
  {
    id: 'fuel_economy_units',
    name: 'Fuel Economy Display Units',
    category: 'Display',
    description: 'Units for fuel economy display',
    did: 0xDE00,
    byteOffset: 0x94,
    options: [
      { label: 'MPG (US)', value: 0x00 },
      { label: 'MPG (UK)', value: 0x01 },
      { label: 'L/100km', value: 0x02 },
      { label: 'km/L', value: 0x03 },
    ]
  },
  {
    id: 'clock_format',
    name: 'Clock Format',
    category: 'Display',
    description: 'Time display format',
    did: 0xDE00,
    byteOffset: 0x95,
    options: [
      { label: '12-Hour (AM/PM)', value: 0x00 },
      { label: '24-Hour', value: 0x01 },
    ]
  },
  {
    id: 'startup_message',
    name: 'Startup Message',
    category: 'Display',
    description: 'Message displayed on vehicle startup',
    did: 0xDE00,
    byteOffset: 0x96,
    options: [
      { label: 'None', value: 0x00 },
      { label: 'Welcome', value: 0x01 },
      { label: 'Vehicle Name', value: 0x02, description: 'Show Charger/Challenger/etc.' },
      { label: 'Custom Message', value: 0x03 },
      { label: 'Performance Stats', value: 0x04, description: 'Show HP/Torque info' },
    ]
  },
  {
    id: 'gauge_sweep',
    name: 'Gauge Sweep on Startup',
    category: 'Display',
    description: 'Sweep gauges to maximum on startup',
    did: 0xDE00,
    byteOffset: 0x97,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'digital_speedometer',
    name: 'Digital Speedometer',
    category: 'Display',
    description: 'Show digital speed readout',
    did: 0xDE00,
    byteOffset: 0x97,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'cluster_brightness_auto',
    name: 'Cluster Auto Brightness',
    category: 'Display',
    description: 'Automatically adjust cluster brightness',
    did: 0xDE00,
    byteOffset: 0x98,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'night_mode_cluster',
    name: 'Night Mode Theme',
    category: 'Display',
    description: 'Cluster display theme at night',
    did: 0xDE00,
    byteOffset: 0x99,
    options: [
      { label: 'Standard', value: 0x00 },
      { label: 'Red Tint', value: 0x01, description: 'Preserve night vision' },
      { label: 'Dim', value: 0x02 },
      { label: 'Off', value: 0x03, description: 'Display off at night' },
    ]
  },

  // ============================================
  // PERFORMANCE & VARIANT FEATURES (DID 0xDE01, Bytes 0x00-0x7F)
  // ============================================
  {
    id: 'vehicle_trim_level',
    name: 'Vehicle Trim Level',
    category: 'Performance & Variant',
    description: 'Configure vehicle trim level identification',
    did: 0xDE01,
    byteOffset: 0x00,
    options: [
      { label: 'SE', value: 0x00, description: 'Base model' },
      { label: 'SXT', value: 0x01, description: 'Standard trim' },
      { label: 'SXT Plus', value: 0x02, description: 'Enhanced SXT' },
      { label: 'GT', value: 0x03, description: 'Grand Touring' },
      { label: 'R/T', value: 0x04, description: 'Road/Track - 5.7L HEMI' },
      { label: 'R/T Plus', value: 0x05, description: 'Enhanced R/T' },
      { label: 'R/T Scat Pack', value: 0x06, description: '6.4L HEMI 392' },
      { label: 'Scat Pack Widebody', value: 0x07, description: 'Widebody 392' },
      { label: 'SRT 392', value: 0x08, description: 'SRT 6.4L' },
      { label: 'SRT Hellcat', value: 0x09, description: '6.2L Supercharged 707HP' },
      { label: 'Hellcat Widebody', value: 0x0A, description: 'Widebody Hellcat' },
      { label: 'SRT Hellcat Redeye', value: 0x0B, description: '6.2L Supercharged 797HP' },
      { label: 'Redeye Widebody', value: 0x0C, description: 'Widebody Redeye' },
      { label: 'SRT Jailbreak', value: 0x0D, description: 'Jailbreak edition' },
      { label: 'SRT Super Stock', value: 0x0E, description: '807HP Drag special' },
      { label: 'SRT Demon', value: 0x0F, description: '840HP Demon' },
      { label: 'SRT Demon 170', value: 0x10, description: '1025HP Demon 170' },
    ],
    notes: 'Critical: Affects available features and performance settings'
  },
  {
    id: 'engine_variant',
    name: 'Engine Variant',
    category: 'Performance & Variant',
    description: 'Engine configuration identifier',
    did: 0xDE01,
    byteOffset: 0x01,
    options: [
      { label: '3.6L Pentastar V6', value: 0x01 },
      { label: '5.7L HEMI V8', value: 0x02 },
      { label: '6.4L HEMI 392 V8', value: 0x03 },
      { label: '6.2L Supercharged V8 (Hellcat)', value: 0x04 },
      { label: '6.2L Supercharged V8 (Redeye)', value: 0x05 },
      { label: '6.2L Supercharged V8 (Demon)', value: 0x06 },
      { label: '6.2L Supercharged V8 (Demon 170)', value: 0x07 },
    ]
  },
  {
    id: 'launch_control',
    name: 'Launch Control',
    category: 'Performance & Variant',
    description: 'Enable launch control system',
    did: 0xDE01,
    byteOffset: 0x10,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Available on SRT and performance models'
  },
  {
    id: 'launch_control_rpm',
    name: 'Launch Control RPM',
    category: 'Performance & Variant',
    description: 'Target RPM for launch control',
    did: 0xDE01,
    byteOffset: 0x11,
    options: [
      { label: '2000 RPM', value: 0x14 },
      { label: '2500 RPM', value: 0x19 },
      { label: '3000 RPM', value: 0x1E },
      { label: '3500 RPM', value: 0x23 },
      { label: '4000 RPM', value: 0x28 },
      { label: '4500 RPM', value: 0x2D },
      { label: '5000 RPM', value: 0x32 },
    ],
    notes: 'Optimal RPM varies by tire and conditions'
  },
  {
    id: 'line_lock',
    name: 'Line Lock',
    category: 'Performance & Variant',
    description: 'Enable line lock for burnouts and tire warming',
    did: 0xDE01,
    byteOffset: 0x12,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'For track use only - holds front brakes while spinning rears'
  },
  {
    id: 'line_lock_duration',
    name: 'Line Lock Duration',
    category: 'Performance & Variant',
    description: 'Maximum time line lock remains engaged',
    did: 0xDE01,
    byteOffset: 0x13,
    options: [
      { label: '10 seconds', value: 0x0A },
      { label: '15 seconds', value: 0x0F },
      { label: '20 seconds', value: 0x14 },
      { label: '30 seconds', value: 0x1E },
      { label: '45 seconds', value: 0x2D },
    ]
  },
  {
    id: 'power_modes_available',
    name: 'Power Modes Available',
    category: 'Performance & Variant',
    description: 'Which drive modes are accessible',
    did: 0xDE01,
    byteOffset: 0x20,
    options: [
      { label: 'Street Only', value: 0x01 },
      { label: 'Street + Sport', value: 0x02 },
      { label: 'Street + Sport + Track', value: 0x03 },
      { label: 'All Modes', value: 0x04, description: 'Street, Sport, Track, Custom' },
      { label: 'All + Drag', value: 0x05, description: 'Includes Drag Mode' },
      { label: 'SRT Modes', value: 0x06, description: 'Full SRT mode selection' },
    ]
  },
  {
    id: 'track_mode',
    name: 'Track Mode',
    category: 'Performance & Variant',
    description: 'Enable track mode for aggressive driving',
    did: 0xDE01,
    byteOffset: 0x21,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Adjusts throttle, transmission, and stability systems'
  },
  {
    id: 'drag_mode',
    name: 'Drag Mode',
    category: 'Performance & Variant',
    description: 'Enable drag strip optimized mode',
    did: 0xDE01,
    byteOffset: 0x21,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ],
    notes: 'Optimizes for straight-line acceleration'
  },
  {
    id: 'custom_mode',
    name: 'Custom Drive Mode',
    category: 'Performance & Variant',
    description: 'Enable user-configurable custom mode',
    did: 0xDE01,
    byteOffset: 0x21,
    bitMask: 0x04,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x04 },
    ]
  },
  {
    id: 'srt_performance_pages',
    name: 'SRT Performance Pages',
    category: 'Performance & Variant',
    description: 'Enable SRT performance monitoring pages',
    did: 0xDE01,
    byteOffset: 0x30,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Shows G-force meter, timers, gauges'
  },
  {
    id: 'srt_pages_timers',
    name: 'SRT Performance Timers',
    category: 'Performance & Variant',
    description: 'Enable 0-60, 1/8 mile, 1/4 mile timers',
    did: 0xDE01,
    byteOffset: 0x30,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'srt_pages_gauges',
    name: 'SRT Performance Gauges',
    category: 'Performance & Variant',
    description: 'Enable additional performance gauges',
    did: 0xDE01,
    byteOffset: 0x30,
    bitMask: 0x04,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x04 },
    ],
    notes: 'Oil temp, trans temp, boost pressure'
  },
  {
    id: 'srt_pages_dyno',
    name: 'SRT Dyno Test Page',
    category: 'Performance & Variant',
    description: 'Enable on-board dyno testing feature',
    did: 0xDE01,
    byteOffset: 0x30,
    bitMask: 0x08,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x08 },
    ]
  },
  {
    id: 'trans_brake',
    name: 'Trans Brake',
    category: 'Performance & Variant',
    description: 'Enable transmission brake for drag racing',
    did: 0xDE01,
    byteOffset: 0x40,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Demon/Super Stock feature - holds trans while building boost'
  },
  {
    id: 'trans_brake_rpm',
    name: 'Trans Brake Target RPM',
    category: 'Performance & Variant',
    description: 'RPM target when trans brake is engaged',
    did: 0xDE01,
    byteOffset: 0x41,
    options: [
      { label: '2000 RPM', value: 0x14 },
      { label: '2200 RPM', value: 0x16 },
      { label: '2350 RPM', value: 0x17, description: 'Demon default' },
      { label: '2500 RPM', value: 0x19 },
      { label: '2700 RPM', value: 0x1B },
    ]
  },
  {
    id: 'race_options_menu',
    name: 'Race Options Menu',
    category: 'Performance & Variant',
    description: 'Enable race options in driver settings',
    did: 0xDE01,
    byteOffset: 0x42,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'torque_reserve',
    name: 'Torque Reserve',
    category: 'Performance & Variant',
    description: 'Pre-load supercharger for faster launch',
    did: 0xDE01,
    byteOffset: 0x43,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Hellcat/Redeye/Demon feature - builds boost before launch'
  },
  {
    id: 'torque_reserve_level',
    name: 'Torque Reserve Level',
    category: 'Performance & Variant',
    description: 'Amount of pre-load torque reserve',
    did: 0xDE01,
    byteOffset: 0x44,
    options: [
      { label: 'Low', value: 0x01 },
      { label: 'Medium', value: 0x02 },
      { label: 'High', value: 0x03 },
      { label: 'Maximum', value: 0x04, description: 'Full boost pre-load' },
    ]
  },
  {
    id: 'launch_assist',
    name: 'Launch Assist',
    category: 'Performance & Variant',
    description: 'Electronic launch assist system',
    did: 0xDE01,
    byteOffset: 0x45,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'esc_sport_mode',
    name: 'ESC Sport Mode',
    category: 'Performance & Variant',
    description: 'Electronic Stability Control sport setting',
    did: 0xDE01,
    byteOffset: 0x50,
    options: [
      { label: 'Full On', value: 0x00, description: 'Maximum intervention' },
      { label: 'Sport', value: 0x01, description: 'Reduced intervention' },
      { label: 'Track', value: 0x02, description: 'Minimal intervention' },
      { label: 'Off', value: 0x03, description: 'ESC disabled - expert only' },
    ],
    notes: 'Adjusts traction and stability thresholds'
  },
  {
    id: 'traction_control_mode',
    name: 'Traction Control Mode',
    category: 'Performance & Variant',
    description: 'Traction control intervention level',
    did: 0xDE01,
    byteOffset: 0x51,
    options: [
      { label: 'Full', value: 0x00, description: 'Maximum traction control' },
      { label: 'Sport', value: 0x01, description: 'Allow controlled wheelspin' },
      { label: 'Minimal', value: 0x02, description: 'Reduced intervention' },
      { label: 'Off', value: 0x03, description: 'Traction control disabled' },
    ]
  },
  {
    id: 'paddle_shifter_mode',
    name: 'Paddle Shifter Mode',
    category: 'Performance & Variant',
    description: 'Paddle shifter behavior',
    did: 0xDE01,
    byteOffset: 0x52,
    options: [
      { label: 'Auto Return', value: 0x00, description: 'Returns to auto after delay' },
      { label: 'Manual Hold', value: 0x01, description: 'Stays in manual mode' },
      { label: 'Sport Auto', value: 0x02, description: 'Aggressive auto shifts' },
    ]
  },
  {
    id: 'shift_light',
    name: 'Shift Light',
    category: 'Performance & Variant',
    description: 'Enable shift indicator light',
    did: 0xDE01,
    byteOffset: 0x53,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'shift_light_rpm',
    name: 'Shift Light RPM',
    category: 'Performance & Variant',
    description: 'RPM at which shift light activates',
    did: 0xDE01,
    byteOffset: 0x54,
    options: [
      { label: '5000 RPM', value: 0x32 },
      { label: '5500 RPM', value: 0x37 },
      { label: '6000 RPM', value: 0x3C },
      { label: '6200 RPM', value: 0x3E },
      { label: '6400 RPM', value: 0x40 },
      { label: '6500 RPM', value: 0x41 },
    ]
  },
  {
    id: 'exhaust_mode',
    name: 'Active Exhaust Mode',
    category: 'Performance & Variant',
    description: 'Active exhaust valve settings',
    did: 0xDE01,
    byteOffset: 0x55,
    options: [
      { label: 'Auto', value: 0x00, description: 'Changes with drive mode' },
      { label: 'Quiet', value: 0x01, description: 'Valves closed - quieter' },
      { label: 'Normal', value: 0x02, description: 'Standard exhaust note' },
      { label: 'Loud', value: 0x03, description: 'Valves open - aggressive' },
      { label: 'Track', value: 0x04, description: 'Full open - maximum sound' },
    ],
    notes: 'Requires active exhaust option'
  },
  {
    id: 'suspension_mode',
    name: 'Adaptive Suspension Mode',
    category: 'Performance & Variant',
    description: 'Adaptive damper settings',
    did: 0xDE01,
    byteOffset: 0x56,
    options: [
      { label: 'Auto', value: 0x00, description: 'Automatic adjustment' },
      { label: 'Comfort', value: 0x01, description: 'Softer damping' },
      { label: 'Sport', value: 0x02, description: 'Firmer damping' },
      { label: 'Track', value: 0x03, description: 'Stiffest setting' },
    ],
    notes: 'Requires adaptive suspension'
  },
  {
    id: 'steering_mode',
    name: 'Steering Mode',
    category: 'Performance & Variant',
    description: 'Electric power steering weight',
    did: 0xDE01,
    byteOffset: 0x57,
    options: [
      { label: 'Comfort', value: 0x00, description: 'Light steering effort' },
      { label: 'Normal', value: 0x01, description: 'Balanced effort' },
      { label: 'Sport', value: 0x02, description: 'Heavy steering effort' },
    ]
  },
  {
    id: 'widebody_enabled',
    name: 'Widebody Mode',
    category: 'Performance & Variant',
    description: 'Enable widebody specific features',
    did: 0xDE01,
    byteOffset: 0x60,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Affects suspension and aero settings'
  },
  {
    id: 'power_chiller',
    name: 'Power Chiller',
    category: 'Performance & Variant',
    description: 'Enable A/C-based supercharger cooling',
    did: 0xDE01,
    byteOffset: 0x61,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Demon/Super Stock feature - uses A/C to cool intercooler'
  },
  {
    id: 'after_run_chiller',
    name: 'After-Run Chiller',
    category: 'Performance & Variant',
    description: 'Continue cooling after engine off',
    did: 0xDE01,
    byteOffset: 0x62,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: '1 minute', value: 0x01 },
      { label: '2 minutes', value: 0x02 },
      { label: '5 minutes', value: 0x05 },
      { label: '10 minutes', value: 0x0A },
    ],
    notes: 'Keeps supercharger cool between runs'
  },
  {
    id: 'drag_mode_suspension',
    name: 'Drag Mode Suspension',
    category: 'Performance & Variant',
    description: 'Suspension settings for drag racing',
    did: 0xDE01,
    byteOffset: 0x63,
    options: [
      { label: 'Street', value: 0x00 },
      { label: 'Soft Front / Stiff Rear', value: 0x01, description: 'Weight transfer optimized' },
      { label: 'Drag Preset', value: 0x02, description: 'Full drag optimization' },
    ],
    notes: 'Optimizes weight transfer for drag launches'
  },
  {
    id: 'rev_match',
    name: 'Automatic Rev Match',
    category: 'Performance & Variant',
    description: 'Automatic throttle blip on downshifts',
    did: 0xDE01,
    byteOffset: 0x64,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Manual transmission models'
  },

  // ============================================
  // ADDITIONAL PERFORMANCE FEATURES (DID 0xDE02)
  // ============================================
  {
    id: 'supercharger_display',
    name: 'Supercharger Boost Display',
    category: 'Performance & Variant',
    description: 'Show supercharger boost gauge',
    did: 0xDE02,
    byteOffset: 0x00,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Hellcat/Redeye/Demon models'
  },
  {
    id: 'intercooler_temp_display',
    name: 'Intercooler Temperature Display',
    category: 'Performance & Variant',
    description: 'Show intercooler coolant temperature',
    did: 0xDE02,
    byteOffset: 0x00,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'oil_temp_display',
    name: 'Oil Temperature Display',
    category: 'Performance & Variant',
    description: 'Show engine oil temperature gauge',
    did: 0xDE02,
    byteOffset: 0x00,
    bitMask: 0x04,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x04 },
    ]
  },
  {
    id: 'trans_temp_display',
    name: 'Transmission Temperature Display',
    category: 'Performance & Variant',
    description: 'Show transmission fluid temperature',
    did: 0xDE02,
    byteOffset: 0x00,
    bitMask: 0x08,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x08 },
    ]
  },
  {
    id: 'g_force_meter',
    name: 'G-Force Meter',
    category: 'Performance & Variant',
    description: 'Show real-time G-force display',
    did: 0xDE02,
    byteOffset: 0x01,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'timer_0_60',
    name: '0-60 MPH Timer',
    category: 'Performance & Variant',
    description: 'Built-in 0-60 mph acceleration timer',
    did: 0xDE02,
    byteOffset: 0x01,
    bitMask: 0x02,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x02 },
    ]
  },
  {
    id: 'timer_quarter_mile',
    name: 'Quarter Mile Timer',
    category: 'Performance & Variant',
    description: 'Built-in 1/4 mile elapsed time timer',
    did: 0xDE02,
    byteOffset: 0x01,
    bitMask: 0x04,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x04 },
    ]
  },
  {
    id: 'timer_eighth_mile',
    name: '1/8 Mile Timer',
    category: 'Performance & Variant',
    description: 'Built-in 1/8 mile elapsed time timer',
    did: 0xDE02,
    byteOffset: 0x01,
    bitMask: 0x08,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x08 },
    ]
  },
  {
    id: 'reaction_time_display',
    name: 'Reaction Time Display',
    category: 'Performance & Variant',
    description: 'Show reaction time from launch',
    did: 0xDE02,
    byteOffset: 0x02,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'brake_temp_warning',
    name: 'Brake Temperature Warning',
    category: 'Performance & Variant',
    description: 'Alert when brake temperatures are high',
    did: 0xDE02,
    byteOffset: 0x10,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Requires brake temperature sensors'
  },
  {
    id: 'drive_mode_memory',
    name: 'Drive Mode Memory',
    category: 'Performance & Variant',
    description: 'Remember last drive mode on restart',
    did: 0xDE02,
    byteOffset: 0x11,
    options: [
      { label: 'Reset to Default', value: 0x00, description: 'Always start in default mode' },
      { label: 'Remember Last', value: 0x01, description: 'Keep previous mode' },
      { label: 'Remember Sport', value: 0x02, description: 'Remember if Sport was selected' },
      { label: 'Remember All', value: 0x03, description: 'Remember all mode settings' },
    ]
  },
  {
    id: 'launch_warning',
    name: 'Launch Control Warning',
    category: 'Performance & Variant',
    description: 'Show warning before launch control activation',
    did: 0xDE02,
    byteOffset: 0x12,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ]
  },
  {
    id: 'performance_data_recorder',
    name: 'Performance Data Recorder',
    category: 'Performance & Variant',
    description: 'Record performance data to USB',
    did: 0xDE02,
    byteOffset: 0x20,
    bitMask: 0x01,
    options: [
      { label: 'Disabled', value: 0x00 },
      { label: 'Enabled', value: 0x01 },
    ],
    notes: 'Requires compatible USB storage'
  },
  {
    id: 'valet_speed_limit',
    name: 'Valet Speed Limit',
    category: 'Performance & Variant',
    description: 'Maximum speed in valet mode',
    did: 0xDE02,
    byteOffset: 0x21,
    options: [
      { label: '25 mph', value: 0x19 },
      { label: '35 mph', value: 0x23 },
      { label: '45 mph', value: 0x2D },
      { label: '55 mph', value: 0x37 },
    ]
  },
  {
    id: 'valet_rpm_limit',
    name: 'Valet RPM Limit',
    category: 'Performance & Variant',
    description: 'Maximum RPM in valet mode',
    did: 0xDE02,
    byteOffset: 0x22,
    options: [
      { label: '3000 RPM', value: 0x1E },
      { label: '3500 RPM', value: 0x23 },
      { label: '4000 RPM', value: 0x28 },
      { label: '4500 RPM', value: 0x2D },
    ]
  },
  {
    id: 'throttle_response',
    name: 'Throttle Response',
    category: 'Performance & Variant',
    description: 'Accelerator pedal sensitivity',
    did: 0xDE02,
    byteOffset: 0x30,
    options: [
      { label: 'Comfort', value: 0x00, description: 'Smooth, progressive' },
      { label: 'Sport', value: 0x01, description: 'Quick response' },
      { label: 'Track', value: 0x02, description: 'Aggressive, immediate' },
    ]
  },
  {
    id: 'cylinder_deactivation',
    name: 'Cylinder Deactivation (MDS)',
    category: 'Performance & Variant',
    description: 'Multi-Displacement System control',
    did: 0xDE02,
    byteOffset: 0x31,
    options: [
      { label: 'Auto', value: 0x00, description: 'Automatic based on load' },
      { label: 'Always Off', value: 0x01, description: 'All cylinders always active' },
    ],
    notes: 'Disabling improves performance but reduces fuel economy'
  },
];

export function getPresetsByCategory(category: BCMFeatureCategory): BCMFeaturePreset[] {
  return BCM_FEATURE_PRESETS.filter(p => p.category === category);
}

export function getPresetById(id: string): BCMFeaturePreset | undefined {
  return BCM_FEATURE_PRESETS.find(p => p.id === id);
}

export function getAllCategories(): BCMFeatureCategory[] {
  const categories = new Set(BCM_FEATURE_PRESETS.map(p => p.category));
  return Array.from(categories) as BCMFeatureCategory[];
}

export function getPresetsByDID(did: number): BCMFeaturePreset[] {
  return BCM_FEATURE_PRESETS.filter(p => p.did === did);
}

export function getPresetCount(): number {
  return BCM_FEATURE_PRESETS.length;
}

export function getPerformancePresets(): BCMFeaturePreset[] {
  return BCM_FEATURE_PRESETS.filter(p => p.category === 'Performance & Variant');
}
