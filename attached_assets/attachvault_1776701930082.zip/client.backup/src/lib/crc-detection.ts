export interface CrcAlgorithm {
  name: string;
  type: "CRC16" | "CRC32";
  polynomial: number;
  initialValue: number;
  finalXor: number;
  reflectInput: boolean;
  reflectOutput: boolean;
}

export interface DetectedCrc {
  algorithm: CrcAlgorithm;
  offset: number;
  value: number;
  confidence: number;
  description: string;
}

export const CRC_ALGORITHMS: CrcAlgorithm[] = [
  {
    name: "CRC-16/MODBUS",
    type: "CRC16",
    polynomial: 0x8005,
    initialValue: 0xffff,
    finalXor: 0x0000,
    reflectInput: true,
    reflectOutput: true,
  },
  {
    name: "CRC-16/IBM",
    type: "CRC16",
    polynomial: 0x8005,
    initialValue: 0x0000,
    finalXor: 0x0000,
    reflectInput: true,
    reflectOutput: true,
  },
  {
    name: "CRC-16/CCITT-FALSE",
    type: "CRC16",
    polynomial: 0x1021,
    initialValue: 0xffff,
    finalXor: 0x0000,
    reflectInput: false,
    reflectOutput: false,
  },
  {
    name: "CRC-16/XMODEM",
    type: "CRC16",
    polynomial: 0x1021,
    initialValue: 0x0000,
    finalXor: 0x0000,
    reflectInput: false,
    reflectOutput: false,
  },
  {
    name: "CRC-16/KERMIT",
    type: "CRC16",
    polynomial: 0x1021,
    initialValue: 0x0000,
    finalXor: 0x0000,
    reflectInput: true,
    reflectOutput: true,
  },
  {
    name: "CRC-32",
    type: "CRC32",
    polynomial: 0xedb88320,
    initialValue: 0xffffffff,
    finalXor: 0xffffffff,
    reflectInput: true,
    reflectOutput: true,
  },
  {
    name: "CRC-32/BZIP2",
    type: "CRC32",
    polynomial: 0x04c11db7,
    initialValue: 0xffffffff,
    finalXor: 0xffffffff,
    reflectInput: false,
    reflectOutput: false,
  },
];

function reflectByte(byte: number): number {
  let reflected = 0;
  for (let i = 0; i < 8; i++) {
    if (byte & (1 << i)) {
      reflected |= 1 << (7 - i);
    }
  }
  return reflected;
}

function reflectWord16(word: number): number {
  let reflected = 0;
  for (let i = 0; i < 16; i++) {
    if (word & (1 << i)) {
      reflected |= 1 << (15 - i);
    }
  }
  return reflected;
}

function reflectWord32(word: number): number {
  let reflected = 0;
  for (let i = 0; i < 32; i++) {
    if (word & (1 << i)) {
      reflected |= 1 << (31 - i);
    }
  }
  return reflected >>> 0;
}

export function calculateCrc16(
  data: Uint8Array,
  algorithm: CrcAlgorithm
): number {
  let crc = algorithm.initialValue;

  for (let i = 0; i < data.length; i++) {
    let byte = data[i];

    if (algorithm.reflectInput) {
      byte = reflectByte(byte);
    }

    crc ^= byte << 8;

    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ algorithm.polynomial;
      } else {
        crc = crc << 1;
      }
    }

    crc &= 0xffff;
  }

  if (algorithm.reflectOutput) {
    crc = reflectWord16(crc);
  }

  return (crc ^ algorithm.finalXor) & 0xffff;
}

export function calculateCrc32(
  data: Uint8Array,
  algorithm: CrcAlgorithm
): number {
  let crc = algorithm.initialValue;

  for (let i = 0; i < data.length; i++) {
    let byte = data[i];

    if (algorithm.reflectInput) {
      byte = reflectByte(byte);
    }

    crc ^= byte << 24;

    for (let j = 0; j < 8; j++) {
      if (crc & 0x80000000) {
        crc = (crc << 1) ^ algorithm.polynomial;
      } else {
        crc = crc << 1;
      }
    }

    crc = crc >>> 0;
  }

  if (algorithm.reflectOutput) {
    crc = reflectWord32(crc);
  }

  return (crc ^ algorithm.finalXor) >>> 0;
}

export function calculateCrcWithAlgorithm(
  data: Uint8Array,
  algorithm: CrcAlgorithm
): number {
  if (algorithm.type === "CRC16") {
    return calculateCrc16(data, algorithm);
  } else {
    return calculateCrc32(data, algorithm);
  }
}

function calculateConfidence(
  offset: number,
  fileSize: number
): number {
  let confidence = 50;

  if (offset === fileSize - 2 || offset === fileSize - 4) {
    confidence = 95;
  } else if (offset > fileSize - 0x100) {
    confidence = 85;
  }

  const knownOffsets = [0x7ffe, 0xfffe, 0x3ffe, 0x1ffe];
  if (knownOffsets.includes(offset)) {
    confidence = 90;
  }

  return confidence;
}

function readUInt16LE(data: Uint8Array, offset: number): number {
  return data[offset] | (data[offset + 1] << 8);
}

function readUInt16BE(data: Uint8Array, offset: number): number {
  return (data[offset] << 8) | data[offset + 1];
}

function readUInt32LE(data: Uint8Array, offset: number): number {
  return (
    data[offset] |
    (data[offset + 1] << 8) |
    (data[offset + 2] << 16) |
    (data[offset + 3] << 24)
  ) >>> 0;
}

function readUInt32BE(data: Uint8Array, offset: number): number {
  return (
    (data[offset] << 24) |
    (data[offset + 1] << 16) |
    (data[offset + 2] << 8) |
    data[offset + 3]
  ) >>> 0;
}

function testCrc16AtOffset(
  data: Uint8Array,
  offset: number,
  algorithm: CrcAlgorithm
): DetectedCrc | null {
  const storedCrcLE = readUInt16LE(data, offset);
  const storedCrcBE = readUInt16BE(data, offset);

  const dataForCrc = new Uint8Array(data.length - 2);
  dataForCrc.set(data.slice(0, offset));
  dataForCrc.set(data.slice(offset + 2), offset);

  const calculatedCrc = calculateCrc16(dataForCrc, algorithm);

  if (calculatedCrc === storedCrcLE) {
    return {
      algorithm,
      offset,
      value: storedCrcLE,
      confidence: calculateConfidence(offset, data.length),
      description: `${algorithm.name} (Little Endian) at 0x${offset.toString(16).toUpperCase()}`,
    };
  } else if (calculatedCrc === storedCrcBE) {
    return {
      algorithm,
      offset,
      value: storedCrcBE,
      confidence: calculateConfidence(offset, data.length),
      description: `${algorithm.name} (Big Endian) at 0x${offset.toString(16).toUpperCase()}`,
    };
  }

  return null;
}

function testCrc32AtOffset(
  data: Uint8Array,
  offset: number,
  algorithm: CrcAlgorithm
): DetectedCrc | null {
  const storedCrcLE = readUInt32LE(data, offset);
  const storedCrcBE = readUInt32BE(data, offset);

  const dataForCrc = new Uint8Array(data.length - 4);
  dataForCrc.set(data.slice(0, offset));
  dataForCrc.set(data.slice(offset + 4), offset);

  const calculatedCrc = calculateCrc32(dataForCrc, algorithm);

  if (calculatedCrc === storedCrcLE) {
    return {
      algorithm,
      offset,
      value: storedCrcLE,
      confidence: calculateConfidence(offset, data.length),
      description: `${algorithm.name} (Little Endian) at 0x${offset.toString(16).toUpperCase()}`,
    };
  } else if (calculatedCrc === storedCrcBE) {
    return {
      algorithm,
      offset,
      value: storedCrcBE,
      confidence: calculateConfidence(offset, data.length),
      description: `${algorithm.name} (Big Endian) at 0x${offset.toString(16).toUpperCase()}`,
    };
  }

  return null;
}

export function detectCrc(data: Uint8Array): DetectedCrc[] {
  const detectedCrcs: DetectedCrc[] = [];

  const candidateOffsets: number[] = [
    data.length - 2,
    data.length - 4,
    0x7ffe,
    0xfffe,
    0x3ffe,
    0x1ffe,
  ];

  for (let offset = 0; offset < data.length - 4; offset += 0x100) {
    candidateOffsets.push(offset);
  }

  for (const algorithm of CRC_ALGORITHMS) {
    for (const offset of candidateOffsets) {
      if (algorithm.type === "CRC16" && offset >= 0 && offset < data.length - 1) {
        const result = testCrc16AtOffset(data, offset, algorithm);
        if (result) {
          detectedCrcs.push(result);
        }
      } else if (algorithm.type === "CRC32" && offset >= 0 && offset < data.length - 3) {
        const result = testCrc32AtOffset(data, offset, algorithm);
        if (result) {
          detectedCrcs.push(result);
        }
      }
    }
  }

  detectedCrcs.sort((a, b) => b.confidence - a.confidence);

  return detectedCrcs.slice(0, 5);
}

export function applyCrc(
  data: Uint8Array,
  detectedCrc: DetectedCrc
): Uint8Array {
  const buffer = new Uint8Array(data);
  const crcSize = detectedCrc.algorithm.type === "CRC16" ? 2 : 4;

  const dataForCrc = new Uint8Array(data.length - crcSize);
  dataForCrc.set(data.slice(0, detectedCrc.offset));
  dataForCrc.set(data.slice(detectedCrc.offset + crcSize), detectedCrc.offset);

  let newCrc: number;
  if (detectedCrc.algorithm.type === "CRC16") {
    newCrc = calculateCrc16(dataForCrc, detectedCrc.algorithm);
    buffer[detectedCrc.offset] = newCrc & 0xff;
    buffer[detectedCrc.offset + 1] = (newCrc >> 8) & 0xff;
  } else {
    newCrc = calculateCrc32(dataForCrc, detectedCrc.algorithm);
    buffer[detectedCrc.offset] = newCrc & 0xff;
    buffer[detectedCrc.offset + 1] = (newCrc >> 8) & 0xff;
    buffer[detectedCrc.offset + 2] = (newCrc >> 16) & 0xff;
    buffer[detectedCrc.offset + 3] = (newCrc >> 24) & 0xff;
  }

  return buffer;
}

export function crcToHex(crc: number, is32Bit: boolean = false): string {
  if (is32Bit) {
    return crc.toString(16).toUpperCase().padStart(8, '0');
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

export function getAlgorithmByName(name: string): CrcAlgorithm | undefined {
  return CRC_ALGORITHMS.find(a => a.name === name);
}

/**
 * Calculate VIN block CRC using CRC-16/CCITT-FALSE
 * Algorithm reverse-engineered from CDA.swf (binascii.crc_hqx with init 0xFFFF)
 * This is the standard algorithm used by FCA/Stellantis for VIN checksums
 * 
 * @param vin - 17-character VIN string
 * @returns 2-byte CRC as Uint8Array (Big Endian)
 */
export function calculateVinCrc(vin: string): Uint8Array {
  if (vin.length !== 17) {
    throw new Error("VIN must be exactly 17 characters");
  }
  
  const vinBytes = new TextEncoder().encode(vin);
  const ccittFalse = CRC_ALGORITHMS.find(a => a.name === "CRC-16/CCITT-FALSE")!;
  const crc = calculateCrc16(vinBytes, ccittFalse);
  
  // Return as Big Endian (high byte first) per FCA standard
  return new Uint8Array([
    (crc >> 8) & 0xFF,
    crc & 0xFF
  ]);
}

/**
 * Verify a VIN's CRC checksum
 * @param vin - 17-character VIN string  
 * @param expectedCrc - 2-byte expected CRC (Big Endian)
 * @returns true if CRC matches
 */
export function verifyVinCrc(vin: string, expectedCrc: Uint8Array): boolean {
  const calculated = calculateVinCrc(vin);
  return calculated[0] === expectedCrc[0] && calculated[1] === expectedCrc[1];
}

// ========== RFHUB-SPECIFIC CHECKSUM ALGORITHM ==========
// RFHUB (SmartBox/KeyFob) uses a complement checksum, not CRC
// VINs are stored REVERSED at 4 locations with 2-byte checksum after each

export interface RfhubVinBlock {
  offset: number;
  markerOffset: number;
  vinOffset: number;
  checksumOffset: number;
  marker: number;
  vinBytes: Uint8Array;
  vinReversed: string;
  vinForward: string;
  checksum: Uint8Array;
  checksumValid: boolean;
}

export interface RfhubFormat {
  isRfhub: boolean;
  version: number;
  target: number;
  vinBlocks: RfhubVinBlock[];
  versionOffset: number;
}

const RFHUB_VIN_OFFSETS = [0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1];
const RFHUB_VERSION_OFFSET = 0x0EF4;

/**
 * DERIVE the actual checksum target from the file data itself
 * This is the ONLY reliable way since different vehicles/versions use different targets
 * 
 * Formula: target = sum(VIN bytes) + storedChecksum
 * 
 * We calculate this from all 4 VIN blocks and ensure they all agree
 * If they don't agree, something is wrong with the file
 * 
 * @param data - The RFHUB file data
 * @returns The derived target value, or null if cannot be determined
 */
function deriveRfhubTarget(data: Uint8Array): { target: number; confidence: 'high' | 'medium' | 'low' } | null {
  if (data.length < 0x1000) {
    return null;
  }
  
  const derivedTargets: number[] = [];
  
  for (const vinOffset of RFHUB_VIN_OFFSETS) {
    if (vinOffset + 19 > data.length) continue;
    
    const vinBytes = data.slice(vinOffset, vinOffset + 17);
    const checksumOffset = vinOffset + 17;
    const checksumBytes = data.slice(checksumOffset, checksumOffset + 2);
    
    // Check if VIN bytes are valid ASCII
    const isValidAscii = vinBytes.every(b => 
      (b >= 0x30 && b <= 0x39) || // 0-9
      (b >= 0x41 && b <= 0x5A) || // A-Z
      (b >= 0x61 && b <= 0x7A)    // a-z
    );
    
    if (!isValidAscii) continue;
    
    // Calculate sum of VIN bytes
    let vinSum = 0;
    for (let i = 0; i < vinBytes.length; i++) {
      vinSum += vinBytes[i];
    }
    
    // Read stored checksum (little-endian)
    const storedChecksum = checksumBytes[0] | (checksumBytes[1] << 8);
    
    // Derive target: target = vinSum + storedChecksum
    const derivedTarget = (vinSum + storedChecksum) & 0xFFFF;
    derivedTargets.push(derivedTarget);
  }
  
  if (derivedTargets.length === 0) {
    return null;
  }
  
  // Check if all blocks agree on the same target
  const firstTarget = derivedTargets[0];
  const allAgree = derivedTargets.every(t => t === firstTarget);
  
  if (allAgree && derivedTargets.length >= 4) {
    return { target: firstTarget, confidence: 'high' };
  } else if (allAgree && derivedTargets.length >= 2) {
    return { target: firstTarget, confidence: 'medium' };
  } else if (derivedTargets.length >= 1) {
    // Use mode (most common value) if they don't agree
    const counts: Record<number, number> = {};
    for (const t of derivedTargets) {
      counts[t] = (counts[t] || 0) + 1;
    }
    let modeTarget = derivedTargets[0];
    let maxCount = 0;
    for (const key of Object.keys(counts)) {
      const t = Number(key);
      const count = counts[t];
      if (count > maxCount) {
        maxCount = count;
        modeTarget = t;
      }
    }
    return { target: modeTarget, confidence: 'low' };
  }
  
  return null;
}

/**
 * Fallback lookup table for RFHUB target based on version byte
 * Only used if we cannot derive from file data
 * 
 * IMPORTANT: These are KNOWN values verified from real files:
 * - Version 0x04: Target 0x4FA (verified from production file 2B3CJ4DV6AH300549)
 * 
 * Other versions may need different targets - always prefer deriveRfhubTarget()
 */
function getFallbackRfhubTarget(version: number): number {
  switch (version) {
    case 0x04:
      return 0x4FA;
    case 0x01:
    default:
      return 0x6F8;
  }
}

/**
 * Calculate RFHUB complement checksum for a VIN
 * Formula: checksum = TARGET - sum(VIN bytes)
 * Result is stored as little-endian 16-bit value
 * 
 * @param vinBytes - 17 bytes of the reversed VIN (as stored in RFHUB)
 * @param target - The target sum (0x4FA or 0x6F8 based on version)
 * @returns 2-byte checksum as Uint8Array (Little Endian)
 */
export function calculateRfhubChecksum(vinBytes: Uint8Array, target: number): Uint8Array {
  if (vinBytes.length !== 17) {
    throw new Error("VIN bytes must be exactly 17");
  }
  
  let sum = 0;
  for (let i = 0; i < vinBytes.length; i++) {
    sum += vinBytes[i];
  }
  
  const checksum = (target - sum) & 0xFFFF;
  
  return new Uint8Array([
    checksum & 0xFF,
    (checksum >> 8) & 0xFF
  ]);
}

/**
 * Verify an RFHUB checksum
 */
export function verifyRfhubChecksum(vinBytes: Uint8Array, expectedChecksum: Uint8Array, target: number): boolean {
  const calculated = calculateRfhubChecksum(vinBytes, target);
  return calculated[0] === expectedChecksum[0] && calculated[1] === expectedChecksum[1];
}

/**
 * Detect if a binary file is in RFHUB format
 * RFHUB files have:
 * - 4 copies of reversed VIN at specific offsets
 * - Version byte at 0x0EF4
 * - Complement checksums after each VIN
 * 
 * IMPORTANT: Target is now DERIVED from actual file data, not hardcoded!
 * This ensures we work with any vehicle regardless of target value.
 */
export function detectRfhubFormat(data: Uint8Array): RfhubFormat {
  const result: RfhubFormat = {
    isRfhub: false,
    version: 0,
    target: 0,
    vinBlocks: [],
    versionOffset: RFHUB_VERSION_OFFSET
  };
  
  if (data.length < 0x1000) {
    return result;
  }
  
  const version = data[RFHUB_VERSION_OFFSET];
  
  // CRITICAL: Derive the target from actual file data, not from lookup table
  // This is the only reliable way to handle different vehicle configurations
  const derivedResult = deriveRfhubTarget(data);
  const target = derivedResult ? derivedResult.target : getFallbackRfhubTarget(version);
  
  result.version = version;
  result.target = target;
  
  let validBlocks = 0;
  
  for (const vinOffset of RFHUB_VIN_OFFSETS) {
    if (vinOffset + 19 > data.length) continue;
    
    const markerOffset = vinOffset - 1;
    const checksumOffset = vinOffset + 17;
    
    const marker = data[markerOffset];
    const vinBytes = data.slice(vinOffset, vinOffset + 17);
    const checksum = data.slice(checksumOffset, checksumOffset + 2);
    
    const vinReversed = String.fromCharCode.apply(null, Array.from(vinBytes));
    const vinForward = vinReversed.split('').reverse().join('');
    
    const isValidAscii = vinBytes.every(b => 
      (b >= 0x30 && b <= 0x39) || // 0-9
      (b >= 0x41 && b <= 0x5A) || // A-Z
      (b >= 0x61 && b <= 0x7A)    // a-z
    );
    
    if (!isValidAscii) continue;
    
    const checksumValid = verifyRfhubChecksum(vinBytes, checksum, target);
    
    result.vinBlocks.push({
      offset: vinOffset,
      markerOffset,
      vinOffset,
      checksumOffset,
      marker,
      vinBytes: new Uint8Array(vinBytes),
      vinReversed,
      vinForward,
      checksum: new Uint8Array(checksum),
      checksumValid
    });
    
    if (checksumValid) {
      validBlocks++;
    }
  }
  
  // File is RFHUB if we found at least 2 VIN blocks
  // With derived target, ALL blocks should validate
  result.isRfhub = result.vinBlocks.length >= 2 && validBlocks >= 1;
  
  return result;
}

/**
 * Patch all VIN blocks in an RFHUB file with a new VIN and recalculate checksums
 * 
 * @param data - The original RFHUB binary file
 * @param newVin - The new 17-character VIN (forward order)
 * @returns New binary with patched VINs and checksums
 */
export function patchRfhubVin(data: Uint8Array, newVin: string): Uint8Array {
  if (newVin.length !== 17) {
    throw new Error("VIN must be exactly 17 characters");
  }
  
  const rfhubInfo = detectRfhubFormat(data);
  if (!rfhubInfo.isRfhub) {
    throw new Error("File is not recognized as RFHUB format");
  }
  
  const result = new Uint8Array(data);
  const reversedVin = newVin.split('').reverse().join('');
  const reversedVinBytes = new TextEncoder().encode(reversedVin);
  const checksum = calculateRfhubChecksum(reversedVinBytes, rfhubInfo.target);
  
  for (const block of rfhubInfo.vinBlocks) {
    for (let i = 0; i < 17; i++) {
      result[block.vinOffset + i] = reversedVinBytes[i];
    }
    
    result[block.checksumOffset] = checksum[0];
    result[block.checksumOffset + 1] = checksum[1];
  }
  
  return result;
}

// ========== BCM D-FLASH SPECIFIC FORMAT ==========
// BCM D-FLASH (64KB) stores VINs at 4 locations with prefix/suffix markers
// Format: [Prefix: 2 bytes "FF"/"FV"/"FW"/"FR"] [VIN: 17 bytes] [Suffix: 2 bytes "-V"]
// Uses FEE (Flash EEPROM Emulation) system with multiple CRC checksums

export interface BcmVinBlock {
  blockOffset: number;      // Start of block (prefix)
  prefixOffset: number;     // Where prefix starts
  vinOffset: number;        // Where VIN starts (prefix + 2)
  suffixOffset: number;     // Where suffix starts (VIN + 17)
  prefix: string;           // "FF", "FV", "FW", or "FR"
  vin: string;              // 17-character VIN
  suffix: string;           // Usually "-V"
}

export interface BcmDflashFormat {
  isBcmDflash: boolean;
  fileSize: number;
  hasFeeHeader: boolean;
  vinBlocks: BcmVinBlock[];
}

// BCM D-FLASH has VINs at varying offsets depending on BCM version
// Each set has 4 VIN blocks with 0x20 spacing
const BCM_DFLASH_VIN_OFFSET_SETS = [
  [0x1298, 0x12B8, 0x12D8, 0x12F8],  // BCM variant A
  [0x12B8, 0x12D8, 0x12F8, 0x1318],  // BCM variant A-Alternate (verified with production files)
  [0x1328, 0x1348, 0x1368, 0x1388],  // BCM variant B
  [0x5328, 0x5348, 0x5368, 0x5388],  // BCM variant C
  [0x52B8, 0x52D8, 0x52F8, 0x5318],  // BCM variant D (DFLASH19CHAL)
];

// Expected prefix bytes: single letter + null byte
// Block 1: "F\0" (0x46 0x00), Block 2: "V\0" (0x56 0x00), etc.
const BCM_VIN_PREFIX_BYTES = [
  [0x46, 0x00],  // "F\0" for block 1
  [0x56, 0x00],  // "V\0" for block 2  
  [0x57, 0x00],  // "W\0" for block 3
  [0x52, 0x00],  // "R\0" for block 4
];

/**
 * Check if a byte sequence is valid VIN characters
 */
function isVinBytes(bytes: Uint8Array): boolean {
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    // 0-9, A-Z except I, O, Q
    const isDigit = b >= 0x30 && b <= 0x39;
    const isLetter = b >= 0x41 && b <= 0x5A && b !== 0x49 && b !== 0x4F && b !== 0x51;
    if (!isDigit && !isLetter) return false;
  }
  return true;
}

/**
 * Detect BCM D-FLASH format
 * 
 * BCM D-FLASH files are typically 64KB (65536 bytes) and contain:
 * - FEE header at start ("FEE1000")
 * - VINs at 4 locations with prefix markers (varies by BCM version)
 * - Prefix markers: "F\0", "V\0", "W\0", "R\0" (letter + null byte)
 * - CRC-16 immediately after each VIN
 * 
 * @param data - The binary file data
 * @returns BCM D-FLASH format info
 */
export function detectBcmDflashFormat(data: Uint8Array): BcmDflashFormat {
  const result: BcmDflashFormat = {
    isBcmDflash: false,
    fileSize: data.length,
    hasFeeHeader: false,
    vinBlocks: [],
  };
  
  // Check for typical BCM D-FLASH size (64KB or 128KB)
  const isBcmSize = data.length === 65536 || data.length === 131072;
  if (!isBcmSize) {
    return result; // Early exit if file size doesn't match
  }
  
  // Check for FEE header signature ("FEE1000" at offset ~0x04)
  if (data.length >= 12) {
    const feeBytes = data.slice(4, 11);
    const feeString = new TextDecoder().decode(feeBytes);
    result.hasFeeHeader = feeString === 'FEE1000';
  }
  
  // Try each offset set to find the one that matches this BCM variant
  for (const offsetSet of BCM_DFLASH_VIN_OFFSET_SETS) {
    const blocksFound: BcmVinBlock[] = [];
    let validPrefixCount = 0;
    let consistentVin = true;
    let firstVin = '';
    
    // Check all 4 blocks in this offset set
    for (let i = 0; i < 4; i++) {
      const vinOffset = offsetSet[i];
      const expectedPrefix = BCM_VIN_PREFIX_BYTES[i];
      
      // Check if offset is within file bounds
      // VIN block structure: [prefix 2] [VIN 17] [CRC 2] = 21 bytes
      if (vinOffset + 17 > data.length) continue;
      
      // Read prefix (2 bytes before VIN offset - the offset IS the VIN start)
      const prefixOffset = vinOffset - 2;
      if (prefixOffset < 0) continue;
      
      const prefixBytes = data.slice(prefixOffset, prefixOffset + 2);
      const prefixValid = prefixBytes[0] === expectedPrefix[0] && prefixBytes[1] === expectedPrefix[1];
      
      // Read VIN (17 bytes at offset)
      const vinBytes = data.slice(vinOffset, vinOffset + 17);
      
      // Read CRC (2 bytes after VIN)
      const crcOffset = vinOffset + 17;
      const crcBytes = data.slice(crcOffset, crcOffset + 2);
      
      // Check if VIN contains valid characters
      if (!isVinBytes(vinBytes)) continue;
      
      const vin = new TextDecoder().decode(vinBytes);
      const prefix = new TextDecoder().decode(prefixBytes);
      
      // Track if all VINs are the same (they should be)
      if (firstVin === '') {
        firstVin = vin;
      } else if (vin !== firstVin) {
        consistentVin = false;
      }
      
      if (prefixValid) {
        validPrefixCount++;
      }
      
      blocksFound.push({
        blockOffset: prefixOffset,
        prefixOffset: prefixOffset,
        vinOffset,
        suffixOffset: crcOffset, // CRC position (was called suffix before)
        prefix,
        vin,
        suffix: crcBytes.toString(), // Store CRC bytes for reference
      });
    }
    
    // This offset set is valid if:
    // - Found at least 4 VIN blocks with valid prefixes
    // - All VINs are consistent (same value)
    if (blocksFound.length >= 4 && validPrefixCount >= 4 && consistentVin) {
      result.vinBlocks = blocksFound;
      result.isBcmDflash = true;
      return result;
    }
    
    // Fallback: Accept if we have FEE header and 4 valid VINs even without perfect prefixes
    if (result.hasFeeHeader && blocksFound.length >= 4 && consistentVin) {
      result.vinBlocks = blocksFound;
      result.isBcmDflash = true;
      return result;
    }
  }
  
  return result;
}

/**
 * Validate file checksums before patching
 * Prevents accidental corruption by verifying checksums match expected algorithms
 * 
 * @param data - The binary file data
 * @returns true if all detected checksums are valid, false if any mismatch found
 */
export function validateFileChecksumsSafe(data: Uint8Array): boolean {
  const verification = verifyFileChecksums(data);
  
  if (!verification.detected) {
    // Unknown format - safer to proceed with caution
    return true;
  }
  
  // For known formats, ALL checksums must be valid before patching
  // This prevents corrupting already-bad files
  return verification.allValid;
}

/**
 * Patch all VIN blocks in a BCM D-FLASH file with a new VIN
 * 
 * This updates all 4 VIN locations and recalculates CRC-16 for each block.
 * BCM D-FLASH structure: [prefix 2] [VIN 17] [CRC 2]
 * 
 * @param data - The original BCM D-FLASH binary file
 * @param newVin - The new 17-character VIN
 * @returns New binary with patched VINs and updated CRCs
 */
export function patchBcmDflashVin(data: Uint8Array, newVin: string): Uint8Array {
  if (newVin.length !== 17) {
    throw new Error("VIN must be exactly 17 characters");
  }
  
  const bcmInfo = detectBcmDflashFormat(data);
  if (!bcmInfo.isBcmDflash) {
    throw new Error("File is not recognized as BCM D-FLASH format");
  }
  
  const result = new Uint8Array(data);
  const vinBytes = new TextEncoder().encode(newVin);
  
  // BCM D-FLASH uses CRC-16/CCITT-FALSE for VIN block checksums
  const ccittFalse = CRC_ALGORITHMS.find(a => a.name === "CRC-16/CCITT-FALSE")!;
  
  // Patch each VIN block
  for (const block of bcmInfo.vinBlocks) {
    // Write new VIN bytes
    for (let i = 0; i < 17; i++) {
      result[block.vinOffset + i] = vinBytes[i];
    }
    
    // Calculate CRC over VIN only (17 bytes)
    // The CRC covers just the VIN, not the prefix
    const crc = calculateCrc16(vinBytes, ccittFalse);
    
    // CRC is stored at suffixOffset (immediately after VIN)
    const crcOffset = block.suffixOffset;
    if (crcOffset + 2 <= result.length) {
      // Write CRC in big-endian (FCA standard)
      result[crcOffset] = (crc >> 8) & 0xFF;
      result[crcOffset + 1] = crc & 0xFF;
    }
  }
  
  return result;
}

// ========== UNIFIED CHECKSUM VERIFICATION FOR UI DISPLAY ==========

export interface ChecksumBlockInfo {
  blockNumber: number;
  vinOffset: number;
  checksumOffset: number;
  vin: string;
  storedChecksum: string;
  calculatedChecksum: string;
  isValid: boolean;
}

export interface FileFormatVerification {
  detected: boolean;
  formatType: 'RFHUB' | 'BCM_DFLASH' | 'UNKNOWN';
  formatName: string;
  algorithm: string;
  fileSize: number;
  variant?: string;
  version?: string;
  blocks: ChecksumBlockInfo[];
  allValid: boolean;
  validCount: number;
  totalCount: number;
}

export function verifyFileChecksums(data: Uint8Array): FileFormatVerification {
  const rfhubInfo = detectRfhubFormat(data);
  
  if (rfhubInfo.isRfhub) {
    const blocks: ChecksumBlockInfo[] = rfhubInfo.vinBlocks.map((block, i) => {
      const storedCs = ((block.checksum[1] << 8) | block.checksum[0]);
      const calcBytes = calculateRfhubChecksum(block.vinBytes, rfhubInfo.target);
      const calcCs = ((calcBytes[1] << 8) | calcBytes[0]);
      
      const isValid = storedCs === calcCs;
      
      return {
        blockNumber: i + 1,
        vinOffset: block.vinOffset,
        checksumOffset: block.checksumOffset,
        vin: block.vinForward,
        storedChecksum: '0x' + storedCs.toString(16).toUpperCase().padStart(4, '0'),
        calculatedChecksum: '0x' + calcCs.toString(16).toUpperCase().padStart(4, '0'),
        isValid,
      };
    });
    
    const validCount = blocks.filter(b => b.isValid).length;
    
    return {
      detected: true,
      formatType: 'RFHUB',
      formatName: data.length === 4096 ? 'RFHUB / Journey SmartBox (4KB EEE)' : 'RFHUB Format',
      algorithm: 'Complement Checksum (TARGET - VIN_sum)',
      fileSize: data.length,
      version: '0x' + rfhubInfo.version.toString(16).toUpperCase().padStart(2, '0') + 
               ' (Target: 0x' + rfhubInfo.target.toString(16).toUpperCase() + ')',
      blocks,
      allValid: validCount === blocks.length,
      validCount,
      totalCount: blocks.length,
    };
  }
  
  const bcmInfo = detectBcmDflashFormat(data);
  
  if (bcmInfo.isBcmDflash) {
    const ccittFalse = CRC_ALGORITHMS.find(a => a.name === "CRC-16/CCITT-FALSE")!;
    
    const blocks: ChecksumBlockInfo[] = bcmInfo.vinBlocks.map((block, i) => {
      const vinBytes = new TextEncoder().encode(block.vin);
      const calcCrc = calculateCrc16(vinBytes, ccittFalse);
      
      const crcOffset = block.suffixOffset;
      const storedCrc = (data[crcOffset] << 8) | data[crcOffset + 1];
      
      const isValid = storedCrc === calcCrc;
      
      return {
        blockNumber: i + 1,
        vinOffset: block.vinOffset,
        checksumOffset: crcOffset,
        vin: block.vin,
        storedChecksum: '0x' + storedCrc.toString(16).toUpperCase().padStart(4, '0'),
        calculatedChecksum: '0x' + calcCrc.toString(16).toUpperCase().padStart(4, '0'),
        isValid,
      };
    });
    
    const validCount = blocks.filter(b => b.isValid).length;
    
    const firstOffset = bcmInfo.vinBlocks[0]?.vinOffset || 0;
    let variant = 'Unknown';
    if (firstOffset === 0x1298) variant = 'Variant A (0x1298)';
    else if (firstOffset === 0x1328) variant = 'Variant B (0x1328)';
    else if (firstOffset === 0x5328) variant = 'Variant C (0x5328)';
    else if (firstOffset === 0x52B8) variant = 'Variant D / DFLASH19CHAL (0x52B8)';
    
    return {
      detected: true,
      formatType: 'BCM_DFLASH',
      formatName: 'BCM D-FLASH (' + (data.length / 1024) + 'KB)',
      algorithm: 'CRC-16/CCITT-FALSE',
      fileSize: data.length,
      variant,
      blocks,
      allValid: validCount === blocks.length,
      validCount,
      totalCount: blocks.length,
    };
  }
  
  return {
    detected: false,
    formatType: 'UNKNOWN',
    formatName: 'Unknown Format',
    algorithm: 'N/A',
    fileSize: data.length,
    blocks: [],
    allValid: false,
    validCount: 0,
    totalCount: 0,
  };
}
