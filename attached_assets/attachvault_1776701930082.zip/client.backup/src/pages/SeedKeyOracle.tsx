import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, Plus, Trash2, Brain, Download } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface SeedKeyPair {
  seed: string;
  key: string;
  module?: string;
  year?: string;
}

export default function SeedKeyOracle() {
  const [pairs, setPairs] = useState<SeedKeyPair[]>([
    { seed: '', key: '', module: '', year: '' }
  ]);
  const [result, setResult] = useState<{
    analysis?: string;
    formula?: string;
    confidence?: number;
    reasoning?: string;
    testResults?: Array<{ seed: string; predicted: string; actual: string; match: boolean }>;
  } | null>(null);

  const analyzeMutation = trpc.ai.analyzeSeedKeyPairs.useMutation();

  const addPair = () => {
    setPairs([...pairs, { seed: '', key: '', module: '', year: '' }]);
  };

  const removePair = (index: number) => {
    setPairs(pairs.filter((_, i) => i !== index));
  };

  const updatePair = (index: number, field: keyof SeedKeyPair, value: string) => {
    const newPairs = [...pairs];
    newPairs[index][field] = value;
    setPairs(newPairs);
  };

  const handleAnalyze = async () => {
    // Filter out empty pairs
    const validPairs = pairs.filter(p => p.seed && p.key);
    
    if (validPairs.length < 3) {
      alert('Please provide at least 3 seed-key pairs for accurate analysis');
      return;
    }

    try {
      const response = await analyzeMutation.mutateAsync({ pairs: validPairs });
      // Parse analysis if it's a JSON string
      if (response.analysis) {
        try {
          const parsed = JSON.parse(response.analysis);
          setResult({ ...parsed, analysis: response.analysis });
        } catch {
          setResult({ analysis: response.analysis });
        }
      } else {
        setResult(response);
      }
    } catch (error) {
      console.error('Analysis failed:', error);
      alert('Analysis failed. Please try again.');
    }
  };

  const exportResults = () => {
    if (!result) return;
    
    const data = {
      formula: result.formula,
      confidence: result.confidence,
      reasoning: result.reasoning,
      testResults: result.testResults,
      timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `seed-key-oracle-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Brain className="w-10 h-10 text-primary" />
          Seed-Key Oracle
        </h1>
        <p className="text-muted-foreground">
          AI-powered algorithm reverse engineering from seed-key pairs. Discovers unknown algorithms through pattern analysis.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Provide at least 10 seed-key pairs from the same module. 
          The AI will analyze mathematical relationships and predict the algorithm formula. 
          More pairs = higher accuracy.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Training Data</CardTitle>
            <CardDescription>
              Enter seed-key pairs from successful programming sessions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="max-h-[600px] overflow-y-auto space-y-4 pr-2">
              {pairs.map((pair, index) => (
                <Card key={index} className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-sm font-medium text-muted-foreground">
                      Pair #{index + 1}
                    </span>
                    {pairs.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removePair(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid gap-3">
                    <div>
                      <Label htmlFor={`seed-${index}`}>Seed (Hex)</Label>
                      <Input
                        id={`seed-${index}`}
                        placeholder="0x12345678"
                        value={pair.seed}
                        onChange={(e) => updatePair(index, 'seed', e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor={`key-${index}`}>Key (Hex)</Label>
                      <Input
                        id={`key-${index}`}
                        placeholder="0xABCDEF01"
                        value={pair.key}
                        onChange={(e) => updatePair(index, 'key', e.target.value)}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor={`module-${index}`}>Module (Optional)</Label>
                        <Input
                          id={`module-${index}`}
                          placeholder="BCM"
                          value={pair.module}
                          onChange={(e) => updatePair(index, 'module', e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`year-${index}`}>Year (Optional)</Label>
                        <Input
                          id={`year-${index}`}
                          placeholder="2015"
                          value={pair.year}
                          onChange={(e) => updatePair(index, 'year', e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            <div className="flex gap-2">
              <Button onClick={addPair} variant="outline" className="flex-1">
                <Plus className="w-4 h-4 mr-2" />
                Add Pair
              </Button>
              <Button 
                onClick={handleAnalyze} 
                disabled={analyzeMutation.isPending}
                className="flex-1"
              >
                {analyzeMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Analyze Pattern
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Analysis Results</CardTitle>
            <CardDescription>
              Discovered algorithm formula and validation
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!result ? (
              <div className="text-center py-12 text-muted-foreground">
                <Brain className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Enter seed-key pairs and click "Analyze Pattern" to discover the algorithm</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Formula */}
                <div>
                  <Label className="text-base font-semibold mb-2 block">Discovered Formula</Label>
                  <div className="bg-primary/10 p-4 rounded-lg font-mono text-sm break-all">
                    {result.formula}
                  </div>
                </div>

                {/* Confidence */}
                <div>
                  <Label className="text-base font-semibold mb-2 block">Confidence Score</Label>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 bg-secondary rounded-full h-3 overflow-hidden">
                      <div 
                        className={`h-full transition-all ${
                          (result.confidence || 0) >= 80 ? 'bg-green-500' :
                          (result.confidence || 0) >= 60 ? 'bg-amber-500' :
                          'bg-red-500'
                        }`}
                        style={{ width: `${result.confidence || 0}%` }}
                      />
                    </div>
                    <span className="font-semibold">{result.confidence}%</span>
                  </div>
                </div>

                {/* Reasoning */}
                <div>
                  <Label className="text-base font-semibold mb-2 block">AI Reasoning</Label>
                  <div className="bg-muted p-4 rounded-lg text-sm whitespace-pre-wrap">
                    {result.reasoning}
                  </div>
                </div>

                {/* Test Results */}
                {result.testResults && result.testResults.length > 0 && (
                  <div>
                    <Label className="text-base font-semibold mb-2 block">Validation Tests</Label>
                    <div className="space-y-2">
                      {result.testResults.map((test, idx) => (
                        <div 
                          key={idx}
                          className={`p-3 rounded-lg border ${
                            test.match ? 'border-green-500/50 bg-green-500/10' : 'border-red-500/50 bg-red-500/10'
                          }`}
                        >
                          <div className="grid grid-cols-3 gap-2 text-sm font-mono">
                            <div>
                              <span className="text-muted-foreground">Seed:</span> {test.seed}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Predicted:</span> {test.predicted}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Actual:</span> {test.actual}
                            </div>
                          </div>
                          <div className="text-xs mt-1 font-semibold">
                            {test.match ? '✓ Match' : '✗ Mismatch'}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Export Button */}
                <Button onClick={exportResults} variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Export Results
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
