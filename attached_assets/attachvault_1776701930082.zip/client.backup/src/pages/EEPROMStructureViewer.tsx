import { useState, useEffect } from "react";
import { trpc } from "../lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Alert, AlertDescription } from "../components/ui/alert";
import { toast } from "sonner";
import { FileCode, CheckCircle, XCircle, Download, GitCompare, Search } from "lucide-react";
import { BackButton } from "../components/BackButton";

export default function EEPROMStructureViewer() {
  const [selectedFile, setSelectedFile] = useState<string>("");
  const [compareFile, setCompareFile] = useState<string>("");
  const [hexViewOffset, setHexViewOffset] = useState(0);
  const [hexViewLength, setHexViewLength] = useState(256);

  const { data: files } = trpc.eepromAnalyzer.listDumps.useQuery();
  const { data: analysis, isLoading: analyzing } = trpc.eepromAnalyzer.analyzeDump.useQuery(
    { filename: selectedFile },
    { enabled: !!selectedFile }
  );
  const { data: hexData } = trpc.eepromAnalyzer.readBytes.useQuery(
    { filename: selectedFile, offset: hexViewOffset, length: hexViewLength },
    { enabled: !!selectedFile }
  );
  const { data: comparison } = trpc.eepromAnalyzer.compareDumps.useQuery(
    { file1: selectedFile, file2: compareFile },
    { enabled: !!selectedFile && !!compareFile }
  );

  // Format hex string for display (16 bytes per line)
  const formatHexDump = (hexString: string, baseOffset: number) => {
    const lines: React.ReactElement[] = [];
    for (let i = 0; i < hexString.length; i += 32) {
      const offset = baseOffset + i / 2;
      const hexLine = hexString.slice(i, i + 32);
      const bytes = hexLine.match(/.{1,2}/g) || [];
      
      // Convert to ASCII (printable chars only)
      const ascii = bytes
        .map(b => {
          const code = parseInt(b, 16);
          return code >= 32 && code <= 126 ? String.fromCharCode(code) : ".";
        })
        .join("");

      lines.push(
        <div key={offset} className="font-mono text-sm flex gap-4">
          <span className="text-muted-foreground w-20">
            {offset.toString(16).toUpperCase().padStart(8, "0")}:
          </span>
          <span className="flex-1">
            {bytes.map((byte, idx) => (
              <span key={idx} className="mr-1">
                {byte}
              </span>
            ))}
          </span>
          <span className="text-muted-foreground">{ascii}</span>
        </div>
      );
    }
    return lines;
  };

  const downloadReport = () => {
    if (!analysis) return;
    
    const report = `EEPROM Analysis Report
======================
File: ${analysis.filename}
Size: ${analysis.size} bytes (${(analysis.size / 1024).toFixed(1)} KB)
Module Type: ${analysis.moduleType}

VIN Locations:
${analysis.vinLocations.map(v => `  ${v.label} (0x${v.offset.toString(16).toUpperCase()}): ${v.vin}`).join("\n")}

Security Byte Regions:
${analysis.securityBytes.map(s => `  ${s.label} (0x${s.start.toString(16).toUpperCase()}-0x${s.end.toString(16).toUpperCase()}): ${s.bytes}`).join("\n")}

Checksums:
${analysis.checksums.map(c => `  ${c.algorithm} @ 0x${c.offset.toString(16).toUpperCase()}: ${c.valid ? "VALID" : "INVALID"} (Expected: ${c.expected}, Calculated: ${c.calculated})`).join("\n")}

Metadata:
  VIN: ${analysis.metadata.extractedVIN || "N/A"}
  Vehicle: ${analysis.metadata.vehicle || "Unknown"}
  Date: ${analysis.metadata.date || "Unknown"}
`;

    const blob = new Blob([report], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${analysis.filename}_analysis.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success("Report downloaded");
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <BackButton />
          <h1 className="text-3xl font-bold flex items-center gap-2 mt-2">
            <FileCode className="h-8 w-8" />
            EEPROM Structure Viewer
          </h1>
          <p className="text-muted-foreground mt-1">
            Analyze BCM/RFHUB memory dumps with VIN highlighting and checksum validation
          </p>
        </div>
      </div>

      {/* File Selector */}
      <Card>
        <CardHeader>
          <CardTitle>Select EEPROM Dump</CardTitle>
          <CardDescription>
            {files?.length || 0} dump files available
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Primary File</label>
              <Select value={selectedFile} onValueChange={setSelectedFile}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a dump file..." />
                </SelectTrigger>
                <SelectContent>
                  {files?.map(file => (
                    <SelectItem key={file} value={file}>
                      {file}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Compare With (Optional)</label>
              <Select value={compareFile} onValueChange={setCompareFile}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose file to compare..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {files?.filter(f => f !== selectedFile).map(file => (
                    <SelectItem key={file} value={file}>
                      {file}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="vins">VIN Locations</TabsTrigger>
            <TabsTrigger value="security">Security Bytes</TabsTrigger>
            <TabsTrigger value="hex">Hex Viewer</TabsTrigger>
            <TabsTrigger value="compare" disabled={!compareFile}>
              Compare
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>File Information</CardTitle>
                  <Button onClick={downloadReport} variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">File Size</div>
                    <div className="text-2xl font-bold">
                      {(analysis.size / 1024).toFixed(1)} KB
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Module Type</div>
                    <div className="text-2xl font-bold">{analysis.moduleType}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">VINs Found</div>
                    <div className="text-2xl font-bold">{analysis.vinLocations.length}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Checksums</div>
                    <div className="text-2xl font-bold flex items-center gap-2">
                      {analysis.checksums.filter(c => c.valid).length}/{analysis.checksums.length}
                      {analysis.checksums.every(c => c.valid) ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                    </div>
                  </div>
                </div>

                {analysis.metadata.extractedVIN && (
                  <Alert>
                    <AlertDescription>
                      <strong>Extracted VIN:</strong> {analysis.metadata.extractedVIN}
                      {analysis.metadata.vehicle && ` (${analysis.metadata.vehicle})`}
                      {analysis.metadata.date && ` - ${analysis.metadata.date}`}
                    </AlertDescription>
                  </Alert>
                )}

                {/* Checksums */}
                <div>
                  <h3 className="font-semibold mb-2">Checksum Validation</h3>
                  <div className="space-y-2">
                    {analysis.checksums.map((checksum, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">{checksum.algorithm}</div>
                          <div className="text-sm text-muted-foreground">
                            Offset: 0x{checksum.offset.toString(16).toUpperCase()}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            {checksum.valid ? (
                              <Badge variant="default" className="bg-green-500">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                VALID
                              </Badge>
                            ) : (
                              <Badge variant="destructive">
                                <XCircle className="h-3 w-3 mr-1" />
                                INVALID
                              </Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Expected: {checksum.expected} | Calculated: {checksum.calculated}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* VIN Locations Tab */}
          <TabsContent value="vins">
            <Card>
              <CardHeader>
                <CardTitle>VIN Locations</CardTitle>
                <CardDescription>
                  All VIN copies found in the EEPROM dump
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analysis.vinLocations.map((vin, idx) => (
                    <div key={idx} className="p-4 border rounded-lg bg-green-50 dark:bg-green-950">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="bg-green-100 dark:bg-green-900">
                          {vin.label}
                        </Badge>
                        <span className="text-sm text-muted-foreground font-mono">
                          Offset: 0x{vin.offset.toString(16).toUpperCase()}
                        </span>
                      </div>
                      <div className="font-mono text-lg font-bold">{vin.vin}</div>
                      {vin.prefix && (
                        <div className="text-sm text-muted-foreground mt-1">
                          Prefix: {vin.prefix}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Bytes Tab */}
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Security Byte Regions</CardTitle>
                <CardDescription>
                  Critical security data regions (SKIM, Key FOBs, Secret Keys)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analysis.securityBytes.map((region, idx) => (
                    <div key={idx} className="p-4 border rounded-lg bg-red-50 dark:bg-red-950">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="bg-red-100 dark:bg-red-900">
                          {region.label}
                        </Badge>
                        <span className="text-sm text-muted-foreground font-mono">
                          0x{region.start.toString(16).toUpperCase()} - 0x{region.end.toString(16).toUpperCase()}
                        </span>
                      </div>
                      <div className="font-mono text-sm break-all">{region.bytes}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hex Viewer Tab */}
          <TabsContent value="hex">
            <Card>
              <CardHeader>
                <CardTitle>Hex Dump Viewer</CardTitle>
                <CardDescription>
                  Raw byte-level view of EEPROM contents
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Button
                    onClick={() => setHexViewOffset(Math.max(0, hexViewOffset - 256))}
                    disabled={hexViewOffset === 0}
                    size="sm"
                  >
                    Previous 256 bytes
                  </Button>
                  <Button
                    onClick={() => setHexViewOffset(hexViewOffset + 256)}
                    disabled={hexViewOffset + 256 >= analysis.size}
                    size="sm"
                  >
                    Next 256 bytes
                  </Button>
                  <span className="text-sm text-muted-foreground flex items-center ml-auto">
                    Showing bytes 0x{hexViewOffset.toString(16).toUpperCase()} - 0x{(hexViewOffset + hexViewLength).toString(16).toUpperCase()}
                  </span>
                </div>

                <div className="bg-black text-green-400 p-4 rounded-lg overflow-x-auto">
                  {hexData && formatHexDump(hexData, hexViewOffset)}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Compare Tab */}
          <TabsContent value="compare">
            {comparison && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GitCompare className="h-5 w-5" />
                    File Comparison
                  </CardTitle>
                  <CardDescription>
                    Showing differences between {selectedFile} and {compareFile}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Total Bytes</div>
                      <div className="text-2xl font-bold">{comparison.totalBytes}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Differences</div>
                      <div className="text-2xl font-bold text-red-500">{comparison.diffCount}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Difference %</div>
                      <div className="text-2xl font-bold">{comparison.diffPercentage.toFixed(2)}%</div>
                    </div>
                  </div>

                  {comparison.differences.length > 0 && (
                    <div>
                      <h3 className="font-semibold mb-2">First {Math.min(100, comparison.differences.length)} Differences</h3>
                      <div className="bg-black text-green-400 p-4 rounded-lg overflow-x-auto max-h-96">
                        {comparison.differences.slice(0, 100).map((diff, idx) => (
                          <div key={idx} className="font-mono text-sm">
                            0x{diff.offset.toString(16).toUpperCase().padStart(8, "0")}: {diff.byte1} → {diff.byte2}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      )}

      {!selectedFile && (
        <Alert>
          <Search className="h-4 w-4" />
          <AlertDescription>
            Select an EEPROM dump file above to begin analysis
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
