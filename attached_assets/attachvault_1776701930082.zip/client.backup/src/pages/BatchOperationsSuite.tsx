import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { BackButton } from "@/components/BackButton";
import { 
  Play, 
  Pause, 
  StopCircle, 
  Download, 
  Upload, 
  CheckCircle2, 
  XCircle, 
  Clock,
  FileText,
  Zap,
  AlertCircle
} from 'lucide-react';

interface BatchOperation {
  id: string;
  type: 'vin_programming' | 'eeprom_analysis' | 'security_access';
  status: 'pending' | 'running' | 'completed' | 'failed';
  target: string;
  progress: number;
  result?: string;
  error?: string;
  startTime?: Date;
  endTime?: Date;
}

export default function BatchOperationsSuite() {
  const [operationType, setOperationType] = useState<'vin_programming' | 'eeprom_analysis' | 'security_access'>('vin_programming');
  const [operations, setOperations] = useState<BatchOperation[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  // VIN Programming inputs
  const [vinList, setVinList] = useState('');
  const [targetModule, setTargetModule] = useState('BCM');

  // EEPROM Analysis inputs
  const [eepromFiles, setEepromFiles] = useState<File[]>([]);

  // Security Access inputs
  const [moduleList, setModuleList] = useState('');
  const [securityLevel, setSecurityLevel] = useState('5');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setEepromFiles(Array.from(e.target.files));
    }
  };

  const createBatchOperations = () => {
    let newOperations: BatchOperation[] = [];

    switch (operationType) {
      case 'vin_programming':
        const vins = vinList.split('\n').filter(v => v.trim());
        newOperations = vins.map((vin, index) => ({
          id: `vin-${index}-${Date.now()}`,
          type: 'vin_programming',
          status: 'pending' as const,
          target: `${targetModule} - ${vin.trim()}`,
          progress: 0
        }));
        break;

      case 'eeprom_analysis':
        newOperations = eepromFiles.map((file, index) => ({
          id: `eeprom-${index}-${Date.now()}`,
          type: 'eeprom_analysis',
          status: 'pending' as const,
          target: file.name,
          progress: 0
        }));
        break;

      case 'security_access':
        const modules = moduleList.split('\n').filter(m => m.trim());
        newOperations = modules.map((module, index) => ({
          id: `security-${index}-${Date.now()}`,
          type: 'security_access',
          status: 'pending' as const,
          target: `${module.trim()} - Level ${securityLevel}`,
          progress: 0
        }));
        break;
    }

    setOperations(newOperations);
  };

  const runBatchOperations = async () => {
    setIsRunning(true);
    setIsPaused(false);

    for (let i = 0; i < operations.length; i++) {
      if (isPaused) break;

      // Update status to running
      setOperations(prev => prev.map((op, idx) => 
        idx === i ? { ...op, status: 'running', startTime: new Date() } : op
      ));

      // Simulate operation progress
      for (let progress = 0; progress <= 100; progress += 10) {
        if (isPaused) break;
        
        await new Promise(resolve => setTimeout(resolve, 200));
        
        setOperations(prev => prev.map((op, idx) => 
          idx === i ? { ...op, progress } : op
        ));
      }

      // Simulate random success/failure (90% success rate)
      const success = Math.random() > 0.1;

      setOperations(prev => prev.map((op, idx) => 
        idx === i ? { 
          ...op, 
          status: success ? 'completed' : 'failed',
          endTime: new Date(),
          result: success ? 'Operation completed successfully' : undefined,
          error: success ? undefined : 'Operation failed - timeout'
        } : op
      ));
    }

    setIsRunning(false);
  };

  const pauseBatchOperations = () => {
    setIsPaused(true);
    setIsRunning(false);
  };

  const stopBatchOperations = () => {
    setIsPaused(false);
    setIsRunning(false);
    setOperations(prev => prev.map(op => 
      op.status === 'running' ? { ...op, status: 'failed', error: 'Stopped by user' } : op
    ));
  };

  const exportResults = () => {
    const results = operations.map(op => ({
      type: op.type,
      target: op.target,
      status: op.status,
      progress: op.progress,
      result: op.result,
      error: op.error,
      duration: op.startTime && op.endTime 
        ? `${((op.endTime.getTime() - op.startTime.getTime()) / 1000).toFixed(2)}s`
        : 'N/A'
    }));

    const csv = [
      ['Type', 'Target', 'Status', 'Progress', 'Result', 'Error', 'Duration'],
      ...results.map(r => [r.type, r.target, r.status, `${r.progress}%`, r.result || '', r.error || '', r.duration])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `batch-operations-${Date.now()}.csv`;
    a.click();
  };

  const getStatusIcon = (status: BatchOperation['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-gray-400" />;
      case 'running':
        return <Zap className="h-4 w-4 text-yellow-500 animate-pulse" />;
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusBadge = (status: BatchOperation['status']) => {
    const variants: Record<BatchOperation['status'], 'default' | 'secondary' | 'destructive' | 'outline'> = {
      pending: 'secondary',
      running: 'default',
      completed: 'default',
      failed: 'destructive'
    };

    const labels: Record<BatchOperation['status'], string> = {
      pending: 'Pending',
      running: 'Running',
      completed: 'Completed',
      failed: 'Failed'
    };

    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    );
  };

  const completedCount = operations.filter(op => op.status === 'completed').length;
  const failedCount = operations.filter(op => op.status === 'failed').length;
  const overallProgress = operations.length > 0 
    ? (operations.reduce((sum, op) => sum + op.progress, 0) / operations.length)
    : 0;

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
          Batch Operations Suite
        </h1>
        <p className="text-muted-foreground mt-2">
          Process multiple vehicles, modules, or files in a single batch operation
        </p>
      </div>

      {/* Operation Type Selection */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Select Operation Type</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            variant={operationType === 'vin_programming' ? 'default' : 'outline'}
            className="h-24 flex flex-col items-center justify-center gap-2"
            onClick={() => setOperationType('vin_programming')}
          >
            <FileText className="h-8 w-8" />
            <span>Batch VIN Programming</span>
          </Button>

          <Button
            variant={operationType === 'eeprom_analysis' ? 'default' : 'outline'}
            className="h-24 flex flex-col items-center justify-center gap-2"
            onClick={() => setOperationType('eeprom_analysis')}
          >
            <Upload className="h-8 w-8" />
            <span>Batch EEPROM Analysis</span>
          </Button>

          <Button
            variant={operationType === 'security_access' ? 'default' : 'outline'}
            className="h-24 flex flex-col items-center justify-center gap-2"
            onClick={() => setOperationType('security_access')}
          >
            <Zap className="h-8 w-8" />
            <span>Batch Security Access</span>
          </Button>
        </div>
      </Card>

      {/* Input Configuration */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Configure Batch Operation</h2>

        {operationType === 'vin_programming' && (
          <div className="space-y-4">
            <div>
              <Label htmlFor="target-module">Target Module</Label>
              <Select value={targetModule} onValueChange={setTargetModule}>
                <SelectTrigger id="target-module">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                  <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                  <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                  <SelectItem value="RFHUB">RFHUB (SmartBox)</SelectItem>
                  <SelectItem value="ABS">ABS (Anti-lock Braking System)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="vin-list">VIN List (one per line)</Label>
              <Textarea
                id="vin-list"
                placeholder="1C3CDFBB8ED123456&#10;2C4RDGCG5KR123456&#10;3C4PDCAB7JT123456"
                value={vinList}
                onChange={(e) => setVinList(e.target.value)}
                rows={6}
                className="font-mono"
              />
              <p className="text-sm text-muted-foreground mt-1">
                {vinList.split('\n').filter(v => v.trim()).length} VINs entered
              </p>
            </div>
          </div>
        )}

        {operationType === 'eeprom_analysis' && (
          <div className="space-y-4">
            <div>
              <Label htmlFor="eeprom-files">Upload EEPROM Dump Files</Label>
              <Input
                id="eeprom-files"
                type="file"
                multiple
                accept=".bin,.eep,.dump"
                onChange={handleFileUpload}
              />
              <p className="text-sm text-muted-foreground mt-1">
                {eepromFiles.length} files selected
              </p>
            </div>

            {eepromFiles.length > 0 && (
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">Selected Files:</h3>
                <ul className="space-y-1">
                  {eepromFiles.map((file, index) => (
                    <li key={index} className="text-sm font-mono">
                      {file.name} ({(file.size / 1024).toFixed(2)} KB)
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {operationType === 'security_access' && (
          <div className="space-y-4">
            <div>
              <Label htmlFor="security-level">Security Level</Label>
              <Select value={securityLevel} onValueChange={setSecurityLevel}>
                <SelectTrigger id="security-level">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Level 1 (Basic)</SelectItem>
                  <SelectItem value="3">Level 3 (Advanced)</SelectItem>
                  <SelectItem value="5">Level 5 (Programming)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="module-list">Module List (one per line)</Label>
              <Textarea
                id="module-list"
                placeholder="BCM&#10;ECM&#10;TCM&#10;RFHUB&#10;ABS"
                value={moduleList}
                onChange={(e) => setModuleList(e.target.value)}
                rows={6}
                className="font-mono"
              />
              <p className="text-sm text-muted-foreground mt-1">
                {moduleList.split('\n').filter(m => m.trim()).length} modules entered
              </p>
            </div>
          </div>
        )}

        <Separator className="my-4" />

        <div className="flex gap-2">
          <Button onClick={createBatchOperations} disabled={isRunning}>
            <FileText className="mr-2 h-4 w-4" />
            Create Batch
          </Button>
          {operations.length > 0 && (
            <Button variant="outline" onClick={() => setOperations([])}>
              Clear
            </Button>
          )}
        </div>
      </Card>

      {/* Progress Overview */}
      {operations.length > 0 && (
        <Card className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Batch Progress</h2>
              <div className="flex gap-2">
                {!isRunning && !isPaused && (
                  <Button onClick={runBatchOperations}>
                    <Play className="mr-2 h-4 w-4" />
                    Start Batch
                  </Button>
                )}
                {isRunning && (
                  <Button variant="outline" onClick={pauseBatchOperations}>
                    <Pause className="mr-2 h-4 w-4" />
                    Pause
                  </Button>
                )}
                {(isRunning || isPaused) && (
                  <Button variant="destructive" onClick={stopBatchOperations}>
                    <StopCircle className="mr-2 h-4 w-4" />
                    Stop
                  </Button>
                )}
                <Button variant="outline" onClick={exportResults}>
                  <Download className="mr-2 h-4 w-4" />
                  Export Results
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-3xl font-bold">{operations.length}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-3xl font-bold text-green-500">{completedCount}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Failed</p>
                <p className="text-3xl font-bold text-red-500">{failedCount}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Progress</p>
                <p className="text-3xl font-bold">{overallProgress.toFixed(0)}%</p>
              </div>
            </div>

            <Progress value={overallProgress} className="h-2" />
          </div>
        </Card>
      )}

      {/* Operation List */}
      {operations.length > 0 && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Operations</h2>
          <div className="space-y-2">
            {operations.map((operation) => (
              <div
                key={operation.id}
                className="border rounded-lg p-4 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(operation.status)}
                    <span className="font-mono text-sm">{operation.target}</span>
                  </div>
                  {getStatusBadge(operation.status)}
                </div>

                {operation.status === 'running' && (
                  <Progress value={operation.progress} className="h-1" />
                )}

                {operation.result && (
                  <Alert>
                    <CheckCircle2 className="h-4 w-4" />
                    <AlertDescription>{operation.result}</AlertDescription>
                  </Alert>
                )}

                {operation.error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{operation.error}</AlertDescription>
                  </Alert>
                )}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
