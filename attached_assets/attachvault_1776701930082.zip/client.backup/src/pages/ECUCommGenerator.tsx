import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Copy, Download, Search, Cpu } from "lucide-react";

export default function ECUCommGenerator() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedECU, setSelectedECU] = useState<any>(null);

  const { data: ecuConfigs, isLoading } = trpc.alphaOBD.getECUCommunicationConfigs.useQuery({
    search: searchQuery || undefined,
  });

  const generateELM327Code = (ecu: any) => {
    return `# ELM327 Initialization for ${ecu.device_id}
import serial
import time

# Open serial connection
ser = serial.Serial('/dev/ttyUSB0', 38400, timeout=1)

# Initialize ELM327
ser.write(b'ATZ\\r')  # Reset
time.sleep(2)
ser.write(b'ATE0\\r')  # Echo off
time.sleep(0.1)
ser.write(b'ATH1\\r')  # Headers on
time.sleep(0.1)
ser.write(b'ATSP0\\r')  # Auto protocol
time.sleep(0.1)

# Set CAN ID for ${ecu.device_id}
# Device ID: ${ecu.device_id}
# Unit: ${ecu.unit_name || 'N/A'}

print("ELM327 initialized for ${ecu.device_id}")
`;
  };

  const generateJ2534Code = (ecu: any) => {
    return `// J2534 PassThru for ${ecu.device_id}
const J2534 = require('./j2534-client');

async function initializeJ2534() {
  const device = new J2534();
  
  // Open device
  await device.open();
  
  // Connect to CAN bus
  const channelId = await device.connect({
    protocol: 'ISO15765',
    baudRate: 500000,  // 500 kbps
    flags: 0
  });
  
  // Set filters for ${ecu.device_id}
  // Device ID: ${ecu.device_id}
  // Unit: ${ecu.unit_name || 'N/A'}
  
  console.log('J2534 initialized for ${ecu.device_id}');
  return { device, channelId };
}

initializeJ2534().catch(console.error);
`;
  };

  const generateArduinoCode = (ecu: any) => {
    return `// Arduino CAN Bridge for ${ecu.device_id}
#include <mcp_can.h>
#include <SPI.h>

#define CAN_CS_PIN 10

MCP_CAN CAN(CAN_CS_PIN);

void setup() {
  Serial.begin(115200);
  
  // Initialize CAN bus at 500 kbps
  if (CAN.begin(MCP_ANY, CAN_500KBPS, MCP_8MHZ) == CAN_OK) {
    Serial.println("CAN initialized");
  } else {
    Serial.println("CAN init failed");
    while(1);
  }
  
  CAN.setMode(MCP_NORMAL);
  
  // Device: ${ecu.device_id}
  // Unit: ${ecu.unit_name || 'N/A'}
}

void loop() {
  // Read CAN messages
  long unsigned int rxId;
  unsigned char len = 0;
  unsigned char rxBuf[8];
  
  if (CAN.checkReceive() == CAN_MSGAVAIL) {
    CAN.readMsgBuf(&rxId, &len, rxBuf);
    
    Serial.print("ID: 0x");
    Serial.print(rxId, HEX);
    Serial.print(" Data: ");
    for (int i = 0; i < len; i++) {
      Serial.print(rxBuf[i], HEX);
      Serial.print(" ");
    }
    Serial.println();
  }
}
`;
  };

  const copyToClipboard = (code: string, type: string) => {
    navigator.clipboard.writeText(code);
    toast.success(`${type} code copied to clipboard`);
  };

  const downloadCode = (code: string, filename: string) => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Downloaded ${filename}`);
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">ECU Communication Generator</h1>
        <p className="text-muted-foreground">
          Generate initialization code for 468 ECU configurations (ELM327, J2534, Arduino)
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* ECU Selector */}
        <Card>
          <CardHeader>
            <CardTitle>Select ECU</CardTitle>
            <CardDescription>Search from 468 ECU communication configurations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by device ID or name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {isLoading && <p className="text-sm text-muted-foreground">Loading ECU configs...</p>}
              
              {ecuConfigs && ecuConfigs.length === 0 && (
                <p className="text-sm text-muted-foreground">No ECUs found. Try a different search.</p>
              )}

              {ecuConfigs?.map((ecu: any, idx: number) => (
                <Card
                  key={idx}
                  className={`cursor-pointer transition-colors hover:bg-accent ${
                    selectedECU?.device_id === ecu.device_id ? 'border-primary bg-accent' : ''
                  }`}
                  onClick={() => setSelectedECU(ecu)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Cpu className="h-5 w-5 text-primary mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{ecu.device_id}</p>
                        {ecu.unit_name && (
                          <p className="text-sm text-muted-foreground truncate">{ecu.unit_name}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Code Generator */}
        <Card>
          <CardHeader>
            <CardTitle>Generated Code</CardTitle>
            <CardDescription>
              {selectedECU ? `Code for ${selectedECU.device_id}` : 'Select an ECU to generate code'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!selectedECU && (
              <div className="flex items-center justify-center h-[500px] text-muted-foreground">
                <div className="text-center">
                  <Cpu className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select an ECU from the list to generate initialization code</p>
                </div>
              </div>
            )}

            {selectedECU && (
              <Tabs defaultValue="elm327" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="elm327">ELM327</TabsTrigger>
                  <TabsTrigger value="j2534">J2534</TabsTrigger>
                  <TabsTrigger value="arduino">Arduino</TabsTrigger>
                </TabsList>

                <TabsContent value="elm327" className="space-y-4">
                  <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto max-h-[400px] overflow-y-auto">
                    {generateELM327Code(selectedECU)}
                  </pre>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => copyToClipboard(generateELM327Code(selectedECU), 'ELM327')}
                      variant="outline"
                      className="flex-1"
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button
                      onClick={() => downloadCode(generateELM327Code(selectedECU), `elm327_${selectedECU.device_id}.py`)}
                      variant="outline"
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="j2534" className="space-y-4">
                  <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto max-h-[400px] overflow-y-auto">
                    {generateJ2534Code(selectedECU)}
                  </pre>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => copyToClipboard(generateJ2534Code(selectedECU), 'J2534')}
                      variant="outline"
                      className="flex-1"
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button
                      onClick={() => downloadCode(generateJ2534Code(selectedECU), `j2534_${selectedECU.device_id}.js`)}
                      variant="outline"
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="arduino" className="space-y-4">
                  <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto max-h-[400px] overflow-y-auto">
                    {generateArduinoCode(selectedECU)}
                  </pre>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => copyToClipboard(generateArduinoCode(selectedECU), 'Arduino')}
                      variant="outline"
                      className="flex-1"
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button
                      onClick={() => downloadCode(generateArduinoCode(selectedECU), `arduino_${selectedECU.device_id}.ino`)}
                      variant="outline"
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
