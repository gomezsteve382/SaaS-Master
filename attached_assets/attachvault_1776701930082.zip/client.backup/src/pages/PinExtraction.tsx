import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BackButton } from "@/components/BackButton";
import { Key, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface PinCandidate {
  did: string;
  description: string;
  encoding: string;
  pin: string;
  rawData: string;
}

// Mock PIN data generator (replace with real J2534 DID reads in production)
const generateMockPinData = (did: number): string | null => {
  // Simulate different PIN storage formats at different DIDs
  const mockPins: Record<number, string> = {
    0xF18C: "1234", // 4-digit BCD: 0x12 0x34
    0xF18D: "5678", // 4-digit BCD: 0x56 0x78
    0xF18E: "04D2", // Binary 1234: 0x04 0xD2
    0xF1A0: "31323334", // ASCII "1234"
    0xF1A1: "0123456789", // 5-digit BCD: 0x01 0x23 0x45
  };

  const pin = mockPins[did];
  if (!pin) return null;

  // Convert PIN string to hex bytes
  if (did === 0xF18C || did === 0xF18D) {
    // BCD format
    return pin.match(/.{2}/g)?.map(p => p).join(" ") || null;
  } else if (did === 0xF18E) {
    // Binary format
    return pin.match(/.{2}/g)?.join(" ") || null;
  } else if (did === 0xF1A0) {
    // ASCII format
    return pin.match(/.{2}/g)?.join(" ") || null;
  } else if (did === 0xF1A1) {
    // 5-digit BCD
    return pin.match(/.{2}/g)?.join(" ") || null;
  }

  return null;
};

export default function PinExtraction() {
  const [isExtracting, setIsExtracting] = useState(false);
  const [pinCandidates, setPinCandidates] = useState<PinCandidate[]>([]);
  const [mostLikelyPin, setMostLikelyPin] = useState<string | null>(null);

  const logAudit = trpc.audit.log.useMutation();

  const handleExtractPin = async () => {
    setIsExtracting(true);
    setPinCandidates([]);
    setMostLikelyPin(null);

    try {
      // DIDs that commonly store PIN codes
      const pinDids = [
        { did: 0xF18C, description: "PIN Storage 1" },
        { did: 0xF18D, description: "PIN Storage 2" },
        { did: 0xF18E, description: "PIN Storage 3" },
        { did: 0xF1A0, description: "Security Data 1" },
        { did: 0xF1A1, description: "Security Data 2" },
      ];

      const candidates: PinCandidate[] = [];

      // Get real hardware connection
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        throw new Error('Not connected to vehicle. Please connect hardware first.');
      }

      // RFHUB CAN addresses
      const RFHUB_TX = 0x742;
      const RFHUB_RX = 0x744;

      for (const { did, description } of pinDids) {
        try {
          // Real UDS 0x22 DID read
          const didHigh = (did >> 8) & 0xFF;
          const didLow = did & 0xFF;
          const response = await protocol.sendUDS(RFHUB_TX, RFHUB_RX, [0x22, didHigh, didLow]);
          
          if (response && response[0] === 0x62 && response[1] === didHigh && response[2] === didLow) {
            // Extract data bytes (skip service ID + DID echo)
            const dataBytes = Array.from(response.slice(3));
            const rawData = dataBytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
            
            // Log the DID read operation
            await logAudit.mutateAsync({
              operation: "READ_DID",
              moduleCode: "RFHUB",
              success: true,
              riskLevel: "safe",
              details: JSON.stringify({ did: `0x${did.toString(16)}`, data: rawData }),
            });

            // Try to decode PIN from bytes
            const pins = decodePinFromBytes(dataBytes);
            
            for (const { encoding, pin } of pins) {
              candidates.push({
                did: `0x${did.toString(16).toUpperCase()}`,
                description,
                encoding,
                pin,
                rawData,
              });
            }
          }
        } catch (error) {
          console.warn(`Failed to read DID 0x${did.toString(16)}: ${error}`);
        }
      }

      if (candidates.length > 0) {
        setPinCandidates(candidates);
        
        // Most likely PIN is the first BCD-encoded one
        const bcdPins = candidates.filter(c => c.encoding === "BCD");
        if (bcdPins.length > 0) {
          setMostLikelyPin(bcdPins[0].pin);
        } else {
          setMostLikelyPin(candidates[0].pin);
        }

        toast.success(`Found ${candidates.length} PIN candidate(s)`);
      } else {
        toast.warning("No PIN found in standard locations");
      }
    } catch (error) {
      toast.error("Failed to extract PIN: " + (error as Error).message);
    } finally {
      setIsExtracting(false);
    }
  };

  const decodePinFromBytes = (bytes: number[]): Array<{ encoding: string; pin: string }> => {
    const pins: Array<{ encoding: string; pin: string }> = [];

    // Try BCD decoding (most common)
    if (bytes.length >= 2) {
      try {
        let bcdPin = "";
        for (let i = 0; i < 2; i++) {
          const high = (bytes[i] >> 4) & 0x0F;
          const low = bytes[i] & 0x0F;
          if (high <= 9 && low <= 9) {
            bcdPin += `${high}${low}`;
          }
        }
        if (bcdPin.length === 4 && /^\d{4}$/.test(bcdPin)) {
          pins.push({ encoding: "BCD", pin: bcdPin });
        }
      } catch (e) {
        // Ignore
      }
    }

    // Try binary decoding (big-endian 16-bit)
    if (bytes.length >= 2) {
      try {
        const binaryPin = (bytes[0] << 8) | bytes[1];
        if (binaryPin >= 1000 && binaryPin <= 9999) {
          pins.push({ encoding: "Binary", pin: binaryPin.toString().padStart(4, "0") });
        }
      } catch (e) {
        // Ignore
      }
    }

    // Try ASCII decoding
    if (bytes.length >= 4) {
      try {
        const asciiPin = String.fromCharCode(...bytes.slice(0, 4));
        if (/^\d{4}$/.test(asciiPin)) {
          pins.push({ encoding: "ASCII", pin: asciiPin });
        }
      } catch (e) {
        // Ignore
      }
    }

    // Try 5-digit BCD (newer models)
    if (bytes.length >= 3) {
      try {
        let bcdPin = "";
        for (let i = 0; i < 3; i++) {
          const high = (bytes[i] >> 4) & 0x0F;
          const low = bytes[i] & 0x0F;
          if (high <= 9 && low <= 9) {
            bcdPin += `${high}${low}`;
          }
        }
        // Take first 5 digits
        if (bcdPin.length >= 5 && /^\d{5}$/.test(bcdPin.substring(0, 5))) {
          pins.push({ encoding: "BCD-5", pin: bcdPin.substring(0, 5) });
        }
      } catch (e) {
        // Ignore
      }
    }

    return pins;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <Key className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">PIN EXTRACTION</h1>
            <p className="text-gray-600">
              Extract 4/5-digit immobilizer PIN from SKIM/RFHUB modules
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Extract PIN Code</CardTitle>
            <CardDescription>
              Reads PIN from RFHUB memory using DIDs 0xF18C, 0xF18D, 0xF18E, 0xF1A0, 0xF1A1
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={handleExtractPin}
              disabled={isExtracting}
              className="w-full gap-2"
            >
              {isExtracting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Extracting PIN...
                </>
              ) : (
                <>
                  <Key className="h-4 w-4" />
                  Extract PIN from RFHUB
                </>
              )}
            </Button>

            {isExtracting && (
              <p className="text-sm text-gray-600 text-center">
                Scanning multiple DID locations for PIN data...
              </p>
            )}
          </CardContent>
        </Card>

        {mostLikelyPin && (
          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle2 className="h-5 w-5" />
                Most Likely PIN
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-6xl font-black text-green-600 tracking-widest font-mono">
                  {mostLikelyPin}
                </div>
                <p className="text-sm text-green-700 mt-4">
                  This is the most likely immobilizer PIN based on encoding format
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {pinCandidates.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>All PIN Candidates</CardTitle>
              <CardDescription>
                Found {pinCandidates.length} possible PIN(s) from different locations and encodings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pinCandidates.map((candidate, index) => (
                  <div
                    key={index}
                    className="p-4 border rounded-lg bg-white"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-mono text-2xl font-bold text-gray-900">
                          {candidate.pin}
                        </div>
                        <div className="text-sm text-gray-600 mt-1">
                          {candidate.description} • {candidate.encoding} encoding
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          DID {candidate.did} • Raw: {candidate.rawData.substring(0, 20)}...
                        </div>
                      </div>
                      {candidate.encoding === "BCD" && (
                        <div className="px-3 py-1 bg-green-100 text-green-700 text-xs font-medium rounded">
                          Most Likely
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {!isExtracting && pinCandidates.length === 0 && (
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-900">How PIN Extraction Works</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-blue-900 space-y-2">
              <p>• Connects to RFHUB module via J2534</p>
              <p>• Reads multiple DID locations (0xF18C, 0xF18D, 0xF18E, 0xF1A0, 0xF1A1)</p>
              <p>• Decodes PIN from BCD, Binary, or ASCII formats</p>
              <p>• Supports both 4-digit (older) and 5-digit (newer) PINs</p>
              <p>• BCD encoding is most common format</p>
            </CardContent>
          </Card>
        )}

        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-900">⚠️ Important Notes</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-yellow-900 space-y-2">
            <p>• Requires active J2534 connection to vehicle</p>
            <p>• Vehicle must be in diagnostic mode</p>
            <p>• PIN is used for immobilizer programming</p>
            <p>• Keep PIN secure - it's a security credential</p>
            <p>• Some modules may store PIN at non-standard locations</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
