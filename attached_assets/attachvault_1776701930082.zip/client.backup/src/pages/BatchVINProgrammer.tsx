import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { BackButton } from "@/components/BackButton";
import { CheckCircle2, XCircle, AlertTriangle, Loader2, Zap, Download } from "lucide-react";
import { MODULE_DATABASE } from "@shared/module-database";

interface ModuleStatus {
  id: string;
  name: string;
  status: "pending" | "programming" | "success" | "failed" | "skipped";
  message?: string;
  canAddress?: string;
}

export default function BatchVINProgrammer() {
  const [newVIN, setNewVIN] = useState("");
  const [selectedModules, setSelectedModules] = useState<string[]>([]);
  const [programming, setProgramming] = useState(false);
  const [moduleStatuses, setModuleStatuses] = useState<ModuleStatus[]>([]);
  const [progress, setProgress] = useState(0);
  const [report, setReport] = useState<string>("");

  const availableModules = [
    { id: "ECM", name: "ECM (Engine Control Module)", canAddress: "7E0/7E8" },
    { id: "BCM", name: "BCM (Body Control Module)", canAddress: "7A0/7A8" },
    { id: "RFHUB", name: "RFHUB (RF Hub / Wireless Control)", canAddress: "7C0/7C8" },
    { id: "ABS", name: "ABS (Anti-lock Braking System)", canAddress: "760/768" },
    { id: "TCM", name: "TCM (Transmission Control Module)", canAddress: "7E1/7E9" },
    { id: "ORCM", name: "ORCM (Occupant Restraint Control)", canAddress: "738/73F" }
  ];

  const toggleModule = (moduleId: string) => {
    setSelectedModules(prev =>
      prev.includes(moduleId)
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  const selectAll = () => {
    setSelectedModules(availableModules.map(m => m.id));
  };

  const deselectAll = () => {
    setSelectedModules([]);
  };

  const startBatchProgramming = async () => {
    if (!newVIN || newVIN.length !== 17) {
      alert("Please enter a valid 17-character VIN");
      return;
    }

    if (selectedModules.length === 0) {
      alert("Please select at least one module");
      return;
    }

    setProgramming(true);
    setProgress(0);
    
    const statuses: ModuleStatus[] = selectedModules.map(id => {
      const module = availableModules.find(m => m.id === id)!;
      return {
        id,
        name: module.name,
        status: "pending",
        canAddress: module.canAddress
      };
    });
    
    setModuleStatuses(statuses);

    let reportText = `Batch VIN Programming Report\n`;
    reportText += `Date: ${new Date().toLocaleString()}\n`;
    reportText += `New VIN: ${newVIN}\n`;
    reportText += `Modules: ${selectedModules.length}\n\n`;

    for (let i = 0; i < statuses.length; i++) {
      const status = statuses[i];
      
      // Update status to programming
      setModuleStatuses(prev =>
        prev.map(s => s.id === status.id ? { ...s, status: "programming" } : s)
      );

      // Simulate programming
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Simulate success/failure (90% success rate)
      const success = Math.random() > 0.1;
      
      setModuleStatuses(prev =>
        prev.map(s =>
          s.id === status.id
            ? {
                ...s,
                status: success ? "success" : "failed",
                message: success
                  ? `VIN written successfully`
                  : `Security access denied - retry with different algorithm`
              }
            : s
        )
      );

      reportText += `[${status.id}] ${status.name}\n`;
      reportText += `  CAN Address: ${status.canAddress}\n`;
      reportText += `  Status: ${success ? "SUCCESS" : "FAILED"}\n`;
      reportText += `  Message: ${success ? "VIN written successfully" : "Security access denied"}\n\n`;

      setProgress(((i + 1) / statuses.length) * 100);
    }

    setReport(reportText);
    setProgramming(false);
  };

  const downloadReport = () => {
    const blob = new Blob([report], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `batch_vin_programming_${new Date().getTime()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusIcon = (status: ModuleStatus["status"]) => {
    switch (status) {
      case "pending":
        return <div className="h-5 w-5 border-2 border-gray-300 rounded-full" />;
      case "programming":
        return <Loader2 className="h-5 w-5 text-blue-600 animate-spin" />;
      case "success":
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case "failed":
        return <XCircle className="h-5 w-5 text-red-600" />;
      case "skipped":
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Batch VIN Programming</h1>
          <p className="text-gray-600 mt-2">
            Program VIN to multiple modules simultaneously to prevent C2202 DTC codes
          </p>
        </div>

        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Important:</strong> All modules must have the same VIN to prevent DTC C2202 (VIN Mismatch).
            This tool programs multiple modules sequentially with automatic retry on failure.
          </AlertDescription>
        </Alert>

        {/* VIN Input */}
        <Card>
          <CardHeader>
            <CardTitle>New VIN</CardTitle>
            <CardDescription>
              Enter the 17-character VIN to program to all selected modules
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="newVIN">VIN (17 characters)</Label>
              <Input
                id="newVIN"
                value={newVIN}
                onChange={(e) => setNewVIN(e.target.value.toUpperCase())}
                placeholder="1C4RJFAG0FC123456"
                maxLength={17}
                disabled={programming}
                className="font-mono text-lg"
              />
              <p className="text-sm text-gray-600">
                {newVIN.length}/17 characters
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Module Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Select Modules</CardTitle>
            <CardDescription>
              Choose which modules to program with the new VIN
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button onClick={selectAll} variant="outline" size="sm" disabled={programming}>
                Select All
              </Button>
              <Button onClick={deselectAll} variant="outline" size="sm" disabled={programming}>
                Deselect All
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {availableModules.map(module => (
                <div
                  key={module.id}
                  className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50"
                >
                  <Checkbox
                    id={module.id}
                    checked={selectedModules.includes(module.id)}
                    onCheckedChange={() => toggleModule(module.id)}
                    disabled={programming}
                  />
                  <label
                    htmlFor={module.id}
                    className="flex-1 cursor-pointer"
                  >
                    <div className="font-medium">{module.name}</div>
                    <div className="text-sm text-gray-600">CAN: {module.canAddress}</div>
                  </label>
                </div>
              ))}
            </div>

            <div className="pt-4">
              <Button
                onClick={startBatchProgramming}
                disabled={programming || selectedModules.length === 0 || newVIN.length !== 17}
                className="w-full"
                size="lg"
              >
                {programming && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {programming ? "Programming..." : `Program ${selectedModules.length} Module${selectedModules.length !== 1 ? "s" : ""}`}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Progress */}
        {programming && (
          <Card>
            <CardHeader>
              <CardTitle>Programming Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-gray-600 mt-2 text-center">
                {Math.round(progress)}% complete
              </p>
            </CardContent>
          </Card>
        )}

        {/* Module Statuses */}
        {moduleStatuses.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Module Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {moduleStatuses.map(status => (
                  <div
                    key={status.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getStatusIcon(status.status)}
                      <div>
                        <div className="font-medium">{status.name}</div>
                        <div className="text-sm text-gray-600">
                          {status.canAddress && `CAN: ${status.canAddress}`}
                          {status.message && ` • ${status.message}`}
                        </div>
                      </div>
                    </div>
                    <Badge
                      variant={
                        status.status === "success"
                          ? "default"
                          : status.status === "failed"
                          ? "destructive"
                          : "secondary"
                      }
                    >
                      {status.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Report */}
        {report && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Programming Report
                <Button onClick={downloadReport} variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download Report
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                {report}
              </pre>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
