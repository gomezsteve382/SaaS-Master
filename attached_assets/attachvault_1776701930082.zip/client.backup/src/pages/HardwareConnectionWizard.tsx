import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle2, XCircle, Usb, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { BackButton } from "@/components/BackButton";
import { ConnectionManager, type HardwareType } from "@/lib/obd2-protocol";

export default function HardwareConnectionWizard() {
  const { toast } = useToast();
  const [connectionManager] = useState(() => new ConnectionManager());
  const [connecting, setConnecting] = useState(false);
  const [connected, setConnected] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState<string>("");
  const [vin, setVin] = useState<string>("");

  const handleConnect = async () => {
    if (!('serial' in navigator)) {
      toast({
        title: "Web Serial Not Supported",
        description: "Your browser doesn't support Web Serial API. Please use Chrome, Edge, or Opera.",
        variant: "destructive",
      });
      return;
    }

    setConnecting(true);
    setConnected(false);
    setDeviceInfo("");
    setVin("");

    try {
      // Request serial port from user
      const port = await (navigator.serial as any).requestPort();
      
      toast({
        title: "Connecting to OBDLink...",
        description: "Initializing ELM327 adapter",
      });

      // Connect using ELM327 protocol
      const success = await connectionManager.connect('elm327', port);

      if (success) {
        setConnected(true);
        setDeviceInfo(`Connected via ${port.getInfo ? JSON.stringify(port.getInfo()) : 'Serial Port'}`);
        
        toast({
          title: "✅ Connected!",
          description: "OBDLink adapter connected successfully",
        });

        // Try to read VIN
        try {
          const protocol = connectionManager.getProtocol();
          if (protocol && 'readVIN' in protocol) {
            const vinResult = await (protocol as any).readVIN();
            if (vinResult) {
              setVin(vinResult);
              toast({
                title: "VIN Read Successfully",
                description: `Vehicle: ${vinResult}`,
              });
            }
          }
        } catch (vinError) {
          console.log("VIN read failed:", vinError);
        }
      } else {
        throw new Error("Connection failed");
      }
    } catch (error: any) {
      console.error("Connection error:", error);
      toast({
        title: "Connection Failed",
        description: error.message || "Could not connect to OBDLink",
        variant: "destructive",
      });
      setConnected(false);
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    await connectionManager.disconnect();
    setConnected(false);
    setDeviceInfo("");
    setVin("");
    toast({
      title: "Disconnected",
      description: "OBDLink adapter disconnected",
    });
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <BackButton />
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Hardware Connection Wizard</h1>
        <p className="text-muted-foreground">
          Connect your OBDLink EX adapter to your vehicle and computer
        </p>
      </div>

      <div className="grid gap-6">
        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle>Connection Status</CardTitle>
            <CardDescription>
              OBDLink EX / ELM327 Adapter
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {connected ? (
              <Alert className="border-green-500 bg-green-50">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  <strong>Connected</strong>
                  <div className="mt-2 text-sm">{deviceInfo}</div>
                  {vin && (
                    <div className="mt-2">
                      <Badge variant="outline" className="bg-white">
                        VIN: {vin}
                      </Badge>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            ) : (
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  Not connected. Click "Connect to OBDLink" to begin.
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-3">
              {!connected ? (
                <Button
                  onClick={handleConnect}
                  disabled={connecting}
                  className="flex items-center gap-2"
                >
                  {connecting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    <>
                      <Usb className="h-4 w-4" />
                      Connect to OBDLink
                    </>
                  )}
                </Button>
              ) : (
                <Button
                  onClick={handleDisconnect}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <XCircle className="h-4 w-4" />
                  Disconnect
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Setup Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <Badge className="mt-1">1</Badge>
              <div>
                <p className="font-medium">Connect OBDLink to Vehicle</p>
                <p className="text-sm text-muted-foreground">
                  Plug your OBDLink EX into the vehicle's OBD2 port (usually under the dashboard)
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="mt-1">2</Badge>
              <div>
                <p className="font-medium">Turn Ignition ON</p>
                <p className="text-sm text-muted-foreground">
                  Turn the vehicle ignition to ON position (engine can stay off)
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="mt-1">3</Badge>
              <div>
                <p className="font-medium">Connect to Computer</p>
                <p className="text-sm text-muted-foreground">
                  Connect OBDLink to your computer via USB cable
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="mt-1">4</Badge>
              <div>
                <p className="font-medium">Click "Connect to OBDLink"</p>
                <p className="text-sm text-muted-foreground">
                  Select your OBDLink device from the browser's serial port picker
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Troubleshooting */}
        <Card>
          <CardHeader>
            <CardTitle>Troubleshooting</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p><strong>Green light on OBDLink but connection fails?</strong></p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
              <li>Make sure you're using Chrome, Edge, or Opera browser (Web Serial API required)</li>
              <li>Check that OBDLink drivers are installed on your computer</li>
              <li>Try unplugging and replugging the USB cable</li>
              <li>Verify vehicle ignition is ON</li>
            </ul>
            
            <p className="mt-4"><strong>No devices shown in serial port picker?</strong></p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
              <li>Install OBDLink drivers from ScanTool.net</li>
              <li>Check USB cable connection</li>
              <li>Try a different USB port</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
