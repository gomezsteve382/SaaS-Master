import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { BackButton } from "@/components/BackButton";
import { trpc } from "@/lib/trpc";
import { ArrowRight, Check, AlertCircle, Download } from "lucide-react";

type SwapScenario = "BCM" | "ECM" | "RFHUB" | "TCM" | "ABS";
type SwapStep = "scenario" | "read-old" | "backup" | "read-new" | "transfer" | "verify" | "report";

export default function ModuleSwapWizard() {
  const [currentStep, setCurrentStep] = useState<SwapStep>("scenario");
  const [scenario, setScenario] = useState<SwapScenario | null>(null);
  const [oldModuleId, setOldModuleId] = useState("");
  const [newModuleId, setNewModuleId] = useState("");
  
  // Transfer options
  const [transferOriginalVIN, setTransferOriginalVIN] = useState(true);
  const [transferCurrentVIN, setTransferCurrentVIN] = useState(true);
  const [transferSecurityBytes, setTransferSecurityBytes] = useState(true);
  const [transferFeatureBytes, setTransferFeatureBytes] = useState(true);
  const [transferCalibration, setTransferCalibration] = useState(true);
  
  // Module data
  const [oldModuleData, setOldModuleData] = useState<any>(null);
  const [newModuleData, setNewModuleData] = useState<any>(null);
  const [swapReport, setSwapReport] = useState<any>(null);
  
  const readOldModuleMutation = trpc.moduleSwap.readOldModule.useMutation();
  const readNewModuleMutation = trpc.moduleSwap.readNewModule.useMutation();
  const transferDataMutation = trpc.moduleSwap.transferData.useMutation();
  const verifyPairingMutation = trpc.moduleSwap.verifyPairing.useMutation();
  const performSwapMutation = trpc.moduleSwap.performSwap.useMutation();
  const generateReportMutation = trpc.moduleSwap.generateSwapReport.useMutation();
  
  const scenarios = [
    {
      name: "BCM" as SwapScenario,
      title: "BCM Replacement",
      description: "Body Control Module - Handles lighting, locks, windows, and vehicle features",
      transfers: ["VINs", "Security Bytes", "Feature Bytes"],
      pairing: "RFHUB",
    },
    {
      name: "ECM" as SwapScenario,
      title: "ECM Replacement",
      description: "Engine Control Module - Manages engine performance and emissions",
      transfers: ["VINs", "Security Bytes", "Calibration Data"],
      pairing: "TCM",
    },
    {
      name: "RFHUB" as SwapScenario,
      title: "RFHUB Replacement",
      description: "SmartBox - Handles key fobs and immobilizer security",
      transfers: ["VINs", "Security Bytes", "PIN Code"],
      pairing: "BCM",
    },
    {
      name: "TCM" as SwapScenario,
      title: "TCM Replacement",
      description: "Transmission Control Module - Controls transmission shifting",
      transfers: ["VINs", "Security Bytes", "Calibration Data"],
      pairing: "ECM",
    },
    {
      name: "ABS" as SwapScenario,
      title: "ABS Replacement",
      description: "Anti-lock Braking System - Manages brake control and stability",
      transfers: ["VINs", "Security Bytes"],
      pairing: "None",
    },
  ];
  
  const handleSelectScenario = (selectedScenario: SwapScenario) => {
    setScenario(selectedScenario);
    setCurrentStep("read-old");
  };
  
  const handleReadOldModule = async () => {
    if (!scenario || !oldModuleId) return;
    
    const result = await readOldModuleMutation.mutateAsync({
      moduleId: oldModuleId,
      moduleName: scenario,
    });
    
    setOldModuleData(result);
    setCurrentStep("backup");
  };
  
  const handleCreateBackup = () => {
    // Backup is automatic - just move to next step
    setCurrentStep("read-new");
  };
  
  const handleReadNewModule = async () => {
    if (!scenario || !newModuleId) return;
    
    const result = await readNewModuleMutation.mutateAsync({
      moduleId: newModuleId,
      moduleName: scenario,
    });
    
    setNewModuleData(result);
    setCurrentStep("transfer");
  };
  
  const handleTransferData = async () => {
    if (!scenario || !newModuleId || !oldModuleData) return;
    
    await transferDataMutation.mutateAsync({
      newModuleId,
      moduleName: scenario,
      oldModuleData,
      transferOriginalVIN,
      transferCurrentVIN,
      transferSecurityBytes,
      transferFeatureBytes,
      transferCalibration,
    });
    
    setCurrentStep("verify");
  };
  
  const handleVerifyPairing = async () => {
    if (!scenario) return;
    
    await verifyPairingMutation.mutateAsync({
      moduleName: scenario,
    });
    
    setCurrentStep("report");
  };
  
  const handleGenerateReport = async () => {
    if (!scenario || !oldModuleData || !newModuleData) return;
    
    const transferredItems = [];
    if (transferOriginalVIN) transferredItems.push("Original VIN");
    if (transferCurrentVIN) transferredItems.push("Current VIN");
    if (transferSecurityBytes) transferredItems.push("Security Bytes");
    if (transferFeatureBytes) transferredItems.push("Feature Bytes");
    if (transferCalibration) transferredItems.push("Calibration Data");
    
    const report = await generateReportMutation.mutateAsync({
      scenario,
      oldModuleData,
      newModuleData,
      transferredItems,
    });
    
    setSwapReport(report);
  };
  
  const handleDownloadReport = () => {
    if (!swapReport) return;
    
    const blob = new Blob([JSON.stringify(swapReport, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `module-swap-report-${swapReport.reportId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  
  const handleStartOver = () => {
    setCurrentStep("scenario");
    setScenario(null);
    setOldModuleId("");
    setNewModuleId("");
    setOldModuleData(null);
    setNewModuleData(null);
    setSwapReport(null);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8">
      <div className="container max-w-5xl">
        <BackButton />
      <div className="mb-8">
          <h1 className="text-4xl font-black uppercase tracking-tight mb-2">Module Swap Wizard</h1>
          <p className="text-muted-foreground">Guided workflow for common module replacement scenarios</p>
        </div>
        
        {/* Progress Steps */}
        <div className="mb-8 flex items-center gap-2 overflow-x-auto pb-2">
          {[
            { id: "scenario", label: "Scenario" },
            { id: "read-old", label: "Read Old" },
            { id: "backup", label: "Backup" },
            { id: "read-new", label: "Read New" },
            { id: "transfer", label: "Transfer" },
            { id: "verify", label: "Verify" },
            { id: "report", label: "Report" },
          ].map((step, index) => (
            <div key={step.id} className="flex items-center gap-2">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                currentStep === step.id
                  ? "bg-red-600 text-white"
                  : ["scenario", "read-old", "backup", "read-new", "transfer", "verify", "report"]
                      .indexOf(currentStep) > index
                  ? "bg-green-600 text-white"
                  : "bg-gray-200 text-gray-600"
              }`}>
                {["scenario", "read-old", "backup", "read-new", "transfer", "verify", "report"]
                  .indexOf(currentStep) > index ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <span className="w-4 h-4 flex items-center justify-center text-xs font-bold">
                    {index + 1}
                  </span>
                )}
                <span className="text-sm font-medium whitespace-nowrap">{step.label}</span>
              </div>
              {index < 6 && <ArrowRight className="w-4 h-4 text-gray-400" />}
            </div>
          ))}
        </div>
        
        {/* Step 1: Select Scenario */}
        {currentStep === "scenario" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Select Replacement Scenario</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {scenarios.map((s) => (
                <Card
                  key={s.name}
                  className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:border-red-500"
                  onClick={() => handleSelectScenario(s.name)}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {s.title}
                      <Badge variant="outline">{s.pairing !== "None" ? `Pairs with ${s.pairing}` : "Standalone"}</Badge>
                    </CardTitle>
                    <CardDescription>{s.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {s.transfers.map((transfer) => (
                        <Badge key={transfer} variant="secondary">{transfer}</Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
        
        {/* Step 2: Read Old Module */}
        {currentStep === "read-old" && (
          <Card>
            <CardHeader>
              <CardTitle>Read Old {scenario} Module Data</CardTitle>
              <CardDescription>
                Connect to the old module and read all configuration data
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="old-module-id">Old Module ID / CAN Address</Label>
                <Input
                  id="old-module-id"
                  value={oldModuleId}
                  onChange={(e) => setOldModuleId(e.target.value)}
                  placeholder="e.g., 0x710"
                />
              </div>
              
              <Button
                onClick={handleReadOldModule}
                disabled={!oldModuleId || readOldModuleMutation.isPending}
                className="w-full"
              >
                {readOldModuleMutation.isPending ? "Reading..." : "Read Old Module"}
              </Button>
              
              {oldModuleData && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Check className="w-5 h-5 text-green-600" />
                    <span className="font-bold text-green-900">Module Data Read Successfully</span>
                  </div>
                  <div className="text-sm text-green-800 space-y-1">
                    <div>Original VIN: {oldModuleData.originalVIN}</div>
                    <div>Current VIN: {oldModuleData.currentVIN}</div>
                    <div>Security Bytes: {oldModuleData.securityBytes}</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* Step 3: Create Backup */}
        {currentStep === "backup" && (
          <Card>
            <CardHeader>
              <CardTitle>Create Backup</CardTitle>
              <CardDescription>
                Automatic backup of old module configuration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="w-5 h-5 text-blue-600" />
                  <span className="font-bold text-blue-900">Backup Created Automatically</span>
                </div>
                <p className="text-sm text-blue-800">
                  A complete backup of the old module configuration has been saved. You can restore this backup
                  from the Module Backup & Restore page if needed.
                </p>
              </div>
              
              <Button onClick={handleCreateBackup} className="w-full">
                Continue to Read New Module
              </Button>
            </CardContent>
          </Card>
        )}
        
        {/* Step 4: Read New Module */}
        {currentStep === "read-new" && (
          <Card>
            <CardHeader>
              <CardTitle>Read New {scenario} Module Status</CardTitle>
              <CardDescription>
                Connect to the new module and check if it's virgin or programmed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="new-module-id">New Module ID / CAN Address</Label>
                <Input
                  id="new-module-id"
                  value={newModuleId}
                  onChange={(e) => setNewModuleId(e.target.value)}
                  placeholder="e.g., 0x710"
                />
              </div>
              
              <Button
                onClick={handleReadNewModule}
                disabled={!newModuleId || readNewModuleMutation.isPending}
                className="w-full"
              >
                {readNewModuleMutation.isPending ? "Reading..." : "Read New Module"}
              </Button>
              
              {newModuleData && (
                <div className={`mt-4 p-4 border rounded-lg ${
                  newModuleData.isVirgin
                    ? "bg-green-50 border-green-200"
                    : "bg-yellow-50 border-yellow-200"
                }`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Check className={`w-5 h-5 ${
                      newModuleData.isVirgin ? "text-green-600" : "text-yellow-600"
                    }`} />
                    <span className={`font-bold ${
                      newModuleData.isVirgin ? "text-green-900" : "text-yellow-900"
                    }`}>
                      {newModuleData.isVirgin ? "Virgin Module Detected" : "Programmed Module Detected"}
                    </span>
                  </div>
                  <p className={`text-sm ${
                    newModuleData.isVirgin ? "text-green-800" : "text-yellow-800"
                  }`}>
                    {newModuleData.isVirgin
                      ? "This module has never been programmed. Safe to write all data."
                      : "This module has been programmed before. Existing data will be overwritten."}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* Step 5: Transfer Data */}
        {currentStep === "transfer" && (
          <Card>
            <CardHeader>
              <CardTitle>Transfer Data to New Module</CardTitle>
              <CardDescription>
                Select which data to transfer from old module to new module
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="transfer-original-vin"
                    checked={transferOriginalVIN}
                    onCheckedChange={(checked) => setTransferOriginalVIN(!!checked)}
                  />
                  <Label htmlFor="transfer-original-vin" className="cursor-pointer">
                    Transfer Original VIN (DID 0xF19E)
                  </Label>
                </div>
                
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="transfer-current-vin"
                    checked={transferCurrentVIN}
                    onCheckedChange={(checked) => setTransferCurrentVIN(!!checked)}
                  />
                  <Label htmlFor="transfer-current-vin" className="cursor-pointer">
                    Transfer Current VIN (DID 0xF190)
                  </Label>
                </div>
                
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="transfer-security-bytes"
                    checked={transferSecurityBytes}
                    onCheckedChange={(checked) => setTransferSecurityBytes(!!checked)}
                  />
                  <Label htmlFor="transfer-security-bytes" className="cursor-pointer">
                    Transfer Security Bytes
                  </Label>
                </div>
                
                {scenario === "BCM" && (
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="transfer-feature-bytes"
                      checked={transferFeatureBytes}
                      onCheckedChange={(checked) => setTransferFeatureBytes(!!checked)}
                    />
                    <Label htmlFor="transfer-feature-bytes" className="cursor-pointer">
                      Transfer Feature Bytes (BCM Configuration)
                    </Label>
                  </div>
                )}
                
                {(scenario === "ECM" || scenario === "TCM") && (
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="transfer-calibration"
                      checked={transferCalibration}
                      onCheckedChange={(checked) => setTransferCalibration(!!checked)}
                    />
                    <Label htmlFor="transfer-calibration" className="cursor-pointer">
                      Transfer Calibration Data ({scenario} Tuning)
                    </Label>
                  </div>
                )}
              </div>
              
              <Button
                onClick={handleTransferData}
                disabled={transferDataMutation.isPending}
                className="w-full"
              >
                {transferDataMutation.isPending ? "Transferring..." : "Transfer Data"}
              </Button>
              
              {transferDataMutation.isSuccess && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Check className="w-5 h-5 text-green-600" />
                    <span className="font-bold text-green-900">Data Transfer Completed</span>
                  </div>
                  <p className="text-sm text-green-800">
                    All selected data has been written to the new module successfully.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* Step 6: Verify Pairing */}
        {currentStep === "verify" && (
          <Card>
            <CardHeader>
              <CardTitle>Verify Module Pairing</CardTitle>
              <CardDescription>
                Verify that the new module is properly paired with other modules
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={handleVerifyPairing}
                disabled={verifyPairingMutation.isPending}
                className="w-full"
              >
                {verifyPairingMutation.isPending ? "Verifying..." : "Verify Pairing"}
              </Button>
              
              {verifyPairingMutation.isSuccess && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Check className="w-5 h-5 text-green-600" />
                    <span className="font-bold text-green-900">Pairing Verified</span>
                  </div>
                  <p className="text-sm text-green-800">
                    Module pairing checks passed. The new {scenario} is properly synchronized with other modules.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* Step 7: Generate Report */}
        {currentStep === "report" && (
          <Card>
            <CardHeader>
              <CardTitle>Swap Complete - Generate Report</CardTitle>
              <CardDescription>
                Module swap completed successfully. Generate a detailed report for your records.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-4">
                  <Check className="w-6 h-6 text-green-600" />
                  <span className="text-lg font-bold text-green-900">{scenario} Swap Completed Successfully</span>
                </div>
                
                {swapReport && (
                  <div className="space-y-2 text-sm text-green-800">
                    <div><strong>Report ID:</strong> {swapReport.reportId}</div>
                    <div><strong>Timestamp:</strong> {new Date(swapReport.timestamp).toLocaleString()}</div>
                    <div><strong>Old Module:</strong> {swapReport.oldModule.id}</div>
                    <div><strong>New Module:</strong> {swapReport.newModule.id}</div>
                    <div><strong>Transferred Items:</strong> {swapReport.transferredItems.join(", ")}</div>
                  </div>
                )}
              </div>
              
              {!swapReport && (
                <Button
                  onClick={handleGenerateReport}
                  disabled={generateReportMutation.isPending}
                  className="w-full"
                >
                  {generateReportMutation.isPending ? "Generating..." : "Generate Report"}
                </Button>
              )}
              
              {swapReport && (
                <div className="flex gap-2">
                  <Button onClick={handleDownloadReport} className="flex-1">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                  <Button onClick={handleStartOver} variant="outline" className="flex-1">
                    Start New Swap
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
