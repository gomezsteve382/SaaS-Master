import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BackButton } from "@/components/BackButton";
import { Download, CheckCircle2, XCircle, Clock, TrendingUp, Layers } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CloneHistoryAnalytics() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [filterModule, setFilterModule] = useState("");

  const operationsQuery = trpc.cloneAnalytics.getCloneOperations.useQuery({
    page,
    pageSize: 50,
    filterModule,
  });

  const statsQuery = trpc.cloneAnalytics.getCloneStatistics.useQuery({});
  const batchesQuery = trpc.cloneAnalytics.getBatchOperations.useQuery();
  const profilesQuery = trpc.cloneAnalytics.getProfileUsage.useQuery();
  const exportMutation = trpc.cloneAnalytics.exportAnalytics.useMutation();

  const handleExport = async () => {
    try {
      const result = await exportMutation.mutateAsync({
        filterModule,
      });

      // Create download
      const blob = new Blob([result.data], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export successful",
        description: `Exported ${operationsQuery.data?.total || 0} clone operations to CSV`,
      });
    } catch (error: any) {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    return status === "success" ? (
      <Badge className="bg-green-600 flex items-center gap-1 w-fit">
        <CheckCircle2 className="h-3 w-3" />
        Success
      </Badge>
    ) : (
      <Badge variant="destructive" className="flex items-center gap-1 w-fit">
        <XCircle className="h-3 w-3" />
        Failed
      </Badge>
    );
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Clone History & Analytics</h1>
        <p className="text-muted-foreground">
          Track module clone operations with success rates, timing analytics, and profile usage
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Clones</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsQuery.data?.statistics?.totalClones || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {statsQuery.data?.statistics?.successRate || "0.0"}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Clone Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold flex items-center gap-2">
              {statsQuery.data?.statistics?.avgCloneTime || "0.00"}
              <span className="text-sm font-normal text-muted-foreground">sec</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Failed Clones</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {statsQuery.data?.statistics?.failedClones || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Operations Table */}
        <div className="lg:col-span-2 space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filters</CardTitle>
              <CardDescription>Filter clone operations by module</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1 space-y-2">
                  <Label>Module</Label>
                  <Input
                    placeholder="e.g., RFHUB, BCM"
                    value={filterModule}
                    onChange={(e) => setFilterModule(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExport}
                  disabled={exportMutation.isPending || !operationsQuery.data?.operations.length}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setFilterModule("")}
                >
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Clone Operations Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Clone Operations</CardTitle>
                  <CardDescription>
                    Showing {operationsQuery.data?.operations.length || 0} of {operationsQuery.data?.total || 0} operations
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-[600px] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead className="w-[140px]">Timestamp</TableHead>
                        <TableHead className="w-[100px]">Module</TableHead>
                        <TableHead>Source → Target</TableHead>
                        <TableHead className="w-[100px]">Time</TableHead>
                        <TableHead className="w-[100px]">Status</TableHead>
                        <TableHead>Profile</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {operationsQuery.isLoading ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                            Loading operations...
                          </TableCell>
                        </TableRow>
                      ) : !operationsQuery.data?.operations.length ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                            No clone operations found
                          </TableCell>
                        </TableRow>
                      ) : (
                        operationsQuery.data.operations.map((op: any) => (
                          <TableRow key={op.id}>
                            <TableCell className="font-mono text-xs">
                              {new Date(op.timestamp).toLocaleString()}
                            </TableCell>
                            <TableCell className="font-semibold">{op.module || "N/A"}</TableCell>
                            <TableCell className="font-mono text-xs">
                              {op.sourceModule} → {op.targetModule}
                            </TableCell>
                            <TableCell className="font-mono">
                              {op.cloneTime > 0 ? `${op.cloneTime.toFixed(2)}s` : "N/A"}
                            </TableCell>
                            <TableCell>{getStatusBadge(op.status)}</TableCell>
                            <TableCell className="text-sm">
                              {op.profileUsed || <span className="text-muted-foreground">Manual</span>}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Pagination */}
              {operationsQuery.data && operationsQuery.data.pageSize && operationsQuery.data.total > operationsQuery.data.pageSize && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Page {page} of {Math.ceil(operationsQuery.data.total / operationsQuery.data.pageSize)}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(page - 1)}
                      disabled={page === 1}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(page + 1)}
                      disabled={page >= Math.ceil(operationsQuery.data.total / operationsQuery.data.pageSize)}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar: Analytics */}
        <div className="space-y-6">
          {/* Module Success Rate */}
          <Card>
            <CardHeader>
              <CardTitle>Success Rate by Module</CardTitle>
              <CardDescription>Clone success rates per module type</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {statsQuery.data?.statistics?.moduleSuccessRate?.map((item: any, index: number) => (
                <div key={item.module} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold">{item.module}</span>
                    <span className="text-muted-foreground">
                      {item.successRate}% ({item.total} total)
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-600 to-emerald-600"
                      style={{ width: `${item.successRate}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Profile Usage */}
          <Card>
            <CardHeader>
              <CardTitle>Profile Usage</CardTitle>
              <CardDescription>Most used clone profiles</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {profilesQuery.data?.profiles?.slice(0, 5).map((item: any, index: number) => (
                <div key={item.profile} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{item.profile}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">{item.count}</span>
                    <Badge variant="outline">{item.percentage}%</Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Batch Operations */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Batch Operations</CardTitle>
              <CardDescription>Sessions with multiple clones</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {batchesQuery.data?.batches?.map((batch: any, index: number) => (
                <div key={batch.sessionId} className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs text-muted-foreground">
                      {batch.sessionId.substring(0, 8)}...
                    </span>
                    <Badge variant="outline">{batch.count} clones</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {new Date(batch.timestamp).toLocaleDateString()}
                    </span>
                    <div className="flex gap-2">
                      <span className="text-green-600">{batch.successCount} ✓</span>
                      {batch.failureCount > 0 && (
                        <span className="text-red-600">{batch.failureCount} ✗</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Module Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Module Distribution</CardTitle>
              <CardDescription>Most cloned module types</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {statsQuery.data?.statistics?.moduleDistribution?.map((item: any, index: number) => (
                <div key={item.module} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold">{item.module}</span>
                    <span className="text-muted-foreground">
                      {item.count} ({item.percentage}%)
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-cyan-600"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
