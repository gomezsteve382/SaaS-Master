import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { BackButton } from "@/components/BackButton";
import { Copy, Download, Key, FileText, Database, Upload } from 'lucide-react';

export default function RFHUBPINExtractor() {
  const [method1PIN, setMethod1PIN] = useState<string>('');
  const [method2PIN, setMethod2PIN] = useState<string>('');
  const [method3PIN, setMethod3PIN] = useState<string>('');
  const [eepromData, setEepromData] = useState<string>('');
  const [udsResponse, setUdsResponse] = useState<string>('');
  const [securityBytes, setSecurityBytes] = useState<Record<string, string>>({});
  const [extracting, setExtracting] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');

  // Load calibration files from backend
  const calibrationFilesQuery = trpc.vinPatcher.listCalibrationFiles.useQuery();
  const keyProgrammingQuery = trpc.alphaOBD.getKeyProgrammingProcedures.useQuery(
    undefined,
    { enabled: false }
  );

  // Filter RFHUB files
  const rfhubFiles = calibrationFilesQuery.data?.filter((f: any) => 
    f.moduleType === 'RFHUB' || f.filename.toLowerCase().includes('rfhub')
  ) || [];

  // Load calibration file from backend
  const loadCalibrationFile = async (filename: string) => {
    try {
      const response = await fetch(`/api/trpc/vinPatcher.downloadCalibrationFile?input=${encodeURIComponent(JSON.stringify({ filename }))}`);
      const result = await response.json();
      if (result.result?.data) {
        const fileData = result.result.data;
        // Convert base64 to hex string
        const bytes = atob(fileData.data);
        const hexStr = Array.from(bytes)
          .map((c: string) => c.charCodeAt(0).toString(16).padStart(2, '0'))
          .join(' ');
        setEepromData(hexStr);
      }
    } catch (error: any) {
      alert(`Failed to load file: ${error.message}`);
    }
  };

  // Handle local file upload
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    setExtracting(true);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      
      // Convert binary to hex string
      const hexStr = Array.from(uint8Array)
        .map(b => b.toString(16).padStart(2, '0'))
        .join(' ');
      
      setEepromData(hexStr);
      setExtracting(false);
    } catch (error: any) {
      alert(`Failed to read file: ${error.message}`);
      setExtracting(false);
    }
  };
  // Method 1: UDS ReadDataByIdentifier (22 F1 8C)
  const extractPINViaUDS = async () => {
    setExtracting(true);
    setMethod1PIN('');
    setUdsResponse('');
    
    try {
      // Get connection manager instance
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        throw new Error('Not connected to vehicle. Please connect OBDLink/J2534 adapter first.');
      }
      
      // RFHUB CAN addresses (try multiple known addresses)
      const rfhubAddresses = [
        { tx: 0x744, rx: 0x74C, name: 'RFHUB Primary' },
        { tx: 0x745, rx: 0x74D, name: 'RFHUB Secondary' },
      ];

      let response: Uint8Array | null = null;
      let usedAddress = rfhubAddresses[0];

      // Try each RFHUB address
      for (const addr of rfhubAddresses) {
        try {
          // Read DID 0xF18C (PIN Code)
          const resp = await protocol.sendUDS(addr.tx, addr.rx, [0x22, 0xF1, 0x8C], 2);
          if (resp && resp[0] === 0x62) {
            response = resp;
            usedAddress = addr;
            break;
          }
        } catch (e) {
          // Try next address
          continue;
        }
      }

      if (!response || response[0] !== 0x62) {
        throw new Error('Failed to read PIN from RFHUB. Module may not respond or PIN DID not supported.');
      }

      // Format response for display
      const responseStr = Array.from(response).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
      setUdsResponse(responseStr);
      
      // Extract PIN bytes (BCD format)
      // Response format: 62 F1 8C [PIN_BYTE_1] [PIN_BYTE_2]
      if (response.length >= 5) {
        const pinByte1 = response[3];
        const pinByte2 = response[4];
        
        // Convert BCD to decimal PIN (each nibble is a digit)
        const pin = `${pinByte1.toString(16).padStart(2, '0')}${pinByte2.toString(16).padStart(2, '0')}`;
        setMethod1PIN(pin.toUpperCase());
      } else {
        throw new Error('Invalid response format from RFHUB');
      }
      
    } catch (error: any) {
      alert(`Failed to extract PIN via UDS: ${error.message}`);
      setMethod1PIN('Error');
    } finally {
      setExtracting(false);
    }
  };

  // Method 2: EEPROM Direct Read
  const extractPINFromEEPROM = () => {
    if (!eepromData.trim()) {
      alert('Please paste EEPROM hex dump first');
      return;
    }
    
    setExtracting(true);
    
    setTimeout(() => {
      // Search for pattern: 1F 00 [PIN_BYTE_1] [PIN_BYTE_2]
      const hexBytes = eepromData.replace(/[^0-9A-Fa-f]/g, '').match(/.{1,2}/g) || [];
      
      for (let i = 0; i < hexBytes.length - 3; i++) {
        if (hexBytes[i] === '1F' || hexBytes[i] === '1f') {
          if (hexBytes[i + 1] === '00') {
            // Found pattern!
            const pinByte1 = hexBytes[i + 2];
            const pinByte2 = hexBytes[i + 3];
            const pin = `${pinByte1}${pinByte2}`.toUpperCase();
            setMethod2PIN(pin);
            setExtracting(false);
            return;
          }
        }
      }
      
      setMethod2PIN('Pattern not found');
      setExtracting(false);
    }, 1000);
  };

  // Method 3: Security Bytes Extraction
  const extractSecurityBytes = () => {
    if (!eepromData.trim()) {
      alert('Please paste EEPROM hex dump first');
      return;
    }
    
    setExtracting(true);
    
    setTimeout(() => {
      const hexBytes = eepromData.replace(/[^0-9A-Fa-f]/g, '').match(/.{1,2}/g) || [];
      
      const offsets = {
        'Pairing Bytes 1 (0x0100)': { offset: 0x0100, length: 8 },
        'Pairing Bytes 2 (0x0108)': { offset: 0x0108, length: 8 },
        'Secret Key 1 (0x0220)': { offset: 0x0220, length: 16 },
        'Secret Key 2 (0x0230)': { offset: 0x0230, length: 16 },
        'Secret Key 3 (0x0240)': { offset: 0x0240, length: 16 },
        'Challenge Seed (0x0510)': { offset: 0x0510, length: 8 },
        'Response Key (0x0518)': { offset: 0x0518, length: 8 },
      };
      
      const extracted: Record<string, string> = {};
      
      for (const [name, { offset, length }] of Object.entries(offsets)) {
        const bytes = hexBytes.slice(offset, offset + length);
        extracted[name] = bytes.join(' ').toUpperCase();
      }
      
      setSecurityBytes(extracted);
      
      // Try to extract PIN from pairing bytes
      const pairingBytes = hexBytes.slice(0x0100, 0x0108);
      // Look for PIN pattern in first 8 bytes
      for (let i = 0; i < pairingBytes.length - 1; i++) {
        const byte1 = parseInt(pairingBytes[i], 16);
        const byte2 = parseInt(pairingBytes[i + 1], 16);
        if (byte1 >= 0x10 && byte1 <= 0x99 && byte2 >= 0x00 && byte2 <= 0x99) {
          setMethod3PIN(`${pairingBytes[i]}${pairingBytes[i + 1]}`.toUpperCase());
          break;
        }
      }
      
      setExtracting(false);
    }, 1500);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportResults = () => {
    const results = {
      method1_uds: method1PIN,
      method2_eeprom: method2PIN,
      method3_security_bytes: method3PIN,
      uds_response: udsResponse,
      security_bytes: securityBytes,
      timestamp: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(results, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rfhub_pin_extraction_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">RFHUB PIN Extractor</h1>
          <p className="text-muted-foreground mt-2">
            Extract SKIM/SKREEM PIN from RFHUB module using 3 different methods
          </p>
        </div>
        <Badge variant="outline" className="text-lg px-4 py-2">
          <Key className="w-4 h-4 mr-2" />
          3 Methods
        </Badge>
      </div>

      <Alert>
        <AlertDescription>
          <strong>What is RFHUB PIN?</strong> The RFHUB (RF Hub) module stores the 4-digit SKIM PIN required for key programming, 
          BCM replacement, and immobilizer synchronization on 2008+ Chrysler/Dodge/Jeep/RAM vehicles.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="method1" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="method1">Method 1: UDS</TabsTrigger>
          <TabsTrigger value="method2">Method 2: EEPROM</TabsTrigger>
          <TabsTrigger value="method3">Method 3: Security Bytes</TabsTrigger>
        </TabsList>

        {/* Method 1: UDS ReadDataByIdentifier */}
        <TabsContent value="method1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Method 1: UDS ReadDataByIdentifier
              </CardTitle>
              <CardDescription>
                Read PIN directly from RFHUB via OBD2 using UDS command <code>22 F1 8C</code>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <p className="text-sm font-mono">
                  <strong>TX:</strong> 22 F1 8C (Read DID F18C - PIN Code)
                </p>
                <p className="text-sm font-mono">
                  <strong>RX:</strong> 62 F1 8C [PIN_BYTE_1] [PIN_BYTE_2]
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Example: <code>62 F1 8C 12 34</code> = PIN <strong>1234</strong> (BCD format)
                </p>
              </div>

              <Button 
                onClick={extractPINViaUDS} 
                disabled={extracting}
                className="w-full"
              >
                {extracting ? 'Extracting...' : 'Extract PIN via UDS'}
              </Button>

              {udsResponse && (
                <div className="space-y-2">
                  <Label>UDS Response:</Label>
                  <div className="flex gap-2">
                    <Input value={udsResponse} readOnly className="font-mono" />
                    <Button size="icon" variant="outline" onClick={() => copyToClipboard(udsResponse)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}

              {method1PIN && (
                <div className="space-y-2">
                  <Label>Extracted PIN:</Label>
                  <div className="flex gap-2">
                    <Input 
                      value={method1PIN} 
                      readOnly 
                      className="font-mono text-2xl font-bold text-center"
                    />
                    <Button size="icon" variant="outline" onClick={() => copyToClipboard(method1PIN)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Method 2: EEPROM Direct Read */}
        <TabsContent value="method2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Method 2: EEPROM Direct Read
              </CardTitle>
              <CardDescription>
                Search for PIN pattern <code>1F 00 [PIN_BYTE_1] [PIN_BYTE_2]</code> in EEPROM dump
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Upload local file */}
              <div className="space-y-2">
                <Label htmlFor="file-upload">Upload RFHUB .bin File:</Label>
                <div className="flex gap-2">
                  <label htmlFor="file-upload" className="flex-1">
                    <div className="flex items-center justify-center w-full h-10 px-4 border-2 border-dashed rounded-md cursor-pointer hover:border-primary transition-colors">
                      <Upload className="w-4 h-4 mr-2" />
                      <span className="text-sm">
                        {uploadedFileName || 'Choose .bin file...'}
                      </span>
                    </div>
                    <input
                      id="file-upload"
                      type="file"
                      accept=".bin,.eep,.dump"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <p className="text-xs text-muted-foreground">
                  Supports .bin, .eep, and .dump files (RFHUB EEPROM dumps)
                </p>
              </div>

              {/* Load from calibration library */}
              {rfhubFiles.length > 0 && (
                <div className="space-y-2">
                  <Label>Or Load from Calibration Library:</Label>
                  <select
                    value={selectedFile}
                    onChange={(e) => {
                      const filename = e.target.value;
                      setSelectedFile(filename);
                      if (filename) {
                        // Trigger file load
                        loadCalibrationFile(filename);
                        setUploadedFileName('');
                      } else {
                        setEepromData('');
                      }
                    }}
                    className="w-full p-2 border rounded-md"
                  >
                    <option value="">-- Select RFHUB file --</option>
                    {rfhubFiles.map((f: any) => (
                      <option key={f.filename} value={f.filename}>
                        {f.filename} ({(f.size / 1024).toFixed(1)} KB)
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-muted-foreground">
                    {rfhubFiles.length} RFHUB calibration files available
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="eeprom-data">EEPROM Hex Dump:</Label>
                <textarea
                  id="eeprom-data"
                  value={eepromData}
                  onChange={(e) => setEepromData(e.target.value)}
                  placeholder="Upload a file above, load from library, or paste hex dump manually..."
                  className="w-full h-32 p-3 font-mono text-sm border rounded-md resize-none"
                />
                <p className="text-xs text-muted-foreground">
                  {eepromData ? `Loaded ${eepromData.split(' ').length} bytes` : 'Supports formats: space-separated, continuous hex, or with line breaks'}
                </p>
              </div>

              <Button 
                onClick={extractPINFromEEPROM} 
                disabled={extracting || !eepromData.trim()}
                className="w-full"
              >
                {extracting ? 'Searching...' : 'Search for PIN Pattern'}
              </Button>

              {method2PIN && (
                <div className="space-y-2">
                  <Label>Extracted PIN:</Label>
                  <div className="flex gap-2">
                    <Input 
                      value={method2PIN} 
                      readOnly 
                      className={`font-mono text-2xl font-bold text-center ${
                        method2PIN === 'Pattern not found' ? 'text-destructive' : ''
                      }`}
                    />
                    {method2PIN !== 'Pattern not found' && (
                      <Button size="icon" variant="outline" onClick={() => copyToClipboard(method2PIN)}>
                        <Copy className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Method 3: Security Bytes Extraction */}
        <TabsContent value="method3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="w-5 h-5" />
                Method 3: Security Bytes Extraction
              </CardTitle>
              <CardDescription>
                Extract all security data from known EEPROM offsets (pairing bytes, secret keys, challenge/response)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="eeprom-data-3">EEPROM Hex Dump:</Label>
                <textarea
                  id="eeprom-data-3"
                  value={eepromData}
                  onChange={(e) => setEepromData(e.target.value)}
                  placeholder="Paste complete EEPROM hex dump here..."
                  className="w-full h-32 p-3 font-mono text-sm border rounded-md resize-none"
                />
              </div>

              <Button 
                onClick={extractSecurityBytes} 
                disabled={extracting || !eepromData.trim()}
                className="w-full"
              >
                {extracting ? 'Extracting...' : 'Extract Security Bytes'}
              </Button>

              {method3PIN && (
                <div className="space-y-2">
                  <Label>Extracted PIN (from pairing bytes):</Label>
                  <div className="flex gap-2">
                    <Input 
                      value={method3PIN} 
                      readOnly 
                      className="font-mono text-2xl font-bold text-center"
                    />
                    <Button size="icon" variant="outline" onClick={() => copyToClipboard(method3PIN)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}

              {Object.keys(securityBytes).length > 0 && (
                <div className="space-y-3">
                  <Label>Security Data:</Label>
                  <div className="space-y-2">
                    {Object.entries(securityBytes).map(([name, value]) => (
                      <div key={name} className="flex gap-2">
                        <Label className="w-48 text-xs flex items-center">{name}:</Label>
                        <Input value={value} readOnly className="font-mono text-xs flex-1" />
                        <Button size="icon" variant="outline" onClick={() => copyToClipboard(value)}>
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Export Results */}
      {(method1PIN || method2PIN || method3PIN) && (
        <Card>
          <CardHeader>
            <CardTitle>Export Results</CardTitle>
            <CardDescription>Save all extracted data to JSON file</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={exportResults} className="w-full">
              <Download className="w-4 h-4 mr-2" />
              Export to JSON
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
