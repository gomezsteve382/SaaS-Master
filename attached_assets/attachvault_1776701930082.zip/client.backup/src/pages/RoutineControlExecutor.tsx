import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Search, Play, AlertTriangle, CheckCircle2, Info, Copy, Zap } from "lucide-react";

export default function RoutineControlExecutor() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedRoutine, setSelectedRoutine] = useState<any>(null);
  const [executionLog, setExecutionLog] = useState<string[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);

  const { data: routines, isLoading } = trpc.alphaOBD.getRoutineControlLibrary.useQuery({
    category: activeCategory === "all" ? undefined : activeCategory,
    search: searchQuery || undefined,
  });

  const categories = [
    { id: "all", name: "All Routines", count: routines?.length || 0 },
    { id: "Calibration", name: "Calibration", icon: "🎯" },
    { id: "Activation", name: "Activation", icon: "⚡" },
    { id: "Learning", name: "Learning", icon: "🧠" },
    { id: "Reset", name: "Reset", icon: "🔄" },
    { id: "Diagnostic", name: "Diagnostic", icon: "🔍" },
    { id: "Other", name: "Other", icon: "📋" },
  ];

  const getSafetyBadge = (level: string) => {
    switch (level) {
      case "high":
        return <Badge variant="destructive" className="gap-1"><AlertTriangle className="h-3 w-3" />High Risk</Badge>;
      case "medium":
        return <Badge variant="outline" className="gap-1 border-yellow-500 text-yellow-600"><AlertTriangle className="h-3 w-3" />Medium Risk</Badge>;
      case "low":
        return <Badge variant="outline" className="gap-1 border-green-500 text-green-600"><CheckCircle2 className="h-3 w-3" />Low Risk</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const generateUDSCommand = (routine: any) => {
    if (routine.source === 'SRT Lab') {
      // SRT Lab uses 0x2F (InputOutputControlByIdentifier)
      const request = routine.request || '';
      if (request.length >= 4) {
        const did = request.substring(0, 4);
        const data = request.substring(4);
        return `2F ${did.match(/.{1,2}/g)?.join(' ')} ${data.match(/.{1,2}/g)?.join(' ') || ''}`.trim();
      }
      return request.match(/.{1,2}/g)?.join(' ') || 'N/A';
    } else {
      // SRT Lab Toolkit uses 0x31 (RoutineControl)
      const routineId = routine.routine_id || '0000';
      const controlType = routine.control_type || '01';
      return `31 ${controlType} ${routineId.replace('0x', '')}`;
    }
  };

  const simulateExecution = async (routine: any) => {
    setIsExecuting(true);
    setExecutionLog([]);

    const log = (message: string) => {
      setExecutionLog(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
    };

    try {
      log("🔧 Initializing routine execution...");
      await new Promise(resolve => setTimeout(resolve, 500));

      log("🔐 Entering extended diagnostic session (10 03)...");
      await new Promise(resolve => setTimeout(resolve, 300));

      if (routine.safety_level === 'high' || routine.safety_level === 'medium') {
        log("🔑 Requesting security access (27 01)...");
        await new Promise(resolve => setTimeout(resolve, 400));
        log("✅ Security unlocked (27 02)");
        await new Promise(resolve => setTimeout(resolve, 300));
      }

      if (routine.requirements) {
        log(`⚠️  Checking preconditions: ${routine.requirements}`);
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      const udsCommand = generateUDSCommand(routine);
      log(`📤 Sending UDS command: ${udsCommand}`);
      await new Promise(resolve => setTimeout(resolve, 800));

      log("📥 Waiting for ECU response...");
      await new Promise(resolve => setTimeout(resolve, 600));

      log("✅ Routine executed successfully!");
      log("🔄 Returning to default session (10 01)");
      await new Promise(resolve => setTimeout(resolve, 300));

      log("✨ Execution complete!");
      toast.success("Routine executed successfully (simulated)");
    } catch (error) {
      log(`❌ Error: ${error}`);
      toast.error("Routine execution failed");
    } finally {
      setIsExecuting(false);
    }
  };

  const copyCommand = () => {
    if (!selectedRoutine) return;
    const command = generateUDSCommand(selectedRoutine);
    navigator.clipboard.writeText(command);
    toast.success("UDS command copied to clipboard");
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Routine Control Executor</h1>
        <p className="text-muted-foreground">
          Execute 232 special diagnostic routines (SRT Lab + SRT Lab Toolkit)
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Routine Library */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Routine Library</CardTitle>
            <CardDescription>
              {routines?.length || 0} routines available
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search routines..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <Button
                  key={cat.id}
                  variant={activeCategory === cat.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveCategory(cat.id)}
                >
                  {cat.icon && <span className="mr-1">{cat.icon}</span>}
                  {cat.name}
                </Button>
              ))}
            </div>

            {/* Routine List */}
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {isLoading && <p className="text-sm text-muted-foreground">Loading routines...</p>}

              {routines && routines.length === 0 && (
                <p className="text-sm text-muted-foreground">No routines found.</p>
              )}

              {routines?.map((routine: any, idx: number) => (
                <Card
                  key={idx}
                  className={`cursor-pointer transition-colors hover:bg-accent ${
                    selectedRoutine?.id === routine.id ? 'border-primary bg-accent' : ''
                  }`}
                  onClick={() => setSelectedRoutine(routine)}
                >
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-medium text-sm leading-tight">
                          {routine.request_name || `Routine ${routine.id}`}
                        </p>
                        {routine.source === 'SRT Lab Toolkit' && (
                          <Badge variant="secondary" className="text-xs shrink-0">SRT Lab Toolkit</Badge>
                        )}
                      </div>
                      {routine.desc && (
                        <p className="text-xs text-muted-foreground line-clamp-2">{routine.desc}</p>
                      )}
                      <div className="flex items-center gap-2">
                        {getSafetyBadge(routine.safety_level)}
                        {routine.category && (
                          <Badge variant="outline" className="text-xs">{routine.category}</Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Routine Details & Execution */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>
              {selectedRoutine ? selectedRoutine.request_name || `Routine ${selectedRoutine.id}` : 'Select a Routine'}
            </CardTitle>
            <CardDescription>
              {selectedRoutine ? 'Review details and execute routine' : 'Choose a routine from the library'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!selectedRoutine && (
              <div className="flex items-center justify-center h-[600px] text-muted-foreground">
                <div className="text-center">
                  <Zap className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select a routine from the library to view details and execute</p>
                </div>
              </div>
            )}

            {selectedRoutine && (
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="details">
                    <Info className="h-4 w-4 mr-2" />
                    Details
                  </TabsTrigger>
                  <TabsTrigger value="execute">
                    <Play className="h-4 w-4 mr-2" />
                    Execute
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="space-y-4">
                  {/* Safety Warning */}
                  {selectedRoutine.safety_level === 'high' && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>High Risk Routine</AlertTitle>
                      <AlertDescription>
                        This routine can affect critical vehicle systems. Only execute if you understand the consequences.
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Routine Information */}
                  <div className="grid gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Description</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedRoutine.desc || 'No description available'}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium mb-2">Category</h4>
                        <Badge>{selectedRoutine.category || 'Other'}</Badge>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Safety Level</h4>
                        {getSafetyBadge(selectedRoutine.safety_level)}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Target Module</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedRoutine.module || selectedRoutine.device_id || 'N/A'}
                      </p>
                    </div>

                    {selectedRoutine.requirements && (
                      <div>
                        <h4 className="font-medium mb-2">Requirements</h4>
                        <Alert>
                          <Info className="h-4 w-4" />
                          <AlertDescription>{selectedRoutine.requirements}</AlertDescription>
                        </Alert>
                      </div>
                    )}

                    <div>
                      <h4 className="font-medium mb-2">UDS Command</h4>
                      <div className="flex gap-2">
                        <code className="flex-1 bg-muted p-3 rounded-lg font-mono text-sm">
                          {generateUDSCommand(selectedRoutine)}
                        </code>
                        <Button onClick={copyCommand} variant="outline" size="icon">
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {selectedRoutine.source && (
                      <div>
                        <h4 className="font-medium mb-2">Source</h4>
                        <Badge variant="secondary">
                          {selectedRoutine.source === 'SRT Lab Toolkit' ? 'SRT Lab Toolkit' : 'SRT Lab Database'}
                        </Badge>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="execute" className="space-y-4">
                  {/* Execution Panel */}
                  <div className="space-y-4">
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertTitle>Demo Mode</AlertTitle>
                      <AlertDescription>
                        This is a simulated execution. Connect real hardware to execute routines on actual ECUs.
                      </AlertDescription>
                    </Alert>

                    <Button
                      onClick={() => simulateExecution(selectedRoutine)}
                      disabled={isExecuting}
                      className="w-full"
                      size="lg"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      {isExecuting ? 'Executing...' : 'Execute Routine (Simulated)'}
                    </Button>

                    {/* Execution Log */}
                    {executionLog.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Execution Log</h4>
                        <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-xs max-h-[400px] overflow-y-auto">
                          {executionLog.map((line, idx) => (
                            <div key={idx}>{line}</div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
