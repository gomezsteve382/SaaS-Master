import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BackButton } from "@/components/BackButton";
import { Play, Square, Download, Filter, TrendingUp, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";

export default function RealTimeCANMonitor() {
  const { toast } = useToast();
  const [sessionId] = useState(() => nanoid());
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [frames, setFrames] = useState<any[]>([]);
  const [filterCanId, setFilterCanId] = useState("");
  const [filterProtocol, setFilterProtocol] = useState<"UDS" | "ISO-TP" | "RAW" | "ALL">("ALL");
  const [autoScroll, setAutoScroll] = useState(true);
  const tableEndRef = useRef<HTMLDivElement>(null);

  const startMutation = trpc.canMonitor.startMonitoring.useMutation();
  const stopMutation = trpc.canMonitor.stopMonitoring.useMutation();
  const framesQuery = trpc.canMonitor.getFrames.useQuery(
    { sessionId, page: 1, pageSize: 100 },
    { enabled: isMonitoring, refetchInterval: isMonitoring ? 1000 : false }
  );
  const statsQuery = trpc.canMonitor.getStatistics.useQuery(
    { sessionId },
    { enabled: isMonitoring, refetchInterval: isMonitoring ? 2000 : false }
  );
  const exportMutation = trpc.canMonitor.exportFrames.useMutation();
  const recentSessionsQuery = trpc.canMonitor.getRecentSessions.useQuery();

  useEffect(() => {
    if (framesQuery.data?.frames) {
      setFrames((prev) => {
        const newFrames = [...prev, ...framesQuery.data.frames];
        // Keep only last 500 frames for performance
        return newFrames.slice(-500);
      });
    }
  }, [framesQuery.data]);

  useEffect(() => {
    if (autoScroll && tableEndRef.current) {
      tableEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [frames, autoScroll]);

  const handleStart = async () => {
    try {
      await startMutation.mutateAsync({
        protocol: 'CAN',
        baudRate: 500000,
      });
      setIsMonitoring(true);
      setFrames([]);
      toast({
        title: "Monitoring started",
        description: "CAN bus monitoring is now active at 500kbps",
      });
    } catch (error: any) {
      toast({
        title: "Failed to start monitoring",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleStop = async () => {
    try {
      await stopMutation.mutateAsync({ sessionId });
      setIsMonitoring(false);
      toast({
        title: "Monitoring stopped",
        description: `Captured ${frames.length} CAN frames`,
      });
    } catch (error: any) {
      toast({
        title: "Failed to stop monitoring",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleExport = async (format: "CSV" | "DBC") => {
    try {
      const result = await exportMutation.mutateAsync({
        sessionId,
        format,
        filterCanId: filterCanId || undefined,
        filterProtocol: filterProtocol !== "ALL" ? filterProtocol : undefined,
      });

      // Create download
      const blob = new Blob([result.data], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export successful",
        description: `Exported ${frames.length} frames to ${format}`,
      });
    } catch (error: any) {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const filteredFrames = frames.filter((frame) => {
    if (filterCanId && !frame.canId.toLowerCase().includes(filterCanId.toLowerCase())) return false;
    if (filterProtocol !== "ALL" && frame.protocol !== filterProtocol) return false;
    return true;
  });

  const getProtocolBadge = (protocol: string) => {
    switch (protocol) {
      case "UDS":
        return <Badge className="bg-blue-600">UDS</Badge>;
      case "ISO-TP":
        return <Badge className="bg-green-600">ISO-TP</Badge>;
      case "RAW":
        return <Badge variant="outline">RAW</Badge>;
      default:
        return <Badge variant="secondary">{protocol}</Badge>;
    }
  };

  const getDirectionBadge = (direction: string) => {
    return direction === "TX" ? (
      <Badge variant="outline" className="border-red-600 text-red-600">TX</Badge>
    ) : (
      <Badge variant="outline" className="border-green-600 text-green-600">RX</Badge>
    );
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Real-Time CAN Bus Monitor</h1>
        <p className="text-muted-foreground">
          Live traffic visualization with protocol detection and export capabilities
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        {/* Statistics Cards */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Frames</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsQuery.data?.statistics.totalFrames || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Unique CAN IDs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsQuery.data?.statistics.uniqueCanIds || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Message Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold flex items-center gap-2">
              {statsQuery.data?.statistics.messageRate.toFixed(1) || "0.0"}
              <span className="text-sm font-normal text-muted-foreground">fps</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Duration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {statsQuery.data?.statistics.duration 
                ? `${(statsQuery.data.statistics.duration / 1000).toFixed(1)}s`
                : "0.0s"}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Monitor */}
        <div className="lg:col-span-2 space-y-6">
          {/* Controls */}
          <Card>
            <CardHeader>
              <CardTitle>Monitor Controls</CardTitle>
              <CardDescription>Start/stop CAN bus monitoring and configure filters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <Button
                  onClick={handleStart}
                  disabled={isMonitoring || startMutation.isPending}
                  className="flex-1"
                >
                  <Play className="h-4 w-4 mr-2" />
                  Start Monitoring
                </Button>
                <Button
                  onClick={handleStop}
                  disabled={!isMonitoring || stopMutation.isPending}
                  variant="destructive"
                  className="flex-1"
                >
                  <Square className="h-4 w-4 mr-2" />
                  Stop Monitoring
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Filter by CAN ID</Label>
                  <Input
                    placeholder="e.g., 0x7E0"
                    value={filterCanId}
                    onChange={(e) => setFilterCanId(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Filter by Protocol</Label>
                  <Select value={filterProtocol} onValueChange={(v: any) => setFilterProtocol(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ALL">All Protocols</SelectItem>
                      <SelectItem value="UDS">UDS Only</SelectItem>
                      <SelectItem value="ISO-TP">ISO-TP Only</SelectItem>
                      <SelectItem value="RAW">RAW Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport("CSV")}
                  disabled={frames.length === 0}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport("DBC")}
                  disabled={frames.length === 0}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export DBC
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAutoScroll(!autoScroll)}
                >
                  Auto-scroll: {autoScroll ? "ON" : "OFF"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* CAN Frames Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>CAN Frames</CardTitle>
                  <CardDescription>
                    Showing {filteredFrames.length} of {frames.length} frames
                  </CardDescription>
                </div>
                {isMonitoring && (
                  <Badge className="bg-green-600 animate-pulse">
                    <Activity className="h-3 w-3 mr-1" />
                    LIVE
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-[600px] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead className="w-[140px]">Timestamp</TableHead>
                        <TableHead className="w-[100px]">CAN ID</TableHead>
                        <TableHead className="w-[60px]">DLC</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead className="w-[100px]">Protocol</TableHead>
                        <TableHead className="w-[80px]">Dir</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredFrames.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                            {isMonitoring ? "Waiting for CAN frames..." : "Start monitoring to capture CAN frames"}
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredFrames.map((frame) => (
                          <TableRow key={frame.id}>
                            <TableCell className="font-mono text-xs">
                              {new Date(frame.timestamp).toLocaleTimeString("en-US", {
                                hour12: false,
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                                fractionalSecondDigits: 3,
                              })}
                            </TableCell>
                            <TableCell className="font-mono font-semibold">{frame.canId}</TableCell>
                            <TableCell className="font-mono">{frame.dlc}</TableCell>
                            <TableCell className="font-mono text-xs">{frame.data}</TableCell>
                            <TableCell>{getProtocolBadge(frame.protocol)}</TableCell>
                            <TableCell>{getDirectionBadge(frame.direction)}</TableCell>
                          </TableRow>
                        ))
                      )}
                      <div ref={tableEndRef} />
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar: Protocol Distribution & Top CAN IDs */}
        <div className="space-y-6">
          {/* Protocol Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Protocol Distribution</CardTitle>
              <CardDescription>Breakdown by protocol type</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {statsQuery.data?.statistics.protocols && (
                <>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-600">UDS</Badge>
                      <span className="text-sm text-muted-foreground">Unified Diagnostic Services</span>
                    </div>
                    <span className="font-semibold">{statsQuery.data.statistics.protocols.UDS}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-green-600">ISO-TP</Badge>
                      <span className="text-sm text-muted-foreground">Transport Protocol</span>
                    </div>
                    <span className="font-semibold">{statsQuery.data.statistics.protocols["ISO-TP"]}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">RAW</Badge>
                      <span className="text-sm text-muted-foreground">Raw CAN</span>
                    </div>
                    <span className="font-semibold">{statsQuery.data.statistics.protocols.RAW}</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Top CAN IDs */}
          <Card>
            <CardHeader>
              <CardTitle>Top CAN IDs</CardTitle>
              <CardDescription>Most active CAN identifiers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {statsQuery.data?.statistics.topCanIds.map((item: any, index: number) => (
                <div key={item.canId} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-mono font-semibold">{item.canId}</span>
                    <span className="text-muted-foreground">
                      {item.count} ({item.percentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-cyan-600"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
