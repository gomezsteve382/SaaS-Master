import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, CheckCircle2, XCircle, Usb, Bluetooth, Wifi, Cable, AlertTriangle } from 'lucide-react';
import { autoDetectDevice, AutoDetectResult, getPairedPorts, HardwareType } from '@/lib/obd2-protocol';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

/**
 * Hardware Auto-Detection Wizard
 * 
 * Automatically scans for available hardware:
 * - J2534 PassThru devices (Windows only)
 * - Arduino CAN bridges (WebSerial)
 * - ELM327 adapters (WebSerial)
 * 
 * Provides recommendations and auto-configuration
 */

interface DetectedDevice {
  type: HardwareType;
  name: string;
  port?: string;
  confidence: 'high' | 'medium' | 'low';
  recommended: boolean;
  details: string;
}

export default function HardwareDetectionWizard() {
  const [, setLocation] = useLocation();
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [devices, setDevices] = useState<DetectedDevice[]>([]);
  const [scanComplete, setScanComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startScan = async () => {
    setScanning(true);
    setProgress(0);
    setDevices([]);
    setScanComplete(false);
    setError(null);

    try {
      // Step 1: Check for J2534 devices (20%)
      setProgress(20);
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const j2534Available = await checkJ2534();
      if (j2534Available) {
        setDevices(prev => [...prev, {
          type: 'j2534',
          name: 'J2534 PassThru Device',
          confidence: 'high',
          recommended: true,
          details: 'Professional-grade PassThru device detected. Best for dealer-level diagnostics.'
        }]);
      }

      // Step 2: Scan WebSerial ports (40%)
      setProgress(40);
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const ports = await getPairedPorts();
      
      // Step 3: Auto-detect device types (60%)
      setProgress(60);
      
      // Try Arduino detection
      const arduinoResult = await autoDetectDevice('arduino');
      if (arduinoResult.status === 'found') {
        setDevices(prev => [...prev, {
          type: 'arduino',
          name: 'Arduino CAN Bridge',
          port: ports[0]?.displayName,
          confidence: 'high',
          recommended: true,
          details: 'Arduino CAN bridge detected. Supports dual-CAN monitoring and programming.'
        }]);
      }
      
      // Try ELM327 detection
      const elm327Result = await autoDetectDevice('elm327');
      if (elm327Result.status === 'found') {
        setDevices(prev => [...prev, {
          type: 'elm327',
          name: 'ELM327 Adapter',
          port: ports[0]?.displayName,
          confidence: 'medium',
          recommended: false,
          details: 'ELM327 adapter detected. Basic OBD2 functionality, limited CAN support.'
        }]);
      }

      // Step 4: Check for manual configuration option (80%)
      setProgress(80);
      await new Promise(resolve => setTimeout(resolve, 500));

      // Step 5: Complete (100%)
      setProgress(100);
      setScanComplete(true);
      
      if (devices.length === 0) {
        setError('No hardware detected. You can still use Demo Mode or configure manually.');
      } else {
        toast.success(`Found ${devices.length} device(s)`);
      }
    } catch (err) {
      setError(`Scan failed: ${err}`);
      toast.error('Hardware detection failed');
    } finally {
      setScanning(false);
    }
  };

  const checkJ2534 = async (): Promise<boolean> => {
    // Check if J2534 WebSocket server is running
    try {
      const response = await fetch('ws://localhost:8765', { method: 'HEAD' });
      return response.ok;
    } catch {
      return false;
    }
  };



  const getConfidenceBadge = (confidence: 'high' | 'medium' | 'low') => {
    const colors = {
      high: 'bg-green-500/20 text-green-400 border-green-500/30',
      medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      low: 'bg-gray-500/20 text-gray-400 border-gray-500/30'
    };
    return colors[confidence];
  };

  const getDeviceIcon = (type: HardwareType) => {
    switch (type) {
      case 'j2534': return <Usb className="w-5 h-5" />;
      case 'arduino': return <Cable className="w-5 h-5" />;
      case 'elm327': return <Bluetooth className="w-5 h-5" />;
      default: return <Wifi className="w-5 h-5" />;
    }
  };

  const handleSelectDevice = (device: DetectedDevice) => {
    // Navigate to Live VIN Programmer with pre-selected hardware
    setLocation(`/live-vin-programmer?hardware=${device.type}`);
  };

  useEffect(() => {
    // Auto-start scan on mount
    startScan();
  }, []);

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold mb-2">Hardware Detection Wizard</h1>
        <p className="text-muted-foreground">
          Automatically detect and configure diagnostic hardware
        </p>
      </div>

      {/* Scanning Progress */}
      {scanning && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Loader2 className="w-5 h-5 animate-spin" />
              Scanning for Hardware...
            </CardTitle>
            <CardDescription>
              Checking for J2534 devices, Arduino bridges, and ELM327 adapters
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={progress} className="w-full" />
            <p className="text-sm text-muted-foreground mt-2">{progress}% complete</p>
          </CardContent>
        </Card>
      )}

      {/* Error Alert */}
      {error && !scanning && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Detected Devices */}
      {scanComplete && devices.length > 0 && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
              Detected Devices ({devices.length})
            </CardTitle>
            <CardDescription>
              Select a device to begin diagnostics
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {devices.map((device, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-4 rounded-lg border border-border/50 bg-background/50 hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="p-2 rounded-lg bg-primary/10">
                    {getDeviceIcon(device.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold">{device.name}</p>
                      {device.recommended && (
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                          RECOMMENDED
                        </Badge>
                      )}
                      <Badge className={getConfidenceBadge(device.confidence)}>
                        {device.confidence.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{device.details}</p>
                    {device.port && (
                      <p className="text-xs text-muted-foreground mt-1 font-mono">
                        Port: {device.port}
                      </p>
                    )}
                  </div>
                </div>
                <Button onClick={() => handleSelectDevice(device)}>
                  Use This Device
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* No Devices Found */}
      {scanComplete && devices.length === 0 && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <XCircle className="w-5 h-5 text-yellow-400" />
              No Hardware Detected
            </CardTitle>
            <CardDescription>
              No diagnostic hardware was found. You can still use Demo Mode or configure manually.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertDescription>
                <p className="font-semibold mb-2">Troubleshooting Tips:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Ensure hardware is connected via USB</li>
                  <li>For J2534: Start the WebSocket bridge server (port 8765)</li>
                  <li>For Arduino/ELM327: Grant WebSerial permissions when prompted</li>
                  <li>Try refreshing the page and scanning again</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div className="flex gap-2">
              <Button onClick={startScan} variant="outline" className="flex-1">
                <Loader2 className="w-4 h-4 mr-2" />
                Scan Again
              </Button>
              <Button onClick={() => setLocation('/live-vin-programmer')} className="flex-1">
                Configure Manually
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Manual Configuration Option */}
      {scanComplete && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Manual Configuration</CardTitle>
            <CardDescription>
              Advanced users can configure hardware settings manually
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => setLocation('/live-vin-programmer')} 
              variant="outline"
              className="w-full"
            >
              Skip Auto-Detection
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
