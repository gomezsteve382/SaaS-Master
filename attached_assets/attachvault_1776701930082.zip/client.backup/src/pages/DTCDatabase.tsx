import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BackButton } from "@/components/BackButton";
import { Database, Search, AlertTriangle, CheckCircle2, AlertCircle, XCircle } from "lucide-react";
import dtcDatabase from "@/../../shared/dtc-database.json";

export default function DTCDatabase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState<"P" | "B" | "C" | "U" | "all">("all");
  const [selectedModule, setSelectedModule] = useState<string>("all");
  const [selectedCode, setSelectedCode] = useState<string | null>(null);

  const { data: codes, isLoading } = trpc.dtc.list.useQuery({
    codeType: selectedType === "all" ? undefined : selectedType,
    moduleCode: selectedModule === "all" ? undefined : selectedModule,
  });

  const importMutation = trpc.dtc.import.useMutation();

  const handleImportDatabase = async () => {
    try {
      const result = await importMutation.mutateAsync({
        codes: dtcDatabase.dtcCodes.map(code => ({
          code: code.code,
          codeType: code.codeType as "P" | "B" | "C" | "U",
          moduleCode: code.moduleCode,
          description: code.description,
          causes: JSON.stringify(code.causes),
          symptoms: JSON.stringify(code.symptoms),
          repairProcedures: JSON.stringify(code.repairProcedures),
          severity: code.severity as "low" | "medium" | "high" | "critical",
        })),
      });
      alert(`Successfully imported ${result} DTC codes!`);
    } catch (error) {
      alert("Failed to import DTC database");
    }
  };

  const filteredCodes = (codes || []).filter(code =>
    code.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    code.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedDtc = selectedCode ? filteredCodes.find(c => c.code === selectedCode) : null;

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical": return <XCircle className="h-5 w-5 text-red-600" />;
      case "high": return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case "medium": return <AlertCircle className="h-5 w-5 text-yellow-600" />;
      case "low": return <CheckCircle2 className="h-5 w-5 text-blue-600" />;
      default: return null;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-600";
      case "high": return "bg-orange-600";
      case "medium": return "bg-yellow-600";
      case "low": return "bg-blue-600";
      default: return "bg-gray-600";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-600 rounded-lg">
              <Database className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight">DTC CODE DATABASE</h1>
              <p className="text-gray-600">
                Comprehensive diagnostic trouble code reference for FCA/Stellantis vehicles
              </p>
            </div>
          </div>
          {(!codes || codes.length === 0) && (
            <Button onClick={handleImportDatabase} disabled={importMutation.isPending}>
              {importMutation.isPending ? "Importing..." : "Import Database"}
            </Button>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Left Panel - Search and Filters */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Search & Filter</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search code or description..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Code Type</label>
                  <div className="grid grid-cols-5 gap-2">
                    {["all", "P", "B", "C", "U"].map((type) => (
                      <Button
                        key={type}
                        variant={selectedType === type ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedType(type as any)}
                        className="text-xs"
                      >
                        {type === "all" ? "All" : type}
                      </Button>
                    ))}
                  </div>
                  <div className="text-xs text-gray-600 mt-2 space-y-1">
                    <p>• P = Powertrain</p>
                    <p>• B = Body</p>
                    <p>• C = Chassis</p>
                    <p>• U = Network</p>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Module</label>
                  <select
                    value={selectedModule}
                    onChange={(e) => setSelectedModule(e.target.value)}
                    className="w-full border rounded px-3 py-2 text-sm"
                  >
                    <option value="all">All Modules</option>
                    <option value="ECM">ECM - Engine Control</option>
                    <option value="BCM">BCM - Body Control</option>
                    <option value="TCM">TCM - Transmission</option>
                    <option value="ABS">ABS - Anti-lock Brakes</option>
                    <option value="RFHUB">RFHUB - Remote Function</option>
                  </select>
                </div>

                <div className="pt-4 border-t">
                  <div className="text-sm space-y-2">
                    <p><strong>Total Codes:</strong> {filteredCodes.length}</p>
                    {isLoading && <p className="text-gray-600">Loading...</p>}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Middle Panel - Code List */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>DTC Codes</CardTitle>
                <CardDescription>Click a code to view details</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {filteredCodes.map((code) => (
                    <div
                      key={code.id}
                      onClick={() => setSelectedCode(code.code)}
                      className={`p-3 rounded cursor-pointer transition-colors ${
                        selectedCode === code.code
                          ? "bg-red-100 border-2 border-red-600"
                          : "bg-gray-50 hover:bg-gray-100"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono font-bold text-lg">{code.code}</span>
                        <div className="flex items-center gap-2">
                          {getSeverityIcon(code.severity || "medium")}
                          <Badge variant="outline" className="text-xs">
                            {code.moduleCode || "N/A"}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-gray-700 line-clamp-2">{code.description}</p>
                    </div>
                  ))}
                  {filteredCodes.length === 0 && !isLoading && (
                    <p className="text-gray-600 text-center py-8">
                      No codes found. {(!codes || codes.length === 0) && "Import database to get started."}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Code Details */}
          <div>
            {selectedDtc ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="font-mono text-2xl">{selectedDtc.code}</CardTitle>
                    <Badge className={getSeverityColor(selectedDtc.severity || "medium")}>
                      {(selectedDtc.severity || "medium").toUpperCase()}
                    </Badge>
                  </div>
                  <CardDescription>{selectedDtc.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-sm mb-2">Module</h3>
                    <Badge variant="outline">{selectedDtc.moduleCode || "N/A"}</Badge>
                  </div>

                  {selectedDtc.causes && (
                    <div>
                      <h3 className="font-semibold text-sm mb-2">Possible Causes</h3>
                      <ul className="text-sm space-y-1 list-disc list-inside">
                        {JSON.parse(selectedDtc.causes).map((cause: string, i: number) => (
                          <li key={i} className="text-gray-700">{cause}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {selectedDtc.symptoms && (
                    <div>
                      <h3 className="font-semibold text-sm mb-2">Symptoms</h3>
                      <ul className="text-sm space-y-1 list-disc list-inside">
                        {JSON.parse(selectedDtc.symptoms).map((symptom: string, i: number) => (
                          <li key={i} className="text-gray-700">{symptom}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {selectedDtc.repairProcedures && (
                    <div>
                      <h3 className="font-semibold text-sm mb-2">Repair Procedures</h3>
                      <ol className="text-sm space-y-2 list-decimal list-inside">
                        {JSON.parse(selectedDtc.repairProcedures).map((step: string, i: number) => (
                          <li key={i} className="text-gray-700">{step}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-gray-600">
                  <Database className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p>Select a DTC code to view detailed information</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">About DTC Database</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-900 space-y-2">
            <p>• Comprehensive diagnostic trouble code reference for FCA/Stellantis vehicles</p>
            <p>• Includes descriptions, causes, symptoms, and repair procedures</p>
            <p>• Codes are categorized by type (P/B/C/U) and module</p>
            <p>• Severity levels help prioritize repairs (Low, Medium, High, Critical)</p>
            <p>• Database integrates with diagnostic reports and DTC Reader</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
