import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { BackButton } from "@/components/BackButton";
import { History, TrendingUp, GitCompare, Download, Search, Calendar } from "lucide-react";
import { toast } from "sonner";
import { Line, LineChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function ScanHistory() {
  const [selectedScanId, setSelectedScanId] = useState<number | null>(null);
  const [comparisonScanId, setComparisonScanId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterModule, setFilterModule] = useState<string>("all");

  const { data: scans, isLoading: scansLoading } = trpc.moduleScanHistory.getAllScans.useQuery();
  const { data: scanDetails } = trpc.moduleScanHistory.getScanById.useQuery(
    { scanId: selectedScanId! },
    { enabled: !!selectedScanId }
  );
  const { data: comparisonData } = trpc.moduleScanHistory.compareScans.useQuery(
    { scanId1: selectedScanId!, scanId2: comparisonScanId! },
    { enabled: !!selectedScanId && !!comparisonScanId }
  );
  const { data: trendData } = trpc.moduleScanHistory.getModuleVINHistory.useQuery(
    { canId: filterModule },
    { enabled: filterModule !== "all" }
  );

  const exportScan = async (scanId: number) => {
    try {
      const scan = scans?.find((s) => s.id === scanId);
      if (!scan) return;

      const csvContent = [
        ["Scan ID", "Date", "Primary VIN", "Module Count", "Mismatch Count"].join(","),
        [
          scan.id,
          new Date(scan.scannedAt).toLocaleString(),
          scan.primaryVIN || "N/A",
          scan.modulesFound,
          scan.mismatchCount,
        ].join(","),
        "",
        ["CAN ID", "Module Name", "VIN", "Mismatch", "Status"].join(","),
              ...(scanDetails?.modules || []).map((r) =>
          [r.canId, r.moduleName, r.vin || "N/A", r.vinMismatch ? "YES" : "NO", r.status].join(",")
        ),
      ].join("\n");

      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `scan_${scanId}_${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);

      toast.success("Scan exported successfully");
    } catch (error) {
      toast.error("Failed to export scan");
      console.error(error);
    }
  };

  const filteredScans = scans?.filter((scan) => {
    const matchesSearch =
      searchTerm === "" ||
      scan.primaryVIN?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scan.id.toString().includes(searchTerm);
    return matchesSearch;
  });

  // Extract unique module names for filter
  const uniqueModules = Array.from(
    new Set(
      scanDetails?.modules?.map((r) => r.moduleName) || []
    )
  );

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center gap-4">
        <BackButton />
        <div>
          <h1 className="text-3xl font-bold">Scan History</h1>
          <p className="text-muted-foreground">
            View past module scans, compare results, and track VIN changes over time
          </p>
        </div>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Search & Filter
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Search by VIN or Scan ID</label>
              <Input
                placeholder="Enter VIN or scan ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Filter by Module</label>
              <Select value={filterModule} onValueChange={setFilterModule}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Modules</SelectItem>
                  {uniqueModules.map((module) => (
                    <SelectItem key={module} value={module}>
                      {module}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scan List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Past Scans
          </CardTitle>
          <CardDescription>
            {filteredScans?.length || 0} scan{filteredScans?.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {scansLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading scans...</div>
          ) : filteredScans && filteredScans.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Scan ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Primary VIN</TableHead>
                  <TableHead>Modules Found</TableHead>
                  <TableHead>Mismatches</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredScans.map((scan) => (
                  <TableRow
                    key={scan.id}
                    className={selectedScanId === scan.id ? "bg-muted" : ""}
                  >
                    <TableCell className="font-mono">{scan.id}</TableCell>
                    <TableCell>{new Date(scan.scannedAt).toLocaleString()}</TableCell>
                    <TableCell className="font-mono">{scan.primaryVIN || "N/A"}</TableCell>
                    <TableCell>{scan.modulesFound}</TableCell>
                    <TableCell>
                      {scan.mismatchCount > 0 ? (
                        <Badge variant="destructive">{scan.mismatchCount}</Badge>
                      ) : (
                        <Badge variant="outline">0</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant={selectedScanId === scan.id ? "default" : "outline"}
                          onClick={() => setSelectedScanId(scan.id)}
                        >
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => exportScan(scan.id)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No scans found. Perform a module scan to see history here.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Scan Details */}
      {selectedScanId && scanDetails && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Scan Details - #{selectedScanId}
            </CardTitle>
            <CardDescription>
              Scanned on {new Date(scanDetails.scan.scannedAt).toLocaleString()}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>CAN ID</TableHead>
                  <TableHead>Module Name</TableHead>
                  <TableHead>VIN</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scanDetails.modules.map((result) => (
                  <TableRow
                    key={result.id}
                    className={result.vinMismatch ? "bg-red-50 dark:bg-red-950/20" : ""}
                  >
                    <TableCell className="font-mono">{result.canId}</TableCell>
                    <TableCell>
                      {result.moduleName}
                      {result.isPrimaryVIN && (
                        <Badge variant="outline" className="ml-2">
                          Primary VIN
                        </Badge>
                      )}
                      {result.vinMismatch && (
                        <Badge variant="destructive" className="ml-2">
                          VIN Mismatch
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="font-mono">{result.vin || "N/A"}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          result.status === "online"
                            ? "default"
                            : result.status === "error"
                            ? "destructive"
                            : "secondary"
                        }
                      >
                        {result.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Comparison */}
      {selectedScanId && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GitCompare className="h-5 w-5" />
              Compare Scans
            </CardTitle>
            <CardDescription>
              Compare scan #{selectedScanId} with another scan to see what changed
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Base Scan</label>
                <Input value={`Scan #${selectedScanId}`} disabled />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Compare With</label>
                <Select
                  value={comparisonScanId?.toString() || ""}
                  onValueChange={(value) => setComparisonScanId(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a scan..." />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredScans
                      ?.filter((s) => s.id !== selectedScanId)
                      .map((scan) => (
                        <SelectItem key={scan.id} value={scan.id.toString()}>
                          Scan #{scan.id} - {new Date(scan.scannedAt).toLocaleDateString()}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {comparisonData && (
              <div className="space-y-4">
                <Alert>
                  <AlertDescription>
                    <strong>{comparisonData.vinChanges.length}</strong> VIN change
                    {comparisonData.vinChanges.length !== 1 ? "s" : ""} detected,{" "}
                    <strong>{comparisonData.addedModules.length}</strong> module{comparisonData.addedModules.length !== 1 ? "s" : ""} added,{" "}
                    <strong>{comparisonData.removedModules.length}</strong> module{comparisonData.removedModules.length !== 1 ? "s" : ""} removed
                  </AlertDescription>
                </Alert>

                {(comparisonData.vinChanges.length > 0 || comparisonData.addedModules.length > 0 || comparisonData.removedModules.length > 0) && (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Module</TableHead>
                        <TableHead>Field</TableHead>
                        <TableHead>Old Value</TableHead>
                        <TableHead>New Value</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {comparisonData.vinChanges.map((change, idx) => (
                        <TableRow key={idx}>
                          <TableCell>{change.moduleName}</TableCell>
                          <TableCell className="capitalize">VIN</TableCell>
                          <TableCell className="font-mono">{change.oldVIN || "N/A"}</TableCell>
                          <TableCell className="font-mono">{change.newVIN || "N/A"}</TableCell>
                        </TableRow>
                      ))}
                      {comparisonData.addedModules.map((module, idx) => (
                        <TableRow key={`added-${idx}`} className="bg-green-50 dark:bg-green-950/20">
                          <TableCell>{module.moduleName}</TableCell>
                          <TableCell className="capitalize">Status</TableCell>
                          <TableCell className="font-mono">Not Present</TableCell>
                          <TableCell className="font-mono">Added</TableCell>
                        </TableRow>
                      ))}
                      {comparisonData.removedModules.map((module, idx) => (
                        <TableRow key={`removed-${idx}`} className="bg-red-50 dark:bg-red-950/20">
                          <TableCell>{module.moduleName}</TableCell>
                          <TableCell className="capitalize">Status</TableCell>
                          <TableCell className="font-mono">Present</TableCell>
                          <TableCell className="font-mono">Removed</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* VIN Trend Chart */}
      {filterModule !== "all" && trendData && trendData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              VIN Change Trend - {filterModule}
            </CardTitle>
            <CardDescription>
              Track VIN changes for {filterModule} over time
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="scannedAt"
                  tickFormatter={(value) => new Date(value).toLocaleDateString()}
                />
                <YAxis hide />
                <Tooltip
                  labelFormatter={(value) => new Date(value).toLocaleString()}
                  formatter={(value: string) => [value, "VIN"]}
                />
                <Legend />
                <Line
                  type="stepAfter"
                  dataKey="vin"
                  stroke="#ef4444"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  name="VIN"
                  connectNulls
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
