import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { Settings, Play, Plus, Trash2, Edit } from "lucide-react";

const BUILTIN_PRESETS = [
  {
    name: "BCM Replacement",
    description: "Complete procedure for replacing Body Control Module",
    presetType: "bcm_replacement",
    steps: [
      { action: "read_vin", module: "ECM", description: "Read VIN from donor ECM" },
      { action: "read_security", module: "ECM", description: "Extract SKIM key (4 bytes) from ECM" },
      { action: "read_security", module: "ECM", description: "Extract Secret key (16 bytes) from ECM" },
      { action: "patch_vin", module: "BCM", description: "Write VIN to new BCM (all 4 copies)" },
      { action: "write_security", module: "BCM", description: "Write SKIM key to BCM" },
      { action: "write_security", module: "BCM", description: "Write Secret key to BCM" },
      { action: "update_crc", module: "BCM", description: "Recalculate and update CRC-16 checksums" },
      { action: "verify", module: "BCM", description: "Verify VIN and security bytes match" },
    ],
  },
  {
    name: "ECM Swap",
    description: "Procedure for swapping Engine Control Module",
    presetType: "ecm_swap",
    steps: [
      { action: "read_vin", module: "BCM", description: "Read VIN from vehicle BCM" },
      { action: "backup", module: "ECM", description: "Backup original ECM to S3" },
      { action: "patch_vin", module: "ECM", description: "Write vehicle VIN to replacement ECM" },
      { action: "security_access", module: "ECM", description: "Perform security access (ROL5+XOR or XTEA)" },
      { action: "write_config", module: "ECM", description: "Write vehicle-specific configuration" },
      { action: "verify", module: "ECM", description: "Verify VIN matches vehicle" },
      { action: "clear_dtc", module: "ECM", description: "Clear diagnostic trouble codes" },
    ],
  },
  {
    name: "SKIM Pairing",
    description: "Pair new SKIM/SKREEM module with vehicle",
    presetType: "skim_pairing",
    steps: [
      { action: "read_vin", module: "BCM", description: "Read VIN from BCM" },
      { action: "read_security", module: "BCM", description: "Extract SKIM key from BCM" },
      { action: "patch_vin", module: "RFHUB", description: "Write VIN to RFHUB" },
      { action: "write_security", module: "RFHUB", description: "Write SKIM key to RFHUB" },
      { action: "update_crc", module: "RFHUB", description: "Update CRC checksums" },
      { action: "pairing", module: "RFHUB", description: "Perform SKIM pairing procedure" },
      { action: "test_keys", module: "RFHUB", description: "Test all programmed key fobs" },
    ],
  },
  {
    name: "TCM Replacement",
    description: "Replace Transmission Control Module",
    presetType: "tcm_replacement",
    steps: [
      { action: "read_vin", module: "ECM", description: "Read VIN from ECM" },
      { action: "backup", module: "TCM", description: "Backup original TCM configuration" },
      { action: "patch_vin", module: "TCM", description: "Write VIN to new TCM" },
      { action: "write_config", module: "TCM", description: "Write transmission type and gear ratios" },
      { action: "security_access", module: "TCM", description: "Perform TCM security access" },
      { action: "adaptive_reset", module: "TCM", description: "Reset adaptive learning values" },
      { action: "verify", module: "TCM", description: "Verify communication with ECM" },
    ],
  },
];

export default function ModulePresets() {
  const [selectedPreset, setSelectedPreset] = useState<typeof BUILTIN_PRESETS[0] | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionLog, setExecutionLog] = useState<string[]>([]);

  const handleExecutePreset = async () => {
    if (!selectedPreset) return;

    setIsExecuting(true);
    setExecutionLog([]);

    for (const step of selectedPreset.steps) {
      setExecutionLog(prev => [...prev, `[${step.module}] ${step.description}...`]);
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate execution
      setExecutionLog(prev => [...prev, `✓ ${step.action} completed`]);
    }

    setExecutionLog(prev => [...prev, "\n✓ Preset execution completed successfully!"]);
    setIsExecuting(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <Settings className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">MODULE CONFIGURATION PRESETS</h1>
            <p className="text-gray-600">
              Automated workflows for common module programming scenarios
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Left Panel - Preset Library */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Built-in Presets</CardTitle>
                  <Button size="sm" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Custom
                  </Button>
                </div>
                <CardDescription>Professional module programming workflows</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {BUILTIN_PRESETS.map((preset, idx) => (
                  <div
                    key={idx}
                    onClick={() => setSelectedPreset(preset)}
                    className={`p-4 rounded cursor-pointer transition-colors ${
                      selectedPreset?.name === preset.name
                        ? "bg-red-100 border-2 border-red-600"
                        : "bg-gray-50 hover:bg-gray-100"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-bold">{preset.name}</h3>
                      <Badge variant="outline">{preset.steps.length} steps</Badge>
                    </div>
                    <p className="text-sm text-gray-700">{preset.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {selectedPreset && (
              <Card>
                <CardHeader>
                  <CardTitle>Execution Log</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-black text-green-400 font-mono text-xs p-4 rounded h-64 overflow-y-auto">
                    {executionLog.length === 0 ? (
                      <p className="text-gray-500">Ready to execute preset...</p>
                    ) : (
                      executionLog.map((log, i) => (
                        <div key={i}>{log}</div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Panel - Preset Details */}
          <div>
            {selectedPreset ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{selectedPreset.name}</CardTitle>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardDescription>{selectedPreset.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-3">Workflow Steps</h3>
                    <div className="space-y-2">
                      {selectedPreset.steps.map((step, idx) => (
                        <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded">
                          <div className="flex-shrink-0 w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                            {idx + 1}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="text-xs">
                                {step.module}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {step.action}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-700">{step.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Button
                      onClick={handleExecutePreset}
                      disabled={isExecuting}
                      className="w-full bg-red-600 hover:bg-red-700"
                      size="lg"
                    >
                      <Play className="h-5 w-5 mr-2" />
                      {isExecuting ? "Executing..." : "Execute Preset"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-gray-600">
                  <Settings className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p>Select a preset to view details and execute</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">About Module Presets</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-900 space-y-2">
            <p>• Automated workflows for common module programming scenarios</p>
            <p>• Each preset contains a sequence of operations (VIN patching, security sync, etc.)</p>
            <p>• Built-in presets cover BCM replacement, ECM swap, SKIM pairing, and TCM replacement</p>
            <p>• Create custom presets for your specific workflow needs</p>
            <p>• Execution log shows real-time progress and results</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
