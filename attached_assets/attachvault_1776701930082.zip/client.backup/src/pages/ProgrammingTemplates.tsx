import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  FileText,
  Play,
  X,
  Zap,
  Shield,
  Wrench,
} from "lucide-react";
import { BackButton } from "@/components/BackButton";
import { PROGRAMMING_TEMPLATES, type ProgrammingTemplate, type ProgrammingStep } from "@/../../shared/programming-templates";
import { useToast } from "@/hooks/use-toast";

const DIFFICULTY_COLORS = {
  easy: "bg-green-500/20 text-green-500 border-green-500",
  medium: "bg-yellow-500/20 text-yellow-500 border-yellow-500",
  hard: "bg-red-500/20 text-red-500 border-red-500",
};

const CATEGORY_ICONS = {
  replacement: Wrench,
  swap: Zap,
  complete: Shield,
  pairing: FileText,
};

export default function ProgrammingTemplates() {
  const { toast } = useToast();
  const [selectedTemplate, setSelectedTemplate] = useState<ProgrammingTemplate | null>(null);
  const [showExecutionDialog, setShowExecutionDialog] = useState(false);
  const [executing, setExecuting] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [stepResults, setStepResults] = useState<Record<string, { success: boolean; message: string }>>({});

  const handleStartTemplate = (template: ProgrammingTemplate) => {
    setSelectedTemplate(template);
    setShowExecutionDialog(true);
    setCurrentStep(0);
    setCompletedSteps([]);
    setStepResults({});
  };

  const handleExecuteStep = async (step: ProgrammingStep) => {
    setExecuting(true);

    // Simulate step execution
    await new Promise((resolve) => setTimeout(resolve, step.estimatedTime * 100)); // Speed up for demo

    // Simulate success/failure (95% success rate)
    const success = Math.random() > 0.05;

    setStepResults((prev) => ({
      ...prev,
      [step.id]: {
        success,
        message: success ? "Step completed successfully" : "Step failed - check connection",
      },
    }));

    if (success) {
      setCompletedSteps((prev) => [...prev, step.id]);
      setCurrentStep((prev) => prev + 1);
    } else if (step.critical) {
      toast({
        title: "Critical Step Failed",
        description: "Workflow aborted due to critical step failure",
        variant: "destructive",
      });
      setExecuting(false);
      return;
    }

    setExecuting(false);
  };

  const handleExecuteAll = async () => {
    if (!selectedTemplate) return;

    for (let i = currentStep; i < selectedTemplate.steps.length; i++) {
      const step = selectedTemplate.steps[i];

      if (step.requiresConfirmation) {
        const confirmed = window.confirm(
          `${step.title}\n\n${step.description}\n\nHave you completed this manual step?`
        );
        if (!confirmed) {
          toast({ title: "Workflow Paused", description: "Manual step not confirmed" });
          return;
        }
      }

      await handleExecuteStep(step);

      // Check if step failed and was critical
      const result = stepResults[step.id];
      if (result && !result.success && step.critical) {
        return; // Abort
      }
    }

    toast({
      title: "Workflow Complete",
      description: `${selectedTemplate.name} completed successfully`,
    });
  };

  const progress = selectedTemplate
    ? (completedSteps.length / selectedTemplate.steps.length) * 100
    : 0;

  return (
    <div className="container py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <BackButton />
          <h1 className="text-3xl font-bold mt-2">Programming Templates</h1>
          <p className="text-muted-foreground mt-1">
            Pre-configured workflows for common module replacement and programming scenarios
          </p>
        </div>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          These templates are designed for experienced technicians. Always backup module data before
          programming and ensure stable power supply throughout the process.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {PROGRAMMING_TEMPLATES.map((template) => {
          const Icon = CATEGORY_ICONS[template.category];
          const difficultyColor = DIFFICULTY_COLORS[template.difficulty];

          return (
            <Card key={template.id} className="hover:border-cyan-500/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="h-5 w-5 text-cyan-500" />
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                  </div>
                  <Badge className={`${difficultyColor} border`} variant="outline">
                    {template.difficulty}
                  </Badge>
                </div>
                <CardDescription>{template.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{template.estimatedTime} min</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <FileText className="h-4 w-4" />
                    <span>{template.steps.length} steps</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium">Required Modules:</div>
                  <div className="flex flex-wrap gap-1">
                    {template.requiredModules.map((moduleId) => (
                      <Badge key={moduleId} variant="secondary" className="text-xs">
                        {moduleId}
                      </Badge>
                    ))}
                  </div>
                </div>

                {template.warnings.length > 0 && (
                  <div className="space-y-2">
                    <div className="text-sm font-medium text-yellow-500 flex items-center gap-1">
                      <AlertTriangle className="h-4 w-4" />
                      Warnings:
                    </div>
                    <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                      {template.warnings.slice(0, 2).map((warning, idx) => (
                        <li key={idx}>{warning}</li>
                      ))}
                      {template.warnings.length > 2 && (
                        <li className="text-cyan-500">+{template.warnings.length - 2} more...</li>
                      )}
                    </ul>
                  </div>
                )}

                <Button
                  onClick={() => handleStartTemplate(template)}
                  className="w-full"
                  variant="outline"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Start Workflow
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Execution Dialog */}
      <Dialog open={showExecutionDialog} onOpenChange={setShowExecutionDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedTemplate && (
                <>
                  {CATEGORY_ICONS[selectedTemplate.category] && (
                    <span className="text-cyan-500">
                      {(() => {
                        const Icon = CATEGORY_ICONS[selectedTemplate.category];
                        return <Icon className="h-5 w-5" />;
                      })()}
                    </span>
                  )}
                  {selectedTemplate.name}
                </>
              )}
            </DialogTitle>
            <DialogDescription>{selectedTemplate?.description}</DialogDescription>
          </DialogHeader>

          {selectedTemplate && (
            <div className="space-y-6">
              {/* Progress */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Progress</span>
                  <span className="text-muted-foreground">
                    {completedSteps.length} / {selectedTemplate.steps.length} steps
                  </span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              {/* Warnings */}
              {selectedTemplate.warnings.length > 0 && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <div className="font-semibold mb-1">Critical Warnings:</div>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {selectedTemplate.warnings.map((warning, idx) => (
                        <li key={idx}>{warning}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              {/* Prerequisites */}
              {selectedTemplate.prerequisites.length > 0 && (
                <div className="space-y-2">
                  <div className="font-semibold text-sm">Prerequisites:</div>
                  <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                    {selectedTemplate.prerequisites.map((prereq, idx) => (
                      <li key={idx}>{prereq}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Steps */}
              <div className="space-y-3">
                <div className="font-semibold text-sm">Workflow Steps:</div>
                {selectedTemplate.steps.map((step, idx) => {
                  const isCompleted = completedSteps.includes(step.id);
                  const isCurrent = idx === currentStep;
                  const result = stepResults[step.id];

                  return (
                    <Card
                      key={step.id}
                      className={`${
                        isCurrent
                          ? "border-cyan-500"
                          : isCompleted
                          ? "border-green-500/50"
                          : "border-slate-700"
                      }`}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="mt-0.5">
                            {isCompleted ? (
                              <CheckCircle2 className="h-5 w-5 text-green-500" />
                            ) : isCurrent ? (
                              <div className="h-5 w-5 rounded-full border-2 border-cyan-500 animate-pulse" />
                            ) : (
                              <div className="h-5 w-5 rounded-full border-2 border-slate-600" />
                            )}
                          </div>
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="font-medium">{step.title}</div>
                              <div className="flex items-center gap-2">
                                {step.critical && (
                                  <Badge variant="destructive" className="text-xs">
                                    CRITICAL
                                  </Badge>
                                )}
                                <span className="text-xs text-muted-foreground">
                                  ~{step.estimatedTime}s
                                </span>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground">{step.description}</p>
                            {step.udsCommand && (
                              <div className="text-xs font-mono bg-slate-900 p-2 rounded">
                                UDS: {step.udsCommand.map((b) => `0x${b.toString(16).toUpperCase().padStart(2, "0")}`).join(" ")}
                              </div>
                            )}
                            {result && (
                              <div
                                className={`text-sm ${
                                  result.success ? "text-green-500" : "text-red-500"
                                }`}
                              >
                                {result.message}
                              </div>
                            )}
                            {isCurrent && !isCompleted && (
                              <Button
                                size="sm"
                                onClick={() => handleExecuteStep(step)}
                                disabled={executing}
                              >
                                {executing ? "Executing..." : "Execute Step"}
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Post Steps */}
              {selectedTemplate.postSteps && selectedTemplate.postSteps.length > 0 && (
                <div className="space-y-2">
                  <div className="font-semibold text-sm">Post-Programming Steps:</div>
                  <ul className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                    {selectedTemplate.postSteps.map((postStep, idx) => (
                      <li key={idx}>{postStep}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowExecutionDialog(false)}>
              <X className="mr-2 h-4 w-4" />
              Close
            </Button>
            <Button
              onClick={handleExecuteAll}
              disabled={executing || progress === 100}
            >
              <Play className="mr-2 h-4 w-4" />
              {progress === 100 ? "Completed" : "Execute All"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
