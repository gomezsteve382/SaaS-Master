import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Copy, Download, Settings, Code2 } from "lucide-react";

export default function BCMConfigTool() {
  const [selectedFeatures, setSelectedFeatures] = useState<Record<string, boolean>>({});
  const [activeCategory, setActiveCategory] = useState<string>("all");

  const { data: bcmFeatures, isLoading, error } = trpc.alphaOBD.getBCMConfigFeatures.useQuery({
    category: activeCategory === "all" ? undefined : activeCategory,
  });

  // Debug logging
  useEffect(() => {
    console.log('[BCM Config Tool] Query state:', { isLoading, hasData: !!bcmFeatures, dataLength: bcmFeatures?.length, error });
    if (bcmFeatures) {
      console.log('[BCM Config Tool] First 3 features:', bcmFeatures.slice(0, 3));
    }
  }, [isLoading, bcmFeatures, error]);

  // Group features by category
  const groupedFeatures = bcmFeatures?.reduce((acc: any, feature: any) => {
    const category = feature.group_name || "Other";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(feature);
    return acc;
  }, {});

  const categories = groupedFeatures ? Object.keys(groupedFeatures).sort() : [];

  const toggleFeature = (featureId: string) => {
    setSelectedFeatures(prev => ({
      ...prev,
      [featureId]: !prev[featureId]
    }));
  };

  const generateUDSCommands = () => {
    const enabledFeatures = Object.entries(selectedFeatures)
      .filter(([_, enabled]) => enabled)
      .map(([id]) => {
        const feature = bcmFeatures?.find((f: any) => `${f.request}_${f.bit_pos}` === id);
        return feature;
      })
      .filter(Boolean);

    if (enabledFeatures.length === 0) {
      return "# No features selected\n# Toggle features on the left to generate UDS commands";
    }

    let script = `# BCM Configuration Script
# Generated: ${new Date().toLocaleString()}
# Features: ${enabledFeatures.length}

import time

def write_bcm_config(uds_client):
    """Write BCM configuration via UDS"""
    
    # Enter extended diagnostic session
    uds_client.send_request([0x10, 0x03])
    time.sleep(0.1)
    
    # Security access (seed/key)
    seed_response = uds_client.send_request([0x27, 0x01])
    if seed_response and len(seed_response) >= 3:
        seed = seed_response[2:]
        key = calculate_key(seed)  # Use FCA keygen
        uds_client.send_request([0x27, 0x02] + list(key))
        time.sleep(0.1)
    
`;

    enabledFeatures.forEach((feature: any, idx: number) => {
      const did = feature.request || "F1A0";
      const value = feature.table_value || "01";
      
      script += `    # Feature ${idx + 1}: ${feature.response_name || 'Unknown'}
    uds_client.send_request([0x2E, 0x${did.slice(0, 2)}, 0x${did.slice(2)}, 0x${value}])
    time.sleep(0.1)
    
`;
    });

    script += `    # Reset ECU to apply changes
    uds_client.send_request([0x11, 0x01])
    
    print("BCM configuration complete!")

# Example usage:
# write_bcm_config(your_uds_client)
`;

    return script;
  };

  const generateHexPreview = () => {
    const enabledFeatures = Object.entries(selectedFeatures)
      .filter(([_, enabled]) => enabled)
      .map(([id]) => {
        const feature = bcmFeatures?.find((f: any) => `${f.request}_${f.bit_pos}` === id);
        return feature;
      })
      .filter(Boolean);

    if (enabledFeatures.length === 0) {
      return "No features selected";
    }

    return enabledFeatures.map((feature: any, idx: number) => {
      const did = feature.request || "F1A0";
      const value = feature.table_value || "01";
      return `${idx + 1}. 2E ${did.slice(0, 2)} ${did.slice(2)} ${value}  // ${feature.response_name || 'Unknown'}`;
    }).join('\n');
  };

  const copyScript = () => {
    navigator.clipboard.writeText(generateUDSCommands());
    toast.success("Script copied to clipboard");
  };

  const downloadScript = () => {
    const script = generateUDSCommands();
    const blob = new Blob([script], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bcm_config_${Date.now()}.py`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Script downloaded");
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">BCM Configuration Tool</h1>
        <p className="text-muted-foreground">
          Configure 4,826 BCM parameters with visual toggles and UDS command generation
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Feature Selector */}
        <Card>
          <CardHeader>
            <CardTitle>BCM Features</CardTitle>
            <CardDescription>Toggle features to enable/disable</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant={activeCategory === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveCategory("all")}
              >
                All
              </Button>
              {categories.slice(0, 10).map((category: string) => (
                <Button
                  key={category}
                  variant={activeCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Feature List */}
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {isLoading && <p className="text-sm text-muted-foreground">Loading BCM features...</p>}
              
              {bcmFeatures && bcmFeatures.length === 0 && (
                <p className="text-sm text-muted-foreground">No features found in this category.</p>
              )}

              {bcmFeatures?.slice(0, 50).map((feature: any, idx: number) => {
                const featureId = `${feature.request}_${feature.bit_pos}`;
                return (
                  <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1 min-w-0 mr-4">
                      <Label htmlFor={featureId} className="font-medium cursor-pointer">
                        {feature.response_name || `Parameter ${idx + 1}`}
                      </Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        DID: {feature.request || 'N/A'} | Bit: {feature.bit_pos || 'N/A'}
                      </p>
                    </div>
                    <Switch
                      id={featureId}
                      checked={selectedFeatures[featureId] || false}
                      onCheckedChange={() => toggleFeature(featureId)}
                    />
                  </div>
                );
              })}
            </div>

            {bcmFeatures && bcmFeatures.length > 50 && (
              <p className="text-sm text-muted-foreground text-center">
                Showing first 50 features. Use category filter to see more.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Code Generator */}
        <Card>
          <CardHeader>
            <CardTitle>Generated Code</CardTitle>
            <CardDescription>
              {Object.values(selectedFeatures).filter(Boolean).length} features selected
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="script" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="script">
                  <Code2 className="h-4 w-4 mr-2" />
                  Python Script
                </TabsTrigger>
                <TabsTrigger value="hex">
                  <Settings className="h-4 w-4 mr-2" />
                  Hex Preview
                </TabsTrigger>
              </TabsList>

              <TabsContent value="script" className="space-y-4">
                <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto max-h-[600px] overflow-y-auto font-mono">
                  {generateUDSCommands()}
                </pre>
                <div className="flex gap-2">
                  <Button onClick={copyScript} variant="outline" className="flex-1">
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Script
                  </Button>
                  <Button onClick={downloadScript} variant="outline" className="flex-1">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="hex" className="space-y-4">
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="font-medium mb-2">UDS Commands (Hex)</h3>
                  <pre className="text-xs font-mono max-h-[600px] overflow-y-auto whitespace-pre-wrap">
                    {generateHexPreview()}
                  </pre>
                </div>
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    <strong>⚠️ Warning:</strong> Modifying BCM configuration can affect vehicle behavior. 
                    Always backup original configuration before making changes.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
