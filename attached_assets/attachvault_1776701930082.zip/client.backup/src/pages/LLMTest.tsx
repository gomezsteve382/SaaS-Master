import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, XCircle, AlertTriangle } from "lucide-react";

export default function LLMTest() {
  const { toast } = useToast();
  const [testMessage, setTestMessage] = useState("Say hello");

  const configQuery = trpc.llmTest.testConfig.useQuery();
  const testMutation = trpc.llmTest.testCall.useMutation();

  const handleTest = async () => {
    try {
      const result = await testMutation.mutateAsync({ message: testMessage });
      
      if (result.success) {
        toast({
          title: "LLM Test Successful!",
          description: "The AI responded correctly",
        });
      } else {
        toast({
          title: "LLM Test Failed",
          description: result.error,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "LLM Test Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-8 max-w-4xl">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">LLM Configuration Test</h1>
        <p className="text-muted-foreground">
          Debug the AI LLM integration and verify configuration
        </p>
      </div>

      {/* Configuration Status */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Configuration Status</CardTitle>
          <CardDescription>Current LLM API configuration</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {configQuery.isLoading ? (
            <p className="text-muted-foreground">Loading configuration...</p>
          ) : configQuery.data ? (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">API URL</Label>
                  <p className="font-mono text-sm break-all">{configQuery.data.config.url}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">API Key Status</Label>
                  <div className="flex items-center gap-2 mt-1">
                    {configQuery.data.config.hasApiKey ? (
                      <>
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        <Badge className="bg-green-600">Configured</Badge>
                      </>
                    ) : (
                      <>
                        <XCircle className="h-4 w-4 text-red-600" />
                        <Badge variant="destructive">Missing</Badge>
                      </>
                    )}
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">API Key Length</Label>
                  <p className="font-mono text-sm">{configQuery.data.config.apiKeyLength} characters</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">API Key Preview</Label>
                  <p className="font-mono text-sm">{configQuery.data.config.apiKeyPrefix}</p>
                </div>
              </div>

              {!configQuery.data.config.hasApiKey && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-red-900">API Key Missing</p>
                    <p className="text-sm text-red-700">
                      The BUILT_IN_FORGE_API_KEY environment variable is not set. 
                      This is required for LLM functionality.
                    </p>
                  </div>
                </div>
              )}
            </>
          ) : (
            <p className="text-red-600">Failed to load configuration</p>
          )}
        </CardContent>
      </Card>

      {/* Test LLM Call */}
      <Card>
        <CardHeader>
          <CardTitle>Test LLM Call</CardTitle>
          <CardDescription>Send a test message to the LLM API</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Test Message</Label>
            <Input
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              placeholder="Enter a test message"
            />
          </div>

          <Button
            onClick={handleTest}
            disabled={testMutation.isPending || !configQuery.data?.config.hasApiKey}
          >
            {testMutation.isPending ? "Testing..." : "Test LLM"}
          </Button>

          {testMutation.data && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                {testMutation.data.success ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    <span className="font-semibold text-green-900">Success</span>
                  </>
                ) : (
                  <>
                    <XCircle className="h-5 w-5 text-red-600" />
                    <span className="font-semibold text-red-900">Failed</span>
                  </>
                )}
              </div>

              {testMutation.data.success ? (
                <div>
                  <Label className="text-muted-foreground">Response</Label>
                  <p className="mt-1">{typeof testMutation.data.response === 'string' ? testMutation.data.response : JSON.stringify(testMutation.data.response)}</p>
                  
                  <details className="mt-4">
                    <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground">
                      View Full Response
                    </summary>
                    <pre className="mt-2 p-2 bg-background rounded text-xs overflow-x-auto">
                      {JSON.stringify(testMutation.data.fullResponse, null, 2)}
                    </pre>
                  </details>
                </div>
              ) : (
                <div>
                  <Label className="text-muted-foreground">Error Message</Label>
                  <p className="mt-1 text-red-600">{testMutation.data.error}</p>
                  
                  {testMutation.data.stack && (
                    <details className="mt-4">
                      <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground">
                        View Stack Trace
                      </summary>
                      <pre className="mt-2 p-2 bg-background rounded text-xs overflow-x-auto">
                        {testMutation.data.stack}
                      </pre>
                    </details>
                  )}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
