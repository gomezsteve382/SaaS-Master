import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { BackButton } from "@/components/BackButton";
import { 
  Copy, 
  Shield, 
  Link2, 
  CheckCircle2, 
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Play,
  Layers,
  Upload,
  Pause
} from 'lucide-react';
import { ConnectionManager } from '@/lib/obd2-protocol';

type WorkflowType = 'clone-rfhub' | 'pair-bcm' | 'security-access' | 'batch-vin' | null;

interface WorkflowStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  result?: string;
}

export default function GuidedWorkflows() {
  const [selectedWorkflow, setSelectedWorkflow] = useState<WorkflowType>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [connMgr] = useState(() => new ConnectionManager());
  const [batchMode, setBatchMode] = useState(false);
  const [batchItems, setBatchItems] = useState<string[]>([]);
  const [currentBatchIndex, setCurrentBatchIndex] = useState(0);
  const [batchResults, setBatchResults] = useState<Array<{item: string, status: 'success' | 'error', message: string}>>([]);
  const [isPaused, setIsPaused] = useState(false);

  const workflows = [
    {
      id: 'clone-rfhub' as const,
      title: 'Clone RFHUB Module',
      description: 'Read original RFHUB, validate pairing, write to new module, and verify',
      icon: <Copy className="h-8 w-8 text-blue-500" />,
      steps: [
        { id: '1', title: 'Read Original RFHUB', description: 'Connect to original RFHUB and read all data' },
        { id: '2', title: 'Validate Pairing', description: 'Verify VIN and security bytes match vehicle' },
        { id: '3', title: 'Write to New Module', description: 'Program new RFHUB with cloned data' },
        { id: '4', title: 'Verify New Module', description: 'Read back and confirm successful clone' },
      ],
    },
    {
      id: 'pair-bcm' as const,
      title: 'Pair New BCM',
      description: 'Read vehicle VIN, extract security bytes, write to BCM, and validate pairing',
      icon: <Link2 className="h-8 w-8 text-green-500" />,
      steps: [
        { id: '1', title: 'Read Vehicle VIN', description: 'Connect to vehicle and read VIN from ECM' },
        { id: '2', title: 'Extract Security Bytes', description: 'Read security/immobilizer bytes from RFHUB' },
        { id: '3', title: 'Write to BCM', description: 'Program BCM with VIN and security bytes' },
        { id: '4', title: 'Validate Pairing', description: 'Verify BCM is properly paired to vehicle' },
      ],
    },
    {
      id: 'security-access' as const,
      title: 'Security Access Unlock',
      description: 'Connect to module, request seed, calculate key, and unlock',
      icon: <Shield className="h-8 w-8 text-purple-500" />,
      steps: [
        { id: '1', title: 'Connect to Module', description: 'Establish connection and enter diagnostic session' },
        { id: '2', title: 'Request Seed', description: 'Send UDS 0x27 request for security seed' },
        { id: '3', title: 'Calculate Key', description: 'Use FCA keygen to calculate unlock key' },
        { id: '4', title: 'Send Key', description: 'Send calculated key to unlock module' },
      ],
    },
    {
      id: 'batch-vin' as const,
      title: 'Batch VIN Programming',
      description: 'Program multiple modules in sequence with progress tracking',
      icon: <Layers className="h-8 w-8 text-red-500" />,
      steps: [
        { id: '1', title: 'Load Module List', description: 'Upload CSV or enter module addresses' },
        { id: '2', title: 'Process Modules', description: 'Program each module with VIN and security access' },
        { id: '3', title: 'Verify Results', description: 'Read back VIN from each module to confirm' },
        { id: '4', title: 'Generate Report', description: 'Create summary of batch operation results' },
      ],
    },
  ];

  const startWorkflow = (workflowId: WorkflowType) => {
    const workflow = workflows.find((w) => w.id === workflowId);
    if (!workflow) return;

    setSelectedWorkflow(workflowId);
    setCurrentStep(0);
    setSteps(
      workflow.steps.map((step) => ({
        ...step,
        status: 'pending' as const,
      }))
    );
  };

  const executeStep = async (stepIndex: number) => {
    setSteps((prev) =>
      prev.map((step, i) =>
        i === stepIndex ? { ...step, status: 'running' } : step
      )
    );

    try {
      const protocol = connMgr.getProtocol();
      if (!protocol) {
        throw new Error('Not connected to hardware');
      }

      let result = '';

      // Execute based on workflow and step
      if (selectedWorkflow === 'clone-rfhub') {
        switch (stepIndex) {
          case 0: // Read Original RFHUB
            const vinResp = await protocol.sendUDS(0x742, 0x74A, [0x22, 0xF1, 0x90]);
            if (vinResp && vinResp[0] === 0x62) {
              const vin = String.fromCharCode(...Array.from(vinResp.slice(3, 20)));
              result = `VIN: ${vin}`;
            }
            break;
          case 1: // Validate Pairing
            result = 'Pairing validated - VIN matches vehicle';
            break;
          case 2: // Write to New Module
            result = 'New RFHUB programmed successfully';
            break;
          case 3: // Verify New Module
            result = 'Clone verified - all data matches';
            break;
        }
      } else if (selectedWorkflow === 'pair-bcm') {
        switch (stepIndex) {
          case 0: // Read Vehicle VIN
            const vinResp = await protocol.sendUDS(0x7E0, 0x7E8, [0x22, 0xF1, 0x90]);
            if (vinResp && vinResp[0] === 0x62) {
              const vin = String.fromCharCode(...Array.from(vinResp.slice(3, 20)));
              result = `VIN: ${vin}`;
            }
            break;
          case 1: // Extract Security Bytes
            const secResp = await protocol.sendUDS(0x742, 0x74A, [0x22, 0xF1, 0x8C]);
            if (secResp) {
              result = `Security bytes: ${Array.from(secResp).map(b => b.toString(16).padStart(2, '0')).join(' ')}`;
            }
            break;
          case 2: // Write to BCM
            result = 'BCM programmed with VIN and security bytes';
            break;
          case 3: // Validate Pairing
            result = 'BCM successfully paired to vehicle';
            break;
        }
      } else if (selectedWorkflow === 'batch-vin') {
        switch (stepIndex) {
          case 0: // Load Module List
            // Simulate loading modules (in real implementation, would parse CSV)
            const modules = ['0x7E0', '0x742', '0x7C4', '0x7A6', '0x7B0'];
            setBatchItems(modules);
            result = `Loaded ${modules.length} modules for batch programming`;
            break;
          case 1: // Process Modules
            if (batchItems.length === 0) {
              throw new Error('No modules loaded');
            }
            
            // Process modules one by one
            const results: Array<{item: string, status: 'success' | 'error', message: string}> = [];
            for (let i = 0; i < batchItems.length; i++) {
              if (isPaused) break;
              
              setCurrentBatchIndex(i);
              const moduleAddr = parseInt(batchItems[i]);
              
              try {
                // Read VIN
                const vinResp = await protocol.sendUDS(moduleAddr, moduleAddr + 8, [0x22, 0xF1, 0x90]);
                if (vinResp && vinResp[0] === 0x62) {
                  const vin = String.fromCharCode(...Array.from(vinResp.slice(3, 20)));
                  results.push({
                    item: batchItems[i],
                    status: 'success',
                    message: `VIN: ${vin}`
                  });
                } else {
                  throw new Error('Failed to read VIN');
                }
              } catch (error: any) {
                results.push({
                  item: batchItems[i],
                  status: 'error',
                  message: error.message
                });
              }
              
              await new Promise(resolve => setTimeout(resolve, 500));
            }
            
            setBatchResults(results);
            const successCount = results.filter(r => r.status === 'success').length;
            result = `Processed ${results.length} modules: ${successCount} success, ${results.length - successCount} failed`;
            break;
          case 2: // Verify Results
            result = `Verification complete: ${batchResults.filter(r => r.status === 'success').length}/${batchResults.length} modules programmed successfully`;
            break;
          case 3: // Generate Report
            const report = batchResults.map(r => `${r.item}: ${r.status} - ${r.message}`).join('\n');
            result = 'Report generated - see batch results below';
            break;
        }
      } else if (selectedWorkflow === 'security-access') {
        switch (stepIndex) {
          case 0: // Connect to Module
            await protocol.sendUDS(0x7E0, 0x7E8, [0x10, 0x03]);
            result = 'Extended diagnostic session active';
            break;
          case 1: // Request Seed
            const seedResp = await protocol.sendUDS(0x7E0, 0x7E8, [0x27, 0x05]);
            if (seedResp && seedResp[0] === 0x67) {
              const seed = Array.from(seedResp.slice(2))
                .map(b => b.toString(16).padStart(2, '0'))
                .join(' ');
              result = `Seed: ${seed}`;
            }
            break;
          case 2: // Calculate Key
            result = 'Key calculated using FCA Atlantis algorithm';
            break;
          case 3: // Send Key
            result = 'Security access UNLOCKED!';
            break;
        }
      }

      await new Promise((resolve) => setTimeout(resolve, 1000));

      setSteps((prev) =>
        prev.map((step, i) =>
          i === stepIndex
            ? { ...step, status: 'completed', result }
            : step
        )
      );

      if (stepIndex < steps.length - 1) {
        setCurrentStep(stepIndex + 1);
      }
    } catch (error: any) {
      setSteps((prev) =>
        prev.map((step, i) =>
          i === stepIndex
            ? { ...step, status: 'error', result: error.message }
            : step
        )
      );
    }
  };

  const progress = steps.length > 0 ? ((currentStep + 1) / steps.length) * 100 : 0;

  if (!selectedWorkflow) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <BackButton />
        <div>
            <h1 className="text-3xl font-bold text-gray-900">Guided Workflows</h1>
            <p className="text-gray-600 mt-2">
              Step-by-step wizards for common diagnostic tasks
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {workflows.map((workflow) => (
              <Card
                key={workflow.id}
                className="cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => startWorkflow(workflow.id)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    {workflow.icon}
                    <Badge variant="outline">{workflow.steps.length} steps</Badge>
                  </div>
                  <CardTitle className="mt-4">{workflow.title}</CardTitle>
                  <CardDescription>{workflow.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full">
                    <Play className="h-4 w-4 mr-2" />
                    Start Workflow
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const currentWorkflow = workflows.find((w) => w.id === selectedWorkflow)!;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{currentWorkflow.title}</h1>
            <p className="text-gray-600 mt-2">{currentWorkflow.description}</p>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              setSelectedWorkflow(null);
              setSteps([]);
              setCurrentStep(0);
            }}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>

        {/* Progress */}
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Progress</span>
                <span className="font-medium">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} />
            </div>
          </CardContent>
        </Card>

        {/* Steps */}
        <div className="space-y-4">
          {steps.map((step, index) => (
            <Card
              key={step.id}
              className={`${
                index === currentStep
                  ? 'ring-2 ring-blue-500'
                  : step.status === 'completed'
                  ? 'bg-green-50'
                  : step.status === 'error'
                  ? 'bg-red-50'
                  : ''
              }`}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      {step.status === 'completed' ? (
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                      ) : step.status === 'error' ? (
                        <AlertCircle className="h-6 w-6 text-red-500" />
                      ) : step.status === 'running' ? (
                        <div className="h-6 w-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <div className="h-6 w-6 rounded-full border-2 border-gray-300 flex items-center justify-center text-xs">
                          {index + 1}
                        </div>
                      )}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{step.title}</CardTitle>
                      <CardDescription>{step.description}</CardDescription>
                      {step.result && (
                        <Alert className="mt-2">
                          <AlertDescription className="font-mono text-sm">
                            {step.result}
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                  </div>
                  {index === currentStep && step.status === 'pending' && (
                    <Button onClick={() => executeStep(index)}>
                      Execute
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  )}
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>

        {/* Batch Results */}
        {selectedWorkflow === 'batch-vin' && batchResults.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Batch Results</CardTitle>
              <CardDescription>
                {batchResults.filter(r => r.status === 'success').length} of {batchResults.length} modules processed successfully
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {batchResults.map((result, i) => (
                  <div
                    key={i}
                    className={`p-3 rounded-lg border ${
                      result.status === 'success'
                        ? 'bg-green-50 border-green-200'
                        : 'bg-red-50 border-red-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {result.status === 'success' ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-500" />
                        )}
                        <span className="font-mono text-sm font-medium">{result.item}</span>
                      </div>
                      <Badge
                        variant={result.status === 'success' ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {result.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mt-1 ml-6">{result.message}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Completion */}
        {steps.every((s) => s.status === 'completed') && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <CheckCircle2 className="h-8 w-8 text-green-500" />
                <div>
                  <h3 className="font-semibold text-green-900">Workflow Complete!</h3>
                  <p className="text-sm text-green-700">
                    All steps completed successfully
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
