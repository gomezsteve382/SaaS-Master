import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BackButton } from "@/components/BackButton";
import { Upload, Download, FileText, AlertCircle, CheckCircle2, Database } from 'lucide-react';

interface SAVData {
  filename: string;
  fileSize: number;
  vin?: string;
  modules: ModuleConfig[];
  dtcCodes: DTCCode[];
  securityBytes?: string;
  timestamp?: Date;
}

interface ModuleConfig {
  name: string;
  address: string;
  partNumber?: string;
  softwareVersion?: string;
  hardwareVersion?: string;
}

interface DTCCode {
  code: string;
  module: string;
  status: string;
  description?: string;
}

export default function SAVParser() {
  const [savData, setSavData] = useState<SAVData | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError('');
    setSavData(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const data = parseSAVFile(arrayBuffer, file.name, file.size);
      setSavData(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to parse .sav file');
    } finally {
      setIsLoading(false);
    }
  };

  const parseSAVFile = (buffer: ArrayBuffer, filename: string, fileSize: number): SAVData => {
    const bytes = new Uint8Array(buffer);
    
    // third-party diagnostic software .sav files are binary configuration snapshots
    // This is a simplified parser - real implementation would need full format spec
    
    // Look for VIN pattern (17 ASCII characters)
    let vin: string | undefined;
    for (let i = 0; i < bytes.length - 17; i++) {
      const slice = bytes.slice(i, i + 17);
      const potential = String.fromCharCode.apply(null, Array.from(slice));
      if (/^[A-HJ-NPR-Z0-9]{17}$/.test(potential)) {
        vin = potential;
        break;
      }
    }

    // Look for module identifiers (simplified)
    const modules: ModuleConfig[] = [];
    const modulePatterns = [
      { name: 'BCM', pattern: [0x42, 0x43, 0x4D] }, // "BCM"
      { name: 'ECM', pattern: [0x45, 0x43, 0x4D] }, // "ECM"
      { name: 'TCM', pattern: [0x54, 0x43, 0x4D] }, // "TCM"
      { name: 'ABS', pattern: [0x41, 0x42, 0x53] }, // "ABS"
      { name: 'RFHUB', pattern: [0x52, 0x46, 0x48] }, // "RFH"
    ];

    modulePatterns.forEach(({ name, pattern }) => {
      for (let i = 0; i < bytes.length - pattern.length; i++) {
        if (pattern.every((byte, idx) => bytes[i + idx] === byte)) {
          // Found module identifier
          // Try to extract CAN address (next 2 bytes after identifier)
          const addr1 = bytes[i + pattern.length];
          const addr2 = bytes[i + pattern.length + 1];
          const address = `0x${addr1.toString(16).padStart(2, '0')}${addr2.toString(16).padStart(2, '0')}`;
          
          modules.push({
            name,
            address,
            partNumber: 'Unknown',
            softwareVersion: 'Unknown',
            hardwareVersion: 'Unknown'
          });
          break;
        }
      }
    });

    // Look for DTC codes (P0xxx, C0xxx, B0xxx, U0xxx patterns)
    const dtcCodes: DTCCode[] = [];
    for (let i = 0; i < bytes.length - 2; i++) {
      const byte1 = bytes[i];
      const byte2 = bytes[i + 1];
      
      // DTC codes are stored as 2 bytes in OBD2 format
      if (byte1 >= 0x00 && byte1 <= 0xFF && byte2 >= 0x00 && byte2 <= 0xFF) {
        const dtcValue = (byte1 << 8) | byte2;
        
        // Check if it looks like a valid DTC
        if (dtcValue >= 0x0000 && dtcValue <= 0xFFFF) {
          const dtcType = (byte1 & 0xC0) >> 6;
          const dtcCode = dtcValue & 0x3FFF;
          
          let prefix = 'P';
          if (dtcType === 1) prefix = 'C';
          else if (dtcType === 2) prefix = 'B';
          else if (dtcType === 3) prefix = 'U';
          
          const codeStr = `${prefix}${dtcCode.toString(16).padStart(4, '0').toUpperCase()}`;
          
          // Only add if it looks like a real DTC
          if (dtcCode > 0 && dtcCode < 0x3FFF) {
            dtcCodes.push({
              code: codeStr,
              module: 'Unknown',
              status: 'Stored',
              description: undefined
            });
          }
        }
      }
    }

    // Remove duplicate DTCs
    const uniqueDTCs = Array.from(new Map(dtcCodes.map(d => [d.code, d])).values());

    // Look for security bytes (16-byte patterns)
    let securityBytes: string | undefined;
    for (let i = 0; i < bytes.length - 16; i++) {
      const chunk = bytes.slice(i, i + 16);
      // Check if it looks like security data (has some entropy)
      const uniqueBytes = new Set(chunk).size;
      if (uniqueBytes >= 8) {
        securityBytes = Array.from(chunk).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
        break;
      }
    }

    return {
      filename,
      fileSize,
      vin,
      modules: modules.slice(0, 10), // Limit to first 10 found
      dtcCodes: uniqueDTCs.slice(0, 20), // Limit to first 20 unique
      securityBytes,
      timestamp: new Date()
    };
  };

  const exportToJSON = () => {
    if (!savData) return;

    const json = JSON.stringify(savData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = savData.filename.replace('.sav', '.json');
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center gap-3">
        <Database className="h-8 w-8 text-red-500" />
        <div>
          <h1 className="text-3xl font-bold">third-party diagnostic software .sav File Parser</h1>
          <p className="text-muted-foreground">
            Import and export third-party diagnostic software configuration files for cross-platform compatibility
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload .sav Configuration File</CardTitle>
          <CardDescription>
            Parse third-party diagnostic software .sav files to extract VIN, module configs, DTCs, and security data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Button asChild variant="outline" className="flex-1">
              <label className="cursor-pointer">
                <Upload className="mr-2 h-4 w-4" />
                Select .sav File
                <input
                  type="file"
                  accept=".sav"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </Button>
            {savData && (
              <Button onClick={exportToJSON}>
                <Download className="mr-2 h-4 w-4" />
                Export to JSON
              </Button>
            )}
          </div>

          {isLoading && (
            <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
              <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
              <span className="text-sm">Parsing .sav file...</span>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
              <AlertCircle className="h-4 w-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {savData && (
            <div className="flex items-center gap-2 p-3 bg-green-500/10 text-green-500 rounded-lg">
              <CheckCircle2 className="h-4 w-4" />
              <span className="text-sm">Successfully parsed {savData.filename}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {savData && (
        <>
          {/* File Information */}
          <Card>
            <CardHeader>
              <CardTitle>File Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Filename</p>
                  <p className="font-mono">{savData.filename}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">File Size</p>
                  <p className="font-mono">{(savData.fileSize / 1024).toFixed(2)} KB</p>
                </div>
                {savData.vin && (
                  <div>
                    <p className="text-sm text-muted-foreground">Vehicle VIN</p>
                    <p className="font-mono text-lg font-bold">{savData.vin}</p>
                  </div>
                )}
                {savData.timestamp && (
                  <div>
                    <p className="text-sm text-muted-foreground">Parsed At</p>
                    <p className="font-mono">{savData.timestamp.toLocaleString()}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Module Configurations */}
          {savData.modules.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Module Configurations</CardTitle>
                <CardDescription>
                  {savData.modules.length} module(s) detected
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Module</TableHead>
                      <TableHead>CAN Address</TableHead>
                      <TableHead>Part Number</TableHead>
                      <TableHead>Software Version</TableHead>
                      <TableHead>Hardware Version</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {savData.modules.map((module, idx) => (
                      <TableRow key={idx}>
                        <TableCell>
                          <Badge>{module.name}</Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{module.address}</TableCell>
                        <TableCell className="font-mono text-sm">{module.partNumber}</TableCell>
                        <TableCell className="font-mono text-sm">{module.softwareVersion}</TableCell>
                        <TableCell className="font-mono text-sm">{module.hardwareVersion}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {/* DTC Codes */}
          {savData.dtcCodes.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Diagnostic Trouble Codes</CardTitle>
                <CardDescription>
                  {savData.dtcCodes.length} DTC(s) found
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>DTC Code</TableHead>
                      <TableHead>Module</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Description</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {savData.dtcCodes.map((dtc, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="font-mono font-bold">{dtc.code}</TableCell>
                        <TableCell>{dtc.module}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{dtc.status}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {dtc.description || 'No description available'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {/* Security Bytes */}
          {savData.securityBytes && (
            <Card>
              <CardHeader>
                <CardTitle>Security Data</CardTitle>
                <CardDescription>
                  Extracted security bytes (potential SKIM/RFHUB data)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-muted rounded-lg font-mono text-sm break-all">
                  {savData.securityBytes}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  ⚠️ This may contain sensitive security data. Handle with care.
                </p>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Parser Information */}
      <Card>
        <CardHeader>
          <CardTitle>About third-party diagnostic software .sav Files</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">What are .sav files?</h3>
            <p className="text-sm text-muted-foreground">
              third-party diagnostic software .sav files are binary configuration snapshots that store diagnostic session data including:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground mt-2">
              <li>Vehicle VIN</li>
              <li>Module configurations (BCM, ECM, TCM, etc.)</li>
              <li>Diagnostic Trouble Codes (DTCs)</li>
              <li>Security bytes and pairing data</li>
              <li>Session metadata</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Available Files</h3>
            <p className="text-sm text-muted-foreground">
              The SRT Lab includes <strong>169 real third-party diagnostic software .sav files</strong> from production vehicles for testing and analysis.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Parser Limitations</h3>
            <p className="text-sm text-muted-foreground">
              This is a simplified parser based on reverse engineering. Full format specification would require complete third-party diagnostic software database decryption.
              Some data may not be extracted correctly.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
