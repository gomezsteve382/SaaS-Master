import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle2, XCircle, AlertTriangle, Wifi } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { BackButton } from "@/components/BackButton";
import { ConnectionManager } from "@/lib/obd2-protocol";

interface DiagnosticStep {
  name: string;
  status: 'pending' | 'running' | 'success' | 'error';
  message: string;
  details?: string;
}

export default function ConnectionDiagnostic() {
  const { toast } = useToast();
  const [connectionManager] = useState(() => new ConnectionManager());
  const [running, setRunning] = useState(false);
  const [steps, setSteps] = useState<DiagnosticStep[]>([]);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [...prev, `[${timestamp}] ${message}`]);
  };

  const updateStep = (index: number, updates: Partial<DiagnosticStep>) => {
    setSteps(prev => prev.map((step, i) => i === index ? { ...step, ...updates } : step));
  };

  const runDiagnostic = async () => {
    setRunning(true);
    setLogs([]);
    
    const diagnosticSteps: DiagnosticStep[] = [
      { name: "Web Serial API Check", status: 'pending', message: '' },
      { name: "Request Serial Port", status: 'pending', message: '' },
      { name: "Open Port Connection", status: 'pending', message: '' },
      { name: "ELM327 Initialization", status: 'pending', message: '' },
      { name: "Protocol Detection", status: 'pending', message: '' },
      { name: "Test Communication (0100)", status: 'pending', message: '' },
      { name: "Test VIN Read (22F190)", status: 'pending', message: '' },
    ];
    
    setSteps(diagnosticSteps);
    
    try {
      // Step 1: Check Web Serial API
      updateStep(0, { status: 'running', message: 'Checking browser support...' });
      addLog('Checking Web Serial API support');
      
      if (!('serial' in navigator)) {
        updateStep(0, { 
          status: 'error', 
          message: 'Web Serial API not supported',
          details: 'Please use Chrome, Edge, or Opera browser'
        });
        addLog('❌ Web Serial API not available');
        return;
      }
      
      updateStep(0, { status: 'success', message: 'Web Serial API available' });
      addLog('✅ Web Serial API supported');
      
      // Step 2: Request port
      updateStep(1, { status: 'running', message: 'Requesting serial port...' });
      addLog('Opening port selection dialog');
      
      let port: any;
      try {
        port = await (navigator.serial as any).requestPort();
        updateStep(1, { status: 'success', message: 'Port selected' });
        addLog('✅ Serial port selected');
      } catch (e: any) {
        updateStep(1, { 
          status: 'error', 
          message: 'Port selection cancelled or failed',
          details: e.message
        });
        addLog(`❌ Port selection failed: ${e.message}`);
        return;
      }
      
      // Step 3: Open connection
      updateStep(2, { status: 'running', message: 'Opening port...' });
      addLog('Attempting to open serial port');
      
      const connected = await connectionManager.connect('elm327', port);
      
      if (!connected) {
        updateStep(2, { 
          status: 'error', 
          message: 'Failed to open port',
          details: 'Connection manager returned false'
        });
        addLog('❌ Failed to establish connection');
        return;
      }
      
      updateStep(2, { status: 'success', message: 'Port opened successfully' });
      addLog('✅ Serial port opened');
      
      // Step 4: Check initialization
      updateStep(3, { status: 'running', message: 'Checking ELM327 initialization...' });
      addLog('Verifying ELM327 initialization');
      
      const protocol = connectionManager.getProtocol();
      if (!protocol) {
        updateStep(3, { 
          status: 'error', 
          message: 'No protocol available',
          details: 'Protocol not initialized'
        });
        addLog('❌ Protocol not available');
        return;
      }
      
      updateStep(3, { status: 'success', message: 'ELM327 initialized' });
      addLog('✅ ELM327 protocol ready');
      
      // Step 5: Check protocol detection
      updateStep(4, { status: 'running', message: 'Detecting vehicle protocol...' });
      addLog('Sending ATDPN to detect protocol');
      
      try {
        const protocolNum = await (protocol as any).sendCommand('ATDPN');
        updateStep(4, { 
          status: 'success', 
          message: `Protocol detected: ${protocolNum.trim()}`,
          details: protocolNum.trim() === '6' ? 'ISO 15765-4 CAN (11-bit, 500 kbaud)' : 
                   protocolNum.trim() === '7' ? 'ISO 15765-4 CAN (29-bit, 500 kbaud)' :
                   protocolNum.trim() === '8' ? 'ISO 15765-4 CAN (11-bit, 250 kbaud)' :
                   protocolNum.trim() === '9' ? 'ISO 15765-4 CAN (29-bit, 250 kbaud)' : 'Unknown'
        });
        addLog(`✅ Protocol: ${protocolNum.trim()}`);
      } catch (e: any) {
        updateStep(4, { 
          status: 'error', 
          message: 'Protocol detection failed',
          details: e.message
        });
        addLog(`❌ Protocol detection error: ${e.message}`);
      }
      
      // Step 6: Test basic communication
      updateStep(5, { status: 'running', message: 'Testing basic OBD2 communication...' });
      addLog('Sending 0100 (supported PIDs)');
      
      try {
        const response = await (protocol as any).sendCommand('0100');
        if (response.includes('NO DATA')) {
          updateStep(5, { 
            status: 'error', 
            message: 'No response from vehicle',
            details: 'Vehicle may not support OBD2 or adapter not connected to vehicle'
          });
          addLog('❌ NO DATA response');
        } else if (response.includes('41 00')) {
          updateStep(5, { 
            status: 'success', 
            message: 'Vehicle responding',
            details: `Response: ${response.substring(0, 50)}`
          });
          addLog(`✅ Vehicle responded: ${response.substring(0, 50)}`);
        } else {
          updateStep(5, { 
            status: 'error', 
            message: 'Unexpected response',
            details: response.substring(0, 100)
          });
          addLog(`⚠️ Unexpected response: ${response.substring(0, 50)}`);
        }
      } catch (e: any) {
        updateStep(5, { 
          status: 'error', 
          message: 'Communication test failed',
          details: e.message
        });
        addLog(`❌ Communication error: ${e.message}`);
      }
      
      // Step 7: Test VIN read
      updateStep(6, { status: 'running', message: 'Testing VIN read...' });
      addLog('Sending 22F190 (read VIN via UDS)');
      
      try {
        // Try PCM first (0x7E0/0x7E8)
        const response = await (protocol as any).sendUDS(0x7E0, 0x7E8, [0x22, 0xF1, 0x90], 1);
        
        if (response && response.length > 3 && response[0] === 0x62) {
          const vinBytes = response.slice(3);
          const vin = String.fromCharCode(...vinBytes).replace(/[^\x20-\x7E]/g, '');
          updateStep(6, { 
            status: 'success', 
            message: `VIN read successful: ${vin}`,
            details: `From PCM (0x7E0)`
          });
          addLog(`✅ VIN: ${vin}`);
        } else {
          updateStep(6, { 
            status: 'error', 
            message: 'VIN read failed',
            details: 'Module did not respond or negative response'
          });
          addLog('❌ No VIN response from PCM');
        }
      } catch (e: any) {
        updateStep(6, { 
          status: 'error', 
          message: 'VIN read error',
          details: e.message
        });
        addLog(`❌ VIN read error: ${e.message}`);
      }
      
      toast({
        title: "Diagnostic Complete",
        description: "Check results below for details",
      });
      
    } catch (error: any) {
      toast({
        title: "Diagnostic Failed",
        description: error.message,
        variant: "destructive",
      });
      addLog(`❌ Fatal error: ${error.message}`);
    } finally {
      setRunning(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'running': return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      default: return <div className="h-5 w-5 rounded-full border-2 border-gray-300" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success': return <Badge variant="default" className="bg-green-500">Success</Badge>;
      case 'error': return <Badge variant="destructive">Error</Badge>;
      case 'running': return <Badge variant="default" className="bg-blue-500">Running</Badge>;
      default: return <Badge variant="outline">Pending</Badge>;
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Connection Diagnostic</h1>
        <p className="text-muted-foreground">
          Diagnose hardware connection issues and verify OBD2 communication
        </p>
      </div>

      <Alert className="mb-6">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Before starting:</strong> Make sure your OBD2 adapter (OBDLink EX, ELM327, etc.) is plugged into your computer's USB port. 
          If testing with a vehicle, ensure the adapter is connected to the vehicle's OBD2 port and ignition is ON.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wifi className="h-5 w-5" />
              Diagnostic Steps
            </CardTitle>
            <CardDescription>
              Step-by-step connection verification
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={runDiagnostic} 
              disabled={running}
              className="w-full mb-4"
            >
              {running ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Running Diagnostic...
                </>
              ) : (
                'Start Diagnostic'
              )}
            </Button>

            <div className="space-y-3">
              {steps.map((step, index) => (
                <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="mt-0.5">
                    {getStatusIcon(step.status)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-medium text-sm">{step.name}</span>
                      {getStatusBadge(step.status)}
                    </div>
                    {step.message && (
                      <p className="text-sm text-muted-foreground">{step.message}</p>
                    )}
                    {step.details && (
                      <p className="text-xs text-muted-foreground mt-1 font-mono">
                        {step.details}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Diagnostic Log</CardTitle>
            <CardDescription>
              Real-time diagnostic output
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-black text-green-400 font-mono text-xs p-4 rounded-lg h-[500px] overflow-y-auto">
              {logs.length === 0 ? (
                <div className="text-gray-500">No logs yet. Click "Start Diagnostic" to begin.</div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="mb-1">{log}</div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Common Issues & Solutions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">❌ Web Serial API not supported</h3>
              <p className="text-sm text-muted-foreground">
                <strong>Solution:</strong> Use Chrome, Edge, or Opera browser. Firefox and Safari don't support Web Serial API.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">❌ Port selection cancelled</h3>
              <p className="text-sm text-muted-foreground">
                <strong>Solution:</strong> Click "Start Diagnostic" again and select your OBD2 adapter from the list. Look for devices with names like "USB Serial", "CP210x", "FTDI", or "OBDLink".
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">❌ NO DATA response</h3>
              <p className="text-sm text-muted-foreground">
                <strong>Solution:</strong> Make sure the adapter is plugged into the vehicle's OBD2 port and the ignition is ON (engine doesn't need to be running). Check that the adapter's LED is blinking/lit.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">❌ VIN read failed</h3>
              <p className="text-sm text-muted-foreground">
                <strong>Solution:</strong> Some modules require security access before reading VIN. Try the Module Scanner's "Quick Scan" which tests multiple CAN addresses.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
