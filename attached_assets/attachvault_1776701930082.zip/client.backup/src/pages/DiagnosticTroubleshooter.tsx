import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, Wrench } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';

export default function DiagnosticTroubleshooter() {
  const [dtcCode, setDtcCode] = useState('');
  const [vehicle, setVehicle] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [previousRepairs, setPreviousRepairs] = useState('');
  const [diagnosis, setDiagnosis] = useState('');

  const troubleshootMutation = trpc.ai.troubleshootDTC.useMutation();

  const handleTroubleshoot = async () => {
    if (!dtcCode || !vehicle) {
      alert('Please provide DTC code and vehicle information');
      return;
    }

    try {
      const response = await troubleshootMutation.mutateAsync({
        dtcCode,
        vehicle,
        symptoms: symptoms || undefined,
        previousRepairs: previousRepairs || undefined
      });
      setDiagnosis(typeof response.diagnosis === 'string' ? response.diagnosis : JSON.stringify(response.diagnosis));
    } catch (error) {
      console.error('Troubleshooting failed:', error);
      alert('Troubleshooting failed. Please try again.');
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Wrench className="w-10 h-10 text-primary" />
          Diagnostic Troubleshooter
        </h1>
        <p className="text-muted-foreground">
          AI-powered DTC analysis with repair suggestions. Get ASE Master Technician-level diagnostic guidance.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Enter a DTC code and vehicle info. The AI analyzes the code, 
          considers symptoms and previous repairs, then provides root cause analysis, diagnostic steps, 
          and repair procedures. Based on 20+ years of FCA/Stellantis diagnostic experience.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Diagnostic Information</CardTitle>
            <CardDescription>Provide DTC code and vehicle details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="dtc-code">DTC Code *</Label>
              <Input
                id="dtc-code"
                value={dtcCode}
                onChange={(e) => setDtcCode(e.target.value.toUpperCase())}
                placeholder="P0420, C2202, B1234, U0100"
                maxLength={5}
              />
              <p className="text-xs text-muted-foreground mt-1">
                P=Powertrain, C=Chassis, B=Body, U=Network
              </p>
            </div>

            <div>
              <Label htmlFor="vehicle">Vehicle *</Label>
              <Input
                id="vehicle"
                value={vehicle}
                onChange={(e) => setVehicle(e.target.value)}
                placeholder="2019 Dodge Charger R/T 5.7L HEMI"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Include year, make, model, engine
              </p>
            </div>

            <div>
              <Label htmlFor="symptoms">Symptoms (Optional)</Label>
              <Textarea
                id="symptoms"
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder="Check engine light on, rough idle, loss of power, etc."
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="previous-repairs">Previous Repairs (Optional)</Label>
              <Textarea
                id="previous-repairs"
                value={previousRepairs}
                onChange={(e) => setPreviousRepairs(e.target.value)}
                placeholder="Replaced O2 sensors, cleaned throttle body, etc."
                rows={3}
              />
            </div>

            <Button 
              onClick={handleTroubleshoot} 
              disabled={troubleshootMutation.isPending || !dtcCode || !vehicle}
              className="w-full"
            >
              {troubleshootMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Wrench className="w-4 h-4 mr-2" />
                  Diagnose Problem
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Diagnostic Report</CardTitle>
            <CardDescription>AI-powered root cause analysis</CardDescription>
          </CardHeader>
          <CardContent>
            {diagnosis ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{diagnosis}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Wrench className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Enter DTC code and vehicle info to begin</p>
                <p className="text-xs mt-2">
                  Get professional diagnostic guidance
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Common DTC Examples */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Common FCA/Stellantis DTCs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <h3 className="font-semibold mb-2">Powertrain (P-codes)</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• P0420 - Catalyst efficiency</li>
                <li>• P0300 - Random misfire</li>
                <li>• P0128 - Coolant thermostat</li>
                <li>• P0456 - EVAP small leak</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Chassis (C-codes)</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• C2202 - VIN mismatch</li>
                <li>• C1513 - ABS wheel speed</li>
                <li>• C121C - Steering angle</li>
                <li>• C2100 - RFHUB fault</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Network (U-codes)</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• U0100 - Lost comm with ECM</li>
                <li>• U0140 - Lost comm with BCM</li>
                <li>• U0155 - Lost comm with IPC</li>
                <li>• U0401 - Invalid data from ECM</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
