import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { BackButton } from "@/components/BackButton";
import { 
  CheckCircle2, 
  XCircle, 
  Clock,
  AlertTriangle,
  Info,
  Play,
  RotateCcw,
  Download
} from 'lucide-react';
import { trpc } from '@/lib/trpc';

type Step = 'input' | 'detecting' | 'reading' | 'security' | 'writing' | 'verifying' | 'report';

export default function AutomatedVINProgrammingWizard() {
  const [currentStep, setCurrentStep] = useState<Step>('input');
  const [vehicleYear, setVehicleYear] = useState(2019);
  const [vehicleMake, setVehicleMake] = useState('Dodge');
  const [vehicleModel, setVehicleModel] = useState('Challenger');
  const [oldVIN, setOldVIN] = useState('');
  const [newVIN, setNewVIN] = useState('');
  
  // Method selector and dual VIN inputs
  const [programmingMethod, setProgrammingMethod] = useState<'standard' | 'eeprom' | 'bootloader' | 'jtag'>('standard');
  const [programOriginalVIN, setProgramOriginalVIN] = useState(false);
  const [programCurrentVIN, setProgramCurrentVIN] = useState(true);
  const [originalVIN, setOriginalVIN] = useState('');
  const [currentVIN, setCurrentVIN] = useState('');

  const [detectionResults, setDetectionResults] = useState<any>(null);
  const [readResults, setReadResults] = useState<any>(null);
  const [securityResults, setSecurityResults] = useState<any>(null);
  const [writeResults, setWriteResults] = useState<any>(null);
  const [verificationResults, setVerificationResults] = useState<any>(null);
  const [reportResults, setReportResults] = useState<any>(null);

  const detectModulesMutation = trpc.vinProgramming.detectModules.useMutation();
  const readVINsMutation = trpc.vinProgramming.readVINs.useMutation();
  const performSecurityAccessMutation = trpc.vinProgramming.performSecurityAccess.useMutation();
  const writeVINsMutation = trpc.vinProgramming.writeVINs.useMutation();
  const verifySyncMutation = trpc.vinProgramming.verifySync.useMutation();
  const generateReportMutation = trpc.vinProgramming.generateReport.useMutation();

  const startWorkflow = async () => {
    try {
      // Step 1: Detect modules
      setCurrentStep('detecting');
      const detection = await detectModulesMutation.mutateAsync({
        vehicleYear,
        vehicleMake,
        vehicleModel,
      });
      setDetectionResults(detection);

      // Step 2: Read current VINs
      setCurrentStep('reading');
      const read = await readVINsMutation.mutateAsync({
        modules: detection.modules,
      });
      setReadResults(read);

      // Auto-fill old VIN from first successful read
      const firstSuccessfulRead = read.results.find(r => r.status === 'success');
      if (firstSuccessfulRead && firstSuccessfulRead.currentVIN) {
        setOldVIN(firstSuccessfulRead.currentVIN);
      }

      // Step 3: Perform security access
      setCurrentStep('security');
      const security = await performSecurityAccessMutation.mutateAsync({
        modules: detection.modules,
      });
      setSecurityResults(security);

      // Check if any critical modules failed
      const criticalFailed = security.results.some(
        r => (r.moduleId === 'BCM' || r.moduleId === 'RFHUB') && r.status === 'failed'
      );

      if (criticalFailed) {
        throw new Error('Critical module security access failed. Cannot proceed with VIN programming.');
      }

      // Step 4: Write VINs
      setCurrentStep('writing');
      const write = await writeVINsMutation.mutateAsync({
        modules: detection.modules,
        newVIN,
      });
      setWriteResults(write);

      // Step 5: Verify sync
      setCurrentStep('verifying');
      const verification = await verifySyncMutation.mutateAsync({
        modules: detection.modules,
        expectedVIN: newVIN,
      });
      setVerificationResults(verification);

      // Step 6: Generate report
      setCurrentStep('report');
      const report = await generateReportMutation.mutateAsync({
        vehicleInfo: {
          year: vehicleYear,
          make: vehicleMake,
          model: vehicleModel,
        },
        oldVIN,
        newVIN,
        detectionResults: detection,
        readResults: read,
        securityResults: security,
        writeResults: write,
        verificationResults: verification,
        timestamp: new Date().toISOString(),
      });
      setReportResults(report);
    } catch (error) {
      console.error('Workflow failed:', error);
    }
  };

  const resetWorkflow = () => {
    setCurrentStep('input');
    setDetectionResults(null);
    setReadResults(null);
    setSecurityResults(null);
    setWriteResults(null);
    setVerificationResults(null);
    setReportResults(null);
  };

  const exportReport = () => {
    const report = {
      vehicleInfo: {
        year: vehicleYear,
        make: vehicleMake,
        model: vehicleModel,
      },
      oldVIN,
      newVIN,
      detectionResults,
      readResults,
      securityResults,
      writeResults,
      verificationResults,
      reportResults,
      timestamp: new Date().toISOString(),
    };

    const json = JSON.stringify(report, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VIN_Programming_Report_${Date.now()}.json`;
    a.click();
  };

  const getStepStatus = (step: Step) => {
    const steps: Step[] = ['input', 'detecting', 'reading', 'security', 'writing', 'verifying', 'report'];
    const currentIndex = steps.indexOf(currentStep);
    const stepIndex = steps.indexOf(step);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'active';
    return 'pending';
  };

  const getStepIcon = (step: Step) => {
    const status = getStepStatus(step);
    if (status === 'completed') return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    if (status === 'active') return <Clock className="h-5 w-5 text-yellow-500 animate-pulse" />;
    return <div className="h-5 w-5 rounded-full border-2 border-gray-300" />;
  };

  const getOverallProgress = () => {
    const steps: Step[] = ['input', 'detecting', 'reading', 'security', 'writing', 'verifying', 'report'];
    const currentIndex = steps.indexOf(currentStep);
    return ((currentIndex + 1) / steps.length) * 100;
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          Automated VIN Programming Wizard
        </h1>
        <p className="text-muted-foreground mt-2">
          Automatically detect, unlock, program, and verify VINs across all modules
        </p>
      </div>

      {/* Overall Progress */}
      <Card className="p-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Overall Progress</h2>
            <Badge>{getOverallProgress().toFixed(0)}%</Badge>
          </div>
          <Progress value={getOverallProgress()} className="h-3" />
        </div>
      </Card>

      {/* Step Indicators */}
      <Card className="p-6">
        <div className="space-y-4">
          {[
            { step: 'input' as Step, title: 'Vehicle & VIN Input', description: 'Enter vehicle information and target VIN' },
            { step: 'detecting' as Step, title: 'Module Detection', description: 'Scan CAN bus for all modules' },
            { step: 'reading' as Step, title: 'Read Current VINs', description: 'Read VINs from all detected modules' },
            { step: 'security' as Step, title: 'Security Access', description: 'Unlock all modules automatically' },
            { step: 'writing' as Step, title: 'VIN Programming', description: 'Write new VIN with CRC calculation' },
            { step: 'verifying' as Step, title: 'Verification', description: 'Verify VIN sync across all modules' },
            { step: 'report' as Step, title: 'Report Generation', description: 'Generate detailed before/after report' },
          ].map(({ step, title, description }) => (
            <div key={step} className="flex items-start gap-4">
              {getStepIcon(step)}
              <div className="flex-1">
                <h3 className={`font-semibold ${getStepStatus(step) === 'active' ? 'text-yellow-500' : ''}`}>
                  {title}
                </h3>
                <p className="text-sm text-muted-foreground">{description}</p>
              </div>
              {getStepStatus(step) === 'completed' && (
                <Badge variant="outline" className="text-green-500 border-green-500">Complete</Badge>
              )}
              {getStepStatus(step) === 'active' && (
                <Badge variant="outline" className="text-yellow-500 border-yellow-500">In Progress</Badge>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Step 1: Input */}
      {currentStep === 'input' && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Step 1: Vehicle & VIN Input</h2>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="year">Year</Label>
                <Select value={vehicleYear.toString()} onValueChange={(v) => setVehicleYear(parseInt(v))}>
                  <SelectTrigger id="year">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 28 }, (_, i) => 1996 + i).map(year => (
                      <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="make">Make</Label>
                <Select value={vehicleMake} onValueChange={setVehicleMake}>
                  <SelectTrigger id="make">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Dodge">Dodge</SelectItem>
                    <SelectItem value="Chrysler">Chrysler</SelectItem>
                    <SelectItem value="Jeep">Jeep</SelectItem>
                    <SelectItem value="RAM">RAM</SelectItem>
                    <SelectItem value="Fiat">Fiat</SelectItem>
                    <SelectItem value="Alfa Romeo">Alfa Romeo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="model">Model</Label>
                <Input
                  id="model"
                  value={vehicleModel}
                  onChange={(e) => setVehicleModel(e.target.value)}
                  placeholder="Challenger"
                />
              </div>
            </div>

            {/* Programming Method Selector */}
            <div>
              <Label htmlFor="method">Programming Method</Label>
              <Select value={programmingMethod} onValueChange={(v: any) => setProgrammingMethod(v)}>
                <SelectTrigger id="method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard UDS (0x2E) - Safest</SelectItem>
                  <SelectItem value="eeprom">Direct EEPROM Write (0x23/0x3D) - Advanced</SelectItem>
                  <SelectItem value="bootloader">Bootloader Mode (0x10 0x02) - Expert</SelectItem>
                  <SelectItem value="jtag">JTAG/BDM Hardware - Requires Equipment</SelectItem>
                </SelectContent>
              </Select>
              {programmingMethod === 'eeprom' && (
                <p className="text-xs text-yellow-500 mt-1">⚠️ Bypasses UDS security, writes directly to memory</p>
              )}
              {programmingMethod === 'bootloader' && (
                <p className="text-xs text-orange-500 mt-1">⚠️ High risk - module may become unresponsive if interrupted</p>
              )}
              {programmingMethod === 'jtag' && (
                <p className="text-xs text-red-500 mt-1">⚠️ Requires physical hardware connection (JTAG/BDM adapter)</p>
              )}
            </div>

            {/* VIN Selection */}
            <div className="space-y-3">
              <Label>VIN Programming Options</Label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={programOriginalVIN}
                    onChange={(e) => setProgramOriginalVIN(e.target.checked)}
                    className="h-4 w-4"
                  />
                  <span className="text-sm">Program Original VIN (DID 0xF19E)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={programCurrentVIN}
                    onChange={(e) => setProgramCurrentVIN(e.target.checked)}
                    className="h-4 w-4"
                  />
                  <span className="text-sm">Program Current VIN (DID 0xF190)</span>
                </label>
              </div>
            </div>

            {/* Original VIN Input */}
            {programOriginalVIN && (
              <div>
                <Label htmlFor="originalVIN">Original VIN (17 characters)</Label>
                <Input
                  id="originalVIN"
                  value={originalVIN}
                  onChange={(e) => setOriginalVIN(e.target.value.toUpperCase())}
                  placeholder="1C4RJFAG0FC123456"
                  maxLength={17}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground mt-1">First VIN ever written to module (usually permanent)</p>
              </div>
            )}

            {/* Current VIN Input */}
            {programCurrentVIN && (
              <div>
                <Label htmlFor="currentVIN">Current VIN (17 characters)</Label>
                <Input
                  id="currentVIN"
                  value={currentVIN}
                  onChange={(e) => setCurrentVIN(e.target.value.toUpperCase())}
                  placeholder="2C3CDXKT3FH796320"
                  maxLength={17}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground mt-1">Active VIN used for diagnostics and communication</p>
              </div>
            )}

            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Automatic Workflow:</strong> This wizard will automatically detect all modules, perform security access, 
                calculate CRCs, write VINs in proper sequence, and verify sync. No manual intervention required!
              </AlertDescription>
            </Alert>

            <Button
              onClick={startWorkflow}
              disabled={
                (!programOriginalVIN && !programCurrentVIN) ||
                (programOriginalVIN && originalVIN.length !== 17) ||
                (programCurrentVIN && currentVIN.length !== 17)
              }
              size="lg"
              className="w-full"
            >
              <Play className="mr-2 h-5 w-5" />
              Start Automated VIN Programming
            </Button>
          </div>
        </Card>
      )}

      {/* Step 2-6: Progress Display */}
      {currentStep !== 'input' && currentStep !== 'report' && (
        <Card className="p-6">
          <div className="flex items-center justify-center py-8">
            <div className="text-center space-y-4">
              <Clock className="h-16 w-16 text-yellow-500 animate-pulse mx-auto" />
              <h2 className="text-2xl font-semibold">
                {currentStep === 'detecting' && 'Detecting Modules...'}
                {currentStep === 'reading' && 'Reading Current VINs...'}
                {currentStep === 'security' && 'Performing Security Access...'}
                {currentStep === 'writing' && 'Programming VINs...'}
                {currentStep === 'verifying' && 'Verifying VIN Sync...'}
              </h2>
              <p className="text-muted-foreground">
                Please wait while the wizard completes this step automatically
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Step 7: Report */}
      {currentStep === 'report' && reportResults && (
        <div className="space-y-4">
          <Alert variant={verificationResults?.allMatched ? 'default' : 'destructive'}>
            {verificationResults?.allMatched ? (
              <CheckCircle2 className="h-4 w-4" />
            ) : (
              <AlertTriangle className="h-4 w-4" />
            )}
            <AlertDescription>
              {reportResults.summary}
            </AlertDescription>
          </Alert>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Programming Report</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground">Total Modules</p>
                  <p className="text-2xl font-bold">{reportResults.totalModules}</p>
                </div>
                <div className="border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground">Successful</p>
                  <p className="text-2xl font-bold text-green-500">{reportResults.successfulModules}</p>
                </div>
                <div className="border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground">Failed</p>
                  <p className="text-2xl font-bold text-red-500">{reportResults.failedModules}</p>
                </div>
                <div className="border rounded-lg p-4">
                  <p className="text-sm text-muted-foreground">Duration</p>
                  <p className="text-2xl font-bold">{reportResults.duration}</p>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-semibold mb-2">Module Details</h3>
                <div className="space-y-2">
                  {writeResults?.results.map((result: any) => (
                    <div key={result.moduleId} className="flex items-center justify-between border rounded-lg p-3">
                      <div className="flex items-center gap-3">
                        {result.status === 'success' && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                        {result.status === 'failed' && <XCircle className="h-5 w-5 text-red-500" />}
                        {result.status === 'skipped' && <div className="h-5 w-5 rounded-full bg-gray-300" />}
                        <div>
                          <p className="font-semibold">{result.moduleName}</p>
                          {result.error && <p className="text-sm text-red-500">{result.error}</p>}
                        </div>
                      </div>
                      <div className="text-right">
                        {result.newVIN && <p className="font-mono text-sm">{result.newVIN}</p>}
                        {result.crc && <p className="text-xs text-muted-foreground">CRC: {result.crc}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="flex gap-2">
                <Button onClick={exportReport} variant="outline" className="flex-1">
                  <Download className="mr-2 h-4 w-4" />
                  Export Report
                </Button>
                <Button onClick={resetWorkflow} variant="outline" className="flex-1">
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Start New Programming
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Info Card */}
      <Card className="p-6 bg-muted/50">
        <h3 className="text-lg font-semibold mb-4">How It Works</h3>
        <div className="space-y-2 text-sm">
          <p><strong>1. Module Detection:</strong> Scans CAN bus for ALL 27 modules (BCM, RFHUB, ECM, TCM, ABS, IPC, ACM, RADIO, CGW, SCCM, FDCM, DTCM, ACC, HVAC, TPMS, AHBM, PAM, BSM, FCM, LDW, SKIM, WCM, DDM, PDM, RFM, PLGM, and more)</p>
          <p><strong>2. VIN Reading:</strong> Reads current VIN from all modules using UDS 0x22 F1 90</p>
          <p><strong>3. Security Access:</strong> Automatically unlocks modules using correct algorithm (SBEC2/NGC3/Shift-XOR/Atlantis)</p>
          <p><strong>4. CRC Calculation:</strong> Calculates RFHUB complement and BCM CRC-16 automatically</p>
          <p><strong>5. VIN Programming:</strong> Writes VINs in proper sequence to all detected modules (BCM → RFHUB → ECM → TCM → ABS → IPC → ACM → RADIO → CGW → SCCM → FDCM → DTCM → ACC)</p>
          <p><strong>6. Verification:</strong> Verifies all modules have matching VINs to prevent C2202 DTC</p>
          <p><strong>7. Report:</strong> Generates detailed report with before/after VINs and success/failure status</p>
        </div>
      </Card>
    </div>
  );
}
