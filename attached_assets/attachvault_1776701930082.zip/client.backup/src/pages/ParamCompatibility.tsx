import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Search, Download, ArrowRight, Database } from "lucide-react";

export default function ParamCompatibility() {
  const [searchMode, setSearchMode] = useState<"device" | "param">("device");
  const [deviceId, setDeviceId] = useState("");
  const [paramId, setParamId] = useState("");

  const { data: compatibilityData, isLoading, refetch } = trpc.alphaOBD.checkParameterCompatibility.useQuery(
    {
      deviceId: searchMode === "device" ? deviceId : undefined,
      paramId: searchMode === "param" ? paramId : undefined,
    },
    {
      enabled: false, // Manual trigger
    }
  );

  const handleSearch = () => {
    if (searchMode === "device" && !deviceId) {
      toast.error("Please enter a device ID");
      return;
    }
    if (searchMode === "param" && !paramId) {
      toast.error("Please enter a parameter ID");
      return;
    }
    refetch();
  };

  const exportToCSV = () => {
    let csvContent = "";
    let filename = "";

    if (searchMode === "device" && compatibilityData?.parameters) {
      csvContent = "Parameter ID,Parameter Name,Unit ID,Unit Name,Device ID\n";
      compatibilityData.parameters.forEach((row: any) => {
        csvContent += `${row.paramId},${row.paramName || 'N/A'},${row.unitId || 'N/A'},${row.unitName || 'N/A'},${row.deviceId}\n`;
      });
      filename = `device_${deviceId}_parameters.csv`;
    } else if (searchMode === "param" && compatibilityData?.devices) {
      csvContent = "Device ID,Device Name,Unit ID,Unit Name,Parameter ID\n";
      compatibilityData.devices.forEach((row: any) => {
        csvContent += `${row.deviceId},${row.deviceName || 'N/A'},${row.unitId || 'N/A'},${row.unitName || 'N/A'},${row.paramId}\n`;
      });
      filename = `param_${paramId}_devices.csv`;
    }

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exported successfully");
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Parameter Compatibility Checker</h1>
        <p className="text-muted-foreground">
          Search 15,393 device-parameter mappings to find compatibility
        </p>
      </div>

      <div className="grid gap-6">
        {/* Search Interface */}
        <Card>
          <CardHeader>
            <CardTitle>Search Mode</CardTitle>
            <CardDescription>Choose how you want to search</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={searchMode} onValueChange={(v) => setSearchMode(v as "device" | "param")}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="device">
                  <Database className="h-4 w-4 mr-2" />
                  Device → Parameters
                </TabsTrigger>
                <TabsTrigger value="param">
                  <ArrowRight className="h-4 w-4 mr-2" />
                  Parameter → Devices
                </TabsTrigger>
              </TabsList>

              <TabsContent value="device" className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Find parameters for a specific ECU</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Enter a device ID to see all supported parameters
                  </p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter device ID (e.g., 221, 222, 223...)"
                      value={deviceId}
                      onChange={(e) => setDeviceId(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                    <Button onClick={handleSearch} disabled={isLoading}>
                      <Search className="h-4 w-4 mr-2" />
                      Search
                    </Button>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="param" className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Find ECUs that support a parameter</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Enter a parameter ID to see all compatible devices
                  </p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter parameter ID (e.g., 1, 2, 3...)"
                      value={paramId}
                      onChange={(e) => setParamId(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                    <Button onClick={handleSearch} disabled={isLoading}>
                      <Search className="h-4 w-4 mr-2" />
                      Search
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Results Table */}
        {compatibilityData && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Compatibility Results</CardTitle>
                  <CardDescription>
                    {searchMode === "device" && compatibilityData.parameters && 
                      `Found ${compatibilityData.parameters.length} parameters for device ${deviceId}`
                    }
                    {searchMode === "param" && compatibilityData.devices && 
                      `Found ${compatibilityData.devices.length} devices supporting parameter ${paramId}`
                    }
                  </CardDescription>
                </div>
                <Button onClick={exportToCSV} variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {searchMode === "device" && compatibilityData.parameters && (
                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Parameter ID</TableHead>
                        <TableHead>Parameter Name</TableHead>
                        <TableHead>Unit ID</TableHead>
                        <TableHead>Unit Name</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {compatibilityData.parameters.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground">
                            No parameters found for this device
                          </TableCell>
                        </TableRow>
                      )}
                      {compatibilityData.parameters.map((row: any, idx: number) => (
                        <TableRow key={idx}>
                          <TableCell className="font-mono">{row.paramId}</TableCell>
                          <TableCell>{row.paramName || 'N/A'}</TableCell>
                          <TableCell className="font-mono">{row.unitId || 'N/A'}</TableCell>
                          <TableCell>{row.unitName || 'N/A'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {searchMode === "param" && compatibilityData.devices && (
                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Device ID</TableHead>
                        <TableHead>Device Name</TableHead>
                        <TableHead>Unit ID</TableHead>
                        <TableHead>Unit Name</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {compatibilityData.devices.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground">
                            No devices found for this parameter
                          </TableCell>
                        </TableRow>
                      )}
                      {compatibilityData.devices.map((row: any, idx: number) => (
                        <TableRow key={idx}>
                          <TableCell className="font-mono">{row.deviceId}</TableCell>
                          <TableCell>{row.deviceName || 'N/A'}</TableCell>
                          <TableCell className="font-mono">{row.unitId || 'N/A'}</TableCell>
                          <TableCell>{row.unitName || 'N/A'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {compatibilityData.error && (
                <div className="text-center text-muted-foreground py-8">
                  {compatibilityData.error}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Help Card */}
        {!compatibilityData && (
          <Card>
            <CardHeader>
              <CardTitle>How to Use</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Device → Parameters</h4>
                <p className="text-sm text-muted-foreground">
                  Enter a device ID (ECU) to see all parameters it supports. Useful for finding what data you can read from a specific module.
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2">Parameter → Devices</h4>
                <p className="text-sm text-muted-foreground">
                  Enter a parameter ID to see which ECUs support it. Useful for cross-module compatibility checking.
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>💡 Tip:</strong> This tool searches 15,393 device-parameter mappings from the SRT Lab database, 
                  covering all Chrysler/FCA/Stellantis modules.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
