import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Search, Gauge, Flame, Wind, Droplet, Zap } from "lucide-react";

export default function DieselEngineDashboard() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: dieselData, isLoading } = trpc.alphaOBD.getDieselParameters.useQuery({
    search: searchQuery || undefined,
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "injection": return <Droplet className="h-4 w-4" />;
      case "turbo": return <Wind className="h-4 w-4" />;
      case "emissions": return <Flame className="h-4 w-4" />;
      case "fuel": return <Gauge className="h-4 w-4" />;
      default: return <Zap className="h-4 w-4" />;
    }
  };

  const renderParameterTable = (params: any[], title: string) => (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{params.length} parameters</CardDescription>
      </CardHeader>
      <CardContent>
        {params.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Request</TableHead>
                  <TableHead>Parameter</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead>Range</TableHead>
                  <TableHead>Formula</TableHead>
                  <TableHead>Unit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {params.slice(0, 50).map((param: any, idx: number) => (
                  <TableRow key={idx}>
                    <TableCell className="font-mono text-xs">{param.request || 'N/A'}</TableCell>
                    <TableCell className="font-medium">{param.response_name || 'Unknown'}</TableCell>
                    <TableCell className="text-xs">{param.group_name || 'N/A'}</TableCell>
                    <TableCell className="text-xs">
                      {param.lower_level && param.upper_level
                        ? `${param.lower_level} - ${param.upper_level}`
                        : 'N/A'}
                    </TableCell>
                    <TableCell className="text-xs font-mono">
                      {param.slope && param.offset
                        ? `x * ${param.slope} + ${param.offset}`
                        : 'N/A'}
                    </TableCell>
                    <TableCell>{param.unit_name || param.unit || 'N/A'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {params.length > 50 && (
              <p className="text-sm text-muted-foreground text-center mt-4">
                Showing first 50 of {params.length} parameters
              </p>
            )}
          </div>
        ) : (
          <p className="text-center py-8 text-muted-foreground">No parameters in this category</p>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Diesel Engine Dashboard</h1>
        <p className="text-muted-foreground">
          Monitor 4,596 diesel-specific parameters (injection, turbo, emissions, fuel)
        </p>
      </div>

      {/* Search */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search parameters..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {isLoading && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Loading diesel parameters...
          </CardContent>
        </Card>
      )}

      {!isLoading && dieselData && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-5">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total</CardTitle>
                <Gauge className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dieselData.total_parameters}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Injection</CardTitle>
                <Droplet className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dieselData.categorized?.injection?.length || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Turbo</CardTitle>
                <Wind className="h-4 w-4 text-cyan-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dieselData.categorized?.turbo?.length || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Emissions</CardTitle>
                <Flame className="h-4 w-4 text-orange-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dieselData.categorized?.emissions?.length || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Fuel</CardTitle>
                <Gauge className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dieselData.categorized?.fuel?.length || 0}</div>
              </CardContent>
            </Card>
          </div>

          {/* Parameter Categories */}
          <Tabs defaultValue="injection" className="w-full">
            <TabsList>
              <TabsTrigger value="injection">
                <Droplet className="h-4 w-4 mr-2" />
                Injection ({dieselData.categorized?.injection?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="turbo">
                <Wind className="h-4 w-4 mr-2" />
                Turbo ({dieselData.categorized?.turbo?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="emissions">
                <Flame className="h-4 w-4 mr-2" />
                Emissions ({dieselData.categorized?.emissions?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="fuel">
                <Gauge className="h-4 w-4 mr-2" />
                Fuel ({dieselData.categorized?.fuel?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="all">
                All ({dieselData.total_parameters})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="injection">
              {renderParameterTable(dieselData.categorized?.injection || [], "Injection System Parameters")}
            </TabsContent>

            <TabsContent value="turbo">
              {renderParameterTable(dieselData.categorized?.turbo || [], "Turbocharger Parameters")}
            </TabsContent>

            <TabsContent value="emissions">
              {renderParameterTable(dieselData.categorized?.emissions || [], "Emissions Control Parameters")}
            </TabsContent>

            <TabsContent value="fuel">
              {renderParameterTable(dieselData.categorized?.fuel || [], "Fuel System Parameters")}
            </TabsContent>

            <TabsContent value="all">
              <div className="space-y-4">
                {renderParameterTable(dieselData.static_params || [], "Static Parameters")}
                {renderParameterTable(dieselData.dynamic_params || [], "Dynamic Parameters")}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}
