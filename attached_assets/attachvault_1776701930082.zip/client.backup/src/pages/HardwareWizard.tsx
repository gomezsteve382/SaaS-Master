import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';
import { Usb, Wifi, CheckCircle, XCircle, Loader2, ArrowRight, RefreshCw, History, Trash2 } from 'lucide-react';
import { ConnectionManager } from '@/lib/obd2-protocol';

interface SerialPortInfo {
  name: string;
  vendorId?: string;
  productId?: string;
}

interface DetectedDevice {
  type: 'elm327' | 'j2534' | 'arduino' | 'unknown';
  name: string;
  port?: string;
  baudRate?: number;
  protocol?: string;
}

export default function HardwareWizard() {
  const [step, setStep] = useState(1);
  const [ports, setPorts] = useState<SerialPortInfo[]>([]);
  const [selectedPort, setSelectedPort] = useState<string>('');
  const [detectedDevices, setDetectedDevices] = useState<DetectedDevice[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'connecting' | 'connected' | 'failed'>('idle');
  const [testResult, setTestResult] = useState<string>('');
  const [connMgr] = useState(() => new ConnectionManager());
  const [savedSettings, setSavedSettings] = useState(() => connMgr.getSavedSettings());

  const clearSavedSettings = () => {
    connMgr.clearSavedSettings();
    setSavedSettings(null);
    toast.success('Saved settings cleared');
  };

  // Step 1: Detect serial ports
  const scanSerialPorts = async () => {
    setIsScanning(true);
    toast.info('Scanning for serial ports...');

    try {
      // Check if WebSerial API is available
      if (!('serial' in navigator)) {
        throw new Error('WebSerial API not supported. Please use Chrome/Edge browser.');
      }

      // Request port access
      const port = await (navigator as any).serial.requestPort();
      
      // Get port info
      const info = port.getInfo();
      const portInfo: SerialPortInfo = {
        name: `USB Serial Device (VID: ${info.usbVendorId?.toString(16) || 'unknown'}, PID: ${info.usbProductId?.toString(16) || 'unknown'})`,
        vendorId: info.usbVendorId?.toString(16),
        productId: info.usbProductId?.toString(16),
      };

      setPorts([portInfo]);
      setSelectedPort(portInfo.name);
      toast.success('Serial port detected!');
      
      // Auto-advance to step 2
      setStep(2);
      
      // Auto-detect device type
      await detectDeviceType(port);

    } catch (error: any) {
      if (error.message.includes('No port selected')) {
        toast.error('No port selected. Please select a device.');
      } else {
        toast.error(`Failed to scan ports: ${error.message}`);
      }
    } finally {
      setIsScanning(false);
    }
  };

  // Step 2: Detect device type
  const detectDeviceType = async (port: any) => {
    setIsScanning(true);
    toast.info('Detecting device type...');

    const baudRates = [38400, 115200, 9600, 57600, 230400];
    const detected: DetectedDevice[] = [];

    for (const baudRate of baudRates) {
      try {
        // Open port
        await port.open({ baudRate });
        
        // Send AT command to test ELM327
        const writer = port.writable.getWriter();
        const reader = port.readable.getReader();
        
        // Send ATZ (reset)
        const encoder = new TextEncoder();
        await writer.write(encoder.encode('ATZ\r'));
        writer.releaseLock();

        // Read response
        const { value, done } = await reader.read();
        reader.releaseLock();

        if (!done && value) {
          const decoder = new TextDecoder();
          const response = decoder.decode(value);
          
          if (response.includes('ELM327') || response.includes('OBDLink')) {
            detected.push({
              type: 'elm327',
              name: response.includes('OBDLink') ? 'OBDLink EX' : 'ELM327 Compatible',
              port: selectedPort,
              baudRate,
              protocol: 'ISO 15765-4 (CAN)',
            });
            
            toast.success(`Detected: ${detected[0].name} at ${baudRate} baud`);
            break;
          }
        }

        await port.close();
        
      } catch (error) {
        // Try next baud rate
        try {
          await port.close();
        } catch (e) {
          // Port already closed
        }
      }
    }

    if (detected.length === 0) {
      // Assume Arduino CAN bridge if no ELM327 response
      detected.push({
        type: 'arduino',
        name: 'Arduino CAN Bridge (assumed)',
        port: selectedPort,
        baudRate: 115200,
        protocol: 'Custom CAN Protocol',
      });
      toast.info('No ELM327 detected, assuming Arduino CAN bridge');
    }

    setDetectedDevices(detected);
    setIsScanning(false);
    setStep(3);
  };

  // Step 3: Test connection
  const testConnection = async () => {
    setConnectionStatus('connecting');
    toast.info('Testing connection...');

    try {
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const connMgr = new ConnectionManager();

      // Connect with detected device
      const device = detectedDevices[0];
      if (!device) {
        throw new Error('No device detected');
      }

      // Request port again
      const port = await (navigator as any).serial.requestPort();
      
      // Connect based on device type
      const hardwareType = device.type === 'elm327' ? 'elm327' : 'arduino';
      const success = await connMgr.connect(hardwareType, port);
      
      if (!success) {
        throw new Error('Failed to establish connection');
      }

      // Test with AT command
      const protocol = connMgr.getProtocol();
      if (protocol) {
        // Try to read VIN as connection test
        try {
          const vinResp = await protocol.sendUDS(0x7E0, 0x7E8, [0x22, 0xF1, 0x90], 5);
          if (vinResp && vinResp.length > 3) {
            const vin = new TextDecoder().decode(vinResp.slice(3));
            setTestResult(`Connection successful! VIN: ${vin}`);
            setConnectionStatus('connected');
            toast.success('Hardware connected successfully!');
          } else {
            setTestResult('Connection established, but no response from ECM');
            setConnectionStatus('connected');
            toast.success('Hardware connected (no vehicle detected)');
          }
        } catch (e) {
          setTestResult('Connection established, but vehicle may not be connected');
          setConnectionStatus('connected');
          toast.success('Hardware connected (no vehicle response)');
        }
      }

    } catch (error: any) {
      setConnectionStatus('failed');
      setTestResult(`Connection failed: ${error.message}`);
      toast.error(`Connection failed: ${error.message}`);
    }
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold tracking-tight">Hardware Connection Wizard</h1>
        <p className="text-muted-foreground mt-2">
          Automatically detect and configure OBD2 adapters
        </p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center gap-4 mb-8">
        <div className={`flex items-center gap-2 ${step >= 1 ? 'text-primary' : 'text-muted-foreground'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
            1
          </div>
          <span className="font-medium">Detect Ports</span>
        </div>
        <ArrowRight className="text-muted-foreground" />
        <div className={`flex items-center gap-2 ${step >= 2 ? 'text-primary' : 'text-muted-foreground'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
            2
          </div>
          <span className="font-medium">Identify Device</span>
        </div>
        <ArrowRight className="text-muted-foreground" />
        <div className={`flex items-center gap-2 ${step >= 3 ? 'text-primary' : 'text-muted-foreground'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
            3
          </div>
          <span className="font-medium">Test Connection</span>
        </div>
      </div>

      {/* Saved Settings */}
      {savedSettings && (
        <Alert className="bg-blue-50 border-blue-200">
          <History className="h-4 w-4 text-blue-600" />
          <AlertDescription className="flex items-center justify-between">
            <div>
              <span className="font-medium text-blue-900">Last connected: </span>
              <span className="text-blue-700">
                {savedSettings.hardwareType.toUpperCase()} @ {savedSettings.baudRate} baud
              </span>
              <span className="text-sm text-blue-600 ml-2">
                ({new Date(savedSettings.lastConnected).toLocaleString()})
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearSavedSettings}
              className="text-blue-600 hover:text-blue-800 hover:bg-blue-100"
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Clear
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Step 1: Scan Ports */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Usb className="w-5 h-5" />
              Step 1: Detect Serial Ports
            </CardTitle>
            <CardDescription>
              Connect your OBDLink EX, ELM327, or Arduino CAN adapter via USB
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertDescription>
                <strong>Before scanning:</strong> Make sure your OBD2 adapter is plugged into your computer's USB port.
                This wizard works with OBDLink EX, generic ELM327 adapters, and custom Arduino CAN bridges.
              </AlertDescription>
            </Alert>

            <Button 
              onClick={scanSerialPorts} 
              disabled={isScanning}
              className="w-full"
              size="lg"
            >
              {isScanning ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Scan for Devices
                </>
              )}
            </Button>

            {ports.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium">Detected Ports:</p>
                {ports.map((port, idx) => (
                  <div key={idx} className="p-3 border rounded-md">
                    <p className="font-mono text-sm">{port.name}</p>
                    {port.vendorId && (
                      <p className="text-xs text-muted-foreground">
                        Vendor: 0x{port.vendorId} | Product: 0x{port.productId}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 2: Device Detection */}
      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wifi className="w-5 h-5" />
              Step 2: Identifying Device
            </CardTitle>
            <CardDescription>
              Testing communication protocols to identify your adapter
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isScanning ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <span className="ml-3">Testing baud rates...</span>
              </div>
            ) : detectedDevices.length > 0 ? (
              <div className="space-y-4">
                {detectedDevices.map((device, idx) => (
                  <div key={idx} className="p-4 border rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-lg">{device.name}</h3>
                      <Badge variant="outline">{device.type.toUpperCase()}</Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Port:</span>
                        <span className="ml-2 font-mono">{device.port}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Baud Rate:</span>
                        <span className="ml-2 font-mono">{device.baudRate}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-muted-foreground">Protocol:</span>
                        <span className="ml-2">{device.protocol}</span>
                      </div>
                    </div>
                  </div>
                ))}
                <Button onClick={() => setStep(3)} className="w-full" size="lg">
                  Continue to Connection Test
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}

      {/* Step 3: Test Connection */}
      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {connectionStatus === 'connected' ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : connectionStatus === 'failed' ? (
                <XCircle className="w-5 h-5 text-red-500" />
              ) : (
                <Loader2 className="w-5 h-5" />
              )}
              Step 3: Test Connection
            </CardTitle>
            <CardDescription>
              Verify communication with your vehicle
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {connectionStatus === 'idle' && (
              <>
                <Alert>
                  <AlertDescription>
                    <strong>Ready to test:</strong> Make sure your adapter is plugged into the vehicle's OBD2 port
                    and the ignition is ON (engine can be off).
                  </AlertDescription>
                </Alert>
                <Button onClick={testConnection} className="w-full" size="lg">
                  Test Connection
                </Button>
              </>
            )}

            {connectionStatus === 'connecting' && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <span className="ml-3">Connecting to vehicle...</span>
              </div>
            )}

            {connectionStatus === 'connected' && (
              <div className="space-y-4">
                <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <AlertDescription className="text-green-700 dark:text-green-300">
                    {testResult}
                  </AlertDescription>
                </Alert>
                <Button onClick={() => window.location.href = '/'} className="w-full" size="lg">
                  Start Using Tools
                </Button>
              </div>
            )}

            {connectionStatus === 'failed' && (
              <div className="space-y-4">
                <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
                  <XCircle className="w-4 h-4 text-red-500" />
                  <AlertDescription className="text-red-700 dark:text-red-300">
                    {testResult}
                  </AlertDescription>
                </Alert>
                <div className="flex gap-2">
                  <Button onClick={() => setStep(1)} variant="outline" className="flex-1">
                    Start Over
                  </Button>
                  <Button onClick={testConnection} className="flex-1">
                    Retry
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
