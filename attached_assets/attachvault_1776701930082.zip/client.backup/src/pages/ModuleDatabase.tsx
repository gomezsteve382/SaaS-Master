import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { BackButton } from "@/components/BackButton";
import { ArrowLeft, Database, Search, CheckCircle2, AlertTriangle, Shield } from "lucide-react";
import { Link } from "wouter";
import { MODULE_DATABASE, getVerifiedModules, getOTPModules } from "@shared/module-database";
import masterDatabase from "@/../../shared/master-module-database.json";

export default function ModuleDatabase() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "verified" | "otp">("all");

  const modules = Object.values(MODULE_DATABASE);
  const filteredModules = modules.filter((module) => {
    const matchesSearch = module.code.toLowerCase().includes(search.toLowerCase()) ||
      module.name.toLowerCase().includes(search.toLowerCase());
    
    if (filter === "verified") return matchesSearch && module.verified;
    if (filter === "otp") return matchesSearch && module.protectionLevel === "otp";
    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-gray-900 to-red-950 text-white py-8">
        <div className="container">
          <BackButton />
      <Link href="/">
            <Button variant="ghost" className="text-white hover:text-red-500 mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Tools
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <Database className="w-12 h-12 text-red-500" />
            <div>
              <h1 className="text-4xl font-black uppercase tracking-tight">Module Database</h1>
              <p className="text-gray-300 mt-1">{masterDatabase.metadata.total_modules}+ verified Chrysler/Dodge modules from {masterDatabase.metadata.sources.join(", ")}</p>
            </div>
          </div>
        </div>
        <div className="red-divider mt-6"></div>
      </div>

      <div className="container py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="aggressive-card">
            <CardContent className="pt-6">
              <div className="text-3xl font-black text-red-600">{modules.length}</div>
              <div className="text-sm text-muted-foreground mt-1">Total Modules</div>
            </CardContent>
          </Card>
          <Card className="aggressive-card">
            <CardContent className="pt-6">
              <div className="text-3xl font-black text-green-600">{getVerifiedModules().length}</div>
              <div className="text-sm text-muted-foreground mt-1">Verified</div>
            </CardContent>
          </Card>
          <Card className="aggressive-card">
            <CardContent className="pt-6">
              <div className="text-3xl font-black text-orange-600">{getOTPModules().length}</div>
              <div className="text-sm text-muted-foreground mt-1">OTP Protected</div>
            </CardContent>
          </Card>
          <Card className="aggressive-card">
            <CardContent className="pt-6">
              <div className="text-3xl font-black text-blue-600">
                {modules.filter(m => m.bus === 'CAN-C').length}
              </div>
              <div className="text-sm text-muted-foreground mt-1">CAN-C Bus</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by code or name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
            >
              All
            </Button>
            <Button
              variant={filter === "verified" ? "default" : "outline"}
              onClick={() => setFilter("verified")}
            >
              Verified
            </Button>
            <Button
              variant={filter === "otp" ? "default" : "outline"}
              onClick={() => setFilter("otp")}
            >
              OTP Only
            </Button>
          </div>
        </div>

        {/* Module Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredModules.map((module) => (
            <Card key={module.code} className="aggressive-card relative">
              {module.protectionLevel === "otp" && (
                <div className="absolute top-4 right-4">
                  <Badge variant="destructive" className="animate-pulse">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    OTP
                  </Badge>
                </div>
              )}
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <CardTitle className="text-xl font-bold">{module.code}</CardTitle>
                    <CardDescription className="mt-1">{module.name}</CardDescription>
                  </div>
                </div>
                {module.verified && (
                  <Badge variant="outline" className="w-fit border-green-600 text-green-600">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">{module.description}</p>
                
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-muted-foreground">TX Address</p>
                    <p className="font-mono font-bold">0x{module.tx.toString(16).toUpperCase()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">RX Address</p>
                    <p className="font-mono font-bold">0x{module.rx.toString(16).toUpperCase()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Bus</p>
                    <Badge variant="outline">{module.bus}</Badge>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Source</p>
                    <p className="text-xs">{module.source}</p>
                  </div>
                </div>

                {module.otpInfo && (
                  <Alert className="border-red-600 bg-red-50">
                    <Shield className="w-4 h-4 text-red-600" />
                    <AlertDescription className="text-xs">
                      {module.otpInfo.warningMessage}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredModules.length === 0 && (
          <div className="text-center py-12">
            <Database className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-bold">No modules found</p>
            <p className="text-muted-foreground">Try adjusting your search or filter</p>
          </div>
        )}
      </div>
    </div>
  );
}
