import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { 
  Save, 
  RotateCcw, 
  Trash2, 
  Download, 
  Upload, 
  GitCompare,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Info
} from 'lucide-react';
import { trpc } from '@/lib/trpc';

export default function ModuleBackupRestore() {
  const [selectedModule, setSelectedModule] = useState('BCM');
  const [searchQuery, setSearchQuery] = useState('');
  const [compareMode, setCompareMode] = useState(false);
  const [selectedBackup1, setSelectedBackup1] = useState<string | null>(null);
  const [selectedBackup2, setSelectedBackup2] = useState<string | null>(null);
  const [backupNotes, setBackupNotes] = useState('');

  const { data: backupsData, refetch: refetchBackups } = trpc.moduleBackup.listBackups.useQuery({
    moduleName: searchQuery || undefined,
  });

  const createBackupMutation = trpc.moduleBackup.createBackup.useMutation({
    onSuccess: () => {
      refetchBackups();
      setBackupNotes('');
    },
  });

  const restoreBackupMutation = trpc.moduleBackup.restoreBackup.useMutation({
    onSuccess: () => {
      refetchBackups();
    },
  });

  const deleteBackupMutation = trpc.moduleBackup.deleteBackup.useMutation({
    onSuccess: () => {
      refetchBackups();
    },
  });

  const { data: compareData } = trpc.moduleBackup.compareBackups.useQuery({
    backupId1: selectedBackup1 || '',
    backupId2: selectedBackup2 || '',
  }, {
    enabled: !!selectedBackup1 && !!selectedBackup2,
  });

  const { data: exportData } = trpc.moduleBackup.exportBackup.useQuery({
    backupId: selectedBackup1 || '',
  }, {
    enabled: !!selectedBackup1 && !compareMode,
  });

  const handleCreateBackup = () => {
    createBackupMutation.mutate({
      moduleId: selectedModule.toLowerCase(),
      moduleName: selectedModule,
      notes: backupNotes || undefined,
    });
  };

  const handleRestoreBackup = (backupId: string) => {
    if (confirm('Are you sure you want to restore this backup? This will overwrite the current module configuration.')) {
      restoreBackupMutation.mutate({ backupId });
    }
  };

  const handleDeleteBackup = (backupId: string) => {
    if (confirm('Are you sure you want to delete this backup? This action cannot be undone.')) {
      deleteBackupMutation.mutate({ backupId });
    }
  };

  const handleExportBackup = () => {
    if (exportData?.data) {
      const blob = new Blob([exportData.data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `module_backup_${selectedBackup1}_${Date.now()}.json`;
      a.click();
    }
  };

  const backups = backupsData?.backups || [];

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
          Module Configuration Backup & Restore
        </h1>
        <p className="text-muted-foreground mt-2">
          Backup and restore complete module configurations with one-click restore capability
        </p>
      </div>

      {/* Create Backup */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Create New Backup</h2>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="module">Select Module</Label>
              <Select value={selectedModule} onValueChange={setSelectedModule}>
                <SelectTrigger id="module">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BCM">BCM - Body Control Module</SelectItem>
                  <SelectItem value="RFHUB">RFHUB - SmartBox (Immobilizer)</SelectItem>
                  <SelectItem value="ECM">ECM - Engine Control Module</SelectItem>
                  <SelectItem value="TCM">TCM - Transmission Control Module</SelectItem>
                  <SelectItem value="ABS">ABS - Anti-lock Braking System</SelectItem>
                  <SelectItem value="IPC">IPC - Instrument Panel Cluster</SelectItem>
                  <SelectItem value="ACM">ACM - Airbag Control Module</SelectItem>
                  <SelectItem value="RADIO">RADIO - Uconnect/Infotainment</SelectItem>
                  <SelectItem value="CGW">CGW - Central Gateway</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Input
                id="notes"
                value={backupNotes}
                onChange={(e) => setBackupNotes(e.target.value)}
                placeholder="Before VIN programming, pre-modification, etc."
              />
            </div>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Backup includes:</strong> Original VIN, Current VIN, Security Bytes, Feature Bytes, Calibration Data, Checksums
            </AlertDescription>
          </Alert>

          <Button
            onClick={handleCreateBackup}
            disabled={createBackupMutation.isPending}
            size="lg"
            className="w-full"
          >
            <Save className="mr-2 h-5 w-5" />
            {createBackupMutation.isPending ? 'Creating Backup...' : 'Create Backup'}
          </Button>

          {createBackupMutation.isSuccess && (
            <Alert className="border-green-500 bg-green-500/10">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              <AlertDescription className="text-green-500">
                {createBackupMutation.data.message}
              </AlertDescription>
            </Alert>
          )}
        </div>
      </Card>

      {/* Search & Filter */}
      <Card className="p-4">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search backups by module name..."
              className="pl-10"
            />
          </div>

          <Button
            variant={compareMode ? 'default' : 'outline'}
            onClick={() => {
              setCompareMode(!compareMode);
              setSelectedBackup1(null);
              setSelectedBackup2(null);
            }}
          >
            <GitCompare className="mr-2 h-4 w-4" />
            {compareMode ? 'Exit Compare Mode' : 'Compare Backups'}
          </Button>
        </div>
      </Card>

      {/* Backup History */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">
          Backup History ({backups.length} backups)
        </h2>

        {backups.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Save className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No backups found. Create your first backup above.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {backups.map((backup) => (
              <div
                key={backup.id}
                className={`p-4 border-2 rounded-lg transition-all ${
                  compareMode
                    ? selectedBackup1 === backup.id || selectedBackup2 === backup.id
                      ? 'border-blue-500 bg-blue-500/10'
                      : 'border-border hover:border-blue-300'
                    : 'border-border hover:border-green-300'
                }`}
                onClick={() => {
                  if (compareMode) {
                    if (!selectedBackup1) {
                      setSelectedBackup1(backup.id);
                    } else if (!selectedBackup2 && backup.id !== selectedBackup1) {
                      setSelectedBackup2(backup.id);
                    } else {
                      setSelectedBackup1(backup.id);
                      setSelectedBackup2(null);
                    }
                  } else {
                    setSelectedBackup1(backup.id);
                  }
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold">{backup.moduleName}</h3>
                      <Badge>{backup.moduleId}</Badge>
                      {compareMode && selectedBackup1 === backup.id && (
                        <Badge className="bg-blue-500">Backup 1</Badge>
                      )}
                      {compareMode && selectedBackup2 === backup.id && (
                        <Badge className="bg-purple-500">Backup 2</Badge>
                      )}
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm mb-2">
                      <div>
                        <span className="text-muted-foreground">Original VIN:</span>
                        <p className="font-mono">{backup.originalVIN || 'N/A'}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Current VIN:</span>
                        <p className="font-mono">{backup.currentVIN || 'N/A'}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Security Bytes:</span>
                        <p className="font-mono text-xs">{backup.securityBytes || 'N/A'}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Checksums:</span>
                        <p className="font-mono text-xs">{backup.checksums || 'N/A'}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(backup.timestamp).toLocaleString()}
                      </span>
                      {backup.notes && (
                        <span>Notes: {backup.notes}</span>
                      )}
                    </div>
                  </div>

                  {!compareMode && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRestoreBackup(backup.id);
                        }}
                        disabled={restoreBackupMutation.isPending}
                      >
                        <RotateCcw className="mr-1 h-4 w-4" />
                        Restore
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedBackup1(backup.id);
                          handleExportBackup();
                        }}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteBackup(backup.id);
                        }}
                        disabled={deleteBackupMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Compare Results */}
      {compareMode && selectedBackup1 && selectedBackup2 && compareData && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Comparison Results</h2>
          <div className="space-y-3">
            {compareData.differences.map((diff, index) => (
              <div
                key={index}
                className={`p-4 border-2 rounded-lg ${
                  diff.changed ? 'border-yellow-500 bg-yellow-500/10' : 'border-border'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold">{diff.field}</h3>
                  {diff.changed ? (
                    <Badge className="bg-yellow-500">CHANGED</Badge>
                  ) : (
                    <Badge className="bg-green-500">SAME</Badge>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Backup 1:</span>
                    <p className="font-mono">{diff.backup1Value || 'N/A'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Backup 2:</span>
                    <p className="font-mono">{diff.backup2Value || 'N/A'}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Restore Status */}
      {restoreBackupMutation.isSuccess && (
        <Alert className="border-green-500 bg-green-500/10">
          <CheckCircle2 className="h-4 w-4 text-green-500" />
          <AlertDescription className="text-green-500">
            {restoreBackupMutation.data.message}
          </AlertDescription>
        </Alert>
      )}

      {restoreBackupMutation.isError && (
        <Alert className="border-red-500 bg-red-500/10">
          <XCircle className="h-4 w-4 text-red-500" />
          <AlertDescription className="text-red-500">
            Restore failed. Please try again.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
