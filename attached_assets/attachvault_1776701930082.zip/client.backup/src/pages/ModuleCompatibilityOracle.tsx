import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, GitCompare } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BackButton } from "@/components/BackButton";

export default function ModuleCompatibilityOracle() {
  const [sourceVehicle, setSourceVehicle] = useState('');
  const [targetVehicle, setTargetVehicle] = useState('');
  const [moduleType, setModuleType] = useState('BCM');
  const [partNumber, setPartNumber] = useState('');
  const [compatibility, setCompatibility] = useState('');

  const checkMutation = trpc.ai.checkModuleCompatibility.useMutation();

  const handleCheck = async () => {
    if (!sourceVehicle || !targetVehicle) {
      alert('Please provide source and target vehicle information');
      return;
    }

    try {
      const response = await checkMutation.mutateAsync({
        sourceVehicle,
        targetVehicle,
        moduleType,
        partNumber: partNumber || undefined
      });
      setCompatibility(typeof response.compatibility === 'string' ? response.compatibility : JSON.stringify(response.compatibility));
    } catch (error) {
      console.error('Compatibility check failed:', error);
      alert('Compatibility check failed. Please try again.');
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <GitCompare className="w-10 h-10 text-primary" />
          Module Compatibility Oracle
        </h1>
        <p className="text-muted-foreground">
          AI-powered module compatibility checker. Verify if modules can be swapped between vehicles.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Enter source and target vehicle info. The AI analyzes hardware compatibility, 
          software versions, CAN bus protocols, and feature differences. Provides compatibility assessment with 
          required programming procedures.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Compatibility Check</CardTitle>
            <CardDescription>Compare module compatibility between vehicles</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="source-vehicle">Source Vehicle (Donor) *</Label>
              <Input
                id="source-vehicle"
                value={sourceVehicle}
                onChange={(e) => setSourceVehicle(e.target.value)}
                placeholder="2015 Dodge Charger R/T 5.7L"
              />
            </div>

            <div>
              <Label htmlFor="target-vehicle">Target Vehicle (Recipient) *</Label>
              <Input
                id="target-vehicle"
                value={targetVehicle}
                onChange={(e) => setTargetVehicle(e.target.value)}
                placeholder="2017 Dodge Charger SXT 3.6L"
              />
            </div>

            <div>
              <Label htmlFor="module-type">Module Type *</Label>
              <Select value={moduleType} onValueChange={setModuleType}>
                <SelectTrigger id="module-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                  <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                  <SelectItem value="PCM">PCM (Powertrain Control Module)</SelectItem>
                  <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                  <SelectItem value="RFHUB">RFHUB (SmartBox)</SelectItem>
                  <SelectItem value="SKIM">SKIM (Security Module)</SelectItem>
                  <SelectItem value="ABS">ABS (Anti-lock Braking)</SelectItem>
                  <SelectItem value="AIRBAG">Airbag Control Module</SelectItem>
                  <SelectItem value="IPC">IPC (Instrument Cluster)</SelectItem>
                  <SelectItem value="HVAC">HVAC Control Module</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="part-number">Part Number (Optional)</Label>
              <Input
                id="part-number"
                value={partNumber}
                onChange={(e) => setPartNumber(e.target.value.toUpperCase())}
                placeholder="68105502AC, 05150818AB"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Mopar part number from module label
              </p>
            </div>

            <Button 
              onClick={handleCheck} 
              disabled={checkMutation.isPending || !sourceVehicle || !targetVehicle}
              className="w-full"
            >
              {checkMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <GitCompare className="w-4 h-4 mr-2" />
                  Check Compatibility
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Compatibility Report</CardTitle>
            <CardDescription>AI analysis of module interchange</CardDescription>
          </CardHeader>
          <CardContent>
            {compatibility ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{compatibility}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <GitCompare className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Enter vehicle info to check compatibility</p>
                <p className="text-xs mt-2">
                  Verify module interchange feasibility
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Compatibility Factors */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Compatibility Factors Analyzed</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <h3 className="font-semibold mb-2">🔌 Hardware</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Connector type and pinout</li>
                <li>• Physical mounting</li>
                <li>• Power requirements</li>
                <li>• CAN bus topology</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">💾 Software</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Firmware version</li>
                <li>• Calibration compatibility</li>
                <li>• Feature set differences</li>
                <li>• Programming requirements</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🔐 Security</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• SKIM pairing</li>
                <li>• VIN synchronization</li>
                <li>• Security byte transfer</li>
                <li>• Immobilizer compatibility</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Common Swaps */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Common Module Swaps</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="font-semibold mb-2 text-green-600">✅ Usually Compatible</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Same generation BCM (2015-2017 LD)</li>
                <li>• Same engine ECM (5.7L HEMI variants)</li>
                <li>• Same transmission TCM (ZF8HP)</li>
                <li>• IPC within same body style</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-red-600">❌ Usually Incompatible</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Cross-generation modules (LD → LC)</li>
                <li>• Different engine families (HEMI → Pentastar)</li>
                <li>• Different transmission types (62TE → ZF8HP)</li>
                <li>• Pre-2018 → 2018+ (SecurityGateway)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
