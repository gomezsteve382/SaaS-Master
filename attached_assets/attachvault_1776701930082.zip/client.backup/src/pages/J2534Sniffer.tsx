import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { BackButton } from "@/components/BackButton";
import { 
  ArrowLeft, Download, Loader2, Radio, Trash2, Eye, EyeOff,
  Play, Square, RefreshCw, Wifi, Cpu, AlertCircle
} from "lucide-react";
import { J2534Protocol, J2534Frame } from "@shared/j2534-protocol";
import { cn } from "@/lib/utils";

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'sniffing' | 'error';

interface FrameWithAnalysis extends J2534Frame {
  type?: string;
  description?: string;
}

export default function J2534Sniffer() {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [protocol, setProtocol] = useState<J2534Protocol | null>(null);
  const [frames, setFrames] = useState<FrameWithAnalysis[]>([]);
  const [frameCount, setFrameCount] = useState(0);
  
  const [bridgeUrl, setBridgeUrl] = useState('ws://localhost:8766');
  const [baudrate, setBaudrate] = useState(500000);
  const [showOnlyUDS, setShowOnlyUDS] = useState(false);
  const [autoscroll, setAutoscroll] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const maxFrames = 500;

  useEffect(() => {
    if (autoscroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [frames, autoscroll]);

  const analyzeFrame = (frame: J2534Frame): FrameWithAnalysis => {
    const analyzed: FrameWithAnalysis = { ...frame };
    
    // Check if this is a UDS frame (typically 7DF-7E8 range or module-specific)
    if (frame.data.length > 0) {
      const service = frame.data[0];
      
      // UDS Services
      if (service === 0x10) {
        analyzed.type = 'UDS';
        analyzed.description = 'Diagnostic Session Control';
      } else if (service === 0x27) {
        analyzed.type = 'UDS';
        analyzed.description = frame.data.length > 1 && (frame.data[1] % 2 === 0) 
          ? 'Security Access - Send Key' 
          : 'Security Access - Request Seed';
      } else if (service === 0x22) {
        analyzed.type = 'UDS';
        analyzed.description = 'Read Data By Identifier';
      } else if (service === 0x2E) {
        analyzed.type = 'UDS';
        analyzed.description = 'Write Data By Identifier';
      } else if (service === 0x19) {
        analyzed.type = 'UDS';
        analyzed.description = 'Read DTC Information';
      } else if (service === 0x14) {
        analyzed.type = 'UDS';
        analyzed.description = 'Clear DTC Information';
      } else if (service === 0x11) {
        analyzed.type = 'UDS';
        analyzed.description = 'ECU Reset';
      } else if (service === 0x3E) {
        analyzed.type = 'UDS';
        analyzed.description = 'Tester Present';
      } else if (service === 0x31) {
        analyzed.type = 'UDS';
        analyzed.description = 'Routine Control';
      } else if (service === 0x34 || service === 0x35 || service === 0x36 || service === 0x37) {
        analyzed.type = 'UDS';
        analyzed.description = 'Flash Programming';
      } else if (service >= 0x50 && service <= 0x7F) {
        analyzed.type = 'UDS';
        analyzed.description = 'Positive Response';
      } else if (service === 0x7F) {
        analyzed.type = 'UDS';
        analyzed.description = 'Negative Response';
      }
    }
    
    return analyzed;
  };

  const handleConnect = async () => {
    setConnectionStatus('connecting');
    setErrorMessage('');
    
    try {
      const j2534 = new J2534Protocol({
        bridgeUrl,
        baudrate
      });
      
      j2534.onStatus((status, message) => {
        if (status === 'connected') {
          setConnectionStatus('connected');
        } else if (status === 'sniffing') {
          setConnectionStatus('sniffing');
        } else if (status === 'stopped') {
          setConnectionStatus('connected');
        } else if (status === 'disconnected') {
          setConnectionStatus('disconnected');
          setProtocol(null);
        } else if (status === 'error') {
          setConnectionStatus('error');
          setErrorMessage(message || 'Unknown error');
        }
      });
      
      await j2534.connect();
      setProtocol(j2534);
      
    } catch (error) {
      console.error('[J2534] Connection error:', error);
      setConnectionStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Failed to connect');
    }
  };

  const handleDisconnect = async () => {
    if (protocol) {
      await protocol.disconnect();
      setProtocol(null);
      setConnectionStatus('disconnected');
    }
  };

  const handleStartSniffing = async () => {
    if (!protocol) return;
    
    try {
      await protocol.startSniffing((frame) => {
        const analyzed = analyzeFrame(frame);
        
        setFrames(prev => {
          const updated = [...prev, analyzed];
          if (updated.length > maxFrames) {
            return updated.slice(-maxFrames);
          }
          return updated;
        });
        
        setFrameCount(prev => prev + 1);
      });
    } catch (error) {
      console.error('[J2534] Start sniffing error:', error);
      setErrorMessage(error instanceof Error ? error.message : 'Failed to start sniffing');
    }
  };

  const handleStopSniffing = async () => {
    if (!protocol) return;
    
    try {
      await protocol.stopSniffing();
    } catch (error) {
      console.error('[J2534] Stop sniffing error:', error);
    }
  };

  const handleClearFrames = () => {
    setFrames([]);
    setFrameCount(0);
  };

  const handleExport = () => {
    const data = JSON.stringify(frames, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `j2534-capture-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredFrames = showOnlyUDS 
    ? frames.filter(f => f.type === 'UDS')
    : frames;

  const getFrameColor = (frame: FrameWithAnalysis): string => {
    if (frame.type === 'UDS') {
      if (frame.description?.includes('Security Access')) {
        return 'text-red-600 font-semibold';
      }
      if (frame.description?.includes('Write')) {
        return 'text-orange-600';
      }
      if (frame.description?.includes('Read')) {
        return 'text-blue-600';
      }
      return 'text-purple-600';
    }
    return 'text-gray-600';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b-4 border-red-600">
        <div className="container mx-auto py-6">
          <BackButton />
      <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-3xl font-black tracking-tight">J2534 CAN SNIFFER</h1>
                <p className="text-sm text-gray-600 mt-1">Professional-Grade Passive Monitoring</p>
              </div>
            </div>
            <Badge variant="outline" className="text-lg px-4 py-2">
              <Cpu className="h-4 w-4 mr-2" />
              J2534 PASSTHRU
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        {/* Connection Card */}
        <Card className="mb-6 border-l-4 border-l-red-600">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wifi className="h-5 w-5" />
              J2534 Bridge Connection
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Bridge URL */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="bridgeUrl">Bridge WebSocket URL</Label>
                <Input
                  id="bridgeUrl"
                  value={bridgeUrl}
                  onChange={(e) => setBridgeUrl(e.target.value)}
                  disabled={connectionStatus !== 'disconnected'}
                  placeholder="ws://localhost:8766"
                />
              </div>
              <div>
                <Label htmlFor="baudrate">CAN Bus Speed</Label>
                <Select 
                  value={baudrate.toString()} 
                  onValueChange={(v) => setBaudrate(parseInt(v))}
                  disabled={connectionStatus !== 'disconnected'}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="500000">500 kbps (CAN-C)</SelectItem>
                    <SelectItem value="125000">125 kbps (CAN-IHS)</SelectItem>
                    <SelectItem value="250000">250 kbps</SelectItem>
                    <SelectItem value="83333">83.3 kbps</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Radio className={cn(
                  "h-4 w-4",
                  connectionStatus === 'connected' || connectionStatus === 'sniffing' ? "text-green-600 animate-pulse" : "text-gray-400"
                )} />
                <span className="text-sm font-medium">
                  {connectionStatus === 'disconnected' && 'Disconnected'}
                  {connectionStatus === 'connecting' && 'Connecting...'}
                  {connectionStatus === 'connected' && 'Connected'}
                  {connectionStatus === 'sniffing' && 'Sniffing Active'}
                  {connectionStatus === 'error' && 'Error'}
                </span>
              </div>
              
              <div className="flex gap-2">
                {connectionStatus === 'disconnected' && (
                  <Button onClick={handleConnect}>
                    <Wifi className="h-4 w-4 mr-2" />
                    Connect
                  </Button>
                )}
                {connectionStatus === 'connecting' && (
                  <Button disabled>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Connecting...
                  </Button>
                )}
                {(connectionStatus === 'connected' || connectionStatus === 'sniffing') && (
                  <>
                    {connectionStatus === 'connected' && (
                      <Button onClick={handleStartSniffing}>
                        <Play className="h-4 w-4 mr-2" />
                        Start Sniffing
                      </Button>
                    )}
                    {connectionStatus === 'sniffing' && (
                      <Button onClick={handleStopSniffing} variant="destructive">
                        <Square className="h-4 w-4 mr-2" />
                        Stop Sniffing
                      </Button>
                    )}
                    <Button onClick={handleDisconnect} variant="outline">
                      Disconnect
                    </Button>
                  </>
                )}
              </div>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Connection Error</AlertTitle>
                <AlertDescription>{errorMessage}</AlertDescription>
              </Alert>
            )}

            {/* Instructions */}
            {connectionStatus === 'disconnected' && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Setup Instructions</AlertTitle>
                <AlertDescription>
                  1. Connect your OBDLink EX or Autel J2534 adapter to the vehicle<br />
                  2. Run the J2534 bridge: <code className="bg-gray-100 px-2 py-1 rounded">python3 j2534-bridge.py</code><br />
                  3. Click "Connect" to start monitoring
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Controls */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Switch
                    id="uds-only"
                    checked={showOnlyUDS}
                    onCheckedChange={setShowOnlyUDS}
                  />
                  <Label htmlFor="uds-only">UDS Only</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    id="autoscroll"
                    checked={autoscroll}
                    onCheckedChange={setAutoscroll}
                  />
                  <Label htmlFor="autoscroll">Autoscroll</Label>
                </div>
                <Badge variant="outline">
                  {frameCount.toLocaleString()} frames captured
                </Badge>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleClearFrames} variant="outline" size="sm">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear
                </Button>
                <Button onClick={handleExport} variant="outline" size="sm" disabled={frames.length === 0}>
                  <Download className="h-4 w-4 mr-2" />
                  Export JSON
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Frame List */}
        <Card>
          <CardHeader>
            <CardTitle>Captured Frames</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px]" ref={scrollRef}>
              <div className="space-y-1 font-mono text-xs">
                {filteredFrames.length === 0 && (
                  <div className="text-center text-gray-400 py-8">
                    No frames captured yet. Start sniffing to see CAN traffic.
                  </div>
                )}
                {filteredFrames.map((frame, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "p-2 rounded border",
                      getFrameColor(frame)
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-gray-400">{frame.timestamp.toString().padStart(10, '0')}</span>
                      <span className="font-semibold">{frame.idHex.padStart(3, '0')}</span>
                      <span className="flex-1">{frame.dataHex}</span>
                      {frame.type && (
                        <Badge variant="outline" className="text-xs">
                          {frame.type}
                        </Badge>
                      )}
                      {frame.description && (
                        <span className="text-xs">{frame.description}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
