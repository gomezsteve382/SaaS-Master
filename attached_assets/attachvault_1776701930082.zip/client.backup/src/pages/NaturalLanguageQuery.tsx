import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, MessageSquare } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';

export default function NaturalLanguageQuery() {
  const [question, setQuestion] = useState('');
  const [context, setContext] = useState('');
  const [answer, setAnswer] = useState('');
  const [history, setHistory] = useState<Array<{ question: string; answer: string }>>([]);

  const askMutation = trpc.ai.askQuestion.useMutation();

  const handleAsk = async () => {
    if (!question) {
      alert('Please enter a question');
      return;
    }

    try {
      const response = await askMutation.mutateAsync({
        question,
        context: context || undefined
      });
      const answerText = typeof response.answer === 'string' ? response.answer : JSON.stringify(response.answer);
      setAnswer(answerText);
      setHistory([{ question, answer: answerText }, ...history]);
      setQuestion('');
    } catch (error) {
      console.error('Query failed:', error);
      alert('Query failed. Please try again.');
    }
  };

  const exampleQuestions = [
    "How do I program a VIN to a BCM module?",
    "What's the difference between Atlantis and Shift-XOR algorithms?",
    "How do I extract a PIN from an RFHUB?",
    "What causes C2202 VIN mismatch error?",
    "How do I bypass SecurityGateway on 2019 RAM 1500?",
    "What seed-key algorithm does a 2015 Charger use?"
  ];

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <MessageSquare className="w-10 h-10 text-primary" />
          Natural Language Query Engine
        </h1>
        <p className="text-muted-foreground">
          Ask diagnostic questions in plain English. Get expert answers from The SRT Lab AI Assistant.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Ask any question about FCA/Stellantis diagnostics, programming, or security. 
          The AI has expert knowledge of seed-key algorithms, VIN programming, CAN bus protocols, and module replacement procedures. 
          Provide context for more specific answers.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Ask a Question</CardTitle>
            <CardDescription>Get expert diagnostic guidance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="question">Your Question *</Label>
              <Textarea
                id="question"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="How do I program a VIN to a BCM module?"
                rows={4}
              />
            </div>

            <div>
              <Label htmlFor="context">Context (Optional)</Label>
              <Textarea
                id="context"
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="2019 Dodge Charger R/T, replacing BCM after accident..."
                rows={3}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Provide vehicle info, symptoms, or previous attempts
              </p>
            </div>

            <Button 
              onClick={handleAsk} 
              disabled={askMutation.isPending || !question}
              className="w-full"
            >
              {askMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Thinking...
                </>
              ) : (
                <>
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask Question
                </>
              )}
            </Button>

            {/* Example Questions */}
            <div className="pt-4 border-t">
              <Label className="mb-2 block">Example Questions</Label>
              <div className="space-y-2">
                {exampleQuestions.map((q, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    onClick={() => setQuestion(q)}
                    className="w-full justify-start text-xs"
                  >
                    {q}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Answer Section */}
        <Card>
          <CardHeader>
            <CardTitle>AI Answer</CardTitle>
            <CardDescription>Expert diagnostic guidance</CardDescription>
          </CardHeader>
          <CardContent>
            {answer ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{answer}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Ask a question to get started</p>
                <p className="text-xs mt-2">
                  Or try an example question
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* AI Capabilities */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>AI Assistant Capabilities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <h3 className="font-semibold mb-2">🔐 Security & Algorithms</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• All seed-key algorithms (1996-2024)</li>
                <li>• Atlantis AES-128 ECB (2018+)</li>
                <li>• SKIM/RFHUB pairing</li>
                <li>• Security byte generation</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🔧 Programming</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• VIN programming procedures</li>
                <li>• Module replacement steps</li>
                <li>• Flash programming sequences</li>
                <li>• UDS protocol commands</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🚗 Diagnostics</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• DTC code analysis</li>
                <li>• CAN bus troubleshooting</li>
                <li>• Module compatibility</li>
                <li>• Hardware setup guidance</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Conversation History */}
      {history.length > 0 && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Recent Questions</CardTitle>
            <CardDescription>Your conversation history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {history.slice(0, 3).map((item, i) => (
                <div key={i} className="border-l-2 border-primary pl-4">
                  <p className="font-semibold text-sm mb-1">Q: {item.question}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {item.answer.substring(0, 150)}...
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
