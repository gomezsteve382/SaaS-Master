import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Send, Bot, User, Loader2, CheckCircle, AlertCircle, Wrench } from "lucide-react";

interface Message {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  status?: "pending" | "success" | "error";
  workflow?: WorkflowStep[];
}

interface WorkflowStep {
  id: number;
  name: string;
  status: "pending" | "running" | "success" | "error";
  details?: string;
}

export default function AgenticDiagnosticAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "👋 Hi! I'm your AI diagnostic assistant. I can help you with:\n\n• Clear fault codes (\"Clear ABS fault on my 2015 Charger\")\n• Program VINs (\"Program VIN to new BCM\")\n• Diagnose issues (\"Why is my check engine light on?\")\n• Add key fobs (\"Add a new key fob\")\n• Calibrate sensors (\"Calibrate steering angle sensor\")\n\nWhat can I help you with today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsProcessing(true);

    // Simulate AI processing
    setTimeout(() => {
      const response = generateResponse(input);
      setMessages((prev) => [...prev, response]);
      setIsProcessing(false);
    }, 1500);
  };

  const generateResponse = (userInput: string): Message => {
    const lower = userInput.toLowerCase();

    // Clear DTC workflow
    if (lower.includes("clear") && (lower.includes("fault") || lower.includes("dtc") || lower.includes("code"))) {
      return {
        role: "assistant",
        content: "I'll help you clear the fault code. Here's what I'm doing:",
        timestamp: new Date(),
        status: "success",
        workflow: [
          { id: 1, name: "Scanning CAN bus for modules", status: "success", details: "Found 12 modules" },
          { id: 2, name: "Reading DTCs from all modules", status: "success", details: "Found 1 active fault: C121A" },
          { id: 3, name: "Entering diagnostic session", status: "success", details: "Session 0x03 active" },
          { id: 4, name: "Security access granted", status: "success", details: "Using SBEC algorithm" },
          { id: 5, name: "Clearing DTC C121A", status: "success", details: "UDS service 0x14" },
          { id: 6, name: "Verifying clear", status: "success", details: "No active faults remaining" },
        ],
      };
    }

    // Program VIN workflow
    if (lower.includes("program") && lower.includes("vin")) {
      return {
        role: "assistant",
        content: "I'll program the VIN to the BCM. Please provide the 17-character VIN:",
        timestamp: new Date(),
        status: "pending",
        workflow: [
          { id: 1, name: "Waiting for VIN input", status: "pending" },
          { id: 2, name: "Validate VIN format", status: "pending" },
          { id: 3, name: "Calculate CRC checksum", status: "pending" },
          { id: 4, name: "Enter programming session", status: "pending" },
          { id: 5, name: "Write VIN to BCM", status: "pending" },
          { id: 6, name: "Verify VIN written correctly", status: "pending" },
        ],
      };
    }

    // Diagnose check engine light
    if (lower.includes("check engine") || lower.includes("cel") || (lower.includes("why") && lower.includes("light"))) {
      return {
        role: "assistant",
        content: "Let me diagnose the check engine light:",
        timestamp: new Date(),
        status: "success",
        workflow: [
          { id: 1, name: "Scanning ECM for DTCs", status: "success", details: "Found P0171" },
          { id: 2, name: "Reading freeze frame data", status: "success", details: "Speed: 45 mph, RPM: 2100" },
          { id: 3, name: "Analyzing fault", status: "success", details: "P0171 - System Too Lean (Bank 1)" },
        ],
      };
    }

    // Add key fob
    if (lower.includes("key") || lower.includes("fob")) {
      return {
        role: "assistant",
        content: "I'll help you add a new key fob:",
        timestamp: new Date(),
        status: "success",
        workflow: [
          { id: 1, name: "Detecting RFHUB module", status: "success", details: "CAN ID: 0x742" },
          { id: 2, name: "Reading current keys", status: "success", details: "2 keys programmed" },
          { id: 3, name: "Entering programming mode", status: "success", details: "PIN verified" },
          { id: 4, name: "Waiting for new key signal", status: "running", details: "Press UNLOCK button on new key NOW" },
        ],
      };
    }

    // Calibrate sensor
    if (lower.includes("calibrate") || lower.includes("alignment") || lower.includes("sensor")) {
      return {
        role: "assistant",
        content: "I'll run the steering angle sensor calibration (proxy alignment):",
        timestamp: new Date(),
        status: "success",
        workflow: [
          { id: 1, name: "Entering diagnostic session", status: "success" },
          { id: 2, name: "Security access granted", status: "success" },
          { id: 3, name: "Running routine 0x0302", status: "success" },
          { id: 4, name: "Waiting for user action", status: "running", details: "Turn steering wheel fully LEFT" },
        ],
      };
    }

    // Default response
    return {
      role: "assistant",
      content: "I can help you with that! Here are some examples of what I can do:\n\n• \"Clear the ABS fault\"\n• \"Program VIN to BCM\"\n• \"Why is my check engine light on?\"\n• \"Add a new key fob\"\n• \"Calibrate steering angle sensor\"\n\nCould you rephrase your request using one of these examples?",
      timestamp: new Date(),
    };
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "pending":
        return <Loader2 className="h-4 w-4 animate-spin text-yellow-500" />;
      case "running":
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />;
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 max-w-5xl">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">🤖 AI Diagnostic Assistant</h1>
        <p className="text-muted-foreground">
          Natural language interface for automotive diagnostics - just tell me what you need
        </p>
      </div>

      <Card className="h-[calc(100vh-250px)] flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Diagnostic Chat
          </CardTitle>
          <CardDescription>
            Powered by 706 algorithms, 94K+ database entries, and 60 SRT Lab Toolkit tools
          </CardDescription>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0">
          {/* Messages */}
          <ScrollArea className="flex-1 p-6" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((message, idx) => (
                <div
                  key={idx}
                  className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                      <Bot className="h-4 w-4 text-primary-foreground" />
                    </div>
                  )}

                  <div className={`max-w-[80%] ${message.role === "user" ? "order-first" : ""}`}>
                    <div
                      className={`rounded-lg p-4 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{message.content}</div>

                      {/* Workflow Steps */}
                      {message.workflow && (
                        <div className="mt-4 space-y-2 border-t border-border pt-4">
                          {message.workflow.map((step) => (
                            <div key={step.id} className="flex items-start gap-2">
                              <div className="mt-1">{getStatusIcon(step.status)}</div>
                              <div className="flex-1">
                                <div className="font-medium text-sm">{step.name}</div>
                                {step.details && (
                                  <div className="text-xs text-muted-foreground mt-1">
                                    {step.details}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="text-xs text-muted-foreground mt-1 px-1">
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </div>

                  {message.role === "user" && (
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                      <User className="h-4 w-4" />
                    </div>
                  )}
                </div>
              ))}

              {isProcessing && (
                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                    <Bot className="h-4 w-4 text-primary-foreground" />
                  </div>
                  <div className="bg-muted rounded-lg p-4">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="border-t p-4">
            <div className="flex gap-2">
              <Input
                placeholder="Type your request... (e.g., 'Clear ABS fault on my 2015 Charger')"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                disabled={isProcessing}
              />
              <Button onClick={handleSend} disabled={isProcessing || !input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="mt-4 grid gap-2 md:grid-cols-3">
        <Button
          variant="outline"
          className="justify-start"
          onClick={() => setInput("Clear the ABS fault")}
        >
          <Wrench className="h-4 w-4 mr-2" />
          Clear Fault Code
        </Button>
        <Button
          variant="outline"
          className="justify-start"
          onClick={() => setInput("Program VIN to BCM")}
        >
          <Wrench className="h-4 w-4 mr-2" />
          Program VIN
        </Button>
        <Button
          variant="outline"
          className="justify-start"
          onClick={() => setInput("Add a new key fob")}
        >
          <Wrench className="h-4 w-4 mr-2" />
          Add Key Fob
        </Button>
      </div>
    </div>
  );
}
