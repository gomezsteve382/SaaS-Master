import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { BackButton } from "@/components/BackButton";
import { Activity, Info, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DecodedParameter {
  name: string;
  rawValue: number;
  decodedValue: number;
  unit: string;
  formula: string;
}

export default function LiveDataDecoder() {
  const [udsResponse, setUdsResponse] = useState<string>("");
  const [decodedParams, setDecodedParams] = useState<DecodedParameter[]>([]);
  const [error, setError] = useState<string>("");
  const { toast } = useToast();

  // Sample FGA parameters with scaling formulas
  const FGA_PARAMETERS = [
    {
      name: "Engine RPM",
      bitPos: 24,
      bitLen: 16,
      slope: 1.0,
      offset: 0.0,
      unit: "RPM",
    },
    {
      name: "Coolant Temperature",
      bitPos: 24,
      bitLen: 8,
      slope: 1.0,
      offset: -40.0,
      unit: "°C",
    },
    {
      name: "Vehicle Speed",
      bitPos: 24,
      bitLen: 16,
      slope: 0.0078125,
      offset: 0.0,
      unit: "km/h",
    },
    {
      name: "Throttle Position",
      bitPos: 24,
      bitLen: 8,
      slope: 1.0,
      offset: 0.0,
      unit: "%",
    },
    {
      name: "Battery Voltage",
      bitPos: 24,
      bitLen: 16,
      slope: 0.0009765625,
      offset: 0.0,
      unit: "V",
    },
  ];

  const handleDecode = () => {
    setError("");
    setDecodedParams([]);

    if (!udsResponse.trim()) {
      setError("Please enter a UDS response");
      return;
    }

    try {
      // Remove spaces and validate hex
      const cleanHex = udsResponse.replace(/\s+/g, "").toUpperCase();
      
      if (!/^[0-9A-F]+$/.test(cleanHex)) {
        setError("Invalid hex format. Use only 0-9 and A-F");
        return;
      }

      if (cleanHex.length < 6) {
        setError("Response too short. Need at least 3 bytes");
        return;
      }

      // Convert hex string to bytes
      const bytes: number[] = [];
      for (let i = 0; i < cleanHex.length; i += 2) {
        bytes.push(parseInt(cleanHex.substr(i, 2), 16));
      }

      // Decode parameters using FGA formulas
      const decoded: DecodedParameter[] = FGA_PARAMETERS.map((param) => {
        // Extract bits from response
        const bytePos = Math.floor(param.bitPos / 8);
        let rawValue = 0;

        if (param.bitLen === 8 && bytePos < bytes.length) {
          rawValue = bytes[bytePos];
        } else if (param.bitLen === 16 && bytePos + 1 < bytes.length) {
          rawValue = (bytes[bytePos] << 8) | bytes[bytePos + 1];
        } else if (param.bitLen === 32 && bytePos + 3 < bytes.length) {
          rawValue = (bytes[bytePos] << 24) | (bytes[bytePos + 1] << 16) | 
                     (bytes[bytePos + 2] << 8) | bytes[bytePos + 3];
        }

        // Apply scaling formula: actual_value = (raw_value * slope) + offset
        const decodedValue = (rawValue * param.slope) + param.offset;

        return {
          name: param.name,
          rawValue,
          decodedValue: Math.round(decodedValue * 100) / 100, // Round to 2 decimals
          unit: param.unit,
          formula: `(${rawValue} * ${param.slope}) + ${param.offset}`,
        };
      });

      setDecodedParams(decoded);

      toast({
        title: "Decoded Successfully",
        description: `Decoded ${decoded.length} parameters`,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Decoding failed");
    }
  };

  const handleExportCSV = () => {
    if (decodedParams.length === 0) {
      toast({
        title: "No Data",
        description: "Decode some parameters first",
        variant: "destructive",
      });
      return;
    }

    const csv = [
      "Parameter,Raw Value,Decoded Value,Unit,Formula",
      ...decodedParams.map((p) =>
        `"${p.name}",${p.rawValue},${p.decodedValue},"${p.unit}","${p.formula}"`
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `live_data_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Exported",
      description: "CSV file downloaded",
    });
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Live Data Decoder</h1>
        <p className="text-muted-foreground">
          Decode UDS responses using FGA scaling formulas (22,641 parameters)
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              UDS Response Decoder
            </CardTitle>
            <CardDescription>Enter raw UDS response in hex format</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* UDS Response Input */}
            <div className="space-y-2">
              <Label>UDS Response (Hex)</Label>
              <Textarea
                placeholder="62 01 00 0A 3C 28 FF..."
                value={udsResponse}
                onChange={(e) => setUdsResponse(e.target.value)}
                rows={4}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">
                Enter response bytes in hex format (spaces optional)
              </p>
            </div>

            {/* Decode Button */}
            <div className="flex gap-2">
              <Button onClick={handleDecode} className="flex-1">
                <Activity className="h-4 w-4 mr-2" />
                Decode Parameters
              </Button>
              {decodedParams.length > 0 && (
                <Button variant="outline" onClick={handleExportCSV}>
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              )}
            </div>

            {/* Error Display */}
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Decoded Results */}
            {decodedParams.length > 0 && (
              <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                <CardHeader>
                  <CardTitle className="text-lg">Decoded Parameters</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {decodedParams.map((param, index) => (
                      <div
                        key={index}
                        className="p-4 bg-white dark:bg-gray-900 rounded-lg border"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <p className="font-medium">{param.name}</p>
                          <Badge variant="outline">{param.unit}</Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Raw Value</p>
                            <p className="font-mono">0x{param.rawValue.toString(16).toUpperCase()}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Decoded Value</p>
                            <p className="font-mono font-bold text-lg">
                              {param.decodedValue} {param.unit}
                            </p>
                          </div>
                        </div>
                        <div className="mt-2 pt-2 border-t">
                          <p className="text-xs text-muted-foreground">Formula:</p>
                          <p className="font-mono text-xs">{param.formula}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Info Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Info className="h-5 w-5" />
                Decoding Formula
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">FGA Formula</p>
                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded border border-blue-200 dark:border-blue-800">
                  <p className="font-mono text-sm">
                    actual_value = (raw_value * slope) + offset
                  </p>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Example</p>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <p>• Raw: 0x0A3C (2620)</p>
                  <p>• Slope: 1.0</p>
                  <p>• Offset: 0.0</p>
                  <p>• Result: 2620 RPM</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Sample Responses</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-xs">
              <div>
                <p className="font-medium">Engine RPM</p>
                <p className="font-mono text-muted-foreground">62 01 00 0A 3C</p>
              </div>
              <div>
                <p className="font-medium">Coolant Temp</p>
                <p className="font-mono text-muted-foreground">62 01 05 5A</p>
              </div>
              <div>
                <p className="font-medium">Vehicle Speed</p>
                <p className="font-mono text-muted-foreground">62 01 0D 28 00</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Database Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Engine Data</span>
                <span className="font-medium">4,427</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">BCM Data</span>
                <span className="font-medium">4,826</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">ABS Data</span>
                <span className="font-medium">4,089</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Petrol Data</span>
                <span className="font-medium">5,099</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-medium">Total Parameters</span>
                <span className="font-bold">22,641</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
