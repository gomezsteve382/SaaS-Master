import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BackButton } from "@/components/BackButton";
import { GitCompare, Upload, Download } from "lucide-react";
import { toast } from "sonner";

interface Difference {
  offset: number;
  oldValue: number;
  newValue: number;
}

export default function ModuleComparison() {
  const [file1, setFile1] = useState<File | null>(null);
  const [file2, setFile2] = useState<File | null>(null);
  const [differences, setDifferences] = useState<Difference[]>([]);
  const [isComparing, setIsComparing] = useState(false);
  const [stats, setStats] = useState<{ total: number; different: number; percent: number } | null>(null);

  const handleFile1Select = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFile1(file);
      setDifferences([]);
      setStats(null);
    }
  };

  const handleFile2Select = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFile2(file);
      setDifferences([]);
      setStats(null);
    }
  };

  const handleCompare = async () => {
    if (!file1 || !file2) {
      toast.error("Please select both files to compare");
      return;
    }

    setIsComparing(true);

    try {
      // Read both files
      const buffer1 = await file1.arrayBuffer();
      const buffer2 = await file2.arrayBuffer();
      
      const data1 = new Uint8Array(buffer1);
      const data2 = new Uint8Array(buffer2);

      if (data1.length !== data2.length) {
        toast.error(`File sizes don't match: ${data1.length} vs ${data2.length} bytes`);
        setIsComparing(false);
        return;
      }

      // Compare byte by byte
      const diffs: Difference[] = [];
      for (let i = 0; i < data1.length; i++) {
        if (data1[i] !== data2[i]) {
          diffs.push({
            offset: i,
            oldValue: data1[i],
            newValue: data2[i],
          });
        }
      }

      setDifferences(diffs);
      setStats({
        total: data1.length,
        different: diffs.length,
        percent: (diffs.length / data1.length) * 100,
      });

      if (diffs.length === 0) {
        toast.success("Files are identical!");
      } else {
        toast.success(`Found ${diffs.length} differences`);
      }
    } catch (error) {
      toast.error("Failed to compare files: " + (error as Error).message);
    } finally {
      setIsComparing(false);
    }
  };

  const exportDiffReport = () => {
    if (differences.length === 0) {
      toast.error("No differences to export");
      return;
    }

    // Create CSV content
    let csv = "Offset (Hex),Offset (Dec),Old Value (Hex),New Value (Hex),Old Value (Dec),New Value (Dec)\n";
    for (const diff of differences) {
      csv += `0x${diff.offset.toString(16).toUpperCase().padStart(8, '0')},`;
      csv += `${diff.offset},`;
      csv += `0x${diff.oldValue.toString(16).toUpperCase().padStart(2, '0')},`;
      csv += `0x${diff.newValue.toString(16).toUpperCase().padStart(2, '0')},`;
      csv += `${diff.oldValue},`;
      csv += `${diff.newValue}\n`;
    }

    // Download CSV
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `module_diff_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success("Diff report exported as CSV");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <GitCompare className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">MODULE COMPARISON</h1>
            <p className="text-gray-600">
              Side-by-side EEPROM dump comparison with byte-level difference analysis
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* File 1 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Original Module
              </CardTitle>
              <CardDescription>First EEPROM dump file</CardDescription>
            </CardHeader>
            <CardContent>
              <Label htmlFor="file1">Module File 1</Label>
              <Input
                id="file1"
                type="file"
                accept=".bin"
                onChange={handleFile1Select}
                className="mt-2"
              />
              {file1 && (
                <p className="text-sm text-gray-600 mt-2">
                  {file1.name} ({(file1.size / 1024).toFixed(2)} KB)
                </p>
              )}
            </CardContent>
          </Card>

          {/* File 2 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Modified Module
              </CardTitle>
              <CardDescription>Second EEPROM dump file</CardDescription>
            </CardHeader>
            <CardContent>
              <Label htmlFor="file2">Module File 2</Label>
              <Input
                id="file2"
                type="file"
                accept=".bin"
                onChange={handleFile2Select}
                className="mt-2"
              />
              {file2 && (
                <p className="text-sm text-gray-600 mt-2">
                  {file2.name} ({(file2.size / 1024).toFixed(2)} KB)
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="pt-6 space-y-4">
            <Button
              onClick={handleCompare}
              disabled={isComparing || !file1 || !file2}
              className="w-full gap-2"
              size="lg"
            >
              <GitCompare className="h-5 w-5" />
              {isComparing ? "Comparing..." : "Compare Modules"}
            </Button>

            {differences.length > 0 && (
              <Button
                onClick={exportDiffReport}
                variant="outline"
                className="w-full gap-2"
              >
                <Download className="h-4 w-4" />
                Export Diff Report (CSV)
              </Button>
            )}
          </CardContent>
        </Card>

        {stats && (
          <Card>
            <CardHeader>
              <CardTitle>Comparison Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold">{stats.total.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Total Bytes</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-red-600">{stats.different.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Different Bytes</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.percent.toFixed(2)}%</p>
                  <p className="text-sm text-gray-600">Difference</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {differences.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Differences ({differences.length})</CardTitle>
              <CardDescription>
                Showing first 1000 differences (export CSV for complete list)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-2 text-left font-mono">Offset (Hex)</th>
                      <th className="p-2 text-left">Offset (Dec)</th>
                      <th className="p-2 text-left font-mono">Old Value</th>
                      <th className="p-2 text-left font-mono">New Value</th>
                      <th className="p-2 text-left">Change</th>
                    </tr>
                  </thead>
                  <tbody>
                    {differences.slice(0, 1000).map((diff, idx) => (
                      <tr key={idx} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-mono text-blue-600">
                          0x{diff.offset.toString(16).toUpperCase().padStart(8, '0')}
                        </td>
                        <td className="p-2">{diff.offset.toLocaleString()}</td>
                        <td className="p-2 font-mono bg-red-50">
                          0x{diff.oldValue.toString(16).toUpperCase().padStart(2, '0')} ({diff.oldValue})
                        </td>
                        <td className="p-2 font-mono bg-green-50">
                          0x{diff.newValue.toString(16).toUpperCase().padStart(2, '0')} ({diff.newValue})
                        </td>
                        <td className="p-2">
                          {diff.newValue > diff.oldValue ? (
                            <span className="text-green-600">+{diff.newValue - diff.oldValue}</span>
                          ) : (
                            <span className="text-red-600">{diff.newValue - diff.oldValue}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">Use Cases</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-900 space-y-2">
            <p>• <strong>Security Byte Verification:</strong> Compare before/after security byte sync</p>
            <p>• <strong>VIN Patching Validation:</strong> Verify only VIN and checksums changed</p>
            <p>• <strong>Configuration Analysis:</strong> Identify feature coding differences</p>
            <p>• <strong>Corruption Detection:</strong> Find unexpected changes in module dumps</p>
            <p>• <strong>Clone Verification:</strong> Ensure module cloning was successful</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
