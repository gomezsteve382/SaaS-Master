import { useState, useCallback, useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { BackButton } from "@/components/BackButton";
import { 
  Home, AlertTriangle, Trash2, RefreshCw, Loader2, 
  Usb, Wifi, Check, X, CircleAlert, Clock, Wrench
} from 'lucide-react';
import { 
  ELM327Protocol, 
  J2534Protocol, 
  ArduinoCANProtocol,
  HardwareType,
  formatHexBytes,
} from "@shared/obd2-protocol";

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

interface LogEntry {
  type: 'tx' | 'rx' | 'info' | 'success' | 'error' | 'warning';
  message: string;
  timestamp: Date;
}

interface DTCInfo {
  code: string;
  status: number;
  statusDescription: string;
  description: string;
  severity: 'critical' | 'warning' | 'info';
  confirmed: boolean;
  pending: boolean;
  permanent: boolean;
}

interface ModuleInfo {
  code: string;
  name: string;
  txId: number;
  rxId: number;
}

const CHRYSLER_MODULES: ModuleInfo[] = [
  { code: 'ECM', name: 'Engine Control Module', txId: 0x7E0, rxId: 0x7E8 },
  { code: 'TCM', name: 'Transmission Control Module', txId: 0x7E1, rxId: 0x7E9 },
  { code: 'BCM', name: 'Body Control Module', txId: 0x742, rxId: 0x74A },
  { code: 'ABS', name: 'Anti-lock Brake System', txId: 0x744, rxId: 0x74C },
  { code: 'IPCM', name: 'Instrument Panel Cluster', txId: 0x760, rxId: 0x768 },
  { code: 'RFHUB', name: 'RF Hub Module', txId: 0x726, rxId: 0x72E },
  { code: 'ORC', name: 'Occupant Restraint Controller', txId: 0x720, rxId: 0x728 },
  { code: 'SDM', name: 'Sensing Diagnostic Module', txId: 0x720, rxId: 0x728 },
  { code: 'EPS', name: 'Electric Power Steering', txId: 0x746, rxId: 0x74E },
  { code: 'PAM', name: 'Parking Assist Module', txId: 0x7A0, rxId: 0x7A8 },
  { code: 'ACC', name: 'Adaptive Cruise Control', txId: 0x764, rxId: 0x76C },
  { code: 'RADIO', name: 'Radio/Uconnect', txId: 0x7D0, rxId: 0x7D8 },
  { code: 'HVAC', name: 'Climate Control Module', txId: 0x763, rxId: 0x76B },
];

const DTC_DESCRIPTIONS: Record<string, string> = {
  'P0000': 'No DTC Requested',
  'P0100': 'Mass Air Flow Circuit Malfunction',
  'P0101': 'Mass Air Flow Circuit Range/Performance Problem',
  'P0102': 'Mass Air Flow Circuit Low Input',
  'P0103': 'Mass Air Flow Circuit High Input',
  'P0110': 'Intake Air Temperature Circuit Malfunction',
  'P0115': 'Engine Coolant Temperature Circuit Malfunction',
  'P0120': 'Throttle Position Sensor/Switch A Circuit Malfunction',
  'P0130': 'O2 Sensor Circuit Bank 1 Sensor 1',
  'P0131': 'O2 Sensor Circuit Low Voltage Bank 1 Sensor 1',
  'P0133': 'O2 Sensor Circuit Slow Response Bank 1 Sensor 1',
  'P0140': 'O2 Sensor Circuit No Activity Detected Bank 1 Sensor 2',
  'P0171': 'System Too Lean Bank 1',
  'P0172': 'System Too Rich Bank 1',
  'P0174': 'System Too Lean Bank 2',
  'P0175': 'System Too Rich Bank 2',
  'P0300': 'Random/Multiple Cylinder Misfire Detected',
  'P0301': 'Cylinder 1 Misfire Detected',
  'P0302': 'Cylinder 2 Misfire Detected',
  'P0303': 'Cylinder 3 Misfire Detected',
  'P0304': 'Cylinder 4 Misfire Detected',
  'P0305': 'Cylinder 5 Misfire Detected',
  'P0306': 'Cylinder 6 Misfire Detected',
  'P0307': 'Cylinder 7 Misfire Detected',
  'P0308': 'Cylinder 8 Misfire Detected',
  'P0325': 'Knock Sensor 1 Circuit Malfunction Bank 1',
  'P0335': 'Crankshaft Position Sensor A Circuit Malfunction',
  'P0340': 'Camshaft Position Sensor A Circuit Malfunction',
  'P0400': 'Exhaust Gas Recirculation Flow Malfunction',
  'P0420': 'Catalyst System Efficiency Below Threshold Bank 1',
  'P0430': 'Catalyst System Efficiency Below Threshold Bank 2',
  'P0440': 'Evaporative Emission System Malfunction',
  'P0442': 'Evaporative Emission System Leak Detected (small leak)',
  'P0443': 'Evaporative Emission System Purge Control Valve Circuit',
  'P0446': 'Evaporative Emission System Vent Control Circuit',
  'P0455': 'Evaporative Emission System Leak Detected (large leak)',
  'P0500': 'Vehicle Speed Sensor A Malfunction',
  'P0505': 'Idle Control System Malfunction',
  'P0507': 'Idle Control System RPM Higher Than Expected',
  'P0562': 'System Voltage Low',
  'P0563': 'System Voltage High',
  'P0600': 'Serial Communication Link Malfunction',
  'P0700': 'Transmission Control System Malfunction',
  'P0705': 'Transmission Range Sensor Circuit Malfunction',
  'P0715': 'Input/Turbine Speed Sensor Circuit Malfunction',
  'P0720': 'Output Speed Sensor Circuit Malfunction',
  'P0725': 'Engine Speed Input Circuit Malfunction',
  'P0730': 'Incorrect Gear Ratio',
  'P0731': 'Gear 1 Incorrect Ratio',
  'P0740': 'Torque Converter Clutch Solenoid Circuit',
  'P0750': 'Shift Solenoid A Malfunction',
  'P0755': 'Shift Solenoid B Malfunction',
  'P0760': 'Shift Solenoid C Malfunction',
  'U0100': 'Lost Communication With ECM/PCM',
  'U0101': 'Lost Communication With TCM',
  'U0121': 'Lost Communication With ABS',
  'U0131': 'Lost Communication With Power Steering',
  'U0140': 'Lost Communication With BCM',
  'U0155': 'Lost Communication With Instrument Panel',
  'U0184': 'Lost Communication With Radio',
  'U0401': 'Invalid Data Received From ECM/PCM',
  'U1411': 'Implausible VIN Received',
  'B1000': 'ECU Hardware Error',
  'B1001': 'ECU Software Error',
  'B1015': 'Battery Voltage Low',
  'B1016': 'Battery Voltage High',
  'B1200': 'Climate Control Push Button Circuit',
  'B1342': 'ECU Malfunction',
  'C0035': 'Left Front Wheel Speed Sensor Circuit',
  'C0040': 'Right Front Wheel Speed Sensor Circuit',
  'C0045': 'Left Rear Wheel Speed Sensor Circuit',
  'C0050': 'Right Rear Wheel Speed Sensor Circuit',
  'C0265': 'EBCM Motor Relay Circuit',
  'C0300': 'Rear Speed Sensor Circuit',
};

function decodeDTC(byte1: number, byte2: number): string {
  const typeIndex = (byte1 >> 6) & 0x03;
  const firstChar = ['P', 'C', 'B', 'U'][typeIndex];
  const secondChar = ((byte1 >> 4) & 0x03).toString();
  const thirdChar = (byte1 & 0x0F).toString(16).toUpperCase();
  const fourthChar = ((byte2 >> 4) & 0x0F).toString(16).toUpperCase();
  const fifthChar = (byte2 & 0x0F).toString(16).toUpperCase();
  
  return `${firstChar}${secondChar}${thirdChar}${fourthChar}${fifthChar}`;
}

function getDTCTypeDescription(code: string): string {
  const typeChar = code.charAt(0);
  const categoryChar = code.charAt(1);
  
  const typeDescriptions: Record<string, string> = {
    'P': 'Powertrain',
    'C': 'Chassis',
    'B': 'Body',
    'U': 'Network/Communication',
  };
  
  const categoryDescriptions: Record<string, Record<string, string>> = {
    'P': {
      '0': 'Generic OBD-II',
      '1': 'Manufacturer-specific',
      '2': 'Generic OBD-II',
      '3': 'Generic/Manufacturer',
    },
    'C': {
      '0': 'Generic OBD-II chassis',
      '1': 'Manufacturer-specific chassis',
      '2': 'Generic OBD-II chassis',
      '3': 'Manufacturer-specific chassis',
    },
    'B': {
      '0': 'Generic OBD-II body',
      '1': 'Manufacturer-specific body',
      '2': 'Generic OBD-II body',
      '3': 'Manufacturer-specific body',
    },
    'U': {
      '0': 'Generic network/communication',
      '1': 'Manufacturer-specific network',
      '2': 'Manufacturer-specific network',
      '3': 'Manufacturer-specific network',
    },
  };
  
  const typeDesc = typeDescriptions[typeChar] || 'Unknown';
  const catDesc = categoryDescriptions[typeChar]?.[categoryChar] || 'Unknown category';
  
  return `${typeDesc} - ${catDesc}`;
}

function getStatusDescription(statusByte: number): string {
  const parts: string[] = [];
  
  if (statusByte & 0x01) parts.push('Test Failed');
  if (statusByte & 0x02) parts.push('Test Failed This Cycle');
  if (statusByte & 0x04) parts.push('Pending DTC');
  if (statusByte & 0x08) parts.push('Confirmed DTC');
  if (statusByte & 0x10) parts.push('Test Not Complete Since Last Clear');
  if (statusByte & 0x20) parts.push('Test Failed Since Last Clear');
  if (statusByte & 0x40) parts.push('Test Not Complete This Cycle');
  if (statusByte & 0x80) parts.push('Warning Indicator Requested');
  
  return parts.length > 0 ? parts.join(', ') : 'Unknown Status';
}

function getDTCDescription(code: string): string {
  if (DTC_DESCRIPTIONS[code]) {
    return DTC_DESCRIPTIONS[code];
  }
  
  const typeChar = code.charAt(0);
  const categoryChar = code.charAt(1);
  const codeNum = parseInt(code.substring(2), 16);
  
  const typeNames: Record<string, string> = {
    'P': 'Powertrain',
    'C': 'Chassis',
    'B': 'Body',
    'U': 'Network',
  };
  
  const categoryTypes: Record<string, string> = {
    '0': 'Generic OBD-II',
    '1': 'Manufacturer-specific',
    '2': 'Generic OBD-II',
    '3': 'Manufacturer/OBD-II',
  };
  
  const typeName = typeNames[typeChar] || 'Unknown';
  const categoryType = categoryTypes[categoryChar] || 'Unknown';
  
  if (typeChar === 'P') {
    if (codeNum >= 0x100 && codeNum <= 0x1FF) return `${categoryType} fuel and air metering fault`;
    if (codeNum >= 0x200 && codeNum <= 0x2FF) return `${categoryType} fuel and air metering (injector) fault`;
    if (codeNum >= 0x300 && codeNum <= 0x3FF) return `${categoryType} ignition/misfire fault`;
    if (codeNum >= 0x400 && codeNum <= 0x4FF) return `${categoryType} emission control fault`;
    if (codeNum >= 0x500 && codeNum <= 0x5FF) return `${categoryType} vehicle speed/idle control fault`;
    if (codeNum >= 0x600 && codeNum <= 0x6FF) return `${categoryType} computer/output circuit fault`;
    if (codeNum >= 0x700 && codeNum <= 0x7FF) return `${categoryType} transmission fault`;
  } else if (typeChar === 'C') {
    return `${categoryType} chassis fault (code ${code.substring(1)})`;
  } else if (typeChar === 'B') {
    return `${categoryType} body electrical fault (code ${code.substring(1)})`;
  } else if (typeChar === 'U') {
    if (codeNum >= 0x100 && codeNum <= 0x1FF) return `${categoryType} lost communication fault`;
    if (codeNum >= 0x400 && codeNum <= 0x4FF) return `${categoryType} invalid data received fault`;
    return `${categoryType} network communication fault (code ${code.substring(1)})`;
  }
  
  return `${typeName} ${categoryType} fault (code ${code.substring(1)})`;
}

function getDTCSeverity(code: string, status: number): 'critical' | 'warning' | 'info' {
  if (status & 0x80) return 'critical';
  if (status & 0x08) return 'warning';
  return 'info';
}

export default function DTCReaderPage() {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [hardwareType, setHardwareType] = useState<HardwareType>('elm327');
  const [protocol, setProtocol] = useState<ELM327Protocol | J2534Protocol | ArduinoCANProtocol | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [selectedModule, setSelectedModule] = useState<string>('ECM');
  const [dtcs, setDtcs] = useState<DTCInfo[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  
  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    setLogs(prev => [...prev.slice(-99), { type, message, timestamp: new Date() }]);
  }, []);
  
  const handleConnect = async () => {
    setConnectionStatus('connecting');
    addLog('info', `Connecting via ${hardwareType.toUpperCase()}...`);
    
    try {
      if (hardwareType === 'elm327') {
        const elm = new ELM327Protocol();
        const success = await elm.connect();
        
        if (success) {
          setProtocol(elm);
          setConnectionStatus('connected');
          addLog('success', 'ELM327 connected successfully');
        } else {
          setConnectionStatus('error');
          addLog('error', `Connection failed: ${elm.getLastError()}`);
        }
      } else if (hardwareType === 'j2534') {
        const j2534 = new J2534Protocol();
        const success = await j2534.connect();
        
        if (success) {
          setProtocol(j2534);
          setConnectionStatus('connected');
          addLog('success', 'J2534 PassThru connected');
        } else {
          setConnectionStatus('error');
          addLog('error', 'J2534 connection failed - check PassThru server');
        }
      } else if (hardwareType === 'arduino') {
        const arduino = new ArduinoCANProtocol();
        const success = await arduino.connect();
        
        if (success) {
          setProtocol(arduino);
          setConnectionStatus('connected');
          addLog('success', 'Arduino CAN connected');
        } else {
          setConnectionStatus('error');
          addLog('error', `Arduino connection failed: ${arduino.getLastError()}`);
        }
      }
    } catch (error) {
      const err = error as Error;
      setConnectionStatus('error');
      addLog('error', `Connection error: ${err.message}`);
    }
  };
  
  const handleDisconnect = async () => {
    if (protocol) {
      await protocol.disconnect();
      setProtocol(null);
    }
    setConnectionStatus('disconnected');
    addLog('info', 'Disconnected');
  };
  
  const getModuleInfo = (): ModuleInfo => {
    return CHRYSLER_MODULES.find(m => m.code === selectedModule) || CHRYSLER_MODULES[0];
  };
  
  const readDTCs = async () => {
    if (!protocol) return;
    
    setIsScanning(true);
    setScanProgress(0);
    setDtcs([]);
    
    const mod = getModuleInfo();
    addLog('info', `=== Reading DTCs from ${mod.name} (${mod.code}) ===`);
    
    try {
      setScanProgress(10);
      
      addLog('info', '1. Entering Diagnostic Session...');
      const sessionRequest = [0x10, 0x01];
      
      let sessionResponse: Uint8Array | null = null;
      if (protocol instanceof ELM327Protocol) {
        sessionResponse = await protocol.sendUDS(mod.txId, mod.rxId, sessionRequest);
      } else if (protocol instanceof J2534Protocol) {
        sessionResponse = await protocol.sendUDS(mod.txId, mod.rxId, sessionRequest);
      } else if (protocol instanceof ArduinoCANProtocol) {
        sessionResponse = await protocol.sendUDS(mod.txId, mod.rxId, sessionRequest);
      }
      
      if (!sessionResponse || (sessionResponse[0] === 0x7F)) {
        addLog('warning', 'Session negotiation failed, continuing anyway...');
      } else {
        addLog('rx', `Session response: ${formatHexBytes(sessionResponse)}`);
      }
      
      setScanProgress(30);
      
      addLog('info', '2. Reading Confirmed DTCs (0x19 03)...');
      const confirmedRequest = [0x19, 0x02, 0xFF];
      addLog('tx', `Request: ${formatHexBytes(new Uint8Array(confirmedRequest))}`);
      
      let confirmedResponse: Uint8Array | null = null;
      if (protocol instanceof ELM327Protocol) {
        confirmedResponse = await protocol.sendUDS(mod.txId, mod.rxId, confirmedRequest);
      } else if (protocol instanceof J2534Protocol) {
        confirmedResponse = await protocol.sendUDS(mod.txId, mod.rxId, confirmedRequest);
      } else if (protocol instanceof ArduinoCANProtocol) {
        confirmedResponse = await protocol.sendUDS(mod.txId, mod.rxId, confirmedRequest);
      }
      
      setScanProgress(50);
      const foundDTCs: DTCInfo[] = [];
      
      if (confirmedResponse && confirmedResponse[0] === 0x59) {
        addLog('rx', `Response: ${formatHexBytes(confirmedResponse)}`);
        
        for (let i = 3; i < confirmedResponse.length - 2; i += 4) {
          if (i + 3 < confirmedResponse.length) {
            const byte1 = confirmedResponse[i];
            const byte2 = confirmedResponse[i + 1];
            const status = confirmedResponse[i + 2];
            
            if (byte1 !== 0x00 || byte2 !== 0x00) {
              const dtcCode = decodeDTC(byte1, byte2);
              const dtcInfo: DTCInfo = {
                code: dtcCode,
                status: status,
                statusDescription: getStatusDescription(status),
                description: getDTCDescription(dtcCode),
                severity: getDTCSeverity(dtcCode, status),
                confirmed: (status & 0x08) !== 0,
                pending: (status & 0x04) !== 0,
                permanent: false,
              };
              foundDTCs.push(dtcInfo);
              addLog('warning', `Found DTC: ${dtcCode} - ${dtcInfo.description}`);
            }
          }
        }
      } else if (confirmedResponse && confirmedResponse[0] === 0x7F) {
        const nrc = confirmedResponse[2];
        addLog('warning', `Read DTCs not supported (NRC: 0x${nrc.toString(16).toUpperCase().padStart(2, '0')})`);
      } else {
        addLog('warning', 'No confirmed DTCs or module does not support this service');
      }
      
      setScanProgress(70);
      
      addLog('info', '3. Reading Pending DTCs (0x19 07)...');
      const pendingRequest = [0x19, 0x07, 0xFF];
      
      let pendingResponse: Uint8Array | null = null;
      if (protocol instanceof ELM327Protocol) {
        pendingResponse = await protocol.sendUDS(mod.txId, mod.rxId, pendingRequest);
      } else if (protocol instanceof J2534Protocol) {
        pendingResponse = await protocol.sendUDS(mod.txId, mod.rxId, pendingRequest);
      } else if (protocol instanceof ArduinoCANProtocol) {
        pendingResponse = await protocol.sendUDS(mod.txId, mod.rxId, pendingRequest);
      }
      
      if (pendingResponse && pendingResponse[0] === 0x59) {
        addLog('rx', `Pending response: ${formatHexBytes(pendingResponse)}`);
        
        for (let i = 3; i < pendingResponse.length - 2; i += 4) {
          if (i + 3 < pendingResponse.length) {
            const byte1 = pendingResponse[i];
            const byte2 = pendingResponse[i + 1];
            const status = pendingResponse[i + 2];
            
            if (byte1 !== 0x00 || byte2 !== 0x00) {
              const dtcCode = decodeDTC(byte1, byte2);
              
              const existingIndex = foundDTCs.findIndex(d => d.code === dtcCode);
              if (existingIndex >= 0) {
                foundDTCs[existingIndex].pending = true;
              } else {
                const dtcInfo: DTCInfo = {
                  code: dtcCode,
                  status: status,
                  statusDescription: getStatusDescription(status),
                  description: getDTCDescription(dtcCode),
                  severity: 'info',
                  confirmed: false,
                  pending: true,
                  permanent: false,
                };
                foundDTCs.push(dtcInfo);
                addLog('info', `Found Pending DTC: ${dtcCode}`);
              }
            }
          }
        }
      }
      
      setScanProgress(100);
      setDtcs(foundDTCs);
      
      if (foundDTCs.length === 0) {
        addLog('success', '✓ No DTCs found - module is clear');
      } else {
        addLog('warning', `Found ${foundDTCs.length} DTC(s)`);
      }
      
    } catch (error) {
      const err = error as Error;
      addLog('error', `Error reading DTCs: ${err.message}`);
    }
    
    setIsScanning(false);
  };
  
  const clearDTCs = async () => {
    if (!protocol) return;
    
    setIsClearing(true);
    
    const mod = getModuleInfo();
    addLog('info', `=== Clearing DTCs from ${mod.name} (${mod.code}) ===`);
    
    try {
      addLog('info', '1. Entering Extended Diagnostic Session...');
      const sessionRequest = [0x10, 0x03];
      
      if (protocol instanceof ELM327Protocol) {
        await protocol.sendUDS(mod.txId, mod.rxId, sessionRequest);
      } else if (protocol instanceof J2534Protocol) {
        await protocol.sendUDS(mod.txId, mod.rxId, sessionRequest);
      } else if (protocol instanceof ArduinoCANProtocol) {
        await protocol.sendUDS(mod.txId, mod.rxId, sessionRequest);
      }
      
      await new Promise(r => setTimeout(r, 100));
      
      addLog('info', '2. Sending Clear DTC command (0x14)...');
      const clearRequest = [0x14, 0xFF, 0xFF, 0xFF];
      addLog('tx', `Request: ${formatHexBytes(new Uint8Array(clearRequest))}`);
      
      let response: Uint8Array | null = null;
      if (protocol instanceof ELM327Protocol) {
        response = await protocol.sendUDS(mod.txId, mod.rxId, clearRequest);
      } else if (protocol instanceof J2534Protocol) {
        response = await protocol.sendUDS(mod.txId, mod.rxId, clearRequest);
      } else if (protocol instanceof ArduinoCANProtocol) {
        response = await protocol.sendUDS(mod.txId, mod.rxId, clearRequest);
      }
      
      if (response) {
        addLog('rx', `Response: ${formatHexBytes(response)}`);
        
        if (response[0] === 0x54) {
          addLog('success', '✓ DTCs cleared successfully');
          setDtcs([]);
        } else if (response[0] === 0x7F) {
          const nrc = response[2];
          if (nrc === 0x22) {
            addLog('error', 'Conditions not correct - key may need to be in RUN position');
          } else if (nrc === 0x33) {
            addLog('error', 'Security access denied - try unlocking first');
          } else {
            addLog('error', `Clear DTCs rejected (NRC: 0x${nrc.toString(16).toUpperCase().padStart(2, '0')})`);
          }
        }
      } else {
        addLog('error', 'No response to clear command');
      }
      
    } catch (error) {
      const err = error as Error;
      addLog('error', `Error clearing DTCs: ${err.message}`);
    }
    
    setIsClearing(false);
  };
  
  const getLogTypeClass = (type: LogEntry['type']) => {
    switch (type) {
      case 'tx': return 'text-blue-400';
      case 'rx': return 'text-green-400';
      case 'success': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };
  
  const getSeverityBadge = (severity: DTCInfo['severity']) => {
    switch (severity) {
      case 'critical':
        return <Badge variant="destructive" className="ml-2">CRITICAL</Badge>;
      case 'warning':
        return <Badge variant="outline" className="ml-2 border-yellow-500 text-yellow-500">WARNING</Badge>;
      default:
        return <Badge variant="outline" className="ml-2 border-blue-500 text-blue-500">PENDING</Badge>;
    }
  };
  
  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-6xl mx-auto">
        <BackButton />
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon" data-testid="button-home">
                <Home className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-red-500 font-mono" data-testid="text-page-title">
                DTC READER/CLEARER
              </h1>
              <p className="text-sm text-gray-400">Read and clear diagnostic trouble codes</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge 
              variant={connectionStatus === 'connected' ? 'default' : 'outline'}
              className={connectionStatus === 'connected' ? 'bg-green-600' : ''}
              data-testid="badge-connection-status"
            >
              {connectionStatus === 'connected' ? (
                <><Check className="w-3 h-3 mr-1" /> Connected</>
              ) : connectionStatus === 'connecting' ? (
                <><Loader2 className="w-3 h-3 mr-1 animate-spin" /> Connecting...</>
              ) : connectionStatus === 'error' ? (
                <><X className="w-3 h-3 mr-1" /> Error</>
              ) : (
                'Disconnected'
              )}
            </Badge>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Usb className="w-4 h-4 text-green-400" />
                  HARDWARE CONNECTION
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <label className="text-xs text-gray-400">Interface Type</label>
                  <Select
                    value={hardwareType}
                    onValueChange={(v) => setHardwareType(v as HardwareType)}
                    disabled={connectionStatus === 'connected'}
                    data-testid="select-hardware-type"
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="elm327">
                        <div className="flex items-center gap-2">
                          <Usb className="w-4 h-4" /> ELM327 (USB/Bluetooth)
                        </div>
                      </SelectItem>
                      <SelectItem value="j2534">
                        <div className="flex items-center gap-2">
                          <Wifi className="w-4 h-4" /> J2534 PassThru
                        </div>
                      </SelectItem>
                      <SelectItem value="arduino">
                        <div className="flex items-center gap-2">
                          <Usb className="w-4 h-4" /> Arduino CAN Shield
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {connectionStatus === 'connected' ? (
                  <Button 
                    className="w-full" 
                    variant="destructive"
                    onClick={handleDisconnect}
                    data-testid="button-disconnect"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Disconnect
                  </Button>
                ) : (
                  <Button 
                    className="w-full"
                    onClick={handleConnect}
                    disabled={connectionStatus === 'connecting'}
                    data-testid="button-connect"
                  >
                    {connectionStatus === 'connecting' ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Usb className="w-4 h-4 mr-2" />
                    )}
                    Connect
                  </Button>
                )}
              </CardContent>
            </Card>
            
            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-blue-400" />
                  TARGET MODULE
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Select
                  value={selectedModule}
                  onValueChange={setSelectedModule}
                  data-testid="select-target-module"
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CHRYSLER_MODULES.map(mod => (
                      <SelectItem key={mod.code} value={mod.code}>
                        <div className="flex items-center justify-between gap-4">
                          <span className="font-mono">{mod.code}</span>
                          <span className="text-xs text-gray-400">{mod.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <div className="text-xs text-gray-400 font-mono">
                  TX: 0x{getModuleInfo().txId.toString(16).toUpperCase()} → 
                  RX: 0x{getModuleInfo().rxId.toString(16).toUpperCase()}
                </div>
              </CardContent>
            </Card>
            
            <Card className="border-white/10 border-red-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2 text-red-400">
                  <AlertTriangle className="w-4 h-4" />
                  DTC OPERATIONS
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full"
                  onClick={readDTCs}
                  disabled={connectionStatus !== 'connected' || isScanning}
                  data-testid="button-read-dtcs"
                >
                  {isScanning ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="w-4 h-4 mr-2" />
                  )}
                  Read DTCs
                </Button>
                
                {isScanning && (
                  <Progress value={scanProgress} className="h-2" />
                )}
                
                <Button 
                  className="w-full"
                  variant="destructive"
                  onClick={clearDTCs}
                  disabled={connectionStatus !== 'connected' || isClearing}
                  data-testid="button-clear-dtcs"
                >
                  {isClearing ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4 mr-2" />
                  )}
                  Clear DTCs
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="lg:col-span-2 space-y-4">
            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <CircleAlert className="w-4 h-4 text-yellow-400" />
                    DIAGNOSTIC TROUBLE CODES
                  </span>
                  <Badge variant="outline" data-testid="badge-dtc-count">
                    {dtcs.length} DTC{dtcs.length !== 1 ? 's' : ''}
                  </Badge>
                </CardTitle>
                <CardDescription className="text-xs text-gray-500">
                  Trouble codes from {getModuleInfo().name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  {dtcs.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-gray-500">
                      <Check className="w-12 h-12 mb-2 text-green-500/50" />
                      <p className="text-sm" data-testid="text-no-dtcs">No DTCs found</p>
                      <p className="text-xs" data-testid="text-scan-hint">Click the read button above to scan the module</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {dtcs.map((dtc, index) => (
                        <div 
                          key={`${dtc.code}-${index}`}
                          className={`p-3 rounded-lg border ${
                            dtc.severity === 'critical' ? 'border-red-500/50 bg-red-900/20' :
                            dtc.severity === 'warning' ? 'border-yellow-500/50 bg-yellow-900/20' :
                            'border-blue-500/50 bg-blue-900/20'
                          }`}
                          data-testid={`dtc-card-${dtc.code}`}
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center">
                                <span className="font-mono font-bold text-lg" data-testid={`text-dtc-code-${dtc.code}`}>
                                  {dtc.code}
                                </span>
                                {getSeverityBadge(dtc.severity)}
                                {dtc.confirmed && (
                                  <Badge variant="outline" className="ml-2 border-red-400 text-red-400">
                                    CONFIRMED
                                  </Badge>
                                )}
                                {dtc.pending && (
                                  <Badge variant="outline" className="ml-2 border-gray-400 text-gray-400">
                                    <Clock className="w-3 h-3 mr-1" />
                                    PENDING
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-gray-300 mt-1" data-testid={`text-dtc-desc-${dtc.code}`}>
                                {dtc.description}
                              </p>
                              <p className="text-xs text-gray-500 mt-1 font-mono">
                                Status: 0x{dtc.status.toString(16).toUpperCase().padStart(2, '0')} - {dtc.statusDescription}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
            
            <Card className="border-white/10">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  COMMUNICATION LOG
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px]">
                  <div className="space-y-1 font-mono text-xs">
                    {logs.map((log, i) => (
                      <div key={i} className={getLogTypeClass(log.type)}>
                        <span className="text-gray-600 mr-2">
                          {log.timestamp.toLocaleTimeString()}
                        </span>
                        <span className="mr-2">
                          {log.type === 'tx' ? '→' : log.type === 'rx' ? '←' : '●'}
                        </span>
                        {log.message}
                      </div>
                    ))}
                    {logs.length === 0 && (
                      <div className="text-gray-600">Ready for commands...</div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
