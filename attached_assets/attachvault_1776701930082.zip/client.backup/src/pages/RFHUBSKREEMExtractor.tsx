import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Upload, Shield, AlertCircle, Loader2, Copy, CheckCircle2, Database } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function RFHUBSKREEMExtractor() {
  const [memoryFile, setMemoryFile] = useState<File | null>(null);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const extractKeys = trpc.rfhub.extractSKREEMKeys.useMutation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMemoryFile(file);
      setError('');
      setResult(null);
    }
  };

  const handleExtract = async () => {
    if (!memoryFile) {
      setError('Please select a memory dump file');
      return;
    }

    try {
      const arrayBuffer = await memoryFile.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      let binary = '';
      for (let i = 0; i < uint8Array.length; i++) {
        binary += String.fromCharCode(uint8Array[i]);
      }
      const base64 = btoa(binary);

      const extractResult = await extractKeys.mutateAsync({
        memoryDumpBase64: base64,
      });

      if (extractResult.success) {
        setResult(extractResult);
        setError('');
      } else {
        setError('No security keys found in the file');
        setResult(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      setResult(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: 'Key data copied to clipboard',
    });
  };

  const getEntropyColor = (entropy: number) => {
    if (entropy >= 7.5) return 'text-green-600 dark:text-green-400';
    if (entropy >= 7.0) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getEntropyLabel = (entropy: number) => {
    if (entropy >= 7.5) return 'High Quality';
    if (entropy >= 7.0) return 'Good';
    return 'Low Quality';
  };

  return (
    <div className="container py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">RFHUB SKREEM Key Extractor</h1>
        <p className="text-muted-foreground">
          Extract security keys from RFHUB memory dumps using entropy analysis
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload Memory Dump</CardTitle>
          <CardDescription>
            Select your RFHUB memory dump file to extract security keys
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="memory-file">Memory Dump File</Label>
            <div className="flex gap-2">
              <Input
                id="memory-file"
                type="file"
                accept=".bin,.dump,.mem,.eee"
                onChange={handleFileChange}
                className="flex-1"
              />
              {memoryFile && (
                <Badge variant="outline" className="flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  {memoryFile.name}
                </Badge>
              )}
            </div>
          </div>

          <Button
            onClick={handleExtract}
            disabled={!memoryFile || extractKeys.isPending}
            className="w-full"
          >
            {extractKeys.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Extracting...
              </>
            ) : (
              <>
                <Shield className="mr-2 h-4 w-4" />
                Extract Security Keys
              </>
            )}
          </Button>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {result && (
            <div className="space-y-4">
              <Alert className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-900 dark:text-green-100">
                  <p className="font-semibold">
                    Found {result.totalKeys} security key(s) with high entropy (≥7.0)
                  </p>
                </AlertDescription>
              </Alert>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Extracted Security Keys
                  </CardTitle>
                  <CardDescription>
                    High-entropy blocks found near security markers
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {result.keys.map((key: any, idx: number) => (
                      <div
                        key={idx}
                        className="p-4 border rounded-lg space-y-3 hover:bg-accent"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline">{key.markerName}</Badge>
                            <Badge variant="secondary">{key.keySize} bytes</Badge>
                            <Badge
                              variant="outline"
                              className={getEntropyColor(key.entropy)}
                            >
                              Entropy: {key.entropy} ({getEntropyLabel(key.entropy)})
                            </Badge>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => copyToClipboard(key.keyData)}
                          >
                            <Copy className="h-3 w-3 mr-1" />
                            Copy
                          </Button>
                        </div>

                        <div className="space-y-1">
                          <div className="text-xs text-muted-foreground">
                            Marker Offset: 0x{key.markerOffset.toString(16).toUpperCase().padStart(4, '0')} | 
                            Key Offset: 0x{key.keyOffset.toString(16).toUpperCase().padStart(4, '0')}
                          </div>
                          <div className="font-mono text-xs bg-muted p-2 rounded break-all">
                            {key.keyData}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-lg">How It Works</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div>
            <span className="font-semibold">Security Markers Searched:</span>
            <ul className="list-disc list-inside ml-4 mt-1 text-muted-foreground">
              <li>SKEY - Secret Key</li>
              <li>SECR - Security Data</li>
              <li>IMMO - Immobilizer</li>
              <li>AUTH - Authentication</li>
              <li>SKRM - SKREEM</li>
              <li>SKIM - SKIM</li>
            </ul>
          </div>
          <div>
            <span className="font-semibold">Entropy Analysis:</span>
            <p className="ml-4 mt-1 text-muted-foreground">
              Shannon entropy measures randomness (0.0 to 8.0). High entropy (≥7.0) indicates
              encrypted or cryptographic data. The tool searches for high-entropy blocks near
              security markers, checking common key sizes: 8, 16, 32, 64, and 128 bytes.
            </p>
          </div>
          <div>
            <span className="font-semibold">Key Sizes Checked:</span>
            <ul className="list-disc list-inside ml-4 mt-1 text-muted-foreground">
              <li>8 bytes - DES keys</li>
              <li>16 bytes - AES-128 keys</li>
              <li>32 bytes - AES-256 keys</li>
              <li>64 bytes - Extended keys</li>
              <li>128 bytes - Key blocks</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
