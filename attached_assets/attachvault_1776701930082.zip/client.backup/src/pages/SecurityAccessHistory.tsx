import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { History, CheckCircle2, XCircle, TrendingUp } from "lucide-react";

export default function SecurityAccessHistory() {
  const { data: logs, isLoading } = trpc.securityAccessLog.list.useQuery({ limit: 100 });
  const { data: stats } = trpc.securityAccessLog.stats.useQuery();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <History className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">SECURITY ACCESS HISTORY</h1>
            <p className="text-gray-600">
              Track all seed-key calculations and success rates by algorithm
            </p>
          </div>
        </div>

        {stats && (
          <div className="grid md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">Total Attempts</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">{stats.total}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">Successful</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-green-600">{stats.successful}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">Failed</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-red-600">{stats.failed}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">Success Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <p className="text-3xl font-bold">{stats.successRate.toFixed(1)}%</p>
                  <TrendingUp className="h-5 w-5 text-green-600" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {stats && Object.keys(stats.byAlgorithm).length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Success Rate by Algorithm</CardTitle>
              <CardDescription>Performance breakdown for each security access method</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(stats.byAlgorithm).map(([algorithm, data]) => {
                  const successRate = data.total > 0 ? (data.successful / data.total) * 100 : 0;
                  return (
                    <div key={algorithm} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div className="flex-1">
                        <p className="font-medium">{algorithm}</p>
                        <p className="text-sm text-gray-600">
                          {data.successful} / {data.total} successful
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-600 h-2 rounded-full"
                            style={{ width: `${successRate}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium w-12 text-right">
                          {successRate.toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Recent Calculations</CardTitle>
            <CardDescription>Last 100 security access attempts</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-gray-600">Loading...</p>
            ) : logs && logs.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-2 text-left">Time</th>
                      <th className="p-2 text-left">Algorithm</th>
                      <th className="p-2 text-left">Level</th>
                      <th className="p-2 text-left">Module</th>
                      <th className="p-2 text-left font-mono">Seed</th>
                      <th className="p-2 text-left font-mono">Key</th>
                      <th className="p-2 text-left">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map((log) => (
                      <tr key={log.id} className="border-b hover:bg-gray-50">
                        <td className="p-2">
                          {new Date(log.createdAt).toLocaleString()}
                        </td>
                        <td className="p-2">
                          <Badge variant="outline">{log.algorithm}</Badge>
                        </td>
                        <td className="p-2">{log.securityLevel || "N/A"}</td>
                        <td className="p-2">{log.moduleCode || "N/A"}</td>
                        <td className="p-2 font-mono text-xs">{log.seed}</td>
                        <td className="p-2 font-mono text-xs">{log.calculatedKey}</td>
                        <td className="p-2">
                          {log.success ? (
                            <Badge className="bg-green-600">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Success
                            </Badge>
                          ) : (
                            <Badge variant="destructive">
                              <XCircle className="h-3 w-3 mr-1" />
                              Failed
                            </Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-600">No security access history yet</p>
            )}
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">About Security Access Logging</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-900 space-y-2">
            <p>• All seed-key calculations are automatically logged for analysis</p>
            <p>• Track which algorithms work best for specific module types</p>
            <p>• Identify patterns in successful vs failed attempts</p>
            <p>• Use success rate data to optimize security access strategies</p>
            <p>• History helps diagnose authentication issues with specific modules</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
