import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { 
  Cpu, 
  Usb, 
  Wifi, 
  RefreshCw, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Settings,
  Info
} from 'lucide-react';

interface HardwareDevice {
  id: string;
  type: 'j2534' | 'arduino' | 'elm327' | 'webserial';
  name: string;
  status: 'connected' | 'disconnected' | 'connecting' | 'error';
  port?: string;
  baudRate?: number;
  firmwareVersion?: string;
  lastSeen?: Date;
  capabilities?: string[];
}

export default function HardwareIntegrationDashboard() {
  const [devices, setDevices] = useState<HardwareDevice[]>([]);
  const [scanning, setScanning] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<HardwareDevice | null>(null);

  // Real device detection
  const scanForDevices = async () => {
    setScanning(true);
    const detectedDevices: HardwareDevice[] = [];

    try {
      // Check WebSerial API availability
      if ('serial' in navigator) {
        try {
          const ports = await (navigator as any).serial.getPorts();
          
          for (const port of ports) {
            const info = port.getInfo();
            const { ConnectionManager } = await import('@/lib/obd2-protocol');
            const connMgr = new ConnectionManager();
            const state = connMgr.getState();
            
            // Try to identify device type by vendor/product ID
            let deviceType: HardwareDevice['type'] = 'webserial';
            let deviceName = 'Unknown Serial Device';
            let capabilities: string[] = ['UDS', 'CAN'];
            
            // OBDLink vendor IDs
            if (info.usbVendorId === 0x0403 || info.usbVendorId === 0x1A86) {
              deviceType = 'j2534';
              deviceName = 'OBDLink Adapter';
              capabilities = ['J2534', 'PassThru', 'UDS', 'CAN', 'ISO15765-4'];
            }
            // Arduino vendor IDs
            else if (info.usbVendorId === 0x2341 || info.usbVendorId === 0x1A86) {
              deviceType = 'arduino';
              deviceName = 'Arduino CAN Bridge';
              capabilities = ['CAN', 'Dual-Bus', 'Passive-Sniffing'];
            }
            // ELM327 clones
            else if (info.usbVendorId === 0x10C4) {
              deviceType = 'elm327';
              deviceName = 'ELM327 Adapter';
              capabilities = ['OBD2', 'CAN', 'ISO15765-4'];
            }
            
            detectedDevices.push({
              id: `serial-${info.usbVendorId}-${info.usbProductId}`,
              type: deviceType,
              name: deviceName,
              status: state === 'connected' ? 'connected' : 'disconnected',
              capabilities,
              lastSeen: new Date()
            });
          }
        } catch (error) {
          console.warn('WebSerial port enumeration failed:', error);
        }
      }

      // Check J2534 bridge (via WebSocket if available)
      try {
        const ws = new WebSocket('ws://localhost:8080/j2534');
        await new Promise((resolve, reject) => {
          ws.onopen = resolve;
          ws.onerror = reject;
          setTimeout(reject, 1000); // 1s timeout
        });
        
        detectedDevices.push({
          id: 'j2534-bridge',
          type: 'j2534',
          name: 'J2534 PassThru Bridge',
          status: 'connected',
          capabilities: ['J2534', 'PassThru', 'UDS', 'CAN', 'ISO14230', 'ISO9141'],
          lastSeen: new Date()
        });
        
        ws.close();
      } catch (error) {
        // J2534 bridge not available
      }

      // If no devices found, show WebSerial as available option
      if (detectedDevices.length === 0 && 'serial' in navigator) {
        detectedDevices.push({
          id: 'webserial-available',
          type: 'webserial',
          name: 'WebSerial API (Click to connect)',
          status: 'disconnected',
          capabilities: ['UDS', 'CAN', 'ISO15765-4'],
          lastSeen: new Date()
        });
      }

    } catch (error) {
      console.error('Device scan failed:', error);
    }

    setDevices(detectedDevices);
    setScanning(false);
  };

  useEffect(() => {
    scanForDevices();
  }, []);

  const getStatusIcon = (status: HardwareDevice['status']) => {
    switch (status) {
      case 'connected':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'disconnected':
        return <XCircle className="h-5 w-5 text-gray-400" />;
      case 'connecting':
        return <RefreshCw className="h-5 w-5 text-yellow-500 animate-spin" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
    }
  };

  const getStatusBadge = (status: HardwareDevice['status']) => {
    const variants: Record<HardwareDevice['status'], 'default' | 'secondary' | 'destructive' | 'outline'> = {
      connected: 'default',
      disconnected: 'secondary',
      connecting: 'outline',
      error: 'destructive'
    };

    const labels: Record<HardwareDevice['status'], string> = {
      connected: '🟢 Connected',
      disconnected: '🔴 Disconnected',
      connecting: '🟡 Connecting',
      error: '❌ Error'
    };

    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    );
  };

  const getDeviceIcon = (type: HardwareDevice['type']) => {
    switch (type) {
      case 'j2534':
        return <Usb className="h-8 w-8 text-blue-500" />;
      case 'arduino':
        return <Cpu className="h-8 w-8 text-purple-500" />;
      case 'elm327':
        return <Wifi className="h-8 w-8 text-green-500" />;
      case 'webserial':
        return <Cpu className="h-8 w-8 text-cyan-500" />;
    }
  };

  const connectToDevice = async (device: HardwareDevice) => {
    setDevices(prev => prev.map(d => 
      d.id === device.id ? { ...d, status: 'connecting' } : d
    ));

    // Simulate connection delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    setDevices(prev => prev.map(d => 
      d.id === device.id ? { ...d, status: 'connected', lastSeen: new Date() } : d
    ));
  };

  const disconnectFromDevice = async (device: HardwareDevice) => {
    setDevices(prev => prev.map(d => 
      d.id === device.id ? { ...d, status: 'disconnected' } : d
    ));
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Hardware Integration Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">
            Manage and monitor all connected diagnostic hardware devices
          </p>
        </div>
        <Button onClick={scanForDevices} disabled={scanning}>
          <RefreshCw className={`mr-2 h-4 w-4 ${scanning ? 'animate-spin' : ''}`} />
          {scanning ? 'Scanning...' : 'Scan Devices'}
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Devices</p>
              <p className="text-3xl font-bold">{devices.length}</p>
            </div>
            <Cpu className="h-8 w-8 text-muted-foreground" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Connected</p>
              <p className="text-3xl font-bold text-green-500">
                {devices.filter(d => d.status === 'connected').length}
              </p>
            </div>
            <CheckCircle2 className="h-8 w-8 text-green-500" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Disconnected</p>
              <p className="text-3xl font-bold text-gray-400">
                {devices.filter(d => d.status === 'disconnected').length}
              </p>
            </div>
            <XCircle className="h-8 w-8 text-gray-400" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Errors</p>
              <p className="text-3xl font-bold text-red-500">
                {devices.filter(d => d.status === 'error').length}
              </p>
            </div>
            <AlertCircle className="h-8 w-8 text-red-500" />
          </div>
        </Card>
      </div>

      {/* WebSerial Info Alert */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>WebSerial API:</strong> The SRT Lab supports direct browser-to-OBD2 communication via WebSerial API. 
          No additional software or drivers required! Just connect your OBD2 adapter and click "Connect" on any WebSerial device.
        </AlertDescription>
      </Alert>

      {/* Device List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {devices.map(device => (
          <Card key={device.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="space-y-4">
              {/* Device Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  {getDeviceIcon(device.type)}
                  <div>
                    <h3 className="text-xl font-semibold">{device.name}</h3>
                    <p className="text-sm text-muted-foreground capitalize">{device.type} Device</p>
                  </div>
                </div>
                {getStatusIcon(device.status)}
              </div>

              <Separator />

              {/* Device Details */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Status:</span>
                  {getStatusBadge(device.status)}
                </div>

                {device.port && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Port:</span>
                    <span className="text-sm font-mono">{device.port}</span>
                  </div>
                )}

                {device.baudRate && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Baud Rate:</span>
                    <span className="text-sm font-mono">{device.baudRate.toLocaleString()} bps</span>
                  </div>
                )}

                {device.firmwareVersion && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Firmware:</span>
                    <span className="text-sm font-mono">v{device.firmwareVersion}</span>
                  </div>
                )}

                {device.lastSeen && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Last Seen:</span>
                    <span className="text-sm">{device.lastSeen.toLocaleTimeString()}</span>
                  </div>
                )}
              </div>

              {/* Capabilities */}
              {device.capabilities && device.capabilities.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Capabilities:</p>
                    <div className="flex flex-wrap gap-2">
                      {device.capabilities.map(cap => (
                        <Badge key={cap} variant="outline">{cap}</Badge>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                {device.status === 'connected' ? (
                  <Button 
                    variant="destructive" 
                    className="flex-1"
                    onClick={() => disconnectFromDevice(device)}
                  >
                    <XCircle className="mr-2 h-4 w-4" />
                    Disconnect
                  </Button>
                ) : (
                  <Button 
                    variant="default" 
                    className="flex-1"
                    onClick={() => connectToDevice(device)}
                    disabled={device.status === 'connecting' || device.status === 'error'}
                  >
                    {device.status === 'connecting' ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="mr-2 h-4 w-4" />
                        Connect
                      </>
                    )}
                  </Button>
                )}
                <Button 
                  variant="outline"
                  onClick={() => setSelectedDevice(device)}
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* No Devices Found */}
      {devices.length === 0 && !scanning && (
        <Card className="p-12 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No Devices Found</h3>
          <p className="text-muted-foreground mb-4">
            Connect a diagnostic device and click "Scan Devices" to detect it.
          </p>
          <Button onClick={scanForDevices}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Scan Again
          </Button>
        </Card>
      )}
    </div>
  );
}
