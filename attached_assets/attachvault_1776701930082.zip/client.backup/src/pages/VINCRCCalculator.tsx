import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { Copy, Calculator, Info, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type ModuleType = "rfhub" | "bcm";

interface CRCResult {
  vin: string;
  module: string;
  crc: string;
  algorithm: string;
  validated: boolean;
}

// Production VIN CRC lookup table from SRT Lab Toolkit toolkit
const PRODUCTION_VINS: Record<string, { rfhub: string; bcm: string }> = {
  "2C3CDXKT3FH796320": { rfhub: "0x9B", bcm: "0x589B" },
  "2B3CJ4DV6AH300549": { rfhub: "0x5B", bcm: "0x8C5B" },
  "2B3CJ5DT2BH590794": { rfhub: "0x5D", bcm: "0x535D" },
  "2C3CDZFK3HH506737": { rfhub: "0xDE", bcm: "0x71DE" },
  "2C3CDZC99HH514330": { rfhub: "0x89", bcm: "0x1189" },
  "2C3CDXGJ1MH539855": { rfhub: "0x08", bcm: "0x5F08" },
};

export default function VINCRCCalculator() {
  const [vin, setVin] = useState<string>("");
  const [moduleType, setModuleType] = useState<ModuleType>("rfhub");
  const [crcResult, setCrcResult] = useState<CRCResult | null>(null);
  const [error, setError] = useState<string>("");
  const { toast } = useToast();

  /**
   * Calculate RFHUB checksum (Complement)
   * 8-bit one's complement of sum
   */
  const calculateRFHUBChecksum = (vinBytes: number[]): number => {
    const sum = vinBytes.reduce((acc, byte) => acc + byte, 0);
    const checksum = sum & 0xFF;
    return (~checksum) & 0xFF; // One's complement
  };

  /**
   * Calculate BCM CRC-16/CCITT-FALSE
   * 16-bit CRC with polynomial 0x1021
   */
  const calculateBCMCRC16 = (vinBytes: number[]): number => {
    let crc = 0xFFFF;
    
    for (const byte of vinBytes) {
      crc ^= (byte << 8);
      for (let i = 0; i < 8; i++) {
        if (crc & 0x8000) {
          crc = (crc << 1) ^ 0x1021;
        } else {
          crc <<= 1;
        }
        crc &= 0xFFFF;
      }
    }
    
    return crc;
  };

  const handleCalculate = () => {
    setError("");
    setCrcResult(null);

    // Validate VIN
    if (!vin.trim()) {
      setError("Please enter a VIN");
      return;
    }

    const cleanVIN = vin.trim().toUpperCase();

    if (cleanVIN.length !== 17) {
      setError("VIN must be exactly 17 characters");
      return;
    }

    if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(cleanVIN)) {
      setError("Invalid VIN format (no I, O, Q allowed)");
      return;
    }

    try {
      // Convert VIN to bytes
      const vinBytes: number[] = [];
      for (let i = 0; i < cleanVIN.length; i++) {
        vinBytes.push(cleanVIN.charCodeAt(i));
      }

      let crc: number;
      let algorithm: string;

      if (moduleType === "rfhub") {
        crc = calculateRFHUBChecksum(vinBytes);
        algorithm = "One's Complement (8-bit)";
      } else {
        crc = calculateBCMCRC16(vinBytes);
        algorithm = "CRC-16/CCITT-FALSE";
      }

      // Check against production database
      const productionData = PRODUCTION_VINS[cleanVIN];
      let validated = false;

      if (productionData) {
        const expectedCRC = moduleType === "rfhub" 
          ? parseInt(productionData.rfhub, 16)
          : parseInt(productionData.bcm, 16);
        
        validated = crc === expectedCRC;
      }

      const result: CRCResult = {
        vin: cleanVIN,
        module: moduleType.toUpperCase(),
        crc: moduleType === "rfhub" 
          ? `0x${crc.toString(16).toUpperCase().padStart(2, "0")}`
          : `0x${crc.toString(16).toUpperCase().padStart(4, "0")}`,
        algorithm,
        validated,
      };

      setCrcResult(result);

      toast({
        title: "CRC Calculated",
        description: validated ? "Validated against production database" : "Calculation complete",
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Calculation failed");
    }
  };

  const handleCopyCRC = () => {
    if (crcResult) {
      navigator.clipboard.writeText(crcResult.crc);
      toast({
        title: "Copied",
        description: "CRC copied to clipboard",
      });
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">VIN CRC Calculator</h1>
        <p className="text-muted-foreground">
          Calculate VIN checksums for RFHUB and BCM modules using production algorithms
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              CRC Calculator
            </CardTitle>
            <CardDescription>Enter VIN and select module type</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* VIN Input */}
            <div className="space-y-2">
              <Label>Vehicle Identification Number (VIN)</Label>
              <Input
                placeholder="2C3CDXKT3FH796320"
                value={vin}
                onChange={(e) => setVin(e.target.value.toUpperCase())}
                maxLength={17}
                className="font-mono text-lg"
              />
              <p className="text-xs text-muted-foreground">
                Enter 17-character VIN (no I, O, Q)
              </p>
            </div>

            {/* Module Selector */}
            <div className="space-y-2">
              <Label>Module Type</Label>
              <Select value={moduleType} onValueChange={(v) => setModuleType(v as ModuleType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rfhub">RFHUB (8-bit Complement)</SelectItem>
                  <SelectItem value="bcm">BCM (16-bit CRC-16)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Calculate Button */}
            <Button onClick={handleCalculate} className="w-full">
              <Calculator className="h-4 w-4 mr-2" />
              Calculate CRC
            </Button>

            {/* Error Display */}
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Result Display */}
            {crcResult && (
              <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    Calculated CRC
                    {crcResult.validated && (
                      <Badge variant="default" className="ml-auto">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Validated
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* CRC Value */}
                  <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-900 rounded-lg border">
                    <div>
                      <p className="text-sm text-muted-foreground">CRC Checksum</p>
                      <p className="text-2xl font-mono font-bold">{crcResult.crc}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Decimal: {parseInt(crcResult.crc, 16)}
                      </p>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleCopyCRC}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>

                  {/* Details */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">VIN</p>
                      <p className="font-mono">{crcResult.vin}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Module</p>
                      <Badge variant="outline">{crcResult.module}</Badge>
                    </div>
                    <div className="col-span-2">
                      <p className="text-muted-foreground">Algorithm</p>
                      <p className="font-mono text-xs">{crcResult.algorithm}</p>
                    </div>
                  </div>

                  {crcResult.validated && (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        CRC validated against production database
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Info Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Info className="h-5 w-5" />
                Algorithm Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">RFHUB Checksum</p>
                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded border border-blue-200 dark:border-blue-800">
                  <p className="font-mono text-xs">
                    checksum = ~(sum(vin_bytes)) & 0xFF
                  </p>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  8-bit one's complement
                </p>
              </div>
              <div>
                <p className="text-sm font-medium mb-2">BCM CRC-16</p>
                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded border border-blue-200 dark:border-blue-800">
                  <p className="font-mono text-xs">
                    CRC-16/CCITT-FALSE
                  </p>
                  <p className="font-mono text-xs">
                    Polynomial: 0x1021
                  </p>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  16-bit big-endian
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Production Database</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                {Object.keys(PRODUCTION_VINS).length} validated VINs from SRT Lab Toolkit toolkit
              </p>
              <div className="space-y-2 text-xs">
                {Object.entries(PRODUCTION_VINS).slice(0, 3).map(([vin, crcs]) => (
                  <div key={vin} className="p-2 bg-muted rounded">
                    <p className="font-mono font-medium">{vin}</p>
                    <div className="flex gap-4 mt-1 text-muted-foreground">
                      <span>RFHUB: {crcs.rfhub}</span>
                      <span>BCM: {crcs.bcm}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">VIN Offsets</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <p className="font-medium">RFHUB</p>
                <div className="text-xs text-muted-foreground space-y-1 mt-1">
                  <p>• Primary: 0x000EA5</p>
                  <p>• Backup 1: 0x000EB9</p>
                  <p>• Backup 2: 0x000ECD</p>
                  <p>• Backup 3: 0x000EE1</p>
                </div>
              </div>
              <div>
                <p className="font-medium">BCM</p>
                <div className="text-xs text-muted-foreground space-y-1 mt-1">
                  <p>• Primary: 0x0098</p>
                  <p>• Backup: 0x00B0</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Production VIN Table */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Production VIN Database</CardTitle>
          <CardDescription>
            Validated VINs with known CRC values from SRT Lab Toolkit toolkit
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">VIN</th>
                  <th className="text-left p-2">RFHUB CRC</th>
                  <th className="text-left p-2">BCM CRC</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(PRODUCTION_VINS).map(([vin, crcs]) => (
                  <tr key={vin} className="border-b hover:bg-muted/50">
                    <td className="p-2 font-mono">{vin}</td>
                    <td className="p-2 font-mono">{crcs.rfhub}</td>
                    <td className="p-2 font-mono">{crcs.bcm}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
