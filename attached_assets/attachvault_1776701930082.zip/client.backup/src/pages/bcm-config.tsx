import { useState, useCallback, useRef } from 'react';
import { Link } from 'wouter';
// Backend functions will use tRPC instead
import { trpc } from '@/lib/trpc';

// Helper function to convert bytes to hex
function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
}
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { BackButton } from "@/components/BackButton";
import { 
  Home, 
  Usb, 
  CheckCircle,
  XCircle,
  Lock,
  Unlock,
  Car,
  Lightbulb,
  Shield,
  Thermometer,
  Volume2,
  Droplets,
  Square,
  Eye,
  Gauge,
  Settings,
  ChevronDown,
  Loader2,
  AlertTriangle,
  Zap,
  RefreshCw,
  Info
} from 'lucide-react';
import { 
  BCM_FEATURE_PRESETS, 
  BCM_FEATURE_CATEGORIES,
  getPresetsByCategory,
  type BCMFeaturePreset,
  type BCMFeatureCategory
} from '@shared/bcm-presets';
import { 
  ELM327Protocol, 
  ArduinoCANProtocol,
  NRC_DESCRIPTIONS,
} from '@shared/obd2-protocol';
import { generateKey } from '@shared/fca-keygen';

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';
type OperationStatus = 'idle' | 'loading' | 'success' | 'error';

interface FeatureState {
  currentValue: number | null;
  pendingValue: number | null;
  isReading: boolean;
  isWriting: boolean;
  error: string | null;
  nrc?: number;
  nrcDescription?: string;
  success: boolean;
}

interface StatusMessageData {
  type: 'success' | 'error' | 'info' | 'warning';
  text: string;
  nrc?: number;
  nrcDetail?: string;
}

const CATEGORY_ICONS: Record<BCMFeatureCategory, React.ReactNode> = {
  'Lighting': <Lightbulb className="w-5 h-5" />,
  'Locks & Security': <Shield className="w-5 h-5" />,
  'Comfort Features': <Thermometer className="w-5 h-5" />,
  'Horn & Sounds': <Volume2 className="w-5 h-5" />,
  'Wipers': <Droplets className="w-5 h-5" />,
  'Windows': <Square className="w-5 h-5" />,
  'Mirrors': <Eye className="w-5 h-5" />,
  'Engine & Start': <Gauge className="w-5 h-5" />,
  'Display': <Settings className="w-5 h-5" />,
  'Performance & Variant': <Zap className="w-5 h-5" />,
  'Other': <Settings className="w-5 h-5" />,
};

// Helper function to create a timeout promise
function withTimeout<T>(promise: Promise<T>, timeoutMs: number, operation: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error(`${operation} timed out after ${timeoutMs}ms`)), timeoutMs)
    ),
  ]);
}

// Helper function to parse NRC responses and provide user-friendly error messages
function getNRCDescription(nrc: number): { short: string; detail: string; actionable: string } {
  const desc = NRC_DESCRIPTIONS[nrc];
  if (desc) {
    return desc;
  }
  return {
    short: `Unknown NRC 0x${nrc.toString(16).toUpperCase()}`,
    detail: 'An unknown error code was received from the ECU',
    actionable: 'Check the module documentation for this error code'
  };
}

export default function BCMConfig() {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [securityUnlocked, setSecurityUnlocked] = useState(false);
  const [protocol, setProtocol] = useState<ELM327Protocol | ArduinoCANProtocol | null>(null);
  const [serialPort, setSerialPort] = useState<SerialPort | null>(null);
  const [featureStates, setFeatureStates] = useState<Map<string, FeatureState>>(new Map());
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [statusMessage, setStatusMessage] = useState<StatusMessageData | null>(null);
  const [configData, setConfigData] = useState<Uint8Array | null>(null);
  const [configLoadStatus, setConfigLoadStatus] = useState<OperationStatus>('idle');
  const [unlockStatus, setUnlockStatus] = useState<OperationStatus>('idle');
  const statusMessageTimeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

  const BCM_TX = 0x720;
  const BCM_RX = 0x728;
  const UDS_TIMEOUT = 5000; // 5 seconds for UDS operations

  const addLog = useCallback((message: string) => {
    console.log(`[BCM] ${message}`);
  }, []);

  const setStatusWithAutoClose = useCallback((message: StatusMessageData, autoCloseDuration = 5000) => {
    if (statusMessageTimeoutRef.current) {
      clearTimeout(statusMessageTimeoutRef.current);
    }
    setStatusMessage(message);
    
    if (message.type === 'success' || message.type === 'info') {
      statusMessageTimeoutRef.current = setTimeout(() => {
        setStatusMessage(null);
      }, autoCloseDuration);
    }
  }, []);

  const handleConnect = async () => {
    if (connectionStatus === 'connected') {
      if (serialPort) {
        try {
          await serialPort.close();
        } catch (e) {
          console.error('Error closing port:', e);
        }
      }
      setProtocol(null);
      setSerialPort(null);
      setConnectionStatus('disconnected');
      setSecurityUnlocked(false);
      setConfigData(null);
      setConfigLoadStatus('idle');
      setStatusWithAutoClose({ type: 'info', text: 'Disconnected from BCM' });
      return;
    }

    setConnectionStatus('connecting');
    setStatusWithAutoClose({ type: 'info', text: 'Connecting to hardware...' }, 10000);

    try {
      const port = await navigator.serial.requestPort();
      await port.open({ baudRate: 115200 });
      setSerialPort(port);

      const elm = new ELM327Protocol();
      const connected = await elm.connectToPort(port);
      if (!connected) {
        throw new Error('Failed to initialize ELM327 adapter');
      }
      setProtocol(elm);
      
      setConnectionStatus('connected');
      setStatusWithAutoClose({ 
        type: 'success', 
        text: 'Connected to BCM at 0x720/0x728' 
      });
      addLog('Connected to ELM327 - BCM ready for communication');
    } catch (error) {
      console.error('Connection error:', error);
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setConnectionStatus('error');
      setStatusWithAutoClose({ 
        type: 'error', 
        text: `Connection failed: ${errorMsg}` 
      }, 0);
      addLog(`Connection failed: ${errorMsg}`);
    }
  };

  const handleUnlock = async () => {
    if (!protocol || connectionStatus !== 'connected') {
      setStatusWithAutoClose({ type: 'error', text: 'Not connected to BCM' }, 0);
      return;
    }

    setUnlockStatus('loading');
    setStatusWithAutoClose({ type: 'info', text: 'Unlocking BCM...' }, 10000);

    try {
      // Step 1: Enter Diagnostic Session (0x10, 0x03)
      addLog('Entering diagnostic session (0x10 0x03)...');
      const sessionRequest = [0x10, 0x03];
      const sessionResponse = await withTimeout(
        protocol.sendUDS(BCM_TX, BCM_RX, sessionRequest),
        UDS_TIMEOUT,
        'Diagnostic session'
      );
      
      if (!sessionResponse || sessionResponse[0] === 0x7F) {
        const nrc = sessionResponse?.[2];
        const nrcDesc = nrc ? getNRCDescription(nrc) : null;
        throw new Error(`Failed to enter diagnostic session${nrcDesc ? `: ${nrcDesc.short}` : ''}`);
      }
      
      if (sessionResponse[0] !== 0x50) {
        throw new Error(`Unexpected session response: 0x${sessionResponse[0].toString(16).toUpperCase()}`);
      }

      addLog('Diagnostic session entered successfully');

      // Step 2: Request Security Seed (0x27, 0x01)
      addLog('Requesting security seed (0x27 0x01)...');
      const seedRequest = [0x27, 0x01];
      const seedResponse = await withTimeout(
        protocol.sendUDS(BCM_TX, BCM_RX, seedRequest),
        UDS_TIMEOUT,
        'Security seed request'
      );
      
      if (!seedResponse) {
        throw new Error('No response from BCM during seed request');
      }

      if (seedResponse[0] === 0x7F) {
        const nrc = seedResponse[2];
        const nrcDesc = getNRCDescription(nrc);
        if (nrc === 0x37) {
          throw new Error('Security locked out - wait 10 seconds before retrying');
        }
        throw new Error(`Failed to get security seed: ${nrcDesc.short} - ${nrcDesc.actionable}`);
      }
      
      if (seedResponse[0] !== 0x67) {
        throw new Error(`Unexpected seed response: 0x${seedResponse[0].toString(16).toUpperCase()}`);
      }

      const seed = seedResponse.slice(2);
      addLog(`Got security seed: ${Array.from(seed).map(b => b.toString(16).padStart(2, '0')).join(' ')}`);

      // Step 3: Calculate and Send Security Key (0x27, 0x02)
      const key = generateKey(seed, 1); // Level 1 = CDA Engineering (0x4B92)
      addLog(`Calculated security key: ${Array.from(key).map((b: number) => b.toString(16).padStart(2, '0')).join(' ')}`);

      const keyRequest = [0x27, 0x02, ...Array.from(key)];
      const keyResponse = await withTimeout(
        protocol.sendUDS(BCM_TX, BCM_RX, keyRequest),
        UDS_TIMEOUT,
        'Security key send'
      );
      
      if (!keyResponse) {
        throw new Error('No response from BCM during key send');
      }

      if (keyResponse[0] === 0x7F) {
        const nrc = keyResponse[2];
        const nrcDesc = getNRCDescription(nrc);
        throw new Error(`Security key rejected: ${nrcDesc.short} - ${nrcDesc.actionable}`);
      }

      if (keyResponse[0] !== 0x67 || keyResponse[1] !== 0x02) {
        throw new Error(`Unexpected key response: 0x${keyResponse[0].toString(16).toUpperCase()}`);
      }

      setSecurityUnlocked(true);
      setUnlockStatus('success');
      addLog('Security unlocked - reading configuration...');

      // Note: Audit log would use tRPC here in production

      // Step 4: Read Configuration Block
      await readConfigBlock();
      
      setStatusWithAutoClose({ 
        type: 'success', 
        text: 'BCM Unlocked - Configuration loaded and ready to program' 
      });
    } catch (error) {
      console.error('Unlock error:', error);
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setUnlockStatus('error');
      setStatusWithAutoClose({ 
        type: 'error', 
        text: `Unlock failed: ${errorMsg}` 
      }, 0);
      addLog(`Unlock failed: ${errorMsg}`);
    }
  };

  const readConfigBlock = async (showLoading = true) => {
    if (!protocol) {
      setStatusWithAutoClose({ type: 'error', text: 'Not connected to BCM' }, 0);
      return;
    }

    if (showLoading) {
      setConfigLoadStatus('loading');
    }

    try {
      addLog('Reading configuration block (DID 0xDE00)...');
      const did = 0xDE00;
      const request = [0x22, (did >> 8) & 0xFF, did & 0xFF];
      
      const response = await withTimeout(
        protocol.sendUDS(BCM_TX, BCM_RX, request),
        UDS_TIMEOUT,
        'Config block read'
      );
      
      if (!response) {
        throw new Error('No response from BCM during config read');
      }

      if (response[0] === 0x7F) {
        const nrc = response[2];
        const nrcDesc = getNRCDescription(nrc);
        throw new Error(`Failed to read config: ${nrcDesc.short}`);
      }

      if (response[0] !== 0x62) {
        throw new Error(`Unexpected read response: 0x${response[0].toString(16).toUpperCase()}`);
      }

      const data = response.slice(3);
      setConfigData(new Uint8Array(data));
      setConfigLoadStatus('success');
      addLog(`Configuration block loaded: ${data.length} bytes`);
      setStatusWithAutoClose({ 
        type: 'success', 
        text: `Configuration loaded: ${data.length} bytes` 
      });
    } catch (error) {
      console.error('Config read error:', error);
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setConfigLoadStatus('error');
      setStatusWithAutoClose({ 
        type: 'error', 
        text: `Config read failed: ${errorMsg}` 
      }, 0);
      addLog(`Config read failed: ${errorMsg}`);
    }
  };

  const getFeatureCurrentValue = (preset: BCMFeaturePreset): number | null => {
    if (!configData) return null;
    
    if (preset.byteOffset >= configData.length) return null;
    
    const byteValue = configData[preset.byteOffset];
    
    if (preset.bitMask) {
      return byteValue & preset.bitMask;
    }
    
    return byteValue;
  };

  const handleFeatureChange = async (preset: BCMFeaturePreset, newValue: number) => {
    if (!protocol || !securityUnlocked || !configData) {
      setStatusWithAutoClose({ 
        type: 'error', 
        text: 'BCM must be connected and unlocked first' 
      }, 0);
      return;
    }

    const featureId = preset.id;
    const currentValue = getFeatureCurrentValue(preset);
    
    // Only write if value actually changed
    if (currentValue === newValue) {
      return;
    }

    setFeatureStates(prev => {
      const newMap = new Map(prev);
      newMap.set(featureId, {
        currentValue: currentValue,
        pendingValue: newValue,
        isReading: false,
        isWriting: true,
        error: null,
        success: false,
      });
      return newMap;
    });

    try {
      const originalData = new Uint8Array(configData);
      
      // Note: Backup creation would use tRPC here in production

      // Prepare modified data
      const newData = new Uint8Array(configData);
      
      if (preset.bitMask) {
        newData[preset.byteOffset] = (newData[preset.byteOffset] & ~preset.bitMask) | (newValue & preset.bitMask);
      } else {
        newData[preset.byteOffset] = newValue;
      }

      // Send Write Data by ID request (0x2E, DID high, DID low, data...)
      const did = preset.did;
      const writeRequest = [0x2E, (did >> 8) & 0xFF, did & 0xFF, ...Array.from(newData)];
      
      addLog(`Writing ${preset.name} to DID 0x${did.toString(16).toUpperCase()}...`);
      
      const response = await withTimeout(
        protocol.sendUDS(BCM_TX, BCM_RX, writeRequest),
        UDS_TIMEOUT,
        `Writing ${preset.name}`
      );

      if (!response) {
        throw new Error('No response from BCM during write');
      }

      // Handle negative response (NRC 0x7F)
      if (response[0] === 0x7F) {
        const nrc = response[2];
        const nrcDesc = getNRCDescription(nrc);
        throw new Error(`${nrcDesc.short}: ${nrcDesc.actionable}`);
      }

      // Check for positive response (0x6E for Write Data by ID)
      if (response[0] !== 0x6E) {
        throw new Error(`Unexpected write response: 0x${response[0].toString(16).toUpperCase()}`);
      }

      // Success! Update local state
      setConfigData(newData);
      
      // Note: Audit log would use tRPC here in production

      addLog(`${preset.name} updated successfully`);

      // Update feature state to show success
      setFeatureStates(prev => {
        const newMap = new Map(prev);
        newMap.set(featureId, {
          currentValue: newValue,
          pendingValue: null,
          isReading: false,
          isWriting: false,
          error: null,
          success: true,
        });
        return newMap;
      });

      setStatusWithAutoClose({ 
        type: 'success', 
        text: `${preset.name} updated to ${preset.options.find((o: any) => o.value === newValue)?.label}` 
      });

      // Clear success state after 2 seconds
      setTimeout(() => {
        setFeatureStates(prev => {
          const newMap = new Map(prev);
          const state = newMap.get(featureId);
          if (state) {
            newMap.set(featureId, { ...state, success: false });
          }
          return newMap;
        });
      }, 2000);
    } catch (error) {
      console.error('Feature change error:', error);
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      
      setFeatureStates(prev => {
        const newMap = new Map(prev);
        newMap.set(featureId, {
          currentValue: currentValue,
          pendingValue: null,
          isReading: false,
          isWriting: false,
          error: errorMsg,
          success: false,
        });
        return newMap;
      });

      setStatusWithAutoClose({ 
        type: 'error', 
        text: `Failed to update ${preset.name}: ${errorMsg}` 
      }, 0);
      addLog(`Feature change failed: ${errorMsg}`);
    }
  };

  const renderFeatureCard = (preset: BCMFeaturePreset) => {
    const featureState = featureStates.get(preset.id);
    const currentValue = featureState?.currentValue ?? getFeatureCurrentValue(preset);
    const isWriting = featureState?.isWriting ?? false;
    const success = featureState?.success ?? false;
    const error = featureState?.error;

    const currentOption = preset.options.find((o: any) => o.value === currentValue);

    return (
      <Card 
        key={preset.id} 
        className={`border-white/10 transition-all ${
          success ? 'border-green-500/50 bg-green-900/10' : ''
        } ${
          error ? 'border-red-500/50 bg-red-900/10' : ''
        }`}
        data-testid={`card-feature-${preset.id}`}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-white text-sm" data-testid={`text-feature-name-${preset.id}`}>
                {preset.name}
              </h4>
              <p className="text-xs text-gray-400 mt-0.5">{preset.description}</p>
              {preset.notes && (
                <p className="text-xs text-yellow-500/70 mt-1 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  {preset.notes}
                </p>
              )}
              {error && (
                <p className="text-xs text-red-400 mt-1 flex items-center gap-1">
                  <XCircle className="w-3 h-3" />
                  {error}
                </p>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {success && <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />}
              {error && <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />}
              
              <Select
                value={currentValue?.toString() ?? ''}
                onValueChange={(val) => handleFeatureChange(preset, parseInt(val))}
                disabled={!securityUnlocked || isWriting || connectionStatus !== 'connected' || configLoadStatus === 'error'}
              >
                <SelectTrigger 
                  className="w-[180px] h-8 text-xs"
                  data-testid={`select-feature-${preset.id}`}
                >
                  {isWriting ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      Applying...
                    </div>
                  ) : (
                    <SelectValue placeholder={currentOption?.label ?? 'Select...'} />
                  )}
                </SelectTrigger>
                <SelectContent>
                  {preset.options.map((option: any) => (
                    <SelectItem 
                      key={option.value} 
                      value={option.value.toString()}
                      data-testid={`option-${preset.id}-${option.value}`}
                    >
                      <div>
                        <span>{option.label}</span>
                        {option.description && (
                          <span className="text-xs text-gray-500 ml-2">- {option.description}</span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const presetsByCategory = getPresetsByCategory(BCM_FEATURE_CATEGORIES[0]);

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="sticky top-0 z-10 bg-black/95 backdrop-blur border-b border-white/10 px-4 py-3">
        <BackButton />
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-home">
                <Home className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-lg font-bold text-red-500 font-mono" data-testid="text-page-title">
                BCM SETTINGS
              </h1>
              <p className="text-xs text-gray-400">Body Control Module Configuration</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {connectionStatus === 'connected' && (
              <Badge 
                variant="outline" 
                className={securityUnlocked ? 'border-green-500 text-green-500' : 'border-yellow-500 text-yellow-500'}
                data-testid={`badge-security-${securityUnlocked ? 'unlocked' : 'locked'}`}
              >
                {securityUnlocked ? (
                  <><Unlock className="w-3 h-3 mr-1" /> Unlocked</>
                ) : (
                  <><Lock className="w-3 h-3 mr-1" /> Locked</>
                )}
              </Badge>
            )}
            
            <Button
              variant={connectionStatus === 'connected' ? 'destructive' : 'default'}
              size="sm"
              onClick={handleConnect}
              disabled={connectionStatus === 'connecting'}
              data-testid="button-connect"
            >
              {connectionStatus === 'connecting' ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Connecting...</>
              ) : connectionStatus === 'connected' ? (
                <><XCircle className="w-4 h-4 mr-2" /> Disconnect</>
              ) : (
                <><Usb className="w-4 h-4 mr-2" /> Connect</>
              )}
            </Button>
            
            {connectionStatus === 'connected' && !securityUnlocked && unlockStatus !== 'loading' && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleUnlock}
                className="border-yellow-500 text-yellow-500 hover:bg-yellow-500/10"
                data-testid="button-unlock"
              >
                <Lock className="w-4 h-4 mr-2" />
                Unlock BCM
              </Button>
            )}

            {unlockStatus === 'loading' && (
              <Button
                variant="outline"
                size="sm"
                disabled
                className="border-yellow-500 text-yellow-500"
              >
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Unlocking...
              </Button>
            )}

            {connectionStatus === 'connected' && securityUnlocked && configLoadStatus === 'error' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => readConfigBlock(true)}
                className="border-orange-500 text-orange-500 hover:bg-orange-500/10"
                data-testid="button-retry-config"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry Load
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-4">
        {statusMessage && (
          <Alert 
            className={`border transition-all ${
              statusMessage.type === 'success' ? 'border-green-500/50 bg-green-900/20' :
              statusMessage.type === 'error' ? 'border-red-500/50 bg-red-900/20' :
              statusMessage.type === 'warning' ? 'border-yellow-500/50 bg-yellow-900/20' :
              'border-blue-500/50 bg-blue-900/20'
            }`}
            data-testid={`alert-status-${statusMessage.type}`}
          >
            <AlertDescription className={`flex items-start gap-2 ${
              statusMessage.type === 'success' ? 'text-green-400' :
              statusMessage.type === 'error' ? 'text-red-400' :
              statusMessage.type === 'warning' ? 'text-yellow-400' :
              'text-blue-400'
            }`}>
              <div className="flex-shrink-0 mt-0.5">
                {statusMessage.type === 'success' && <CheckCircle className="w-4 h-4" />}
                {statusMessage.type === 'error' && <XCircle className="w-4 h-4" />}
                {statusMessage.type === 'warning' && <AlertTriangle className="w-4 h-4" />}
                {statusMessage.type === 'info' && <Car className="w-4 h-4" />}
              </div>
              <div className="flex-1">
                <div>{statusMessage.text}</div>
                {statusMessage.nrcDetail && (
                  <div className="text-xs opacity-75 mt-1">{statusMessage.nrcDetail}</div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {connectionStatus !== 'connected' && (
          <Card className="border-white/10">
            <CardContent className="p-8 text-center">
              <Usb className="w-12 h-12 mx-auto text-gray-500 mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">Connect to Vehicle</h3>
              <p className="text-gray-400 text-sm mb-4">
                Plug in your ELM327 or OBDLink adapter and click Connect to start configuring BCM features.
                The connection uses CAN IDs 0x720 (TX) and 0x728 (RX).
              </p>
              <Button onClick={handleConnect} data-testid="button-connect-main">
                <Usb className="w-4 h-4 mr-2" />
                Connect OBD2 Adapter
              </Button>
            </CardContent>
          </Card>
        )}

        {connectionStatus === 'connected' && !securityUnlocked && (
          <Card className="border-yellow-500/30 bg-yellow-900/10">
            <CardContent className="p-6 text-center">
              <Lock className="w-10 h-10 mx-auto text-yellow-500 mb-3" />
              <h3 className="text-lg font-medium text-white mb-2">BCM is Locked</h3>
              <p className="text-gray-400 text-sm mb-4">
                Click Unlock to enter diagnostic session and perform security access. This will read your BCM configuration.
              </p>
              {unlockStatus === 'error' && (
                <Alert className="border-red-500/50 bg-red-900/20 mb-4">
                  <AlertDescription className="text-red-400 text-sm">
                    Last unlock attempt failed. Check the connection and try again.
                  </AlertDescription>
                </Alert>
              )}
              <Button 
                onClick={handleUnlock}
                disabled={unlockStatus === 'loading'}
                className="bg-yellow-600 hover:bg-yellow-700"
                data-testid="button-unlock-main"
              >
                {unlockStatus === 'loading' ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Unlocking...</>
                ) : (
                  <><Unlock className="w-4 h-4 mr-2" /> Unlock BCM</>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {connectionStatus === 'connected' && securityUnlocked && configLoadStatus === 'error' && (
          <Card className="border-red-500/30 bg-red-900/10">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <XCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="font-medium text-white mb-1">Configuration Load Failed</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    The BCM configuration block (DID 0xDE00) could not be read. This may indicate a communication issue or module problem.
                  </p>
                  <Button
                    onClick={() => readConfigBlock(true)}
                    variant="outline"
                    size="sm"
                    className="border-red-500/50 text-red-400 hover:bg-red-900/20"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Retry
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {connectionStatus === 'connected' && securityUnlocked && configLoadStatus === 'loading' && (
          <Card className="border-blue-500/30 bg-blue-900/10">
            <CardContent className="p-6 text-center">
              <Loader2 className="w-10 h-10 mx-auto text-blue-500 mb-3 animate-spin" />
              <h3 className="text-lg font-medium text-white mb-2">Loading Configuration</h3>
              <p className="text-gray-400 text-sm">
                Reading BCM configuration from DID 0xDE00...
              </p>
            </CardContent>
          </Card>
        )}

        {connectionStatus === 'connected' && securityUnlocked && configLoadStatus === 'success' && configData && (
          <ScrollArea className="h-[calc(100vh-250px)]">
            <Accordion type="multiple" defaultValue={['Lighting']} className="space-y-2 pr-4">
              {BCM_FEATURE_CATEGORIES.map((category: any) => {
                const presets = getPresetsByCategory(category);
                if (presets.length === 0) return null;

                return (
                  <AccordionItem 
                    key={category} 
                    value={category}
                    className="border border-white/10 rounded-lg overflow-hidden bg-white/5"
                    data-testid={`accordion-${category.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <AccordionTrigger className="px-4 py-3 hover:bg-white/5 hover:no-underline">
                      <div className="flex items-center gap-3">
                        <div className="text-red-400">
                          {CATEGORY_ICONS[category as BCMFeatureCategory]}
                        </div>
                        <span className="font-medium">{category}</span>
                        <Badge variant="secondary" className="text-xs">
                          {presets.length} features
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      <div className="space-y-2">
                        {presets.map((preset: any) => renderFeatureCard(preset))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>

            <Separator className="my-6" />

            <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
              <CollapsibleTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="w-full justify-between text-gray-400 hover:text-white"
                  data-testid="button-advanced-toggle"
                >
                  <span className="flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Advanced / Engineering Mode
                  </span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-4 space-y-4 pr-4">
                <Alert className="border-yellow-500/50 bg-yellow-900/20">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <AlertDescription className="text-yellow-400">
                    Advanced mode is for experienced users. Incorrect settings can affect vehicle operation.
                  </AlertDescription>
                </Alert>
                
                <Card className="border-white/10">
                  <CardHeader>
                    <CardTitle className="text-sm">Raw Config Data</CardTitle>
                    <CardDescription>Current DID 0xDE00 configuration block ({configData.length} bytes)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {configData ? (
                      <div className="space-y-3">
                        <div className="font-mono text-xs bg-black/50 p-3 rounded overflow-x-auto">
                          <div className="grid grid-cols-16 gap-1">
                            {Array.from(configData).map((byte, i) => (
                              <span key={i} className="text-green-400" data-testid={`byte-${i}`}>
                                {byte.toString(16).padStart(2, '0').toUpperCase()}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2 text-xs text-gray-400">
                          <div className="flex items-center gap-1">
                            <Info className="w-3 h-3" />
                            <span>Total: {configData.length} bytes</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">No config data loaded</p>
                    )}
                  </CardContent>
                </Card>
              </CollapsibleContent>
            </Collapsible>
          </ScrollArea>
        )}
      </div>
    </div>
  );
}
