import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { BackButton } from '@/components/BackButton';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Square, AlertTriangle, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function LiveDataMonitor() {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [liveData, setLiveData] = useState<Record<string, { value: number; unit: string; name: string }>>({});
  const { toast } = useToast();

  const availablePIDsQuery = trpc.liveData.getAvailablePIDs.useQuery();
  const streamPIDsQuery = trpc.liveData.streamPIDs.useQuery(
    { pids: ['0C', '0D', '05', '0A', '11', '2F'] },
    { enabled: isMonitoring, refetchInterval: isMonitoring ? 1000 : false }
  );

  useEffect(() => {
    if (streamPIDsQuery.data?.success && streamPIDsQuery.data.data) {
      const newData: Record<string, { value: number; unit: string; name: string }> = {};
      streamPIDsQuery.data.data.forEach((item) => {
        newData[item.pid] = {
          value: item.value,
          unit: item.unit,
          name: item.name,
        };
      });
      setLiveData(newData);
    }
  }, [streamPIDsQuery.data]);

  const handleStartMonitoring = () => {
    setIsMonitoring(true);
    toast({
      title: 'Monitoring Started',
      description: 'Reading live data from vehicle...',
    });
  };

  const handleStopMonitoring = () => {
    setIsMonitoring(false);
    toast({
      title: 'Monitoring Stopped',
      description: 'Live data monitoring paused',
    });
  };

  const getValueColor = (pid: string, value: number) => {
    // Alert thresholds
    if (pid === '05' && value > 100) return 'text-red-500'; // Coolant > 100°C
    if (pid === '0C' && value > 6000) return 'text-yellow-500'; // RPM > 6000
    if (pid === '2F' && value < 20) return 'text-yellow-500'; // Fuel < 20%
    return 'text-foreground';
  };

  const getAlertIcon = (pid: string, value: number) => {
    if (pid === '05' && value > 100) return <AlertTriangle className="h-4 w-4 text-red-500" />;
    if (pid === '0C' && value > 6000) return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    if (pid === '2F' && value < 20) return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    return null;
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Live Data Monitor</h1>
          <p className="text-muted-foreground mt-2">
            Real-time engine metrics from OBD2 PIDs
          </p>
        </div>
        <div className="flex gap-2">
          {!isMonitoring ? (
            <Button onClick={handleStartMonitoring} size="lg">
              <Play className="mr-2 h-4 w-4" />
              Start Monitoring
            </Button>
          ) : (
            <Button onClick={handleStopMonitoring} variant="destructive" size="lg">
              <Square className="mr-2 h-4 w-4" />
              Stop Monitoring
            </Button>
          )}
        </div>
      </div>

      {/* Status */}
      {isMonitoring && (
        <Card className="border-green-500/50 bg-green-500/10">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-green-500 animate-pulse" />
              <span className="font-semibold text-green-600 dark:text-green-400">
                Live monitoring active - Updating every second
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error */}
      {streamPIDsQuery.data && !streamPIDsQuery.data.success && (
        <Card className="border-red-500/50 bg-red-500/10">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              <span className="font-semibold text-red-600 dark:text-red-400">
                {streamPIDsQuery.data.error}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Live Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Engine RPM */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Engine RPM
              {liveData['0C'] && getAlertIcon('0C', liveData['0C'].value)}
            </CardTitle>
            <CardDescription>Revolutions per minute</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-4xl font-bold ${liveData['0C'] ? getValueColor('0C', liveData['0C'].value) : ''}`}>
              {liveData['0C'] ? liveData['0C'].value.toFixed(0) : '---'}
              <span className="text-lg text-muted-foreground ml-2">RPM</span>
            </div>
          </CardContent>
        </Card>

        {/* Vehicle Speed */}
        <Card>
          <CardHeader>
            <CardTitle>Vehicle Speed</CardTitle>
            <CardDescription>Current speed</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">
              {liveData['0D'] ? liveData['0D'].value.toFixed(0) : '---'}
              <span className="text-lg text-muted-foreground ml-2">km/h</span>
            </div>
          </CardContent>
        </Card>

        {/* Coolant Temperature */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Coolant Temp
              {liveData['05'] && getAlertIcon('05', liveData['05'].value)}
            </CardTitle>
            <CardDescription>Engine coolant temperature</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-4xl font-bold ${liveData['05'] ? getValueColor('05', liveData['05'].value) : ''}`}>
              {liveData['05'] ? liveData['05'].value.toFixed(1) : '---'}
              <span className="text-lg text-muted-foreground ml-2">°C</span>
            </div>
          </CardContent>
        </Card>

        {/* Fuel Pressure */}
        <Card>
          <CardHeader>
            <CardTitle>Fuel Pressure</CardTitle>
            <CardDescription>Fuel rail pressure</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">
              {liveData['0A'] ? liveData['0A'].value.toFixed(0) : '---'}
              <span className="text-lg text-muted-foreground ml-2">kPa</span>
            </div>
          </CardContent>
        </Card>

        {/* Throttle Position */}
        <Card>
          <CardHeader>
            <CardTitle>Throttle Position</CardTitle>
            <CardDescription>Accelerator pedal position</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">
              {liveData['11'] ? liveData['11'].value.toFixed(1) : '---'}
              <span className="text-lg text-muted-foreground ml-2">%</span>
            </div>
          </CardContent>
        </Card>

        {/* Fuel Level */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Fuel Level
              {liveData['2F'] && getAlertIcon('2F', liveData['2F'].value)}
            </CardTitle>
            <CardDescription>Remaining fuel percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-4xl font-bold ${liveData['2F'] ? getValueColor('2F', liveData['2F'].value) : ''}`}>
              {liveData['2F'] ? liveData['2F'].value.toFixed(1) : '---'}
              <span className="text-lg text-muted-foreground ml-2">%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Available PIDs */}
      <Card>
        <CardHeader>
          <CardTitle>Available OBD2 PIDs</CardTitle>
          <CardDescription>
            All supported parameters that can be monitored
          </CardDescription>
        </CardHeader>
        <CardContent>
          {availablePIDsQuery.data?.success && (
            <div className="flex flex-wrap gap-2">
              {availablePIDsQuery.data.pids.map((pid) => (
                <Badge key={pid.pid} variant="outline">
                  {pid.name} ({pid.unit})
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instructions */}
      {!isMonitoring && (
        <Card>
          <CardHeader>
            <CardTitle>How to Use</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>1. Connect ELM327 adapter via Hardware Connection Wizard</p>
            <p>2. Ensure vehicle ignition is ON (engine can be off for basic readings)</p>
            <p>3. Click "Start Monitoring" to begin live data stream</p>
            <p>4. Start engine for accurate RPM, speed, and fuel pressure readings</p>
            <p>5. Alert icons appear when values exceed safe thresholds</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
