import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Search, Download, Clock, Gauge, AlertTriangle, TrendingUp } from "lucide-react";

export default function FreezeFrameAnalyzer() {
  const [dtcCode, setDtcCode] = useState("");
  const [deviceId, setDeviceId] = useState("");

  const { data: freezeFrameData, isLoading, refetch } = trpc.alphaOBD.getFreezeFrameData.useQuery({
    dtcCode: dtcCode || undefined,
    deviceId: deviceId || undefined,
  });

  const handleSearch = () => {
    refetch();
  };

  const exportToCSV = () => {
    if (!freezeFrameData) return;

    const rows = [
      ['Type', 'DTC', 'Parameter', 'Bit Position', 'Bit Length', 'Lower', 'Upper', 'Slope', 'Offset', 'Unit', 'Device IDs']
    ];

    freezeFrameData.ipc_snapshots?.forEach((snap: any) => {
      rows.push([
        'IPC',
        snap.dtc || 'N/A',
        snap.response_name || 'N/A',
        snap.bit_pos || 'N/A',
        snap.bit_len || 'N/A',
        snap.lower_level || 'N/A',
        snap.upper_level || 'N/A',
        snap.slope || 'N/A',
        snap.offset || 'N/A',
        snap.unit_name || 'N/A',
        snap.device_id || 'N/A'
      ]);
    });

    freezeFrameData.abs_snapshots?.forEach((snap: any) => {
      rows.push([
        'ABS',
        'N/A',
        snap.response_name || 'N/A',
        snap.bit_pos || 'N/A',
        snap.bit_len || 'N/A',
        snap.lower_level || 'N/A',
        snap.upper_level || 'N/A',
        snap.slope || 'N/A',
        snap.offset || 'N/A',
        snap.unit || 'N/A',
        snap.device_id || 'N/A'
      ]);
    });

    const csv = rows.map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `freeze_frame_${Date.now()}.csv`;
    a.click();
    toast.success("Freeze frame data exported to CSV");
  };

  const calculateValue = (snap: any, rawValue: number = 0) => {
    const slope = parseFloat(snap.slope || '1');
    const offset = parseFloat(snap.offset || '0');
    return (rawValue * slope + offset).toFixed(2);
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Freeze Frame Analyzer</h1>
        <p className="text-muted-foreground">
          Analyze 9,967 snapshot parameters captured at fault occurrence
        </p>
      </div>

      {/* Search Controls */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Search Freeze Frame Data</CardTitle>
          <CardDescription>
            Filter by DTC code or device ID to view snapshot parameters
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">DTC Code</label>
              <Input
                placeholder="e.g., P0171, C121A, U0100"
                value={dtcCode}
                onChange={(e) => setDtcCode(e.target.value.toUpperCase())}
              />
            </div>
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Device ID</label>
              <Input
                placeholder="e.g., 55844, 55968"
                value={deviceId}
                onChange={(e) => setDeviceId(e.target.value)}
              />
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={handleSearch} disabled={isLoading}>
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              {freezeFrameData && freezeFrameData.total_parameters > 0 && (
                <Button onClick={exportToCSV} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {isLoading && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Loading freeze frame data...
          </CardContent>
        </Card>
      )}

      {!isLoading && freezeFrameData && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Parameters</CardTitle>
                <Gauge className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{freezeFrameData.total_parameters}</div>
                <p className="text-xs text-muted-foreground">
                  Snapshot data points
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">IPC Snapshots</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{freezeFrameData.ipc_snapshots?.length || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Instrument cluster data
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">ABS Snapshots</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{freezeFrameData.abs_snapshots?.length || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Brake system data
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Data Tables */}
          <Tabs defaultValue="ipc" className="w-full">
            <TabsList>
              <TabsTrigger value="ipc">
                IPC Snapshots ({freezeFrameData.ipc_snapshots?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="abs">
                ABS Snapshots ({freezeFrameData.abs_snapshots?.length || 0})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="ipc">
              <Card>
                <CardHeader>
                  <CardTitle>Instrument Cluster Freeze Frame Data</CardTitle>
                  <CardDescription>
                    Vehicle state captured at fault occurrence (speed, RPM, throttle, etc.)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {freezeFrameData.ipc_snapshots && freezeFrameData.ipc_snapshots.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>DTC</TableHead>
                            <TableHead>Parameter</TableHead>
                            <TableHead>Bit Pos</TableHead>
                            <TableHead>Bit Len</TableHead>
                            <TableHead>Range</TableHead>
                            <TableHead>Formula</TableHead>
                            <TableHead>Unit</TableHead>
                            <TableHead>Device IDs</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {freezeFrameData.ipc_snapshots.map((snap: any, idx: number) => (
                            <TableRow key={idx}>
                              <TableCell>
                                <Badge variant="outline">{snap.dtc || 'N/A'}</Badge>
                              </TableCell>
                              <TableCell className="font-medium">
                                {snap.response_name || 'Unknown'}
                              </TableCell>
                              <TableCell>{snap.bit_pos || 'N/A'}</TableCell>
                              <TableCell>{snap.bit_len || 'N/A'}</TableCell>
                              <TableCell className="text-xs">
                                {snap.lower_level && snap.upper_level
                                  ? `${snap.lower_level} - ${snap.upper_level}`
                                  : 'N/A'}
                              </TableCell>
                              <TableCell className="text-xs font-mono">
                                {snap.slope && snap.offset
                                  ? `x * ${snap.slope} + ${snap.offset}`
                                  : 'N/A'}
                              </TableCell>
                              <TableCell>{snap.unit_name || 'N/A'}</TableCell>
                              <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">
                                {snap.device_id || 'N/A'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No IPC freeze frame data found</p>
                      <p className="text-sm mt-2">Try searching by DTC code or device ID</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="abs">
              <Card>
                <CardHeader>
                  <CardTitle>ABS/Brake System Freeze Frame Data</CardTitle>
                  <CardDescription>
                    Brake system state at fault occurrence (wheel speeds, pressure, etc.)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {freezeFrameData.abs_snapshots && freezeFrameData.abs_snapshots.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Parameter</TableHead>
                            <TableHead>Bit Pos</TableHead>
                            <TableHead>Bit Len</TableHead>
                            <TableHead>Range</TableHead>
                            <TableHead>Formula</TableHead>
                            <TableHead>Unit</TableHead>
                            <TableHead>Device IDs</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {freezeFrameData.abs_snapshots.map((snap: any, idx: number) => (
                            <TableRow key={idx}>
                              <TableCell className="font-medium">
                                {snap.response_name || 'Unknown'}
                              </TableCell>
                              <TableCell>{snap.bit_pos || 'N/A'}</TableCell>
                              <TableCell>{snap.bit_len || 'N/A'}</TableCell>
                              <TableCell className="text-xs">
                                {snap.lower_level && snap.upper_level
                                  ? `${snap.lower_level} - ${snap.upper_level}`
                                  : 'N/A'}
                              </TableCell>
                              <TableCell className="text-xs font-mono">
                                {snap.slope && snap.offset
                                  ? `x * ${snap.slope} + ${snap.offset}`
                                  : 'N/A'}
                              </TableCell>
                              <TableCell>{snap.unit || 'N/A'}</TableCell>
                              <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">
                                {snap.device_id || 'N/A'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No ABS freeze frame data found</p>
                      <p className="text-sm mt-2">Try searching by device ID</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}

      {!isLoading && !freezeFrameData && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Enter search criteria to view freeze frame data</p>
            <p className="text-sm mt-2">Search by DTC code or device ID</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
