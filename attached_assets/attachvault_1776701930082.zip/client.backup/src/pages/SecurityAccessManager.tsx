import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BackButton } from "@/components/BackButton";
import { 
  ArrowLeft, Shield, Play, Square, Loader2, CheckCircle2, 
  XCircle, AlertCircle, Key, Lock, Unlock, Download
} from "lucide-react";
import { generateKey } from "@shared/fca-keygen";
import { MODULE_DATABASE } from "@shared/module-database";
import { cn } from "@/lib/utils";

interface SecurityAttempt {
  timestamp: number;
  module: string;
  level: number;
  constant: number;
  seed: number[];
  key: number[];
  success: boolean;
  nrc?: number;
}

const SECURITY_CONSTANTS = [
  { value: 0x4B92, name: "Legacy (0x4B92)", description: "Pre-2018 modules" },
  { value: 0x82F1, name: "Standard (0x82F1)", description: "2018-2021 modules" },
  { value: 0x1209, name: "Extended (0x1209)", description: "2022+ modules" },
];

const SECURITY_LEVELS = [
  { value: 1, name: "Level 1", description: "Basic diagnostic access" },
  { value: 3, name: "Level 3", description: "Programming access" },
  { value: 5, name: "Level 5", description: "Advanced programming" },
  { value: 7, name: "Level 7", description: "Factory access" },
];

export default function SecurityAccessManager() {
  const [selectedModule, setSelectedModule] = useState("");
  const [selectedLevel, setSelectedLevel] = useState(1);
  const [autoWaterfall, setAutoWaterfall] = useState(true);
  const [isRunning, setIsRunning] = useState(false);
  const [attempts, setAttempts] = useState<SecurityAttempt[]>([]);
  const [currentAttempt, setCurrentAttempt] = useState<string>("");

  const handleStartWaterfall = async () => {
    if (!selectedModule) return;
    
    setIsRunning(true);
    setAttempts([]);
    
    const module = Object.values(MODULE_DATABASE).find((m: any) => m.name === selectedModule);
    if (!module) {
      alert('Module not found in database');
      setIsRunning(false);
      return;
    }

    try {
      // Get connection manager instance
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        throw new Error('Not connected to vehicle. Please connect OBDLink/J2534 adapter first.');
      }

      // Get module CAN addresses from database
      const txAddr = (module as any).canTx || 0x7E0;
      const rxAddr = (module as any).canRx || 0x7E8;

      // Try waterfall - test all constants until one works
      for (const constant of SECURITY_CONSTANTS) {
        setCurrentAttempt(`Trying ${constant.name} on ${selectedModule}...`);
        
        try {
          // Step 1: Request seed (UDS 0x27 [level])
          const seedResp = await protocol.sendUDS(txAddr, rxAddr, [0x27, selectedLevel]);
          
          if (!seedResp || seedResp[0] === 0x7F) {
            // Negative response
            const nrc = seedResp ? seedResp[2] : 0x00;
            const attempt: SecurityAttempt = {
              timestamp: Date.now(),
              module: selectedModule,
              level: selectedLevel,
              constant: constant.value,
              seed: [],
              key: [],
              success: false,
              nrc,
            };
            setAttempts(prev => [...prev, attempt]);
            continue;
          }

          // Extract seed (4 bytes typically)
          const seed = Array.from(seedResp.slice(2, 6));
          
          // Step 2: Calculate key using FCA keygen with this constant
          const keyResult = generateKey(new Uint8Array(seed), selectedLevel as 1 | 3 | 5);
          const key = Array.from(keyResult);
          
          // Step 3: Send key (UDS 0x27 [level+1] [key_bytes])
          const keyResp = await protocol.sendUDS(
            txAddr,
            rxAddr,
            [0x27, selectedLevel + 1, ...key]
          );
          
          const success = !!(keyResp && keyResp[0] === 0x67);
          const nrc = (!success && keyResp && keyResp[0] === 0x7F) ? keyResp[2] : undefined;
          
          const attempt: SecurityAttempt = {
            timestamp: Date.now(),
            module: selectedModule,
            level: selectedLevel,
            constant: constant.value,
            seed,
            key,
            success,
            nrc,
          };
          
          setAttempts(prev => [...prev, attempt]);
          
          if (success) {
            setCurrentAttempt(`Security access granted with ${constant.name}!`);
            break;
          }
          
        } catch (error: any) {
          console.error(`Error trying ${constant.name}:`, error);
          // Continue to next constant
        }
      }
      
    } catch (error: any) {
      alert(`Security access failed: ${error.message}`);
    } finally {
      setIsRunning(false);
      setCurrentAttempt("");
    }
  };

  const handleExportLog = () => {
    const data = JSON.stringify(attempts, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `security-log-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getAttemptIcon = (attempt: SecurityAttempt) => {
    if (attempt.success) {
      return <CheckCircle2 className="h-4 w-4 text-green-600" />;
    }
    return <XCircle className="h-4 w-4 text-red-600" />;
  };

  const getConstantName = (value: number) => {
    const constant = SECURITY_CONSTANTS.find(c => c.value === value);
    return constant?.name || `0x${value.toString(16).toUpperCase()}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b-4 border-red-600">
        <div className="container mx-auto py-6">
          <BackButton />
      <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-3xl font-black tracking-tight">SECURITY ACCESS MANAGER</h1>
                <p className="text-sm text-gray-600 mt-1">Algorithm Waterfall & Seed/Key Logging</p>
              </div>
            </div>
            <Badge variant="outline" className="text-lg px-4 py-2">
              <Shield className="h-4 w-4 mr-2" />
              FCA KEYGEN
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration */}
          <div className="lg:col-span-1">
            <Card className="border-l-4 border-l-red-600">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="h-5 w-5" />
                  Configuration
                </CardTitle>
                <CardDescription>
                  Select module and security level for waterfall attack
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Module Selection */}
                <div>
                  <Label htmlFor="module">Target Module</Label>
                  <Select value={selectedModule} onValueChange={setSelectedModule}>
                    <SelectTrigger id="module">
                      <SelectValue placeholder="Select module..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.values(MODULE_DATABASE).map((module: any) => (
                        <SelectItem key={module.name} value={module.name}>
                          {module.name} ({module.txId})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Security Level */}
                <div>
                  <Label htmlFor="level">Security Level</Label>
                  <Select value={selectedLevel.toString()} onValueChange={(v) => setSelectedLevel(parseInt(v))}>
                    <SelectTrigger id="level">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SECURITY_LEVELS.map(level => (
                        <SelectItem key={level.value} value={level.value.toString()}>
                          {level.name} - {level.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Auto Waterfall */}
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Algorithm Waterfall</AlertTitle>
                  <AlertDescription>
                    Automatically tries all three FCA security constants (0x4B92, 0x82F1, 0x1209) until one succeeds or all fail.
                  </AlertDescription>
                </Alert>

                {/* Start Button */}
                <Button 
                  onClick={handleStartWaterfall} 
                  disabled={!selectedModule || isRunning}
                  className="w-full"
                >
                  {isRunning ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Start Waterfall
                    </>
                  )}
                </Button>

                {currentAttempt && (
                  <div className="text-sm text-center text-gray-600 font-mono">
                    {currentAttempt}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Security Constants Reference */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-sm">Security Constants</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {SECURITY_CONSTANTS.map(constant => (
                  <div key={constant.value} className="flex items-center justify-between text-xs">
                    <span className="font-mono">{constant.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {constant.description}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Attempt Log */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5" />
                    Seed/Key Log
                  </CardTitle>
                  <Button 
                    onClick={handleExportLog} 
                    variant="outline" 
                    size="sm"
                    disabled={attempts.length === 0}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Export JSON
                  </Button>
                </div>
                <CardDescription>
                  Captured security access attempts with seeds and keys
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  {attempts.length === 0 && (
                    <div className="text-center text-gray-400 py-8">
                      No attempts yet. Start the waterfall to begin logging.
                    </div>
                  )}
                  <div className="space-y-3">
                    {attempts.map((attempt, idx) => (
                      <div
                        key={idx}
                        className={cn(
                          "p-4 rounded-lg border",
                          attempt.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                        )}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getAttemptIcon(attempt)}
                            <span className="font-semibold text-sm">
                              {attempt.module} - Level {attempt.level}
                            </span>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {getConstantName(attempt.constant)}
                          </Badge>
                        </div>
                        
                        <div className="space-y-1 font-mono text-xs">
                          <div className="flex items-center gap-2">
                            <span className="text-gray-600">Seed:</span>
                            <span className="font-semibold">
                              {attempt.seed.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-gray-600">Key:</span>
                            <span className="font-semibold">
                              {attempt.key.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')}
                            </span>
                          </div>
                          {attempt.nrc && (
                            <div className="flex items-center gap-2 text-red-600">
                              <span>NRC:</span>
                              <span className="font-semibold">0x{attempt.nrc.toString(16).toUpperCase()}</span>
                              <span className="text-xs">(Security Access Denied)</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="text-xs text-gray-500 mt-2">
                          {new Date(attempt.timestamp).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
