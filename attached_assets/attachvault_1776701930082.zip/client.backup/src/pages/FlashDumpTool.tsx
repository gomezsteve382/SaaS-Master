import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BackButton } from "@/components/BackButton";
import { HardDrive, Download, Cloud, AlertTriangle, CheckCircle, Wifi } from "lucide-react";
import { toast } from "sonner";
import { MODULE_DATABASE } from "@shared/module-database";
import { J2534Protocol, J2534UDS } from "@shared/j2534-protocol";

export default function FlashDumpTool() {
  const [selectedModule, setSelectedModule] = useState<string>("BCM");
  const [operation, setOperation] = useState<"read" | "write" | null>(null);
  const [progress, setProgress] = useState(0);
  const [dumpData, setDumpData] = useState<Uint8Array | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [j2534, setJ2534] = useState<J2534Protocol | null>(null);
  const [connected, setConnected] = useState(false);
  const [bridgeUrl, setBridgeUrl] = useState("ws://localhost:8766");

  const { data: backups, refetch: refetchBackups } = trpc.backups.list.useQuery();
  const createBackupMutation = trpc.backups.create.useMutation();

  const moduleInfo = MODULE_DATABASE[selectedModule];

  useEffect(() => {
    // Initialize J2534 protocol
    const protocol = new J2534Protocol({ bridgeUrl });
    protocol.onStatus((status, message) => {
      if (status === "connected") {
        setConnected(true);
        toast.success("J2534 bridge connected");
      } else if (status === "disconnected") {
        setConnected(false);
        toast.error("J2534 bridge disconnected");
      } else if (status === "error") {
        toast.error(`J2534 error: ${message}`);
      }
    });
    setJ2534(protocol);

    return () => {
      protocol.disconnect();
    };
  }, [bridgeUrl]);

  const handleConnect = async () => {
    if (!j2534) return;
    try {
      await j2534.connect();
    } catch (error) {
      toast.error("Failed to connect to J2534 bridge: " + (error as Error).message);
    }
  };

  const handleReadDump = async () => {
    if (!moduleInfo || !j2534 || !connected) {
      toast.error("Please connect to J2534 bridge first");
      return;
    }

    setOperation("read");
    setIsProcessing(true);
    setProgress(0);

    try {
      const uds = new J2534UDS(j2534, moduleInfo.tx, moduleInfo.rx);

      // Step 1: Extended Diagnostic Session
      toast.info("Starting extended diagnostic session...");
      await uds.diagnosticSessionControl(0x03);
      setProgress(10);

      // Step 2: Security Access (if required)
      if (moduleInfo.protectionLevel !== "software") {
        toast.info("Requesting security access...");
        const seedResponse = await uds.securityAccess(0x01);
        
        // Extract seed and calculate key using FCA keygen
        const seed = seedResponse.slice(2, 4); // 2-byte seed
        const { generateKey } = await import("@shared/fca-keygen");
        const key = generateKey(new Uint8Array(seed), 1); // Level 1 = CDA Engineering
        
        await uds.securityAccess(0x01, Array.from(key));
        setProgress(20);
      }

      // Step 3: Read EEPROM via Service 0x23 (ReadMemoryByAddress)
      toast.info("Reading EEPROM memory...");
      const memorySize = 8192; // 8KB EEPROM
      const chunkSize = 256; // Read in 256-byte chunks
      const chunks = Math.ceil(memorySize / chunkSize);
      const dumpBuffer = new Uint8Array(memorySize);

      for (let i = 0; i < chunks; i++) {
        const address = i * chunkSize;
        const size = Math.min(chunkSize, memorySize - address);

        // Service 0x23: ReadMemoryByAddress
        // Format: [0x23, AddressAndLengthFormatIdentifier, Address..., Size...]
        const addressBytes = [
          (address >> 16) & 0xFF,
          (address >> 8) & 0xFF,
          address & 0xFF
        ];
        const sizeBytes = [(size >> 8) & 0xFF, size & 0xFF];

        const response = await j2534.sendUDS(
          moduleInfo.tx,
          moduleInfo.rx,
          0x23,
          [0x34, ...addressBytes, ...sizeBytes] // 0x34 = 3-byte address, 4-byte size format
        );

        // Extract data from response (skip service ID and format byte)
        if (response[0] === 0x63) { // Positive response
          const data = response.slice(1);
          dumpBuffer.set(data, address);
        } else if (response[0] === 0x7F) {
          throw new Error(`NRC: 0x${response[2].toString(16).padStart(2, '0')}`);
        }

        setProgress(20 + Math.floor((i / chunks) * 70));
      }

      setDumpData(dumpBuffer);
      setProgress(90);

      // Step 4: Create S3 backup
      toast.info("Uploading to S3...");
      const blob = new Blob([dumpBuffer], { type: "application/octet-stream" });
      const base64 = await blobToBase64(blob);
      
      await createBackupMutation.mutateAsync({
        fileName: `${selectedModule}_dump_${Date.now()}.bin`,
        moduleCode: selectedModule,
        moduleName: moduleInfo.name,
        vin: "EXTRACTED_FROM_DUMP", // Will be extracted from dump
        fileData: base64
      });

      await refetchBackups();
      setProgress(100);
      toast.success(`${selectedModule} EEPROM read complete (${memorySize} bytes) and backed up to S3`);
    } catch (error) {
      toast.error("Failed to read EEPROM: " + (error as Error).message);
    } finally {
      setIsProcessing(false);
      setOperation(null);
      setProgress(0);
    }
  };

  const handleWriteDump = async (file: File) => {
    if (!moduleInfo || !j2534 || !connected) {
      toast.error("Please connect to J2534 bridge first");
      return;
    }

    setOperation("write");
    setIsProcessing(true);
    setProgress(0);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);

      // Create backup before write
      const base64 = await blobToBase64(new Blob([data]));
      await createBackupMutation.mutateAsync({
        fileName: `${selectedModule}_pre_write_${Date.now()}.bin`,
        moduleCode: selectedModule,
        moduleName: moduleInfo.name,
        vin: "PRE-WRITE-BACKUP",
        fileData: base64
      });
      setProgress(10);

      const uds = new J2534UDS(j2534, moduleInfo.tx, moduleInfo.rx);

      // Step 1: Extended Diagnostic Session
      toast.info("Starting extended diagnostic session...");
      await uds.diagnosticSessionControl(0x03);
      setProgress(15);

      // Step 2: Security Access
      if (moduleInfo.protectionLevel !== "software") {
        toast.info("Requesting security access...");
        const seedResponse = await uds.securityAccess(0x01);
        const seed = seedResponse.slice(2, 4); // 2-byte seed
        const { generateKey } = await import("@shared/fca-keygen");
        const key = generateKey(new Uint8Array(seed), 1); // Level 1 = CDA Engineering
        await uds.securityAccess(0x01, Array.from(key));
        setProgress(20);
      }

      // Step 3: Write EEPROM via Service 0x3D (WriteMemoryByAddress)
      toast.info("Writing EEPROM memory...");
      const chunkSize = 128; // Write in smaller chunks for safety
      const chunks = Math.ceil(data.length / chunkSize);

      for (let i = 0; i < chunks; i++) {
        const address = i * chunkSize;
        const size = Math.min(chunkSize, data.length - address);
        const chunk = data.slice(address, address + size);

        // Service 0x3D: WriteMemoryByAddress
        const addressBytes = [
          (address >> 16) & 0xFF,
          (address >> 8) & 0xFF,
          address & 0xFF
        ];
        const sizeBytes = [(size >> 8) & 0xFF, size & 0xFF];

        const response = await j2534.sendUDS(
          moduleInfo.tx,
          moduleInfo.rx,
          0x3D,
          [0x34, ...addressBytes, ...sizeBytes, ...Array.from(chunk)]
        );

        if (response[0] === 0x7F) {
          throw new Error(`Write failed at 0x${address.toString(16)}: NRC 0x${response[2].toString(16)}`);
        }

        setProgress(20 + Math.floor((i / chunks) * 70));
      }

      // Step 4: ECU Reset
      toast.info("Resetting module...");
      await uds.ecuReset(0x01);
      setProgress(95);

      await refetchBackups();
      setProgress(100);
      toast.success(`${selectedModule} EEPROM written successfully (${data.length} bytes)`);
    } catch (error) {
      toast.error("Failed to write EEPROM: " + (error as Error).message);
    } finally {
      setIsProcessing(false);
      setOperation(null);
      setProgress(0);
    }
  };

  const handleDownloadDump = () => {
    if (!dumpData) {
      toast.error("No dump data available");
      return;
    }

    const blob = new Blob([new Uint8Array(dumpData)], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedModule}_dump_${Date.now()}.bin`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Dump downloaded");
  };

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <HardDrive className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">FLASH MEMORY DUMP TOOL</h1>
            <p className="text-gray-600">Full EEPROM backup and restore via J2534 with automatic S3 cloud backup</p>
          </div>
        </div>

        {/* Warning Banner */}
        <Card className="border-yellow-500 bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold text-yellow-900">CRITICAL: Always create backup before writing</p>
                <p className="text-sm text-yellow-800">
                  Writing incorrect data can brick your module. All backups are automatically saved to S3 cloud storage.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* J2534 Connection Status */}
        <Card className={connected ? "border-green-500 bg-green-50" : "border-gray-300"}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Wifi className={`h-5 w-5 ${connected ? "text-green-600" : "text-gray-400"}`} />
                <div>
                  <p className="font-bold">{connected ? "J2534 Bridge Connected" : "J2534 Bridge Disconnected"}</p>
                  <p className="text-sm text-gray-600">Bridge URL: {bridgeUrl}</p>
                </div>
              </div>
              {!connected && (
                <Button onClick={handleConnect} variant="outline">
                  Connect
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Operations */}
          <div className="space-y-6">
            {/* Module Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Module Selection</CardTitle>
                <CardDescription>Select the module to read/write EEPROM</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Module Type</Label>
                  <select
                    value={selectedModule}
                    onChange={(e) => setSelectedModule(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-gray-300"
                    disabled={isProcessing}
                  >
                    {Object.entries(MODULE_DATABASE).map(([code, module]) => (
                      <option key={code} value={code}>
                        {code} - {module.description}
                      </option>
                    ))}
                  </select>
                </div>

                {moduleInfo && (
                  <div className="p-4 bg-gray-50 rounded-lg space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">CAN TX Address:</span>
                      <span className="font-mono font-bold">0x{moduleInfo.tx.toString(16).toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">CAN RX Address:</span>
                      <span className="font-mono font-bold">0x{moduleInfo.rx.toString(16).toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Bus:</span>
                      <span className="font-mono font-bold">{moduleInfo.bus}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Protection:</span>
                      <Badge variant={(moduleInfo.protectionLevel || "software") === "software" ? "default" : "destructive"}>
                        {(moduleInfo.protectionLevel || "software").toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Read EEPROM */}
            <Card>
              <CardHeader>
                <CardTitle>Read EEPROM</CardTitle>
                <CardDescription>Extract full module memory dump via UDS Service 0x23</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={handleReadDump}
                  disabled={isProcessing || !connected}
                  className="w-full gap-2"
                >
                  <Download className="h-4 w-4" />
                  Read Full EEPROM (8KB)
                </Button>

                {operation === "read" && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Reading EEPROM...</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} />
                  </div>
                )}

                {dumpData && !isProcessing && (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span className="font-bold text-green-900">Dump Complete</span>
                    </div>
                    <p className="text-sm text-green-800 mb-3">
                      {dumpData.length.toLocaleString()} bytes read and backed up to S3
                    </p>
                    <Button onClick={handleDownloadDump} variant="outline" size="sm" className="gap-2">
                      <Download className="h-4 w-4" />
                      Download Dump File
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Write EEPROM */}
            <Card>
              <CardHeader>
                <CardTitle>Write EEPROM</CardTitle>
                <CardDescription>Restore module from backup file via UDS Service 0x3D</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Upload Dump File (.bin)</Label>
                  <input
                    type="file"
                    accept=".bin,.eep,.hex"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleWriteDump(file);
                    }}
                    disabled={isProcessing || !connected}
                    className="w-full"
                  />
                </div>

                {operation === "write" && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Writing EEPROM...</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Cloud Backups */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cloud className="h-5 w-5" />
                  Cloud Backups (S3)
                </CardTitle>
                <CardDescription>
                  All EEPROM dumps are automatically backed up to secure cloud storage
                </CardDescription>
              </CardHeader>
              <CardContent>
                {backups && backups.length > 0 ? (
                  <div className="space-y-3">
                    {backups.slice(0, 10).map((backup) => (
                      <div key={backup.id} className="p-3 bg-gray-50 rounded-lg border">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="font-bold">{backup.moduleCode}</div>
                            <div className="text-sm text-gray-600">
                              VIN: {backup.vin || "N/A"}
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(backup.createdAt).toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-500">
                              Size: {(backup.fileSize / 1024).toFixed(2)} KB
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (backup.fileUrl) {
                                window.open(backup.fileUrl, "_blank");
                              } else {
                                toast.error("File URL not available");
                              }
                            }}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Cloud className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No cloud backups yet</p>
                    <p className="text-sm mt-2">Read an EEPROM to create your first backup</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
