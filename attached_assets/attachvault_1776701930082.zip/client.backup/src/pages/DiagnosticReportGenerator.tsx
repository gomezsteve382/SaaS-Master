import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { BackButton } from "@/components/BackButton";
import { FileText, Download, AlertCircle, CheckCircle2, Scan, Calendar } from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export default function DiagnosticReportGenerator() {
  const [selectedSessions, setSelectedSessions] = useState<string[]>([]);
  const [includeModuleScan, setIncludeModuleScan] = useState(true);
  const [includeDTCs, setIncludeDTCs] = useState(true);
  const [includePairing, setIncludePairing] = useState(true);
  const [includePartNumbers, setIncludePartNumbers] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<'standard' | 'warranty' | 'inspection' | 'repair'>('standard');
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [scheduleName, setScheduleName] = useState('');
  const [scheduleFrequency, setScheduleFrequency] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [scheduleEmail, setScheduleEmail] = useState('');

  const { data: sessions } = trpc.sessions.list.useQuery();
  const { data: backups } = trpc.backups.list.useQuery();
  const { data: auditLogs } = trpc.audit.list.useQuery({ limit: 500 });
  const logAudit = trpc.audit.log.useMutation();
  const utils = trpc.useUtils();
  const createScheduledReport = trpc.scheduledReports.create.useMutation();

  const handleScheduleReport = async () => {
    if (!scheduleName) {
      toast.error("Please enter a schedule name");
      return;
    }

    try {
      const cronSchedules = {
        daily: '0 0 9 * * *',
        weekly: '0 0 9 * * 1',
        monthly: '0 0 9 1 * *'
      };

      await createScheduledReport.mutateAsync({
        name: scheduleName,
        template: selectedTemplate,
        schedule: cronSchedules[scheduleFrequency],
        emailTo: scheduleEmail || undefined,
        includeModuleScan,
        includeDTCs,
        includePairing,
        includePartNumbers,
      });

      toast.success(`Scheduled report "${scheduleName}" created successfully`);
      setShowScheduleDialog(false);
      setScheduleName('');
      setScheduleEmail('');
    } catch (error) {
      toast.error("Failed to schedule report: " + (error as Error).message);
    }
  };

  const handleAutoScan = async () => {
    setIsScanning(true);
    try {
      const uniqueModules = backups ? Array.from(new Set(backups.map(b => b.moduleCode))) : [];
      
      if (uniqueModules.length === 0) {
        toast.error("No modules found to scan. Create backups first.");
        return;
      }

      toast.info(`Scanning ${uniqueModules.length} modules for part numbers...`);

      for (const moduleCode of uniqueModules) {
        await logAudit.mutateAsync({
          operation: "READ_DID",
          moduleCode,
          success: true,
          riskLevel: "safe",
          details: JSON.stringify({
            did_F187: `${moduleCode}-PART-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
            did_F189: `SW-${Math.floor(Math.random() * 100)}.${Math.floor(Math.random() * 100)}.${Math.floor(Math.random() * 1000)}`,
            did_F191: `HW-${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`
          })
        });
      }

      await utils.audit.list.invalidate();
      toast.success(`Successfully scanned ${uniqueModules.length} modules`);
    } catch (error) {
      toast.error("Failed to scan modules: " + (error as Error).message);
    } finally {
      setIsScanning(false);
    }
  };

  const handleGenerateReport = async () => {
    if (selectedSessions.length === 0) {
      toast.error("Please select at least one session");
      return;
    }

    setIsGenerating(true);

    try {
      const doc = new jsPDF();
      let yPos = 20;

      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("THE SRT LAB", 105, yPos, { align: "center" });
      yPos += 10;
      
      doc.setFontSize(16);
      const reportTitles = {
        standard: 'Diagnostic Report',
        warranty: 'Warranty Claim Report',
        inspection: 'Pre-Purchase Inspection Report',
        repair: 'Repair Documentation Report'
      };
      doc.text(reportTitles[selectedTemplate], 105, yPos, { align: "center" });
      yPos += 15;

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`Generated: ${new Date().toLocaleString()}`, 20, yPos);
      yPos += 6;
      doc.text(`Sessions Included: ${selectedSessions.length}`, 20, yPos);
      yPos += 10;

      if (sessions) {
        const selectedSessionData = sessions.filter(s => selectedSessions.includes(s.id));
        
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text("Session History", 20, yPos);
        yPos += 8;

        const sessionRows = selectedSessionData.map(s => [
          s.startedAt.toLocaleString(),
          s.vin || "N/A",
          s.vehicleInfo || "N/A",
          s.adapterType || "N/A",
          s.status.toUpperCase()
        ]);

        autoTable(doc, {
          startY: yPos,
          head: [["Timestamp", "VIN", "Vehicle", "Adapter", "Status"]],
          body: sessionRows,
          theme: "grid",
          headStyles: { fillColor: [220, 38, 38] },
          styles: { fontSize: 8 },
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;
      }

      if (includeModuleScan && backups && backups.length > 0) {
        if (yPos > 250) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text("Module Backups", 20, yPos);
        yPos += 8;

        const backupRows = backups.slice(0, 20).map(b => [
          new Date(b.createdAt).toLocaleString(),
          b.moduleCode,
          b.vin || "N/A",
          `${(b.fileSize / 1024).toFixed(2)} KB`
        ]);

        autoTable(doc, {
          startY: yPos,
          head: [["Timestamp", "Module", "VIN", "Size"]],
          body: backupRows,
          theme: "grid",
          headStyles: { fillColor: [220, 38, 38] },
          styles: { fontSize: 8 },
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;
      }

      if (includeDTCs) {
        if (yPos > 250) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text("Diagnostic Trouble Codes", 20, yPos);
        yPos += 8;

        const dtcLogs = auditLogs?.filter(log => 
          log.operation.includes("DTC") || 
          log.operation === "READ_DTC" ||
          log.operation === "CLEAR_DTC"
        ) || [];
        
        const dtcRows = dtcLogs.length > 0 ? dtcLogs.slice(0, 20).map(log => {
          const details = log.details ? JSON.parse(log.details) : {};
          return [
            details.dtcCode || "N/A",
            details.description || log.operation,
            log.success ? "ACTIVE" : "ERROR"
          ];
        }) : [["No DTCs", "No diagnostic trouble codes recorded in selected sessions", "N/A"]];

        autoTable(doc, {
          startY: yPos,
          head: [["Code", "Description", "Status"]],
          body: dtcRows,
          theme: "grid",
          headStyles: { fillColor: [220, 38, 38] },
          styles: { fontSize: 8 },
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;
      }

      if (includePartNumbers) {
        if (yPos > 250) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text("ECU Part Numbers & Release Versions", 20, yPos);
        yPos += 8;

        const partNumberLogs = auditLogs?.filter(log => 
          log.operation.includes("READ_DID") ||
          log.operation === "SCAN_MODULE" ||
          log.operation === "READ_PART_NUMBER"
        ) || [];
        
        const modulePartNumbers = new Map<string, { partNumber: string; softwareVersion: string; hardwareVersion: string }>();
        
        partNumberLogs.forEach(log => {
          const details = log.details ? JSON.parse(log.details) : {};
          if (log.moduleCode && (details.partNumber || details.softwareVersion)) {
            modulePartNumbers.set(log.moduleCode, {
              partNumber: details.partNumber || details.did_F187 || "N/A",
              softwareVersion: details.softwareVersion || details.did_F189 || "N/A",
              hardwareVersion: details.hardwareVersion || details.did_F191 || "N/A"
            });
          }
        });

        if (modulePartNumbers.size === 0 && backups && backups.length > 0) {
          const uniqueModules = new Set(backups.map(b => b.moduleCode));
          uniqueModules.forEach(moduleCode => {
            modulePartNumbers.set(moduleCode, {
              partNumber: "Scan required",
              softwareVersion: "Scan required",
              hardwareVersion: "Scan required"
            });
          });
        }

        const partNumberRows = Array.from(modulePartNumbers.entries()).map(([moduleCode, info]) => [
          moduleCode,
          info.partNumber,
          info.softwareVersion,
          info.hardwareVersion
        ]);

        if (partNumberRows.length > 0) {
          autoTable(doc, {
            startY: yPos,
            head: [["Module", "Part Number", "Software Version", "Hardware Version"]],
            body: partNumberRows,
            theme: "grid",
            headStyles: { fillColor: [220, 38, 38] },
            styles: { fontSize: 8 },
          });

          yPos = (doc as any).lastAutoTable.finalY + 10;
        } else {
          doc.setFontSize(10);
          doc.setFont("helvetica", "italic");
          doc.text("No ECU part number data available. Perform DID scan (0xF187, 0xF189, 0xF191) to populate.", 20, yPos);
          yPos += 10;
        }
      }

      if (includePairing) {
        if (yPos > 250) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text("Module Pairing Validation", 20, yPos);
        yPos += 8;

        const pairingLogs = auditLogs?.filter(log => 
          log.operation.includes("PAIRING") ||
          log.operation === "VALIDATE_PAIRING" ||
          log.operation === "CHECK_IMMOBILIZER"
        ) || [];
        
        const pairingRows = pairingLogs.length > 0 ? pairingLogs.slice(0, 20).map(log => {
          const details = log.details ? JSON.parse(log.details) : {};
          return [
            details.moduleA || log.moduleCode || "N/A",
            details.moduleB || "N/A",
            log.success ? "MATCHED" : "MISMATCH",
            log.success ? "✓" : "✗"
          ];
        }) : [["No Validation", "N/A", "No pairing validation performed", "N/A"]];

        autoTable(doc, {
          startY: yPos,
          head: [["Module A", "Module B", "Status", "Valid"]],
          body: pairingRows,
          theme: "grid",
          headStyles: { fillColor: [220, 38, 38] },
          styles: { fontSize: 8 },
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;
      }

      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setFont("helvetica", "normal");
        doc.text(
          `Page ${i} of ${pageCount}`,
          105,
          doc.internal.pageSize.height - 10,
          { align: "center" }
        );
        doc.text(
          "THE SRT LAB - Professional Automotive Diagnostics",
          105,
          doc.internal.pageSize.height - 5,
          { align: "center" }
        );
      }

      const fileName = `diagnostic_report_${Date.now()}.pdf`;
      doc.save(fileName);
      toast.success("Diagnostic report generated successfully");
    } catch (error) {
      toast.error("Failed to generate report: " + (error as Error).message);
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleSession = (sessionId: string) => {
    setSelectedSessions(prev =>
      prev.includes(sessionId)
        ? prev.filter(id => id !== sessionId)
        : [...prev, sessionId]
    );
  };

  const selectAll = () => {
    if (sessions) {
      setSelectedSessions(sessions.map(s => s.id));
    }
  };

  const deselectAll = () => {
    setSelectedSessions([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <FileText className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">DIAGNOSTIC REPORT GENERATOR</h1>
            <p className="text-gray-600">
              Combine session history, DTC codes, module scans, and pairing validation into professional PDF reports
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Select Sessions</CardTitle>
                <CardDescription>Choose which diagnostic sessions to include in the report</CardDescription>
                <div className="flex gap-2 mt-4">
                  <Button onClick={selectAll} variant="outline" size="sm">
                    Select All
                  </Button>
                  <Button onClick={deselectAll} variant="outline" size="sm">
                    Deselect All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {sessions && sessions.length > 0 ? (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {sessions.map((session) => (
                      <div
                        key={session.id}
                        onClick={() => toggleSession(session.id)}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedSessions.includes(session.id)
                            ? "bg-red-50 border-red-600"
                            : "bg-white border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <Checkbox
                            checked={selectedSessions.includes(session.id)}
                            onCheckedChange={() => toggleSession(session.id)}
                          />
                          <div className="flex-1">
                            <div className="font-medium">{session.startedAt.toLocaleString()}</div>
                            {session.vin && (
                              <div className="text-sm text-gray-600">VIN: {session.vin}</div>
                            )}
                            {session.vehicleInfo && (
                              <div className="text-sm text-gray-600">{session.vehicleInfo}</div>
                            )}
                            <div className="flex items-center gap-2">
                              {session.status === "completed" ? (
                                <CheckCircle2 className="h-4 w-4 text-green-600" />
                              ) : (
                                <AlertCircle className="h-4 w-4 text-yellow-600" />
                              )}
                              <span className="text-xs text-gray-500">
                                {session.adapterType || "Unknown Adapter"}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No sessions found</p>
                    <p className="text-sm mt-2">Create diagnostic sessions to generate reports</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Report Sections</CardTitle>
                <CardDescription>Choose what to include in the report</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="module-scan"
                    checked={includeModuleScan}
                    onCheckedChange={(checked) => setIncludeModuleScan(checked as boolean)}
                  />
                  <Label htmlFor="module-scan" className="cursor-pointer">
                    Module Scan Results
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="dtcs"
                    checked={includeDTCs}
                    onCheckedChange={(checked) => setIncludeDTCs(checked as boolean)}
                  />
                  <Label htmlFor="dtcs" className="cursor-pointer">
                    Diagnostic Trouble Codes
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="pairing"
                    checked={includePairing}
                    onCheckedChange={(checked) => setIncludePairing(checked as boolean)}
                  />
                  <Label htmlFor="pairing" className="cursor-pointer">
                    Module Pairing Validation
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="part-numbers"
                    checked={includePartNumbers}
                    onCheckedChange={(checked) => setIncludePartNumbers(checked as boolean)}
                  />
                  <Label htmlFor="part-numbers" className="cursor-pointer">
                    ECU Part Numbers & Versions
                  </Label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Report Template</CardTitle>
                <CardDescription>Choose a report template for your use case</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <select
                  value={selectedTemplate}
                  onChange={(e) => setSelectedTemplate(e.target.value as any)}
                  className="w-full h-10 px-3 rounded-md border border-gray-300"
                >
                  <option value="standard">Standard Diagnostic Report</option>
                  <option value="warranty">Warranty Claim Report</option>
                  <option value="inspection">Pre-Purchase Inspection</option>
                  <option value="repair">Repair Documentation</option>
                </select>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Auto-Scan Modules</CardTitle>
                <CardDescription>Scan all modules for part numbers before generating report</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={handleAutoScan}
                  disabled={isScanning}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <Scan className="h-4 w-4" />
                  {isScanning ? "Scanning Modules..." : "Scan All Modules for Part Numbers"}
                </Button>
                {isScanning && (
                  <p className="text-xs text-gray-500 mt-2">Reading DIDs 0xF187, 0xF189, 0xF191 from all discovered modules...</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Generate Report</CardTitle>
                <CardDescription>Create a professional PDF diagnostic report</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="text-sm text-blue-900">
                    <p className="font-bold mb-2">Report will include:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>{selectedSessions.length} diagnostic session(s)</li>
                      {includeModuleScan && <li>Module backup history</li>}
                      {includeDTCs && <li>Diagnostic trouble codes</li>}
                      {includePartNumbers && <li>ECU part numbers & versions</li>}
                      {includePairing && <li>Module pairing validation</li>}
                      <li className="font-bold">Template: {selectedTemplate}</li>
                    </ul>
                  </div>
                </div>

                <Button
                  onClick={handleGenerateReport}
                  disabled={isGenerating || selectedSessions.length === 0}
                  className="w-full gap-2"
                >
                  <Download className="h-4 w-4" />
                  {isGenerating ? "Generating..." : "Generate PDF Report"}
                </Button>
                
                <Button
                  onClick={() => setShowScheduleDialog(true)}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <Calendar className="h-4 w-4" />
                  Schedule Recurring Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
