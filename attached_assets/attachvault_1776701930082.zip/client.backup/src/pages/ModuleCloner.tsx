import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Upload, Download, AlertTriangle, CheckCircle2, FileCode, Shield } from "lucide-react";
import { toast } from "sonner";
import HexViewer from "@/components/HexViewer";
import CalibrationFileBrowser from "@/components/CalibrationFileBrowser";
import { BackButton } from "@/components/BackButton";

export default function ModuleCloner() {
  const [sourceFile, setSourceFile] = useState<File | null>(null);
  const [targetVIN, setTargetVIN] = useState("");
  const [moduleType, setModuleType] = useState<string>("BCM");
  const [cloneMode, setCloneMode] = useState<string>("full");
  const [sourceData, setSourceData] = useState<ArrayBuffer | null>(null);
  const [clonedData, setClonedData] = useState<ArrayBuffer | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLibraryFile, setSelectedLibraryFile] = useState<string | null>(null);
  const [showHexViewer, setShowHexViewer] = useState(false);
  const [vinOffsets, setVinOffsets] = useState<any>(null);

  const createBackupMutation = trpc.backups.create.useMutation();
  const { data: libraryFiles } = trpc.vinPatcher.listCalibrationFiles.useQuery();
  const patchVINMutation = trpc.vinPatcher.patchVIN.useMutation();
  const downloadFileMutation = trpc.vinPatcher.downloadCalibrationFile.useQuery(
    { filename: selectedLibraryFile || '' },
    { enabled: false }
  );
  const moduleInfoQuery = trpc.vinPatcher.getModuleInfo.useQuery(
    { moduleType },
    { enabled: !!moduleType }
  );

  useEffect(() => {
    if (moduleInfoQuery.data) {
      setVinOffsets(moduleInfoQuery.data);
    }
  }, [moduleInfoQuery.data]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSourceFile(file);
    const buffer = await file.arrayBuffer();
    setSourceData(buffer);
    setSelectedLibraryFile(null);
    toast.success("Source module loaded successfully");
  };

  const handleLoadFromLibrary = async (filename: string) => {
    setSelectedLibraryFile(filename);
    const result = await downloadFileMutation.refetch();
    if (result.data) {
      const buffer = atob(result.data.data);
      const bytes = new Uint8Array(buffer.length);
      for (let i = 0; i < buffer.length; i++) {
        bytes[i] = buffer.charCodeAt(i);
      }
      setSourceData(bytes.buffer);
      setSourceFile(new File([bytes], filename));
      toast.success(`Loaded ${filename} from library`);
    }
  };

  const handleClone = async () => {
    if (!sourceData || !targetVIN) {
      toast.error("Please upload source file and enter target VIN");
      return;
    }

    if (targetVIN.length !== 17) {
      toast.error("VIN must be exactly 17 characters");
      return;
    }

    setIsProcessing(true);

    try {
      // Use VIN patcher backend if we have a library file
      if (selectedLibraryFile) {
        const result = await patchVINMutation.mutateAsync({
          inputFilename: selectedLibraryFile,
          newVIN: targetVIN,
          moduleType,
        });
        toast.success(result.message);
        toast.info(`Output: ${result.outputFilename}`);
        setIsProcessing(false);
        return;
      }
      // Create backup of source
      const sourceBlob = new Blob([sourceData]);
      const sourceUrl = URL.createObjectURL(sourceBlob);
      
      await createBackupMutation.mutateAsync({
        moduleCode: moduleType,
        moduleName: `${moduleType} Source Module`,
        fileName: sourceFile?.name || "source.bin",
        fileData: sourceUrl,
        vin: "SOURCE_MODULE",
      });

      // Clone the data based on mode
      const cloned = new Uint8Array(sourceData);
      
      if (cloneMode === "full" || cloneMode === "vin") {
        // Update VIN at all known offsets for the module type
        const vinOffsets = getVINOffsets(moduleType);
        const vinBytes = new TextEncoder().encode(targetVIN);
        
        vinOffsets.forEach(offset => {
          if (offset + 17 <= cloned.length) {
            cloned.set(vinBytes, offset);
          }
        });
      }

      // Recalculate checksums
      if (cloneMode === "full" || cloneMode === "vin") {
        recalculateChecksums(cloned, moduleType);
      }

      setClonedData(cloned.buffer);
      toast.success("Module cloned successfully!");
      
    } catch (error) {
      console.error("Clone error:", error);
      toast.error("Failed to clone module");
    } finally {
      setIsProcessing(false);
    }
  };

  const getVINOffsets = (moduleType: string): number[] => {
    const offsets: Record<string, number[]> = {
      "BCM": [0x100, 0x200],
      "RFHUB": [0x100],
      "ECM": [0x160],
      "ABS": [0x20, 0x100],
      "TCM": [0x80, 0x200],
      "ORCM": [0x200],
    };
    return offsets[moduleType] || [0x100];
  };

  const recalculateChecksums = (data: Uint8Array, moduleType: string) => {
    // Implement checksum recalculation based on module type
    if (moduleType === "RFHUB") {
      // RFHUB complement checksum
      const target = data.reduce((sum, byte) => sum + byte, 0) & 0xFFFF;
      const complement = (0x10000 - target) & 0xFFFF;
      // Write complement at checksum location (module-specific)
    } else if (moduleType === "BCM") {
      // BCM CRC-16/CCITT-FALSE
      let crc = 0xFFFF;
      for (let i = 0; i < data.length - 2; i++) {
        crc ^= data[i] << 8;
        for (let j = 0; j < 8; j++) {
          crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1;
        }
      }
      crc &= 0xFFFF;
      // Write CRC at checksum location (module-specific)
    }
  };

  const downloadClonedFile = () => {
    if (!clonedData) return;

    const blob = new Blob([clonedData]);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${moduleType}_cloned_${targetVIN}.bin`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Cloned file downloaded");
  };

  const getHexDump = (data: ArrayBuffer | null, offset: number, length: number): string => {
    if (!data) return "";
    const view = new Uint8Array(data);
    const slice = view.slice(offset, offset + length);
    return Array.from(slice)
      .map(b => b.toString(16).padStart(2, "0"))
      .join(" ");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <BackButton />
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">MODULE CLONER</h1>
          <p className="text-gray-600">Full EEPROM backup/restore with automatic VIN synchronization</p>
        </div>

        {/* Warning */}
        <Alert className="mb-6 border-red-600 bg-red-50">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>WARNING:</strong> Module cloning is an advanced operation. Incorrect cloning can brick modules.
            Always create backups before writing. Verify VIN and checksums before flashing.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Source Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Source Module
              </CardTitle>
              <CardDescription>Upload the module dump to clone</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="source-file">Module File (.bin, .hex, .eeprom)</Label>
                <Input
                  id="source-file"
                  type="file"
                  accept=".bin,.hex,.eeprom,.flash"
                  onChange={handleFileUpload}
                  className="mt-2"
                />
              </div>

              {sourceFile && (
                <div className="bg-gray-50 p-4 rounded space-y-2">
                  <p className="text-sm"><strong>File:</strong> {sourceFile.name}</p>
                  <p className="text-sm"><strong>Size:</strong> {(sourceFile.size / 1024).toFixed(2)} KB</p>
                  <Badge variant="outline" className="mt-2">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Loaded
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Clone Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Copy className="h-5 w-5" />
                Clone Configuration
              </CardTitle>
              <CardDescription>Configure cloning parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="module-type">Module Type</Label>
                <Select value={moduleType} onValueChange={setModuleType}>
                  <SelectTrigger id="module-type" className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                    <SelectItem value="RFHUB">RFHUB (RF Hub)</SelectItem>
                    <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                    <SelectItem value="ABS">ABS (Anti-lock Braking System)</SelectItem>
                    <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                    <SelectItem value="ORCM">ORCM (Occupant Restraint Control Module)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="clone-mode">Clone Mode</Label>
                <Select value={cloneMode} onValueChange={setCloneMode}>
                  <SelectTrigger id="clone-mode" className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full">Full Clone (All Data + VIN Sync)</SelectItem>
                    <SelectItem value="vin">VIN Only (Update VIN + Checksums)</SelectItem>
                    <SelectItem value="security">Security Bytes Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="target-vin">Target VIN (17 characters)</Label>
                <Input
                  id="target-vin"
                  value={targetVIN}
                  onChange={(e) => setTargetVIN(e.target.value.toUpperCase())}
                  placeholder="1C4RJFBG8FC123456"
                  maxLength={17}
                  className="mt-2 font-mono"
                />
                {targetVIN && targetVIN.length !== 17 && (
                  <p className="text-sm text-red-600 mt-1">VIN must be exactly 17 characters</p>
                )}
              </div>

              <Button
                onClick={handleClone}
                disabled={!sourceData || !targetVIN || targetVIN.length !== 17 || isProcessing}
                className="w-full"
              >
                {isProcessing ? "Cloning..." : "Clone Module"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Calibration File Library */}
        <div className="mt-6">
          <CalibrationFileBrowser
            onSelectFile={(filename, data) => {
              setSourceData(data);
              setSourceFile(new File([data], filename));
              setSelectedLibraryFile(filename);
              toast.success(`Loaded ${filename} from library`);
            }}
          />
        </div>

        {/* Hex Viewer */}
        {sourceData && (
          <div className="mt-6">
            <HexViewer
              data={sourceData}
              vinOffsets={vinOffsets}
              moduleType={moduleType}
            />
          </div>
        )}

        {/* Results */}
        {clonedData && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileCode className="h-5 w-5" />
                Clone Results
              </CardTitle>
              <CardDescription>Review and download cloned module</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="comparison">
                <TabsList>
                  <TabsTrigger value="comparison">Hex Comparison</TabsTrigger>
                  <TabsTrigger value="info">Module Info</TabsTrigger>
                </TabsList>

                <TabsContent value="comparison" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold mb-2">Original (Offset 0x100)</h4>
                      <pre className="bg-gray-900 text-green-400 p-4 rounded font-mono text-xs overflow-x-auto">
                        {getHexDump(sourceData, 0x100, 32)}
                      </pre>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Cloned (Offset 0x100)</h4>
                      <pre className="bg-gray-900 text-green-400 p-4 rounded font-mono text-xs overflow-x-auto">
                        {getHexDump(clonedData, 0x100, 32)}
                      </pre>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="info">
                  <div className="space-y-2">
                    <p><strong>Module Type:</strong> {moduleType}</p>
                    <p><strong>Target VIN:</strong> <span className="font-mono">{targetVIN}</span></p>
                    <p><strong>Clone Mode:</strong> {cloneMode}</p>
                    <p><strong>File Size:</strong> {(clonedData.byteLength / 1024).toFixed(2)} KB</p>
                    <Badge variant="default" className="bg-green-600 mt-2">
                      <Shield className="h-3 w-3 mr-1" />
                      Checksums Recalculated
                    </Badge>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="mt-6 flex gap-4">
                <Button onClick={downloadClonedFile} className="flex-1">
                  <Download className="h-4 w-4 mr-2" />
                  Download Cloned File
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
