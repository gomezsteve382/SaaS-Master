import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import {
  Copy, Cpu, Car, Radio, Cog, Shield, Zap, AlertTriangle,
  CheckCircle2, ArrowRight, Database, FileCode
} from "lucide-react";

interface ModuleType {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  difficulty: "easy" | "medium" | "hard";
  risks: string[];
  criticalDids: string[];
  route: string;
}

const modules: ModuleType[] = [
  {
    id: "gateway",
    name: "Gateway (GPEC4)",
    icon: <Shield className="h-8 w-8" />,
    description: "Central communication hub with SGW authorization",
    difficulty: "hard",
    risks: ["SGW lockout", "Module authorization mismatch", "CAN bus failure"],
    criticalDids: ["F190 (VIN)", "F187 (Config)", "F1B0 (SGW List)"],
    route: "/clone/gateway"
  },
  {
    id: "ecm",
    name: "Engine Control Module",
    icon: <Cog className="h-8 w-8" />,
    description: "Engine management and powertrain control",
    difficulty: "medium",
    risks: ["Odometer fraud detection", "Immobilizer mismatch", "Emissions tampering flags"],
    criticalDids: ["F190 (VIN)", "F18C (Serial)", "F1C1 (Odometer)"],
    route: "/clone/ecm"
  },
  {
    id: "bcm",
    name: "Body Control Module",
    icon: <Car className="h-8 w-8" />,
    description: "Body electronics, lighting, and security",
    difficulty: "medium",
    risks: ["Key FOB loss", "SKIM lockout", "Feature configuration mismatch"],
    criticalDids: ["F190 (VIN)", "F1D0 (Key FOBs)", "F1D1 (SKIM)"],
    route: "/clone/bcm"
  },
  {
    id: "rfhub",
    name: "RF Hub (TPMS)",
    icon: <Radio className="h-8 w-8" />,
    description: "Tire pressure monitoring system",
    difficulty: "easy",
    risks: ["Sensor ID mismatch", "TPMS warning light"],
    criticalDids: ["F190 (VIN)", "F1E0 (Sensor IDs)"],
    route: "/clone/rfhub"
  },
  {
    id: "tcm",
    name: "Transmission Control",
    icon: <Zap className="h-8 w-8" />,
    description: "Transmission shift control and adaptation",
    difficulty: "medium",
    risks: ["Shift adaptation loss", "Transmission mismatch", "Harsh shifting"],
    criticalDids: ["F190 (VIN)", "F18C (Serial)", "F1F0 (Adaptation)"],
    route: "/clone/tcm"
  },
  {
    id: "abs",
    name: "ABS Module",
    icon: <Shield className="h-8 w-8" />,
    description: "Anti-lock braking system",
    difficulty: "easy",
    risks: ["Brake system mismatch", "ABS warning light"],
    criticalDids: ["F190 (VIN)", "F18C (Serial)"],
    route: "/clone/abs"
  }
];

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case "easy": return "bg-green-500";
    case "medium": return "bg-yellow-500";
    case "hard": return "bg-red-500";
    default: return "bg-gray-500";
  }
};

export default function ModuleCloningHub() {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="p-4 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl">
            <Copy className="h-10 w-10" />
          </div>
          <div>
            <h1 className="text-4xl font-black tracking-tight">MODULE CLONING HUB</h1>
            <p className="text-gray-400 text-lg">
              Professional module cloning with DID transfer and verification
            </p>
          </div>
        </div>

        {/* Warning Banner */}
        <Card className="border-yellow-500/50 bg-yellow-500/10">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
              <div className="space-y-2">
                <h3 className="font-bold text-yellow-500">Critical Safety Information</h3>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• <strong>Always backup source module</strong> before reading data</li>
                  <li>• <strong>Verify part numbers match</strong> between source and target</li>
                  <li>• <strong>Test on bench first</strong> - never clone directly in vehicle</li>
                  <li>• <strong>Security gateway (SGW) lockout</strong> can brick modules permanently</li>
                  <li>• <strong>Keep 12V power stable</strong> during write operations (no interruptions)</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Access Tools */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link href="/clone/did-explorer">
            <Card className="cursor-pointer hover:border-blue-500 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-blue-500" />
                  DID Explorer
                </CardTitle>
                <CardDescription>
                  Manual read/write of any Data Identifier (DID) - Advanced users only
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/clone/batch">
            <Card className="cursor-pointer hover:border-purple-500 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileCode className="h-5 w-5 text-purple-500" />
                  Batch Clone
                </CardTitle>
                <CardDescription>
                  Clone multiple modules from saved backup files
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>
        </div>

        {/* Module Selection Grid */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Select Module Type</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {modules.map((module) => (
              <Link key={module.id} href={module.route}>
                <Card 
                  className={`cursor-pointer transition-all hover:scale-105 ${
                    selectedModule === module.id ? 'border-blue-500 bg-blue-500/10' : ''
                  }`}
                  onClick={() => setSelectedModule(module.id)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg">
                        {module.icon}
                      </div>
                      <Badge className={getDifficultyColor(module.difficulty)}>
                        {module.difficulty.toUpperCase()}
                      </Badge>
                    </div>
                    <CardTitle className="mt-4">{module.name}</CardTitle>
                    <CardDescription className="text-gray-400">
                      {module.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* Critical DIDs */}
                    <div>
                      <p className="text-xs font-semibold text-gray-400 mb-1">Critical DIDs:</p>
                      <div className="flex flex-wrap gap-1">
                        {module.criticalDids.map((did) => (
                          <Badge key={did} variant="outline" className="text-xs">
                            {did}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Risks */}
                    <div>
                      <p className="text-xs font-semibold text-gray-400 mb-1">Risks:</p>
                      <ul className="text-xs text-gray-300 space-y-0.5">
                        {module.risks.slice(0, 2).map((risk, idx) => (
                          <li key={idx}>• {risk}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Action Button */}
                    <Button className="w-full gap-2" variant="outline">
                      Start Cloning
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Information Section */}
        <Card>
          <CardHeader>
            <CardTitle>Cloning Process Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-500/20 rounded">
                  <CheckCircle2 className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-semibold">1. Read Source</h3>
                  <p className="text-sm text-gray-400">Connect to source module and read all DIDs</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-purple-500/20 rounded">
                  <Database className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <h3 className="font-semibold">2. Save Backup</h3>
                  <p className="text-sm text-gray-400">Export configuration to JSON file</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-green-500/20 rounded">
                  <Copy className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <h3 className="font-semibold">3. Write Target</h3>
                  <p className="text-sm text-gray-400">Transfer data to target module</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-yellow-500/20 rounded">
                  <CheckCircle2 className="h-5 w-5 text-yellow-500" />
                </div>
                <div>
                  <h3 className="font-semibold">4. Verify</h3>
                  <p className="text-sm text-gray-400">Read back and confirm all DIDs match</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
