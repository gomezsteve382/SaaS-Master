import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";
import { Zap, ArrowLeft, AlertTriangle, Loader2, CheckCircle2, XCircle, Radio } from "lucide-react";
import { Link } from "wouter";
import { MODULE_DATABASE } from "@shared/module-database";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BackButton } from "@/components/BackButton";

export default function LiveProgrammer() {
  const [port, setPort] = useState<any>(null);
  const [connected, setConnected] = useState(false);
  const [selectedModule, setSelectedModule] = useState("");
  const [newVin, setNewVin] = useState("");
  const [currentVin, setCurrentVin] = useState("");
  const [status, setStatus] = useState<string[]>([]);
  const [processing, setProcessing] = useState(false);

  const addStatus = (message: string) => {
    setStatus(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  };

  const connectSerial = async () => {
    try {
      if (!('serial' in navigator)) {
        toast.error("Web Serial API not supported in this browser");
        return;
      }

      const selectedPort = await (navigator as any).serial.requestPort();
      await selectedPort.open({ baudRate: 38400 });
      
      setPort(selectedPort);
      setConnected(true);
      addStatus("Connected to OBD2 adapter");
      toast.success("Connected to OBD2 adapter");
    } catch (error: any) {
      toast.error(`Connection failed: ${error.message}`);
      addStatus(`ERROR: ${error.message}`);
    }
  };

  const disconnectSerial = async () => {
    if (port) {
      try {
        await port.close();
        setPort(null);
        setConnected(false);
        addStatus("Disconnected from OBD2 adapter");
        toast.info("Disconnected");
      } catch (error: any) {
        toast.error(`Disconnect failed: ${error.message}`);
      }
    }
  };

  const sendCommand = async (command: string): Promise<string> => {
    if (!port) throw new Error("Not connected");

    const writer = port.writable?.getWriter();
    const reader = port.readable?.getReader();
    
    if (!writer || !reader) throw new Error("Port not ready");

    try {
      // Send command
      const encoder = new TextEncoder();
      await writer.write(encoder.encode(command + '\r'));
      
      // Read response
      const decoder = new TextDecoder();
      let response = '';
      let attempts = 0;
      
      while (attempts < 10) {
        const { value, done } = await reader.read();
        if (done) break;
        
        response += decoder.decode(value);
        
        // Check for prompt (>)
        if (response.includes('>')) {
          break;
        }
        
        attempts++;
      }
      
      return response.trim();
    } finally {
      writer.releaseLock();
      reader.releaseLock();
    }
  };

  const readVin = async () => {
    if (!selectedModule) {
      toast.error("Please select a module");
      return;
    }

    setProcessing(true);
    addStatus(`Reading VIN from ${selectedModule}...`);

    try {
      const module = Object.values(MODULE_DATABASE).find((m: any) => m.code === selectedModule);
      if (!module) throw new Error("Module not found");

      // Initialize ELM327
      await sendCommand("ATZ"); // Reset
      await sendCommand("ATE0"); // Echo off
      await sendCommand("ATH1"); // Headers on
      await sendCommand("ATSP6"); // Set protocol CAN 500kbps

      // Set CAN filter to module TX address
      await sendCommand(`ATCF ${module.tx.toString(16)}`);
      
      // UDS: Start Diagnostic Session (0x10 0x03)
      addStatus("Starting diagnostic session...");
      const sessionResp = await sendCommand(`${module.rx.toString(16)} 02 10 03`);
      addStatus(`Session response: ${sessionResp}`);

      // UDS: Read Data By Identifier (0x22) - VIN is DID 0xF190
      addStatus("Reading VIN (DID 0xF190)...");
      const vinResp = await sendCommand(`${module.rx.toString(16)} 03 22 F1 90`);
      addStatus(`VIN response: ${vinResp}`);

      // Parse VIN from response
      // Expected format: "7E8 10 14 62 F1 90 XX XX XX..." (multi-frame)
      // Simplified parsing - real implementation needs ISO-TP
      const vinMatch = vinResp.match(/62 F1 90 ([0-9A-F ]+)/i);
      if (vinMatch) {
        const vinHex = vinMatch[1].replace(/ /g, '');
        const vin = Buffer.from(vinHex, 'hex').toString('ascii').substring(0, 17);
        setCurrentVin(vin);
        addStatus(`VIN read: ${vin}`);
        toast.success(`VIN: ${vin}`);
      } else {
        throw new Error("Failed to parse VIN from response");
      }
    } catch (error: any) {
      toast.error(`Read failed: ${error.message}`);
      addStatus(`ERROR: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const writeVin = async () => {
    if (!selectedModule || !newVin || newVin.length !== 17) {
      toast.error("Please select module and enter valid VIN");
      return;
    }

    setProcessing(true);
    addStatus(`Writing VIN to ${selectedModule}...`);

    try {
      const module = Object.values(MODULE_DATABASE).find((m: any) => m.code === selectedModule);
      if (!module) throw new Error("Module not found");

      // Check if module is OTP
      if (module.otpInfo) {
        const confirmed = window.confirm(
          `⚠️ WARNING: ${module.name} is ONE-TIME PROGRAMMABLE!\n\n` +
          `This operation is IRREVERSIBLE. The VIN can only be written ONCE.\n\n` +
          `Current VIN: ${currentVin || 'Unknown'}\n` +
          `New VIN: ${newVin}\n\n` +
          `Are you absolutely sure you want to proceed?`
        );
        
        if (!confirmed) {
          addStatus("Operation cancelled by user");
          setProcessing(false);
          return;
        }
      }

      // Initialize ELM327
      await sendCommand("ATZ");
      await sendCommand("ATE0");
      await sendCommand("ATH1");
      await sendCommand("ATSP6");
      await sendCommand(`ATCF ${module.tx.toString(16)}`);

      // Start diagnostic session
      addStatus("Starting diagnostic session...");
      await sendCommand(`${module.rx.toString(16)} 02 10 03`);

      // Security access (if required)
      if (module.protectionLevel === 'otp' || module.protectionLevel === 'software') {
        addStatus(`Security access may be required...`);
        // TODO: Implement security access with FCA keygen
        addStatus("⚠️ Security access not implemented in this demo");
      }

      // Write VIN (DID 0xF190)
      addStatus("Writing VIN...");
      const vinHex = Buffer.from(newVin).toString('hex').toUpperCase();
      const writeResp = await sendCommand(`${module.rx.toString(16)} 2E F1 90 ${vinHex}`);
      addStatus(`Write response: ${writeResp}`);

      // Check for positive response (0x6E)
      if (writeResp.includes('6E')) {
        addStatus(`✓ VIN written successfully: ${newVin}`);
        toast.success("VIN written successfully!");
        setCurrentVin(newVin);
      } else {
        throw new Error("Write failed - negative response from module");
      }

      // Reset ECU
      addStatus("Resetting module...");
      await sendCommand(`${module.rx.toString(16)} 02 11 01`);
      addStatus("✓ Module reset complete");
      
    } catch (error: any) {
      toast.error(`Write failed: ${error.message}`);
      addStatus(`ERROR: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const module = Object.values(MODULE_DATABASE).find((m: any) => m.code === selectedModule);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-gray-900 to-red-950 text-white py-8">
        <div className="container">
          <BackButton />
      <Link href="/">
            <Button variant="ghost" className="text-white hover:text-red-500 mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Tools
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <Zap className="w-12 h-12 text-red-500" />
            <div>
              <h1 className="text-4xl font-black uppercase tracking-tight">Live Module Programmer</h1>
              <p className="text-gray-300 mt-1">Real-time VIN programming via OBD2 with full UDS workflow</p>
            </div>
          </div>
        </div>
        <div className="red-divider mt-6"></div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Connection */}
            <Card className="aggressive-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Radio className="w-5 h-5 text-red-600" />
                  OBD2 Connection
                </CardTitle>
                <CardDescription>
                  Connect via ELM327, J2534, or Arduino CAN Shield
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  {!connected ? (
                    <Button onClick={connectSerial} className="aggressive-button">
                      <Radio className="w-4 h-4 mr-2" />
                      Connect to OBD2 Adapter
                    </Button>
                  ) : (
                    <>
                      <Badge className="bg-green-600 text-white px-4 py-2">
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Connected
                      </Badge>
                      <Button onClick={disconnectSerial} variant="outline" size="sm">
                        Disconnect
                      </Button>
                    </>
                  )}
                </div>
                
                {!connected && (
                  <Alert>
                    <AlertDescription className="text-sm">
                      Web Serial API requires Chrome/Edge browser. Connect ELM327 adapter via USB or Bluetooth.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Module Selection */}
            <Card className="aggressive-card">
              <CardHeader>
                <CardTitle>Module Selection</CardTitle>
                <CardDescription>
                  Select target module for VIN programming
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="module">Target Module</Label>
                  <Select value={selectedModule} onValueChange={setSelectedModule} disabled={!connected || processing}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select a module..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.values(MODULE_DATABASE).map((mod: any) => (
                        <SelectItem key={mod.code} value={mod.code}>
                          {mod.name} ({mod.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {module && (
                  <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded text-sm">
                    <div>
                      <p className="text-muted-foreground">CAN TX</p>
                      <p className="font-mono">0x{module.tx.toString(16).toUpperCase()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">CAN RX</p>
                      <p className="font-mono">0x{module.rx.toString(16).toUpperCase()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Bus</p>
                      <Badge variant="outline">{module.bus}</Badge>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Protection</p>
                      <Badge variant={module.protectionLevel === 'otp' ? 'destructive' : 'secondary'}>
                        {module.protectionLevel}
                      </Badge>
                    </div>
                    {module.otpInfo && (
                      <div className="col-span-2">
                        <Alert className="border-red-600 bg-red-50">
                          <AlertTriangle className="w-4 h-4 text-red-600" />
                          <AlertDescription className="text-xs">
                            <strong>ONE-TIME PROGRAMMABLE</strong> - VIN can only be written once!
                          </AlertDescription>
                        </Alert>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* VIN Operations */}
            <Card className="aggressive-card">
              <CardHeader>
                <CardTitle>VIN Operations</CardTitle>
                <CardDescription>
                  Read current VIN or write new VIN to module
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="currentVin">Current VIN</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      id="currentVin"
                      value={currentVin}
                      readOnly
                      placeholder="Click Read VIN to retrieve..."
                      className="font-mono"
                    />
                    <Button
                      onClick={readVin}
                      disabled={!connected || !selectedModule || processing}
                      variant="outline"
                    >
                      {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : "Read VIN"}
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="newVin">New VIN</Label>
                  <Input
                    id="newVin"
                    value={newVin}
                    onChange={(e) => setNewVin(e.target.value.toUpperCase())}
                    placeholder="1C4RJFBG8FC123456"
                    maxLength={17}
                    className="mt-2 font-mono"
                    disabled={processing}
                  />
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-xs text-muted-foreground">
                      {newVin.length}/17 characters
                    </p>
                    {newVin.length === 17 && (
                      <Badge variant="outline" className="text-xs border-green-600 text-green-600">
                        Valid Length
                      </Badge>
                    )}
                  </div>
                </div>

                <Button
                  onClick={writeVin}
                  disabled={!connected || !selectedModule || !newVin || newVin.length !== 17 || processing}
                  className="aggressive-button w-full"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      Write VIN to Module
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Status Log */}
            <Card className="aggressive-card">
              <CardHeader>
                <CardTitle className="text-lg">Status Log</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-black text-green-400 p-4 rounded font-mono text-xs h-[300px] overflow-y-auto">
                  {status.length === 0 ? (
                    <p className="text-gray-600">Waiting for operations...</p>
                  ) : (
                    status.map((msg, idx) => (
                      <div key={idx} className="mb-1">
                        {msg}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Info Panel */}
          <div className="space-y-6">
            <Alert className="border-red-600 bg-red-50">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <AlertDescription className="text-sm">
                <strong className="font-bold">Critical Warning</strong>
                <br />
                Live programming can brick modules if interrupted. Ensure stable power and connection. Never disconnect during write operations.
              </AlertDescription>
            </Alert>

            <Card className="aggressive-card">
              <CardHeader>
                <CardTitle className="text-lg">UDS Workflow</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">1</Badge>
                  <div>
                    <p className="font-semibold">Diagnostic Session</p>
                    <p className="text-muted-foreground text-xs">Service 0x10 - Extended session</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">2</Badge>
                  <div>
                    <p className="font-semibold">Security Access</p>
                    <p className="text-muted-foreground text-xs">Service 0x27 - Seed/key exchange</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">3</Badge>
                  <div>
                    <p className="font-semibold">Read VIN</p>
                    <p className="text-muted-foreground text-xs">Service 0x22 - DID 0xF190</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">4</Badge>
                  <div>
                    <p className="font-semibold">Write VIN</p>
                    <p className="text-muted-foreground text-xs">Service 0x2E - DID 0xF190</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">5</Badge>
                  <div>
                    <p className="font-semibold">ECU Reset</p>
                    <p className="text-muted-foreground text-xs">Service 0x11 - Hard reset</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="aggressive-card">
              <CardHeader>
                <CardTitle className="text-lg">Supported Adapters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div>
                  <Badge className="mb-1">ELM327</Badge>
                  <p className="text-muted-foreground text-xs">
                    USB or Bluetooth OBD2 adapter. Most common and affordable option.
                  </p>
                </div>
                <div>
                  <Badge className="mb-1">J2534</Badge>
                  <p className="text-muted-foreground text-xs">
                    Professional PassThru device. Faster scan times (30-60s vs 2-3min).
                  </p>
                </div>
                <div>
                  <Badge className="mb-1">Arduino CAN Shield</Badge>
                  <p className="text-muted-foreground text-xs">
                    DIY solution with MCP2515 CAN controller. Full control over CAN bus.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
