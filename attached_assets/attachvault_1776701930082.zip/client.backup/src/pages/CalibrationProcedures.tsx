import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { trpc } from '@/lib/trpc';
import { Gauge, Search, AlertCircle, Settings, Play, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';

export default function CalibrationProcedures() {
  const [searchQuery, setSearchQuery] = useState('');
  const [executingId, setExecutingId] = useState<number | null>(null);
  const { data: procedures, isLoading } = trpc.alphaOBD.getCalibrationProcedures.useQuery();
  const executeMutation = trpc.procedureExecution.executeCalibration.useMutation({
    onSuccess: (data) => {
      toast.success(`Calibration completed in ${data.executionTime}ms`);
      setExecutingId(null);
    },
    onError: (error) => {
      toast.error(`Calibration failed: ${error.message}`);
      setExecutingId(null);
    },
  });

  const handleExecute = (proc: any) => {
    setExecutingId(proc.id);
    toast.info('Starting calibration procedure...');
    executeMutation.mutate({
      procedureId: proc.id,
      procedureName: proc.description.substring(0, 256),
    });
  };

  const filteredProcedures = procedures?.filter((proc: any) =>
    proc.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
          <Gauge className="h-10 w-10 text-purple-600" />
          Calibration & Adaptation Procedures
        </h1>
        <p className="text-muted-foreground mt-2">
          Sensor calibrations, self-learning procedures, and system adaptations from SRT Lab database
        </p>
      </div>

      <Alert className="bg-purple-50 border-purple-200">
        <AlertCircle className="h-4 w-4 text-purple-600" />
        <AlertDescription className="text-purple-900">
          <strong>Found {procedures?.length || 0} calibration procedures</strong> including steering wheel position,
          headlamp sensors, acceleration sensors, clutch self-calibration, and throttle adaptation.
        </AlertDescription>
      </Alert>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search procedures (steering, headlamp, sensor, throttle, clutch...)"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Procedures List */}
      {isLoading ? (
        <div className="text-center py-12">
          <Settings className="h-12 w-12 animate-spin text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Loading procedures...</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredProcedures?.map((proc: any) => (
            <Card key={proc.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Settings className="h-5 w-5 text-purple-600" />
                      Procedure ID: {proc.id}
                    </CardTitle>
                    <CardDescription className="mt-2 whitespace-pre-wrap text-sm">
                      {proc.description}
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => handleExecute(proc)}
                    disabled={executingId === proc.id}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    {executingId === proc.id ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Calibrating...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Execute
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
            </Card>
          ))}

          {filteredProcedures?.length === 0 && (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                No procedures found matching "{searchQuery}"
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
