import { useState } from "react";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BackButton } from "@/components/BackButton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Download, Upload, CheckCircle2, XCircle, AlertTriangle,
  Loader2, Database, FileJson, Cpu, Car, Radio, Cog, Zap, Shield
} from "lucide-react";
import { toast } from "sonner";
import didDatabase from "@/../../shared/did_database.json";

interface DIDData {
  did: string;
  name: string;
  value: string;
  status: "pending" | "reading" | "writing" | "success" | "error";
  errorMessage?: string;
}

type ModuleType = "ecm" | "bcm" | "rfhub" | "tcm" | "abs";

const moduleConfig = {
  ecm: {
    name: "Engine Control Module",
    icon: Cog,
    color: "from-orange-600 to-red-600",
    risks: ["Odometer fraud detection", "Immobilizer mismatch", "Emissions tampering flags"],
  },
  bcm: {
    name: "Body Control Module",
    icon: Car,
    color: "from-blue-600 to-cyan-600",
    risks: ["Key FOB loss", "SKIM lockout", "Feature configuration mismatch"],
  },
  rfhub: {
    name: "RF Hub (TPMS)",
    icon: Radio,
    color: "from-green-600 to-emerald-600",
    risks: ["Sensor ID mismatch", "TPMS warning light"],
  },
  tcm: {
    name: "Transmission Control",
    icon: Zap,
    color: "from-purple-600 to-pink-600",
    risks: ["Shift adaptation loss", "Transmission mismatch", "Harsh shifting"],
  },
  abs: {
    name: "ABS Module",
    icon: Shield,
    color: "from-yellow-600 to-orange-600",
    risks: ["Brake system mismatch", "ABS warning light"],
  },
};

export default function ModuleCloneTool() {
  const [, params] = useRoute("/clone/:type");
  const moduleType = (params?.type || "ecm") as ModuleType;
  const config = moduleConfig[moduleType];
  const Icon = config.icon;

  const [sourceData, setSourceData] = useState<DIDData[]>([]);
  const [isReading, setIsReading] = useState(false);
  const [isWriting, setIsWriting] = useState(false);
  const [progress, setProgress] = useState(0);

  // Get critical DIDs for this module type
  const moduleInfo = didDatabase.module_specific[moduleType];
  const criticalDIDCodes = moduleInfo?.critical_dids || [];
  
  const criticalDIDs = criticalDIDCodes.map(didCode => {
    const didInfo = didDatabase.standard_dids[didCode as keyof typeof didDatabase.standard_dids];
    return {
      did: didCode,
      name: didInfo?.name || "Unknown",
      critical: true
    };
  });

  // Add module-specific DIDs
  if (moduleInfo?.additional_dids) {
    Object.entries(moduleInfo.additional_dids).forEach(([didCode, didInfo]) => {
      criticalDIDs.push({
        did: didCode,
        name: didInfo.name,
        critical: (didInfo as any).critical || false
      });
    });
  }

  const handleReadSource = async () => {
    setIsReading(true);
    setProgress(0);

    const dids: DIDData[] = criticalDIDs.map(d => ({
      did: d.did,
      name: d.name,
      value: "",
      status: "pending" as const
    }));
    setSourceData(dids);

    try {
      for (let i = 0; i < dids.length; i++) {
        dids[i].status = "reading";
        setSourceData([...dids]);

        // Simulate reading DID
        await new Promise(resolve => setTimeout(resolve, 800));

        // Mock data based on DID type
        if (dids[i].did === "F190") {
          dids[i].value = "2C3CDXKT3FH796320";
        } else if (dids[i].did === "F1E0") {
          // TPMS sensor IDs
          dids[i].value = "11 22 33 44 55 66 77 88 99 AA BB CC DD EE FF 00";
        } else if (dids[i].did === "F1D0") {
          // Key FOB data
          dids[i].value = "AA BB CC DD EE FF 11 22";
        } else if (dids[i].did === "F1C1") {
          // Odometer
          dids[i].value = "00 01 86 A0"; // 100,000 miles
        } else {
          dids[i].value = "AA BB CC DD";
        }

        dids[i].status = "success";
        setProgress(((i + 1) / dids.length) * 100);
        setSourceData([...dids]);
      }

      toast.success(`Successfully read all DIDs from source ${config.name}`);
    } catch (error) {
      toast.error(`Failed to read from source ${config.name}`);
    } finally {
      setIsReading(false);
    }
  };

  const handleWriteTarget = async () => {
    if (sourceData.length === 0) {
      toast.error("No source data available. Read from source first.");
      return;
    }

    setIsWriting(true);
    setProgress(0);

    const dids = [...sourceData].map(d => ({ ...d, status: "pending" as DIDData["status"] }));
    setSourceData(dids);

    try {
      for (let i = 0; i < dids.length; i++) {
        dids[i].status = "writing";
        setSourceData([...dids]);

        // Simulate writing DID
        await new Promise(resolve => setTimeout(resolve, 1000));

        dids[i].status = "success";
        setProgress(((i + 1) / dids.length) * 100);
        setSourceData([...dids]);
      }

      toast.success(`Successfully wrote all DIDs to target ${config.name}`);
    } catch (error) {
      toast.error(`Failed to write to target ${config.name}`);
    } finally {
      setIsWriting(false);
    }
  };

  const handleExportBackup = () => {
    if (sourceData.length === 0) {
      toast.error("No data to export");
      return;
    }

    const backup = {
      timestamp: new Date().toISOString(),
      module: config.name,
      moduleType: moduleType,
      dids: sourceData.map(d => ({
        did: d.did,
        name: d.name,
        value: d.value
      }))
    };

    const json = JSON.stringify(backup, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${moduleType}_backup_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success("Backup exported successfully");
  };

  const handleImportBackup = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const backup = JSON.parse(event.target?.result as string);
          if (backup.moduleType !== moduleType) {
            toast.error(`This backup is for ${backup.moduleType}, not ${moduleType}`);
            return;
          }
          setSourceData(backup.dids.map((d: any) => ({
            ...d,
            status: "success"
          })));
          toast.success("Backup imported successfully");
        } catch (error) {
          toast.error("Invalid backup file");
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />

        {/* Header */}
        <div className="flex items-center gap-4">
          <div className={`p-4 bg-gradient-to-br ${config.color} rounded-xl`}>
            <Icon className="h-10 w-10" />
          </div>
          <div>
            <h1 className="text-4xl font-black tracking-tight">{config.name.toUpperCase()}</h1>
            <p className="text-gray-400 text-lg">Module Cloning Tool</p>
          </div>
        </div>

        {/* Warning */}
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Known Risks</AlertTitle>
          <AlertDescription>
            <ul className="list-disc list-inside space-y-1">
              {config.risks.map((risk, idx) => (
                <li key={idx}>{risk}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Control Panel */}
          <Card>
            <CardHeader>
              <CardTitle>Operations</CardTitle>
              <CardDescription>Read from source, write to target</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={handleReadSource}
                disabled={isReading || isWriting}
                className="w-full gap-2"
              >
                {isReading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Reading...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4" />
                    Read Source Module
                  </>
                )}
              </Button>

              <Button
                onClick={handleWriteTarget}
                disabled={isWriting || isReading || sourceData.length === 0}
                variant="destructive"
                className="w-full gap-2"
              >
                {isWriting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Writing...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    Write Target Module
                  </>
                )}
              </Button>

              <div className="border-t border-gray-700 pt-3 space-y-3">
                <Button
                  onClick={handleExportBackup}
                  disabled={sourceData.length === 0}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <FileJson className="h-4 w-4" />
                  Export Backup
                </Button>

                <Button
                  onClick={handleImportBackup}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <Upload className="h-4 w-4" />
                  Import Backup
                </Button>
              </div>

              {(isReading || isWriting) && (
                <div className="space-y-2">
                  <Progress value={progress} />
                  <p className="text-xs text-center text-gray-400">
                    {Math.round(progress)}%
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* DID Status */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>DID Status</CardTitle>
              <CardDescription>
                {sourceData.length === 0
                  ? "No data loaded"
                  : `${sourceData.filter(d => d.status === "success").length}/${sourceData.length} DIDs complete`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                {sourceData.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-gray-500">
                    <Database className="h-12 w-12 mb-2 opacity-50" />
                    <p>Click "Read Source Module" to begin</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {sourceData.map((did, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded border ${
                          did.status === "success"
                            ? "bg-green-500/10 border-green-500/30"
                            : did.status === "error"
                            ? "bg-red-500/10 border-red-500/30"
                            : did.status === "reading" || did.status === "writing"
                            ? "bg-blue-500/10 border-blue-500/30"
                            : "bg-gray-500/10 border-gray-500/30"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="font-mono font-semibold">{did.did}</span>
                            <span className="text-sm text-gray-400">{did.name}</span>
                            {criticalDIDs.find(d => d.did === did.did)?.critical && (
                              <Badge variant="destructive" className="text-xs">CRITICAL</Badge>
                            )}
                          </div>
                          {did.status === "success" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                          {did.status === "error" && <XCircle className="h-4 w-4 text-red-500" />}
                          {(did.status === "reading" || did.status === "writing") && (
                            <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
                          )}
                        </div>
                        {did.value && (
                          <p className="font-mono text-sm mt-2 text-gray-300 break-all">{did.value}</p>
                        )}
                        {did.errorMessage && (
                          <p className="text-sm text-red-400 mt-2">{did.errorMessage}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
