import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { Play, Book, Wrench, Key, Zap } from "lucide-react";

interface Tutorial {
  id: string;
  title: string;
  description: string;
  duration: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  icon: any;
}

const tutorials: Tutorial[] = [
  {
    id: "vin-programming",
    title: "VIN Programming",
    description: "Learn how to program VIN to BCM, RFHUB, and ECM modules with automatic CRC calculation",
    duration: "8 min",
    difficulty: "intermediate",
    icon: Wrench,
  },
  {
    id: "key-programming",
    title: "FOBIK Key Programming",
    description: "Step-by-step guide to learning new keys and erasing old ones from RFHUB",
    duration: "12 min",
    difficulty: "intermediate",
    icon: Key,
  },
  {
    id: "dtc-clearing",
    title: "DTC Clearing Workflow",
    description: "Complete workflow: scan modules → read DTCs → clear codes → verify",
    duration: "6 min",
    difficulty: "beginner",
    icon: Zap,
  },
  {
    id: "flash-programming",
    title: "Flash Programming",
    description: "Advanced: Enter bootloader mode and flash firmware to ECU",
    duration: "15 min",
    difficulty: "advanced",
    icon: Wrench,
  },
  {
    id: "proxy-alignment",
    title: "Proxy Alignment",
    description: "Calibrate steering angle sensor after wheel alignment or replacement",
    duration: "10 min",
    difficulty: "intermediate",
    icon: Wrench,
  },
  {
    id: "hardware-setup",
    title: "Hardware Connection",
    description: "Connect ELM327 or J2534 adapter and configure communication settings",
    duration: "5 min",
    difficulty: "beginner",
    icon: Wrench,
  },
];

export default function VideoTutorials() {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-500";
      case "intermediate":
        return "bg-yellow-500";
      case "advanced":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">🎥 Video Tutorials</h1>
        <p className="text-muted-foreground">
          Learn how to use The SRT Lab platform with step-by-step video guides
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tutorials.map((tutorial) => {
          const Icon = tutorial.icon;
          return (
            <Card key={tutorial.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <Badge className={getDifficultyColor(tutorial.difficulty)}>
                    {tutorial.difficulty}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{tutorial.title}</CardTitle>
                <CardDescription>{tutorial.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{tutorial.duration}</span>
                  <Button size="sm">
                    <Play className="h-4 w-4 mr-2" />
                    Watch
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Book className="h-5 w-5" />
            Interactive Guided Mode
          </CardTitle>
          <CardDescription>
            Follow along with interactive tooltips and step-by-step instructions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button>
            Start Guided Tour
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
