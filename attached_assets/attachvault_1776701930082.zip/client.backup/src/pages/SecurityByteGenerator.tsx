import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, Shield } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';

export default function SecurityByteGenerator() {
  const [moduleType, setModuleType] = useState('RFHUB');
  const [vin, setVin] = useState('');
  const [existingBytes, setExistingBytes] = useState('');
  const [securityData, setSecurityData] = useState('');

  const generateMutation = trpc.ai.generateSecurityBytes.useMutation();

  const handleGenerate = async () => {
    if (!vin || vin.length !== 17) {
      alert('Please provide a valid 17-character VIN');
      return;
    }

    try {
      const response = await generateMutation.mutateAsync({
        moduleType,
        vin,
        existingBytes: existingBytes || undefined
      });
      setSecurityData(typeof response.securityData === 'string' ? response.securityData : JSON.stringify(response.securityData));
    } catch (error) {
      console.error('Security byte generation failed:', error);
      alert('Security byte generation failed. Please try again.');
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Shield className="w-10 h-10 text-primary" />
          Security Byte Generator
        </h1>
        <p className="text-muted-foreground">
          Generate security bytes for module pairing. AI-powered calculation based on VIN and module type.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Security bytes pair modules to vehicles (SKIM, RFHUB, BCM). 
          Derived from VIN using module-specific algorithms. Required for module replacement to prevent 
          C2202 VIN mismatch and immobilizer issues.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Module Information</CardTitle>
            <CardDescription>Provide VIN and module type</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="vin">Vehicle VIN *</Label>
              <Input
                id="vin"
                value={vin}
                onChange={(e) => setVin(e.target.value.toUpperCase())}
                placeholder="1C3CDFBB8ED123456"
                maxLength={17}
              />
              <p className="text-xs text-muted-foreground mt-1">
                17-character Vehicle Identification Number
              </p>
            </div>

            <div>
              <Label htmlFor="module-type">Module Type *</Label>
              <Select value={moduleType} onValueChange={setModuleType}>
                <SelectTrigger id="module-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="RFHUB">RFHUB (SmartBox)</SelectItem>
                  <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                  <SelectItem value="SKIM">SKIM (Security Module)</SelectItem>
                  <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                  <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="existing-bytes">Existing Security Bytes (Optional)</Label>
              <Input
                id="existing-bytes"
                value={existingBytes}
                onChange={(e) => setExistingBytes(e.target.value.toUpperCase())}
                placeholder="AA BB CC DD EE FF"
              />
              <p className="text-xs text-muted-foreground mt-1">
                From original module (for verification)
              </p>
            </div>

            <Button 
              onClick={handleGenerate} 
              disabled={generateMutation.isPending || vin.length !== 17}
              className="w-full"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4 mr-2" />
                  Generate Security Bytes
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Security Byte Data</CardTitle>
            <CardDescription>Generated pairing information</CardDescription>
          </CardHeader>
          <CardContent>
            {securityData ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{securityData}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Shield className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Enter VIN to generate security bytes</p>
                <p className="text-xs mt-2">
                  For module pairing and replacement
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Security Byte Locations */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Security Byte Storage Locations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <h3 className="font-semibold mb-2">RFHUB (SmartBox)</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Offset 0x0100 (2 bytes)</li>
                <li>• Offset 0x0108 (2 bytes)</li>
                <li>• Offset 0x0220 (2 bytes)</li>
                <li>• Offset 0x0230 (2 bytes)</li>
                <li>• Offset 0x0240 (2 bytes)</li>
                <li>• Offset 0x0510 (2 bytes)</li>
                <li>• Offset 0x0518 (2 bytes)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">BCM D-FLASH</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Region 0x00C000-0x00F000</li>
                <li>• Multiple copies for redundancy</li>
                <li>• CRC-16 protected</li>
                <li>• Paired with SKIM/RFHUB</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Calculation Methods</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• VIN last 8 digits (BCD)</li>
                <li>• Complement checksum</li>
                <li>• CRC-16 CCITT</li>
                <li>• Module-specific constants</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Use Cases */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>When Security Bytes Are Needed</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="font-semibold mb-2">Module Replacement</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• RFHUB replacement (key programming)</li>
                <li>• BCM replacement (body features)</li>
                <li>• SKIM replacement (immobilizer)</li>
                <li>• ECM/TCM replacement (powertrain)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Common Issues</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• C2202 - VIN mismatch</li>
                <li>• No-start condition (immobilizer)</li>
                <li>• Key programming failure</li>
                <li>• Module not communicating</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
