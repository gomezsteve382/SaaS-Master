import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Zap,
  Wrench,
  Clock,
  Shield,
  ArrowRight,
  Download,
  Upload,
} from 'lucide-react';

interface BCMType {
  manufacturer: 'Continental' | 'Marelli' | 'Bosch' | 'Unknown';
  partNumber: string;
  generation: string;
  bootloaderSupport: boolean;
}

interface BrickSeverity {
  level: 'mild' | 'moderate' | 'severe' | 'critical';
  canCommunicate: boolean;
  bootloaderAccessible: boolean;
  flashCorrupted: boolean;
  recoveryProbability: number;
  recommendedMethod: string;
}

interface RecoveryStep {
  number: number;
  title: string;
  description: string;
  duration: number;
  critical: boolean;
}

interface RecoveryPlan {
  steps: RecoveryStep[];
  estimatedTime: number;
  requiredTools: string[];
  riskLevel: 'low' | 'medium' | 'high';
  warnings: string[];
}

export default function BCMRecovery() {
  const [partNumber, setPartNumber] = useState('');
  const [bcmType, setBCMType] = useState<BCMType | null>(null);
  const [canResponse, setCanResponse] = useState(false);
  const [bootloaderResponse, setBootloaderResponse] = useState(false);
  const [powerDraw, setPowerDraw] = useState('');
  const [canBusVoltage, setCanBusVoltage] = useState('');
  const [brickSeverity, setBrickSeverity] = useState<BrickSeverity | null>(null);
  const [recoveryPlan, setRecoveryPlan] = useState<RecoveryPlan | null>(null);
  const [activeStep, setActiveStep] = useState(1);
  
  // Hardware integration state
  const [hardwareType, setHardwareType] = useState<'BDM100' | 'J2534' | 'KESS' | 'KTAG' | null>(null);
  const [hardwareConnected, setHardwareConnected] = useState(false);
  const [flashProgress, setFlashProgress] = useState({ current: 0, total: 0 });
  const [flashOperation, setFlashOperation] = useState<'idle' | 'reading' | 'writing' | 'verifying'>('idle');
  const [flashLog, setFlashLog] = useState<string[]>([]);

  const detectBCMType = () => {
    // Continental BCMs (most common in FCA vehicles)
    if (/^(68|56)\d{6}[A-Z]{2}$/.test(partNumber)) {
      setBCMType({
        manufacturer: 'Continental',
        partNumber,
        generation: partNumber.startsWith('68') ? '2011-2023' : '2008-2010',
        bootloaderSupport: true,
      });
      return;
    }

    // Marelli BCMs (Alfa Romeo, some Fiat)
    if (/^5[01]\d{6}[A-Z]{2}$/.test(partNumber)) {
      setBCMType({
        manufacturer: 'Marelli',
        partNumber,
        generation: '2015-2023',
        bootloaderSupport: true,
      });
      return;
    }

    // Bosch BCMs (older Chrysler)
    if (/^P\d{8}$/.test(partNumber)) {
      setBCMType({
        manufacturer: 'Bosch',
        partNumber,
        generation: '2004-2010',
        bootloaderSupport: false,
      });
      return;
    }

    setBCMType({
      manufacturer: 'Unknown',
      partNumber,
      generation: 'Unknown',
      bootloaderSupport: false,
    });
  };

  const diagnoseBrick = () => {
    const power = parseFloat(powerDraw);
    const voltage = parseFloat(canBusVoltage);

    // Critical: No power draw or CAN bus voltage
    if (power < 50 || voltage < 2.0) {
      setBrickSeverity({
        level: 'critical',
        canCommunicate: false,
        bootloaderAccessible: false,
        flashCorrupted: true,
        recoveryProbability: 10,
        recommendedMethod: 'Hardware repair required - check power supply and ground connections',
      });
      return;
    }

    // Severe: Power OK but no bootloader response
    if (!canResponse && !bootloaderResponse) {
      setBrickSeverity({
        level: 'severe',
        canCommunicate: false,
        bootloaderAccessible: false,
        flashCorrupted: true,
        recoveryProbability: 30,
        recommendedMethod: 'BDM/JTAG recovery required - bootloader may be corrupted',
      });
      return;
    }

    // Moderate: No CAN but bootloader responds
    if (!canResponse && bootloaderResponse) {
      setBrickSeverity({
        level: 'moderate',
        canCommunicate: false,
        bootloaderAccessible: true,
        flashCorrupted: true,
        recoveryProbability: 70,
        recommendedMethod: 'Boot mode flash recovery - firmware corrupted but bootloader intact',
      });
      return;
    }

    // Mild: CAN responds but errors
    if (canResponse) {
      setBrickSeverity({
        level: 'mild',
        canCommunicate: true,
        bootloaderAccessible: true,
        flashCorrupted: false,
        recoveryProbability: 95,
        recommendedMethod: 'Standard OBD2 reflash - module partially functional',
      });
      return;
    }

    setBrickSeverity({
      level: 'moderate',
      canCommunicate: false,
      bootloaderAccessible: false,
      flashCorrupted: true,
      recoveryProbability: 50,
      recommendedMethod: 'Try boot mode entry sequence first',
    });
  };

  const generateRecoveryPlan = () => {
    if (!brickSeverity || !bcmType) return;

    if (brickSeverity.level === 'mild') {
      setRecoveryPlan({
        steps: [
          {
            number: 1,
            title: 'Verify CAN Communication',
            description: 'Test basic CAN bus communication with BCM',
            duration: 5,
            critical: true,
          },
          {
            number: 2,
            title: 'Enter Programming Session',
            description: 'Send UDS command 0x10 02 to enter programming mode',
            duration: 2,
            critical: true,
          },
          {
            number: 3,
            title: 'Flash New Firmware',
            description: 'Upload firmware file via OBD2',
            duration: 15,
            critical: true,
          },
          {
            number: 4,
            title: 'Verify and Reset',
            description: 'Verify flash integrity and reset BCM',
            duration: 5,
            critical: true,
          },
        ],
        estimatedTime: 27,
        requiredTools: ['OBD2 adapter', 'Firmware file'],
        riskLevel: 'low',
        warnings: [],
      });
    } else if (brickSeverity.level === 'moderate') {
      setRecoveryPlan({
        steps: [
          {
            number: 1,
            title: 'Bench Setup',
            description: 'Remove BCM and set up bench power supply',
            duration: 10,
            critical: true,
          },
          {
            number: 2,
            title: 'Enter Boot Mode',
            description: 'Activate bootloader using pin manipulation or CAN command',
            duration: 5,
            critical: true,
          },
          {
            number: 3,
            title: 'Verify Bootloader',
            description: 'Confirm bootloader responds to UDS commands',
            duration: 3,
            critical: true,
          },
          {
            number: 4,
            title: 'Erase Flash',
            description: 'Erase corrupted firmware sectors',
            duration: 5,
            critical: true,
          },
          {
            number: 5,
            title: 'Flash Firmware',
            description: 'Write new firmware via bootloader',
            duration: 20,
            critical: true,
          },
          {
            number: 6,
            title: 'Verify and Test',
            description: 'Verify flash integrity and test BCM functionality',
            duration: 10,
            critical: true,
          },
        ],
        estimatedTime: 53,
        requiredTools: ['Bench power supply', 'CAN transceiver', 'Firmware file', 'Jumper wires'],
        riskLevel: 'medium',
        warnings: [
          'Ensure correct power supply voltage (12V)',
          'Do not disconnect power during flash operation',
          'Have backup firmware file ready',
        ],
      });
    } else {
      setRecoveryPlan({
        steps: [
          {
            number: 1,
            title: 'Hardware Diagnosis',
            description: 'Check power supply, ground connections, and CAN bus voltage',
            duration: 15,
            critical: true,
          },
          {
            number: 2,
            title: 'BDM/JTAG Setup',
            description: 'Open BCM case and connect BDM programmer',
            duration: 30,
            critical: true,
          },
          {
            number: 3,
            title: 'Read Flash Memory',
            description: 'Backup existing flash contents via BDM',
            duration: 10,
            critical: true,
          },
          {
            number: 4,
            title: 'Erase Flash',
            description: 'Full flash erase via BDM',
            duration: 5,
            critical: true,
          },
          {
            number: 5,
            title: 'Write Firmware',
            description: 'Program new firmware via BDM',
            duration: 30,
            critical: true,
          },
          {
            number: 6,
            title: 'Verify and Reassemble',
            description: 'Verify flash integrity, reassemble BCM, and test',
            duration: 20,
            critical: true,
          },
        ],
        estimatedTime: 110,
        requiredTools: [
          'BDM programmer',
          'Soldering equipment',
          'Firmware file',
          'Multimeter',
          'Oscilloscope (recommended)',
        ],
        riskLevel: 'high',
        warnings: [
          'Opening BCM case voids warranty',
          'Soldering required - risk of PCB damage',
          'BDM programming can brick BCM permanently if done incorrectly',
          'Consider professional repair service',
        ],
      });
    }
  };

  const getSeverityColor = (level: string) => {
    switch (level) {
      case 'mild':
        return 'bg-green-500';
      case 'moderate':
        return 'bg-yellow-500';
      case 'severe':
        return 'bg-orange-500';
      case 'critical':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'text-green-600';
      case 'medium':
        return 'text-yellow-600';
      case 'high':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  // Hardware integration handlers
  const detectHardware = async () => {
    addLog('Scanning for hardware adapters...');
    
    // Simulate hardware detection (in real implementation, this would use WebUSB/WebSerial)
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // For demo, randomly detect BDM100 or J2534
    const detected = Math.random() > 0.5 ? 'BDM100' : 'J2534';
    setHardwareType(detected);
    setHardwareConnected(true);
    addLog(`✓ ${detected} adapter detected and connected`);
  };

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setFlashLog(prev => [...prev, `[${timestamp}] ${message}`]);
  };

  const readFlash = async () => {
    if (!hardwareConnected) {
      addLog('❌ No hardware connected');
      return;
    }

    setFlashOperation('reading');
    addLog(`Starting flash read via ${hardwareType}...`);
    
    // Simulate flash read with progress
    const totalBlocks = 256;
    for (let i = 0; i <= totalBlocks; i += 8) {
      setFlashProgress({ current: i, total: totalBlocks });
      await new Promise(resolve => setTimeout(resolve, 50));
      if (i % 64 === 0) {
        addLog(`Reading block ${i}/${totalBlocks}...`);
      }
    }
    
    addLog('✓ Flash read complete (512KB)');
    setFlashOperation('idle');
    setFlashProgress({ current: 0, total: 0 });
  };

  const writeFlash = async () => {
    if (!hardwareConnected) {
      addLog('❌ No hardware connected');
      return;
    }

    setFlashOperation('writing');
    addLog(`Starting flash write via ${hardwareType}...`);
    addLog('⚠ Do NOT disconnect power during this operation!');
    
    // Simulate flash write with progress
    const totalBlocks = 256;
    for (let i = 0; i <= totalBlocks; i += 4) {
      setFlashProgress({ current: i, total: totalBlocks });
      await new Promise(resolve => setTimeout(resolve, 100));
      if (i % 64 === 0) {
        addLog(`Writing block ${i}/${totalBlocks}...`);
      }
    }
    
    addLog('✓ Flash write complete');
    setFlashOperation('verifying');
    addLog('Verifying flash integrity...');
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    addLog('✓ Verification complete - CRC match');
    
    setFlashOperation('idle');
    setFlashProgress({ current: 0, total: 0 });
  };

  const verifyBootloader = async () => {
    if (!hardwareConnected) {
      addLog('❌ No hardware connected');
      return;
    }

    addLog('Checking bootloader presence...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const bootloaderOK = Math.random() > 0.3; // 70% success rate
    if (bootloaderOK) {
      addLog('✓ Bootloader detected and responding');
      addLog('Bootloader version: 2.1.4');
      addLog('Flash size: 512KB');
      addLog('EEPROM size: 64KB');
    } else {
      addLog('❌ Bootloader not responding - BDM recovery required');
    }
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">BCM Recovery Suite</h1>
        <p className="text-muted-foreground">
          Diagnostic and recovery tools for bricked Body Control Modules
        </p>
      </div>

      <Tabs value={`step-${activeStep}`} onValueChange={(v) => setActiveStep(parseInt(v.split('-')[1]))}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="step-1">1. Identify BCM</TabsTrigger>
          <TabsTrigger value="step-2" disabled={!bcmType}>
            2. Diagnose
          </TabsTrigger>
          <TabsTrigger value="step-3" disabled={!brickSeverity}>
            3. Recovery Plan
          </TabsTrigger>
          <TabsTrigger value="step-4" disabled={!recoveryPlan}>
            4. Execute
          </TabsTrigger>
        </TabsList>

        {/* Step 1: Identify BCM */}
        <TabsContent value="step-1" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Step 1: Identify BCM Type</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="partNumber">BCM Part Number</Label>
                <Input
                  id="partNumber"
                  value={partNumber}
                  onChange={(e) => setPartNumber(e.target.value.toUpperCase())}
                  placeholder="e.g., 68303831AA, 56029764AB, P05150618AB"
                  className="font-mono"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Enter the part number printed on the BCM label
                </p>
              </div>

              <Button onClick={detectBCMType} disabled={!partNumber}>
                Detect BCM Type
              </Button>

              {bcmType && (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>
                    <div className="space-y-2">
                      <div>
                        <strong>Manufacturer:</strong> {bcmType.manufacturer}
                      </div>
                      <div>
                        <strong>Generation:</strong> {bcmType.generation}
                      </div>
                      <div>
                        <strong>Bootloader Support:</strong>{' '}
                        {bcmType.bootloaderSupport ? (
                          <Badge variant="default">Yes</Badge>
                        ) : (
                          <Badge variant="destructive">No (BDM Required)</Badge>
                        )}
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {bcmType && (
                <Button onClick={() => setActiveStep(2)} className="w-full">
                  Next: Diagnose Brick Severity
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </Card>
        </TabsContent>

        {/* Step 2: Diagnose */}
        <TabsContent value="step-2" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Step 2: Diagnose Brick Severity</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="canResponse"
                    checked={canResponse}
                    onChange={(e) => setCanResponse(e.target.checked)}
                    className="rounded"
                  />
                  <Label htmlFor="canResponse">CAN Bus Response</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="bootloaderResponse"
                    checked={bootloaderResponse}
                    onChange={(e) => setBootloaderResponse(e.target.checked)}
                    className="rounded"
                  />
                  <Label htmlFor="bootloaderResponse">Bootloader Response</Label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="powerDraw">Power Draw (mA)</Label>
                  <Input
                    id="powerDraw"
                    type="number"
                    value={powerDraw}
                    onChange={(e) => setPowerDraw(e.target.value)}
                    placeholder="e.g., 150"
                  />
                </div>

                <div>
                  <Label htmlFor="canBusVoltage">CAN Bus Voltage (V)</Label>
                  <Input
                    id="canBusVoltage"
                    type="number"
                    step="0.1"
                    value={canBusVoltage}
                    onChange={(e) => setCanBusVoltage(e.target.value)}
                    placeholder="e.g., 2.5"
                  />
                </div>
              </div>

              <Button onClick={diagnoseBrick} disabled={!powerDraw || !canBusVoltage}>
                Diagnose Brick Severity
              </Button>

              {brickSeverity && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">Severity Level:</span>
                        <Badge className={getSeverityColor(brickSeverity.level)}>
                          {brickSeverity.level.toUpperCase()}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="flex items-center gap-2">
                          {brickSeverity.canCommunicate ? (
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                          CAN Communication
                        </div>
                        <div className="flex items-center gap-2">
                          {brickSeverity.bootloaderAccessible ? (
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                          Bootloader Access
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold">Recovery Probability:</span>
                          <span className="text-lg">{brickSeverity.recoveryProbability}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              brickSeverity.recoveryProbability >= 70
                                ? 'bg-green-500'
                                : brickSeverity.recoveryProbability >= 40
                                  ? 'bg-yellow-500'
                                  : 'bg-red-500'
                            }`}
                            style={{ width: `${brickSeverity.recoveryProbability}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <span className="font-semibold">Recommended Method:</span>
                        <p className="text-sm mt-1">{brickSeverity.recommendedMethod}</p>
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {brickSeverity && (
                <Button onClick={() => {
                  generateRecoveryPlan();
                  setActiveStep(3);
                }} className="w-full">
                  Next: Generate Recovery Plan
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </Card>
        </TabsContent>

        {/* Step 3: Recovery Plan */}
        <TabsContent value="step-3" className="space-y-6">
          {recoveryPlan && (
            <>
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">Step 3: Recovery Plan</h2>

                <div className="space-y-6">
                  {/* Overview */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="text-sm text-muted-foreground">Estimated Time</div>
                        <div className="font-semibold">{recoveryPlan.estimatedTime} minutes</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Shield className={`h-5 w-5 ${getRiskColor(recoveryPlan.riskLevel)}`} />
                      <div>
                        <div className="text-sm text-muted-foreground">Risk Level</div>
                        <div className={`font-semibold ${getRiskColor(recoveryPlan.riskLevel)}`}>
                          {recoveryPlan.riskLevel.toUpperCase()}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Wrench className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="text-sm text-muted-foreground">Tools Required</div>
                        <div className="font-semibold">{recoveryPlan.requiredTools.length}</div>
                      </div>
                    </div>
                  </div>

                  {/* Required Tools */}
                  <div>
                    <h3 className="font-semibold mb-2">Required Tools:</h3>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {recoveryPlan.requiredTools.map((tool, i) => (
                        <li key={i}>{tool}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Warnings */}
                  {recoveryPlan.warnings.length > 0 && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        <div className="font-semibold mb-2">⚠️ Important Warnings:</div>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          {recoveryPlan.warnings.map((warning, i) => (
                            <li key={i}>{warning}</li>
                          ))}
                        </ul>
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Recovery Steps */}
                  <div>
                    <h3 className="font-semibold mb-3">Recovery Steps:</h3>
                    <div className="space-y-3">
                      {recoveryPlan.steps.map((step) => (
                        <Card key={step.number} className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0">
                              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                                {step.number}
                              </div>
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-semibold">{step.title}</h4>
                                {step.critical && (
                                  <Badge variant="destructive" className="text-xs">
                                    <Zap className="h-3 w-3 mr-1" />
                                    Critical
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">{step.description}</p>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {step.duration} minutes
                              </div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <Button onClick={() => setActiveStep(4)} className="w-full">
                    Next: Execute Recovery
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Step 4: Execute */}
        <TabsContent value="step-4" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Step 4: Execute Recovery</h2>
            
            {/* Hardware Connection */}
            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${
                    hardwareConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-300'
                  }`} />
                  <div>
                    <div className="font-semibold">
                      {hardwareConnected ? `${hardwareType} Connected` : 'No Hardware Detected'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {hardwareConnected
                        ? 'Ready for flash operations'
                        : 'Connect BDM100, J2534, KESS, or K-TAG adapter'}
                    </div>
                  </div>
                </div>
                <Button
                  onClick={detectHardware}
                  disabled={hardwareConnected}
                  variant={hardwareConnected ? 'outline' : 'default'}
                >
                  {hardwareConnected ? 'Connected' : 'Detect Hardware'}
                </Button>
              </div>

              {!hardwareConnected && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <p className="font-semibold mb-1">Hardware Required</p>
                    <p className="text-sm">
                      Connect a BDM100, J2534, KESS, or K-TAG adapter to your computer before proceeding.
                      Ensure the BCM is properly powered and connected to the adapter.
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </div>

            {/* Flash Operations */}
            {hardwareConnected && (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <Button
                    onClick={verifyBootloader}
                    disabled={flashOperation !== 'idle'}
                    variant="outline"
                  >
                    <Shield className="mr-2 h-4 w-4" />
                    Verify Bootloader
                  </Button>
                  <Button
                    onClick={readFlash}
                    disabled={flashOperation !== 'idle'}
                    variant="outline"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Read Flash
                  </Button>
                  <Button
                    onClick={writeFlash}
                    disabled={flashOperation !== 'idle'}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Write Flash
                  </Button>
                </div>

                {/* Progress Bar */}
                {flashOperation !== 'idle' && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium capitalize">{flashOperation}...</span>
                      <span>
                        {flashProgress.total > 0
                          ? `${Math.round((flashProgress.current / flashProgress.total) * 100)}%`
                          : '0%'}
                      </span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all"
                        style={{
                          width: flashProgress.total > 0
                            ? `${(flashProgress.current / flashProgress.total) * 100}%`
                            : '0%',
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* Operation Log */}
                <div className="border rounded-lg p-4 bg-black text-green-400 font-mono text-xs h-64 overflow-y-auto">
                  {flashLog.length === 0 ? (
                    <div className="text-gray-500">Waiting for operations...</div>
                  ) : (
                    flashLog.map((log, idx) => (
                      <div key={idx} className="mb-1">
                        {log}
                      </div>
                    ))
                  )}
                </div>

                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <p className="font-semibold mb-1">⚠️ Critical Safety Warnings</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      <li>Do NOT disconnect power during flash write operations</li>
                      <li>Ensure stable 12V power supply to BCM</li>
                      <li>Verify firmware file matches BCM part number</li>
                      <li>Always read and backup flash before writing</li>
                      <li>Incorrect firmware can permanently brick the BCM</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </div>
            )}

            <div className="flex gap-4 mt-6">
              <Button variant="outline" onClick={() => setActiveStep(1)}>
                Start Over
              </Button>
              <Button variant="outline" onClick={() => window.print()}>
                Print Recovery Plan
              </Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
