import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, FileSearch, Upload } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';

export default function EEPROMForensicsAI() {
  const [hexDump, setHexDump] = useState('');
  const [moduleType, setModuleType] = useState('BCM');
  const [knownVIN, setKnownVIN] = useState('');
  const [analysis, setAnalysis] = useState('');

  const analyzeMutation = trpc.ai.analyzeEEPROMDump.useMutation();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const arrayBuffer = event.target?.result as ArrayBuffer;
      const bytes = new Uint8Array(arrayBuffer);
      
      // Convert to hex dump format (16 bytes per line)
      let hexStr = '';
      for (let i = 0; i < Math.min(bytes.length, 4096); i += 16) {
        const offset = i.toString(16).padStart(4, '0').toUpperCase();
        const chunk = bytes.slice(i, i + 16);
        const hex = Array.from(chunk).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
        const ascii = Array.from(chunk).map(b => (b >= 32 && b <= 126) ? String.fromCharCode(b) : '.').join('');
        hexStr += `${offset}: ${hex.padEnd(48, ' ')} | ${ascii}\n`;
      }
      
      setHexDump(hexStr);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleAnalyze = async () => {
    if (!hexDump) {
      alert('Please upload an EEPROM dump file or paste hex data');
      return;
    }

    try {
      const response = await analyzeMutation.mutateAsync({
        hexDump,
        moduleType,
        knownVIN: knownVIN || undefined
      });
      setAnalysis(typeof response.analysis === 'string' ? response.analysis : JSON.stringify(response.analysis));
    } catch (error) {
      console.error('Analysis failed:', error);
      alert('Analysis failed. Please try again.');
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <FileSearch className="w-10 h-10 text-primary" />
          EEPROM Forensics AI
        </h1>
        <p className="text-muted-foreground">
          AI-powered EEPROM dump analysis. Identifies VIN locations, security bytes, calibration data, and hidden regions.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Upload a BCM/RFHUB/ECM EEPROM dump (.bin file) or paste hex data. 
          The AI will analyze memory structure, identify VIN locations, security byte regions, and potential hidden data. 
          Supports BCM D-FLASH (64KB), RFHUB SmartBox (8KB), and ECM calibration dumps.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>EEPROM Dump Input</CardTitle>
            <CardDescription>Upload .bin file or paste hex data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="file-upload">Upload EEPROM Dump (.bin)</Label>
              <div className="mt-2">
                <Input
                  id="file-upload"
                  type="file"
                  accept=".bin,.eep,.dump"
                  onChange={handleFileUpload}
                  className="cursor-pointer"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="module-type">Module Type</Label>
              <Select value={moduleType} onValueChange={setModuleType}>
                <SelectTrigger id="module-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                  <SelectItem value="RFHUB">RFHUB (SmartBox)</SelectItem>
                  <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                  <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                  <SelectItem value="SKIM">SKIM (Security Module)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="known-vin">Known VIN (Optional)</Label>
              <Input
                id="known-vin"
                value={knownVIN}
                onChange={(e) => setKnownVIN(e.target.value.toUpperCase())}
                placeholder="1C3CDFBB8ED123456"
                maxLength={17}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Helps AI locate VIN in dump
              </p>
            </div>

            <div>
              <Label htmlFor="hex-dump">Hex Dump Preview</Label>
              <Textarea
                id="hex-dump"
                value={hexDump}
                onChange={(e) => setHexDump(e.target.value)}
                placeholder="0000: FF FF FF FF 00 00 00 00 ... | ........"
                rows={10}
                className="font-mono text-xs"
              />
              <p className="text-xs text-muted-foreground mt-1">
                First 4KB shown (full dump analyzed)
              </p>
            </div>

            <Button 
              onClick={handleAnalyze} 
              disabled={analyzeMutation.isPending || !hexDump}
              className="w-full"
            >
              {analyzeMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <FileSearch className="w-4 h-4 mr-2" />
                  Analyze EEPROM Dump
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Forensics Analysis</CardTitle>
            <CardDescription>AI-powered memory structure analysis</CardDescription>
          </CardHeader>
          <CardContent>
            {analysis ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{analysis}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <FileSearch className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Upload an EEPROM dump to begin analysis</p>
                <p className="text-xs mt-2">
                  Supports BCM, RFHUB, ECM, TCM, SKIM modules
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Example Findings */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>What the AI Can Find</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <h3 className="font-semibold mb-2">🔍 VIN Locations</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Primary VIN (offset 0x0100)</li>
                <li>• Backup VIN copies (0x0200, 0x0300)</li>
                <li>• ASCII vs binary format</li>
                <li>• Prefix markers (0x31, 0x43)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🔐 Security Regions</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Security bytes (0x00C000-0x00F000)</li>
                <li>• SKIM pairing data</li>
                <li>• CRC checksums</li>
                <li>• Immobilizer keys</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">⚙️ Calibration Data</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Module configuration</li>
                <li>• Feature flags</li>
                <li>• Unused regions (0xFF/0x00)</li>
                <li>• Hidden backdoors</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
