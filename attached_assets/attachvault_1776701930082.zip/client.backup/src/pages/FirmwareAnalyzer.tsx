import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Upload, FileText, Download, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function FirmwareAnalyzer() {
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [parsedFlpart, setParsedFlpart] = useState<any>(null);
  const [parsedFms, setParsedFms] = useState<any>(null);
  const [udsCommands, setUdsCommands] = useState<any[]>([]);
  const [writeCommands, setWriteCommands] = useState<any[]>([]);
  
  const parseFlpartMutation = trpc.firmwareAnalysis.parseFlpart.useMutation({
    onSuccess: (data) => {
      setParsedFlpart(data);
      toast({
        title: "✅ .flpart Parsed Successfully",
        description: `Part Number: ${data.metadata.partNumber}`,
      });
    },
    onError: (error) => {
      toast({
        title: "❌ Parse Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const parseFmsMutation = trpc.firmwareAnalysis.parseFms.useMutation({
    onSuccess: (data) => {
      setParsedFms(data);
      setUdsCommands(data.commands);
      toast({
        title: "✅ .fms Parsed Successfully",
        description: `Found ${data.totalCommands} UDS commands`,
      });
    },
    onError: (error) => {
      toast({
        title: "❌ Parse Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const extractWriteMutation = trpc.firmwareAnalysis.extractWriteCommands.useMutation({
    onSuccess: (data) => {
      setWriteCommands(data.commands);
      toast({
        title: "✅ Write Commands Extracted",
        description: `Found ${data.writeCommands} Write Data By Identifier (0x2E) commands`,
      });
    },
  });
  
  const generateCSVMutation = trpc.firmwareAnalysis.generateCSV.useMutation({
    onSuccess: (data) => {
      // Download CSV
      const blob = new Blob([data.csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `uds_commands_${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "✅ CSV Downloaded",
        description: "UDS commands exported successfully",
      });
    },
  });
  
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };
  
  const handleParseFile = async (file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const content = e.target?.result as string;
      const base64 = content.split(',')[1]; // Remove data:... prefix
      
      if (file.name.endsWith('.flpart')) {
        parseFlpartMutation.mutate({
          fileName: file.name,
          content: base64,
        });
      } else if (file.name.endsWith('.fms')) {
        parseFmsMutation.mutate({
          fileName: file.name,
          content: base64,
        });
      }
    };
    reader.readAsDataURL(file);
  };
  
  const handleExtractWrites = () => {
    if (selectedFiles.length === 0) return;
    
    const fmsFile = selectedFiles.find(f => f.name.endsWith('.fms'));
    if (!fmsFile) {
      toast({
        title: "❌ No .fms File",
        description: "Please upload a .fms flash script file",
        variant: "destructive",
      });
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const base64 = content.split(',')[1];
      extractWriteMutation.mutate({ content: base64 });
    };
    reader.readAsDataURL(fmsFile);
  };
  
  const handleExportCSV = (commandType: 'all' | 'write') => {
    if (selectedFiles.length === 0) return;
    
    const fmsFile = selectedFiles.find(f => f.name.endsWith('.fms'));
    if (!fmsFile) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const base64 = content.split(',')[1];
      generateCSVMutation.mutate({ content: base64, commandType });
    };
    reader.readAsDataURL(fmsFile);
  };
  
  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Firmware File Analyzer</h1>
        <p className="text-muted-foreground">
          Parse Stellantis firmware files (.flpart XML, .fms flash scripts) and extract UDS programming commands
        </p>
      </div>
      
      {/* File Upload */}
      <Card>
        <CardHeader>
          <CardTitle>Upload Firmware Files</CardTitle>
          <CardDescription>
            Upload .flpart (metadata), .fms (flash scripts), or .efd (firmware binary) files
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="firmware-files">Select Files</Label>
            <Input
              id="firmware-files"
              type="file"
              multiple
              accept=".flpart,.fms,.efd"
              onChange={handleFileSelect}
            />
          </div>
          
          {selectedFiles.length > 0 && (
            <div className="space-y-2">
              <Label>Selected Files ({selectedFiles.length})</Label>
              <div className="space-y-1">
                {selectedFiles.map((file, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2 bg-muted rounded">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <span className="text-sm">{file.name}</span>
                      <Badge variant="outline">{(file.size / 1024).toFixed(1)} KB</Badge>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleParseFile(file)}
                      disabled={parseFlpartMutation.isPending || parseFmsMutation.isPending}
                    >
                      {parseFlpartMutation.isPending || parseFmsMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        'Parse'
                      )}
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="flex gap-2">
            <Button
              onClick={handleExtractWrites}
              disabled={selectedFiles.length === 0 || extractWriteMutation.isPending}
            >
              {extractWriteMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              Extract 0x2E Commands
            </Button>
            <Button
              variant="outline"
              onClick={() => handleExportCSV('all')}
              disabled={selectedFiles.length === 0 || generateCSVMutation.isPending}
            >
              <Download className="h-4 w-4 mr-2" />
              Export All CSV
            </Button>
            <Button
              variant="outline"
              onClick={() => handleExportCSV('write')}
              disabled={selectedFiles.length === 0 || generateCSVMutation.isPending}
            >
              <Download className="h-4 w-4 mr-2" />
              Export 0x2E CSV
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Results Tabs */}
      <Tabs defaultValue="flpart" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="flpart">
            .flpart Metadata
            {parsedFlpart && <CheckCircle2 className="ml-2 h-4 w-4 text-green-500" />}
          </TabsTrigger>
          <TabsTrigger value="fms">
            .fms UDS Commands
            {parsedFms && <CheckCircle2 className="ml-2 h-4 w-4 text-green-500" />}
          </TabsTrigger>
          <TabsTrigger value="write">
            0x2E Write Commands
            {writeCommands.length > 0 && <CheckCircle2 className="ml-2 h-4 w-4 text-green-500" />}
          </TabsTrigger>
        </TabsList>
        
        {/* .flpart Metadata Tab */}
        <TabsContent value="flpart">
          <Card>
            <CardHeader>
              <CardTitle>Firmware Metadata (.flpart)</CardTitle>
              <CardDescription>Parsed XML metadata from .flpart file</CardDescription>
            </CardHeader>
            <CardContent>
              {parsedFlpart ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Part Number</Label>
                      <p className="text-lg font-mono">{parsedFlpart.metadata.partNumber}</p>
                    </div>
                    <div>
                      <Label>Module Type</Label>
                      <Badge variant="secondary">{parsedFlpart.metadata.moduleType}</Badge>
                    </div>
                    <div>
                      <Label>File Name</Label>
                      <p className="text-sm font-mono">{parsedFlpart.metadata.fileName}</p>
                    </div>
                    <div>
                      <Label>File Size</Label>
                      <p className="text-sm">{(parsedFlpart.metadata.fileSize / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  
                  <div>
                    <Label>Calibration</Label>
                    <p className="text-sm">{parsedFlpart.metadata.calibration}</p>
                  </div>
                  
                  {parsedFlpart.metadata.applications.length > 0 && (
                    <div>
                      <Label>Vehicle Applications</Label>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Year</TableHead>
                            <TableHead>Body Code</TableHead>
                            <TableHead>Engine</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {parsedFlpart.metadata.applications.map((app: any, idx: number) => (
                            <TableRow key={idx}>
                              <TableCell>{app.year}</TableCell>
                              <TableCell><Badge variant="outline">{app.body}</Badge></TableCell>
                              <TableCell className="text-sm">{app.engine}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                  
                  {parsedFlpart.metadata.supersedes.length > 0 && (
                    <div>
                      <Label>Supersedes ({parsedFlpart.metadata.supersedes.length} parts)</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {parsedFlpart.metadata.supersedes.map((part: string, idx: number) => (
                          <Badge key={idx} variant="secondary">{part}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Upload and parse a .flpart file to see metadata</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* .fms UDS Commands Tab */}
        <TabsContent value="fms">
          <Card>
            <CardHeader>
              <CardTitle>UDS Commands (.fms)</CardTitle>
              <CardDescription>
                {parsedFms ? `${parsedFms.totalCommands} commands found` : 'Parsed UDS commands from flash script'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {parsedFms ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(parsedFms.stats.byService).map(([service, count]) => (
                      <Card key={service}>
                        <CardContent className="pt-6">
                          <div className="text-2xl font-bold">{count as number}</div>
                          <p className="text-xs text-muted-foreground">{service}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  
                  <div>
                    <Label>Command Preview (first 100)</Label>
                    <div className="border rounded-lg overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Offset</TableHead>
                            <TableHead>Service</TableHead>
                            <TableHead>Hex</TableHead>
                            <TableHead>Notes</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {udsCommands.slice(0, 50).map((cmd: any, idx: number) => (
                            <TableRow key={idx}>
                              <TableCell className="font-mono text-xs">0x{cmd.offset.toString(16).padStart(4, '0')}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{cmd.serviceName}</Badge>
                              </TableCell>
                              <TableCell className="font-mono text-xs">{cmd.hex.slice(0, 30)}...</TableCell>
                              <TableCell className="text-xs text-muted-foreground">{cmd.notes || '-'}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Upload and parse a .fms file to see UDS commands</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Write Commands Tab */}
        <TabsContent value="write">
          <Card>
            <CardHeader>
              <CardTitle>Write Data By Identifier (0x2E)</CardTitle>
              <CardDescription>
                {writeCommands.length > 0 ? `${writeCommands.length} write commands found` : 'Extracted 0x2E commands'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {writeCommands.length > 0 ? (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Offset</TableHead>
                        <TableHead>DID</TableHead>
                        <TableHead>DID Name</TableHead>
                        <TableHead>Payload</TableHead>
                        <TableHead>ASCII</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {writeCommands.slice(0, 100).map((cmd: any, idx: number) => (
                        <TableRow key={idx}>
                          <TableCell className="font-mono text-xs">0x{cmd.offset.toString(16).padStart(4, '0')}</TableCell>
                          <TableCell className="font-mono text-xs">{cmd.did || 'N/A'}</TableCell>
                          <TableCell className="text-xs">{cmd.didName || '-'}</TableCell>
                          <TableCell className="font-mono text-xs">{cmd.payloadHex?.slice(0, 20) || '-'}...</TableCell>
                          <TableCell className="font-mono text-xs">{cmd.payloadAscii?.slice(0, 15) || '-'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Click "Extract 0x2E Commands" to analyze write operations</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
