import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { BackButton } from "@/components/BackButton";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const MODULES = [
  { id: "BCM-0x28", name: "BCM (Body Control Module)", canId: "0x28" },
  { id: "ECM-0x10", name: "ECM (Engine Control Module)", canId: "0x10" },
  { id: "RFHUB-0x2C", name: "RFHUB (SmartBox)", canId: "0x2C" },
  { id: "TCM-0x11", name: "TCM (Transmission Control Module)", canId: "0x11" },
  { id: "ABS-0x20", name: "ABS (Anti-lock Braking System)", canId: "0x20" },
];

export default function QuickModuleClone() {
  const [sourceModuleId, setSourceModuleId] = useState("");
  const [targetModuleIds, setTargetModuleIds] = useState<string[]>([""]);
  const [includeVINs, setIncludeVINs] = useState(true);
  const [includeSecurityBytes, setIncludeSecurityBytes] = useState(true);
  const [includeFeatureBytes, setIncludeFeatureBytes] = useState(true);
  const [includeCalibrations, setIncludeCalibrations] = useState(true);
  const [profileName, setProfileName] = useState("");
  const [selectedProfile, setSelectedProfile] = useState("");
  const [isCloning, setIsCloning] = useState(false);
  const [cloneResult, setCloneResult] = useState<any>(null);

  const cloneMutation = trpc.moduleClone.cloneModule.useMutation();
  const batchCloneMutation = trpc.moduleClone.batchClone.useMutation();
  const saveProfileMutation = trpc.moduleClone.saveCloneProfile.useMutation();
  const { data: profiles } = trpc.moduleClone.listCloneProfiles.useQuery();

  const handleClone = async () => {
    if (!sourceModuleId) {
      toast.error("Please select a source module");
      return;
    }

    const validTargets = targetModuleIds.filter((id) => id);
    if (validTargets.length === 0) {
      toast.error("Please select at least one target module");
      return;
    }

    setIsCloning(true);
    setCloneResult(null);

    try {
      if (validTargets.length === 1) {
        // Single clone
        const result = await cloneMutation.mutateAsync({
          sourceModuleId,
          targetModuleId: validTargets[0],
          includeVINs,
          includeSecurityBytes,
          includeFeatureBytes,
          includeCalibrations,
        });

        setCloneResult(result);
        toast.success(`Module cloned successfully in ${result.duration}ms!`);
      } else {
        // Batch clone
        const result = await batchCloneMutation.mutateAsync({
          sourceModuleId,
          targetModuleIds: validTargets,
          includeVINs,
          includeSecurityBytes,
          includeFeatureBytes,
          includeCalibrations,
        });

        setCloneResult(result);
        toast.success(`Cloned to ${result.successCount}/${result.totalTargets} targets!`);
      }
    } catch (error) {
      toast.error("Clone failed: " + (error as Error).message);
    } finally {
      setIsCloning(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!profileName) {
      toast.error("Please enter a profile name");
      return;
    }

    if (!sourceModuleId) {
      toast.error("Please select a source module");
      return;
    }

    try {
      const result = await saveProfileMutation.mutateAsync({
        name: profileName,
        sourceModuleId,
        includeVINs,
        includeSecurityBytes,
        includeFeatureBytes,
        includeCalibrations,
      });

      toast.success(`Profile "${result.name}" saved!`);
      setProfileName("");
    } catch (error) {
      toast.error("Failed to save profile: " + (error as Error).message);
    }
  };

  const handleLoadProfile = (profileId: string) => {
    const profile = profiles?.find((p) => p.profileId === profileId);
    if (profile) {
      setSourceModuleId(profile.sourceModuleId);
      setSelectedProfile(profileId);
      toast.success(`Profile "${profile.name}" loaded!`);
    }
  };

  const addTargetModule = () => {
    setTargetModuleIds([...targetModuleIds, ""]);
  };

  const removeTargetModule = (index: number) => {
    setTargetModuleIds(targetModuleIds.filter((_, i) => i !== index));
  };

  const updateTargetModule = (index: number, value: string) => {
    const newTargets = [...targetModuleIds];
    newTargets[index] = value;
    setTargetModuleIds(newTargets);
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-black uppercase tracking-tight bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
          Quick Module Clone
        </h1>
        <p className="text-muted-foreground mt-2">
          One-click module configuration cloning for rapid fleet deployment
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Clone Configuration */}
        <Card>
          <CardHeader>
            <CardTitle>Clone Configuration</CardTitle>
            <CardDescription>Select source and target modules</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Source Module */}
            <div>
              <Label>Source Module</Label>
              <Select value={sourceModuleId} onValueChange={setSourceModuleId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select source module" />
                </SelectTrigger>
                <SelectContent>
                  {MODULES.map((module) => (
                    <SelectItem key={module.id} value={module.id}>
                      {module.name} ({module.canId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Target Modules */}
            <div>
              <Label>Target Module(s)</Label>
              {targetModuleIds.map((targetId, index) => (
                <div key={index} className="flex gap-2 mt-2">
                  <Select value={targetId} onValueChange={(value) => updateTargetModule(index, value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target module" />
                    </SelectTrigger>
                    <SelectContent>
                      {MODULES.filter((m) => m.id !== sourceModuleId).map((module) => (
                        <SelectItem key={module.id} value={module.id}>
                          {module.name} ({module.canId})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {targetModuleIds.length > 1 && (
                    <Button variant="outline" size="icon" onClick={() => removeTargetModule(index)}>
                      ✕
                    </Button>
                  )}
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={addTargetModule} className="mt-2">
                + Add Target Module
              </Button>
            </div>

            {/* Clone Options */}
            <div className="space-y-2">
              <Label>Clone Options</Label>
              <div className="flex items-center space-x-2">
                <Checkbox id="vins" checked={includeVINs} onCheckedChange={(checked) => setIncludeVINs(checked as boolean)} />
                <label htmlFor="vins" className="text-sm">
                  VINs (Original + Current)
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="security"
                  checked={includeSecurityBytes}
                  onCheckedChange={(checked) => setIncludeSecurityBytes(checked as boolean)}
                />
                <label htmlFor="security" className="text-sm">
                  Security Bytes
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="feature"
                  checked={includeFeatureBytes}
                  onCheckedChange={(checked) => setIncludeFeatureBytes(checked as boolean)}
                />
                <label htmlFor="feature" className="text-sm">
                  Feature Bytes
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="calibrations"
                  checked={includeCalibrations}
                  onCheckedChange={(checked) => setIncludeCalibrations(checked as boolean)}
                />
                <label htmlFor="calibrations" className="text-sm">
                  Calibrations (ECM/TCM only)
                </label>
              </div>
            </div>

            {/* Clone Button */}
            <Button onClick={handleClone} disabled={isCloning} className="w-full" size="lg">
              {isCloning ? "Cloning..." : "🚀 Clone Module"}
            </Button>
          </CardContent>
        </Card>

        {/* Clone Profiles */}
        <Card>
          <CardHeader>
            <CardTitle>Clone Profiles</CardTitle>
            <CardDescription>Save and load clone configurations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Save Profile */}
            <div>
              <Label>Save Current Configuration</Label>
              <div className="flex gap-2 mt-2">
                <Input
                  placeholder="Profile name"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                />
                <Button onClick={handleSaveProfile} disabled={!profileName || !sourceModuleId}>
                  Save
                </Button>
              </div>
            </div>

            {/* Load Profile */}
            <div>
              <Label>Load Saved Profile</Label>
              <Select value={selectedProfile} onValueChange={handleLoadProfile}>
                <SelectTrigger>
                  <SelectValue placeholder="Select profile" />
                </SelectTrigger>
                <SelectContent>
                  {profiles?.map((profile) => (
                    <SelectItem key={profile.profileId} value={profile.profileId}>
                      {profile.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Saved Profiles List */}
            {profiles && profiles.length > 0 && (
              <div>
                <Label>Saved Profiles</Label>
                <div className="space-y-2 mt-2">
                  {profiles.map((profile) => (
                    <Card key={profile.profileId}>
                      <CardContent className="p-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">{profile.name}</p>
                            <p className="text-xs text-muted-foreground">{profile.description}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Source: {MODULES.find((m) => m.id === profile.sourceModuleId)?.name}
                            </p>
                          </div>
                          <Button variant="outline" size="sm" onClick={() => handleLoadProfile(profile.profileId)}>
                            Load
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Clone Results */}
      {cloneResult && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Clone Results</CardTitle>
            <CardDescription>
              {cloneResult.totalTargets
                ? `Batch clone to ${cloneResult.totalTargets} targets`
                : `Single clone from ${cloneResult.sourceModuleId} to ${cloneResult.targetModuleId}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {cloneResult.totalTargets ? (
              // Batch results
              <div className="space-y-4">
                <div className="flex gap-4">
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    ✓ {cloneResult.successCount} Successful
                  </Badge>
                  {cloneResult.failureCount > 0 && (
                    <Badge variant="outline" className="text-red-600 border-red-600">
                      ✗ {cloneResult.failureCount} Failed
                    </Badge>
                  )}
                </div>
                <div className="space-y-2">
                  {cloneResult.results.map((result: any, index: number) => (
                    <Card key={index}>
                      <CardContent className="p-3">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{result.targetModuleId}</span>
                          <Badge variant={result.success ? "default" : "destructive"}>
                            {result.success ? "✓ Success" : "✗ Failed"}
                          </Badge>
                        </div>
                        {result.success && (
                          <p className="text-xs text-muted-foreground mt-1">Duration: {result.duration}ms</p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ) : (
              // Single clone results
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    ✓ Clone Successful
                  </Badge>
                  <Badge variant="outline">Duration: {cloneResult.duration}ms</Badge>
                </div>

                <div>
                  <Label>Items Transferred</Label>
                  <div className="space-y-1 mt-2">
                    {cloneResult.writeResults.map((item: any, index: number) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <Badge variant={item.success ? "default" : "destructive"} className="w-16">
                          {item.success ? "✓" : "✗"}
                        </Badge>
                        <span>{item.item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Verification</Label>
                  <div className="space-y-1 mt-2">
                    {Object.entries(cloneResult.verification).map(([key, value]) => (
                      <div key={key} className="flex items-center gap-2 text-sm">
                        <Badge variant={value ? "default" : "destructive"} className="w-16">
                          {value ? "✓" : "✗"}
                        </Badge>
                        <span>{key.replace(/([A-Z])/g, " $1").trim()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
