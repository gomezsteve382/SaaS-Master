import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { FileUp, Download, CheckCircle2, AlertCircle, Package } from "lucide-react";
import { toast } from "sonner";
import JSZip from "jszip";
import vinOffsetDatabase from "@/../../shared/vin_offset_database.json";
import { validateVIN, getVINInfo } from "@/lib/vin-validator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

interface ModuleFile {
  file: File;
  detectedType: string | null;
  status: "pending" | "patched" | "failed";
  message?: string;
}

export default function BatchVINPatcherFiles() {
  const [moduleFiles, setModuleFiles] = useState<ModuleFile[]>([]);
  const [newVIN, setNewVIN] = useState("");
  const [isPatching, setIsPatching] = useState(false);

  const handleFilesSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const newModuleFiles: ModuleFile[] = files.map(file => ({
      file,
      detectedType: null,
      status: "pending",
    }));

    setModuleFiles(newModuleFiles);
  };

  const detectModuleType = async (file: File): Promise<string | null> => {
    const buffer = await file.arrayBuffer();
    const data = new Uint8Array(buffer);

    // Try to detect module type by checking for VIN at known offsets
    const modules = vinOffsetDatabase.modules as any;

    for (const [moduleKey, moduleInfo] of Object.entries(modules)) {
      const info = moduleInfo as any;
      if (!info.vin_locations) continue;

      for (const vinLoc of info.vin_locations) {
        const offset = parseInt(vinLoc.offset, 16);
        if (offset + 17 > data.length) continue;

        const vinBytes = data.slice(offset, offset + 17);
        const vinStr = String.fromCharCode(...Array.from(vinBytes));

        // Check if it looks like a valid VIN
        if (/^[A-HJ-NPR-Z0-9]{17}$/.test(vinStr)) {
          return moduleKey;
        }
      }
    }

    // Legacy detection for BCM/RFHUB
    const bcmOffsets = [0x0052B8, 0x0052D8];
    for (const offset of bcmOffsets) {
      if (offset + 17 <= data.length) {
        const vinStr = String.fromCharCode(...Array.from(data.slice(offset, offset + 17)));
        if (/^[A-HJ-NPR-Z0-9]{17}$/.test(vinStr)) {
          return "bcm";
        }
      }
    }

    const rfhubOffsets = [0x000EA5, 0x000EB9];
    for (const offset of rfhubOffsets) {
      if (offset + 17 <= data.length) {
        const vinBytes = Array.from(data.slice(offset, offset + 17)).reverse();
        const vinStr = String.fromCharCode(...vinBytes);
        if (/^[A-HJ-NPR-Z0-9]{17}$/.test(vinStr)) {
          return "rfhub";
        }
      }
    }

    return null;
  };

  const patchModule = async (moduleFile: ModuleFile, vin: string): Promise<Uint8Array | null> => {
    const buffer = await moduleFile.file.arrayBuffer();
    const data = new Uint8Array(buffer);
    const patchedData = new Uint8Array(data);
    const vinBytes = new TextEncoder().encode(vin.toUpperCase());

    const moduleType = moduleFile.detectedType;
    if (!moduleType) return null;

    const modules = vinOffsetDatabase.modules as any;
    const moduleInfo = modules[moduleType];

    if (moduleInfo && moduleInfo.vin_locations) {
      // Use database offsets
      for (const vinLoc of moduleInfo.vin_locations) {
        const offset = parseInt(vinLoc.offset, 16);
        patchedData.set(vinBytes, offset);

        // Update checksum if specified
        if (moduleInfo.checksum && moduleInfo.checksum.algorithm === "CRC-16-CCITT") {
          const crc = calculateCRC16CCITT(vinBytes);
          const crcLocs = moduleInfo.checksum.locations;
          if (crcLocs && crcLocs.length > 0) {
            const crcOffset = parseInt(crcLocs[0].offset, 16);
            if (crcLocs[0].endian === "little") {
              patchedData[crcOffset] = crc & 0xFF;
              patchedData[crcOffset + 1] = (crc >> 8) & 0xFF;
            } else {
              patchedData[crcOffset] = (crc >> 8) & 0xFF;
              patchedData[crcOffset + 1] = crc & 0xFF;
            }
          }
        }
      }
      return patchedData;
    }

    // Legacy BCM/RFHUB patching
    if (moduleType === "bcm") {
      const bcmOffsets = [0x0052B8, 0x0052D8, 0x0052F8, 0x005318];
      for (const offset of bcmOffsets) {
        patchedData.set(vinBytes, offset);
        const crc = calculateCRC16CCITT(vinBytes);
        const crcOffset = offset + 17;
        patchedData[crcOffset] = crc & 0xFF;
        patchedData[crcOffset + 1] = (crc >> 8) & 0xFF;
      }
      return patchedData;
    }

    if (moduleType === "rfhub") {
      const rfhubOffsets = [0x000EA5, 0x000EB9, 0x000ECD, 0x000EE1];
      const reversedVin = Array.from(vinBytes).reverse();
      for (const offset of rfhubOffsets) {
        patchedData.set(reversedVin, offset);
      }
      return patchedData;
    }

    return null;
  };

  const calculateCRC16CCITT = (data: Uint8Array): number => {
    let crc = 0xFFFF;
    for (const byte of Array.from(data)) {
      crc ^= (byte << 8);
      for (let i = 0; i < 8; i++) {
        if (crc & 0x8000) {
          crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
        } else {
          crc = (crc << 1) & 0xFFFF;
        }
      }
    }
    return crc;
  };

  const handleBatchPatch = async () => {
    if (moduleFiles.length === 0) {
      toast.error("Please select module files");
      return;
    }

    // Validate VIN format and check digit
    const vinValidation = validateVIN(newVIN);
    if (!vinValidation.valid) {
      toast.error(`Invalid VIN: ${vinValidation.errors.join(', ')}`);
      return;
    }

    setIsPatching(true);

    try {
      // Detect all module types first
      const updatedFiles = [...moduleFiles];
      for (let i = 0; i < updatedFiles.length; i++) {
        const detectedType = await detectModuleType(updatedFiles[i].file);
        updatedFiles[i].detectedType = detectedType;
        if (!detectedType) {
          updatedFiles[i].status = "failed";
          updatedFiles[i].message = "Could not detect module type";
        }
      }
      setModuleFiles(updatedFiles);

      // Patch all modules
      const zip = new JSZip();
      let successCount = 0;

      for (let i = 0; i < updatedFiles.length; i++) {
        if (updatedFiles[i].detectedType) {
          const patchedData = await patchModule(updatedFiles[i], newVIN);
          if (patchedData) {
            const originalName = updatedFiles[i].file.name;
            const patchedName = `patched_${originalName}`;
            zip.file(patchedName, patchedData);
            updatedFiles[i].status = "patched";
            updatedFiles[i].message = `Patched as ${updatedFiles[i].detectedType}`;
            successCount++;
          } else {
            updatedFiles[i].status = "failed";
            updatedFiles[i].message = "Patching failed";
          }
        }
      }
      setModuleFiles(updatedFiles);

      if (successCount > 0) {
        // Generate ZIP file
        const zipBlob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `batch_patched_${newVIN}_${Date.now()}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        toast.success(`Successfully patched ${successCount} modules!`);
      } else {
        toast.error("No modules were successfully patched");
      }
    } catch (error) {
      toast.error("Batch patching failed: " + (error as Error).message);
    } finally {
      setIsPatching(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <Package className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">BATCH VIN PATCHER</h1>
            <p className="text-gray-600">
              Patch multiple modules (ECM + BCM + TCM) with a single VIN
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Upload Module Files</CardTitle>
            <CardDescription>
              Select multiple EEPROM dump files (.bin) - ECM, BCM, TCM, etc.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="files-upload">Module Files (multiple)</Label>
              <Input
                id="files-upload"
                type="file"
                accept=".bin"
                multiple
                onChange={handleFilesSelect}
                className="mt-2"
              />
              {moduleFiles.length > 0 && (
                <p className="text-sm text-gray-600 mt-2">
                  {moduleFiles.length} file(s) selected
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="new-vin">New VIN (17 characters)</Label>
              <Input
                id="new-vin"
                type="text"
                value={newVIN}
                onChange={(e) => setNewVIN(e.target.value.toUpperCase())}
                placeholder="2C3CDXKT3FH796320"
                maxLength={17}
                className="mt-2 font-mono"
              />
              <p className="text-xs text-gray-500 mt-1">
                No I, O, or Q allowed • {newVIN.length}/17 characters
              </p>
              
              {newVIN.length === 17 && (() => {
                const vinInfo = getVINInfo(newVIN);
                return (
                  <>
                    <div className="mt-2 p-2 bg-gray-100 rounded text-xs space-y-1">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Manufacturer:</span>
                        <span className="font-mono">{vinInfo.manufacturer}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Year:</span>
                        <span className="font-mono">{vinInfo.modelYear || 'Unknown'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Check Digit:</span>
                        <Badge variant={vinInfo.checkDigitValid ? 'default' : 'destructive'} className="text-[10px]">
                          {vinInfo.checkDigitValid ? 'VALID' : 'INVALID'}
                        </Badge>
                      </div>
                    </div>
                    
                    {!vinInfo.valid && vinInfo.errors.length > 0 && (
                      <Alert variant="destructive" className="mt-2">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle className="text-sm">Invalid VIN</AlertTitle>
                        <AlertDescription className="text-xs">
                          {vinInfo.errors.map((err, i) => (
                            <div key={i}>• {err}</div>
                          ))}
                        </AlertDescription>
                      </Alert>
                    )}
                  </>
                );
              })()}
            </div>

            <Button
              onClick={handleBatchPatch}
              disabled={isPatching || moduleFiles.length === 0 || newVIN.length !== 17 || (newVIN.length === 17 && !getVINInfo(newVIN).valid)}
              className="w-full gap-2"
              size="lg"
            >
              {isPatching ? (
                <>Processing...</>
              ) : (
                <>
                  <Download className="h-5 w-5" />
                  Patch All & Download ZIP
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {moduleFiles.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Module Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {moduleFiles.map((moduleFile, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div className="flex-1">
                      <p className="font-medium">{moduleFile.file.name}</p>
                      <p className="text-sm text-gray-600">
                        {(moduleFile.file.size / 1024).toFixed(2)} KB
                        {moduleFile.detectedType && ` • Detected: ${moduleFile.detectedType}`}
                      </p>
                      {moduleFile.message && (
                        <p className="text-xs text-gray-500 mt-1">{moduleFile.message}</p>
                      )}
                    </div>
                    <div>
                      {moduleFile.status === "pending" && (
                        <Badge variant="secondary">Pending</Badge>
                      )}
                      {moduleFile.status === "patched" && (
                        <Badge className="bg-green-600">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Patched
                        </Badge>
                      )}
                      {moduleFile.status === "failed" && (
                        <Badge variant="destructive">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Failed
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-900">⚠️ Important Notes</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-yellow-900 space-y-2">
            <p>• All modules will be patched with the SAME VIN</p>
            <p>• Module type is auto-detected from file content</p>
            <p>• Checksums are automatically recalculated where applicable</p>
            <p>• Patched files are downloaded as a single ZIP archive</p>
            <p>• Always backup original files before flashing to vehicle</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
