import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { PostFlashRoutines } from "@/components/PostFlashRoutines";
import { BatchFlashUpload } from "@/components/BatchFlashUpload";
import { FlashFileVersions } from "@/components/FlashFileVersions";
import { Search, CheckCircle2, XCircle, AlertTriangle, Download, Clock, FileText, Database, Upload, Trash2, Zap, History } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

export default function J2534FlashAvailability() {
  const [partNumber, setPartNumber] = useState('');
  const [uploadingId, setUploadingId] = useState<number | null>(null);
  const { toast } = useToast();

  const searchFlash = trpc.j2534.searchFlash.useQuery(
    { partNumber },
    { enabled: partNumber.length >= 8 }
  );

  const uploadFlashFile = trpc.j2534.uploadFlashFile.useMutation({
    onSuccess: () => {
      toast({
        title: "✅ Upload Successful",
        description: "Flash file uploaded to S3 and linked to calibration record",
      });
      searchFlash.refetch();
      setUploadingId(null);
    },
    onError: (error) => {
      toast({
        title: "❌ Upload Failed",
        description: error.message,
        variant: "destructive",
      });
      setUploadingId(null);
    },
  });

  const [downloadingId, setDownloadingId] = useState<number | null>(null);

  const handleFileUpload = async (calibrationId: number, file: File) => {
    setUploadingId(calibrationId);

    // Validate file type
    const validExtensions = ['.hex', '.bin', '.cal'];
    const fileExt = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (!validExtensions.includes(fileExt)) {
      toast({
        title: "❌ Invalid File Type",
        description: "Only .hex, .bin, and .cal files are supported",
        variant: "destructive",
      });
      setUploadingId(null);
      return;
    }

    // Read file as base64
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64Data = e.target?.result as string;
      const base64 = base64Data.split(',')[1]; // Remove data:... prefix

      await uploadFlashFile.mutateAsync({
        calibrationId,
        fileData: base64,
        fileName: file.name,
        fileType: fileExt.substring(1) as 'hex' | 'bin' | 'cal',
      });
    };
    reader.readAsDataURL(file);
  };

  const utils = trpc.useUtils();

  const handleDownload = async (calibrationId: number) => {
    setDownloadingId(calibrationId);
    try {
      const data = await utils.client.j2534.getFlashFileUrl.query({ calibrationId });
      if (data.found && data.url) {
        // Download file
        const link = document.createElement('a');
        link.href = data.url;
        link.download = data.fileName || 'flash.bin';
        link.click();
        toast({
          title: "📥 Downloading Flash File",
          description: `${data.fileName} (${(data.fileSize! / 1024).toFixed(1)} KB)`,
        });
      } else {
        toast({
          title: "❌ No File Found",
          description: "No flash file uploaded for this calibration",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "❌ Download Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDownloadingId(null);
    }
  };

  const handleSearch = () => {
    if (partNumber.length >= 8) {
      searchFlash.refetch();
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          J2534 Flash Availability Search
        </h1>
        <p className="text-muted-foreground mt-2">
          Search FCA flash database with supersedence validation (1,164 calibrations)
        </p>
      </div>

      {/* Batch Upload Section */}
      <div className="mb-6">
        <BatchFlashUpload />
      </div>

      {/* Search Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Flash Availability Database
          </CardTitle>
          <CardDescription>
            Enter current ECU part number to find available flash updates and validate supersedence
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="Enter part number (e.g., 68105234AA, 04606081AA)"
                value={partNumber}
                onChange={(e) => setPartNumber(e.target.value.toUpperCase().replace(/[^0-9A-Z]/g, ''))}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground mt-1">
                8-10 alphanumeric characters (e.g., 04606081AA, 68105234AB)
              </p>
            </div>
            <Button onClick={handleSearch} disabled={partNumber.length < 8 || searchFlash.isLoading}>
              <Search className="mr-2 h-4 w-4" />
              Search
            </Button>
          </div>

          {searchFlash.isLoading && (
            <div className="mt-4 text-center text-muted-foreground">
              <Database className="h-8 w-8 mx-auto mb-2 animate-pulse" />
              Searching 1,164 flash records...
            </div>
          )}

          {searchFlash.data && (
            <div className="mt-6 space-y-4">
              {searchFlash.data.found ? (
                <Alert className="border-green-500 bg-green-50">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-900">
                    <strong>✅ Flash Available!</strong> Found {searchFlash.data.matches.length} compatible flash{searchFlash.data.matches.length > 1 ? 'es' : ''}
                  </AlertDescription>
                </Alert>
              ) : (
                <Alert className="border-red-500 bg-red-50">
                  <XCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-900">
                    <strong>❌ No Flash Found</strong> - Part number "{partNumber}" not in supersedence database
                  </AlertDescription>
                </Alert>
              )}

              {searchFlash.data.matches?.map((match: any, idx: number) => (
                <Card key={idx} className="border-2 border-green-200">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{match.calibration}</CardTitle>
                        <CardDescription className="mt-1">
                          <Badge variant="outline" className="mr-2">{match.ecuType}</Badge>
                          Flash Update Available
                        </CardDescription>
                      </div>
                      <Badge className="bg-green-500">
                        {match.confidence}% Match
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Part Numbers */}
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-3">Part Number Information</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <span className="text-sm text-muted-foreground">Your Current Part:</span>
                          <div className="font-mono font-bold text-lg mt-1">{partNumber}</div>
                        </div>
                        <div>
                          <span className="text-sm text-muted-foreground">New Flash Part:</span>
                          <div className="font-mono font-bold text-lg mt-1 text-green-600">
                            {match.newPartNumber}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Supersedence List */}
                    <div>
                      <h4 className="font-semibold mb-2 flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        Supersedes {match.oldPartNumbers.length} Part Number{match.oldPartNumbers.length > 1 ? 's' : ''}
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {match.oldPartNumbers.map((pn: string, i: number) => (
                          <Badge 
                            key={i} 
                            variant={pn === partNumber ? "default" : "secondary"}
                            className="font-mono text-xs"
                          >
                            {pn}
                            {pn === partNumber && " ← YOUR PART"}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-sm text-muted-foreground mt-2">
                        ✅ Your part number IS in the supersedence list - safe to flash
                      </p>
                    </div>

                    {/* TSBs */}
                    {match.tsbs && match.tsbs.length > 0 && (
                      <div className="border-l-4 border-yellow-500 pl-4">
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <FileText className="h-4 w-4 text-yellow-600" />
                          Technical Service Bulletins ({match.tsbs.length})
                        </h4>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {match.tsbs.map((tsb: string, i: number) => (
                            <Badge key={i} variant="outline" className="font-mono bg-yellow-50">
                              {tsb}
                            </Badge>
                          ))}
                        </div>
                        <Alert className="bg-yellow-50 border-yellow-200">
                          <AlertTriangle className="h-4 w-4 text-yellow-600" />
                          <AlertDescription className="text-yellow-900 text-sm">
                            <strong>Post-Flash Routines Required:</strong> After flashing, you must perform procedures documented in the TSBs above (e.g., VIN programming, throttle relearn, transmission adaptation).
                          </AlertDescription>
                        </Alert>
                      </div>
                    )}

                    {/* Recalls */}
                    {match.recalls && match.recalls.length > 0 && (
                      <Alert className="border-red-500 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-900">
                          <strong>⚠️ SAFETY RECALL LINKED:</strong> {match.recalls.join(', ')}
                          <br />
                          <span className="text-sm">This flash addresses a safety recall. Ensure customer is notified.</span>
                        </AlertDescription>
                      </Alert>
                    )}

                    {/* Post-Flash Routines */}
                    {match.tsbs && match.tsbs.length > 0 && (
                      <div className="mt-4">
                        <PostFlashRoutines 
                          ecuType={match.ecuType}
                          tsbNumbers={match.tsbs}
                        />
                      </div>
                    )}

                    {/* Flash File Versions */}
                    <div className="mt-4">
                      <FlashFileVersions 
                        calibrationId={match.id}
                        calibrationName={match.calibration}
                      />
                    </div>

                    {/* File Management */}
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <Database className="h-4 w-4 text-blue-600" />
                        Flash File Storage
                      </h4>
                      <div className="flex gap-2">
                        <label className="flex-1">
                          <input
                            type="file"
                            accept=".hex,.bin,.cal"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleFileUpload(match.id, file);
                            }}
                            disabled={uploadingId === match.id}
                          />
                          <Button 
                            variant="outline" 
                            className="w-full"
                            disabled={uploadingId === match.id}
                            onClick={(e) => {
                              e.preventDefault();
                              (e.currentTarget.previousElementSibling as HTMLInputElement)?.click();
                            }}
                          >
                            <Upload className="mr-2 h-4 w-4" />
                            {uploadingId === match.id ? 'Uploading...' : 'Upload Flash File'}
                          </Button>
                        </label>
                        <Button 
                          variant="default" 
                          onClick={() => handleDownload(match.id)}
                          disabled={downloadingId === match.id}
                        >
                          <Download className="mr-2 h-4 w-4" />
                          {downloadingId === match.id ? 'Downloading...' : 'Download'}
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        Supported formats: .hex, .bin, .cal (max 50MB)
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Database Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Records</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">1,164</div>
            <p className="text-xs text-muted-foreground mt-1">Flash calibrations</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">ECU Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">5</div>
            <p className="text-xs text-muted-foreground mt-1">PCM, TCM, ECM, BPCM, IPC</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">TSB Coverage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">79.7%</div>
            <p className="text-xs text-muted-foreground mt-1">928 records with TSBs</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Recall Coverage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">19.2%</div>
            <p className="text-xs text-muted-foreground mt-1">224 safety recalls</p>
          </CardContent>
        </Card>
      </div>

      {/* Info Section */}
      <Card className="mt-6 bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="h-5 w-5 text-blue-600" />
            About This Database
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p><strong>Source:</strong> FCA J2534 Federal World Report (Official wiTECH Database)</p>
          <p><strong>Coverage:</strong> 1995-2025 (30 years of FCA/Stellantis vehicles)</p>
          <p><strong>Brands:</strong> Dodge, Chrysler, Jeep, RAM, Fiat, Alfa Romeo</p>
          <p><strong>Supersedence Validation:</strong> Prevents bricking ECUs by verifying part number compatibility</p>
          <p><strong>TSB Integration:</strong> Links to Technical Service Bulletins for post-flash procedures</p>
          <p><strong>Recall Awareness:</strong> Identifies safety-critical flash updates</p>
        </CardContent>
      </Card>
    </div>
  );
}
