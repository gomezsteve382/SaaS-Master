import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { BackButton } from "@/components/BackButton";
import { useToast } from "@/hooks/use-toast";
import { 
  Shield, ArrowLeft, Key, Lock, Unlock, Radio, AlertTriangle, 
  Loader2, CheckCircle2, XCircle, Usb, Smartphone, RefreshCw,
  FileKey, Zap, Car
} from "lucide-react";
import { ELM327Protocol } from "@shared/obd2-protocol";

type RFHUBOperation = "read_status" | "unlock" | "lock" | "red_key_renewal" | "program_fob";

interface RFHUBStatus {
  locked: boolean;
  vinProgrammed: boolean;
  currentVin: string;
  keyCount: number;
  redKeyStatus: "valid" | "expired" | "unknown";
}

export default function RFHUBTool() {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [protocol, setProtocol] = useState<ELM327Protocol | null>(null);
  const [rfhubStatus, setRfhubStatus] = useState<RFHUBStatus | null>(null);
  const [isOperating, setIsOperating] = useState(false);
  const [currentOperation, setCurrentOperation] = useState<string>("");
  const [operationLog, setOperationLog] = useState<string[]>([]);
  const { toast } = useToast();

  const RFHUB_TX = 0x742;
  const RFHUB_RX = 0x762;

  const addLog = (message: string) => {
    setOperationLog(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  };

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      const elm = new ELM327Protocol();
      const connected = await elm.connect();
      
      if (connected) {
        setProtocol(elm);
        setIsConnected(true);
        addLog("Connected to OBD2 adapter");
        toast({
          title: "Connected",
          description: "OBD2 adapter connected successfully",
        });
      } else {
        toast({
          title: "Connection Failed",
          description: "Could not connect to OBD2 adapter",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Connection Error",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    if (protocol) {
      await protocol.disconnect();
      setProtocol(null);
      setIsConnected(false);
      setRfhubStatus(null);
      addLog("Disconnected from OBD2 adapter");
    }
  };

  const readRFHUBStatus = async () => {
    if (!protocol) return;
    
    setIsOperating(true);
    setCurrentOperation("Reading RFHUB status...");
    addLog("Reading RFHUB module status...");
    
    try {
      addLog(`Sending TesterPresent to RFHUB (TX: 0x${RFHUB_TX.toString(16).toUpperCase()})`);
      
      const vinResponse = await protocol.sendUDS(RFHUB_TX, RFHUB_RX, [0x22, 0xF1, 0x90]);
      
      let currentVin = "Unknown";
      if (vinResponse && vinResponse.length >= 3 && vinResponse[0] === 0x62) {
        const vinBytes = Array.from(vinResponse.slice(3));
        currentVin = String.fromCharCode(...vinBytes.filter(b => b >= 0x20 && b <= 0x7E));
      }
      
      addLog(`VIN read: ${currentVin}`);
      
      setRfhubStatus({
        locked: false,
        vinProgrammed: currentVin !== "Unknown" && currentVin.length === 17,
        currentVin,
        keyCount: 0,
        redKeyStatus: "unknown",
      });
      
      addLog("RFHUB status read complete");
      toast({
        title: "Status Read",
        description: `VIN: ${currentVin}`,
      });
    } catch (error) {
      addLog(`Error reading status: ${error}`);
      toast({
        title: "Read Failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsOperating(false);
      setCurrentOperation("");
    }
  };

  const performRedKeyRenewal = async () => {
    if (!protocol) return;
    
    setIsOperating(true);
    setCurrentOperation("Performing Red Key Renewal...");
    addLog("=== RED KEY RENEWAL PROCEDURE ===");
    
    try {
      addLog("Step 1: Entering Extended Diagnostic Session...");
      const sessionResponse = await protocol.sendUDS(RFHUB_TX, RFHUB_RX, [0x10, 0x03]);
      if (!sessionResponse || sessionResponse[0] === 0x7F) {
        throw new Error("Failed to enter extended session");
      }
      addLog("Extended session active");
      
      addLog("Step 2: Requesting Security Access (Seed)...");
      const seedResponse = await protocol.sendUDS(RFHUB_TX, RFHUB_RX, [0x27, 0x01]);
      if (!seedResponse || seedResponse[0] === 0x7F) {
        throw new Error("Failed to get security seed");
      }
      
      const seed = Array.from(seedResponse.slice(2));
      addLog(`Seed received: ${seed.map(b => b.toString(16).padStart(2, '0')).join(' ')}`);
      
      addLog("Step 3: Calculating security key (professional diagnostic tool algorithm)...");
      
      addLog("Step 4: Sending security key...");
      
      addLog("WARNING: Red Key Renewal requires the actual professional diagnostic tool algorithm constants.");
      addLog("This is a placeholder - actual key calculation not implemented.");
      
      toast({
        title: "Red Key Renewal",
        description: "Procedure requires professional diagnostic tool algorithm - see console for details",
        variant: "destructive",
      });
      
    } catch (error) {
      addLog(`Error: ${error}`);
      toast({
        title: "Renewal Failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsOperating(false);
      setCurrentOperation("");
    }
  };

  const performUnlock = async () => {
    if (!protocol) return;
    
    setIsOperating(true);
    setCurrentOperation("Unlocking RFHUB...");
    addLog("=== RFHUB UNLOCK PROCEDURE ===");
    
    try {
      addLog("Step 1: Entering Programming Session (0x10 0x02)...");
      const sessionResponse = await protocol.sendUDS(RFHUB_TX, RFHUB_RX, [0x10, 0x02]);
      if (!sessionResponse || sessionResponse[0] === 0x7F) {
        throw new Error("Failed to enter programming session");
      }
      addLog("Programming session active");
      
      addLog("Step 2: Security Access required for unlock...");
      addLog("WARNING: RFHUB unlock requires security algorithm constants.");
      
      toast({
        title: "RFHUB Unlock",
        description: "Requires security algorithm - see console for details",
        variant: "destructive",
      });
      
    } catch (error) {
      addLog(`Error: ${error}`);
      toast({
        title: "Unlock Failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsOperating(false);
      setCurrentOperation("");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-md">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <BackButton />
      <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2" data-testid="button-back">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="w-8 h-8 bg-orange-600 rounded flex items-center justify-center">
              <Key className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="font-mono font-bold text-lg leading-none tracking-tight" data-testid="text-page-title">
                RFHUB / professional diagnostic tool TOOL
              </h1>
              <span className="text-[10px] text-orange-400 uppercase tracking-widest">Key Programming & Red Key Renewal</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant={isConnected ? "default" : "outline"} className={isConnected ? "bg-green-600" : ""}>
              {isConnected ? "Connected" : "Disconnected"}
            </Badge>
            <Link href="/radio-codes">
              <Button size="sm" className="bg-purple-600 hover:bg-purple-700" data-testid="button-radio-codes">
                <Radio className="w-3 h-3 mr-1.5" />
                Radio Codes
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="max-w-6xl mx-auto space-y-6">
          <Alert className="border-red-500/50 bg-red-500/10">
            <AlertTriangle className="h-4 w-4 text-red-400" />
            <AlertTitle className="text-red-400">RFHUB is OTP (One-Time Programmable)</AlertTitle>
            <AlertDescription className="text-white/70">
              Writing incorrect data to the RFHUB can permanently brick the module. 
              Always create a backup before any write operations. Replacement cost: $200-500 + dealer programming.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="border-white/10 bg-white/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm font-mono">
                  <Usb className="w-4 h-4 text-blue-400" />
                  Connection
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!isConnected ? (
                  <Button
                    onClick={handleConnect}
                    disabled={isConnecting}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    data-testid="button-connect"
                  >
                    {isConnecting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      <>
                        <Usb className="w-4 h-4 mr-2" />
                        Connect OBD2
                      </>
                    )}
                  </Button>
                ) : (
                  <Button
                    onClick={handleDisconnect}
                    variant="outline"
                    className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10"
                    data-testid="button-disconnect"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Disconnect
                  </Button>
                )}

                <div className="text-xs text-white/50 space-y-1">
                  <p>RFHUB CAN Address:</p>
                  <p className="font-mono">TX: 0x742 | RX: 0x762</p>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2 border-orange-500/30 bg-orange-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-mono">
                  <Smartphone className="w-5 h-5 text-orange-400" />
                  RFHUB Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                {rfhubStatus ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-white/5 rounded-lg">
                      <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center ${rfhubStatus.locked ? 'bg-red-500/20' : 'bg-green-500/20'}`}>
                        {rfhubStatus.locked ? <Lock className="w-4 h-4 text-red-400" /> : <Unlock className="w-4 h-4 text-green-400" />}
                      </div>
                      <p className="text-xs text-white/50 mt-2">Lock Status</p>
                      <p className="font-mono text-sm">{rfhubStatus.locked ? "LOCKED" : "UNLOCKED"}</p>
                    </div>
                    <div className="text-center p-3 bg-white/5 rounded-lg">
                      <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center ${rfhubStatus.vinProgrammed ? 'bg-green-500/20' : 'bg-yellow-500/20'}`}>
                        <Car className="w-4 h-4 text-white/70" />
                      </div>
                      <p className="text-xs text-white/50 mt-2">VIN Status</p>
                      <p className="font-mono text-sm">{rfhubStatus.vinProgrammed ? "PROGRAMMED" : "BLANK"}</p>
                    </div>
                    <div className="text-center p-3 bg-white/5 rounded-lg col-span-2">
                      <p className="text-xs text-white/50">Current VIN</p>
                      <p className="font-mono text-lg">{rfhubStatus.currentVin || "N/A"}</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-white/40">
                    <Smartphone className="w-12 h-12 mx-auto mb-2" />
                    <p>Connect and read RFHUB status to view details</p>
                  </div>
                )}

                {isConnected && (
                  <Button
                    onClick={readRFHUBStatus}
                    disabled={isOperating}
                    className="w-full mt-4 bg-orange-600 hover:bg-orange-700"
                    data-testid="button-read-status"
                  >
                    {isOperating ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {currentOperation}
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Read RFHUB Status
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="operations" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-white/5">
              <TabsTrigger value="operations">Operations</TabsTrigger>
              <TabsTrigger value="key-programming">Key Programming</TabsTrigger>
              <TabsTrigger value="log">Operation Log</TabsTrigger>
            </TabsList>

            <TabsContent value="operations" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-green-500/30 bg-green-500/5">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <Unlock className="w-4 h-4 text-green-400" />
                      RFHUB Unlock
                    </CardTitle>
                    <CardDescription>Unlock the RFHUB module for programming</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button
                      onClick={performUnlock}
                      disabled={!isConnected || isOperating}
                      className="w-full bg-green-600 hover:bg-green-700"
                      data-testid="button-unlock"
                    >
                      <Unlock className="w-4 h-4 mr-2" />
                      Unlock RFHUB
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-red-500/30 bg-red-500/5">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <Key className="w-4 h-4 text-red-400" />
                      Red Key Renewal
                    </CardTitle>
                    <CardDescription>Renew expired Red Key status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button
                      onClick={performRedKeyRenewal}
                      disabled={!isConnected || isOperating}
                      className="w-full bg-red-600 hover:bg-red-700"
                      data-testid="button-red-key"
                    >
                      <Key className="w-4 h-4 mr-2" />
                      Red Key Renewal
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="key-programming" className="space-y-4">
              <Card className="border-blue-500/30 bg-blue-500/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileKey className="w-5 h-5 text-blue-400" />
                    Key Fob Programming
                  </CardTitle>
                  <CardDescription>
                    Program new key fobs to the vehicle. Requires security access.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-yellow-500/50 bg-yellow-500/10">
                    <AlertTriangle className="h-4 w-4 text-yellow-400" />
                    <AlertDescription className="text-white/70">
                      Key programming requires the professional diagnostic tool security algorithm. 
                      This tool provides the UDS framework - you need to supply the crypto constants.
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button
                      disabled={!isConnected || isOperating}
                      variant="outline"
                      className="border-blue-500/50"
                      data-testid="button-add-key"
                    >
                      <Key className="w-4 h-4 mr-2" />
                      Add New Key
                    </Button>
                    <Button
                      disabled={!isConnected || isOperating}
                      variant="outline"
                      className="border-yellow-500/50"
                      data-testid="button-delete-keys"
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      Delete All Keys
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="log">
              <Card className="border-white/10 bg-black/50">
                <CardHeader>
                  <CardTitle className="text-sm font-mono flex items-center justify-between">
                    <span>Operation Log</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setOperationLog([])}
                      data-testid="button-clear-log"
                    >
                      Clear
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 overflow-y-auto font-mono text-xs bg-black/50 p-3 rounded">
                    {operationLog.length === 0 ? (
                      <span className="text-white/30">No operations logged yet...</span>
                    ) : (
                      operationLog.map((log, i) => (
                        <div key={i} className="text-green-400/80">{log}</div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
