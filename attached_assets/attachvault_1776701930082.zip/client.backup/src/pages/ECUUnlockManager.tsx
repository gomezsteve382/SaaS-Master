import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { 
  Unlock, 
  Lock, 
  CheckCircle2, 
  XCircle, 
  Clock,
  Zap,
  Shield,
  Info
} from 'lucide-react';

interface SecurityLevel {
  id: string;
  level: number;
  fileName: string;
  description: string;
  status: 'available' | 'unlocked' | 'locked' | 'unlocking';
}

interface ECUModule {
  id: string;
  name: string;
  ecuId: string;
  instanceId: string;
  securityLevels: SecurityLevel[];
  connected: boolean;
}

export default function ECUUnlockManager() {
  const [modules, setModules] = useState<ECUModule[]>([
    {
      id: 'bcm',
      name: 'BCM (Body Control Module)',
      ecuId: '0x7E0',
      instanceId: '1',
      connected: true,
      securityLevels: [
        {
          id: 'bcm-level-1',
          level: 1,
          fileName: 'unlock_level_1.xml',
          description: 'Basic Diagnostic Access',
          status: 'available'
        },
        {
          id: 'bcm-level-3',
          level: 3,
          fileName: 'unlock_level_3.xml',
          description: 'Advanced Diagnostic Access',
          status: 'available'
        },
        {
          id: 'bcm-level-5',
          level: 5,
          fileName: 'unlock_level_5.xml',
          description: 'Programming Access (Atlantis)',
          status: 'available'
        }
      ]
    },
    {
      id: 'ecm',
      name: 'ECM (Engine Control Module)',
      ecuId: '0x7E1',
      instanceId: '1',
      connected: true,
      securityLevels: [
        {
          id: 'ecm-level-1',
          level: 1,
          fileName: 'unlock_level_1.xml',
          description: 'Basic Diagnostic Access',
          status: 'available'
        },
        {
          id: 'ecm-level-5',
          level: 5,
          fileName: 'unlock_level_5.xml',
          description: 'Programming Access (Atlantis)',
          status: 'available'
        }
      ]
    },
    {
      id: 'tcm',
      name: 'TCM (Transmission Control Module)',
      ecuId: '0x7E2',
      instanceId: '1',
      connected: true,
      securityLevels: [
        {
          id: 'tcm-level-1',
          level: 1,
          fileName: 'unlock_level_1.xml',
          description: 'Basic Diagnostic Access',
          status: 'available'
        },
        {
          id: 'tcm-level-5',
          level: 5,
          fileName: 'unlock_level_5.xml',
          description: 'Programming Access (Atlantis)',
          status: 'available'
        }
      ]
    },
    {
      id: 'rfhub',
      name: 'RFHUB (SmartBox)',
      ecuId: '0x7E3',
      instanceId: '1',
      connected: true,
      securityLevels: [
        {
          id: 'rfhub-level-1',
          level: 1,
          fileName: 'unlock_level_1.xml',
          description: 'Basic Diagnostic Access',
          status: 'available'
        },
        {
          id: 'rfhub-level-3',
          level: 3,
          fileName: 'unlock_level_3.xml',
          description: 'PIN Extraction Access',
          status: 'available'
        }
      ]
    },
    {
      id: 'sgw',
      name: 'SecurityGateway',
      ecuId: '0x7E4',
      instanceId: '1',
      connected: true,
      securityLevels: [
        {
          id: 'sgw-level-5',
          level: 5,
          fileName: 'unlock_level_5.xml',
          description: 'Gateway Bypass (Atlantis)',
          status: 'available'
        }
      ]
    }
  ]);

  const unlockSecurityLevel = async (moduleId: string, levelId: string) => {
    // Update status to unlocking
    setModules(prev => prev.map(module => {
      if (module.id === moduleId) {
        return {
          ...module,
          securityLevels: module.securityLevels.map(level => 
            level.id === levelId ? { ...level, status: 'unlocking' as const } : level
          )
        };
      }
      return module;
    }));

    // Simulate unlock delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Simulate 90% success rate
    const success = Math.random() > 0.1;

    // Update status to unlocked or locked
    setModules(prev => prev.map(module => {
      if (module.id === moduleId) {
        return {
          ...module,
          securityLevels: module.securityLevels.map(level => 
            level.id === levelId 
              ? { ...level, status: success ? 'unlocked' as const : 'locked' as const } 
              : level
          )
        };
      }
      return module;
    }));
  };

  const unlockAllModules = async () => {
    for (const module of modules) {
      if (module.connected) {
        for (const level of module.securityLevels) {
          if (level.status === 'available') {
            await unlockSecurityLevel(module.id, level.id);
            // Small delay between modules
            await new Promise(resolve => setTimeout(resolve, 500));
          }
        }
      }
    }
  };

  const getStatusIcon = (status: SecurityLevel['status']) => {
    switch (status) {
      case 'available':
        return <Lock className="h-5 w-5 text-gray-400" />;
      case 'unlocking':
        return <Clock className="h-5 w-5 text-yellow-500 animate-spin" />;
      case 'unlocked':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'locked':
        return <XCircle className="h-5 w-5 text-red-500" />;
    }
  };

  const getStatusBadge = (status: SecurityLevel['status']) => {
    const variants: Record<SecurityLevel['status'], 'default' | 'secondary' | 'destructive' | 'outline'> = {
      available: 'secondary',
      unlocking: 'outline',
      unlocked: 'default',
      locked: 'destructive'
    };

    const labels: Record<SecurityLevel['status'], string> = {
      available: 'Available',
      unlocking: 'Unlocking...',
      unlocked: '✅ Unlocked',
      locked: '❌ Failed'
    };

    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    );
  };

  const totalLevels = modules.reduce((sum, module) => sum + module.securityLevels.length, 0);
  const unlockedLevels = modules.reduce((sum, module) => 
    sum + module.securityLevels.filter(l => l.status === 'unlocked').length, 0
  );

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 bg-clip-text text-transparent">
            ECU Unlock Manager
          </h1>
          <p className="text-muted-foreground mt-2">
            One-click security access unlock for all vehicle modules (professional diagnostic tool Clone)
          </p>
        </div>
        <Button onClick={unlockAllModules} size="lg">
          <Zap className="mr-2 h-5 w-5" />
          Unlock All Modules
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Modules</p>
              <p className="text-3xl font-bold">{modules.length}</p>
            </div>
            <Shield className="h-8 w-8 text-muted-foreground" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Security Levels</p>
              <p className="text-3xl font-bold">{totalLevels}</p>
            </div>
            <Lock className="h-8 w-8 text-muted-foreground" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Unlocked</p>
              <p className="text-3xl font-bold text-green-500">{unlockedLevels}</p>
            </div>
            <Unlock className="h-8 w-8 text-green-500" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-3xl font-bold">
                {totalLevels > 0 ? ((unlockedLevels / totalLevels) * 100).toFixed(0) : 0}%
              </p>
            </div>
            <CheckCircle2 className="h-8 w-8 text-green-500" />
          </div>
        </Card>
      </div>

      {/* Info Alert */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>professional diagnostic tool Clone Feature:</strong> This ECU Unlock Manager replicates the functionality of Chrysler's professional diagnostic tool diagnostic application. 
          It uses the same message protocol (FindECUUnlockInformationMessage, DoEcuUnlockMessage) and supports all security levels including Atlantis Level 5 for 2018+ vehicles.
        </AlertDescription>
      </Alert>

      {/* Module List */}
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Vehicle Modules</h2>
        {modules.map(module => (
          <Card key={module.id} className="p-6">
            <div className="space-y-4">
              {/* Module Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl font-semibold">{module.name}</h3>
                  <p className="text-sm text-muted-foreground font-mono">
                    ECU ID: {module.ecuId} | Instance: {module.instanceId}
                  </p>
                </div>
                <Badge variant={module.connected ? 'default' : 'secondary'}>
                  {module.connected ? '🟢 Connected' : '🔴 Disconnected'}
                </Badge>
              </div>

              <Separator />

              {/* Security Levels */}
              <div className="space-y-2">
                <h4 className="font-semibold">Security Levels</h4>
                {module.securityLevels.map(level => (
                  <div
                    key={level.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {getStatusIcon(level.status)}
                      <div>
                        <p className="font-semibold">Level {level.level}</p>
                        <p className="text-sm text-muted-foreground">{level.description}</p>
                        <p className="text-xs text-muted-foreground font-mono mt-1">
                          File: {level.fileName}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {getStatusBadge(level.status)}
                      {level.status === 'available' && (
                        <Button
                          size="sm"
                          onClick={() => unlockSecurityLevel(module.id, level.id)}
                        >
                          <Unlock className="mr-2 h-4 w-4" />
                          Unlock
                        </Button>
                      )}
                      {level.status === 'unlocking' && (
                        <Button size="sm" disabled>
                          <Clock className="mr-2 h-4 w-4 animate-spin" />
                          Unlocking...
                        </Button>
                      )}
                      {level.status === 'unlocked' && (
                        <Button size="sm" variant="outline" disabled>
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          Unlocked
                        </Button>
                      )}
                      {level.status === 'locked' && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => unlockSecurityLevel(module.id, level.id)}
                        >
                          <XCircle className="mr-2 h-4 w-4" />
                          Retry
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Technical Details */}
      <Card className="p-6 bg-muted/50">
        <h3 className="text-lg font-semibold mb-4">Technical Details</h3>
        <div className="space-y-2 text-sm">
          <p><strong>Message Protocol:</strong> professional diagnostic tool-compatible JSON messages over HTTP/HTTPS</p>
          <p><strong>FindECUUnlockInformationMessage:</strong> Queries available security levels for each module</p>
          <p><strong>DoEcuUnlockMessage:</strong> Performs the actual unlock operation using UDS 0x27 SecurityAccess</p>
          <p><strong>Atlantis Support:</strong> Level 5 security access uses Atlantis algorithm with SECRET_KEY: BC474048A33B483A</p>
          <p><strong>Response Format:</strong> JSON with result (success/failure) and unlocks array containing level details</p>
        </div>
      </Card>
    </div>
  );
}
