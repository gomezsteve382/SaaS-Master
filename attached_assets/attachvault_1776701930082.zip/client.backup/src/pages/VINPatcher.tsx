import { useState } from "react";
import { Upload, Download, Calculator, CheckCircle2, XCircle, Info, FileUp, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { BackButton } from "@/components/BackButton";
import { VINDecoderPanel } from "@/components/VINDecoderPanel";
import JSZip from "jszip";

interface VINLocation {
  offset: number;
  label: string;
  currentVIN: string;
}

interface ChecksumInfo {
  type: "CRC-16" | "Complement";
  algorithm: string;
  currentValue: string;
  newValue: string;
  location: number;
  valid: boolean;
  calculationSteps: string[];
}

interface VINValidation {
  valid: boolean;
  errors: string[];
  warnings: string[];
  checkDigit: {
    expected: string;
    actual: string;
    valid: boolean;
  };
  wmi: {
    code: string;
    manufacturer: string;
    country: string;
  } | null;
  modelYear: string;
}

interface BatchFile {
  file: File;
  data: Uint8Array;
  moduleType: "BCM" | "RFHUB" | null;
  vinLocations: VINLocation[];
  status: "pending" | "processing" | "success" | "error";
  error?: string;
  patchedData?: Uint8Array;
}

export default function VINPatcher() {
  const [file, setFile] = useState<File | null>(null);
  const [fileData, setFileData] = useState<Uint8Array | null>(null);
  const [moduleType, setModuleType] = useState<"BCM" | "RFHUB" | null>(null);
  const [vinLocations, setVinLocations] = useState<VINLocation[]>([]);
  const [newVIN, setNewVIN] = useState("");
  const [checksumInfo, setChecksumInfo] = useState<ChecksumInfo | null>(null);
  const [patchedData, setPatchedData] = useState<Uint8Array | null>(null);
  const [vinValidation, setVinValidation] = useState<VINValidation | null>(null);
  
  // Batch mode state
  const [batchMode, setBatchMode] = useState(false);
  const [batchFiles, setBatchFiles] = useState<BatchFile[]>([]);
  const [batchVIN, setBatchVIN] = useState("");

  // WMI database for validation
  const WMI_DATABASE: Record<string, { manufacturer: string; country: string }> = {
    "1C3": { manufacturer: "Chrysler", country: "United States" },
    "1C4": { manufacturer: "Chrysler", country: "United States" },
    "1C6": { manufacturer: "Chrysler", country: "United States" },
    "1C8": { manufacturer: "Chrysler", country: "United States" },
    "1D3": { manufacturer: "Dodge", country: "United States" },
    "1D4": { manufacturer: "Dodge", country: "United States" },
    "1D7": { manufacturer: "Dodge", country: "United States" },
    "1D8": { manufacturer: "Dodge", country: "United States" },
    "1J4": { manufacturer: "Jeep", country: "United States" },
    "1J8": { manufacturer: "Jeep", country: "United States" },
    "2C3": { manufacturer: "Chrysler", country: "Canada" },
    "2C4": { manufacturer: "Chrysler", country: "Canada" },
    "2C8": { manufacturer: "Chrysler", country: "Canada" },
    "2D3": { manufacturer: "Dodge", country: "Canada" },
    "2D4": { manufacturer: "Dodge", country: "Canada" },
    "2D8": { manufacturer: "Dodge", country: "Canada" },
    "3C3": { manufacturer: "Chrysler", country: "Mexico" },
    "3C4": { manufacturer: "Chrysler", country: "Mexico" },
    "3C6": { manufacturer: "Dodge", country: "Mexico" },
    "3C8": { manufacturer: "Dodge", country: "Mexico" },
    "3D3": { manufacturer: "Dodge", country: "Mexico" },
    "3D4": { manufacturer: "Dodge", country: "Mexico" },
    "ZFA": { manufacturer: "Fiat", country: "Italy" },
    "ZAR": { manufacturer: "Alfa Romeo", country: "Italy" },
    "ZCF": { manufacturer: "Lancia", country: "Italy" },
  };

  const MODEL_YEAR_MAP: Record<string, string> = {
    "A": "2010", "B": "2011", "C": "2012", "D": "2013", "E": "2014",
    "F": "2015", "G": "2016", "H": "2017", "J": "2018", "K": "2019",
    "L": "2020", "M": "2021", "N": "2022", "P": "2023", "R": "2024",
    "S": "2025", "T": "2026", "V": "2027", "W": "2028", "X": "2029",
    "Y": "2030", "1": "2031", "2": "2032", "3": "2033", "4": "2034",
    "5": "2035", "6": "2036", "7": "2037", "8": "2038", "9": "2039",
  };

  const validateVIN = (vin: string): VINValidation => {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Check length
    if (vin.length !== 17) {
      errors.push(`VIN must be exactly 17 characters (current: ${vin.length})`);
    }

    // Check for invalid characters (I, O, Q not allowed)
    const invalidChars = vin.match(/[IOQ]/g);
    if (invalidChars) {
      errors.push(`Invalid characters: ${invalidChars.join(", ")} (I, O, Q not allowed in VINs)`);
    }

    // Check for valid VIN characters only
    if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(vin)) {
      errors.push("VIN contains invalid characters (only A-H, J-N, P-Z, 0-9 allowed)");
    }

    // WMI validation
    const wmiCode = vin.substring(0, 3);
    const wmiInfo = WMI_DATABASE[wmiCode];
    
    if (!wmiInfo) {
      warnings.push(`Unknown WMI code: ${wmiCode} (not in Chrysler/FCA/Stellantis database)`);
    }

    // Model year
    const yearChar = vin.charAt(9);
    const modelYear = MODEL_YEAR_MAP[yearChar] || "Unknown";

    // Check digit validation (9th character)
    const checkDigit = calculateCheckDigit(vin);
    const actualCheckDigit = vin.charAt(8);
    const checkDigitValid = checkDigit === actualCheckDigit;

    if (!checkDigitValid) {
      errors.push(`Check digit mismatch: expected "${checkDigit}", got "${actualCheckDigit}"`);
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
      checkDigit: {
        expected: checkDigit,
        actual: actualCheckDigit,
        valid: checkDigitValid,
      },
      wmi: wmiInfo ? { code: wmiCode, ...wmiInfo } : null,
      modelYear,
    };
  };

  const calculateCheckDigit = (vin: string): string => {
    const transliteration: Record<string, number> = {
      "A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8,
      "J": 1, "K": 2, "L": 3, "M": 4, "N": 5, "P": 7, "R": 9,
      "S": 2, "T": 3, "U": 4, "V": 5, "W": 6, "X": 7, "Y": 8, "Z": 9,
      "0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
    };

    const weights = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];
    let sum = 0;

    for (let i = 0; i < 17; i++) {
      const char = vin.charAt(i);
      const value = transliteration[char] || 0;
      sum += value * weights[i];
    }

    const remainder = sum % 11;
    return remainder === 10 ? "X" : remainder.toString();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    setFile(uploadedFile);
    
    const arrayBuffer = await uploadedFile.arrayBuffer();
    const data = new Uint8Array(arrayBuffer);
    setFileData(data);

    // Detect module type based on file size
    let detectedType: "BCM" | "RFHUB" | null = null;
    if (data.length === 65536) {
      detectedType = "BCM";
    } else if (data.length === 4096 || data.length === 8192) {
      detectedType = "RFHUB";
    }

    setModuleType(detectedType);

    if (!detectedType) {
      toast.error("Unable to detect module type. File size must be 4KB, 8KB (RFHUB) or 64KB (BCM)");
      return;
    }

    // Scan entire file for VIN patterns
    const locations: VINLocation[] = [];
    const vinRegex = /^[A-HJ-NPR-Z0-9]{17}$/;
    const foundVINs = new Set<string>();
    
    for (let i = 0; i < data.length - 17; i++) {
      const vinBytes = data.slice(i, i + 17);
      const candidate = String.fromCharCode(...Array.from(vinBytes));
      
      if (vinRegex.test(candidate) && !foundVINs.has(candidate)) {
        // Validate WMI to filter false positives
        const wmiCode = candidate.substring(0, 3);
        if (WMI_DATABASE[wmiCode]) {
          foundVINs.add(candidate);
          const label = locations.length === 0 ? "Primary VIN" : `Backup VIN ${locations.length}`;
          locations.push({ offset: i, label, currentVIN: candidate });
          i += 16;
        }
      }
    }

    setVinLocations(locations);
    
    const initialVIN = locations.length > 0 ? locations[0].currentVIN : "";
    setNewVIN(initialVIN);
    
    if (initialVIN) {
      calculateChecksum(data, detectedType, initialVIN);
      setVinValidation(validateVIN(initialVIN));
    }

    if (locations.length > 0) {
      toast.success(`${detectedType} module detected with ${locations.length} VIN location(s)`);
    } else {
      toast.info(`${detectedType} module detected. No existing VIN found - you can enter a new VIN.`);
    }
  };

  const handleBatchFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const batchFilesData: BatchFile[] = [];

    for (const file of files) {
      const arrayBuffer = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);

      let detectedType: "BCM" | "RFHUB" | null = null;
      if (data.length === 65536) {
        detectedType = "BCM";
      } else if (data.length === 4096 || data.length === 8192) {
        detectedType = "RFHUB";
      }

      // Scan for VINs
      const locations: VINLocation[] = [];
      const vinRegex = /^[A-HJ-NPR-Z0-9]{17}$/;
      const foundVINs = new Set<string>();
      
      for (let i = 0; i < data.length - 17; i++) {
        const vinBytes = data.slice(i, i + 17);
        const candidate = String.fromCharCode(...Array.from(vinBytes));
        
        if (vinRegex.test(candidate) && !foundVINs.has(candidate)) {
          const wmiCode = candidate.substring(0, 3);
          if (WMI_DATABASE[wmiCode]) {
            foundVINs.add(candidate);
            const label = locations.length === 0 ? "Primary VIN" : `Backup VIN ${locations.length}`;
            locations.push({ offset: i, label, currentVIN: candidate });
            i += 16;
          }
        }
      }

      batchFilesData.push({
        file,
        data,
        moduleType: detectedType,
        vinLocations: locations,
        status: "pending",
      });
    }

    setBatchFiles(batchFilesData);
    toast.success(`${files.length} files loaded for batch processing`);
  };

  const handleBatchPatch = async () => {
    if (!batchVIN || batchVIN.length !== 17) {
      toast.error("Please enter a valid 17-character VIN");
      return;
    }

    const validation = validateVIN(batchVIN);
    if (!validation.valid) {
      toast.error(`VIN validation failed: ${validation.errors.join(", ")}`);
      return;
    }

    const updatedFiles = [...batchFiles];

    for (let i = 0; i < updatedFiles.length; i++) {
      const batchFile = updatedFiles[i];
      batchFile.status = "processing";
      setBatchFiles([...updatedFiles]);

      try {
        if (!batchFile.moduleType) {
          throw new Error("Unknown module type");
        }

        const patched = new Uint8Array(batchFile.data.slice(0));
        
        // Write VIN to all locations
        const offsetsToWrite = batchFile.vinLocations.length > 0 
          ? batchFile.vinLocations 
          : getDefaultVINOffsets(batchFile.moduleType);
        
        for (const location of offsetsToWrite) {
          for (let j = 0; j < 17; j++) {
            patched[location.offset + j] = batchVIN.charCodeAt(j);
          }
        }

        // Recalculate checksum
        if (batchFile.moduleType === "BCM") {
          let crc = 0xFFFF;
          const dataForCRC = patched.slice(0, 0xFFFE);
          
          for (let j = 0; j < dataForCRC.length; j++) {
            crc ^= (dataForCRC[j] << 8);
            for (let k = 0; k < 8; k++) {
              if (crc & 0x8000) {
                crc = (crc << 1) ^ 0x1021;
              } else {
                crc = crc << 1;
              }
            }
            crc &= 0xFFFF;
          }
          
          patched[0xFFFE] = (crc >> 8) & 0xFF;
          patched[0xFFFF] = crc & 0xFF;
        } else if (batchFile.moduleType === "RFHUB") {
          let sum = 0;
          for (let j = 0; j < patched.length - 1; j++) {
            sum += patched[j];
          }
          const checksum = (~sum) & 0xFF;
          patched[patched.length - 1] = checksum;
        }

        batchFile.patchedData = patched;
        batchFile.status = "success";
      } catch (error) {
        batchFile.status = "error";
        batchFile.error = error instanceof Error ? error.message : "Unknown error";
      }

      setBatchFiles([...updatedFiles]);
    }

    toast.success("Batch patching complete!");
  };

  const handleBatchDownload = async () => {
    const zip = new JSZip();

    for (const batchFile of batchFiles) {
      if (batchFile.status === "success" && batchFile.patchedData) {
        const filename = batchFile.file.name.replace(/\.bin$/, "_patched.bin");
        zip.file(filename, batchFile.patchedData);
      }
    }

    const content = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(content);
    const a = document.createElement("a");
    a.href = url;
    a.download = "patched_files.zip";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success("Batch files downloaded as ZIP!");
  };

  const calculateChecksum = (data: Uint8Array, type: "BCM" | "RFHUB", vin: string) => {
    const steps: string[] = [];
    
    if (type === "BCM") {
      steps.push("Algorithm: CRC-16/CCITT-FALSE");
      steps.push("Polynomial: 0x1021");
      steps.push("Initial value: 0xFFFF");
      
      let crc = 0xFFFF;
      const dataForCRC = data.slice(0, 0xFFFE);
      
      for (let i = 0; i < dataForCRC.length; i++) {
        crc ^= (dataForCRC[i] << 8);
        for (let j = 0; j < 8; j++) {
          if (crc & 0x8000) {
            crc = (crc << 1) ^ 0x1021;
          } else {
            crc = crc << 1;
          }
        }
        crc &= 0xFFFF;
      }
      
      const currentCRC = (data[0xFFFE] << 8) | data[0xFFFF];
      steps.push(`Calculated CRC: 0x${crc.toString(16).toUpperCase().padStart(4, "0")}`);
      steps.push(`Current CRC at 0xFFFE: 0x${currentCRC.toString(16).toUpperCase().padStart(4, "0")}`);
      
      setChecksumInfo({
        type: "CRC-16",
        algorithm: "CRC-16/CCITT-FALSE (polynomial 0x1021)",
        currentValue: `0x${currentCRC.toString(16).toUpperCase().padStart(4, "0")}`,
        newValue: `0x${crc.toString(16).toUpperCase().padStart(4, "0")}`,
        location: 0xFFFE,
        valid: crc === currentCRC,
        calculationSteps: steps,
      });
    } else if (type === "RFHUB") {
      steps.push("Algorithm: 8-bit One's Complement Checksum");
      
      let sum = 0;
      const dataForChecksum = data.slice(0, data.length - 1);
      
      for (let i = 0; i < dataForChecksum.length; i++) {
        sum += dataForChecksum[i];
      }
      
      const checksum = (~sum) & 0xFF;
      const currentChecksum = data[data.length - 1];
      
      steps.push(`Sum: 0x${sum.toString(16).toUpperCase()}`);
      steps.push(`Complement: 0x${checksum.toString(16).toUpperCase().padStart(2, "0")}`);
      
      setChecksumInfo({
        type: "Complement",
        algorithm: "8-bit One's Complement Checksum",
        currentValue: `0x${currentChecksum.toString(16).toUpperCase().padStart(2, "0")}`,
        newValue: `0x${checksum.toString(16).toUpperCase().padStart(2, "0")}`,
        location: data.length - 1,
        valid: checksum === currentChecksum,
        calculationSteps: steps,
      });
    }
  };

  const handleVINChange = (value: string) => {
    const upperValue = value.toUpperCase();
    setNewVIN(upperValue);
    
    if (upperValue.length === 17) {
      setVinValidation(validateVIN(upperValue));
    } else {
      setVinValidation(null);
    }
    
    if (fileData && moduleType && upperValue.length === 17) {
      const tempData = new Uint8Array(fileData);
      
      for (const location of vinLocations) {
        for (let i = 0; i < 17; i++) {
          tempData[location.offset + i] = upperValue.charCodeAt(i);
        }
      }
      
      calculateChecksum(tempData, moduleType, upperValue);
    }
  };

  const handlePatch = () => {
    if (!fileData || !moduleType || newVIN.length !== 17) {
      toast.error("Please upload a file and enter a valid 17-character VIN");
      return;
    }

    const validation = validateVIN(newVIN);
    if (!validation.valid) {
      toast.error(`VIN validation failed: ${validation.errors.join(", ")}`);
      return;
    }

    const patched = new Uint8Array(fileData.slice(0));
    
    const offsetsToWrite = vinLocations.length > 0 ? vinLocations : getDefaultVINOffsets(moduleType);
    
    for (const location of offsetsToWrite) {
      for (let i = 0; i < 17; i++) {
        patched[location.offset + i] = newVIN.charCodeAt(i);
      }
    }

    if (moduleType === "BCM") {
      let crc = 0xFFFF;
      const dataForCRC = patched.slice(0, 0xFFFE);
      
      for (let i = 0; i < dataForCRC.length; i++) {
        crc ^= (dataForCRC[i] << 8);
        for (let j = 0; j < 8; j++) {
          if (crc & 0x8000) {
            crc = (crc << 1) ^ 0x1021;
          } else {
            crc = crc << 1;
          }
        }
        crc &= 0xFFFF;
      }
      
      patched[0xFFFE] = (crc >> 8) & 0xFF;
      patched[0xFFFF] = crc & 0xFF;
    } else if (moduleType === "RFHUB") {
      let sum = 0;
      for (let i = 0; i < patched.length - 1; i++) {
        sum += patched[i];
      }
      const checksum = (~sum) & 0xFF;
      patched[patched.length - 1] = checksum;
    }

    setPatchedData(patched);
    calculateChecksum(patched, moduleType, newVIN);
    toast.success("VIN patched successfully with recalculated checksum!");
  };

  const handleDownload = () => {
    if (!patchedData || !file) return;

    const blob = new Blob([new Uint8Array(patchedData)], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name.replace(/\.bin$/, "_patched.bin");
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success("Patched file downloaded!");
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">VIN Patcher with CRC Calculator</h1>
        <p className="text-muted-foreground">
          Patch VIN in BCM/RFHUB EEPROM dumps with automatic checksum recalculation
        </p>
      </div>

      {/* Mode Toggle */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <Button
              variant={!batchMode ? "default" : "outline"}
              onClick={() => setBatchMode(false)}
              className="flex-1"
            >
              <FileUp className="mr-2 h-4 w-4" />
              Single File Mode
            </Button>
            <Button
              variant={batchMode ? "default" : "outline"}
              onClick={() => setBatchMode(true)}
              className="flex-1"
            >
              <Package className="mr-2 h-4 w-4" />
              Batch Mode
            </Button>
          </div>
        </CardContent>
      </Card>

      {!batchMode ? (
        // SINGLE FILE MODE
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Left Column */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload EEPROM Dump</CardTitle>
                <CardDescription>
                  Upload a BCM (64KB) or RFHUB (4KB/8KB) binary file
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <Input
                      type="file"
                      accept=".bin"
                      onChange={handleFileUpload}
                      className="max-w-xs mx-auto"
                    />
                  </div>
                  
                  {file && (
                    <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium">{file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(file.size / 1024).toFixed(2)} KB
                        </p>
                      </div>
                      {moduleType && (
                        <Badge variant="outline">{moduleType}</Badge>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {vinLocations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Current VIN Locations</CardTitle>
                  <CardDescription>
                    Found {vinLocations.length} VIN location(s) in file
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {vinLocations.map((loc, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <p className="font-medium">{loc.label}</p>
                          <p className="text-sm text-muted-foreground">
                            Offset: 0x{loc.offset.toString(16).toUpperCase().padStart(4, "0")}
                          </p>
                        </div>
                        <Badge variant="secondary" className="font-mono">
                          {loc.currentVIN}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {file && (
              <Card>
                <CardHeader>
                  <CardTitle>Enter New VIN</CardTitle>
                  <CardDescription>
                    17-character VIN (no I, O, or Q)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Input
                      value={newVIN}
                      onChange={(e) => handleVINChange(e.target.value)}
                      placeholder="1C3CCCAG0FN123456"
                      maxLength={17}
                      className="font-mono text-lg"
                    />
                    
                    {/* VIN Decoder Integration */}
                    {newVIN.length === 17 && (
                      <div className="pt-4 border-t">
                        <VINDecoderPanel initialVIN={newVIN} compact={true} />
                      </div>
                    )}
                    
                    {vinValidation && (
                      <div className="space-y-2">
                        {vinValidation.errors.length > 0 && (
                          <Alert variant="destructive">
                            <XCircle className="h-4 w-4" />
                            <AlertDescription>
                              {vinValidation.errors.map((err, idx) => (
                                <div key={idx}>{err}</div>
                              ))}
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        {vinValidation.warnings.length > 0 && (
                          <Alert>
                            <Info className="h-4 w-4" />
                            <AlertDescription>
                              {vinValidation.warnings.map((warn, idx) => (
                                <div key={idx}>{warn}</div>
                              ))}
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        {vinValidation.valid && (
                          <Alert className="border-green-500 bg-green-500/10">
                            <CheckCircle2 className="h-4 w-4 text-green-500" />
                            <AlertDescription className="text-green-500">
                              VIN validation passed
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Check Digit</p>
                            <Badge variant={vinValidation.checkDigit.valid ? "default" : "destructive"}>
                              {vinValidation.checkDigit.actual} 
                              {!vinValidation.checkDigit.valid && ` (expected ${vinValidation.checkDigit.expected})`}
                            </Badge>
                          </div>
                          
                          {vinValidation.wmi && (
                            <div>
                              <p className="text-muted-foreground">Manufacturer</p>
                              <Badge variant="outline">
                                {vinValidation.wmi.manufacturer} ({vinValidation.wmi.country})
                              </Badge>
                            </div>
                          )}
                          
                          <div>
                            <p className="text-muted-foreground">Model Year</p>
                            <Badge variant="outline">{vinValidation.modelYear}</Badge>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      <Button
                        onClick={handlePatch}
                        disabled={!file || newVIN.length !== 17 || (vinValidation ? !vinValidation.valid : false)}
                        className="flex-1"
                      >
                        <Calculator className="mr-2 h-4 w-4" />
                        Patch VIN & Recalculate CRC
                      </Button>
                      
                      {patchedData && (
                        <Button onClick={handleDownload} variant="outline">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {checksumInfo && (
              <Card>
                <CardHeader>
                  <CardTitle>Checksum Information</CardTitle>
                  <CardDescription>{checksumInfo.algorithm}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Current Checksum</p>
                        <Badge variant="outline" className="font-mono">
                          {checksumInfo.currentValue}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">New Checksum</p>
                        <Badge variant="outline" className="font-mono">
                          {checksumInfo.newValue}
                        </Badge>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Checksum Location</p>
                      <Badge variant="outline" className="font-mono">
                        0x{checksumInfo.location.toString(16).toUpperCase().padStart(4, "0")}
                      </Badge>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Calculation Steps</p>
                      <div className="bg-muted p-3 rounded-lg space-y-1 text-xs font-mono">
                        {checksumInfo.calculationSteps.map((step, idx) => (
                          <div key={idx}>{step}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {fileData && (
              <Card>
                <CardHeader>
                  <CardTitle>Hex Viewer</CardTitle>
                  <CardDescription>
                    {patchedData ? "Patched data (showing changes)" : "Original data"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-green-500/20 border border-green-500 rounded"></div>
                        <span>VIN Bytes</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-blue-500/20 border border-blue-500 rounded"></div>
                        <span>Checksum Bytes</span>
                      </div>
                      {patchedData && (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-red-500/20 border border-red-500 rounded"></div>
                          <span>Modified Bytes</span>
                        </div>
                      )}
                    </div>

                    <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-xs overflow-x-auto max-h-96 overflow-y-auto">
                      <div className="space-y-1">
                        {renderHexDump()}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      ) : (
        // BATCH MODE
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Batch File Upload</CardTitle>
              <CardDescription>
                Upload multiple BCM/RFHUB files to patch with the same VIN
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-2 border-dashed rounded-lg p-8 text-center">
                  <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <Input
                    type="file"
                    accept=".bin"
                    multiple
                    onChange={handleBatchFileUpload}
                    className="max-w-xs mx-auto"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Select multiple .bin files
                  </p>
                </div>

                {batchFiles.length > 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{batchFiles.length} files loaded</p>
                      <Badge variant="outline">
                        {batchFiles.filter(f => f.status === "success").length} / {batchFiles.length} patched
                      </Badge>
                    </div>

                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {batchFiles.map((batchFile, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                          <div className="flex-1">
                            <p className="font-medium text-sm">{batchFile.file.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {batchFile.moduleType || "Unknown"} • {(batchFile.file.size / 1024).toFixed(2)} KB
                            </p>
                          </div>
                          <Badge
                            variant={
                              batchFile.status === "success" ? "default" :
                              batchFile.status === "error" ? "destructive" :
                              batchFile.status === "processing" ? "secondary" :
                              "outline"
                            }
                          >
                            {batchFile.status}
                          </Badge>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium mb-2">Enter VIN for all files</p>
                        <Input
                          value={batchVIN}
                          onChange={(e) => setBatchVIN(e.target.value.toUpperCase())}
                          placeholder="1C3CCCAG0FN123456"
                          maxLength={17}
                          className="font-mono text-lg"
                        />
                      </div>

                      <div className="flex gap-2">
                        <Button
                          onClick={handleBatchPatch}
                          disabled={batchVIN.length !== 17}
                          className="flex-1"
                        >
                          <Calculator className="mr-2 h-4 w-4" />
                          Patch All Files
                        </Button>
                        
                        {batchFiles.some(f => f.status === "success") && (
                          <Button onClick={handleBatchDownload} variant="outline">
                            <Download className="mr-2 h-4 w-4" />
                            Download ZIP
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );

  function renderHexDump() {
    if (!fileData) return null;

    const dataToDisplay = patchedData || fileData;
    const rows: React.ReactElement[] = [];
    const bytesPerRow = 16;

    const vinOffsets = new Set<number>();
    for (const loc of vinLocations) {
      for (let i = 0; i < 17; i++) {
        vinOffsets.add(loc.offset + i);
      }
    }

    const checksumOffsets = new Set<number>();
    if (checksumInfo) {
      if (checksumInfo.type === "CRC-16") {
        checksumOffsets.add(checksumInfo.location);
        checksumOffsets.add(checksumInfo.location + 1);
      } else {
        checksumOffsets.add(checksumInfo.location);
      }
    }

    const modifiedOffsets = new Set<number>();
    if (patchedData && fileData) {
      for (let i = 0; i < dataToDisplay.length; i++) {
        if (dataToDisplay[i] !== fileData[i]) {
          modifiedOffsets.add(i);
        }
      }
    }

    for (let offset = 0; offset < dataToDisplay.length; offset += bytesPerRow) {
      const rowBytes = dataToDisplay.slice(offset, offset + bytesPerRow);
      
      const offsetStr = offset.toString(16).toUpperCase().padStart(8, "0");
      
      const hexBytes = Array.from(rowBytes).map((byte, idx) => {
        const byteOffset = offset + idx;
        const hexStr = byte.toString(16).toUpperCase().padStart(2, "0");
        
        let className = "";
        if (vinOffsets.has(byteOffset)) {
          className = "bg-green-500/20 border border-green-500 px-0.5";
        } else if (checksumOffsets.has(byteOffset)) {
          className = "bg-blue-500/20 border border-blue-500 px-0.5";
        } else if (modifiedOffsets.has(byteOffset)) {
          className = "bg-red-500/20 border border-red-500 px-0.5";
        }
        
        return (
          <span key={idx} className={className}>
            {hexStr}
          </span>
        );
      });
      
      const asciiChars = Array.from(rowBytes).map((byte) => {
        return byte >= 0x20 && byte <= 0x7E ? String.fromCharCode(byte) : ".";
      }).join("");
      
      rows.push(
        <div key={offset} className="flex gap-4">
          <span className="text-gray-500">{offsetStr}</span>
          <span className="flex gap-1">{hexBytes}</span>
          <span className="text-gray-400">{asciiChars}</span>
        </div>
      );
    }

    return rows;
  }

  function getDefaultVINOffsets(type: "BCM" | "RFHUB"): VINLocation[] {
    if (type === "BCM") {
      return [
        { offset: 0x0100, label: "Primary VIN", currentVIN: "" },
        { offset: 0x0200, label: "Backup VIN 1", currentVIN: "" },
        { offset: 0x0300, label: "Backup VIN 2", currentVIN: "" },
        { offset: 0x0400, label: "Backup VIN 3", currentVIN: "" },
      ];
    } else {
      return [
        { offset: 0x0100, label: "Primary VIN", currentVIN: "" },
        { offset: 0x0150, label: "Backup VIN", currentVIN: "" },
      ];
    }
  }
}
