import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { BackButton } from "@/components/BackButton";
import { 
  Upload, 
  Play, 
  StopCircle, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  Cpu,
  FileCode,
  Info
} from 'lucide-react';

interface FlashFile {
  name: string;
  size: number;
  type: string;
  file: File;
}

interface FlashProgress {
  phase: 'idle' | 'starting' | 'erasing' | 'programming' | 'verifying' | 'completed' | 'failed';
  progress: number;
  currentBlock: number;
  totalBlocks: number;
  message: string;
}

export default function FlashProgrammingManager() {
  const [selectedModule, setSelectedModule] = useState('BCM');
  const [flashFile, setFlashFile] = useState<FlashFile | null>(null);
  const [flashProgress, setFlashProgress] = useState<FlashProgress>({
    phase: 'idle',
    progress: 0,
    currentBlock: 0,
    totalBlocks: 0,
    message: 'Ready to flash'
  });
  const [isFlashing, setIsFlashing] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFlashFile({
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream',
        file
      });
    }
  };

  const startFlash = async () => {
    if (!flashFile) return;

    setIsFlashing(true);

    // Phase 1: Starting
    setFlashProgress({
      phase: 'starting',
      progress: 5,
      currentBlock: 0,
      totalBlocks: 100,
      message: 'Entering bootloader mode...'
    });
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Phase 2: Erasing
    setFlashProgress({
      phase: 'erasing',
      progress: 15,
      currentBlock: 0,
      totalBlocks: 100,
      message: 'Erasing flash memory...'
    });
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Phase 3: Programming
    setFlashProgress({
      phase: 'programming',
      progress: 25,
      currentBlock: 0,
      totalBlocks: 100,
      message: 'Programming flash memory...'
    });

    // Simulate block-by-block programming
    for (let block = 1; block <= 100; block++) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setFlashProgress({
        phase: 'programming',
        progress: 25 + (block * 0.6),
        currentBlock: block,
        totalBlocks: 100,
        message: `Programming block ${block}/100...`
      });
    }

    // Phase 4: Verifying
    setFlashProgress({
      phase: 'verifying',
      progress: 90,
      currentBlock: 100,
      totalBlocks: 100,
      message: 'Verifying flash memory...'
    });
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Phase 5: Completed
    setFlashProgress({
      phase: 'completed',
      progress: 100,
      currentBlock: 100,
      totalBlocks: 100,
      message: 'Flash programming completed successfully!'
    });

    setIsFlashing(false);
  };

  const stopFlash = () => {
    setFlashProgress({
      phase: 'failed',
      progress: flashProgress.progress,
      currentBlock: flashProgress.currentBlock,
      totalBlocks: flashProgress.totalBlocks,
      message: 'Flash programming stopped by user'
    });
    setIsFlashing(false);
  };

  const resetFlash = () => {
    setFlashProgress({
      phase: 'idle',
      progress: 0,
      currentBlock: 0,
      totalBlocks: 0,
      message: 'Ready to flash'
    });
    setFlashFile(null);
  };

  const getPhaseIcon = (phase: FlashProgress['phase']) => {
    switch (phase) {
      case 'idle':
        return <FileCode className="h-5 w-5 text-gray-400" />;
      case 'starting':
      case 'erasing':
      case 'programming':
      case 'verifying':
        return <Cpu className="h-5 w-5 text-yellow-500 animate-pulse" />;
      case 'completed':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
    }
  };

  const getPhaseColor = (phase: FlashProgress['phase']) => {
    switch (phase) {
      case 'idle':
        return 'bg-gray-500';
      case 'starting':
      case 'erasing':
        return 'bg-blue-500';
      case 'programming':
        return 'bg-yellow-500';
      case 'verifying':
        return 'bg-purple-500';
      case 'completed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
    }
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">
          Flash Programming Manager
        </h1>
        <p className="text-muted-foreground mt-2">
          Upload and flash firmware to vehicle modules (professional diagnostic tool Clone)
        </p>
      </div>

      {/* Warning Alert */}
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>WARNING:</strong> Flash programming can brick your module if interrupted or if the wrong firmware is used. 
          Ensure stable power supply and correct firmware file before proceeding. Always backup original firmware first.
        </AlertDescription>
      </Alert>

      {/* Configuration */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Flash Configuration</h2>
        <div className="space-y-4">
          <div>
            <Label htmlFor="target-module">Target Module</Label>
            <Select value={selectedModule} onValueChange={setSelectedModule} disabled={isFlashing}>
              <SelectTrigger id="target-module">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                <SelectItem value="RFHUB">RFHUB (SmartBox)</SelectItem>
                <SelectItem value="ABS">ABS (Anti-lock Braking System)</SelectItem>
                <SelectItem value="SGW">SecurityGateway</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="flash-file">Firmware File (.hex, .bin)</Label>
            <Input
              id="flash-file"
              type="file"
              accept=".hex,.bin,.s19,.srec"
              onChange={handleFileUpload}
              disabled={isFlashing}
            />
          </div>

          {flashFile && (
            <div className="border rounded-lg p-4 bg-muted/50">
              <h3 className="font-semibold mb-2">Selected File:</h3>
              <div className="space-y-1 text-sm">
                <p><strong>Name:</strong> {flashFile.name}</p>
                <p><strong>Size:</strong> {(flashFile.size / 1024).toFixed(2)} KB</p>
                <p><strong>Type:</strong> {flashFile.type}</p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Flash Progress */}
      {flashProgress.phase !== 'idle' && (
        <Card className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {getPhaseIcon(flashProgress.phase)}
                <div>
                  <h2 className="text-xl font-semibold capitalize">{flashProgress.phase}</h2>
                  <p className="text-sm text-muted-foreground">{flashProgress.message}</p>
                </div>
              </div>
              <Badge variant={flashProgress.phase === 'completed' ? 'default' : flashProgress.phase === 'failed' ? 'destructive' : 'outline'}>
                {flashProgress.progress.toFixed(0)}%
              </Badge>
            </div>

            <Progress value={flashProgress.progress} className={`h-3 ${getPhaseColor(flashProgress.phase)}`} />

            {flashProgress.phase === 'programming' && (
              <div className="text-sm text-muted-foreground">
                Block {flashProgress.currentBlock} / {flashProgress.totalBlocks}
              </div>
            )}

            {flashProgress.phase === 'completed' && (
              <Alert>
                <CheckCircle2 className="h-4 w-4" />
                <AlertDescription>
                  Flash programming completed successfully! The module will now reboot. 
                  Wait 30 seconds before attempting to communicate with the module.
                </AlertDescription>
              </Alert>
            )}

            {flashProgress.phase === 'failed' && (
              <Alert variant="destructive">
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  Flash programming failed! The module may be in recovery mode. 
                  Try again or use recovery mode flashing if available.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </Card>
      )}

      {/* Actions */}
      <Card className="p-6">
        <div className="flex gap-2">
          {!isFlashing && flashProgress.phase === 'idle' && (
            <Button
              onClick={startFlash}
              disabled={!flashFile}
              size="lg"
            >
              <Play className="mr-2 h-5 w-5" />
              Start Flash Programming
            </Button>
          )}

          {isFlashing && (
            <Button
              onClick={stopFlash}
              variant="destructive"
              size="lg"
            >
              <StopCircle className="mr-2 h-5 w-5" />
              Stop Flash
            </Button>
          )}

          {!isFlashing && flashProgress.phase !== 'idle' && (
            <Button
              onClick={resetFlash}
              variant="outline"
              size="lg"
            >
              Reset
            </Button>
          )}
        </div>
      </Card>

      {/* Technical Details */}
      <Card className="p-6 bg-muted/50">
        <h3 className="text-lg font-semibold mb-4">Technical Details</h3>
        <div className="space-y-2 text-sm">
          <p><strong>Message Protocol:</strong> professional diagnostic tool-compatible JSON messages over HTTP/HTTPS</p>
          <p><strong>StartFlashMessage:</strong> Initiates flash programming session</p>
          <p><strong>FlashProgressMessage:</strong> Reports real-time progress during flashing</p>
          <p><strong>StopFlashMessage:</strong> Cancels ongoing flash operation</p>
          <p><strong>UDS Commands:</strong> 0x10 0x02 (Enter Bootloader), 0x31 (Erase), 0x34/0x36 (Download), 0x31 (Verify)</p>
          <p><strong>Block Size:</strong> Typically 256-4096 bytes depending on module</p>
          <p><strong>CRC Verification:</strong> Automatic CRC-16 or CRC-32 after programming</p>
        </div>
      </Card>

      {/* Info Alert */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>professional diagnostic tool Clone Feature:</strong> This Flash Programming Manager replicates the functionality of Chrysler's professional diagnostic tool flash programming system. 
          It supports .hex, .bin, .s19, and .srec firmware files and uses the same message protocol as the original professional diagnostic tool application.
        </AlertDescription>
      </Alert>

      {/* Supported Modules */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Supported Modules</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">BCM (Body Control Module)</h4>
            <p className="text-sm text-muted-foreground">
              Firmware updates, feature activation, VIN programming
            </p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">ECM (Engine Control Module)</h4>
            <p className="text-sm text-muted-foreground">
              Performance tuning, emissions updates, calibration changes
            </p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">TCM (Transmission Control Module)</h4>
            <p className="text-sm text-muted-foreground">
              Shift logic updates, torque management, gear ratio changes
            </p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">RFHUB (SmartBox)</h4>
            <p className="text-sm text-muted-foreground">
              Key programming, immobilizer updates, security features
            </p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">ABS (Anti-lock Braking System)</h4>
            <p className="text-sm text-muted-foreground">
              Brake control updates, stability control, traction control
            </p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">SecurityGateway</h4>
            <p className="text-sm text-muted-foreground">
              Gateway firmware, security updates, module authorization
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
