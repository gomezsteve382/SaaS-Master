import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BackButton } from "@/components/BackButton";
import { useToast } from "@/hooks/use-toast";
import { 
  Shield, Radio, ArrowLeft, Calculator, Copy, CheckCircle2, 
  AlertTriangle, Loader2, Music, Smartphone
} from "lucide-react";

interface RadioCodeResult {
  success: boolean;
  serial: string;
  type: string;
  code: string;
  error?: string;
}

type RadioType = "auto" | "t00be" | "tqn" | "tm9" | "vp2";

const RADIO_TYPES: Record<RadioType, { name: string; prefix: string; supplier: string; description: string }> = {
  auto: { name: "Auto-Detect", prefix: "", supplier: "Any", description: "Automatically detect radio type from serial" },
  t00be: { name: "T00BE (Harman/Becker)", prefix: "T00BE", supplier: "Harman Becker", description: "Uconnect 8.4 / RB3 / NTG4 head units" },
  tqn: { name: "TQN (Continental)", prefix: "T00QN", supplier: "Continental VP2", description: "Continental VP2 navigation units" },
  tm9: { name: "TM9 (Panasonic)", prefix: "TM9", supplier: "Panasonic", description: "Panasonic infotainment systems" },
  vp2: { name: "VP2 (Continental)", prefix: "VP2", supplier: "Continental", description: "VP2 variant head units" },
};

export default function RadioCodes() {
  const [serialNumber, setSerialNumber] = useState("");
  const [radioType, setRadioType] = useState<RadioType>("auto");
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<RadioCodeResult | null>(null);
  const { toast } = useToast();

  const detectRadioType = (serial: string): RadioType => {
    const upperSerial = serial.toUpperCase().trim();
    if (upperSerial.includes("T00BE") || upperSerial.startsWith("T00BE")) return "t00be";
    if (upperSerial.includes("QN") || upperSerial.includes("T00QN")) return "tqn";
    if (upperSerial.startsWith("TM9")) return "tm9";
    if (upperSerial.includes("VP2")) return "vp2";
    return "auto";
  };

  const handleCalculate = async () => {
    if (!serialNumber.trim()) {
      toast({
        title: "Missing Serial Number",
        description: "Please enter a radio serial number",
        variant: "destructive",
      });
      return;
    }

    setIsCalculating(true);
    setResult(null);

    try {
      const response = await fetch("/api/radio-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serial: serialNumber.trim().toUpperCase(),
          type: radioType === "auto" ? detectRadioType(serialNumber) : radioType,
        }),
      });

      const data = await response.json();
      setResult(data);

      if (data.success) {
        toast({
          title: "Code Calculated",
          description: `Radio code: ${data.code}`,
        });
      } else {
        toast({
          title: "Calculation Failed",
          description: data.error || "Could not calculate code",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Code copied to clipboard",
    });
  };

  const detectedType = radioType === "auto" ? detectRadioType(serialNumber) : radioType;

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-md">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <BackButton />
      <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2" data-testid="button-back">
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
            </Link>
            <div className="w-8 h-8 bg-purple-600 rounded flex items-center justify-center">
              <Music className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="font-mono font-bold text-lg leading-none tracking-tight" data-testid="text-page-title">
                RADIO CODE CALCULATOR
              </h1>
              <span className="text-[10px] text-purple-400 uppercase tracking-widest">Infotainment Unlock Codes</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Link href="/rfhub-tool">
              <Button size="sm" className="bg-orange-600 hover:bg-orange-700" data-testid="button-rfhub-tool">
                <Smartphone className="w-3 h-3 mr-1.5" />
                RFHUB Tool
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card className="border-purple-500/30 bg-purple-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-mono">
                <Calculator className="w-5 h-5 text-purple-400" />
                Radio Unlock Code Calculator
              </CardTitle>
              <CardDescription>
                Enter your radio's serial number to calculate the unlock code. 
                Supports Harman/Becker (T00BE), Continental (TQN/VP2), and Panasonic (TM9).
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="radio-type">Radio Type</Label>
                    <Select value={radioType} onValueChange={(v) => setRadioType(v as RadioType)}>
                      <SelectTrigger id="radio-type" data-testid="select-radio-type">
                        <SelectValue placeholder="Select radio type" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(RADIO_TYPES).map(([key, info]) => (
                          <SelectItem key={key} value={key}>
                            {info.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {radioType !== "auto" && (
                      <p className="text-xs text-white/50">{RADIO_TYPES[radioType].description}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="serial-number">Serial Number</Label>
                    <Input
                      id="serial-number"
                      placeholder="e.g., T00BE12345678"
                      value={serialNumber}
                      onChange={(e) => setSerialNumber(e.target.value.toUpperCase())}
                      className="font-mono text-lg"
                      data-testid="input-serial-number"
                    />
                    {serialNumber && detectedType !== "auto" && (
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-purple-400 border-purple-400/30">
                          Detected: {RADIO_TYPES[detectedType].name}
                        </Badge>
                      </div>
                    )}
                  </div>

                  <Button
                    onClick={handleCalculate}
                    disabled={isCalculating || !serialNumber.trim()}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                    data-testid="button-calculate"
                  >
                    {isCalculating ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Calculating...
                      </>
                    ) : (
                      <>
                        <Calculator className="w-4 h-4 mr-2" />
                        Calculate Code
                      </>
                    )}
                  </Button>
                </div>

                <div className="space-y-4">
                  {result && (
                    <Card className={result.success ? "border-green-500/30 bg-green-500/10" : "border-red-500/30 bg-red-500/10"}>
                      <CardContent className="pt-6">
                        {result.success ? (
                          <div className="text-center space-y-4">
                            <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto" />
                            <div>
                              <p className="text-sm text-white/60">Unlock Code</p>
                              <p className="text-4xl font-mono font-bold text-green-400" data-testid="text-result-code">
                                {result.code}
                              </p>
                            </div>
                            <div className="text-sm text-white/60">
                              <p>Radio Type: {result.type}</p>
                              <p>Serial: {result.serial}</p>
                            </div>
                            <Button
                              variant="outline"
                              onClick={() => copyToClipboard(result.code)}
                              className="border-green-500/30"
                              data-testid="button-copy-code"
                            >
                              <Copy className="w-4 h-4 mr-2" />
                              Copy Code
                            </Button>
                          </div>
                        ) : (
                          <div className="text-center space-y-4">
                            <AlertTriangle className="w-12 h-12 text-red-400 mx-auto" />
                            <div>
                              <p className="text-lg font-semibold text-red-400">Calculation Failed</p>
                              <p className="text-sm text-white/60">{result.error}</p>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {!result && (
                    <Card className="border-white/10 bg-white/5">
                      <CardContent className="pt-6">
                        <div className="text-center space-y-4 text-white/40">
                          <Radio className="w-12 h-12 mx-auto" />
                          <p>Enter a serial number and click Calculate to get the unlock code</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-white/10 bg-white/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Badge className="bg-blue-600">T00BE</Badge>
                  Harman/Becker
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-white/60">
                  Uconnect 8.4, RB3, NTG4 head units. Serial format: T00BEXXXXXXXX
                </p>
              </CardContent>
            </Card>

            <Card className="border-white/10 bg-white/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Badge className="bg-green-600">TQN/VP2</Badge>
                  Continental
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-white/60">
                  VP2 navigation units. Serial format: T00QNXXXXXXXX or VP2XXXXXXX
                </p>
              </CardContent>
            </Card>

            <Card className="border-white/10 bg-white/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Badge className="bg-orange-600">TM9</Badge>
                  Panasonic
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-white/60">
                  Panasonic infotainment systems. Serial format: TM9XXXXXXXXX
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="border-yellow-500/30 bg-yellow-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-400 text-sm">
                <AlertTriangle className="w-4 h-4" />
                Algorithm Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-white/70">
                The radio code algorithms require proprietary calculations or database lookups. 
                The backend currently uses placeholder functions. To enable real code calculation, 
                you need to provide the actual algorithm constants or a serial-to-code database.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
