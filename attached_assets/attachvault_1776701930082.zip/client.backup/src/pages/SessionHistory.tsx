import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { Calendar, Download, Search, Filter, Clock, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function SessionHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [dateRange, setDateRange] = useState<string>("all");
  
  const { data: sessions, isLoading } = trpc.sessions.list.useQuery();
  
  // Convert sessions to audit log format for display
  const auditLogs = sessions?.map(session => ({
    id: session.id,
    action: `Diagnostic Session - ${session.adapterType || 'Unknown Adapter'}`,
    moduleType: session.adapterType || 'N/A',
    details: `VIN: ${session.vin || 'N/A'} | Vehicle: ${session.vehicleInfo || 'N/A'} | Status: ${session.status}`,
    timestamp: session.startedAt,
    status: session.status
  }));

  const filteredLogs = auditLogs?.filter((log: any) => {
    const matchesSearch = 
      searchTerm === "" ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === "all" || log.action.includes(filterType);
    
    // Date range filtering
    if (dateRange !== "all") {
      const logDate = new Date(log.timestamp);
      const now = new Date();
      const daysDiff = Math.floor((now.getTime() - logDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (dateRange === "today" && daysDiff > 0) return false;
      if (dateRange === "week" && daysDiff > 7) return false;
      if (dateRange === "month" && daysDiff > 30) return false;
    }
    
    return matchesSearch && matchesType;
  });

  const exportToCSV = () => {
    if (!filteredLogs) return;
    
    const headers = ["Timestamp", "Action", "Module Type", "Details", "Status"];
    const rows = filteredLogs.map((log: any) => [
      format(new Date(log.timestamp), "yyyy-MM-dd HH:mm:ss"),
      log.action,
      log.moduleType || "N/A",
      log.details || "",
      log.status || "completed"
    ]);
    
    const csv = [headers, ...rows].map(row => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `session-history-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
  };

  const getActionIcon = (action: string) => {
    if (action.includes("VIN")) return <CheckCircle2 className="h-4 w-4 text-green-600" />;
    if (action.includes("Security")) return <AlertCircle className="h-4 w-4 text-yellow-600" />;
    if (action.includes("DTC")) return <XCircle className="h-4 w-4 text-red-600" />;
    return <Clock className="h-4 w-4 text-gray-600" />;
  };

  const getActionBadge = (action: string) => {
    if (action.includes("VIN")) return <Badge variant="default" className="bg-green-600">VIN Operation</Badge>;
    if (action.includes("Security")) return <Badge variant="default" className="bg-yellow-600">Security Access</Badge>;
    if (action.includes("DTC")) return <Badge variant="default" className="bg-red-600">DTC Operation</Badge>;
    if (action.includes("BCM")) return <Badge variant="default" className="bg-blue-600">BCM Coding</Badge>;
    return <Badge variant="outline">Other</Badge>;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <BackButton />
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">SESSION HISTORY</h1>
          <p className="text-gray-600">Track all diagnostic operations and module programming sessions</p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search operations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Operation Type Filter */}
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="Operation Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Operations</SelectItem>
                  <SelectItem value="VIN">VIN Programming</SelectItem>
                  <SelectItem value="Security">Security Access</SelectItem>
                  <SelectItem value="DTC">DTC Operations</SelectItem>
                  <SelectItem value="BCM">BCM Coding</SelectItem>
                </SelectContent>
              </Select>

              {/* Date Range Filter */}
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger>
                  <SelectValue placeholder="Date Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Past Week</SelectItem>
                  <SelectItem value="month">Past Month</SelectItem>
                </SelectContent>
              </Select>

              {/* Export Button */}
              <Button onClick={exportToCSV} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Timeline */}
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Loading session history...</p>
          </div>
        ) : filteredLogs && filteredLogs.length > 0 ? (
          <div className="space-y-4">
            {filteredLogs.map((log: any) => (
              <Card key={log.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Icon */}
                    <div className="mt-1">
                      {getActionIcon(log.action)}
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <h3 className="font-bold text-lg">{log.action}</h3>
                          {getActionBadge(log.action)}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Calendar className="h-4 w-4" />
                          {format(new Date(log.timestamp), "MMM dd, yyyy HH:mm:ss")}
                        </div>
                      </div>

                      {log.moduleType && (
                        <p className="text-sm text-gray-600 mb-1">
                          <span className="font-semibold">Module:</span> {log.moduleType}
                        </p>
                      )}

                      {log.details && (
                        <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded mt-2 font-mono">
                          {log.details}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Clock className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">No Sessions Found</h3>
              <p className="text-gray-500">
                {searchTerm || filterType !== "all" || dateRange !== "all"
                  ? "Try adjusting your filters"
                  : "Start performing diagnostic operations to see history here"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
