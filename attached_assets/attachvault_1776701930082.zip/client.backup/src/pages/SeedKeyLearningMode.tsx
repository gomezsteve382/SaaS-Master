import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';

/**
 * Seed-Key Learning Mode
 * 
 * Machine learning-based pattern recognition for unknown modules
 * Captures successful seed-key pairs and automatically updates algorithm constants
 */

interface SeedKeyPair {
  seed: string;
  key: string;
  moduleCode?: string;
  timestamp: number;
  verified: boolean;
}

interface LearnedPattern {
  constant?: number;
  multiplier?: number;
  xorMask?: number;
  addend?: number;
  confidence: number;
  sampleSize: number;
  formula: string;
}

export default function SeedKeyLearningMode() {
  const [pairs, setPairs] = useState<SeedKeyPair[]>([]);
  const [seedInput, setSeedInput] = useState('');
  const [keyInput, setKeyInput] = useState('');
  const [moduleCode, setModuleCode] = useState('');
  const [learnedPattern, setLearnedPattern] = useState<LearnedPattern | null>(null);
  const [learning, setLearning] = useState(false);

  const addPair = () => {
    if (!seedInput || !keyInput) {
      toast.error('Please enter both seed and key values');
      return;
    }

    const newPair: SeedKeyPair = {
      seed: seedInput,
      key: keyInput,
      moduleCode: moduleCode || undefined,
      timestamp: Date.now(),
      verified: false
    };

    setPairs(prev => [...prev, newPair]);
    setSeedInput('');
    setKeyInput('');
    toast.success('Seed-key pair added');
  };

  const analyzePatterns = () => {
    if (pairs.length < 3) {
      toast.error('Need at least 3 seed-key pairs to analyze patterns');
      return;
    }

    setLearning(true);

    try {
      const pattern = detectAlgorithm(pairs);
      setLearnedPattern(pattern);
      toast.success(`Pattern detected with ${pattern.confidence}% confidence!`);
    } catch (error) {
      toast.error(`Pattern detection failed: ${error}`);
    } finally {
      setLearning(false);
    }
  };

  const detectAlgorithm = (pairs: SeedKeyPair[]): LearnedPattern => {
    const seedKeys = pairs.map(p => ({
      seed: parseInt(p.seed.replace(/[^0-9A-Fa-f]/g, ''), 16),
      key: parseInt(p.key.replace(/[^0-9A-Fa-f]/g, ''), 16)
    }));

    // Try simple multiply-add: key = (seed * M) + A
    const multiplyAddResult = tryMultiplyAdd(seedKeys);
    if (multiplyAddResult.confidence > 90) {
      return multiplyAddResult;
    }

    // Try XOR-multiply-add: key = ((seed ^ X) * M) + A
    const xorMultiplyAddResult = tryXORMultiplyAdd(seedKeys);
    if (xorMultiplyAddResult.confidence > 90) {
      return xorMultiplyAddResult;
    }

    // Try shift-XOR: key = shift_xor(seed, constant, iterations)
    const shiftXORResult = tryShiftXOR(seedKeys);
    if (shiftXORResult.confidence > 90) {
      return shiftXORResult;
    }

    // Return best result
    return [multiplyAddResult, xorMultiplyAddResult, shiftXORResult]
      .sort((a, b) => b.confidence - a.confidence)[0];
  };

  const tryMultiplyAdd = (pairs: Array<{ seed: number; key: number }>): LearnedPattern => {
    // Try to find M and A where key = (seed * M) + A
    let bestM = 0;
    let bestA = 0;
    let bestScore = 0;

    for (let m = 1; m < 256; m++) {
      for (let a = 0; a < 65536; a += 256) {
        let score = 0;
        pairs.forEach(({ seed, key }) => {
          const predicted = ((seed * m) + a) & 0xFFFFFFFF;
          if (predicted === key) score++;
        });
        if (score > bestScore) {
          bestScore = score;
          bestM = m;
          bestA = a;
        }
      }
    }

    const confidence = (bestScore / pairs.length) * 100;
    return {
      multiplier: bestM,
      addend: bestA,
      confidence,
      sampleSize: pairs.length,
      formula: `key = (seed * 0x${bestM.toString(16).toUpperCase()}) + 0x${bestA.toString(16).toUpperCase()}`
    };
  };

  const tryXORMultiplyAdd = (pairs: Array<{ seed: number; key: number }>): LearnedPattern => {
    // Try to find X, M, A where key = ((seed ^ X) * M) + A
    let bestX = 0;
    let bestM = 0;
    let bestA = 0;
    let bestScore = 0;

    for (let x = 0; x < 65536; x += 256) {
      for (let m = 1; m < 256; m++) {
        for (let a = 0; a < 65536; a += 256) {
          let score = 0;
          pairs.forEach(({ seed, key }) => {
            const predicted = (((seed ^ x) * m) + a) & 0xFFFFFFFF;
            if (predicted === key) score++;
          });
          if (score > bestScore) {
            bestScore = score;
            bestX = x;
            bestM = m;
            bestA = a;
          }
        }
      }
    }

    const confidence = (bestScore / pairs.length) * 100;
    return {
      xorMask: bestX,
      multiplier: bestM,
      addend: bestA,
      confidence,
      sampleSize: pairs.length,
      formula: `key = ((seed ^ 0x${bestX.toString(16).toUpperCase()}) * 0x${bestM.toString(16).toUpperCase()}) + 0x${bestA.toString(16).toUpperCase()}`
    };
  };

  const tryShiftXOR = (pairs: Array<{ seed: number; key: number }>): LearnedPattern => {
    // Try to find constant for shift-XOR algorithm
    let bestConstant = 0;
    let bestScore = 0;

    for (let constant = 0; constant < 0x1000000; constant += 0x1000) {
      let score = 0;
      pairs.forEach(({ seed, key }) => {
        let result = seed;
        for (let i = 0; i < 5; i++) {
          if (result & 0x80000000) {
            result = (result << 1) ^ constant;
          } else {
            result = result << 1;
          }
        }
        result = result & 0xFFFFFFFF;
        if (result === key) score++;
      });
      if (score > bestScore) {
        bestScore = score;
        bestConstant = constant;
      }
    }

    const confidence = (bestScore / pairs.length) * 100;
    return {
      constant: bestConstant,
      confidence,
      sampleSize: pairs.length,
      formula: `key = shift_xor(seed, 0x${bestConstant.toString(16).toUpperCase()}, 5)`
    };
  };

  const exportPattern = () => {
    if (!learnedPattern) return;
    
    const data = {
      pattern: learnedPattern,
      pairs,
      timestamp: Date.now()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `learned-pattern-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success('Pattern exported!');
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold mb-2">Seed-Key Learning Mode</h1>
        <p className="text-muted-foreground">
          Machine learning-based pattern recognition for unknown modules
        </p>
      </div>

      {/* Input Section */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader>
          <CardTitle>Add Seed-Key Pair</CardTitle>
          <CardDescription>
            Enter successful seed-key pairs from real diagnostic sessions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="seed">Seed (Hex)</Label>
              <Input
                id="seed"
                placeholder="48D01C4A"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
                className="font-mono"
              />
            </div>
            <div>
              <Label htmlFor="key">Key (Hex)</Label>
              <Input
                id="key"
                placeholder="1A10081F"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                className="font-mono"
              />
            </div>
            <div>
              <Label htmlFor="module">Module Code (Optional)</Label>
              <Input
                id="module"
                placeholder="BCM"
                value={moduleCode}
                onChange={(e) => setModuleCode(e.target.value)}
              />
            </div>
          </div>
          <Button onClick={addPair} className="w-full">Add Pair</Button>
        </CardContent>
      </Card>

      {/* Pairs List */}
      {pairs.length > 0 && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Captured Pairs ({pairs.length})</CardTitle>
            <CardDescription>
              {pairs.length < 3 && `Need ${3 - pairs.length} more pairs to analyze`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {pairs.map((pair, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded border border-border/30"
                >
                  <div className="font-mono text-sm">
                    <span className="text-muted-foreground">Seed:</span> {pair.seed}
                    <span className="mx-4 text-muted-foreground">→</span>
                    <span className="text-muted-foreground">Key:</span> {pair.key}
                  </div>
                  {pair.moduleCode && (
                    <Badge variant="outline">{pair.moduleCode}</Badge>
                  )}
                </div>
              ))}
            </div>
            
            {pairs.length >= 3 && (
              <Button onClick={analyzePatterns} disabled={learning} className="w-full">
                {learning ? 'Analyzing...' : 'Analyze Patterns'}
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Learned Pattern */}
      {learnedPattern && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Learned Pattern</CardTitle>
            <CardDescription>
              Detected algorithm with {learnedPattern.confidence.toFixed(1)}% confidence
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded-lg border-2 border-green-500/30 bg-green-500/10">
              <Label className="text-green-400 font-semibold">FORMULA</Label>
              <p className="text-xl font-mono mt-2">{learnedPattern.formula}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Confidence</Label>
                <p className="text-3xl font-bold">{learnedPattern.confidence.toFixed(1)}%</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Sample Size</Label>
                <p className="text-3xl font-bold">{learnedPattern.sampleSize}</p>
              </div>
            </div>

            {learnedPattern.confidence >= 90 && (
              <div className="p-4 rounded-lg border border-green-500/30 bg-green-500/5">
                <p className="text-green-400 font-semibold">✓ HIGH CONFIDENCE</p>
                <p className="text-sm text-muted-foreground mt-1">
                  This pattern is reliable and can be added to the algorithm database
                </p>
              </div>
            )}

            {learnedPattern.confidence < 90 && learnedPattern.confidence >= 70 && (
              <div className="p-4 rounded-lg border border-yellow-500/30 bg-yellow-500/5">
                <p className="text-yellow-400 font-semibold">⚠ MEDIUM CONFIDENCE</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Add more seed-key pairs to improve confidence
                </p>
              </div>
            )}

            {learnedPattern.confidence < 70 && (
              <div className="p-4 rounded-lg border border-red-500/30 bg-red-500/5">
                <p className="text-red-400 font-semibold">✗ LOW CONFIDENCE</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Pattern detection failed. This module may use a complex or unknown algorithm
                </p>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={exportPattern} className="flex-1">
                Export Pattern
              </Button>
              <Button variant="outline" className="flex-1">
                Add to Algorithm Database
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
