import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { BackButton } from "@/components/BackButton";
import { 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Trash2, 
  Clock, 
  Calendar,
  Search,
  Download
} from 'lucide-react';

interface UDSCommand {
  id: number;
  sessionId: string;
  timestamp: Date;
  direction: 'tx' | 'rx';
  data: string;
  description: string | null;
  duration: number | null;
  status: 'success' | 'error' | 'pending';
}

export default function SessionReplay() {
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');

  const { data: sessions, refetch: refetchSessions } = trpc.sessionReplay.getSessions.useQuery();
  const { data: sessionData } = trpc.sessionReplay.getSession.useQuery(
    { id: selectedSessionId! },
    { enabled: !!selectedSessionId }
  );

  const deleteSession = trpc.sessionReplay.deleteSession.useMutation({
    onSuccess: () => {
      refetchSessions();
      setSelectedSessionId(null);
    },
  });

  const filteredSessions = sessions?.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.vehicle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.module?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const commands = sessionData?.commands || [];

  const handlePlay = () => {
    if (playing) {
      setPlaying(false);
      return;
    }

    setPlaying(true);
    const interval = setInterval(() => {
      setCurrentIndex((prev) => {
        if (prev >= commands.length - 1) {
          setPlaying(false);
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 1000);
  };

  const handleStepForward = () => {
    setCurrentIndex((prev) => Math.min(prev + 1, commands.length - 1));
  };

  const handleStepBack = () => {
    setCurrentIndex((prev) => Math.max(prev - 1, 0));
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this session?')) {
      deleteSession.mutate({ id });
    }
  };

  const exportSession = () => {
    if (!sessionData) return;

    const content = [
      `Session: ${sessionData.session.name}`,
      `Vehicle: ${sessionData.session.vehicle || 'Unknown'}`,
      `Module: ${sessionData.session.module || 'Unknown'}`,
      `Start: ${new Date(sessionData.session.startTime).toLocaleString()}`,
      `End: ${sessionData.session.endTime ? new Date(sessionData.session.endTime).toLocaleString() : 'N/A'}`,
      '',
      'Commands:',
      ...commands.map((cmd, i) => 
        `[${i + 1}] ${new Date(cmd.timestamp).toLocaleTimeString()} ${cmd.direction.toUpperCase()}: ${cmd.data} ${cmd.description ? `(${cmd.description})` : ''}`
      ),
    ].join('\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `session_${sessionData.session.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Session Replay</h1>
          <p className="text-gray-600 mt-2">
            Review and analyze recorded diagnostic sessions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sessions List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Saved Sessions</CardTitle>
              <CardDescription>Select a session to replay</CardDescription>
              <div className="relative mt-2">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search sessions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[600px] overflow-y-auto">
              {filteredSessions?.map((session) => (
                <div
                  key={session.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedSessionId === session.id
                      ? 'bg-blue-50 border-blue-300'
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => {
                    setSelectedSessionId(session.id);
                    setCurrentIndex(0);
                    setPlaying(false);
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium text-sm">{session.name}</h3>
                      {session.vehicle && (
                        <p className="text-xs text-gray-600 mt-1">{session.vehicle}</p>
                      )}
                      {session.module && (
                        <Badge variant="outline" className="mt-1 text-xs">
                          {session.module}
                        </Badge>
                      )}
                      <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                        <Calendar className="h-3 w-3" />
                        {new Date(session.startTime).toLocaleDateString()}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(session.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}

              {filteredSessions?.length === 0 && (
                <p className="text-center text-gray-500 py-8">No sessions found</p>
              )}
            </CardContent>
          </Card>

          {/* Replay View */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>
                    {sessionData?.session.name || 'Select a session'}
                  </CardTitle>
                  <CardDescription>
                    {sessionData?.session.vehicle || 'No session selected'}
                  </CardDescription>
                </div>
                {sessionData && (
                  <Button variant="outline" size="sm" onClick={exportSession}>
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {sessionData && (
                <>
                  {/* Playback Controls */}
                  <div className="flex items-center justify-center gap-4 p-4 bg-gray-100 rounded-lg">
                    <Button variant="outline" size="sm" onClick={handleStepBack}>
                      <SkipBack className="h-4 w-4" />
                    </Button>
                    <Button onClick={handlePlay}>
                      {playing ? (
                        <Pause className="h-4 w-4 mr-2" />
                      ) : (
                        <Play className="h-4 w-4 mr-2" />
                      )}
                      {playing ? 'Pause' : 'Play'}
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleStepForward}>
                      <SkipForward className="h-4 w-4" />
                    </Button>
                    <div className="ml-4 text-sm text-gray-600">
                      {currentIndex + 1} / {commands.length}
                    </div>
                  </div>

                  {/* Timeline */}
                  <div className="relative">
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div
                        className="h-2 bg-blue-500 rounded-full transition-all"
                        style={{
                          width: `${((currentIndex + 1) / commands.length) * 100}%`,
                        }}
                      />
                    </div>
                    <input
                      type="range"
                      min="0"
                      max={commands.length - 1}
                      value={currentIndex}
                      onChange={(e) => setCurrentIndex(parseInt(e.target.value))}
                      className="absolute top-0 w-full h-2 opacity-0 cursor-pointer"
                    />
                  </div>

                  {/* Current Command */}
                  {commands[currentIndex] && (
                    <Card className="bg-gray-900 text-white">
                      <CardContent className="p-4 space-y-2">
                        <div className="flex items-center justify-between">
                          <Badge
                            variant={
                              commands[currentIndex].direction === 'tx'
                                ? 'default'
                                : 'secondary'
                            }
                          >
                            {commands[currentIndex].direction.toUpperCase()}
                          </Badge>
                          <div className="flex items-center gap-2 text-sm text-gray-400">
                            <Clock className="h-3 w-3" />
                            {new Date(commands[currentIndex].timestamp).toLocaleTimeString()}
                            {commands[currentIndex].duration && (
                              <span>({commands[currentIndex].duration}ms)</span>
                            )}
                          </div>
                        </div>
                        <div className="font-mono text-sm">
                          {commands[currentIndex].data}
                        </div>
                        {commands[currentIndex].description && (
                          <div className="text-sm text-gray-400">
                            {commands[currentIndex].description}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Command History */}
                  <div className="space-y-2 max-h-[400px] overflow-y-auto">
                    {commands.slice(0, currentIndex + 1).map((cmd, i) => (
                      <div
                        key={cmd.id}
                        className={`p-3 rounded-lg border ${
                          i === currentIndex
                            ? 'bg-blue-50 border-blue-300'
                            : 'bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <Badge
                              variant={cmd.direction === 'tx' ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {cmd.direction.toUpperCase()}
                            </Badge>
                            <span className="font-mono">{cmd.data}</span>
                          </div>
                          <span className="text-xs text-gray-500">
                            {new Date(cmd.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                        {cmd.description && (
                          <div className="text-xs text-gray-600 mt-1">
                            {cmd.description}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </>
              )}

              {!sessionData && (
                <div className="text-center py-12 text-gray-500">
                  Select a session from the list to begin replay
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
