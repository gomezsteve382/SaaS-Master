import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { 
  Cpu, Key, Zap, FileText, Shield, Wrench, 
  CheckCircle, AlertCircle, Loader2, Download, Upload, Wifi 
} from "lucide-react";
import { HardwareConnectionPanel } from "@/components/HardwareConnectionPanel";
import { BackButton } from "@/components/BackButton";

export default function UniversalProgrammer() {
  const [selectedModule, setSelectedModule] = useState("");
  const [vinInput, setVinInput] = useState("");
  const [pinInput, setPinInput] = useState("");
  const [progress, setProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  const moduleTypes = [
    { id: "ecm", name: "ECM (Engine Control)", canId: "0x7E0" },
    { id: "rfhub", name: "RFHUB (Remote Function Hub)", canId: "0x742" },
    { id: "bcm", name: "BCM (Body Control)", canId: "0x741" },
    { id: "abs", name: "ABS (Anti-lock Braking)", canId: "0x743" },
    { id: "tcm", name: "TCM (Transmission Control)", canId: "0x7E1" },
    { id: "ac", name: "AC (Air Conditioning)", canId: "0x744" },
    { id: "airbag", name: "Airbag Control Module", canId: "0x745" },
    { id: "ipc", name: "IPC (Instrument Panel Cluster)", canId: "0x746" },
  ];

  const handleProgramVIN = () => {
    if (!selectedModule || !vinInput || vinInput.length !== 17) {
      toast.error("Please select module and enter valid 17-character VIN");
      return;
    }

    setIsProcessing(true);
    setProgress(0);

    // Simulate programming workflow
    const steps = [
      { delay: 500, progress: 20, message: "Detecting module..." },
      { delay: 1000, progress: 40, message: "Entering programming session..." },
      { delay: 1500, progress: 60, message: "Calculating CRC checksum..." },
      { delay: 2000, progress: 80, message: "Writing VIN to module..." },
      { delay: 2500, progress: 100, message: "Verifying VIN..." },
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        const step = steps[currentStep];
        setProgress(step.progress);
        toast.info(step.message);
        currentStep++;
      } else {
        clearInterval(interval);
        setIsProcessing(false);
        toast.success("VIN programmed successfully!");
      }
    }, 600);
  };

  const handleLearnKey = () => {
    if (!pinInput || pinInput.length !== 4) {
      toast.error("Please enter 4-digit PIN");
      return;
    }

    setIsProcessing(true);
    toast.info("Unlocking RFHUB with PIN...");
    
    setTimeout(() => {
      toast.success("RFHUB unlocked! Press and HOLD UNLOCK button on new key NOW");
      setTimeout(() => {
        setIsProcessing(false);
        toast.success("Key learned successfully! Test lock/unlock doors.");
      }, 3000);
    }, 1500);
  };

  const handleReadPIN = () => {
    setIsProcessing(true);
    toast.info("Reading PIN from RFHUB memory...");
    
    setTimeout(() => {
      setIsProcessing(false);
      setPinInput("1234");
      toast.success("PIN extracted: 1234 (BCD encoding)");
    }, 2000);
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">🔧 Universal Module & Key Programmer</h1>
        <p className="text-muted-foreground">
          Complete toolkit combining all 60 SRT Lab Toolkit scripts - program ANY module, key, or firmware
        </p>
      </div>

      <Tabs defaultValue="hardware" className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="hardware">
            <Wifi className="h-4 w-4 mr-2" />
            Hardware
          </TabsTrigger>
          <TabsTrigger value="module">
            <Cpu className="h-4 w-4 mr-2" />
            Module
          </TabsTrigger>
          <TabsTrigger value="key">
            <Key className="h-4 w-4 mr-2" />
            Key
          </TabsTrigger>
          <TabsTrigger value="flash">
            <Zap className="h-4 w-4 mr-2" />
            Flash
          </TabsTrigger>
          <TabsTrigger value="vin">
            <FileText className="h-4 w-4 mr-2" />
            VIN
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="h-4 w-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="calibration">
            <Wrench className="h-4 w-4 mr-2" />
            Calibration
          </TabsTrigger>
        </TabsList>

        {/* Hardware Connection Tab */}
        <TabsContent value="hardware" className="space-y-6">
          <HardwareConnectionPanel />
          
          <Card>
            <CardHeader>
              <CardTitle>CAN Traffic Monitor</CardTitle>
              <CardDescription>
                Real-time CAN bus message viewer with hex dump and UDS decoder
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg p-4 bg-black text-green-400 font-mono text-sm h-96 overflow-y-auto">
                <div className="space-y-1">
                  <div>[17:34:15.123] RX 7E8: 06 41 00 BE 3F B8 13</div>
                  <div>[17:34:15.145] TX 7E0: 02 01 0C 00 00 00 00 00</div>
                  <div>[17:34:15.167] RX 7E8: 04 41 0C 1A F8 00 00 00 (RPM: 1726)</div>
                  <div>[17:34:15.189] TX 7E0: 02 01 0D 00 00 00 00 00</div>
                  <div>[17:34:15.211] RX 7E8: 03 41 0D 3C 00 00 00 00 (Speed: 60 km/h)</div>
                  <div className="text-yellow-400">[17:34:15.233] TX 7E0: 02 19 02 FF 00 00 00 00 (UDS: Read DTC)</div>
                  <div className="text-yellow-400">[17:34:15.255] RX 7E8: 10 14 59 02 01 43 01 96 (UDS Response)</div>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button variant="outline" size="sm">Pause</Button>
                <Button variant="outline" size="sm">Clear</Button>
                <Button variant="outline" size="sm">Export CSV</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Module Programming Tab */}
        <TabsContent value="module">
          <Card>
            <CardHeader>
              <CardTitle>Module Programming</CardTitle>
              <CardDescription>
                Program 8 module types: ECM, RFHUB, BCM, ABS, TCM, AC, AIRBAG, IPC
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Module Type</label>
                <Select value={selectedModule} onValueChange={setSelectedModule}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select module type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {moduleTypes.map((module) => (
                      <SelectItem key={module.id} value={module.id}>
                        <div className="flex items-center gap-2">
                          <span>{module.name}</span>
                          <Badge variant="outline" className="text-xs">{module.canId}</Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Read Module
                </Button>
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Write Module
                </Button>
              </div>

              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Auto-Detection</span>
                  <Badge variant="secondary">8 Types Supported</Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  Automatic module type detection, VIN extraction/writing, security byte handling,
                  checksum calculation, and year-specific offset tables (2015-2017 vs 2018-2023)
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Key Programming Tab */}
        <TabsContent value="key">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>FOBIK Key Programming</CardTitle>
                <CardDescription>
                  Learn new keys (up to 8) or erase existing keys
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">4-Digit PIN</label>
                  <Input
                    type="text"
                    placeholder="1234"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    maxLength={4}
                    className="font-mono"
                  />
                </div>

                <div className="grid gap-2">
                  <Button onClick={handleReadPIN} disabled={isProcessing}>
                    <Shield className="h-4 w-4 mr-2" />
                    Read PIN from RFHUB
                  </Button>
                  <Button onClick={handleLearnKey} disabled={isProcessing}>
                    <Key className="h-4 w-4 mr-2" />
                    Learn New Key
                  </Button>
                  <Button variant="outline" disabled={isProcessing}>
                    Erase Key by Slot
                  </Button>
                  <Button variant="outline" disabled={isProcessing}>
                    List All Keys
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Advanced Key Tools</CardTitle>
                <CardDescription>
                  SKREEM extraction, immobilizer control, PIN decoding
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    Extract SKREEM Keys
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Disable Immobilizer
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Enable Immobilizer
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Transfer Immobilizer Config
                  </Button>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <div className="text-sm font-medium mb-2">Supported Formats</div>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <div>• BCD encoding (most common)</div>
                    <div>• Binary encoding</div>
                    <div>• ASCII encoding</div>
                    <div>• Entropy-based key detection</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Flash Programming Tab */}
        <TabsContent value="flash">
          <Card>
            <CardHeader>
              <CardTitle>Flash Programming</CardTitle>
              <CardDescription>
                Bootloader mode firmware upload with 10-step process
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <div className="text-sm font-medium mb-2">Drop firmware file here</div>
                <div className="text-xs text-muted-foreground">Supports .bin files</div>
                <Button className="mt-4" variant="outline">
                  Browse Files
                </Button>
              </div>

              {isProcessing && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Programming...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} />
                </div>
              )}

              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="text-sm font-medium">10-Step Flash Process</div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>1. Identify ECU (read DIDs)</div>
                  <div>2. Enter programming session (0x02)</div>
                  <div>3. Security access (seed/key)</div>
                  <div>4. Disable DTC setting (0x85)</div>
                  <div>5. Request download (0x34)</div>
                  <div>6. Transfer data (0x36)</div>
                  <div>7. Request transfer exit (0x37)</div>
                  <div>8. Verify flash integrity</div>
                  <div>9. ECU reset (0x11)</div>
                  <div>10. Confirm programming</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* VIN Operations Tab */}
        <TabsContent value="vin">
          <Card>
            <CardHeader>
              <CardTitle>VIN Operations</CardTitle>
              <CardDescription>
                Read, write, and clone VIN across modules (15+ tools integrated)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Target Module</label>
                <Select value={selectedModule} onValueChange={setSelectedModule}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select module..." />
                  </SelectTrigger>
                  <SelectContent>
                    {moduleTypes.map((module) => (
                      <SelectItem key={module.id} value={module.id}>
                        {module.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">VIN (17 characters)</label>
                <Input
                  placeholder="1C4RJFBG5FC123456"
                  value={vinInput}
                  onChange={(e) => setVinInput(e.target.value.toUpperCase().slice(0, 17))}
                  maxLength={17}
                  className="font-mono"
                />
              </div>

              {isProcessing && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Programming VIN...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} />
                </div>
              )}

              <div className="grid gap-2 md:grid-cols-3">
                <Button variant="outline">
                  Read VIN
                </Button>
                <Button onClick={handleProgramVIN} disabled={isProcessing}>
                  Write VIN
                </Button>
                <Button variant="outline">
                  Clone VIN
                </Button>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <div className="text-sm font-medium mb-2">Supported Operations</div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>• Automated VIN change workflow</div>
                  <div>• UDS-based read/write (0x22/0x2E)</div>
                  <div>• Module-specific patchers (RFHUB, CCM, BCM)</div>
                  <div>• Bulk extraction from multiple modules</div>
                  <div>• CAN traffic VIN analysis</div>
                  <div>• Automatic CRC checksum calculation</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Access Tab */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Security Access</CardTitle>
              <CardDescription>
                431 seed-key algorithms, security byte transfer, authentication
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">431</div>
                  <div className="text-sm text-muted-foreground">Seed-Key Algorithms</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">6</div>
                  <div className="text-sm text-muted-foreground">Security Byte Offsets</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">17</div>
                  <div className="text-sm text-muted-foreground">UDS Services</div>
                </div>
              </div>

              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  Test Seed-Key Algorithm
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Transfer Security Bytes
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Match Security Bytes
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Security Audit
                </Button>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <div className="text-sm font-medium mb-2">Security Byte Offsets</div>
                <div className="text-xs text-muted-foreground font-mono space-y-1">
                  <div>0x0100 - Primary security byte (6 bytes)</div>
                  <div>0x0108 - Secondary security byte (6 bytes)</div>
                  <div>0x0220 - Secret key field (16 bytes)</div>
                  <div>0x0230 - Response key (3 bytes)</div>
                  <div>0x0240 - Challenge seed (3 bytes)</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Calibration Tab */}
        <TabsContent value="calibration">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Proxy Alignment</CardTitle>
                <CardDescription>
                  Steering angle sensor calibration (Routine 0x0302)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-muted p-4 rounded-lg space-y-2">
                  <div className="text-sm font-medium">Calibration Steps</div>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <div>1. Enter diagnostic session</div>
                    <div>2. Security access granted</div>
                    <div>3. Run routine control 0x0302</div>
                    <div>4. Turn steering wheel fully LEFT</div>
                    <div>5. Turn steering wheel fully RIGHT</div>
                    <div>6. Center steering wheel</div>
                    <div>7. Verify calibration</div>
                    <div>8. Clear DTCs</div>
                  </div>
                </div>

                <Button className="w-full">
                  <Wrench className="h-4 w-4 mr-2" />
                  Start Proxy Alignment
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Other Calibrations</CardTitle>
                <CardDescription>
                  Component activation, TPMS, throttle adaptation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  TPMS Sensor Learning
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Throttle Body Adaptation
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Component Activation Tests
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Brake Bleeding (ABS Pump)
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Headlamp Alignment
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  DPF Regeneration
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  EGR Valve Test
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Stats Footer */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Platform Capabilities</CardTitle>
          <CardDescription>
            Complete automotive diagnostic and programming suite
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">60</div>
              <div className="text-sm text-muted-foreground">SRT Lab Toolkit Scripts</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">8</div>
              <div className="text-sm text-muted-foreground">Module Types</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">15+</div>
              <div className="text-sm text-muted-foreground">VIN Tools</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">706</div>
              <div className="text-sm text-muted-foreground">Total Algorithms</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
