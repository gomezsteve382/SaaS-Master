import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { trpc } from '@/lib/trpc';
import { History, Search, CheckCircle2, XCircle, Clock, FileText } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";

export default function ProcedureHistory() {
  const [searchVIN, setSearchVIN] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'service_reset' | 'calibration' | 'special_function'>('all');
  
  const { data: history, isLoading } = trpc.procedureExecution.getHistory.useQuery({
    vin: searchVIN || undefined,
    procedureType: filterType === 'all' ? undefined : filterType,
    limit: 100,
  });

  const successCount = history?.filter(h => h.success).length || 0;
  const failureCount = history?.filter(h => !h.success).length || 0;

  const exportToCSV = () => {
    if (!history) return;
    
    const csv = [
      ['Timestamp', 'Procedure Type', 'Procedure Name', 'VIN', 'Module', 'Success', 'Execution Time (ms)', 'Error'],
      ...history.map(h => [
        h.createdAt?.toISOString() || '',
        h.procedureType,
        h.procedureName || '',
        h.vin || '',
        h.moduleCode || '',
        h.success ? 'Yes' : 'No',
        h.executionTime?.toString() || '',
        h.errorMessage || '',
      ])
    ].map(row => row.join(',')).join('\\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `procedure-history-${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
          <History className="h-10 w-10 text-blue-600" />
          Procedure Execution History
        </h1>
        <p className="text-muted-foreground mt-2">
          Track all service resets, calibrations, and special functions executed on vehicles
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Executions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{history?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Successful</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{successCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Failed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{failureCount}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Filter by VIN..."
            value={searchVIN}
            onChange={(e) => setSearchVIN(e.target.value)}
            className="pl-10"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value as any)}
          className="px-4 py-2 border rounded-md"
        >
          <option value="all">All Types</option>
          <option value="service_reset">Service Resets</option>
          <option value="calibration">Calibrations</option>
          <option value="special_function">Special Functions</option>
        </select>
        <Button onClick={exportToCSV} variant="outline">
          <FileText className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* History List */}
      {isLoading ? (
        <div className="text-center py-12">
          <History className="h-12 w-12 animate-pulse text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Loading history...</p>
        </div>
      ) : history && history.length > 0 ? (
        <div className="space-y-3">
          {history.map((record: any) => (
            <Card key={record.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {record.success ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                      <CardTitle className="text-lg">
                        {record.procedureName || `Procedure #${record.procedureId}`}
                      </CardTitle>
                      <Badge variant={record.success ? "default" : "destructive"}>
                        {record.success ? 'Success' : 'Failed'}
                      </Badge>
                      <Badge variant="outline">{record.procedureType.replace('_', ' ')}</Badge>
                    </div>
                    <CardDescription className="space-y-1">
                      {record.vin && <div><strong>VIN:</strong> {record.vin}</div>}
                      {record.moduleCode && <div><strong>Module:</strong> {record.moduleCode}</div>}
                      <div className="flex items-center gap-4 text-xs">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {record.createdAt ? new Date(record.createdAt).toLocaleString() : 'N/A'}
                        </span>
                        {record.executionTime && (
                          <span>Execution time: {record.executionTime}ms</span>
                        )}
                      </div>
                      {!record.success && record.errorMessage && (
                        <Alert className="mt-2 bg-red-50 border-red-200">
                          <AlertDescription className="text-red-900 text-sm">
                            <strong>Error:</strong> {record.errorMessage}
                          </AlertDescription>
                        </Alert>
                      )}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No procedure executions recorded yet. Execute procedures from Service Resets or Calibration pages.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
