import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { BackButton } from "@/components/BackButton";
import { History, Download, Search, Calendar, Car, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function VINHistoryTracker() {
  const [searchVIN, setSearchVIN] = useState("");
  const [filterModule, setFilterModule] = useState<string>("all");

  // Fetch real audit logs for VIN operations
  const { data: auditLogs, isLoading } = trpc.audit.list.useQuery({ limit: 500 });

  // Filter audit logs for VIN-related operations
  const vinAuditLogs = auditLogs?.filter(log => 
    log.operation.toLowerCase().includes("vin") || 
    log.operation === "WRITE_VIN" ||
    log.operation === "READ_VIN" ||
    log.operation === "VIN_PATCH" ||
    log.operation === "BATCH_VIN_PROGRAM"
  );

  const filteredLogs = vinAuditLogs?.filter(log => {
    const vinMatch = !searchVIN || log.vin?.includes(searchVIN.toUpperCase());
    const moduleMatch = filterModule === "all" || log.moduleCode === filterModule;
    return vinMatch && moduleMatch;
  });

  const handleExportHistory = () => {
    if (!filteredLogs || filteredLogs.length === 0) {
      toast.error("No history to export");
      return;
    }

    const csv = [
      "Timestamp,Operation,Module,Old VIN,New VIN,Risk Level,Status,Error",
      ...filteredLogs.map(log => {
        const details = log.details ? JSON.parse(log.details) : {};
        const oldVIN = details.oldVIN || "N/A";
        const newVIN = details.newVIN || log.vin || "N/A";
        return `${log.createdAt.toISOString()},${log.operation},${log.moduleCode || "N/A"},${oldVIN},${newVIN},${log.riskLevel || "N/A"},${log.success ? "SUCCESS" : "FAILED"},${log.errorMessage || ""}`;
      })
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vin-history-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("VIN history exported");
  };

  const getOperationBadge = (operation: string) => {
    if (operation.includes("WRITE") || operation.includes("PATCH")) {
      return "bg-red-600 text-white";
    } else if (operation.includes("READ")) {
      return "bg-blue-600 text-white";
    } else if (operation.includes("BATCH")) {
      return "bg-purple-600 text-white";
    }
    return "bg-gray-600 text-white";
  };

  const getRiskBadge = (riskLevel?: string | null) => {
    if (riskLevel === "danger") return "bg-red-600 text-white";
    if (riskLevel === "caution") return "bg-yellow-600 text-white";
    if (riskLevel === "safe") return "bg-green-600 text-white";
    return "bg-gray-600 text-white";
  };

  // Calculate statistics
  const stats = {
    totalChanges: filteredLogs?.length || 0,
    successRate: filteredLogs ? 
      Math.round((filteredLogs.filter((l: any) => l.success).length / filteredLogs.length) * 100) : 0,
    uniqueVINs: new Set(filteredLogs?.map((l: any) => l.vin).filter(Boolean)).size,
    modulesModified: new Set(filteredLogs?.map((l: any) => l.moduleCode).filter(Boolean)).size
  };

  // Get unique modules from logs
  const uniqueModules = Array.from(new Set(vinAuditLogs?.map((l: any) => l.moduleCode).filter(Boolean) || [])) as string[];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-600 rounded-lg">
              <History className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight">VIN HISTORY TRACKER</h1>
              <p className="text-gray-600">Complete audit trail for all VIN modifications</p>
            </div>
          </div>
          <Button onClick={handleExportHistory} className="gap-2">
            <Download className="h-4 w-4" />
            Export History
          </Button>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Total Changes</CardDescription>
              <CardTitle className="text-3xl font-black">{stats.totalChanges}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Success Rate</CardDescription>
              <CardTitle className="text-3xl font-black text-green-600">{stats.successRate}%</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Unique VINs</CardDescription>
              <CardTitle className="text-3xl font-black">{stats.uniqueVINs}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Modules Modified</CardDescription>
              <CardTitle className="text-3xl font-black">{stats.modulesModified}</CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Search & Filter</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Search by VIN</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Enter VIN..."
                    value={searchVIN}
                    onChange={(e) => setSearchVIN(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Filter by Module</Label>
                <select
                  value={filterModule}
                  onChange={(e) => setFilterModule(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-gray-300"
                >
                  <option value="all">All Modules</option>
                  {uniqueModules.map((module: string) => (
                    <option key={module} value={module}>{module}</option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* History Timeline */}
        <Card>
          <CardHeader>
            <CardTitle>VIN Modification History</CardTitle>
            <CardDescription>
              Chronological log of all VIN read/write operations with before/after values
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-gray-500">Loading history...</div>
            ) : filteredLogs && filteredLogs.length > 0 ? (
              <div className="space-y-4">
                {filteredLogs.map((log: any) => {
                  const details = log.details ? JSON.parse(log.details) : {};
                  const oldVIN = details.oldVIN;
                  const newVIN = details.newVIN || log.vin;
                  
                  return (
                    <div key={log.id} className="border-l-4 border-red-600 pl-4 py-3 bg-gray-50 rounded-r">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center gap-3">
                            <Badge className={getOperationBadge(log.operation)}>
                              {log.operation.replace(/_/g, " ")}
                            </Badge>
                            {log.success ? (
                              <CheckCircle2 className="h-4 w-4 text-green-600" />
                            ) : (
                              <AlertCircle className="h-4 w-4 text-red-600" />
                            )}
                            {log.riskLevel && (
                              <Badge className={getRiskBadge(log.riskLevel)}>
                                {log.riskLevel.toUpperCase()}
                              </Badge>
                            )}
                            {log.moduleCode && (
                              <Badge variant="outline">{log.moduleCode}</Badge>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            {oldVIN && (
                              <div className="flex items-center gap-2">
                                <span className="text-gray-600">Old VIN:</span>
                                <span className="font-mono font-bold text-red-600">{oldVIN}</span>
                              </div>
                            )}
                            {newVIN && (
                              <div className="flex items-center gap-2">
                                <span className="text-gray-600">New VIN:</span>
                                <span className="font-mono font-bold text-green-600">{newVIN}</span>
                              </div>
                            )}
                            <div className="flex items-center gap-2 text-gray-500">
                              <Calendar className="h-4 w-4" />
                              {log.createdAt.toLocaleString()}
                            </div>
                          </div>

                          {details.notes && (
                            <div className="text-sm text-gray-600 italic">
                              Note: {details.notes}
                            </div>
                          )}

                          {!log.success && log.errorMessage && (
                            <div className="text-sm text-red-600 font-medium">
                              Error: {log.errorMessage}
                            </div>
                          )}

                          {details.checksum && (
                            <div className="text-xs text-gray-500">
                              Checksum: {details.checksum}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <History className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No VIN modification history found</p>
                <p className="text-sm mt-2">Start programming VINs to build your audit trail</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
