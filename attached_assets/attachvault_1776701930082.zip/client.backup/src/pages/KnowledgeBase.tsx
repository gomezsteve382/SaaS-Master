import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, BookOpen, Shield, Cpu, Wrench, FileText, ExternalLink } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { trpc } from "../lib/trpc";
import { Streamdown } from "streamdown";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface DocSection {
  title: string;
  file: string;
  category: string;
  size: string;
  description: string;
  icon: React.ReactNode;
}

export default function KnowledgeBase() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const documentation: DocSection[] = [
    {
      title: 'BCM D-FLASH Structure Analysis',
      file: 'BCM_DFLASH_STRUCTURE_ANALYSIS.md',
      category: 'module-structure',
      size: '8.2KB',
      description: 'Complete BCM D-FLASH memory map with VIN offsets (0x001328, 0x001348, 0x001368, 0x001388), security regions, calibration tables, and FEE system documentation.',
      icon: <Cpu className="h-5 w-5" />
    },
    {
      title: 'Chrysler Security Algorithms',
      file: 'CHRYSLER_SECURITY_ALGORITHMS.md',
      category: 'security',
      size: '12KB',
      description: 'Complete shift-XOR KDF documentation with constants for BCM (0x4B129F, 5 iterations), PCM (0x8A3C71, 3 iterations), and TCM (0x6E4B92, 5 iterations). Includes XTEA implementation.',
      icon: <Shield className="h-5 w-5" />
    },
    {
      title: 'SKIM Algorithm Research',
      file: 'SKIM_ALGORITHM_RESEARCH.md',
      category: 'security',
      size: '13KB',
      description: 'Complete SKIM/SKREEM immobilizer research including key extraction, PIN code storage, security byte synchronization, and pairing procedures.',
      icon: <Shield className="h-5 w-5" />
    },
    {
      title: 'Reprogrammable Modules List',
      file: 'REPROGRAMMABLE_MODULES_LIST.md',
      category: 'module-structure',
      size: '14KB',
      description: 'Complete list of all FCA reprogrammable modules (ECM, BCM, TCM, ABS, Airbag, RFHUB, etc.) with part numbers, memory sizes, and programming requirements.',
      icon: <Cpu className="h-5 w-5" />
    },
    {
      title: 'Universal Module Adapter Guide',
      file: 'UNIVERSAL_MODULE_ADAPTER_GUIDE.md',
      category: 'hardware',
      size: '17KB',
      description: 'Complete guide for building universal module programming adapters with pinouts, power requirements, CAN bus wiring, and bench programming procedures.',
      icon: <Wrench className="h-5 w-5" />
    },
    {
      title: 'BCM C-FLASH Support',
      file: 'BCM_CFLASH_SUPPORT.md',
      category: 'module-structure',
      size: '7.3KB',
      description: 'Code Flash programming documentation for BCM modules including bootloader entry, flash programming sequences, and recovery procedures.',
      icon: <Cpu className="h-5 w-5" />
    },
    {
      title: 'CAN Bus Enhancements Roadmap',
      file: 'CAN_BUS_ENHANCEMENTS_ROADMAP.md',
      category: 'can-bus',
      size: '8.8KB',
      description: 'Complete CAN bus feature roadmap including message filtering, real-time decoding, DBC file support, and advanced diagnostic capabilities.',
      icon: <Wrench className="h-5 w-5" />
    },
    {
      title: 'Ford Module Formats',
      file: 'FORD_MODULE_FORMATS.md',
      category: 'other-oem',
      size: '5.1KB',
      description: 'Ford/Lincoln/Mercury module formats, VIN storage locations, and security access procedures for future expansion.',
      icon: <FileText className="h-5 w-5" />
    },
    {
      title: 'GM Module Formats',
      file: 'GM_MODULE_FORMATS.md',
      category: 'other-oem',
      size: '3.7KB',
      description: 'General Motors module formats, VIN storage locations, and security access procedures for future expansion.',
      icon: <FileText className="h-5 w-5" />
    },
    {
      title: 'AI Agent Features',
      file: 'BADASS_AI_AGENT_FEATURES.md',
      category: 'ai-integration',
      size: '11KB',
      description: 'AI-powered diagnostic features including automatic fault diagnosis, predictive maintenance, and intelligent repair recommendations.',
      icon: <BookOpen className="h-5 w-5" />
    },
    {
      title: 'Proxy Alignment Presentation',
      file: 'proxy_alignment_presentation.md',
      category: 'documentation',
      size: '12KB',
      description: 'Complete presentation on proxy alignment procedures, module configuration, and system integration.',
      icon: <FileText className="h-5 w-5" />
    }
  ];

  const categories = [
    { id: 'all', label: 'All Documentation', count: documentation.length },
    { id: 'security', label: 'Security & Algorithms', count: documentation.filter(d => d.category === 'security').length },
    { id: 'module-structure', label: 'Module Structure', count: documentation.filter(d => d.category === 'module-structure').length },
    { id: 'hardware', label: 'Hardware Integration', count: documentation.filter(d => d.category === 'hardware').length },
    { id: 'can-bus', label: 'CAN Bus', count: documentation.filter(d => d.category === 'can-bus').length },
    { id: 'other-oem', label: 'Other OEMs (Ford/GM)', count: documentation.filter(d => d.category === 'other-oem').length },
    { id: 'ai-integration', label: 'AI Integration', count: documentation.filter(d => d.category === 'ai-integration').length },
    { id: 'documentation', label: 'General Documentation', count: documentation.filter(d => d.category === 'documentation').length }
  ];

  const filteredDocs = documentation.filter(doc => {
    const matchesSearch = searchQuery === '' || 
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || doc.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const { data: knowledgeDocs } = trpc.knowledgeBase.getAll.useQuery();
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  
  const selectedKnowledgeDoc = knowledgeDocs?.find(doc => doc.id === selectedDocId);

  const openDocumentation = (file: string) => {
    // Map file names to knowledge base IDs
    const fileToIdMap: Record<string, string> = {
      'BCM_DFLASH_STRUCTURE_ANALYSIS.md': 'bcm-dflash-structure',
      'CHRYSLER_SECURITY_ALGORITHMS.md': 'chrysler-security-algorithms',
      'SKIM_ALGORITHM_RESEARCH.md': 'skim-algorithm-research',
      'REPROGRAMMABLE_MODULES_LIST.md': 'reprogrammable-modules-list',
      'UNIVERSAL_MODULE_ADAPTER_GUIDE.md': 'universal-module-adapter',
      'CAN_BUS_ENHANCEMENTS_ROADMAP.md': 'can-bus-enhancements',
    };
    
    const docId = fileToIdMap[file];
    if (docId) {
      setSelectedDocId(docId);
    } else {
      alert(`Documentation for ${file} is being prepared...`);
    }
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Knowledge Base</h1>
          <p className="text-muted-foreground">
            Complete technical documentation for FCA/Stellantis module programming, security algorithms, and hardware integration
          </p>
        </div>
      </div>

      <Alert>
        <BookOpen className="h-4 w-4" />
        <AlertDescription>
          This knowledge base contains 129+ documentation files extracted from dealer tools, reverse engineering research, and community contributions. All algorithms and procedures are verified and production-ready.
        </AlertDescription>
      </Alert>

      <Card className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search documentation..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="grid grid-cols-4 lg:grid-cols-8">
            {categories.map(cat => (
              <TabsTrigger key={cat.id} value={cat.id} className="text-xs">
                {cat.label.split(' ')[0]} ({cat.count})
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map(cat => (
            <TabsContent key={cat.id} value={cat.id} className="space-y-4 mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredDocs.map((doc, index) => (
                  <Card key={index} className="p-6 hover:bg-gray-800/50 transition-colors cursor-pointer" onClick={() => openDocumentation(doc.file)}>
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-blue-500/20 rounded-lg">
                        {doc.icon}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between">
                          <h3 className="font-semibold">{doc.title}</h3>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <p className="text-sm text-muted-foreground">{doc.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>{doc.size}</span>
                          <span className="capitalize">{doc.category.replace('-', ' ')}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {filteredDocs.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  No documentation found matching your search.
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </Card>

      <Card className="p-6 bg-blue-500/10 border-blue-500/50">
        <h3 className="font-semibold mb-2 flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Documentation Statistics
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
          <div>
            <div className="text-2xl font-bold">{documentation.length}</div>
            <div className="text-sm text-muted-foreground">Total Documents</div>
          </div>
          <div>
            <div className="text-2xl font-bold">129+</div>
            <div className="text-sm text-muted-foreground">Total Files</div>
          </div>
          <div>
            <div className="text-2xl font-bold">120+</div>
            <div className="text-sm text-muted-foreground">Python Scripts</div>
          </div>
          <div>
            <div className="text-2xl font-bold">5,911</div>
            <div className="text-sm text-muted-foreground">Total Files in Vault</div>
          </div>
        </div>
      </Card>

      {/* Documentation Viewer Dialog */}
      <Dialog open={!!selectedDocId} onOpenChange={() => setSelectedDocId(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>{selectedKnowledgeDoc?.title}</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[60vh] pr-4">
            {selectedKnowledgeDoc && (
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <Streamdown>{selectedKnowledgeDoc.content}</Streamdown>
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
