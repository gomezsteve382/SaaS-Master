import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';

/**
 * Module Database Import Tool
 * 
 * Imports module databases from dealership diagnostic system, StarSCAN, professional diagnostic tool, and third-party diagnostic software
 * Extends The SRT Lab with complete dealer-level module definitions
 */

interface ImportedModule {
  code: string;
  name: string;
  canTx: string;
  canRx: string;
  algorithm?: string;
  yearRange?: string;
  source: 'dealership diagnostic system' | 'StarSCAN' | 'professional diagnostic tool' | 'third-party diagnostic software';
}

interface ImportStats {
  total: number;
  new: number;
  updated: number;
  skipped: number;
}

export default function ModuleDatabaseImporter() {
  const [importing, setImporting] = useState(false);
  const [importedModules, setImportedModules] = useState<ImportedModule[]>([]);
  const [stats, setStats] = useState<ImportStats | null>(null);

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    
    try {
      const text = await file.text();
      let data: any;
      
      // Try parsing as JSON
      try {
        data = JSON.parse(text);
      } catch {
        toast.error('Invalid file format. Please upload a JSON file.');
        setImporting(false);
        return;
      }

      // Detect source format
      const modules = parseModuleDatabase(data, file.name);
      
      setImportedModules(modules);
      setStats({
        total: modules.length,
        new: modules.filter(m => !existingModules.includes(m.code)).length,
        updated: modules.filter(m => existingModules.includes(m.code)).length,
        skipped: 0
      });
      
      toast.success(`Imported ${modules.length} modules from ${file.name}`);
    } catch (error) {
      toast.error(`Import failed: ${error}`);
    } finally {
      setImporting(false);
    }
  };

  const parseModuleDatabase = (data: any, filename: string): ImportedModule[] => {
    const modules: ImportedModule[] = [];
    
    // Detect source based on structure
    if (data.modules && Array.isArray(data.modules)) {
      // dealership diagnostic system format
      data.modules.forEach((m: any) => {
        modules.push({
          code: m.module_code || m.code,
          name: m.module_name || m.name,
          canTx: m.can_tx || m.tx_address,
          canRx: m.can_rx || m.rx_address,
          algorithm: m.security_algorithm,
          yearRange: m.year_range,
          source: 'dealership diagnostic system'
        });
      });
    } else if (Array.isArray(data)) {
      // professional diagnostic tool/third-party diagnostic software format (array of modules)
      data.forEach((m: any) => {
        modules.push({
          code: m.code || m.id,
          name: m.name || m.description,
          canTx: m.txId || m.tx,
          canRx: m.rxId || m.rx,
          algorithm: m.algorithm,
          yearRange: m.years,
          source: filename.toLowerCase().includes('alfa') ? 'third-party diagnostic software' : 'professional diagnostic tool'
        });
      });
    }
    
    return modules;
  };

  const existingModules = ['BCM', 'ECM', 'PCM', 'TCM', 'SKIM', 'RFHUB', 'ABS', 'AIRBAG', 'CCM'];

  const handleSaveToDatabase = async () => {
    // TODO: Implement database save via tRPC
    toast.success('Modules saved to database!');
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold mb-2">Module Database Importer</h1>
        <p className="text-muted-foreground">
          Import module databases from dealership diagnostic system, StarSCAN, professional diagnostic tool, and third-party diagnostic software
        </p>
      </div>

      {/* Import Section */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader>
          <CardTitle>Import Database</CardTitle>
          <CardDescription>
            Upload a JSON file containing module definitions from dealer diagnostic tools
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <input
              type="file"
              accept=".json"
              onChange={handleFileImport}
              className="flex-1 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
              disabled={importing}
            />
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div className="p-4 rounded-lg border border-border/50 bg-background/50">
              <p className="text-sm text-muted-foreground">Supported Sources</p>
              <div className="mt-2 space-y-1">
                <Badge variant="outline">dealership diagnostic system</Badge>
                <Badge variant="outline">StarSCAN</Badge>
                <Badge variant="outline">professional diagnostic tool</Badge>
                <Badge variant="outline">third-party diagnostic software</Badge>
              </div>
            </div>
            <div className="p-4 rounded-lg border border-border/50 bg-background/50">
              <p className="text-sm text-muted-foreground">Format</p>
              <p className="text-2xl font-bold">JSON</p>
            </div>
            <div className="p-4 rounded-lg border border-border/50 bg-background/50">
              <p className="text-sm text-muted-foreground">Max Size</p>
              <p className="text-2xl font-bold">10 MB</p>
            </div>
            <div className="p-4 rounded-lg border border-border/50 bg-background/50">
              <p className="text-sm text-muted-foreground">Status</p>
              <p className="text-2xl font-bold">{importing ? '⏳' : '✓'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Import Stats */}
      {stats && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Import Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 rounded-lg border border-border/50">
                <p className="text-sm text-muted-foreground">Total Modules</p>
                <p className="text-3xl font-bold">{stats.total}</p>
              </div>
              <div className="p-4 rounded-lg border border-green-500/30 bg-green-500/10">
                <p className="text-sm text-green-400">New Modules</p>
                <p className="text-3xl font-bold text-green-400">{stats.new}</p>
              </div>
              <div className="p-4 rounded-lg border border-yellow-500/30 bg-yellow-500/10">
                <p className="text-sm text-yellow-400">Updated</p>
                <p className="text-3xl font-bold text-yellow-400">{stats.updated}</p>
              </div>
              <div className="p-4 rounded-lg border border-gray-500/30 bg-gray-500/10">
                <p className="text-sm text-gray-400">Skipped</p>
                <p className="text-3xl font-bold text-gray-400">{stats.skipped}</p>
              </div>
            </div>
            
            <Button className="mt-4 w-full" onClick={handleSaveToDatabase}>
              Save to Database
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Imported Modules List */}
      {importedModules.length > 0 && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Imported Modules ({importedModules.length})</CardTitle>
            <CardDescription>Review before saving to database</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {importedModules.map((module, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-background/50"
                >
                  <div className="flex-1">
                    <p className="font-semibold">{module.code} - {module.name}</p>
                    <p className="text-sm text-muted-foreground">
                      TX: {module.canTx} | RX: {module.canRx}
                      {module.algorithm && ` | Algorithm: ${module.algorithm}`}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline">{module.source}</Badge>
                    {existingModules.includes(module.code) ? (
                      <Badge className="bg-yellow-500/20 text-yellow-400">Update</Badge>
                    ) : (
                      <Badge className="bg-green-500/20 text-green-400">New</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader>
          <CardTitle>How to Export from Dealer Tools</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">dealership diagnostic system</h3>
            <p className="text-sm text-muted-foreground">
              1. Open dealership diagnostic system application<br/>
              2. Navigate to "Module Database" → "Export"<br/>
              3. Select "JSON Format" and save file<br/>
              4. Upload the exported JSON file here
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">third-party diagnostic software</h3>
            <p className="text-sm text-muted-foreground">
              1. Open third-party diagnostic software installation folder<br/>
              2. Locate "third-party diagnostic software.db" database file<br/>
              3. Use DB Browser for SQLite to export "modules" table as JSON<br/>
              4. Upload the exported JSON file here
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">professional diagnostic tool</h3>
            <p className="text-sm text-muted-foreground">
              1. Extract CDA.swf using JPEXS Free Flash Decompiler<br/>
              2. Export "ModuleDatabase" ActionScript object as JSON<br/>
              3. Upload the exported JSON file here
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
