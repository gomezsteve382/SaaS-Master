import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { trpc } from '@/lib/trpc';
import { Sparkles, AlertCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";

export default function SpecialFunctions() {
  const { data: functions, isLoading } = trpc.alphaOBD.getSpecialFunctions.useQuery();

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
          <Sparkles className="h-10 w-10 text-orange-600" />
          Special Functions & Routines
        </h1>
        <p className="text-muted-foreground mt-2">
          TPMS programming, throttle adaptation, and special diagnostic routines from FGA_IPC_ROUTINES table
        </p>
      </div>

      <Alert className="bg-orange-50 border-orange-200">
        <AlertCircle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-900">
          <strong>Found {functions?.length || 0} special function routines</strong> from the SRT Lab FGA (Fiat Group Automobiles) database.
          These are advanced diagnostic procedures for specific modules and systems.
        </AlertDescription>
      </Alert>

      {/* Functions List */}
      {isLoading ? (
        <div className="text-center py-12">
          <Loader2 className="h-12 w-12 animate-spin text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Loading special functions...</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {functions?.map((func: any, index: number) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-orange-600" />
                  {func[2] || `Routine ${func[0]}`}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-muted-foreground">Command:</span>
                    <code className="ml-2 bg-gray-100 px-2 py-1 rounded">{func[1]}</code>
                  </div>
                  <div>
                    <span className="font-medium text-muted-foreground">ID:</span>
                    <span className="ml-2">{func[0]}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {functions?.length === 0 && (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                No special functions found
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
