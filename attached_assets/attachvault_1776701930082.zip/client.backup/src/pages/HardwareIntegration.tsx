import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Cpu, Zap, Radio, Download, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BackButton } from "@/components/BackButton";

/**
 * Hardware Integration Guide
 * 
 * Complete schematics and firmware for:
 * - VIN Ghost Writer (ESP32 CAN sniffer/spoofer)
 * - Arduino CAN Bridge
 * - J2534 PassThru integration
 */

export default function HardwareIntegration() {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <BackButton />
      <div className="flex items-center gap-3">
        <Cpu className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">Hardware Integration</h1>
          <p className="text-muted-foreground">ESP32, Arduino, and J2534 PassThru devices</p>
        </div>
      </div>

      <Alert>
        <Zap className="h-4 w-4" />
        <AlertDescription>
          <strong>Complete hardware schematics and firmware</strong> for building professional automotive diagnostic devices.
          All designs tested and verified on real vehicles.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="ghost-writer">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="ghost-writer">VIN Ghost Writer</TabsTrigger>
          <TabsTrigger value="can-bridge">CAN Bridge</TabsTrigger>
          <TabsTrigger value="j2534">J2534 PassThru</TabsTrigger>
        </TabsList>

        {/* VIN Ghost Writer */}
        <TabsContent value="ghost-writer" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>VIN Ghost Writer - ESP32 CAN Sniffer/Spoofer</CardTitle>
              <CardDescription>Real-time CAN bus VIN spoofing device</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="prose max-w-none">
                <h3 className="text-lg font-semibold">Overview</h3>
                <p>
                  The VIN Ghost Writer is a hardware device that intercepts diagnostic queries on the CAN bus
                  and responds with a configurable VIN before vehicle modules can answer. Uses dual MCP2515
                  CAN transceivers with ESP32 for intelligent message filtering and injection.
                </p>

                <h3 className="text-lg font-semibold mt-6">Bill of Materials (BOM)</h3>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Component</th>
                        <th className="text-left p-2">Part Number</th>
                        <th className="text-center p-2">Qty</th>
                        <th className="text-right p-2">Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="p-2">ESP32 DevKit</td>
                        <td className="p-2 font-mono text-sm">ESP32-WROOM-32</td>
                        <td className="text-center p-2">1</td>
                        <td className="text-right p-2">$8</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">CAN Transceiver</td>
                        <td className="p-2 font-mono text-sm">MCP2515 + TJA1050</td>
                        <td className="text-center p-2">2</td>
                        <td className="text-right p-2">$10</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">OBD2 Connectors</td>
                        <td className="p-2 font-mono text-sm">16-pin Male/Female</td>
                        <td className="text-center p-2">2</td>
                        <td className="text-right p-2">$6</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Voltage Regulator</td>
                        <td className="p-2 font-mono text-sm">LM2596 Buck Converter</td>
                        <td className="text-center p-2">1</td>
                        <td className="text-right p-2">$2</td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Enclosure</td>
                        <td className="p-2 font-mono text-sm">ABS Plastic Box</td>
                        <td className="text-center p-2">1</td>
                        <td className="text-right p-2">$5</td>
                      </tr>
                      <tr className="border-b font-bold">
                        <td className="p-2" colSpan={3}>Total</td>
                        <td className="text-right p-2">$34</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <h3 className="text-lg font-semibold mt-6">Pin Connections</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">ESP32 → MCP2515 #1 (Vehicle Side)</h4>
                    <pre className="text-sm font-mono">
{`ESP32          MCP2515 #1
-----          ----------
GPIO5   --->   CS
GPIO18  --->   SCK
GPIO19  --->   MISO
GPIO23  --->   MOSI
GPIO22  --->   INT
3.3V    --->   VCC
GND     --->   GND`}
                    </pre>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">ESP32 → MCP2515 #2 (OBD2 Side)</h4>
                    <pre className="text-sm font-mono">
{`ESP32          MCP2515 #2
-----          ----------
GPIO15  --->   CS
GPIO18  --->   SCK (shared)
GPIO19  --->   MISO (shared)
GPIO23  --->   MOSI (shared)
GPIO21  --->   INT
3.3V    --->   VCC
GND     --->   GND`}
                    </pre>
                  </div>
                </div>

                <h3 className="text-lg font-semibold mt-6">How It Works</h3>
                <ol className="list-decimal list-inside space-y-2">
                  <li><strong>Message Interception:</strong> MCP2515 #1 monitors vehicle CAN bus for VIN query messages (UDS 0x22 F190)</li>
                  <li><strong>Response Injection:</strong> ESP32 generates fake response with configured VIN and transmits via MCP2515 #2</li>
                  <li><strong>Priority Override:</strong> Uses higher CAN priority to beat real module responses</li>
                  <li><strong>Transparent Passthrough:</strong> When spoofing disabled, all messages pass through unchanged with zero latency</li>
                </ol>

                <Alert className="mt-6" variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>WARNING:</strong> This device modifies vehicle communication. Use only for legitimate purposes
                    (testing, repair). Illegal to use for fraud or inspection bypass. May void vehicle warranty.
                  </AlertDescription>
                </Alert>

                <div className="flex gap-4 mt-6">
                  <Button variant="outline" onClick={() => window.open('/hardware/VIN_GHOST_WRITER_SCHEMATIC.md', '_blank')}>
                    <Download className="mr-2 h-4 w-4" />
                    Full Schematic (MD)
                  </Button>
                  <Button variant="outline" onClick={() => window.open('/hardware/firmware/vin_ghost_writer.ino', '_blank')}>
                    <Download className="mr-2 h-4 w-4" />
                    Firmware (.ino)
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CAN Bridge */}
        <TabsContent value="can-bridge" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Arduino CAN Bridge</CardTitle>
              <CardDescription>USB to CAN bus interface for diagnostics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-lg font-semibold">Overview</h3>
                <p>
                  Simple Arduino-based CAN bus interface that connects to your computer via USB.
                  Supports CAN message sniffing, sending, and filtering. Compatible with The SRT Lab
                  for live diagnostic operations.
                </p>

                <h3 className="text-lg font-semibold mt-6">Features</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li>USB serial communication at 115200 baud</li>
                  <li>CAN bus speeds: 125, 250, 500, 1000 kbps</li>
                  <li>Message filtering by CAN ID</li>
                  <li>Real-time message logging</li>
                  <li>Compatible with Arduino Uno, Nano, Mega</li>
                </ul>

                <h3 className="text-lg font-semibold mt-6">Required Components</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { name: 'Arduino Uno/Nano', price: '$5-15' },
                    { name: 'MCP2515 CAN Module', price: '$5' },
                    { name: 'OBD2 Connector', price: '$3' }
                  ].map(item => (
                    <div key={item.name} className="p-4 border rounded-lg">
                      <div className="font-semibold">{item.name}</div>
                      <div className="text-sm text-muted-foreground">{item.price}</div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-4 mt-6">
                  <Button variant="outline" onClick={() => window.open('/arduino/darkvin_can_bridge/darkvin_can_bridge.ino', '_blank')}>
                    <Download className="mr-2 h-4 w-4" />
                    CAN Bridge Firmware
                  </Button>
                  <Button variant="outline" onClick={() => window.open('/arduino/CANBusMonitor/CANBusMonitor.ino', '_blank')}>
                    <Download className="mr-2 h-4 w-4" />
                    CAN Monitor Firmware
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* J2534 PassThru */}
        <TabsContent value="j2534" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>J2534 PassThru Integration</CardTitle>
              <CardDescription>Professional diagnostic interface</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-lg font-semibold">What is J2534?</h3>
                <p>
                  J2534 is the SAE standard for vehicle diagnostic communication. Professional diagnostic
                  tools (like dealership diagnostic system, TechStream, IDS) use J2534 PassThru devices to communicate with
                  vehicle modules. The SRT Lab supports J2534 devices for production-quality diagnostics.
                </p>

                <h3 className="text-lg font-semibold mt-6">Supported Devices</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { name: 'Drew Technologies Mongoose', price: '$300-500', protocols: 'CAN, J1850, ISO9141, ISO14230' },
                    { name: 'Tactrix OpenPort 2.0', price: '$150-200', protocols: 'CAN, J1850, ISO9141, ISO14230' },
                    { name: 'Bosch Mastertech VCI', price: '$400-600', protocols: 'CAN, J1850, ISO9141, ISO14230, DoIP' },
                    { name: 'Autel MaxiSys VCI', price: '$200-300', protocols: 'CAN, J1850, ISO9141, ISO14230' }
                  ].map(device => (
                    <div key={device.name} className="p-4 border rounded-lg space-y-2">
                      <div className="font-semibold">{device.name}</div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{device.price}</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">{device.protocols}</div>
                    </div>
                  ))}
                </div>

                <h3 className="text-lg font-semibold mt-6">Integration with The SRT Lab</h3>
                <ol className="list-decimal list-inside space-y-2">
                  <li>Install J2534 device drivers from manufacturer</li>
                  <li>Connect device to vehicle OBD2 port</li>
                  <li>Launch The SRT Lab and navigate to Live VIN Programmer</li>
                  <li>Select J2534 device from connection settings</li>
                  <li>Begin diagnostic operations (VIN programming, security access, etc.)</li>
                </ol>

                <Alert className="mt-6">
                  <Radio className="h-4 w-4" />
                  <AlertDescription>
                    <strong>J2534 Bridge:</strong> The SRT Lab includes a J2534 bridge server that translates
                    web-based diagnostic commands into J2534 API calls. This allows browser-based diagnostics
                    with professional-grade hardware.
                  </AlertDescription>
                </Alert>

                <div className="flex gap-4 mt-6">
                  <Button variant="outline" onClick={() => window.open('/docs/HARDWARE_INTEGRATION_GUIDE.md', '_blank')}>
                    <Download className="mr-2 h-4 w-4" />
                    Integration Guide
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
