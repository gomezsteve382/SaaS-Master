import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { trpc } from '@/lib/trpc';
import { Database, Search, FileText, Cpu, Gauge, AlertTriangle, Zap } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";

export default function SRTLabExplorer() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  // Universal search
  const { data: searchResults, isLoading: searchLoading } = trpc.alphaOBD.searchAll.useQuery(
    { query: searchQuery, limit: 50 },
    { enabled: searchQuery.length > 2 }
  );

  // Individual data queries
  const { data: dtcCodes } = trpc.alphaOBD.getAllDTCCodes.useQuery({ limit: 100 });
  const { data: liveData } = trpc.alphaOBD.getAllLiveDataParameters.useQuery({ limit: 100 });
  const { data: ecus } = trpc.alphaOBD.getAllECUDefinitions.useQuery({ limit: 100 });
  const { data: engineData } = trpc.alphaOBD.getAllFGAEngineData.useQuery({ limit: 100 });
  const { data: bcmData } = trpc.alphaOBD.getAllFGABCMData.useQuery({ limit: 100 });
  const { data: absData } = trpc.alphaOBD.getAllFGAABSData.useQuery({ limit: 100 });
  const { data: petrolData } = trpc.alphaOBD.getAllFGAPetrolData.useQuery({ limit: 100 });
  const { data: devices } = trpc.alphaOBD.getAllDeviceTypes.useQuery();

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
          <Database className="h-10 w-10 text-blue-600" />
          SRT Lab Database Explorer
        </h1>
        <p className="text-muted-foreground mt-2">
          Complete professional diagnostic database - 53,000+ data points from SRT Lab Android
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              DTC Codes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">22,166</div>
            <p className="text-xs text-muted-foreground mt-1">Fault codes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Gauge className="h-4 w-4" />
              Live Data
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">4,757</div>
            <p className="text-xs text-muted-foreground mt-1">Parameters</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Cpu className="h-4 w-4" />
              ECU Definitions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">1,632</div>
            <p className="text-xs text-muted-foreground mt-1">Modules</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Zap className="h-4 w-4" />
              FGA Data
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">22,641</div>
            <p className="text-xs text-muted-foreground mt-1">Diagnostic parameters</p>
          </CardContent>
        </Card>
      </div>

      {/* Universal Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Universal Search
          </CardTitle>
          <CardDescription>Search across all 53,000+ data points</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            placeholder="Search DTC codes, live data, ECUs, procedures..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="text-lg"
          />
          
          {searchQuery.length > 2 && (
            <div className="space-y-4">
              {searchLoading ? (
                <p className="text-center text-muted-foreground">Searching...</p>
              ) : searchResults ? (
                <div className="space-y-4">
                  {searchResults.dtcCodes.length > 0 && (
                    <div>
                      <h3 className="font-semibold mb-2 flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4" />
                        DTC Codes ({searchResults.dtcCodes.length})
                      </h3>
                      <div className="space-y-2">
                        {searchResults.dtcCodes.slice(0, 5).map((dtc: any, i: number) => (
                          <Card key={i}>
                            <CardContent className="pt-4">
                              <div className="flex items-start justify-between">
                                <div>
                                  <Badge>{dtc.hexcode}</Badge>
                                  <p className="text-sm mt-2">{dtc.description}</p>
                                  <p className="text-xs text-muted-foreground mt-1">Device: {dtc.device_id}</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {searchResults.liveData.length > 0 && (
                    <div>
                      <h3 className="font-semibold mb-2 flex items-center gap-2">
                        <Gauge className="h-4 w-4" />
                        Live Data Parameters ({searchResults.liveData.length})
                      </h3>
                      <div className="grid grid-cols-2 gap-2">
                        {searchResults.liveData.slice(0, 6).map((param: any) => (
                          <Card key={param.id}>
                            <CardContent className="pt-4">
                              <Badge variant="outline">ID: {param.id}</Badge>
                              <p className="text-sm mt-2">{param.name}</p>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {searchResults.ecus.length > 0 && (
                    <div>
                      <h3 className="font-semibold mb-2 flex items-center gap-2">
                        <Cpu className="h-4 w-4" />
                        ECU Definitions ({searchResults.ecus.length})
                      </h3>
                      <div className="space-y-2">
                        {searchResults.ecus.slice(0, 5).map((ecu: any) => (
                          <Card key={ecu.ID}>
                            <CardContent className="pt-4">
                              <div className="flex items-start justify-between">
                                <div>
                                  <h4 className="font-semibold">{ecu.ECUNAME}</h4>
                                  <p className="text-sm text-muted-foreground">{ecu.Option}</p>
                                  <div className="flex gap-2 mt-2">
                                    {ecu.Chrysler && <Badge>Chrysler</Badge>}
                                    {ecu.Jeep && <Badge>Jeep</Badge>}
                                    {ecu.Dodge_RAM && <Badge>Dodge/RAM</Badge>}
                                    {ecu.Fiat_Fiat_Pro && <Badge>Fiat</Badge>}
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : null}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabbed Data Browser */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 lg:grid-cols-8 w-full">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="dtc">DTC Codes</TabsTrigger>
          <TabsTrigger value="livedata">Live Data</TabsTrigger>
          <TabsTrigger value="ecus">ECUs</TabsTrigger>
          <TabsTrigger value="engine">Engine</TabsTrigger>
          <TabsTrigger value="bcm">BCM</TabsTrigger>
          <TabsTrigger value="abs">ABS</TabsTrigger>
          <TabsTrigger value="devices">Devices</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Alert>
            <Database className="h-4 w-4" />
            <AlertDescription>
              <strong>Complete SRT Lab Database</strong> - This platform contains the ENTIRE diagnostic protocol for Chrysler/FCA/Stellantis vehicles.
              Browse 22,166 DTC codes, 4,757 live data parameters, 1,632 ECU definitions, and 22,641 FGA diagnostic parameters.
            </AlertDescription>
          </Alert>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Database Contents</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>DTC Fault Codes</span>
                  <Badge>22,166</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Live Data Parameters</span>
                  <Badge>4,757</Badge>
                </div>
                <div className="flex justify-between">
                  <span>ECU Definitions</span>
                  <Badge>1,632</Badge>
                </div>
                <div className="flex justify-between">
                  <span>FGA Engine Data</span>
                  <Badge>4,427</Badge>
                </div>
                <div className="flex justify-between">
                  <span>FGA BCM Data</span>
                  <Badge>4,826</Badge>
                </div>
                <div className="flex justify-between">
                  <span>FGA ABS Data</span>
                  <Badge>4,089</Badge>
                </div>
                <div className="flex justify-between">
                  <span>FGA Petrol Data</span>
                  <Badge>5,099</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Device Types</span>
                  <Badge>330</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Supported Brands</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Badge variant="outline" className="mr-2">Chrysler</Badge>
                <Badge variant="outline" className="mr-2">Jeep</Badge>
                <Badge variant="outline" className="mr-2">Dodge</Badge>
                <Badge variant="outline" className="mr-2">RAM</Badge>
                <Badge variant="outline" className="mr-2">Fiat</Badge>
                <Badge variant="outline" className="mr-2">Alfa Romeo</Badge>
                <Badge variant="outline" className="mr-2">Lancia</Badge>
                <Badge variant="outline" className="mr-2">Abarth</Badge>
                <Badge variant="outline" className="mr-2">Peugeot</Badge>
                <Badge variant="outline" className="mr-2">Citroen</Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="dtc" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>DTC Fault Codes (22,166 total)</CardTitle>
              <CardDescription>Diagnostic Trouble Codes with multilingual descriptions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {dtcCodes?.slice(0, 50).map((dtc: any, i: number) => (
                  <Card key={i}>
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <Badge>{dtc.hexcode}</Badge>
                          <p className="text-sm mt-2 whitespace-pre-wrap">{dtc.description}</p>
                          <p className="text-xs text-muted-foreground mt-1">Device IDs: {dtc.device_id}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="livedata" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live Data Parameters (4,757 total)</CardTitle>
              <CardDescription>Real-time sensor readings and vehicle parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[600px] overflow-y-auto">
                {liveData?.map((param: any) => (
                  <Card key={param.id}>
                    <CardContent className="pt-4">
                      <Badge variant="outline">ID: {param.id}</Badge>
                      <p className="text-sm mt-2 font-medium">{param.name}</p>
                      {param.name_de && <p className="text-xs text-muted-foreground mt-1">DE: {param.name_de}</p>}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ecus" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>ECU Definitions (1,632 total)</CardTitle>
              <CardDescription>Complete vehicle/ECU compatibility matrix</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {ecus?.map((ecu: any) => (
                  <Card key={ecu.ID}>
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold">{ecu.ECUNAME}</h4>
                          <p className="text-sm text-muted-foreground mt-1">{ecu.Option}</p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <Badge variant="outline">Device ID: {ecu.Device_ID}</Badge>
                            {ecu.Chrysler && <Badge>Chrysler</Badge>}
                            {ecu.Jeep && <Badge>Jeep</Badge>}
                            {ecu.Dodge_RAM && <Badge>Dodge/RAM</Badge>}
                            {ecu.Fiat_Fiat_Pro && <Badge>Fiat</Badge>}
                            {ecu.Alfa && <Badge>Alfa</Badge>}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="engine" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>FGA Engine Data (4,427 parameters)</CardTitle>
              <CardDescription>Engine diagnostic parameters with request/response formats</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {engineData?.map((param: any, i: number) => (
                  <Card key={i}>
                    <CardContent className="pt-4 text-xs font-mono">
                      <div className="grid grid-cols-2 gap-2">
                        <div><strong>Request:</strong> {param.request}</div>
                        <div><strong>Response:</strong> {param.response_name}</div>
                        <div><strong>Bit Pos:</strong> {param.bit_pos}</div>
                        <div><strong>Bit Len:</strong> {param.bit_len}</div>
                        {param.unit_name && <div><strong>Unit:</strong> {param.unit_name}</div>}
                        <div><strong>Device:</strong> {param.device_id}</div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bcm" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>FGA BCM Data (4,826 parameters)</CardTitle>
              <CardDescription>Body Control Module parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {bcmData?.slice(0, 50).map((param: any, i: number) => (
                  <Card key={i}>
                    <CardContent className="pt-4 text-xs font-mono">
                      <pre className="whitespace-pre-wrap">{JSON.stringify(param, null, 2)}</pre>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="abs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>FGA ABS Data (4,089 parameters)</CardTitle>
              <CardDescription>ABS/ESP brake system parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {absData?.slice(0, 50).map((param: any, i: number) => (
                  <Card key={i}>
                    <CardContent className="pt-4 text-xs font-mono">
                      <pre className="whitespace-pre-wrap">{JSON.stringify(param, null, 2)}</pre>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="devices" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Device Types (330 total)</CardTitle>
              <CardDescription>All supported diagnostic modules</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 max-h-[600px] overflow-y-auto">
                {devices?.map((device: any) => (
                  <Card key={device.Device_ID}>
                    <CardContent className="pt-4">
                      <Badge variant="outline">ID: {device.Device_ID}</Badge>
                      <p className="text-sm mt-2 font-medium">{device.Device_name}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
