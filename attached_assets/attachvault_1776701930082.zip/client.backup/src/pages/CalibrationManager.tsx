import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackButton } from "@/components/BackButton";
import { 
  Download, 
  Upload, 
  Save, 
  Eye,
  EyeOff,
  CheckCircle2,
  AlertTriangle,
  Info,
  FileCode
} from 'lucide-react';

interface CalibrationData {
  address: string;
  hexValue: string;
  decValue: number;
  description: string;
}

export default function CalibrationManager() {
  const [selectedModule, setSelectedModule] = useState('ECM');
  const [viewMode, setViewMode] = useState<'hex' | 'decimal'>('hex');
  const [calibrationData, setCalibrationData] = useState<CalibrationData[]>([
    {
      address: '0x1000',
      hexValue: 'FF 00 A5 3C',
      decValue: 4278235452,
      description: 'Fuel Injection Timing Offset'
    },
    {
      address: '0x1004',
      hexValue: '12 34 56 78',
      decValue: 305419896,
      description: 'Ignition Advance Map Base'
    },
    {
      address: '0x1008',
      hexValue: 'AB CD EF 01',
      decValue: 2882400001,
      description: 'Boost Pressure Limit'
    },
    {
      address: '0x100C',
      hexValue: '00 00 1F 40',
      decValue: 8000,
      description: 'RPM Limiter'
    },
    {
      address: '0x1010',
      hexValue: '00 00 00 64',
      decValue: 100,
      description: 'Throttle Response Multiplier'
    }
  ]);

  const [hasBackup, setHasBackup] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const readCalibration = async () => {
    // Simulate reading calibration
    await new Promise(resolve => setTimeout(resolve, 2000));
    // Calibration data is already loaded
  };

  const writeCalibration = async () => {
    // Simulate writing calibration
    await new Promise(resolve => setTimeout(resolve, 3000));
    setHasChanges(false);
  };

  const backupCalibration = () => {
    const json = JSON.stringify(calibrationData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedModule}_calibration_backup_${Date.now()}.json`;
    a.click();
    setHasBackup(true);
  };

  const exportCalibrationBin = () => {
    // Simulate binary export
    const hexData = calibrationData.map(c => c.hexValue).join(' ');
    const blob = new Blob([hexData], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedModule}_calibration_${Date.now()}.bin`;
    a.click();
  };

  const updateCalibrationValue = (index: number, newHexValue: string) => {
    setCalibrationData(prev => prev.map((item, i) => {
      if (i === index) {
        // Convert hex to decimal
        const decValue = parseInt(newHexValue.replace(/\s/g, ''), 16);
        return { ...item, hexValue: newHexValue, decValue };
      }
      return item;
    }));
    setHasChanges(true);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
          Calibration Manager
        </h1>
        <p className="text-muted-foreground mt-2">
          Read, edit, and write module calibration data (professional diagnostic tool Clone)
        </p>
      </div>

      {/* Warning Alert */}
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>WARNING:</strong> Incorrect calibration values can damage your engine or cause drivability issues. 
          Always backup original calibration before making changes. Only modify values if you understand their purpose.
        </AlertDescription>
      </Alert>

      {/* Configuration */}
      <Card className="p-6">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="target-module">Target Module</Label>
              <Select value={selectedModule} onValueChange={setSelectedModule}>
                <SelectTrigger id="target-module">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ECM">ECM (Engine Control Module)</SelectItem>
                  <SelectItem value="TCM">TCM (Transmission Control Module)</SelectItem>
                  <SelectItem value="BCM">BCM (Body Control Module)</SelectItem>
                  <SelectItem value="ABS">ABS (Anti-lock Braking System)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="view-mode">View Mode</Label>
              <Select value={viewMode} onValueChange={(v) => setViewMode(v as 'hex' | 'decimal')}>
                <SelectTrigger id="view-mode">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hex">Hexadecimal</SelectItem>
                  <SelectItem value="decimal">Decimal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={readCalibration}>
              <Download className="mr-2 h-4 w-4" />
              Read Calibration
            </Button>
            <Button onClick={backupCalibration} variant="outline">
              <Save className="mr-2 h-4 w-4" />
              Backup Original
            </Button>
            <Button onClick={exportCalibrationBin} variant="outline">
              <FileCode className="mr-2 h-4 w-4" />
              Export Binary
            </Button>
          </div>

          {hasBackup && (
            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>
                Original calibration backed up successfully! You can now safely modify values.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </Card>

      {/* Calibration Editor */}
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Calibration Data</h2>
            {hasChanges && (
              <Badge variant="destructive">⚠️ Unsaved Changes</Badge>
            )}
          </div>

          <Separator />

          <Tabs defaultValue="editor">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="editor">Visual Editor</TabsTrigger>
              <TabsTrigger value="hex">Hex Dump</TabsTrigger>
            </TabsList>

            <TabsContent value="editor" className="space-y-2">
              {calibrationData.map((item, index) => (
                <div
                  key={index}
                  className="border rounded-lg p-4 space-y-2"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-semibold">{item.description}</p>
                      <p className="text-sm text-muted-foreground font-mono">
                        Address: {item.address}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Hex Value</Label>
                      <Input
                        value={item.hexValue}
                        onChange={(e) => updateCalibrationValue(index, e.target.value)}
                        className="font-mono"
                        placeholder="FF 00 A5 3C"
                      />
                    </div>
                    <div>
                      <Label>Decimal Value</Label>
                      <Input
                        value={item.decValue}
                        readOnly
                        className="font-mono bg-muted"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="hex">
              <Textarea
                value={calibrationData.map(c => `${c.address}: ${c.hexValue}`).join('\n')}
                readOnly
                rows={15}
                className="font-mono text-sm"
              />
            </TabsContent>
          </Tabs>
        </div>
      </Card>

      {/* Write Actions */}
      <Card className="p-6">
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Write Calibration</h2>
          <p className="text-sm text-muted-foreground">
            Write modified calibration data to the module. This operation requires security access.
          </p>

          <div className="flex gap-2">
            <Button
              onClick={writeCalibration}
              disabled={!hasChanges}
              size="lg"
            >
              <Upload className="mr-2 h-5 w-5" />
              Write to Module
            </Button>
            {hasChanges && (
              <Button
                onClick={() => {
                  setCalibrationData(calibrationData);
                  setHasChanges(false);
                }}
                variant="outline"
                size="lg"
              >
                Discard Changes
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Comparison Tool */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Before/After Comparison</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Compare original and modified calibration values side-by-side
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border rounded-lg p-4">
            <h3 className="font-semibold mb-2">Original</h3>
            <div className="space-y-1 text-sm font-mono">
              {calibrationData.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <span>{item.address}:</span>
                  <span className="text-muted-foreground">FF 00 A5 3C</span>
                </div>
              ))}
            </div>
          </div>
          <div className="border rounded-lg p-4">
            <h3 className="font-semibold mb-2">Modified</h3>
            <div className="space-y-1 text-sm font-mono">
              {calibrationData.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <span>{item.address}:</span>
                  <span className={hasChanges ? 'text-yellow-500' : 'text-muted-foreground'}>
                    {item.hexValue}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Technical Details */}
      <Card className="p-6 bg-muted/50">
        <h3 className="text-lg font-semibold mb-4">Technical Details</h3>
        <div className="space-y-2 text-sm">
          <p><strong>Message Protocol:</strong> professional diagnostic tool-compatible JSON messages over HTTP/HTTPS</p>
          <p><strong>ReadCalibrationPM:</strong> Reads calibration data from module memory</p>
          <p><strong>WriteCalibrationPM:</strong> Writes modified calibration data to module</p>
          <p><strong>UDS Commands:</strong> 0x22 (Read), 0x2E (Write), 0x31 (Verify)</p>
          <p><strong>Data Format:</strong> Raw hex bytes with address mapping</p>
          <p><strong>Validation:</strong> CRC-16 or CRC-32 checksum verification</p>
          <p><strong>Security:</strong> Requires Level 5 security access (Atlantis)</p>
        </div>
      </Card>

      {/* Info Alert */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>professional diagnostic tool Clone Feature:</strong> This Calibration Manager replicates the functionality of Chrysler's professional diagnostic tool calibration editor. 
          It supports reading, editing, and writing calibration data to ECM, TCM, BCM, and ABS modules using the same message protocol as the original professional diagnostic tool application.
        </AlertDescription>
      </Alert>

      {/* Common Calibrations */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Common Calibration Parameters</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">ECM (Engine)</h4>
            <ul className="text-sm space-y-1">
              <li>• Fuel injection timing</li>
              <li>• Ignition advance maps</li>
              <li>• Boost pressure limits</li>
              <li>• RPM limiter</li>
              <li>• Throttle response</li>
              <li>• Air/fuel ratio targets</li>
            </ul>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold mb-2">TCM (Transmission)</h4>
            <ul className="text-sm space-y-1">
              <li>• Shift points</li>
              <li>• Shift firmness</li>
              <li>• Torque management</li>
              <li>• Line pressure</li>
              <li>• Converter lockup</li>
              <li>• Gear ratios</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
