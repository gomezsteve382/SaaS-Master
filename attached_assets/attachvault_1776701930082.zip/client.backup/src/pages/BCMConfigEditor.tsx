import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackButton } from "@/components/BackButton";
import { AlertTriangle, CheckCircle2, Car, Zap, Settings2, Download } from 'lucide-react';
import { toast } from 'sonner';

interface BCMConfig {
  vehicleVariant: string;
  launchControl: boolean;
  lineLock: boolean;
  dragMode: boolean;
  performancePages: boolean;
  gaugeClusterVariant: string;
}

const VEHICLE_VARIANTS = [
  { value: 'base', label: 'Base Model', hp: '292 HP', engine: '3.6L V6' },
  { value: 'rt', label: 'R/T', hp: '370 HP', engine: '5.7L HEMI V8' },
  { value: 'scat', label: 'Scat Pack', hp: '485 HP', engine: '6.4L 392 HEMI V8' },
  { value: 'redeye', label: 'Redeye', hp: '797 HP', engine: '6.2L Supercharged HEMI V8' },
  { value: 'demon', label: 'Demon', hp: '840 HP', engine: '6.2L Supercharged HEMI V8' },
];

const GAUGE_VARIANTS = [
  { value: 'base', label: 'Base Cluster' },
  { value: 'sport', label: 'Sport Cluster' },
  { value: 'performance', label: 'Performance Cluster' },
  { value: 'srt', label: 'SRT Cluster' },
];

export default function BCMConfigEditor() {
  const [currentConfig, setCurrentConfig] = useState<BCMConfig>({
    vehicleVariant: 'base',
    launchControl: false,
    lineLock: false,
    dragMode: false,
    performancePages: false,
    gaugeClusterVariant: 'base',
  });

  const [newConfig, setNewConfig] = useState<BCMConfig>({ ...currentConfig });
  const [isReading, setIsReading] = useState(false);
  const [isWriting, setIsWriting] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const handleReadConfig = async () => {
    setIsReading(true);
    toast.info('Reading BCM configuration from vehicle...');

    try {
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        throw new Error('Not connected to vehicle. Please connect OBDLink/J2534 adapter first.');
      }

      // BCM CAN addresses (typical for FCA vehicles)
      const BCM_TX = 0x750;
      const BCM_RX = 0x758;

      // Read BCM configuration DIDs
      // DID 0xF190 - Vehicle Variant
      const variantResp = await protocol.sendUDS(BCM_TX, BCM_RX, [0x22, 0xF1, 0x90]);
      
      // DID 0xF1A0 - Feature Configuration Byte 1
      const features1Resp = await protocol.sendUDS(BCM_TX, BCM_RX, [0x22, 0xF1, 0xA0]);
      
      // DID 0xF1A1 - Feature Configuration Byte 2
      const features2Resp = await protocol.sendUDS(BCM_TX, BCM_RX, [0x22, 0xF1, 0xA1]);
      
      // DID 0xF1A2 - Gauge Cluster Variant
      const gaugeResp = await protocol.sendUDS(BCM_TX, BCM_RX, [0x22, 0xF1, 0xA2]);

      // Parse responses
      const variantByte = variantResp && variantResp.length > 3 ? variantResp[3] : 0x00;
      const features1 = features1Resp && features1Resp.length > 3 ? features1Resp[3] : 0x00;
      const features2 = features2Resp && features2Resp.length > 3 ? features2Resp[3] : 0x00;
      const gaugeByte = gaugeResp && gaugeResp.length > 3 ? gaugeResp[3] : 0x00;

      // Map bytes to config
      const variantMap: Record<number, string> = {
        0x00: 'base',
        0x01: 'rt',
        0x02: 'scat',
        0x03: 'redeye',
        0x04: 'demon',
      };

      const gaugeMap: Record<number, string> = {
        0x00: 'base',
        0x01: 'sport',
        0x02: 'performance',
        0x03: 'srt',
      };

      const readConfig: BCMConfig = {
        vehicleVariant: variantMap[variantByte] || 'base',
        launchControl: !!(features1 & 0x01),
        lineLock: !!(features1 & 0x02),
        dragMode: !!(features1 & 0x04),
        performancePages: !!(features2 & 0x01),
        gaugeClusterVariant: gaugeMap[gaugeByte] || 'base',
      };

      setCurrentConfig(readConfig);
      setNewConfig(readConfig);
      toast.success('BCM configuration read from vehicle');
    } catch (error: any) {
      toast.error(`Failed to read config: ${error.message}`);
    } finally {
      setIsReading(false);
    }
  };

  const handleWriteConfig = async () => {
    setIsWriting(true);
    toast.info('Writing BCM configuration to vehicle...');

    try {
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const { generateKey } = await import('../../../shared/fca-keygen');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        throw new Error('Not connected to vehicle');
      }

      const BCM_TX = 0x750;
      const BCM_RX = 0x758;

      // Step 1: Request security access
      toast.info('Requesting security access...');
      const seedResp = await protocol.sendUDS(BCM_TX, BCM_RX, [0x27, 0x01]);
      
      if (!seedResp || seedResp[0] === 0x7F) {
        throw new Error('Security access denied - seed request failed');
      }

      const seed = seedResp.slice(2, 6);
      const key = generateKey(new Uint8Array(seed), 1);
      
      // Step 2: Send key
      const keyResp = await protocol.sendUDS(BCM_TX, BCM_RX, [0x27, 0x02, ...Array.from(key)]);
      
      if (!keyResp || keyResp[0] !== 0x67) {
        throw new Error('Security access denied - invalid key');
      }

      toast.success('Security access granted');

      // Step 3: Write configuration DIDs
      const variantMap: Record<string, number> = {
        'base': 0x00,
        'rt': 0x01,
        'scat': 0x02,
        'redeye': 0x03,
        'demon': 0x04,
      };

      const gaugeMap: Record<string, number> = {
        'base': 0x00,
        'sport': 0x01,
        'performance': 0x02,
        'srt': 0x03,
      };

      // Build feature bytes
      let features1 = 0x00;
      if (newConfig.launchControl) features1 |= 0x01;
      if (newConfig.lineLock) features1 |= 0x02;
      if (newConfig.dragMode) features1 |= 0x04;

      let features2 = 0x00;
      if (newConfig.performancePages) features2 |= 0x01;

      // Write DIDs using UDS 0x2E
      await protocol.sendUDS(BCM_TX, BCM_RX, [0x2E, 0xF1, 0x90, variantMap[newConfig.vehicleVariant] || 0x00]);
      await protocol.sendUDS(BCM_TX, BCM_RX, [0x2E, 0xF1, 0xA0, features1]);
      await protocol.sendUDS(BCM_TX, BCM_RX, [0x2E, 0xF1, 0xA1, features2]);
      await protocol.sendUDS(BCM_TX, BCM_RX, [0x2E, 0xF1, 0xA2, gaugeMap[newConfig.gaugeClusterVariant] || 0x00]);

      setCurrentConfig(newConfig);
      setHasChanges(false);
      toast.success('BCM configuration written to vehicle!');
      toast.info('Cycle ignition to apply changes');
    } catch (error: any) {
      toast.error(`Failed to write config: ${error.message}`);
    } finally {
      setIsWriting(false);
    }
  };

  const handleConfigChange = (key: keyof BCMConfig, value: any) => {
    setNewConfig(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const getVariantBadgeColor = (variant: string) => {
    switch (variant) {
      case 'demon':
        return 'bg-red-600 text-white';
      case 'redeye':
        return 'bg-orange-600 text-white';
      case 'scat':
        return 'bg-yellow-600 text-white';
      case 'rt':
        return 'bg-blue-600 text-white';
      default:
        return 'bg-gray-600 text-white';
    }
  };

  const selectedVariant = VEHICLE_VARIANTS.find(v => v.value === newConfig.vehicleVariant);

  return (
    <div className="container py-8">
      <BackButton />
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">BCM Configuration Editor</h1>
        <p className="text-muted-foreground">
          Change vehicle variant and enable performance features
        </p>
      </div>

      {/* Warning */}
      <Alert className="mb-6 border-red-600 bg-red-50">
        <AlertTriangle className="h-5 w-5 text-red-600" />
        <AlertDescription className="text-red-800">
          <strong>WARNING:</strong> Changing BCM configuration can affect vehicle behavior. 
          Ensure hardware matches selected variant (engine, transmission, etc.). 
          Incorrect configuration may cause DTCs or system malfunctions.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings2 className="h-5 w-5" />
              Current Configuration
            </CardTitle>
            <CardDescription>Read from BCM</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={handleReadConfig}
              disabled={isReading}
              className="w-full"
            >
              {isReading ? 'Reading...' : 'Read BCM Configuration'}
            </Button>

            {currentConfig && (
              <div className="bg-gray-50 p-4 rounded space-y-3">
                <div>
                  <Label className="text-sm text-gray-600">Vehicle Variant</Label>
                  <Badge className={`mt-1 ${getVariantBadgeColor(currentConfig.vehicleVariant)}`}>
                    {VEHICLE_VARIANTS.find(v => v.value === currentConfig.vehicleVariant)?.label || 'Unknown'}
                  </Badge>
                </div>

                <div>
                  <Label className="text-sm text-gray-600">Features Enabled</Label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {currentConfig.launchControl && <Badge variant="outline">Launch Control</Badge>}
                    {currentConfig.lineLock && <Badge variant="outline">Line Lock</Badge>}
                    {currentConfig.dragMode && <Badge variant="outline">Drag Mode</Badge>}
                    {currentConfig.performancePages && <Badge variant="outline">Performance Pages</Badge>}
                    {!currentConfig.launchControl && !currentConfig.lineLock && !currentConfig.dragMode && !currentConfig.performancePages && (
                      <span className="text-sm text-gray-500">None</span>
                    )}
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600">Gauge Cluster</Label>
                  <p className="text-sm mt-1">
                    {GAUGE_VARIANTS.find(g => g.value === currentConfig.gaugeClusterVariant)?.label || 'Unknown'}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* New Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="h-5 w-5" />
              New Configuration
            </CardTitle>
            <CardDescription>Configure and write to BCM</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Vehicle Variant */}
            <div>
              <Label htmlFor="variant">Vehicle Variant</Label>
              <Select
                value={newConfig.vehicleVariant}
                onValueChange={(value) => handleConfigChange('vehicleVariant', value)}
              >
                <SelectTrigger id="variant" className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {VEHICLE_VARIANTS.map(variant => (
                    <SelectItem key={variant.value} value={variant.value}>
                      <div className="flex items-center justify-between w-full">
                        <span>{variant.label}</span>
                        <span className="text-xs text-gray-500 ml-4">{variant.hp} • {variant.engine}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedVariant && (
                <div className="mt-2 p-3 bg-blue-50 rounded">
                  <p className="text-sm text-blue-800">
                    <strong>{selectedVariant.label}:</strong> {selectedVariant.hp} • {selectedVariant.engine}
                  </p>
                </div>
              )}
            </div>

            {/* Performance Features */}
            <div className="space-y-4">
              <Label>Performance Features</Label>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="launch-control" className="font-normal">Launch Control</Label>
                  <p className="text-xs text-gray-500">High-RPM launch assist</p>
                </div>
                <Switch
                  id="launch-control"
                  checked={newConfig.launchControl}
                  onCheckedChange={(checked) => handleConfigChange('launchControl', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="line-lock" className="font-normal">Line Lock</Label>
                  <p className="text-xs text-gray-500">Front brake hold for burnouts</p>
                </div>
                <Switch
                  id="line-lock"
                  checked={newConfig.lineLock}
                  onCheckedChange={(checked) => handleConfigChange('lineLock', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="drag-mode" className="font-normal">Drag Mode</Label>
                  <p className="text-xs text-gray-500">Optimized for drag racing</p>
                </div>
                <Switch
                  id="drag-mode"
                  checked={newConfig.dragMode}
                  onCheckedChange={(checked) => handleConfigChange('dragMode', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="perf-pages" className="font-normal">Performance Pages</Label>
                  <p className="text-xs text-gray-500">0-60, 1/4 mile, G-force display</p>
                </div>
                <Switch
                  id="perf-pages"
                  checked={newConfig.performancePages}
                  onCheckedChange={(checked) => handleConfigChange('performancePages', checked)}
                />
              </div>
            </div>

            {/* Gauge Cluster */}
            <div>
              <Label htmlFor="cluster">Gauge Cluster Variant</Label>
              <Select
                value={newConfig.gaugeClusterVariant}
                onValueChange={(value) => handleConfigChange('gaugeClusterVariant', value)}
              >
                <SelectTrigger id="cluster" className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {GAUGE_VARIANTS.map(variant => (
                    <SelectItem key={variant.value} value={variant.value}>
                      {variant.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Write Button */}
            <Button
              onClick={handleWriteConfig}
              disabled={!hasChanges || isWriting}
              className="w-full"
              size="lg"
            >
              <Zap className="h-5 w-5 mr-2" />
              {isWriting ? 'Writing...' : 'Write Configuration to BCM'}
            </Button>

            {hasChanges && (
              <p className="text-sm text-orange-600 text-center">
                ⚠️ Unsaved changes
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Comparison */}
      {hasChanges && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Configuration Comparison</CardTitle>
            <CardDescription>Review changes before writing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">Current (BCM)</h4>
                <div className="space-y-1 text-sm">
                  <p><strong>Variant:</strong> {VEHICLE_VARIANTS.find(v => v.value === currentConfig.vehicleVariant)?.label}</p>
                  <p><strong>Launch Control:</strong> {currentConfig.launchControl ? '✅' : '❌'}</p>
                  <p><strong>Line Lock:</strong> {currentConfig.lineLock ? '✅' : '❌'}</p>
                  <p><strong>Drag Mode:</strong> {currentConfig.dragMode ? '✅' : '❌'}</p>
                  <p><strong>Performance Pages:</strong> {currentConfig.performancePages ? '✅' : '❌'}</p>
                  <p><strong>Cluster:</strong> {GAUGE_VARIANTS.find(g => g.value === currentConfig.gaugeClusterVariant)?.label}</p>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">New (To Write)</h4>
                <div className="space-y-1 text-sm">
                  <p><strong>Variant:</strong> {VEHICLE_VARIANTS.find(v => v.value === newConfig.vehicleVariant)?.label}</p>
                  <p><strong>Launch Control:</strong> {newConfig.launchControl ? '✅' : '❌'}</p>
                  <p><strong>Line Lock:</strong> {newConfig.lineLock ? '✅' : '❌'}</p>
                  <p><strong>Drag Mode:</strong> {newConfig.dragMode ? '✅' : '❌'}</p>
                  <p><strong>Performance Pages:</strong> {newConfig.performancePages ? '✅' : '❌'}</p>
                  <p><strong>Cluster:</strong> {GAUGE_VARIANTS.find(g => g.value === newConfig.gaugeClusterVariant)?.label}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
