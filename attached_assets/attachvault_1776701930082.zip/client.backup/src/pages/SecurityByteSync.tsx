import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BackButton } from "@/components/BackButton";
import { Shield, Download, CheckCircle2, AlertCircle, Upload } from "lucide-react";
import { toast } from "sonner";

interface SyncResult {
  success: boolean;
  skimKey?: string;
  secretKey?: string;
  message?: string;
}

export default function SecurityByteSync() {
  const [donorFile, setDonorFile] = useState<File | null>(null);
  const [targetFile, setTargetFile] = useState<File | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<SyncResult | null>(null);

  const handleDonorFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDonorFile(file);
      setSyncResult(null);
    }
  };

  const handleTargetFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setTargetFile(file);
      setSyncResult(null);
    }
  };

  const handleSync = async () => {
    if (!donorFile || !targetFile) {
      toast.error("Please select both donor ECM and target BCM files");
      return;
    }

    setIsSyncing(true);

    try {
      // Read both files
      const donorBuffer = await donorFile.arrayBuffer();
      const targetBuffer = await targetFile.arrayBuffer();
      
      const donorData = new Uint8Array(donorBuffer);
      const targetData = new Uint8Array(targetBuffer);

      // Extract security bytes from donor ECM
      // SKIM Key: typically at offset 0x00-0x03 (4 bytes)
      // Secret Key: typically at offset 0x10-0x1F (16 bytes)
      const skimKeyOffset = 0x00;
      const secretKeyOffset = 0x10;

      const skimKey = donorData.slice(skimKeyOffset, skimKeyOffset + 4);
      const secretKey = donorData.slice(secretKeyOffset, secretKeyOffset + 16);

      // Clone target data for modification
      const syncedData = new Uint8Array(targetData);

      // Write security bytes to target BCM
      // BCM security byte locations (example offsets - adjust based on module)
      const bcmSkimOffset = 0x100;
      const bcmSecretOffset = 0x110;

      syncedData.set(skimKey, bcmSkimOffset);
      syncedData.set(secretKey, bcmSecretOffset);

      // Calculate and update CRC-16/CCITT-FALSE checksum
      const crcData = syncedData.slice(bcmSkimOffset, bcmSecretOffset + 16);
      const crc = calculateCRC16CCITT(crcData);
      const crcOffset = bcmSecretOffset + 16;
      syncedData[crcOffset] = crc & 0xFF;
      syncedData[crcOffset + 1] = (crc >> 8) & 0xFF;

      // Create download blob
      const blob = new Blob([syncedData], { type: "application/octet-stream" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `synced_${targetFile.name}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setSyncResult({
        success: true,
        skimKey: Array.from(skimKey).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
        secretKey: Array.from(secretKey).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
      });

      toast.success("Security bytes synced successfully!");
    } catch (error) {
      toast.error("Failed to sync security bytes: " + (error as Error).message);
      setSyncResult({ success: false, message: (error as Error).message });
    } finally {
      setIsSyncing(false);
    }
  };

  // CRC-16/CCITT-FALSE algorithm
  const calculateCRC16CCITT = (data: Uint8Array): number => {
    let crc = 0xFFFF;
    for (const byte of Array.from(data)) {
      crc ^= (byte << 8);
      for (let i = 0; i < 8; i++) {
        if (crc & 0x8000) {
          crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
        } else {
          crc = (crc << 1) & 0xFFFF;
        }
      }
    }
    return crc;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">SECURITY BYTE SYNC</h1>
            <p className="text-gray-600">
              Transfer SKIM keys from donor ECM to target BCM with CRC correction
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Donor ECM */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Donor ECM (Source)
              </CardTitle>
              <CardDescription>Module containing security keys to extract</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="donor-file">ECM/SKIM EEPROM File</Label>
                <Input
                  id="donor-file"
                  type="file"
                  accept=".bin"
                  onChange={handleDonorFileSelect}
                  className="mt-2"
                />
                {donorFile && (
                  <p className="text-sm text-gray-600 mt-2">
                    {donorFile.name} ({(donorFile.size / 1024).toFixed(2)} KB)
                  </p>
                )}
              </div>
              <div className="text-xs text-gray-500 space-y-1">
                <p>• SKIM Key: Offset 0x00-0x03 (4 bytes)</p>
                <p>• Secret Key: Offset 0x10-0x1F (16 bytes)</p>
              </div>
            </CardContent>
          </Card>

          {/* Target BCM */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Target BCM (Destination)
              </CardTitle>
              <CardDescription>Module to receive security keys</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="target-file">BCM D-FLASH File</Label>
                <Input
                  id="target-file"
                  type="file"
                  accept=".bin"
                  onChange={handleTargetFileSelect}
                  className="mt-2"
                />
                {targetFile && (
                  <p className="text-sm text-gray-600 mt-2">
                    {targetFile.name} ({(targetFile.size / 1024).toFixed(2)} KB)
                  </p>
                )}
              </div>
              <div className="text-xs text-gray-500 space-y-1">
                <p>• Keys written to BCM security area</p>
                <p>• CRC-16/CCITT-FALSE updated automatically</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="pt-6">
            <Button
              onClick={handleSync}
              disabled={isSyncing || !donorFile || !targetFile}
              className="w-full gap-2"
              size="lg"
            >
              {isSyncing ? (
                <>Processing...</>
              ) : (
                <>
                  <Download className="h-5 w-5" />
                  Sync Security Bytes & Download
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {syncResult && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {syncResult.success ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    Sync Successful
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-5 w-5 text-red-600" />
                    Sync Failed
                  </>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {syncResult.success ? (
                <div className="space-y-3 text-sm font-mono">
                  <div>
                    <p className="text-gray-600 mb-1">SKIM Key (4 bytes):</p>
                    <p className="bg-gray-100 p-2 rounded">{syncResult.skimKey}</p>
                  </div>
                  <div>
                    <p className="text-gray-600 mb-1">Secret Key (16 bytes):</p>
                    <p className="bg-gray-100 p-2 rounded break-all">{syncResult.secretKey}</p>
                  </div>
                  <p className="text-green-600 font-sans mt-4">
                    ✓ Security bytes transferred and CRC updated
                  </p>
                </div>
              ) : (
                <p className="text-red-600">{syncResult.message}</p>
              )}
            </CardContent>
          </Card>
        )}

        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-900">⚠️ Important Notes</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-yellow-900 space-y-2">
            <p>• Always keep backups of original module dumps</p>
            <p>• Test synced module on bench before vehicle installation</p>
            <p>• Security byte offsets may vary by module variant</p>
            <p>• Incorrect security bytes will prevent module pairing</p>
            <p>• CRC mismatch will cause module errors</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
