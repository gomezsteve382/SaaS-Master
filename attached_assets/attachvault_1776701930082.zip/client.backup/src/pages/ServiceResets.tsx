import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { trpc } from '@/lib/trpc';
import { RefreshCw, Search, AlertCircle, CheckCircle2, Play, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';

export default function ServiceResets() {
  const [searchQuery, setSearchQuery] = useState('');
  const [executingId, setExecutingId] = useState<number | null>(null);
  const { data: procedures, isLoading } = trpc.alphaOBD.getServiceResetProcedures.useQuery();
  const executeMutation = trpc.procedureExecution.executeServiceReset.useMutation({
    onSuccess: (data) => {
      toast.success(`Procedure executed successfully in ${data.executionTime}ms`);
      setExecutingId(null);
    },
    onError: (error) => {
      toast.error(`Execution failed: ${error.message}`);
      setExecutingId(null);
    },
  });

  const handleExecute = (proc: any) => {
    setExecutingId(proc.id);
    toast.info('Connecting to hardware...');
    executeMutation.mutate({
      procedureId: proc.id,
      procedureName: proc.description.substring(0, 256),
    });
  };

  const filteredProcedures = procedures?.filter((proc: any) =>
    proc.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
          <RefreshCw className="h-10 w-10 text-green-600" />
          Service Resets & Maintenance
        </h1>
        <p className="text-muted-foreground mt-2">
          Oil service intervals, maintenance counters, and service history programming from SRT Lab database
        </p>
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>Found {procedures?.length || 0} service reset procedures</strong> from the SRT Lab database.
          These procedures are for Chrysler/FCA/Stellantis vehicles and require proper diagnostic equipment.
        </AlertDescription>
      </Alert>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search procedures (oil, service, maintenance, odometer...)"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Procedures List */}
      {isLoading ? (
        <div className="text-center py-12">
          <RefreshCw className="h-12 w-12 animate-spin text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Loading procedures...</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredProcedures?.map((proc: any) => (
            <Card key={proc.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                      Procedure ID: {proc.id}
                    </CardTitle>
                    <CardDescription className="mt-2 whitespace-pre-wrap text-sm">
                      {proc.description}
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => handleExecute(proc)}
                    disabled={executingId === proc.id}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {executingId === proc.id ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Executing...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Execute
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
            </Card>
          ))}

          {filteredProcedures?.length === 0 && (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                No procedures found matching "{searchQuery}"
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
