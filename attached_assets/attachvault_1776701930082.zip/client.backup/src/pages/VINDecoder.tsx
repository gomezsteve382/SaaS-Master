/**
 * VIN Decoder Page
 * Standalone page for decoding VINs
 */

import { VINDecoderPanel } from "@/components/VINDecoderPanel";
import { BackButton } from "@/components/BackButton";

export default function VINDecoder() {
  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center gap-4">
        <BackButton />
        <div>
          <h1 className="text-3xl font-bold">VIN Decoder</h1>
          <p className="text-muted-foreground">
            Decode Vehicle Identification Numbers to reveal manufacturer, year, engine, and assembly plant information
          </p>
        </div>
      </div>
      
      <VINDecoderPanel />
    </div>
  );
}
