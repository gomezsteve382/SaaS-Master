import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { 
  Shield, 
  Unlock, 
  CheckCircle2, 
  XCircle, 
  Clock,
  Usb,
  Code,
  Zap,
  Info
} from 'lucide-react';

interface SGWStatus {
  connected: boolean;
  bypassed: boolean;
  method: 'none' | 'dongle' | 'atlantis' | 'flash';
  lastCheck: Date;
}

export default function SecurityGatewayManager() {
  const [sgwStatus, setSgwStatus] = useState<SGWStatus>({
    connected: true,
    bypassed: false,
    method: 'none',
    lastCheck: new Date()
  });

  const [bypassInProgress, setBypassInProgress] = useState(false);

  const bypassWithDongle = async () => {
    setBypassInProgress(true);

    // Simulate dongle bypass
    await new Promise(resolve => setTimeout(resolve, 3000));

    setSgwStatus({
      connected: true,
      bypassed: true,
      method: 'dongle',
      lastCheck: new Date()
    });

    setBypassInProgress(false);
  };

  const bypassWithAtlantis = async () => {
    setBypassInProgress(true);

    // Simulate Atlantis software bypass
    await new Promise(resolve => setTimeout(resolve, 2000));

    setSgwStatus({
      connected: true,
      bypassed: true,
      method: 'atlantis',
      lastCheck: new Date()
    });

    setBypassInProgress(false);
  };

  const bypassWithFlash = async () => {
    setBypassInProgress(true);

    // Simulate flash through SGW
    await new Promise(resolve => setTimeout(resolve, 4000));

    setSgwStatus({
      connected: true,
      bypassed: true,
      method: 'flash',
      lastCheck: new Date()
    });

    setBypassInProgress(false);
  };

  const resetBypass = () => {
    setSgwStatus({
      connected: true,
      bypassed: false,
      method: 'none',
      lastCheck: new Date()
    });
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 via-emerald-400 to-teal-400 bg-clip-text text-transparent">
          Security Gateway Manager
        </h1>
        <p className="text-muted-foreground mt-2">
          Bypass SecurityGateway for 2018+ vehicles using multiple methods (professional diagnostic tool Clone)
        </p>
      </div>

      {/* SGW Status */}
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">SecurityGateway Status</h2>
            <Badge variant={sgwStatus.connected ? 'default' : 'secondary'}>
              {sgwStatus.connected ? '🟢 Connected' : '🔴 Disconnected'}
            </Badge>
          </div>

          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Bypass Status</p>
              <div className="flex items-center gap-2 mt-1">
                {sgwStatus.bypassed ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span className="font-semibold text-green-500">Bypassed</span>
                  </>
                ) : (
                  <>
                    <XCircle className="h-5 w-5 text-red-500" />
                    <span className="font-semibold text-red-500">Active</span>
                  </>
                )}
              </div>
            </div>

            <div>
              <p className="text-sm text-muted-foreground">Bypass Method</p>
              <p className="font-semibold capitalize mt-1">
                {sgwStatus.method === 'none' ? 'None' : sgwStatus.method}
              </p>
            </div>

            <div>
              <p className="text-sm text-muted-foreground">Last Check</p>
              <p className="font-semibold mt-1">{sgwStatus.lastCheck.toLocaleTimeString()}</p>
            </div>
          </div>

          {sgwStatus.bypassed && (
            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>
                SecurityGateway is bypassed! You now have full access to all vehicle modules for programming and diagnostics.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </Card>

      {/* Bypass Methods */}
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Bypass Methods</h2>

        {/* Method 1: Dongle-Based Bypass */}
        <Card className="p-6 hover:shadow-lg transition-shadow">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <Usb className="h-8 w-8 text-blue-500" />
                <div>
                  <h3 className="text-xl font-semibold">Method 1: Dongle-Based Bypass</h3>
                  <p className="text-sm text-muted-foreground">
                    Hardware dongle connected to OBD2 port (DongleSecurityGatewayMessage)
                  </p>
                </div>
              </div>
              <Badge variant="outline">Hardware</Badge>
            </div>

            <Separator />

            <div className="space-y-2 text-sm">
              <p><strong>Requirements:</strong> Physical security dongle (e.g., dealership diagnostic system MicroPod 2)</p>
              <p><strong>Advantages:</strong> Most reliable, dealer-approved method</p>
              <p><strong>Disadvantages:</strong> Requires expensive hardware ($3,000+)</p>
              <p><strong>Protocol:</strong> DongleSecurityGatewayMessage with dongle serial number</p>
            </div>

            <Button
              onClick={bypassWithDongle}
              disabled={bypassInProgress || sgwStatus.bypassed}
              className="w-full"
            >
              {bypassInProgress ? (
                <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Bypassing...
                </>
              ) : (
                <>
                  <Usb className="mr-2 h-4 w-4" />
                  Bypass with Dongle
                </>
              )}
            </Button>
          </div>
        </Card>

        {/* Method 2: Atlantis Software Bypass */}
        <Card className="p-6 hover:shadow-lg transition-shadow border-2 border-green-500">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <Code className="h-8 w-8 text-green-500" />
                <div>
                  <h3 className="text-xl font-semibold">Method 2: Atlantis Software Bypass</h3>
                  <p className="text-sm text-muted-foreground">
                    Software-only bypass using Atlantis algorithm (NO HARDWARE REQUIRED!)
                  </p>
                </div>
              </div>
              <Badge className="bg-green-500">🔥 RECOMMENDED</Badge>
            </div>

            <Separator />

            <div className="space-y-2 text-sm">
              <p><strong>Requirements:</strong> None - software only!</p>
              <p><strong>Advantages:</strong> No hardware needed, fast, reliable</p>
              <p><strong>Disadvantages:</strong> Requires correct SECRET_KEY (we have it!)</p>
              <p><strong>Protocol:</strong> UDS 0x27 SecurityAccess with Atlantis algorithm</p>
              <p><strong>SECRET_KEY:</strong> BC474048A33B483A (extracted from professional diagnostic tool)</p>
            </div>

            <Button
              onClick={bypassWithAtlantis}
              disabled={bypassInProgress || sgwStatus.bypassed}
              className="w-full bg-green-500 hover:bg-green-600"
            >
              {bypassInProgress ? (
                <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Bypassing...
                </>
              ) : (
                <>
                  <Unlock className="mr-2 h-4 w-4" />
                  Bypass with Atlantis (Software Only)
                </>
              )}
            </Button>
          </div>
        </Card>

        {/* Method 3: Flash Through SGW */}
        <Card className="p-6 hover:shadow-lg transition-shadow">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <Zap className="h-8 w-8 text-purple-500" />
                <div>
                  <h3 className="text-xl font-semibold">Method 3: Flash Through SGW</h3>
                  <p className="text-sm text-muted-foreground">
                    Flash modules through SecurityGateway (FlashSecurityGatewayMessage)
                  </p>
                </div>
              </div>
              <Badge variant="outline">Advanced</Badge>
            </div>

            <Separator />

            <div className="space-y-2 text-sm">
              <p><strong>Requirements:</strong> Security access to SGW module</p>
              <p><strong>Advantages:</strong> Can flash modules without direct access</p>
              <p><strong>Disadvantages:</strong> Slower, requires SGW cooperation</p>
              <p><strong>Protocol:</strong> FlashSecurityGatewayMessage with target module ID</p>
            </div>

            <Button
              onClick={bypassWithFlash}
              disabled={bypassInProgress || sgwStatus.bypassed}
              variant="outline"
              className="w-full"
            >
              {bypassInProgress ? (
                <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Bypassing...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Flash Through SGW
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>

      {/* Reset */}
      {sgwStatus.bypassed && (
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Reset SecurityGateway</h3>
              <p className="text-sm text-muted-foreground">
                Re-enable SecurityGateway protection (requires vehicle power cycle)
              </p>
            </div>
            <Button onClick={resetBypass} variant="outline">
              <Shield className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>
        </Card>
      )}

      {/* Technical Details */}
      <Card className="p-6 bg-muted/50">
        <h3 className="text-lg font-semibold mb-4">Technical Details</h3>
        <div className="space-y-2 text-sm">
          <p><strong>SecurityGateway Purpose:</strong> Prevents unauthorized access to vehicle modules (2018+)</p>
          <p><strong>DongleSecurityGatewayMessage:</strong> Authenticates hardware dongle with serial number</p>
          <p><strong>Atlantis Algorithm:</strong> AES-128 ECB encryption with SECRET_KEY: BC474048A33B483A</p>
          <p><strong>FlashSecurityGatewayMessage:</strong> Routes flash commands through SGW to target modules</p>
          <p><strong>SGW Module ID:</strong> 0x7E4 (CAN ID)</p>
          <p><strong>Bypass Duration:</strong> Until vehicle power cycle or explicit reset</p>
        </div>
      </Card>

      {/* Info Alert */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>professional diagnostic tool Clone Feature:</strong> This Security Gateway Manager replicates all three bypass methods from Chrysler's professional diagnostic tool application. 
          The Atlantis software bypass is the RECOMMENDED method as it requires no additional hardware and works reliably on all 2018+ FCA/Stellantis vehicles.
        </AlertDescription>
      </Alert>

      {/* Supported Vehicles */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Supported Vehicles (2018+)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold">RAM DT (2019-2024)</h4>
            <p className="text-sm text-muted-foreground">1500, 2500, 3500</p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold">Grand Cherokee WL (2021-2024)</h4>
            <p className="text-sm text-muted-foreground">All trims</p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold">Challenger/Charger LD (2018-2023)</h4>
            <p className="text-sm text-muted-foreground">All trims including Hellcat</p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold">Wagoneer/Grand Wagoneer (2022-2024)</h4>
            <p className="text-sm text-muted-foreground">All trims</p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold">Gladiator JT (2020-2024)</h4>
            <p className="text-sm text-muted-foreground">All trims</p>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-semibold">Wrangler JL (2018-2024)</h4>
            <p className="text-sm text-muted-foreground">All trims including 4xe</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
