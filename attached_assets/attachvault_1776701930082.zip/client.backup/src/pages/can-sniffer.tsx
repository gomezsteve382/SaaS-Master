import { useState, useCallback, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { BackButton } from "@/components/BackButton";
import { 
  ArrowLeft, Download, Loader2, Radio, Trash2, Eye, EyeOff,
  Play, Square, RefreshCw, Plus, Wifi, FileCode, Cpu
} from "lucide-react";
import { 
  CANSnifferProtocol, 
  SniffedFrame, 
  SecurityCapture,
  getSnifferFrameColor,
  getSnifferFrameEmoji,
  processSniffedFrame,
  getSnifferCaptures,
  clearSnifferCaptures,
  loadSnifferCaptures,
  exportSnifferCapturesToJSON,
  formatHexBytes,
  getPairedPorts,
  requestNewPort,
  forgetAllPorts as forgetAllPortsUtil,
  SerialPortInfo,
} from "@shared/obd2-protocol";
import { cn } from "@/lib/utils";

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

export default function CANSniffer() {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [isSniffing, setIsSniffing] = useState(false);
  const [protocol, setProtocol] = useState<CANSnifferProtocol | null>(null);
  
  const [sniffedFrames, setSniffedFrames] = useState<SniffedFrame[]>([]);
  const [securityCaptures, setSecurityCaptures] = useState<SecurityCapture[]>([]);
  const [frameCount, setFrameCount] = useState(0);
  
  const [isInIframe, setIsInIframe] = useState(false);
  const [serialSupported, setSerialSupported] = useState(true);
  const [availablePorts, setAvailablePorts] = useState<SerialPortInfo[]>([]);
  const [selectedPortIndex, setSelectedPortIndex] = useState<number>(-1);
  
  const [showOnlySecurityFrames, setShowOnlySecurityFrames] = useState(false);
  const [autoscroll, setAutoscroll] = useState(true);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const maxFrames = 500;

  const refreshPorts = useCallback(async () => {
    const ports = await getPairedPorts();
    setAvailablePorts(ports);
    if (ports.length > 0 && selectedPortIndex === -1) {
      setSelectedPortIndex(0);
    }
  }, [selectedPortIndex]);

  useEffect(() => {
    const inIframe = window !== window.top;
    setIsInIframe(inIframe);
    setSerialSupported('serial' in navigator);
    refreshPorts();
    loadSnifferCaptures();
    setSecurityCaptures(getSnifferCaptures());
  }, []);

  useEffect(() => {
    if (autoscroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [sniffedFrames, autoscroll]);

  const openInNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  const handlePairNewPort = async () => {
    const port = await requestNewPort();
    if (port) {
      await refreshPorts();
    }
  };

  const forgetAllPorts = async () => {
    await forgetAllPortsUtil();
    setAvailablePorts([]);
    setSelectedPortIndex(-1);
  };

  const handleConnect = async () => {
    if (selectedPortIndex < 0 || selectedPortIndex >= availablePorts.length) {
      console.error('No port selected');
      return;
    }

    setConnectionStatus('connecting');

    try {
      const portInfo = availablePorts[selectedPortIndex];
      console.log(`Connecting to ${portInfo.displayName}...`);
      const sniffer = new CANSnifferProtocol();
      const connected = await sniffer.connectToPort(portInfo.port);
      
      if (connected) {
        setProtocol(sniffer);
        setConnectionStatus('connected');
        console.log('CAN Sniffer connected successfully');
      } else {
        setConnectionStatus('error');
        const errorDetail = sniffer.getLastError();
        console.error('Connection failed:', errorDetail);
        alert(`Connection failed: ${errorDetail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Connection error:', error);
      setConnectionStatus('error');
      alert(`Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const handleDisconnect = async () => {
    if (protocol) {
      protocol.stopSniffing();
      await protocol.disconnect();
    }
    setProtocol(null);
    setConnectionStatus('disconnected');
    setIsSniffing(false);
  };

  const handleStartSniffing = () => {
    if (!protocol) return;

    setIsSniffing(true);
    setSniffedFrames([]);
    setFrameCount(0);

    protocol.startSniffing((frame: SniffedFrame) => {
      console.log(`[CANSniffer Callback] Frame received: ${frame.canIdHex} -> ${frame.dataHex}`);
      setSniffedFrames(prev => {
        const updated = [...prev, frame];
        if (updated.length > maxFrames) {
          return updated.slice(-maxFrames);
        }
        return updated;
      });
      setFrameCount(prev => prev + 1);

      const capture = processSniffedFrame(frame);
      if (capture) {
        setSecurityCaptures(getSnifferCaptures());
      }
    });
  };

  const handleStopSniffing = () => {
    if (protocol) {
      protocol.stopSniffing();
    }
    setIsSniffing(false);
  };

  const handleClearFrames = () => {
    setSniffedFrames([]);
    setFrameCount(0);
  };

  const handleClearCaptures = () => {
    clearSnifferCaptures();
    setSecurityCaptures([]);
  };

  const handleExportCaptures = () => {
    const json = exportSnifferCapturesToJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `can_sniffer_captures_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadArduinoSketch = () => {
    const sketchCode = `/*
 * THAT ECM GUY - Passive CAN Sniffer Sketch
 * For Arduino Uno R3 with MCP2515 CAN Shield
 * 
 * IMPORTANT: This sketch uses LISTEN-ONLY mode!
 * It will NOT interfere with other tools (Autel, dealership diagnostic system, Alpha OBD, etc.)
 * The Arduino only receives CAN frames - it never transmits anything,
 * including ACK bits, so it won't disrupt other devices on the bus.
 * 
 * This sketch passively listens to ALL CAN bus traffic and outputs
 * each frame to serial in the format: ID:HEXDATA
 * 
 * Example output:
 *   7E8:0362F1905A5A5A
 *   7E0:0322F190
 *   
 * Hardware:
 *   - Arduino Uno R3
 *   - MCP2515 CAN Shield (CS pin 10, INT pin 2)
 *   - OBD2 Y-Splitter cable (to connect both Arduino and Autel/scan tool)
 *   
 * Install Library:
 *   Arduino IDE -> Sketch -> Include Library -> Manage Libraries
 *   Search for "mcp_can" by coryjfowler and install it
 *   
 * Upload:
 *   1. Select Board: Arduino Uno
 *   2. Select Port: Your Arduino's COM port
 *   3. Click Upload
 *   
 * Usage:
 *   1. Connect OBD2 Y-splitter to vehicle
 *   2. Connect Autel/scan tool to one port
 *   3. Connect Arduino CAN shield to other port
 *   4. Open THAT ECM GUY CAN Sniffer page
 *   5. Select serial port and click "Start Sniffing"
 *   6. Use Autel to perform security access - Arduino will capture the traffic
 */

#include <SPI.h>
#include <mcp_can.h>

// MCP2515 Chip Select pin - most shields use pin 10
// If yours uses pin 9, change this
const int SPI_CS_PIN = 10;

// Interrupt pin - most shields use pin 2
const int CAN_INT_PIN = 2;

// CAN bus speed - 500kbps for Chrysler/FCA/Stellantis
// Change to CAN_250KBPS if your vehicle uses 250k
#define CAN_SPEED CAN_500KBPS

// Crystal frequency on your MCP2515 module
// Most modules use 8MHz, some use 16MHz
// Change to MCP_16MHZ if yours is 16MHz
#define CAN_CLOCK MCP_8MHZ

MCP_CAN CAN(SPI_CS_PIN);

void setup() {
  // Initialize serial at 115200 baud (must match CAN Sniffer page)
  Serial.begin(115200);
  while (!Serial) {
    ; // Wait for serial port to connect (needed for some boards)
  }
  
  Serial.println("THAT ECM GUY - CAN Sniffer");
  Serial.println("Initializing MCP2515...");
  
  // Initialize CAN controller
  // Try up to 10 times
  int attempts = 0;
  while (CAN_OK != CAN.begin(MCP_ANY, CAN_SPEED, CAN_CLOCK)) {
    Serial.println("CAN init failed, retrying...");
    delay(500);
    attempts++;
    if (attempts >= 10) {
      Serial.println("CAN init FAILED! Check wiring.");
      while (1); // Halt
    }
  }
  
  Serial.println("CAN init OK!");
  
  // CRITICAL: Set to LISTEN-ONLY mode
  // This prevents the Arduino from sending ACK bits on the CAN bus
  // which would interfere with other tools like Autel, dealership diagnostic system, Alpha OBD
  CAN.setMode(MCP_LISTENONLY);
  
  // Accept all messages - no filtering
  // Mask = 0 means don't care about any ID bits
  CAN.init_Mask(0, 0, 0x00000000);
  CAN.init_Mask(1, 0, 0x00000000);
  CAN.init_Filt(0, 0, 0x00000000);
  CAN.init_Filt(1, 0, 0x00000000);
  CAN.init_Filt(2, 0, 0x00000000);
  CAN.init_Filt(3, 0, 0x00000000);
  CAN.init_Filt(4, 0, 0x00000000);
  CAN.init_Filt(5, 0, 0x00000000);
  
  Serial.println("Listening for CAN traffic...");
  Serial.println("---");
}

// Buffer for building output string
char outputBuffer[32];
char hexChars[] = "0123456789ABCDEF";

void loop() {
  unsigned long canId;
  unsigned char len = 0;
  unsigned char buf[8];
  
  // Check if message is available
  if (CAN_MSGAVAIL == CAN.checkReceive()) {
    // Read the message
    CAN.readMsgBuf(&canId, &len, buf);
    
    // Check if extended ID (29-bit) - mask off the extended bit flag
    if (canId & 0x80000000) {
      canId &= 0x1FFFFFFF; // Extended ID
    } else {
      canId &= 0x7FF; // Standard 11-bit ID
    }
    
    // Build output string: ID:HEXDATA
    // Format CAN ID as 3 hex chars (for standard IDs) or 8 for extended
    int pos = 0;
    
    // Output CAN ID (3 hex digits for standard, 8 for extended)
    if (canId <= 0x7FF) {
      // Standard 11-bit ID - output as 3 hex chars
      outputBuffer[pos++] = hexChars[(canId >> 8) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 4) & 0x0F];
      outputBuffer[pos++] = hexChars[canId & 0x0F];
    } else {
      // Extended 29-bit ID - output as 8 hex chars
      outputBuffer[pos++] = hexChars[(canId >> 28) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 24) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 20) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 16) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 12) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 8) & 0x0F];
      outputBuffer[pos++] = hexChars[(canId >> 4) & 0x0F];
      outputBuffer[pos++] = hexChars[canId & 0x0F];
    }
    
    // Separator
    outputBuffer[pos++] = ':';
    
    // Output data bytes as hex
    for (int i = 0; i < len; i++) {
      outputBuffer[pos++] = hexChars[(buf[i] >> 4) & 0x0F];
      outputBuffer[pos++] = hexChars[buf[i] & 0x0F];
    }
    
    // Null terminate
    outputBuffer[pos] = '\\0';
    
    // Send to serial
    Serial.println(outputBuffer);
  }
}
`;
    const blob = new Blob([sketchCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'THAT_ECM_GUY_CAN_Sniffer.ino';
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredFrames = showOnlySecurityFrames 
    ? sniffedFrames.filter(f => 
        f.frameType === 'security_seed' || 
        f.frameType === 'security_key' || 
        f.frameType === 'security_success' || 
        f.frameType === 'security_reject' ||
        f.frameType === 'csn_response'
      )
    : sniffedFrames;

  const getConnectionBadge = () => {
    switch (connectionStatus) {
      case 'connected':
        return <Badge className="bg-green-500">Connected</Badge>;
      case 'connecting':
        return <Badge className="bg-yellow-500">Connecting...</Badge>;
      case 'error':
        return <Badge className="bg-red-500">Error</Badge>;
      default:
        return <Badge variant="outline">Disconnected</Badge>;
    }
  };

  if (isInIframe && serialSupported) {
    return (
      <div className="min-h-screen bg-background p-6 flex items-center justify-center">
        <Card className="max-w-md border-yellow-500/30">
          <CardHeader>
            <CardTitle className="text-yellow-400 flex items-center gap-2">
              <Radio className="w-5 h-5" />
              CAN Sniffer - WebSerial Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-white/70">
              CAN Sniffer requires WebSerial API which doesn't work inside iframes.
            </p>
            <Button onClick={openInNewTab} className="w-full" data-testid="button-open-new-tab">
              Open in New Tab
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!serialSupported) {
    return (
      <div className="min-h-screen bg-background p-6 flex items-center justify-center">
        <Card className="max-w-md border-red-500/30">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Radio className="w-5 h-5" />
              WebSerial Not Supported
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-white/70">
              Your browser doesn't support WebSerial. Please use Chrome or Edge.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-white/10 bg-card/50">
        <div className="container mx-auto px-4 py-3">
          <BackButton />
      <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" data-testid="button-back">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-primary" />
                <h1 className="text-lg font-bold" data-testid="text-page-title">CAN SNIFFER</h1>
                <Badge variant="outline" className="text-xs">PASSIVE MODE</Badge>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {getConnectionBadge()}
              {isSniffing && (
                <Badge className="bg-green-500 animate-pulse">
                  SNIFFING ({frameCount} frames)
                </Badge>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-1 space-y-4">
            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Wifi className="w-4 h-4" />
                  CONNECTION
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs text-white/70">Arduino Port</Label>
                  <div className="flex gap-1">
                    <Select 
                      value={selectedPortIndex >= 0 ? selectedPortIndex.toString() : ''} 
                      onValueChange={(v) => setSelectedPortIndex(parseInt(v))}
                      disabled={connectionStatus === 'connected'}
                    >
                      <SelectTrigger className="text-xs flex-1" data-testid="select-port">
                        <SelectValue placeholder="Select port..." />
                      </SelectTrigger>
                      <SelectContent>
                        {availablePorts.length === 0 ? (
                          <SelectItem value="none" disabled>No ports paired</SelectItem>
                        ) : (
                          availablePorts.map((portInfo, idx) => (
                            <SelectItem key={idx} value={idx.toString()}>
                              {portInfo.displayName}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="h-8 px-2"
                      onClick={handlePairNewPort}
                      disabled={connectionStatus === 'connected'}
                      data-testid="button-pair-port"
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="h-8 px-2"
                      onClick={refreshPorts}
                      disabled={connectionStatus === 'connected'}
                      data-testid="button-refresh-ports"
                    >
                      <RefreshCw className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {connectionStatus !== 'connected' ? (
                  <Button 
                    className="w-full"
                    onClick={handleConnect}
                    disabled={selectedPortIndex < 0 || connectionStatus === 'connecting'}
                    data-testid="button-connect"
                  >
                    {connectionStatus === 'connecting' ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Radio className="w-4 h-4 mr-2" />
                    )}
                    Connect
                  </Button>
                ) : (
                  <Button 
                    variant="destructive"
                    className="w-full"
                    onClick={handleDisconnect}
                    data-testid="button-disconnect"
                  >
                    Disconnect
                  </Button>
                )}

                {availablePorts.length > 0 && connectionStatus !== 'connected' && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="w-full text-xs text-white/40"
                    onClick={forgetAllPorts}
                    data-testid="button-forget-ports"
                  >
                    Clear Paired Ports
                  </Button>
                )}
              </CardContent>
            </Card>

            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2">
                  <Radio className="w-4 h-4" />
                  SNIFF CONTROL
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!isSniffing ? (
                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={handleStartSniffing}
                    disabled={connectionStatus !== 'connected'}
                    data-testid="button-start-sniffing"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start Sniffing
                  </Button>
                ) : (
                  <Button 
                    className="w-full bg-red-600 hover:bg-red-700"
                    onClick={handleStopSniffing}
                    data-testid="button-stop-sniffing"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Stop Sniffing
                  </Button>
                )}

                <div className="flex items-center justify-between">
                  <Label className="text-xs text-white/70">Security frames only</Label>
                  <Switch 
                    checked={showOnlySecurityFrames}
                    onCheckedChange={setShowOnlySecurityFrames}
                    data-testid="switch-security-only"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label className="text-xs text-white/70">Auto-scroll</Label>
                  <Switch 
                    checked={autoscroll}
                    onCheckedChange={setAutoscroll}
                    data-testid="switch-autoscroll"
                  />
                </div>

                <Button 
                  variant="outline"
                  className="w-full"
                  onClick={handleClearFrames}
                  data-testid="button-clear-frames"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear Log
                </Button>
              </CardContent>
            </Card>

            <Card className="border-white/10 border-green-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2 text-green-400">
                  <Eye className="w-4 h-4" />
                  SECURITY CAPTURES
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-green-500/10 border-green-500/30">
                  <AlertTitle className="text-xs text-green-400">
                    {securityCaptures.length} Seed/Key Pair{securityCaptures.length !== 1 ? 's' : ''}
                  </AlertTitle>
                  <AlertDescription className="text-xs text-white/60">
                    Complete security exchanges are captured automatically
                  </AlertDescription>
                </Alert>

                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={handleExportCaptures}
                    disabled={securityCaptures.length === 0}
                    data-testid="button-export-captures"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                  <Button 
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={handleClearCaptures}
                    disabled={securityCaptures.length === 0}
                    data-testid="button-clear-captures"
                  >
                    <Trash2 className="w-3 h-3 mr-1" />
                    Clear
                  </Button>
                </div>

                {securityCaptures.length > 0 && (
                  <ScrollArea className="h-40">
                    <div className="space-y-2">
                      {securityCaptures.slice(-10).reverse().map((capture) => (
                        <div 
                          key={capture.id}
                          className={cn(
                            "text-xs p-2 rounded border",
                            capture.success 
                              ? "border-green-500/30 bg-green-500/10" 
                              : "border-red-500/30 bg-red-500/10"
                          )}
                        >
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-mono text-white/70">
                              0x{capture.canId.toString(16).toUpperCase()}
                            </span>
                            <Badge 
                              className={capture.success ? "bg-green-500" : "bg-red-500"}
                            >
                              {capture.success ? 'OK' : 'FAIL'}
                            </Badge>
                          </div>
                          {capture.seed && (
                            <div className="font-mono text-green-400 truncate">
                              Seed: {formatHexBytes(capture.seed)}
                            </div>
                          )}
                          {capture.key && (
                            <div className="font-mono text-yellow-400 truncate">
                              Key: {formatHexBytes(capture.key)}
                            </div>
                          )}
                          {capture.csn && (
                            <div className="font-mono text-blue-400 truncate">
                              CSN: {formatHexBytes(capture.csn)}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>

            <Card className="border-white/10 border-cyan-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono flex items-center gap-2 text-cyan-400">
                  <Cpu className="w-4 h-4" />
                  ARDUINO SKETCH
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-white/60">
                  Download the passive CAN sniffer sketch for your Arduino Uno R3 + MCP2515 shield.
                </p>
                <Button 
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                  onClick={handleDownloadArduinoSketch}
                  data-testid="button-download-sketch"
                >
                  <FileCode className="w-4 h-4 mr-2" />
                  Download .ino Sketch
                </Button>
                <div className="text-[10px] text-white/40 space-y-1">
                  <p>1. Open in Arduino IDE</p>
                  <p>2. Install mcp_can library</p>
                  <p>3. Upload to Arduino</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono">FRAME LEGEND</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 text-xs">
                  <div className="flex items-center gap-2">
                    <span>🌱</span>
                    <span className="text-green-400">Security Seed (67 01/03/05)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>🔑</span>
                    <span className="text-yellow-400">Security Key (27 02/04/06)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>✅</span>
                    <span className="text-emerald-400">Key Accepted (67 02/04/06)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>❌</span>
                    <span className="text-red-400">Key Rejected (7F 27 xx)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>🔢</span>
                    <span className="text-blue-400">CSN Response (62 F1 8C)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>🚗</span>
                    <span className="text-purple-400">VIN Response (62 F1 90)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>⚠️</span>
                    <span className="text-orange-400">Negative Response (7F xx)</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Card className="border-white/10 h-[calc(100vh-8rem)]">
              <CardHeader className="pb-3 border-b border-white/10">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-mono flex items-center gap-2">
                    <Radio className="w-4 h-4" />
                    LIVE CAN TRAFFIC
                  </CardTitle>
                  <div className="flex items-center gap-2 text-xs text-white/50">
                    <span>{filteredFrames.length} / {sniffedFrames.length} frames</span>
                    {showOnlySecurityFrames && (
                      <Badge variant="outline" className="text-xs">Filtered</Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 h-[calc(100%-4rem)]">
                <ScrollArea className="h-full" ref={scrollRef}>
                  <div className="p-2 space-y-0.5 font-mono text-xs">
                    {filteredFrames.length === 0 ? (
                      <div className="text-center text-white/30 py-8">
                        {isSniffing 
                          ? "Waiting for CAN traffic..." 
                          : "Connect and start sniffing to see traffic"
                        }
                      </div>
                    ) : (
                      filteredFrames.map((frame) => (
                        <div 
                          key={frame.id}
                          className={cn(
                            "px-2 py-1 rounded flex items-start gap-2",
                            getSnifferFrameColor(frame.frameType)
                          )}
                        >
                          <span className="text-white/30 w-20 flex-shrink-0">
                            {new Date(frame.timestamp).toISOString().slice(11, 23)}
                          </span>
                          <span className="w-4 flex-shrink-0">
                            {getSnifferFrameEmoji(frame.frameType)}
                          </span>
                          <span className="w-12 flex-shrink-0 text-primary">
                            {frame.canIdHex}
                          </span>
                          <span className="flex-1 font-mono">
                            {frame.dataHex.match(/.{1,2}/g)?.join(' ') || frame.dataHex}
                          </span>
                          <span className="text-white/50 flex-shrink-0 w-48 text-right truncate">
                            {frame.parsed?.serviceName}
                            {frame.parsed?.didName && ` - ${frame.parsed.didName}`}
                            {frame.parsed?.seed && ` [${frame.parsed.seed.length}B]`}
                            {frame.parsed?.key && ` [${frame.parsed.key.length}B]`}
                            {frame.parsed?.nrcDescription && ` (${frame.parsed.nrcDescription})`}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
