import { useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, Download, FileCheck, AlertCircle, CheckCircle2, Trash2, Plus } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface FileToProcess {
  id: string;
  filename: string;
  fileData: string; // Base64
  size: number;
  moduleType?: string;
  originalVIN?: string;
  newVIN?: string;
  status: 'pending' | 'processing' | 'success' | 'error';
  error?: string;
}

export default function VINBatchPatcher() {
  const { toast } = useToast();
  const [files, setFiles] = useState<FileToProcess[]>([]);
  const [globalNewVIN, setGlobalNewVIN] = useState('');
  const [useGlobalVIN, setUseGlobalVIN] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [patchedResults, setPatchedResults] = useState<any[]>([]);

  const batchPatchMutation = trpc.vinBatchPatcher.batchPatch.useMutation();
  const createZipMutation = trpc.vinBatchPatcher.createZipArchive.useMutation();

  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = e.target.files;
    if (!uploadedFiles || uploadedFiles.length === 0) return;

    const newFiles: FileToProcess[] = [];

    for (let i = 0; i < uploadedFiles.length; i++) {
      const file = uploadedFiles[i];
      
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds 10MB limit`,
          variant: "destructive",
        });
        continue;
      }

      try {
        const arrayBuffer = await file.arrayBuffer();
        const data = new Uint8Array(arrayBuffer);
        const base64 = btoa(String.fromCharCode.apply(null, Array.from(data) as any));

        newFiles.push({
          id: Math.random().toString(36).substr(2, 9),
          filename: file.name,
          fileData: base64,
          size: file.size,
          status: 'pending',
        });
      } catch (error) {
        toast({
          title: "Upload failed",
          description: `Failed to read ${file.name}`,
          variant: "destructive",
        });
      }
    }

    setFiles(prev => [...prev, ...newFiles]);
    toast({
      title: "Files added",
      description: `${newFiles.length} file(s) added to batch`,
    });
  }, [toast]);

  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const updateFileVIN = (id: string, newVIN: string) => {
    setFiles(prev => prev.map(f => 
      f.id === id ? { ...f, newVIN } : f
    ));
  };

  const processBatch = async () => {
    if (files.length === 0) {
      toast({
        title: "No files",
        description: "Please add files to process",
        variant: "destructive",
      });
      return;
    }

    // Validate VINs
    const newVINs = useGlobalVIN 
      ? [globalNewVIN]
      : files.map(f => f.newVIN || '');

    const invalidVINs = newVINs.filter(vin => !/^[A-HJ-NPR-Z0-9]{17}$/.test(vin));
    if (invalidVINs.length > 0) {
      toast({
        title: "Invalid VIN",
        description: "All VINs must be exactly 17 characters (alphanumeric, no I/O/Q)",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setProgress(0);

    try {
      const result = await batchPatchMutation.mutateAsync({
        files: files.map(f => ({ filename: f.filename, fileData: f.fileData })),
        newVINs: useGlobalVIN ? [globalNewVIN] : files.map(f => f.newVIN!),
      });

      setPatchedResults(result.patchedFiles);
      setProgress(100);

      toast({
        title: "Batch processing complete",
        description: `${result.patchedFiles.length} file(s) patched successfully`,
      });

      if (result.errors.length > 0) {
        toast({
          title: "Some files failed",
          description: `${result.errors.length} file(s) encountered errors`,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Batch processing failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadAllAsZip = async () => {
    if (patchedResults.length === 0) {
      toast({
        title: "No patched files",
        description: "Process files first before downloading",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await createZipMutation.mutateAsync({
        files: patchedResults.map(f => ({
          filename: f.filename,
          fileData: f.patchedData,
        })),
      });

      // Open download URL
      window.open(result.downloadUrl, '_blank');

      toast({
        title: "ZIP created",
        description: `Archive size: ${(result.size / 1024).toFixed(2)} KB`,
      });
    } catch (error) {
      toast({
        title: "ZIP creation failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  const downloadSingle = (fileData: string, filename: string) => {
    const buffer = atob(fileData);
    const bytes = new Uint8Array(buffer.length);
    for (let i = 0; i < buffer.length; i++) {
      bytes[i] = buffer.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container py-8 max-w-7xl">
      <BackButton />
      
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">VIN Batch Patcher</h1>
        <p className="text-muted-foreground">
          Patch multiple EEPROM dumps with new VINs and automatically recalculate CRC checksums
        </p>
      </div>

      <Tabs defaultValue="upload" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upload">Upload Files</TabsTrigger>
          <TabsTrigger value="configure">Configure VINs</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          <Card className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="file-upload">Upload EEPROM Dumps</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Select multiple .bin files (BCM, RFHUB, SmartBox supported)
                </p>
                <Input
                  id="file-upload"
                  type="file"
                  accept=".bin,.hex,.eep,.dump"
                  multiple
                  onChange={handleFileUpload}
                  className="cursor-pointer"
                />
              </div>

              {files.length > 0 && (
                <Alert>
                  <FileCheck className="h-4 w-4" />
                  <AlertDescription>
                    {files.length} file(s) ready for processing
                  </AlertDescription>
                </Alert>
              )}

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Filename</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {files.map(file => (
                    <TableRow key={file.id}>
                      <TableCell className="font-medium">{file.filename}</TableCell>
                      <TableCell>{(file.size / 1024).toFixed(2)} KB</TableCell>
                      <TableCell>
                        <Badge variant={
                          file.status === 'success' ? 'default' :
                          file.status === 'error' ? 'destructive' :
                          'secondary'
                        }>
                          {file.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFile(file.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="configure" className="space-y-6">
          <Card className="p-6">
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <input
                  type="checkbox"
                  id="use-global-vin"
                  checked={useGlobalVIN}
                  onChange={(e) => setUseGlobalVIN(e.target.checked)}
                  className="h-4 w-4"
                />
                <Label htmlFor="use-global-vin">Use same VIN for all files</Label>
              </div>

              {useGlobalVIN ? (
                <div className="space-y-2">
                  <Label htmlFor="global-vin">New VIN (17 characters)</Label>
                  <Input
                    id="global-vin"
                    value={globalNewVIN}
                    onChange={(e) => setGlobalNewVIN(e.target.value.toUpperCase())}
                    placeholder="1C3CDFBB0ED123456"
                    maxLength={17}
                    className="font-mono text-lg"
                  />
                  <p className="text-sm text-muted-foreground">
                    This VIN will be written to all uploaded files
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <Label>Individual VINs for each file</Label>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Filename</TableHead>
                        <TableHead>New VIN</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {files.map(file => (
                        <TableRow key={file.id}>
                          <TableCell className="font-medium">{file.filename}</TableCell>
                          <TableCell>
                            <Input
                              value={file.newVIN || ''}
                              onChange={(e) => updateFileVIN(file.id, e.target.value.toUpperCase())}
                              placeholder="1C3CDFBB0ED123456"
                              maxLength={17}
                              className="font-mono"
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              <div className="flex gap-4">
                <Button
                  onClick={processBatch}
                  disabled={isProcessing || files.length === 0}
                  className="flex-1"
                >
                  {isProcessing ? (
                    <>Processing...</>
                  ) : (
                    <>
                      <FileCheck className="h-4 w-4 mr-2" />
                      Process Batch
                    </>
                  )}
                </Button>
              </div>

              {isProcessing && (
                <div className="space-y-2">
                  <Progress value={progress} />
                  <p className="text-sm text-muted-foreground text-center">
                    Processing {files.length} file(s)...
                  </p>
                </div>
              )}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <Card className="p-6">
            <div className="space-y-4">
              {patchedResults.length === 0 ? (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    No results yet. Process files to see results here.
                  </AlertDescription>
                </Alert>
              ) : (
                <>
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">
                      Patched Files ({patchedResults.length})
                    </h3>
                    <Button onClick={downloadAllAsZip}>
                      <Download className="h-4 w-4 mr-2" />
                      Download All as ZIP
                    </Button>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Filename</TableHead>
                        <TableHead>Module Type</TableHead>
                        <TableHead>Original VIN</TableHead>
                        <TableHead>New VIN</TableHead>
                        <TableHead>CRC Updated</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {patchedResults.map((result, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{result.filename}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{result.moduleType}</Badge>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{result.originalVIN}</TableCell>
                          <TableCell className="font-mono text-sm font-bold text-green-600">
                            {result.newVIN}
                          </TableCell>
                          <TableCell>
                            {result.crcRecalculated ? (
                              <CheckCircle2 className="h-4 w-4 text-green-600" />
                            ) : (
                              <AlertCircle className="h-4 w-4 text-yellow-600" />
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => downloadSingle(result.patchedData, result.filename)}
                            >
                              <Download className="h-4 w-4 mr-2" />
                              Download
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </>
              )}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
