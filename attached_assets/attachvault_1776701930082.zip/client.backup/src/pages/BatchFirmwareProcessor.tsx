import { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, FileText, Download, CheckCircle2, XCircle, Loader2, FolderOpen } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface UploadedFile {
  file: File;
  type: 'flpart' | 'fms' | 'efd';
  status: 'pending' | 'processing' | 'success' | 'error';
  error?: string;
}

export default function BatchFirmwareProcessor() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);

  const createBatchJobMutation = trpc.batchFirmware.createBatchJob.useMutation();
  const processBatchMutation = trpc.batchFirmware.processBatch.useMutation();
  const { data: jobStatus, refetch: refetchJobStatus } = trpc.batchFirmware.getJobStatus.useQuery(
    { jobId: currentJobId || '' },
    { enabled: !!currentJobId, refetchInterval: 1000 }
  );
  const { data: jobResults } = trpc.batchFirmware.getJobResults.useQuery(
    { jobId: currentJobId || '' },
    { enabled: !!currentJobId && jobStatus?.status === 'completed' }
  );
  const { data: consolidatedReport } = trpc.batchFirmware.getConsolidatedReport.useQuery(
    { jobId: currentJobId || '' },
    { enabled: !!currentJobId && jobStatus?.status === 'completed' }
  );
  const exportCSVMutation = trpc.batchFirmware.exportReportToCSV.useMutation();

  const getFileType = (filename: string): 'flpart' | 'fms' | 'efd' | null => {
    const ext = filename.toLowerCase().split('.').pop();
    if (ext === 'flpart') return 'flpart';
    if (ext === 'fms') return 'fms';
    if (ext === 'efd') return 'efd';
    return null;
  };

  const handleFileSelect = useCallback((selectedFiles: FileList | null) => {
    if (!selectedFiles) return;

    const newFiles: UploadedFile[] = [];
    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];
      const type = getFileType(file.name);
      
      if (type) {
        newFiles.push({
          file,
          type,
          status: 'pending',
        });
      }
    }

    setFiles(prev => [...prev, ...newFiles]);
    toast({
      title: 'Files Added',
      description: `Added ${newFiles.length} firmware files`,
    });
  }, [toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    handleFileSelect(e.dataTransfer.files);
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleFolderSelect = useCallback(() => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  }, []);

  const processBatch = async () => {
    if (files.length === 0) {
      toast({
        title: 'No Files',
        description: 'Please add firmware files to process',
        variant: 'destructive',
      });
      return;
    }

    setIsProcessing(true);
    setProgress(0);

    try {
      // Create batch job
      const { jobId } = await createBatchJobMutation.mutateAsync({
        totalFiles: files.length,
      });

      setCurrentJobId(jobId);

      // Convert files to base64
      const filePromises = files.map(async ({ file, type }) => {
        const buffer = await file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.length; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64 = btoa(binary);
        return {
          filename: file.name,
          content: base64,
          type,
        };
      });

      const encodedFiles = await Promise.all(filePromises);

      // Process batch
      await processBatchMutation.mutateAsync({
        jobId,
        files: encodedFiles,
      });

      await refetchJobStatus();

      toast({
        title: 'Processing Complete',
        description: `Successfully processed ${files.length} files`,
      });
    } catch (error) {
      toast({
        title: 'Processing Failed',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
      setProgress(100);
    }
  };

  const exportToCSV = async () => {
    if (!currentJobId) return;

    try {
      const csvData = await exportCSVMutation.mutateAsync({ jobId: currentJobId });

      // Download all CSV files
      const downloads = [
        { name: 'part_inventory.csv', content: csvData.partInventory },
        { name: 'compatibility_matrix.csv', content: csvData.compatibilityMatrix },
        { name: 'uds_statistics.csv', content: csvData.udsStatistics },
        { name: 'supersedence_chains.csv', content: csvData.supersedenceChains },
      ];

      downloads.forEach(({ name, content }) => {
        const blob = new Blob([content], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = name;
        a.click();
        URL.revokeObjectURL(url);
      });

      toast({
        title: 'Export Complete',
        description: 'Downloaded 4 CSV files',
      });
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    }
  };

  const clearFiles = () => {
    setFiles([]);
    setCurrentJobId(null);
    setProgress(0);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Batch Firmware Processor</h1>
          <p className="text-muted-foreground mt-2">
            Upload and analyze multiple firmware files simultaneously
          </p>
        </div>
      </div>

      {/* Upload Area */}
      <Card>
        <CardHeader>
          <CardTitle>Upload Firmware Files</CardTitle>
          <CardDescription>
            Drag and drop firmware files (.flpart, .fms, .efd) or select a folder
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-primary transition-colors cursor-pointer"
            onClick={handleFolderSelect}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".flpart,.fms,.efd"
              onChange={(e) => handleFileSelect(e.target.files)}
              className="hidden"
            />
            <FolderOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <p className="text-lg font-medium mb-2">Drop firmware files here</p>
            <p className="text-sm text-muted-foreground mb-4">
              or click to select files from your computer
            </p>
            <Button variant="outline" onClick={(e) => { e.stopPropagation(); handleFolderSelect(); }}>
              <Upload className="w-4 h-4 mr-2" />
              Select Files
            </Button>
          </div>

          {files.length > 0 && (
            <div className="mt-6 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  {files.length} files selected
                </p>
                <div className="flex gap-2">
                  <Button
                    onClick={processBatch}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Process Batch
                      </>
                    )}
                  </Button>
                  <Button variant="outline" onClick={clearFiles} disabled={isProcessing}>
                    Clear
                  </Button>
                </div>
              </div>

              {isProcessing && (
                <div className="space-y-2">
                  <Progress value={progress} />
                  <p className="text-sm text-muted-foreground text-center">
                    Processing {files.length} files...
                  </p>
                </div>
              )}

              <div className="max-h-64 overflow-y-auto border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Filename</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {files.map((file, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-mono text-sm">{file.file.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{file.type.toUpperCase()}</Badge>
                        </TableCell>
                        <TableCell>
                          {file.status === 'pending' && (
                            <Badge variant="secondary">Pending</Badge>
                          )}
                          {file.status === 'processing' && (
                            <Badge variant="secondary">
                              <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                              Processing
                            </Badge>
                          )}
                          {file.status === 'success' && (
                            <Badge variant="default">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              Success
                            </Badge>
                          )}
                          {file.status === 'error' && (
                            <Badge variant="destructive">
                              <XCircle className="w-3 h-3 mr-1" />
                              Error
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {jobStatus?.status === 'completed' && consolidatedReport && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Processing Results</CardTitle>
                <CardDescription>
                  Batch job completed in {(consolidatedReport.summary.processingTime / 1000).toFixed(2)}s
                </CardDescription>
              </div>
              <Button onClick={exportToCSV}>
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="summary">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="summary">Summary</TabsTrigger>
                <TabsTrigger value="inventory">Part Inventory</TabsTrigger>
                <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
                <TabsTrigger value="supersedence">Supersedence</TabsTrigger>
                <TabsTrigger value="uds">UDS Stats</TabsTrigger>
              </TabsList>

              <TabsContent value="summary" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>Total Files</CardDescription>
                      <CardTitle className="text-3xl">{consolidatedReport.summary.totalFiles}</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>Module Types</CardDescription>
                      <CardTitle className="text-3xl">{consolidatedReport.summary.totalModuleTypes}</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>Vehicles Covered</CardDescription>
                      <CardTitle className="text-3xl">{consolidatedReport.summary.totalVehicles}</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>UDS Commands</CardDescription>
                      <CardTitle className="text-3xl">{consolidatedReport.summary.totalUDSCommands}</CardTitle>
                    </CardHeader>
                  </Card>
                </div>

                <Alert>
                  <AlertDescription>
                    Successfully processed {jobStatus.successCount} files with {jobStatus.errorCount} errors
                  </AlertDescription>
                </Alert>
              </TabsContent>

              <TabsContent value="inventory">
                <div className="border rounded-lg max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Part Number</TableHead>
                        <TableHead>Module Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Superseded By</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {consolidatedReport.partInventory.map((part, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-mono">{part.partNumber}</TableCell>
                          <TableCell>{part.moduleType}</TableCell>
                          <TableCell>
                            <Badge variant={part.supersedenceStatus === 'current' ? 'default' : 'secondary'}>
                              {part.supersedenceStatus}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-mono">{part.supersededBy || '-'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="compatibility">
                <div className="border rounded-lg max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Part Number</TableHead>
                        <TableHead>Module Type</TableHead>
                        <TableHead>Compatible Vehicles</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {consolidatedReport.compatibilityMatrix.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-mono">{item.partNumber}</TableCell>
                          <TableCell>{item.moduleType}</TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              {item.vehicles.slice(0, 3).map((vehicle, vIndex) => (
                                <div key={vIndex} className="text-sm">
                                  {vehicle.year} {vehicle.body} {vehicle.engine}
                                </div>
                              ))}
                              {item.vehicles.length > 3 && (
                                <div className="text-sm text-muted-foreground">
                                  +{item.vehicles.length - 3} more
                                </div>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="supersedence">
                <div className="border rounded-lg max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Module Type</TableHead>
                        <TableHead>Supersedence Chain</TableHead>
                        <TableHead>Latest Part</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {consolidatedReport.supersedenceChains.map((chain, index) => (
                        <TableRow key={index}>
                          <TableCell>{chain.moduleType}</TableCell>
                          <TableCell className="font-mono text-sm">
                            {chain.chain.join(' → ')}
                          </TableCell>
                          <TableCell className="font-mono">
                            <Badge variant="default">{chain.latest}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="uds">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>UDS Services</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {Object.entries(consolidatedReport.udsStatistics.byService).map(([service, count]) => (
                          <div key={service} className="flex justify-between items-center">
                            <span className="text-sm">{service}</span>
                            <Badge variant="outline">{count}</Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Security Levels</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {consolidatedReport.udsStatistics.securityLevels.map((level) => (
                          <Badge key={level} variant="secondary">
                            Level {level}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
