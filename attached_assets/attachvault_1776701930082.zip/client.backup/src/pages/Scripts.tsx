import { useState, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BackButton } from "@/components/BackButton";
import { 
  ArrowLeft, Play, Save, FolderOpen, Plus, Trash2, Download, 
  Upload, Code2, Terminal, AlertCircle, CheckCircle2, Loader2
} from "lucide-react";
import Editor from "@monaco-editor/react";
import { trpc } from "@/lib/trpc";
import { useToast } from "@/hooks/use-toast";

interface ScriptOutput {
  timestamp: number;
  type: "info" | "success" | "error";
  message: string;
}

const EXAMPLE_SCRIPTS = {
  "read-vin": {
    name: "Read VIN from ECM",
    code: `// Read VIN from ECM using UDS Service 0x22
// DID 0xF190 = VIN

const ECM_TX = 0x7E0;
const ECM_RX = 0x7E8;

// Request VIN
const request = [0x22, 0xF1, 0x90];
console.log("Sending VIN read request...");

// Send and wait for response
const response = await sendUDS(ECM_TX, ECM_RX, request);

if (response[0] === 0x62 && response[1] === 0xF1 && response[2] === 0x90) {
  const vin = String.fromCharCode(...response.slice(3, 20));
  console.log("VIN: " + vin);
  return { success: true, vin };
} else {
  console.error("Failed to read VIN");
  return { success: false };
}`,
  },
  "security-access": {
    name: "Security Access with FCA Keygen",
    code: `// Perform security access using FCA keygen
// Level 1 (0x4B92) for diagnostic access

const ECM_TX = 0x7E0;
const ECM_RX = 0x7E8;

// Request seed
console.log("Requesting security seed...");
const seedRequest = [0x27, 0x01]; // Level 1 seed
const seedResponse = await sendUDS(ECM_TX, ECM_RX, seedRequest);

if (seedResponse[0] !== 0x67 || seedResponse[1] !== 0x01) {
  console.error("Failed to get seed");
  return { success: false };
}

const seed = seedResponse.slice(2, 6);
console.log("Seed: " + toHex(seed));

// Generate key using FCA keygen
const key = generateKey(seed, 1); // Level 1
console.log("Key: " + toHex(key));

// Send key
const keyRequest = [0x27, 0x02, ...key];
const keyResponse = await sendUDS(ECM_TX, ECM_RX, keyRequest);

if (keyResponse[0] === 0x67 && keyResponse[1] === 0x02) {
  console.log("Security access granted!");
  return { success: true };
} else {
  console.error("Security access denied");
  return { success: false };
}`,
  },
  "dtc-read": {
    name: "Read DTCs",
    code: `// Read Diagnostic Trouble Codes
// Service 0x19 0x02 = Read DTC by status mask

const ECM_TX = 0x7E0;
const ECM_RX = 0x7E8;

console.log("Reading DTCs...");
const request = [0x19, 0x02, 0xFF]; // All DTCs
const response = await sendUDS(ECM_TX, ECM_RX, request);

if (response[0] !== 0x59 || response[1] !== 0x02) {
  console.error("Failed to read DTCs");
  return { success: false };
}

const dtcCount = (response.length - 3) / 4;
console.log(\`Found \${dtcCount} DTCs\`);

const dtcs = [];
for (let i = 0; i < dtcCount; i++) {
  const offset = 3 + (i * 4);
  const dtcHigh = response[offset];
  const dtcLow = response[offset + 1];
  const status = response[offset + 2];
  
  const dtcCode = ((dtcHigh << 8) | dtcLow).toString(16).padStart(4, '0').toUpperCase();
  console.log(\`DTC: \${dtcCode} (Status: 0x\${status.toString(16)})\`);
  dtcs.push({ code: dtcCode, status });
}

return { success: true, dtcs };`,
  },
};

export default function Scripts() {
  const [scriptName, setScriptName] = useState("");
  const [code, setCode] = useState(EXAMPLE_SCRIPTS["read-vin"].code);
  const [output, setOutput] = useState<ScriptOutput[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedExample, setSelectedExample] = useState("read-vin");
  const editorRef = useRef<any>(null);
  const { toast } = useToast();

  const scripts = trpc.scripts.list.useQuery();
  const saveScript = trpc.scripts.create.useMutation();
  // Note: Delete functionality not yet implemented in backend
  const deleteScript = { mutateAsync: async (input: any) => { console.log('Delete not implemented'); } };

  const addOutput = (type: "info" | "success" | "error", message: string) => {
    setOutput(prev => [...prev, { timestamp: Date.now(), type, message }]);
  };

  const handleRun = async () => {
    setIsRunning(true);
    setOutput([]);
    addOutput("info", "Starting script execution...");

    try {
      // Get real hardware connection
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const { generateKey } = await import('../../../shared/fca-keygen');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        throw new Error('Not connected to vehicle. Please connect hardware first.');
      }

      // Real console for script output
      const scriptConsole = {
        log: (msg: string) => addOutput("info", String(msg)),
        error: (msg: string) => addOutput("error", String(msg)),
      };

      // Real UDS functions
      const realFunctions = {
        sendUDS: async (tx: number, rx: number, data: number[]) => {
          addOutput("info", `TX[0x${tx.toString(16)}] → ${data.map(b => '0x' + b.toString(16).padStart(2, '0')).join(' ')}`);
          const response = await protocol.sendUDS(tx, rx, data);
          if (response) {
            addOutput("info", `RX[0x${rx.toString(16)}] ← ${Array.from(response).map(b => '0x' + b.toString(16).padStart(2, '0')).join(' ')}`);
            return Array.from(response);
          }
          throw new Error('No response from module');
        },
        generateKey: (seed: number[], level: number) => {
          const key = generateKey(new Uint8Array(seed), level as 1 | 3 | 5);
          return Array.from(key);
        },
        toHex: (arr: number[]) => arr.map(b => '0x' + b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
      };

      addOutput("success", "Connected to vehicle - executing script...");

      // Execute script in sandboxed context with real hardware
      const func = new Function('console', 'sendUDS', 'generateKey', 'toHex', `return (async () => { ${code} })();`);
      const result = await func(scriptConsole, realFunctions.sendUDS, realFunctions.generateKey, realFunctions.toHex);
      
      if (result) {
        addOutput("success", `Script completed: ${JSON.stringify(result)}`);
      } else {
        addOutput("success", "Script completed successfully");
      }
      
    } catch (error: any) {
      addOutput("error", `Error: ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  const handleSave = async () => {
    if (!scriptName) {
      toast({ title: "Error", description: "Please enter a script name", variant: "destructive" });
      return;
    }

    try {
      await saveScript.mutateAsync({
        name: scriptName,
        code,
        description: "Custom UDS script",
      });
      toast({ title: "Success", description: "Script saved successfully" });
      scripts.refetch();
    } catch (error) {
      toast({ title: "Error", description: "Failed to save script", variant: "destructive" });
    }
  };

  const handleLoad = (script: any) => {
    setScriptName(script.name);
    setCode(script.code);
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteScript.mutateAsync({ id });
      toast({ title: "Success", description: "Script deleted" });
      scripts.refetch();
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete script", variant: "destructive" });
    }
  };

  const handleLoadExample = (key: string) => {
    setSelectedExample(key);
    const example = EXAMPLE_SCRIPTS[key as keyof typeof EXAMPLE_SCRIPTS];
    setScriptName(example.name);
    setCode(example.code);
  };

  const handleExport = () => {
    const blob = new Blob([code], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${scriptName || 'script'}.js`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b-4 border-red-600">
        <div className="container mx-auto py-6">
          <BackButton />
      <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-3xl font-black tracking-tight">SCRIPTS</h1>
                <p className="text-sm text-gray-600 mt-1">Custom UDS Diagnostic Sequences</p>
              </div>
            </div>
            <Badge variant="outline" className="text-lg px-4 py-2">
              <Code2 className="h-4 w-4 mr-2" />
              JAVASCRIPT
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Script Name */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Script Name</CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  value={scriptName}
                  onChange={(e) => setScriptName(e.target.value)}
                  placeholder="my-script"
                />
              </CardContent>
            </Card>

            {/* Examples */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Examples</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {Object.entries(EXAMPLE_SCRIPTS).map(([key, example]) => (
                  <Button
                    key={key}
                    variant={selectedExample === key ? "default" : "outline"}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => handleLoadExample(key)}
                  >
                    <Code2 className="h-3 w-3 mr-2" />
                    {example.name}
                  </Button>
                ))}
              </CardContent>
            </Card>

            {/* Saved Scripts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Saved Scripts</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px]">
                  {scripts.data?.length === 0 && (
                    <div className="text-xs text-gray-400 text-center py-4">
                      No saved scripts
                    </div>
                  )}
                  <div className="space-y-2">
                    {scripts.data?.map((script: any) => (
                      <div key={script.id} className="flex items-center justify-between">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="flex-1 justify-start text-xs"
                          onClick={() => handleLoad(script)}
                        >
                          <FolderOpen className="h-3 w-3 mr-2" />
                          {script.name}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => handleDelete(script.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="space-y-2">
              <Button onClick={handleSave} className="w-full" variant="outline">
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
              <Button onClick={handleExport} className="w-full" variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Editor & Output */}
          <div className="lg:col-span-3 space-y-4">
            {/* Code Editor */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="h-5 w-5" />
                    Code Editor
                  </CardTitle>
                  <Button onClick={handleRun} disabled={isRunning}>
                    {isRunning ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Running...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Run
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <Editor
                    height="400px"
                    defaultLanguage="javascript"
                    value={code}
                    onChange={(value) => setCode(value || "")}
                    theme="vs-dark"
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                      lineNumbers: "on",
                      scrollBeyondLastLine: false,
                      automaticLayout: true,
                    }}
                    onMount={(editor) => {
                      editorRef.current = editor;
                    }}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Output Console */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="h-5 w-5" />
                  Output Console
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px] bg-black rounded-lg p-4 font-mono text-sm">
                  {output.length === 0 && (
                    <div className="text-gray-500">No output yet. Run a script to see results.</div>
                  )}
                  {output.map((line, idx) => (
                    <div
                      key={idx}
                      className={
                        line.type === "error"
                          ? "text-red-400"
                          : line.type === "success"
                          ? "text-green-400"
                          : "text-gray-300"
                      }
                    >
                      <span className="text-gray-600">
                        [{new Date(line.timestamp).toLocaleTimeString()}]
                      </span>{" "}
                      {line.message}
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>

            {/* API Reference */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Available Functions</AlertTitle>
              <AlertDescription className="font-mono text-xs space-y-1">
                <div><strong>sendUDS(tx, rx, data)</strong> - Send UDS request and get response</div>
                <div><strong>generateKey(seed, level)</strong> - Generate FCA security key</div>
                <div><strong>toHex(array)</strong> - Convert byte array to hex string</div>
                <div><strong>console.log(msg)</strong> - Print to output console</div>
              </AlertDescription>
            </Alert>
          </div>
        </div>
      </div>
    </div>
  );
}
