import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BackButton } from "@/components/BackButton";
import { useLocation } from 'wouter';
import { Car, Calendar, Cpu, Key, ArrowRight } from 'lucide-react';
import type { ModuleType, AlgorithmType } from '@shared/seed-key-algorithms';

interface VehicleData {
  year: number;
  make: string;
  model: string;
  algorithm: AlgorithmType;
  generation: string;
  modules: ModuleType[];
}

const VEHICLE_DATABASE: Record<string, VehicleData[]> = {
  'Dodge Challenger': [
    { year: 2008, make: 'Dodge', model: 'Challenger', algorithm: 'ngc3', generation: 'LC (2008-2010)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG'] },
    { year: 2011, make: 'Dodge', model: 'Challenger', algorithm: 'shift-xor', generation: 'LC (2011-2014)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB'] },
    { year: 2015, make: 'Dodge', model: 'Challenger', algorithm: 'shift-xor', generation: 'LC (2015-2017)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] },
    { year: 2018, make: 'Dodge', model: 'Challenger', algorithm: 'xtea', generation: 'LC Facelift (2018-2023)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] }
  ],
  'Dodge Charger': [
    { year: 2006, make: 'Dodge', model: 'Charger', algorithm: 'ngc3', generation: 'LX (2006-2010)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG'] },
    { year: 2011, make: 'Dodge', model: 'Charger', algorithm: 'shift-xor', generation: 'LD (2011-2014)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB'] },
    { year: 2015, make: 'Dodge', model: 'Charger', algorithm: 'shift-xor', generation: 'LD (2015-2017)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] },
    { year: 2018, make: 'Dodge', model: 'Charger', algorithm: 'xtea', generation: 'LD Facelift (2018-2023)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] }
  ],
  'Jeep Grand Cherokee': [
    { year: 1999, make: 'Jeep', model: 'Grand Cherokee', algorithm: 'sbec2', generation: 'WJ (1999-2004)', modules: ['PCM', 'BCM', 'TCM', 'ABS'] },
    { year: 2005, make: 'Jeep', model: 'Grand Cherokee', algorithm: 'ngc3', generation: 'WK (2005-2010)', modules: ['ECM', 'BCM', 'TCM', 'ABS', 'AIRBAG'] },
    { year: 2011, make: 'Jeep', model: 'Grand Cherokee', algorithm: 'shift-xor', generation: 'WK2 (2011-2017)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB'] },
    { year: 2018, make: 'Jeep', model: 'Grand Cherokee', algorithm: 'xtea', generation: 'WK2 Facelift (2018-2021)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] },
    { year: 2022, make: 'Jeep', model: 'Grand Cherokee', algorithm: 'xtea', generation: 'WL (2022-2023)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] }
  ],
  'RAM 1500': [
    { year: 2002, make: 'RAM', model: '1500', algorithm: 'sbec2', generation: '2nd Gen (2002-2008)', modules: ['PCM', 'BCM', 'TCM', 'ABS'] },
    { year: 2009, make: 'RAM', model: '1500', algorithm: 'ngc3', generation: '3rd Gen (2009-2010)', modules: ['ECM', 'BCM', 'TCM', 'ABS', 'AIRBAG'] },
    { year: 2011, make: 'RAM', model: '1500', algorithm: 'shift-xor', generation: '4th Gen (2011-2017)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB'] },
    { year: 2018, make: 'RAM', model: '1500', algorithm: 'xtea', generation: 'DT (2018-2023)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] }
  ],
  'Chrysler 300': [
    { year: 2005, make: 'Chrysler', model: '300', algorithm: 'ngc3', generation: 'LX (2005-2010)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG'] },
    { year: 2011, make: 'Chrysler', model: '300', algorithm: 'shift-xor', generation: 'LD (2011-2017)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] },
    { year: 2018, make: 'Chrysler', model: '300', algorithm: 'xtea', generation: 'LD Facelift (2018-2023)', modules: ['BCM', 'ECM', 'TCM', 'ABS', 'AIRBAG', 'RFHUB', 'CCM'] }
  ]
};

const ALGORITHM_INFO: Record<AlgorithmType, { name: string; years: string; description: string; color: string }> = {
  'sbec2': {
    name: 'SBEC2/SBEC3',
    years: '1996-2006',
    description: 'Legacy multiply-add algorithm: key = (seed * 4) + 0x9018',
    color: 'bg-blue-500'
  },
  'ngc3': {
    name: 'NGC3/NGC4',
    years: '2004-2010',
    description: 'XOR-multiply-add: key = ((seed ^ 0x8749) * 0x4A) + 0x259B',
    color: 'bg-purple-500'
  },
  'shift-xor': {
    name: 'Modern FCA Shift-XOR',
    years: '2010-2017',
    description: 'Bitwise shift-and-XOR with module-specific constants',
    color: 'bg-green-500'
  },
  'xtea': {
    name: 'SecurityGateway XTEA',
    years: '2018-2023',
    description: 'XTEA encryption with 3 methods for 2018+ vehicles',
    color: 'bg-red-500'
  },
  'vin-based': {
    name: 'VIN-based PIN',
    years: 'Various',
    description: 'SKIM PIN extraction from VIN',
    color: 'bg-yellow-500'
  },
  'simple-math': {
    name: 'Simple Math',
    years: 'Various',
    description: 'Basic multiply/add operations',
    color: 'bg-gray-500'
  }
};

export default function VehicleSelector() {
  const [, setLocation] = useLocation();
  const [selectedVehicle, setSelectedVehicle] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const [vehicleData, setVehicleData] = useState<VehicleData | null>(null);

  const handleVehicleChange = (vehicle: string) => {
    setSelectedVehicle(vehicle);
    setSelectedYear(null);
    setVehicleData(null);
  };

  const handleYearChange = (year: string) => {
    const yearNum = parseInt(year);
    setSelectedYear(yearNum);
    
    // Find matching vehicle data
    const vehicles = VEHICLE_DATABASE[selectedVehicle] || [];
    const match = vehicles.find(v => v.year === yearNum) || vehicles[vehicles.length - 1];
    setVehicleData(match);
  };

  const handleProgramVIN = () => {
    if (vehicleData) {
      // Navigate to Live VIN Programmer with pre-filled data
      setLocation(`/live-vin-programmer?algorithm=${vehicleData.algorithm}&module=${vehicleData.modules[0]}`)
    }
  };

  const availableYears = selectedVehicle ? VEHICLE_DATABASE[selectedVehicle].map(v => v.year) : [];
  const algorithmInfo = vehicleData ? ALGORITHM_INFO[vehicleData.algorithm] : null;

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center gap-3">
        <Car className="h-8 w-8 text-red-500" />
        <div>
          <h1 className="text-3xl font-bold">Legacy Vehicle Selector</h1>
          <p className="text-muted-foreground">
            Auto-detect security algorithm based on vehicle year and model (1996-2023)
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Select Your Vehicle</CardTitle>
          <CardDescription>
            Choose your vehicle to automatically detect the correct seed-key algorithm
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Vehicle Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Vehicle Model</label>
              <Select value={selectedVehicle} onValueChange={handleVehicleChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select vehicle..." />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(VEHICLE_DATABASE).map(vehicle => (
                    <SelectItem key={vehicle} value={vehicle}>
                      {vehicle}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Year</label>
              <Select 
                value={selectedYear?.toString() || ''} 
                onValueChange={handleYearChange}
                disabled={!selectedVehicle}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select year..." />
                </SelectTrigger>
                <SelectContent>
                  {availableYears.map(year => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Vehicle Information */}
          {vehicleData && algorithmInfo && (
            <div className="space-y-4 pt-4 border-t">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>Generation</span>
                  </div>
                  <p className="font-medium">{vehicleData.generation}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Key className="h-4 w-4" />
                    <span>Security Algorithm</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`${algorithmInfo.color} text-white`}>
                      {algorithmInfo.name}
                    </Badge>
                    <span className="text-sm text-muted-foreground">{algorithmInfo.years}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Cpu className="h-4 w-4" />
                  <span>Compatible Modules</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {vehicleData.modules.map(module => (
                    <Badge key={module} variant="outline">
                      {module}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-muted rounded-lg space-y-2">
                <p className="text-sm font-medium">Algorithm Details:</p>
                <p className="text-sm text-muted-foreground font-mono">
                  {algorithmInfo.description}
                </p>
              </div>

              <Button 
                onClick={handleProgramVIN}
                className="w-full"
                size="lg"
              >
                Program VIN with {algorithmInfo.name}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          )}

          {/* Algorithm Coverage Overview */}
          {!vehicleData && (
            <div className="pt-4 border-t space-y-4">
              <h3 className="font-semibold">Complete Algorithm Coverage (1996-2023)</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Object.entries(ALGORITHM_INFO).filter(([key]) => key !== 'vin-based' && key !== 'simple-math').map(([key, info]) => (
                  <div key={key} className="p-3 border rounded-lg space-y-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${info.color}`} />
                      <span className="font-medium">{info.name}</span>
                      <Badge variant="secondary" className="ml-auto">{info.years}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground font-mono">
                      {info.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">28</div>
            <p className="text-sm text-muted-foreground">Years Covered</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">5</div>
            <p className="text-sm text-muted-foreground">Algorithms</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">22+</div>
            <p className="text-sm text-muted-foreground">Module Types</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">100%</div>
            <p className="text-sm text-muted-foreground">Real Algorithms</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
