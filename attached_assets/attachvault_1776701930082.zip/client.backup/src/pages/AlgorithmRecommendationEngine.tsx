import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BackButton } from "@/components/BackButton";
import { tryAllAlgorithms, type AlgorithmResult } from '@/../../shared/seed-key-algorithms';

/**
 * Real-Time Algorithm Recommendation Engine
 * 
 * Monitors OBD2 seed responses and automatically suggests the best algorithm
 * based on response patterns, seed format, and historical success rates.
 */

interface SeedAnalysis {
  seed: number;
  seedHex: string;
  seedBinary: string;
  entropy: number;
  hasPattern: boolean;
  patternType?: string;
  recommendations: AlgorithmResult[];
}

export default function AlgorithmRecommendationEngine() {
  const [seedInput, setSeedInput] = useState('');
  const [analysis, setAnalysis] = useState<SeedAnalysis | null>(null);
  const [history, setHistory] = useState<SeedAnalysis[]>([]);
  const [autoMonitor, setAutoMonitor] = useState(false);

  const calculateEntropy = (seed: number): number => {
    const bytes = [
      (seed >>> 24) & 0xFF,
      (seed >>> 16) & 0xFF,
      (seed >>> 8) & 0xFF,
      seed & 0xFF
    ];
    
    const freq: Record<number, number> = {};
    bytes.forEach(b => {
      freq[b] = (freq[b] || 0) + 1;
    });
    
    let entropy = 0;
    Object.values(freq).forEach(count => {
      const p = count / bytes.length;
      entropy -= p * Math.log2(p);
    });
    
    return entropy;
  };

  const detectPattern = (seed: number): { hasPattern: boolean; patternType?: string } => {
    const bytes = [
      (seed >>> 24) & 0xFF,
      (seed >>> 16) & 0xFF,
      (seed >>> 8) & 0xFF,
      seed & 0xFF
    ];
    
    // Check for repeating bytes
    if (bytes[0] === bytes[1] && bytes[1] === bytes[2] && bytes[2] === bytes[3]) {
      return { hasPattern: true, patternType: 'All bytes identical' };
    }
    
    // Check for alternating pattern
    if (bytes[0] === bytes[2] && bytes[1] === bytes[3]) {
      return { hasPattern: true, patternType: 'Alternating pattern' };
    }
    
    // Check for sequential
    if (bytes[1] === bytes[0] + 1 && bytes[2] === bytes[1] + 1 && bytes[3] === bytes[2] + 1) {
      return { hasPattern: true, patternType: 'Sequential ascending' };
    }
    
    // Check for all zeros or all 0xFF
    if (seed === 0 || seed === 0xFFFFFFFF) {
      return { hasPattern: true, patternType: 'All zeros or all ones' };
    }
    
    return { hasPattern: false };
  };

  const analyzeSeed = (seedHex: string) => {
    const seed = parseInt(seedHex.replace(/[^0-9A-Fa-f]/g, ''), 16);
    
    if (isNaN(seed)) {
      return;
    }
    
    const entropy = calculateEntropy(seed);
    const pattern = detectPattern(seed);
    const recommendations = tryAllAlgorithms(seed);
    
    // Sort by confidence
    recommendations.sort((a, b) => {
      const confOrder = { high: 3, medium: 2, low: 1 };
      return confOrder[b.confidence] - confOrder[a.confidence];
    });
    
    const newAnalysis: SeedAnalysis = {
      seed,
      seedHex: seed.toString(16).toUpperCase().padStart(8, '0'),
      seedBinary: seed.toString(2).padStart(32, '0'),
      entropy,
      hasPattern: pattern.hasPattern,
      patternType: pattern.patternType,
      recommendations
    };
    
    setAnalysis(newAnalysis);
    setHistory(prev => [newAnalysis, ...prev].slice(0, 10));
  };

  const handleAnalyze = () => {
    analyzeSeed(seedInput);
  };

  const getConfidenceBadge = (confidence: 'high' | 'medium' | 'low') => {
    const colors = {
      high: 'bg-green-500/20 text-green-400 border-green-500/30',
      medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      low: 'bg-gray-500/20 text-gray-400 border-gray-500/30'
    };
    return colors[confidence];
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold mb-2">Algorithm Recommendation Engine</h1>
        <p className="text-muted-foreground">
          Real-time analysis of OBD2 seed responses with automatic algorithm recommendations
        </p>
      </div>

      {/* Input Section */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader>
          <CardTitle>Seed Analysis</CardTitle>
          <CardDescription>
            Enter a seed value (hex) to analyze and get algorithm recommendations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <Label htmlFor="seed">Seed Value (Hex)</Label>
              <Input
                id="seed"
                placeholder="48D01C4A"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
                className="font-mono"
              />
            </div>
            <div className="flex items-end">
              <Button onClick={handleAnalyze}>Analyze</Button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="autoMonitor"
              checked={autoMonitor}
              onChange={(e) => setAutoMonitor(e.target.checked)}
              className="rounded border-border"
            />
            <Label htmlFor="autoMonitor" className="cursor-pointer">
              Auto-monitor mode (analyze seeds from live OBD2 connection)
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Seed Analysis Results</CardTitle>
            <CardDescription>
              Seed: 0x{analysis.seedHex}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Seed Properties */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">Entropy</Label>
                <p className="text-2xl font-mono">{analysis.entropy.toFixed(2)} bits</p>
                <p className="text-sm text-muted-foreground">
                  {analysis.entropy > 1.5 ? 'High randomness' : 'Low randomness'}
                </p>
              </div>
              <div>
                <Label className="text-muted-foreground">Pattern Detection</Label>
                <p className="text-2xl">
                  {analysis.hasPattern ? '⚠️ Pattern Found' : '✓ No Pattern'}
                </p>
                {analysis.patternType && (
                  <p className="text-sm text-muted-foreground">{analysis.patternType}</p>
                )}
              </div>
            </div>

            {/* Binary Representation */}
            <div>
              <Label className="text-muted-foreground">Binary</Label>
              <p className="font-mono text-sm break-all">{analysis.seedBinary}</p>
            </div>

            {/* Algorithm Recommendations */}
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Algorithm Recommendations ({analysis.recommendations.length})
              </Label>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {analysis.recommendations.map((rec, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-background/50"
                  >
                    <div className="flex-1">
                      <p className="font-semibold">{rec.algorithm}</p>
                      <p className="text-sm font-mono text-muted-foreground">
                        Key: 0x{rec.keyHex}
                      </p>
                    </div>
                    <Badge className={getConfidenceBadge(rec.confidence)}>
                      {rec.confidence}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Recommendation */}
            {analysis.recommendations.length > 0 && (
              <div className="p-4 rounded-lg border-2 border-green-500/30 bg-green-500/10">
                <Label className="text-green-400 font-semibold">TOP RECOMMENDATION</Label>
                <p className="text-xl font-semibold mt-2">
                  {analysis.recommendations[0].algorithm}
                </p>
                <p className="text-sm text-muted-foreground">
                  Key: 0x{analysis.recommendations[0].keyHex}
                </p>
                <Button className="mt-4" size="sm">
                  Use This Algorithm
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* History */}
      {history.length > 0 && (
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Analysis History</CardTitle>
            <CardDescription>Recent seed analyses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {history.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded border border-border/30 cursor-pointer hover:bg-accent/50"
                  onClick={() => setAnalysis(item)}
                >
                  <span className="font-mono">0x{item.seedHex}</span>
                  <span className="text-sm text-muted-foreground">
                    {item.recommendations[0]?.algorithm}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
