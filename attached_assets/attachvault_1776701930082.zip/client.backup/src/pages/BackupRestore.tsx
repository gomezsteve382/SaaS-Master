/**
 * Backup & Restore Page
 * 
 * Main page for managing module backups and restore operations
 */

import { BackButton } from "@/components/BackButton";
import { BackupManager } from "@/components/BackupManager";

export default function BackupRestore() {
  return (
    <div className="container py-8">
      <BackButton />
      <div className="mt-6">
        <BackupManager />
      </div>
    </div>
  );
}
