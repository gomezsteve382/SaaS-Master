import { useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileUp, Search, Download, AlertCircle, CheckCircle2, Info, Upload, Trash2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { trpc } from '@/lib/trpc';
import { useToast } from '@/hooks/use-toast';

interface VINLocation {
  offset: number;
  prefix: string;
  vin: string;
  suffix: string;
}

interface SecurityRegion {
  start: number;
  end: number;
  name: string;
  description: string;
}

interface CRCBlock {
  offset: number;
  value: string;
  calculated: string;
  valid: boolean;
}

export default function EEPROMViewer() {
  const [fileData, setFileData] = useState<Uint8Array | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [moduleType, setModuleType] = useState<string>('BCM_DFLASH');
  const [vinLocations, setVinLocations] = useState<VINLocation[]>([]);
  const [securityRegions] = useState<SecurityRegion[]>([
    { start: 0x00C000, end: 0x00D000, name: 'SKIM Security Bytes', description: '4-byte SKIM key data' },
    { start: 0x00D000, end: 0x00E000, name: 'Immobilizer Keys', description: '16-byte secret key data' },
    { start: 0x00E000, end: 0x00F000, name: 'PIN Code Storage', description: 'Encrypted PIN codes' },
    { start: 0x00F000, end: 0x010000, name: 'Security Checksums', description: 'CRC protection' }
  ]);
  const [crcBlocks, setCrcBlocks] = useState<CRCBlock[]>([]);
  const [selectedOffset, setSelectedOffset] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const { toast } = useToast();
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const uploadMutation = trpc.eepromAnalyzer.uploadDump.useMutation();
  const userDumpsQuery = trpc.eepromAnalyzer.listUserDumps.useQuery();

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Maximum file size is 10MB",
        variant: "destructive",
      });
      return;
    }

    setFileName(file.name);
    setIsUploading(true);

    try {
      // Read file as ArrayBuffer
      const arrayBuffer = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);
      setFileData(data);
      analyzeEEPROM(data);

      // Convert to base64 for upload
      const base64 = btoa(String.fromCharCode.apply(null, Array.from(data) as any));
      
      // Upload to S3
      const result = await uploadMutation.mutateAsync({
        filename: file.name,
        fileData: base64,
        moduleType,
      });

      toast({
        title: "Upload successful",
        description: `File uploaded: ${result.filename}${result.extractedVIN ? ` (VIN: ${result.extractedVIN})` : ''}`,
      });

      // Refresh user dumps list
      userDumpsQuery.refetch();
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileUpload(file);
  }, [moduleType]);

  const analyzeEEPROM = (data: Uint8Array) => {
    // Find all VIN locations (BCM has 4 copies)
    const vins: VINLocation[] = [];
    const vinOffsets = moduleType === 'BCM_DFLASH' 
      ? [0x001328, 0x001348, 0x001368, 0x001388]
      : [0x0100, 0x0200]; // RFHUB offsets

    vinOffsets.forEach((offset, index) => {
      if (offset + 17 < data.length) {
        const vinBytes = data.slice(offset, offset + 17);
        const vin = String.fromCharCode(...Array.from(vinBytes));
        
        // Check if it's a valid VIN (alphanumeric)
        if (/^[A-HJ-NPR-Z0-9]{17}$/.test(vin)) {
          const prefix = String.fromCharCode(...Array.from(data.slice(offset - 2, offset)));
          const suffix = String.fromCharCode(...Array.from(data.slice(offset + 17, offset + 19)));
          vins.push({ offset, prefix, vin, suffix });
        }
      }
    });
    setVinLocations(vins);

    // Validate CRC checksums
    const crcs: CRCBlock[] = [];
    const crcOffsets = [0x000000, 0x000100, 0x001000, 0x002000, 0x008000];
    
    crcOffsets.forEach(offset => {
      if (offset + 4 < data.length) {
        const value = Array.from(data.slice(offset, offset + 4))
          .map(b => b.toString(16).padStart(2, '0').toUpperCase())
          .join('');
        
        // Calculate CRC-16/CCITT-FALSE for the block
        const blockData = data.slice(offset + 4, Math.min(offset + 0x1000, data.length));
        const calculated = calculateCRC16(blockData);
        const valid = value.substring(0, 4) === calculated;
        
        crcs.push({ offset, value, calculated, valid });
      }
    });
    setCrcBlocks(crcs);
  };

  const calculateCRC16 = (data: Uint8Array): string => {
    let crc = 0xFFFF;
    const polynomial = 0x1021;

    for (let i = 0; i < data.length; i++) {
      crc ^= (data[i] << 8);
      for (let j = 0; j < 8; j++) {
        if (crc & 0x8000) {
          crc = (crc << 1) ^ polynomial;
        } else {
          crc = crc << 1;
        }
        crc &= 0xFFFF;
      }
    }

    return crc.toString(16).padStart(4, '0').toUpperCase();
  };

  const renderHexDump = () => {
    if (!fileData) return null;

    const bytesPerRow = 16;
    const rows: React.ReactElement[] = [];
    const startOffset = Math.floor(selectedOffset / bytesPerRow) * bytesPerRow;
    const endOffset = Math.min(startOffset + (bytesPerRow * 32), fileData.length);

    for (let offset = startOffset; offset < endOffset; offset += bytesPerRow) {
      const rowBytes = fileData.slice(offset, Math.min(offset + bytesPerRow, fileData.length));
      const hexBytes = Array.from(rowBytes).map((b, i) => {
        const globalOffset = offset + i;
        const isVIN = vinLocations.some(v => globalOffset >= v.offset && globalOffset < v.offset + 17);
        const isSecurity = securityRegions.some(r => globalOffset >= r.start && globalOffset < r.end);
        
        let className = 'inline-block w-8 text-center';
        if (isVIN) className += ' bg-green-500/20 text-green-400 font-bold';
        else if (isSecurity) className += ' bg-red-500/20 text-red-400';
        else if (b === 0) className += ' text-gray-600';
        
        return (
          <span key={i} className={className}>
            {b.toString(16).padStart(2, '0').toUpperCase()}
          </span>
        );
      });

      const asciiBytes = Array.from(rowBytes).map((b, i) => {
        const char = b >= 32 && b <= 126 ? String.fromCharCode(b) : '.';
        const globalOffset = offset + i;
        const isVIN = vinLocations.some(v => globalOffset >= v.offset && globalOffset < v.offset + 17);
        
        return (
          <span key={i} className={isVIN ? 'text-green-400 font-bold' : ''}>
            {char}
          </span>
        );
      });

      rows.push(
        <div key={offset} className="font-mono text-sm flex gap-4 hover:bg-gray-800/50 px-2">
          <span className="text-gray-500 w-20">{offset.toString(16).padStart(8, '0').toUpperCase()}</span>
          <span className="flex-1">{hexBytes}</span>
          <span className="text-gray-400 w-40">{asciiBytes}</span>
        </div>
      );
    }

    return <div className="space-y-0.5">{rows}</div>;
  };

  const exportAnnotatedReport = () => {
    if (!fileData) return;

    let report = `EEPROM Structure Analysis Report\n`;
    report += `File: ${fileName}\n`;
    report += `Module Type: ${moduleType}\n`;
    report += `Size: ${fileData.length} bytes (${(fileData.length / 1024).toFixed(1)} KB)\n\n`;

    report += `=== VIN LOCATIONS ===\n`;
    vinLocations.forEach((v, i) => {
      report += `VIN #${i + 1} at 0x${v.offset.toString(16).padStart(6, '0').toUpperCase()}\n`;
      report += `  Prefix: ${v.prefix}\n`;
      report += `  VIN: ${v.vin}\n`;
      report += `  Suffix: ${v.suffix}\n\n`;
    });

    report += `=== CRC CHECKSUMS ===\n`;
    crcBlocks.forEach(crc => {
      report += `Block at 0x${crc.offset.toString(16).padStart(6, '0').toUpperCase()}\n`;
      report += `  Stored: ${crc.value}\n`;
      report += `  Calculated: ${crc.calculated}\n`;
      report += `  Status: ${crc.valid ? 'VALID ✓' : 'INVALID ✗'}\n\n`;
    });

    report += `=== SECURITY REGIONS ===\n`;
    securityRegions.forEach(region => {
      report += `${region.name} (0x${region.start.toString(16).toUpperCase()} - 0x${region.end.toString(16).toUpperCase()})\n`;
      report += `  ${region.description}\n\n`;
    });

    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}_analysis.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">EEPROM Structure Viewer</h1>
          <p className="text-muted-foreground">
            Analyze BCM/RFHUB EEPROM dumps with VIN highlighting, security region viewer, and CRC validation
          </p>
        </div>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          This tool analyzes real production EEPROM dumps. Upload a BCM D-FLASH (64KB) or RFHUB SmartBox (4KB) dump to view structure, VIN locations, security bytes, and checksums.
        </AlertDescription>
      </Alert>

      <Card className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Module Type</Label>
            <Select value={moduleType} onValueChange={setModuleType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BCM_DFLASH">BCM D-FLASH (64KB)</SelectItem>
                <SelectItem value="RFHUB">RFHUB SmartBox (4KB)</SelectItem>
                <SelectItem value="ECM">ECM GPEC2 (512KB)</SelectItem>
                <SelectItem value="TCM">TCM ZF8HP (256KB)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Upload EEPROM Dump</Label>
            <div className="flex gap-2">
              <Input
                type="file"
                accept=".bin,.hex,.eep,.dump"
                onChange={handleInputChange}
                className="flex-1"
              />
              {fileData && (
                <Button onClick={exportAnnotatedReport} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export Report
                </Button>
              )}
            </div>
          </div>
        </div>

        {fileName && (
          <div className="text-sm text-muted-foreground">
            Loaded: {fileName} ({fileData?.length.toLocaleString()} bytes)
          </div>
        )}
      </Card>

      {fileData && (
        <Tabs defaultValue="hex" className="space-y-4">
          <TabsList>
            <TabsTrigger value="hex">Hex Dump</TabsTrigger>
            <TabsTrigger value="vin">VIN Locations</TabsTrigger>
            <TabsTrigger value="security">Security Regions</TabsTrigger>
            <TabsTrigger value="crc">CRC Checksums</TabsTrigger>
          </TabsList>

          <TabsContent value="hex" className="space-y-4">
            <Card className="p-4">
              <div className="flex items-center gap-4 mb-4">
                <div className="flex-1 flex items-center gap-2">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Jump to offset (hex)..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      const offset = parseInt(e.target.value, 16);
                      if (!isNaN(offset)) setSelectedOffset(offset);
                    }}
                    className="max-w-xs"
                  />
                </div>
                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-500/20 border border-green-500"></div>
                    <span>VIN Data</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-red-500/20 border border-red-500"></div>
                    <span>Security Region</span>
                  </div>
                </div>
              </div>

              <div className="bg-black/50 rounded-lg p-4 overflow-x-auto max-h-[600px] overflow-y-auto">
                {renderHexDump()}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="vin" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">VIN Storage Locations</h3>
              {vinLocations.length === 0 ? (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    No valid VIN found. The module may be blank or VIN offsets may be incorrect for this module type.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-4">
                  {vinLocations.map((v, i) => (
                    <Card key={i} className="p-4 bg-gray-800/50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold">VIN Copy #{i + 1}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedOffset(v.offset)}
                        >
                          Jump to Offset
                        </Button>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Offset:</span>
                          <span className="ml-2 font-mono">0x{v.offset.toString(16).padStart(6, '0').toUpperCase()}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Prefix:</span>
                          <span className="ml-2 font-mono">{v.prefix}</span>
                        </div>
                        <div className="col-span-2">
                          <span className="text-muted-foreground">VIN:</span>
                          <span className="ml-2 font-mono text-lg text-green-400 font-bold">{v.vin}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Suffix:</span>
                          <span className="ml-2 font-mono">{v.suffix}</span>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Security & Immobilizer Regions</h3>
              <div className="space-y-4">
                {securityRegions.map((region, i) => (
                  <Card key={i} className="p-4 bg-red-500/10 border-red-500/50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold">{region.name}</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedOffset(region.start)}
                      >
                        Jump to Region
                      </Button>
                    </div>
                    <div className="text-sm space-y-1">
                      <div>
                        <span className="text-muted-foreground">Range:</span>
                        <span className="ml-2 font-mono">
                          0x{region.start.toString(16).toUpperCase()} - 0x{region.end.toString(16).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Size:</span>
                        <span className="ml-2">{((region.end - region.start) / 1024).toFixed(1)} KB</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Description:</span>
                        <span className="ml-2">{region.description}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="crc" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">CRC Checksum Validation</h3>
              <div className="space-y-4">
                {crcBlocks.map((crc, i) => (
                  <Card key={i} className={`p-4 ${crc.valid ? 'bg-green-500/10 border-green-500/50' : 'bg-red-500/10 border-red-500/50'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {crc.valid ? (
                          <CheckCircle2 className="h-5 w-5 text-green-400" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-red-400" />
                        )}
                        <span className="font-semibold">Block #{i + 1}</span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedOffset(crc.offset)}
                      >
                        Jump to Offset
                      </Button>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Offset:</span>
                        <span className="ml-2 font-mono">0x{crc.offset.toString(16).padStart(6, '0').toUpperCase()}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Stored CRC:</span>
                        <span className="ml-2 font-mono">{crc.value}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Calculated:</span>
                        <span className="ml-2 font-mono">{crc.calculated}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
