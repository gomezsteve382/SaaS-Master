import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { CheckCircle2, AlertCircle, Loader2, Upload, Download, Zap } from 'lucide-react';

interface FlashStep {
  id: string;
  name: string;
  progress: number;
  status: 'pending' | 'running' | 'success' | 'error';
}

export default function ModuleFlasher() {
  const [selectedModule, setSelectedModule] = useState<string>('');
  const [firmwareFile, setFirmwareFile] = useState<File | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);
  const [flashSteps, setFlashSteps] = useState<FlashStep[]>([
    { id: '1', name: 'Connect to Module', progress: 0, status: 'pending' },
    { id: '2', name: 'Enter Bootloader Mode', progress: 0, status: 'pending' },
    { id: '3', name: 'Erase Flash Memory', progress: 0, status: 'pending' },
    { id: '4', name: 'Upload Firmware', progress: 0, status: 'pending' },
    { id: '5', name: 'Verify Firmware', progress: 0, status: 'pending' },
    { id: '6', name: 'Reset Module', progress: 0, status: 'pending' }
  ]);

  const modules = [
    { id: 'ecm-gpec2', name: 'ECM - GPEC2 (Pentastar 3.6L)', address: '0x7E0', bootloader: '0x7DF' },
    { id: 'ecm-gpec2a', name: 'ECM - GPEC2A (Hemi 5.7L/6.4L)', address: '0x7E0', bootloader: '0x7DF' },
    { id: 'bcm-chrysler', name: 'BCM - Chrysler (D-FLASH)', address: '0x760', bootloader: '0x75F' },
    { id: 'bcm-continental', name: 'BCM - Continental (C-FLASH)', address: '0x760', bootloader: '0x75F' },
    { id: 'tcm-zf8hp', name: 'TCM - ZF 8HP (8-Speed Auto)', address: '0x7E1', bootloader: '0x7E9' },
    { id: 'tcm-zf9hp', name: 'TCM - ZF 9HP (9-Speed Auto)', address: '0x7E1', bootloader: '0x7E9' },
    { id: 'abs-bosch', name: 'ABS - Bosch ESP 9.0', address: '0x760', bootloader: '0x75F' },
    { id: 'airbag-autoliv', name: 'Airbag - Autoliv ACU5', address: '0x738', bootloader: '0x737' }
  ];

  const selectedModuleData = modules.find(m => m.id === selectedModule);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFirmwareFile(file);
    }
  };

  const startFlashing = async () => {
    if (!selectedModuleData || !firmwareFile) {
      alert('Please select a module and firmware file');
      return;
    }

    setIsFlashing(true);

    // Reset all steps
    setFlashSteps(flashSteps.map(step => ({ ...step, progress: 0, status: 'pending' as const })));

    // Simulate flashing process
    for (let i = 0; i < flashSteps.length; i++) {
      // Update step to running
      setFlashSteps(prev => prev.map((step, idx) => 
        idx === i ? { ...step, status: 'running' as const } : step
      ));

      // Simulate progress
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise(resolve => setTimeout(resolve, 200));
        setFlashSteps(prev => prev.map((step, idx) => 
          idx === i ? { ...step, progress } : step
        ));
      }

      // Update step to success
      setFlashSteps(prev => prev.map((step, idx) => 
        idx === i ? { ...step, status: 'success' as const, progress: 100 } : step
      ));
    }

    setIsFlashing(false);
    alert(`Firmware flashed successfully to ${selectedModuleData.name}!`);
  };

  const totalProgress = flashSteps.reduce((sum, step) => sum + step.progress, 0) / flashSteps.length;

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Module Firmware Flasher</h1>
          <p className="text-muted-foreground">
            Flash firmware/calibrations to ECM, BCM, TCM, and other modules via OBD2
          </p>
        </div>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>WARNING:</strong> Flashing incorrect firmware can brick your module. Always verify firmware compatibility before flashing. Requires stable 12V power and J2534 device.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <Card className="p-6 space-y-4">
            <div>
              <h3 className="font-semibold mb-4">Module Selection</h3>
              <Select value={selectedModule} onValueChange={setSelectedModule} disabled={isFlashing}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose module..." />
                </SelectTrigger>
                <SelectContent>
                  {modules.map(module => (
                    <SelectItem key={module.id} value={module.id}>
                      {module.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedModuleData && (
              <div className="space-y-4">
                <div className="p-3 bg-gray-800 rounded-lg space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Application Address:</span>
                    <span className="font-mono">{selectedModuleData.address}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bootloader Address:</span>
                    <span className="font-mono">{selectedModuleData.bootloader}</span>
                  </div>
                </div>

                <div>
                  <Label>Firmware File</Label>
                  <div className="mt-2">
                    <Input
                      type="file"
                      accept=".bin,.hex,.s19,.srec"
                      onChange={handleFileSelect}
                      disabled={isFlashing}
                    />
                  </div>
                  {firmwareFile && (
                    <p className="text-xs text-muted-foreground mt-2">
                      {firmwareFile.name} ({(firmwareFile.size / 1024).toFixed(2)} KB)
                    </p>
                  )}
                </div>

                <div className="pt-4">
                  <Button 
                    onClick={startFlashing} 
                    className="w-full"
                    disabled={!firmwareFile || isFlashing}
                  >
                    {isFlashing ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Flashing...
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        Start Flashing
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold mb-4">Supported File Formats</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• <strong>.bin</strong> - Raw binary firmware</li>
              <li>• <strong>.hex</strong> - Intel HEX format</li>
              <li>• <strong>.s19</strong> - Motorola S-Record</li>
              <li>• <strong>.srec</strong> - S-Record format</li>
            </ul>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-6">
          {selectedModuleData && (
            <>
              <Card className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">Overall Progress</h3>
                    <span className="text-sm text-muted-foreground">
                      {totalProgress.toFixed(0)}%
                    </span>
                  </div>
                  <Progress value={totalProgress} className="h-2" />
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-semibold mb-4">Flash Steps</h3>
                <div className="space-y-3">
                  {flashSteps.map((step, index) => (
                    <div 
                      key={step.id}
                      className={`p-4 rounded-lg border transition-all ${
                        step.status === 'running' ? 'border-blue-500 bg-blue-500/10' :
                        step.status === 'success' ? 'border-green-500 bg-green-500/10' :
                        step.status === 'error' ? 'border-red-500 bg-red-500/10' :
                        'border-gray-700 bg-gray-800/50'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5">
                          {step.status === 'running' && <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />}
                          {step.status === 'success' && <CheckCircle2 className="h-5 w-5 text-green-400" />}
                          {step.status === 'error' && <AlertCircle className="h-5 w-5 text-red-400" />}
                          {step.status === 'pending' && <div className="h-5 w-5 rounded-full border-2 border-gray-600" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold">{step.name}</span>
                            <span className="text-xs text-muted-foreground">
                              {step.progress}%
                            </span>
                          </div>
                          {step.status === 'running' && (
                            <Progress value={step.progress} className="h-1" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-semibold mb-4">Flashing Protocol</h3>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x10 02</div>
                    <div>
                      <strong className="text-foreground">Enter Programming Session</strong>
                      <p>Switch module to programming mode</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x27 XX</div>
                    <div>
                      <strong className="text-foreground">Security Access</strong>
                      <p>Unlock module with seed-key authentication</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x31 01</div>
                    <div>
                      <strong className="text-foreground">Erase Memory</strong>
                      <p>Erase flash sectors before writing</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x34 XX</div>
                    <div>
                      <strong className="text-foreground">Request Download</strong>
                      <p>Prepare module to receive firmware data</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x36 XX</div>
                    <div>
                      <strong className="text-foreground">Transfer Data</strong>
                      <p>Upload firmware blocks sequentially</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x37</div>
                    <div>
                      <strong className="text-foreground">Request Transfer Exit</strong>
                      <p>Finalize firmware upload</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x31 03</div>
                    <div>
                      <strong className="text-foreground">Checksum Verification</strong>
                      <p>Verify firmware integrity</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="font-mono text-xs bg-gray-800 px-2 py-1 rounded mt-0.5">0x11 01</div>
                    <div>
                      <strong className="text-foreground">Reset ECU</strong>
                      <p>Restart module with new firmware</p>
                    </div>
                  </div>
                </div>
              </Card>
            </>
          )}

          {!selectedModuleData && (
            <Card className="p-12 text-center">
              <p className="text-muted-foreground">Select a module to begin</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
