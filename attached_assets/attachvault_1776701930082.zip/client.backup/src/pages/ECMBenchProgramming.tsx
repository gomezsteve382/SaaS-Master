/**
 * ECM Bench Programming Page
 * Supports 3 programming modes:
 * 1. OBD2 Bench Programming (via UDS without opening ECM)
 * 2. Boot Mode Programming (BDM/JTAG for recovery)
 * 3. Hybrid Mode (automatic fallback)
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { 
  Cpu, 
  Zap, 
  Wifi, 
  HardDrive, 
  Lock, 
  Unlock, 
  Download, 
  Upload, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Play,
  StopCircle,
  Settings,
  Info,
  Cable,
} from 'lucide-react';

type ProgrammingMode = 'OBD2' | 'BDM' | 'JTAG' | 'Hybrid';
type ConnectionStatus = {
  connected: boolean;
  mode: string;
  ecuType?: string;
  partNumber?: string;
  message?: string;
};

export default function ECMBenchProgramming() {
  const [selectedMode, setSelectedMode] = useState<ProgrammingMode>('Hybrid');
  const [connection, setConnection] = useState<ConnectionStatus | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [activeOperation, setActiveOperation] = useState<string | null>(null);
  
  // OBD2 Mode State
  const [obd2VIN, setObd2VIN] = useState('');
  const [obd2Odometer, setObd2Odometer] = useState('');
  const [obd2CalibrationFile, setObd2CalibrationFile] = useState('');
  
  // Boot Mode State
  const [bootFlashFile, setBootFlashFile] = useState('');
  const [bootEEPROMFile, setBootEEPROMFile] = useState('');
  const [bootVerify, setBootVerify] = useState(true);
  
  // Hybrid Mode State
  const [hybridVIN, setHybridVIN] = useState('');
  const [hybridOdometer, setHybridOdometer] = useState('');
  const [hybridCalibration, setHybridCalibration] = useState('');
  const [hybridRemoveImmo, setHybridRemoveImmo] = useState(false);
  const [hybridSteps, setHybridSteps] = useState<any[]>([]);
  
  // Mutations
  const detectMutation = trpc.ecmBench.detectECM.useMutation();
  const initializeMutation = trpc.ecmBench.initializeBench.useMutation();
  
  // OBD2 Mutations
  const obd2ReadVINMutation = trpc.ecmBench.obd2ReadVIN.useMutation();
  const obd2WriteVINMutation = trpc.ecmBench.obd2WriteVIN.useMutation();
  const obd2ReadOdometerMutation = trpc.ecmBench.obd2ReadOdometer.useMutation();
  const obd2WriteOdometerMutation = trpc.ecmBench.obd2WriteOdometer.useMutation();
  const obd2FlashMutation = trpc.ecmBench.obd2FlashCalibration.useMutation();
  const obd2SecurityMutation = trpc.ecmBench.obd2SecurityAccess.useMutation();
  const obd2ReadDTCsMutation = trpc.ecmBench.obd2ReadDTCs.useMutation();
  const obd2ClearDTCsMutation = trpc.ecmBench.obd2ClearDTCs.useMutation();
  
  // Boot Mode Mutations
  const enterBootMutation = trpc.ecmBench.enterBootMode.useMutation();
  const bootReadFlashMutation = trpc.ecmBench.bootReadFlash.useMutation();
  const bootWriteFlashMutation = trpc.ecmBench.bootWriteFlash.useMutation();
  const bootReadEEPROMMutation = trpc.ecmBench.bootReadEEPROM.useMutation();
  const bootWriteEEPROMMutation = trpc.ecmBench.bootWriteEEPROM.useMutation();
  const bootUnlockMutation = trpc.ecmBench.bootUnlockECM.useMutation();
  const bootRemoveImmoMutation = trpc.ecmBench.bootRemoveImmobilizer.useMutation();
  const bootCloneMutation = trpc.ecmBench.bootCloneECM.useMutation();
  const bootRestoreMutation = trpc.ecmBench.bootRestoreECM.useMutation();
  const exitBootMutation = trpc.ecmBench.exitBootMode.useMutation();
  
  // Hybrid Mode Mutation
  const hybridCompleteMutation = trpc.ecmBench.hybridCompleteProgram.useMutation();
  
  // Queries
  const { data: wiringGuide } = trpc.ecmBench.getWiringGuide.useQuery({ 
    mode: selectedMode === 'Hybrid' ? 'OBD2' : selectedMode 
  });
  const { data: supportedECUs } = trpc.ecmBench.getSupportedECUs.useQuery();
  
  const handleDetectECM = async () => {
    setIsConnecting(true);
    try {
      const result = await detectMutation.mutateAsync({
        preferredMode: selectedMode === 'Hybrid' ? 'Auto' : selectedMode,
      });
      setConnection(result);
      
      if (result.connected) {
        // Auto-initialize
        await initializeMutation.mutateAsync({
          mode: result.mode as any,
          canSpeed: 500000,
          voltage: 12.0,
        });
      }
    } catch (error: any) {
      console.error('Detection failed:', error);
    } finally {
      setIsConnecting(false);
    }
  };
  
  const handleOBD2ReadVIN = async () => {
    setActiveOperation('read-vin');
    try {
      const result = await obd2ReadVINMutation.mutateAsync();
      setObd2VIN(result.vin);
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleOBD2WriteVIN = async () => {
    if (!obd2VIN || obd2VIN.length !== 17) {
      alert('Please enter a valid 17-character VIN');
      return;
    }
    
    setActiveOperation('write-vin');
    try {
      await obd2SecurityMutation.mutateAsync({ algorithm: 'Auto' });
      await obd2WriteVINMutation.mutateAsync({ vin: obd2VIN });
      alert('VIN programmed successfully!');
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleOBD2ReadOdometer = async () => {
    setActiveOperation('read-odometer');
    try {
      const result = await obd2ReadOdometerMutation.mutateAsync();
      setObd2Odometer(result.odometer.toString());
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleOBD2WriteOdometer = async () => {
    const odo = parseInt(obd2Odometer);
    if (isNaN(odo) || odo < 0) {
      alert('Please enter a valid odometer value');
      return;
    }
    
    setActiveOperation('write-odometer');
    try {
      await obd2SecurityMutation.mutateAsync({ algorithm: 'Auto' });
      await obd2WriteOdometerMutation.mutateAsync({ odometer: odo });
      alert('Odometer programmed successfully!');
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleOBD2Flash = async () => {
    if (!obd2CalibrationFile) {
      alert('Please select a calibration file');
      return;
    }
    
    setActiveOperation('flash-calibration');
    try {
      await obd2FlashMutation.mutateAsync({ 
        calibrationFile: obd2CalibrationFile,
        verifyAfter: true,
      });
      alert('Calibration flashed successfully!');
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleBootReadFlash = async () => {
    setActiveOperation('boot-read-flash');
    try {
      await enterBootMutation.mutateAsync({ method: selectedMode as 'BDM' | 'JTAG' });
      const result = await bootReadFlashMutation.mutateAsync({});
      alert(`Flash read complete! Saved to: ${result.data}`);
      await exitBootMutation.mutateAsync();
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleBootWriteFlash = async () => {
    if (!bootFlashFile) {
      alert('Please select a flash file');
      return;
    }
    
    setActiveOperation('boot-write-flash');
    try {
      await enterBootMutation.mutateAsync({ method: selectedMode as 'BDM' | 'JTAG' });
      await bootWriteFlashMutation.mutateAsync({ 
        file: bootFlashFile,
        verify: bootVerify,
      });
      alert('Flash written successfully!');
      await exitBootMutation.mutateAsync();
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleBootUnlock = async () => {
    if (!confirm('This will clear security bytes. Continue?')) return;
    
    setActiveOperation('boot-unlock');
    try {
      await enterBootMutation.mutateAsync({ method: selectedMode as 'BDM' | 'JTAG' });
      await bootUnlockMutation.mutateAsync();
      alert('ECM unlocked successfully!');
      await exitBootMutation.mutateAsync();
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleBootRemoveImmo = async () => {
    if (!confirm('This will remove immobilizer. ECM will start without SKIM. Continue?')) return;
    
    setActiveOperation('boot-remove-immo');
    try {
      await enterBootMutation.mutateAsync({ method: selectedMode as 'BDM' | 'JTAG' });
      await bootRemoveImmoMutation.mutateAsync();
      alert('Immobilizer removed successfully!');
      await exitBootMutation.mutateAsync();
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleBootClone = async () => {
    setActiveOperation('boot-clone');
    try {
      await enterBootMutation.mutateAsync({ method: selectedMode as 'BDM' | 'JTAG' });
      const result = await bootCloneMutation.mutateAsync({
        includeFlash: true,
        includeEEPROM: true,
      });
      alert(`ECM cloned successfully!\nFlash: ${result.backup.flash}\nEEPROM: ${result.backup.eeprom}`);
      await exitBootMutation.mutateAsync();
    } finally {
      setActiveOperation(null);
    }
  };
  
  const handleHybridProgram = async () => {
    setActiveOperation('hybrid-program');
    setHybridSteps([]);
    
    try {
      const result = await hybridCompleteMutation.mutateAsync({
        vin: hybridVIN || undefined,
        odometer: hybridOdometer ? parseInt(hybridOdometer) : undefined,
        calibrationFile: hybridCalibration || undefined,
        removeImmobilizer: hybridRemoveImmo,
      });
      
      setHybridSteps(result.steps);
      alert(`Programming complete!\nMode: ${result.mode}\nDuration: ${(result.duration / 1000).toFixed(1)}s`);
    } finally {
      setActiveOperation(null);
    }
  };
  
  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'OBD2': return <Wifi className="h-5 w-5" />;
      case 'BDM': return <Cpu className="h-5 w-5" />;
      case 'JTAG': return <Cable className="h-5 w-5" />;
      case 'Hybrid': return <Zap className="h-5 w-5" />;
      default: return <Settings className="h-5 w-5" />;
    }
  };
  
  const getModeColor = (mode: string) => {
    switch (mode) {
      case 'OBD2': return 'bg-blue-500';
      case 'BDM': return 'bg-orange-500';
      case 'JTAG': return 'bg-purple-500';
      case 'Hybrid': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };
  
  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold">ECM Bench Programming</h1>
          <p className="text-muted-foreground mt-2">
            Program ECMs on bench via OBD2, Boot Mode (BDM/JTAG), or Hybrid approach
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <Select value={selectedMode} onValueChange={(v) => setSelectedMode(v as ProgrammingMode)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Hybrid">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  Hybrid (Auto)
                </div>
              </SelectItem>
              <SelectItem value="OBD2">
                <div className="flex items-center gap-2">
                  <Wifi className="h-4 w-4" />
                  OBD2 Only
                </div>
              </SelectItem>
              <SelectItem value="BDM">
                <div className="flex items-center gap-2">
                  <Cpu className="h-4 w-4" />
                  BDM Boot Mode
                </div>
              </SelectItem>
              <SelectItem value="JTAG">
                <div className="flex items-center gap-2">
                  <Cable className="h-4 w-4" />
                  JTAG Boot Mode
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            onClick={handleDetectECM} 
            disabled={isConnecting}
            size="lg"
          >
            {isConnecting ? 'Detecting...' : 'Detect ECM'}
          </Button>
        </div>
      </div>
      
      {/* Connection Status */}
      {connection && (
        <Alert className={connection.connected ? 'border-green-500' : 'border-red-500'}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {connection.connected ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
              <div>
                <AlertDescription className="font-semibold">
                  {connection.message}
                </AlertDescription>
                {connection.ecuType && (
                  <div className="text-sm text-muted-foreground mt-1">
                    {connection.ecuType} • {connection.partNumber}
                  </div>
                )}
              </div>
            </div>
            
            <Badge className={getModeColor(connection.mode)}>
              {getModeIcon(connection.mode)}
              <span className="ml-2">{connection.mode}</span>
            </Badge>
          </div>
        </Alert>
      )}
      
      {/* Main Tabs */}
      <Tabs value={selectedMode} onValueChange={(v) => setSelectedMode(v as ProgrammingMode)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="Hybrid">
            <Zap className="h-4 w-4 mr-2" />
            Hybrid Mode
          </TabsTrigger>
          <TabsTrigger value="OBD2">
            <Wifi className="h-4 w-4 mr-2" />
            OBD2 Mode
          </TabsTrigger>
          <TabsTrigger value="BDM">
            <Cpu className="h-4 w-4 mr-2" />
            BDM Mode
          </TabsTrigger>
          <TabsTrigger value="JTAG">
            <Cable className="h-4 w-4 mr-2" />
            JTAG Mode
          </TabsTrigger>
        </TabsList>
        
        {/* Hybrid Mode Tab */}
        <TabsContent value="Hybrid" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Hybrid Programming (Automatic Fallback)
              </CardTitle>
              <CardDescription>
                Attempts OBD2 first, automatically falls back to Boot Mode if needed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="hybrid-vin">VIN (Optional)</Label>
                  <Input
                    id="hybrid-vin"
                    value={hybridVIN}
                    onChange={(e) => setHybridVIN(e.target.value.toUpperCase())}
                    placeholder="1C3CDFBB8ED123456"
                    maxLength={17}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="hybrid-odometer">Odometer (Optional)</Label>
                  <Input
                    id="hybrid-odometer"
                    type="number"
                    value={hybridOdometer}
                    onChange={(e) => setHybridOdometer(e.target.value)}
                    placeholder="125000"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="hybrid-calibration">Calibration File (Optional)</Label>
                <Input
                  id="hybrid-calibration"
                  value={hybridCalibration}
                  onChange={(e) => setHybridCalibration(e.target.value)}
                  placeholder="calibration_v2.5.bin"
                />
              </div>
              
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Remove Immobilizer</Label>
                  <p className="text-sm text-muted-foreground">
                    ECM will start without SKIM (requires Boot Mode)
                  </p>
                </div>
                <Switch
                  checked={hybridRemoveImmo}
                  onCheckedChange={setHybridRemoveImmo}
                />
              </div>
              
              <Button 
                onClick={handleHybridProgram} 
                disabled={!connection?.connected || activeOperation !== null}
                className="w-full"
                size="lg"
              >
                <Play className="h-4 w-4 mr-2" />
                {activeOperation === 'hybrid-program' ? 'Programming...' : 'Start Hybrid Programming'}
              </Button>
              
              {/* Progress Steps */}
              {hybridSteps.length > 0 && (
                <div className="space-y-2 mt-6">
                  <h3 className="font-semibold">Programming Steps:</h3>
                  <div className="space-y-1">
                    {hybridSteps.map((step, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm p-2 border rounded">
                        {step.status === 'success' ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
                        ) : step.status === 'failed' ? (
                          <XCircle className="h-4 w-4 text-red-500 flex-shrink-0" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-yellow-500 flex-shrink-0" />
                        )}
                        <span className="flex-1">{step.step}</span>
                        {step.duration && (
                          <span className="text-muted-foreground">{(step.duration / 1000).toFixed(1)}s</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* OBD2 Mode Tab */}
        <TabsContent value="OBD2" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* VIN Programming */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">VIN Programming</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>VIN (17 characters)</Label>
                  <Input
                    value={obd2VIN}
                    onChange={(e) => setObd2VIN(e.target.value.toUpperCase())}
                    placeholder="1C3CDFBB8ED123456"
                    maxLength={17}
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    onClick={handleOBD2ReadVIN}
                    disabled={!connection?.connected || activeOperation !== null}
                    variant="outline"
                    className="flex-1"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Read
                  </Button>
                  <Button 
                    onClick={handleOBD2WriteVIN}
                    disabled={!connection?.connected || activeOperation !== null}
                    className="flex-1"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Write
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Odometer Programming */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Odometer Programming</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Odometer (miles)</Label>
                  <Input
                    type="number"
                    value={obd2Odometer}
                    onChange={(e) => setObd2Odometer(e.target.value)}
                    placeholder="125000"
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    onClick={handleOBD2ReadOdometer}
                    disabled={!connection?.connected || activeOperation !== null}
                    variant="outline"
                    className="flex-1"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Read
                  </Button>
                  <Button 
                    onClick={handleOBD2WriteOdometer}
                    disabled={!connection?.connected || activeOperation !== null}
                    className="flex-1"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Write
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Calibration Flash */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Calibration Flash</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Calibration File</Label>
                  <Input
                    value={obd2CalibrationFile}
                    onChange={(e) => setObd2CalibrationFile(e.target.value)}
                    placeholder="calibration_v2.5.bin"
                  />
                </div>
                
                <Button 
                  onClick={handleOBD2Flash}
                  disabled={!connection?.connected || activeOperation !== null}
                  className="w-full"
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Flash Calibration (~45s)
                </Button>
              </CardContent>
            </Card>
            
            {/* DTC Management */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">DTC Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={async () => {
                    const result = await obd2ReadDTCsMutation.mutateAsync();
                    alert(`Found ${result.count} DTCs:\n${result.dtcs.map(d => `${d.code}: ${d.description}`).join('\n')}`);
                  }}
                  disabled={!connection?.connected}
                  variant="outline"
                  className="w-full"
                >
                  <Info className="h-4 w-4 mr-2" />
                  Read DTCs
                </Button>
                
                <Button 
                  onClick={async () => {
                    const result = await obd2ClearDTCsMutation.mutateAsync();
                    alert(`Cleared ${result.cleared} DTCs`);
                  }}
                  disabled={!connection?.connected}
                  variant="outline"
                  className="w-full"
                >
                  <StopCircle className="h-4 w-4 mr-2" />
                  Clear DTCs
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* BDM/JTAG Mode Tabs */}
        {['BDM', 'JTAG'].map((mode) => (
          <TabsContent key={mode} value={mode} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* Flash Operations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Flash Memory</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Flash File</Label>
                    <Input
                      value={bootFlashFile}
                      onChange={(e) => setBootFlashFile(e.target.value)}
                      placeholder="flash_backup.bin"
                    />
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={bootVerify}
                      onCheckedChange={setBootVerify}
                    />
                    <Label>Verify after write</Label>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleBootReadFlash}
                      disabled={!connection?.connected || activeOperation !== null}
                      variant="outline"
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Read (~15s)
                    </Button>
                    <Button 
                      onClick={handleBootWriteFlash}
                      disabled={!connection?.connected || activeOperation !== null}
                      className="flex-1"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Write (~30s)
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              {/* EEPROM Operations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">EEPROM</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>EEPROM File</Label>
                    <Input
                      value={bootEEPROMFile}
                      onChange={(e) => setBootEEPROMFile(e.target.value)}
                      placeholder="eeprom_backup.bin"
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={async () => {
                        setActiveOperation('boot-read-eeprom');
                        try {
                          await enterBootMutation.mutateAsync({ method: mode as 'BDM' | 'JTAG' });
                          const result = await bootReadEEPROMMutation.mutateAsync({});
                          alert(`EEPROM read complete! Saved to: ${result.data}`);
                          await exitBootMutation.mutateAsync();
                        } finally {
                          setActiveOperation(null);
                        }
                      }}
                      disabled={!connection?.connected || activeOperation !== null}
                      variant="outline"
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Read
                    </Button>
                    <Button 
                      onClick={async () => {
                        if (!bootEEPROMFile) {
                          alert('Please select an EEPROM file');
                          return;
                        }
                        setActiveOperation('boot-write-eeprom');
                        try {
                          await enterBootMutation.mutateAsync({ method: mode as 'BDM' | 'JTAG' });
                          await bootWriteEEPROMMutation.mutateAsync({ 
                            file: bootEEPROMFile,
                            verify: bootVerify,
                          });
                          alert('EEPROM written successfully!');
                          await exitBootMutation.mutateAsync();
                        } finally {
                          setActiveOperation(null);
                        }
                      }}
                      disabled={!connection?.connected || activeOperation !== null}
                      className="flex-1"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Write
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              {/* Security Operations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Security Operations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button 
                    onClick={handleBootUnlock}
                    disabled={!connection?.connected || activeOperation !== null}
                    variant="outline"
                    className="w-full"
                  >
                    <Unlock className="h-4 w-4 mr-2" />
                    Unlock ECM
                  </Button>
                  
                  <Button 
                    onClick={handleBootRemoveImmo}
                    disabled={!connection?.connected || activeOperation !== null}
                    variant="outline"
                    className="w-full"
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    Remove Immobilizer
                  </Button>
                </CardContent>
              </Card>
              
              {/* Clone/Restore */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Clone & Restore</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button 
                    onClick={handleBootClone}
                    disabled={!connection?.connected || activeOperation !== null}
                    variant="outline"
                    className="w-full"
                  >
                    <HardDrive className="h-4 w-4 mr-2" />
                    Full Clone (~20s)
                  </Button>
                  
                  <Button 
                    onClick={async () => {
                      if (!bootFlashFile && !bootEEPROMFile) {
                        alert('Please select flash and/or EEPROM file');
                        return;
                      }
                      setActiveOperation('boot-restore');
                      try {
                        await enterBootMutation.mutateAsync({ method: mode as 'BDM' | 'JTAG' });
                        await bootRestoreMutation.mutateAsync({
                          flashFile: bootFlashFile || undefined,
                          eepromFile: bootEEPROMFile || undefined,
                          verify: bootVerify,
                        });
                        alert('ECM restored successfully!');
                        await exitBootMutation.mutateAsync();
                      } finally {
                        setActiveOperation(null);
                      }
                    }}
                    disabled={!connection?.connected || activeOperation !== null}
                    className="w-full"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Restore from Backup
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        ))}
      </Tabs>
      
      {/* Wiring Guide */}
      {wiringGuide && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cable className="h-5 w-5" />
              {wiringGuide.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold mb-2">Pin Connections:</h3>
                <div className="space-y-1">
                  {wiringGuide.connections.map((conn: any, index: number) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <Badge variant={conn.required ? 'default' : 'outline'}>
                        {conn.pin}
                      </Badge>
                      <span className="flex-1">{conn.signal}</span>
                      <span className="text-muted-foreground">{conn.wire}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Important Notes:</h3>
                <ul className="space-y-1 text-sm list-disc list-inside">
                  {wiringGuide.notes.map((note: string, index: number) => (
                    <li key={index} className="text-muted-foreground">{note}</li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Supported ECUs */}
      {supportedECUs && (
        <Card>
          <CardHeader>
            <CardTitle>Supported ECU Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {supportedECUs.map((ecu: any, index: number) => (
                <div key={index} className="p-4 border rounded-lg">
                  <h3 className="font-semibold">{ecu.manufacturer}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {ecu.models.join(', ')}
                  </p>
                  <div className="flex gap-2 mt-2">
                    {ecu.obd2Support && <Badge variant="outline">OBD2</Badge>}
                    {ecu.bdmSupport && <Badge variant="outline">BDM</Badge>}
                    {ecu.jtagSupport && <Badge variant="outline">JTAG</Badge>}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Active Operation Indicator */}
      {activeOperation && (
        <div className="fixed bottom-4 right-4 bg-background border shadow-lg rounded-lg p-4 min-w-[300px]">
          <div className="flex items-center gap-3">
            <div className="animate-spin">
              <Settings className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold">Operation in Progress</p>
              <p className="text-sm text-muted-foreground">{activeOperation.replace(/-/g, ' ')}</p>
            </div>
          </div>
          <Progress value={undefined} className="mt-2" />
        </div>
      )}
    </div>
  );
}
