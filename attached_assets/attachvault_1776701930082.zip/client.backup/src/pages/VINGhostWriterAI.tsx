import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, Sparkles } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';

export default function VINGhostWriterAI() {
  const [year, setYear] = useState(2020);
  const [make, setMake] = useState('Dodge');
  const [model, setModel] = useState('');
  const [engine, setEngine] = useState('');
  const [transmission, setTransmission] = useState('');
  const [vinData, setVinData] = useState('');

  const generateMutation = trpc.ai.generateVIN.useMutation();

  const handleGenerate = async () => {
    if (!model) {
      alert('Please provide vehicle model');
      return;
    }

    try {
      const response = await generateMutation.mutateAsync({
        year,
        make,
        model,
        engine: engine || undefined,
        transmission: transmission || undefined
      });
      setVinData(typeof response.vinData === 'string' ? response.vinData : JSON.stringify(response.vinData));
    } catch (error) {
      console.error('VIN generation failed:', error);
      alert('VIN generation failed. Please try again.');
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Sparkles className="w-10 h-10 text-primary" />
          VIN Ghost Writer AI
        </h1>
        <p className="text-muted-foreground">
          Generate valid VINs for module programming. AI-powered VIN structure analysis with check digit calculation.
        </p>
      </div>

      <Alert className="mb-6 border-red-500/50 bg-red-500/10">
        <AlertDescription>
          <strong>⚠️ LEGAL WARNING:</strong> Generated VINs are for MODULE PROGRAMMING ONLY (replacing modules, 
          VIN synchronization). DO NOT use for vehicle registration, title fraud, or illegal purposes. 
          Always use the vehicle's original VIN when possible.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Vehicle Specifications</CardTitle>
            <CardDescription>Provide vehicle details for VIN generation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="year">Model Year *</Label>
              <Select value={year.toString()} onValueChange={(v) => setYear(parseInt(v))}>
                <SelectTrigger id="year">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 30 }, (_, i) => 2024 - i).map(y => (
                    <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="make">Make *</Label>
              <Select value={make} onValueChange={setMake}>
                <SelectTrigger id="make">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Dodge">Dodge</SelectItem>
                  <SelectItem value="Chrysler">Chrysler</SelectItem>
                  <SelectItem value="Jeep">Jeep</SelectItem>
                  <SelectItem value="RAM">RAM</SelectItem>
                  <SelectItem value="Fiat">Fiat</SelectItem>
                  <SelectItem value="Alfa Romeo">Alfa Romeo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="model">Model *</Label>
              <Input
                id="model"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="Charger, Challenger, Grand Cherokee, 1500"
              />
            </div>

            <div>
              <Label htmlFor="engine">Engine (Optional)</Label>
              <Input
                id="engine"
                value={engine}
                onChange={(e) => setEngine(e.target.value)}
                placeholder="5.7L HEMI V8, 3.6L Pentastar V6, 6.2L Supercharged V8"
              />
            </div>

            <div>
              <Label htmlFor="transmission">Transmission (Optional)</Label>
              <Input
                id="transmission"
                value={transmission}
                onChange={(e) => setTransmission(e.target.value)}
                placeholder="8-speed automatic, 6-speed manual"
              />
            </div>

            <Button 
              onClick={handleGenerate} 
              disabled={generateMutation.isPending || !model}
              className="w-full"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate VIN
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Generated VIN</CardTitle>
            <CardDescription>AI-generated valid VIN structure</CardDescription>
          </CardHeader>
          <CardContent>
            {vinData ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{vinData}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Sparkles className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Enter vehicle specs to generate VIN</p>
                <p className="text-xs mt-2">
                  For module programming only
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* VIN Structure Reference */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>VIN Structure Reference (17 Characters)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <h3 className="font-semibold mb-2">Positions 1-3: WMI</h3>
              <p className="text-sm text-muted-foreground mb-2">World Manufacturer Identifier</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• 1C3/1C4/1C6 - Chrysler US</li>
                <li>• 2C3/2C4 - Chrysler Canada</li>
                <li>• 3C4/3C6 - Chrysler Mexico</li>
                <li>• 1J4 - Jeep</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Positions 4-9: VDS</h3>
              <p className="text-sm text-muted-foreground mb-2">Vehicle Descriptor Section</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• 4-8: Model, body, engine</li>
                <li>• 9: Check digit (calculated)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Positions 10-17: VIS</h3>
              <p className="text-sm text-muted-foreground mb-2">Vehicle Identifier Section</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• 10: Model year code</li>
                <li>• 11: Plant code</li>
                <li>• 12-17: Sequential number</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Use Cases */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Valid Use Cases</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="font-semibold mb-2 text-green-600">✅ LEGAL Uses</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Module replacement (BCM, ECM, TCM)</li>
                <li>• VIN synchronization across modules</li>
                <li>• Fixing C2202 VIN mismatch DTC</li>
                <li>• Module cloning/backup</li>
                <li>• Testing diagnostic tools</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-red-600">❌ ILLEGAL Uses</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Vehicle registration fraud</li>
                <li>• Title washing</li>
                <li>• Odometer tampering</li>
                <li>• Stolen vehicle re-identification</li>
                <li>• Insurance fraud</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
