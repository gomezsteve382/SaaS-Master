import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Alert, AlertDescription } from "../components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { toast } from "sonner";
import { Usb, CheckCircle, XCircle, RefreshCw, Terminal, AlertTriangle, Download } from "lucide-react";
import { BackButton } from "../components/BackButton";

interface J2534Device {
  name: string;
  dll: string;
  connected: boolean;
}

export default function J2534Bridge() {
  const [wsConnected, setWsConnected] = useState(false);
  const [devices, setDevices] = useState<J2534Device[]>([]);
  const [selectedDevice, setSelectedDevice] = useState<J2534Device | null>(null);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [...prev, `[${timestamp}] ${message}`]);
  };

  const connectWebSocket = () => {
    try {
      const websocket = new WebSocket("ws://localhost:8765");
      
      websocket.onopen = () => {
        setWsConnected(true);
        addLog("✅ Connected to J2534 Bridge");
        toast.success("Connected to J2534 Bridge");
        
        // Request device list
        websocket.send(JSON.stringify({ command: "list_devices" }));
      };

      websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === "device_list") {
            setDevices(data.devices);
            addLog(`Found ${data.devices.length} J2534 device(s)`);
          } else if (data.type === "device_connected") {
            setSelectedDevice(data.device);
            addLog(`✅ Connected to ${data.device.name}`);
            toast.success(`Connected to ${data.device.name}`);
          } else if (data.type === "error") {
            addLog(`❌ Error: ${data.message}`);
            toast.error(data.message);
          } else if (data.type === "log") {
            addLog(data.message);
          }
        } catch (err) {
          addLog(`Error parsing message: ${err}`);
        }
      };

      websocket.onclose = () => {
        setWsConnected(false);
        setSelectedDevice(null);
        addLog("❌ Disconnected from J2534 Bridge");
        toast.error("Disconnected from J2534 Bridge");
      };

      websocket.onerror = (error) => {
        addLog(`❌ WebSocket error: ${error}`);
        toast.error("Failed to connect to J2534 Bridge");
      };

      setWs(websocket);
    } catch (err) {
      addLog(`❌ Connection error: ${err}`);
      toast.error("Failed to connect to J2534 Bridge");
    }
  };

  const disconnectWebSocket = () => {
    if (ws) {
      ws.close();
      setWs(null);
    }
  };

  const connectDevice = (device: J2534Device) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        command: "connect_device",
        dll: device.dll,
      }));
      addLog(`Connecting to ${device.name}...`);
    }
  };

  const testCommunication = () => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        command: "test_communication",
        tx_id: 0x7E0,
        rx_id: 0x7E8,
        data: [0x01, 0x00], // OBD2 Mode 01 PID 00
      }));
      addLog("Testing CAN communication...");
    }
  };

  useEffect(() => {
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, [ws]);

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <BackButton />
          <h1 className="text-3xl font-bold flex items-center gap-2 mt-2">
            <Usb className="h-8 w-8" />
            J2534 PassThru Bridge
          </h1>
          <p className="text-muted-foreground mt-1">
            Connect professional J2534 devices for real hardware communication
          </p>
        </div>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Bridge Status
            {wsConnected ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle className="h-3 w-3 mr-1" />
                Connected
              </Badge>
            ) : (
              <Badge variant="destructive">
                <XCircle className="h-3 w-3 mr-1" />
                Disconnected
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            WebSocket bridge running on localhost:8765
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!wsConnected ? (
            <div>
              <Button onClick={connectWebSocket} className="w-full">
                <Usb className="h-4 w-4 mr-2" />
                Connect to J2534 Bridge
              </Button>
              
              <Alert className="mt-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Bridge Not Running</strong>
                  <br />
                  Start the J2534 bridge on your Windows machine:
                  <ol className="list-decimal ml-4 mt-2 space-y-1">
                    <li>Download j2534-bridge folder from project</li>
                    <li>Install Python 3.8+ and run: <code className="bg-black px-1">pip install websockets</code></li>
                    <li>Run: <code className="bg-black px-1">python j2534_bridge.py</code></li>
                    <li>Click "Connect to J2534 Bridge" above</li>
                  </ol>
                </AlertDescription>
              </Alert>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex gap-2">
                <Button onClick={() => ws?.send(JSON.stringify({ command: "list_devices" }))} variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh Devices
                </Button>
                <Button onClick={disconnectWebSocket} variant="outline">
                  Disconnect Bridge
                </Button>
              </div>

              {selectedDevice && (
                <Alert className="bg-green-50 dark:bg-green-950 border-green-500">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <AlertDescription>
                    <strong>Device Connected:</strong> {selectedDevice.name}
                    <br />
                    <span className="text-xs text-muted-foreground">{selectedDevice.dll}</span>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Device List */}
      {wsConnected && (
        <Card>
          <CardHeader>
            <CardTitle>Available J2534 Devices</CardTitle>
            <CardDescription>
              {devices.length} device{devices.length !== 1 ? "s" : ""} detected
            </CardDescription>
          </CardHeader>
          <CardContent>
            {devices.length === 0 ? (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  No J2534 devices found. Make sure your PassThru device is connected and drivers are installed.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-3">
                {devices.map((device, idx) => (
                  <Card
                    key={idx}
                    className={`cursor-pointer transition-colors ${
                      selectedDevice?.dll === device.dll
                        ? "border-green-500 bg-green-50 dark:bg-green-950"
                        : "hover:bg-accent"
                    }`}
                    onClick={() => connectDevice(device)}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{device.name}</CardTitle>
                          <CardDescription className="text-xs font-mono">
                            {device.dll}
                          </CardDescription>
                        </div>
                        {selectedDevice?.dll === device.dll ? (
                          <Badge variant="default" className="bg-green-500">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Connected
                          </Badge>
                        ) : (
                          <Button size="sm" variant="outline">
                            Connect
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Testing & Logs */}
      {wsConnected && selectedDevice && (
        <Tabs defaultValue="test" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="test">Communication Test</TabsTrigger>
            <TabsTrigger value="logs">Bridge Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="test">
            <Card>
              <CardHeader>
                <CardTitle>Test CAN Communication</CardTitle>
                <CardDescription>
                  Send test messages to verify device is working
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={testCommunication} className="w-full">
                  <Terminal className="h-4 w-4 mr-2" />
                  Send Test Message (OBD2 Mode 01)
                </Button>

                <Alert>
                  <AlertDescription>
                    This will send a standard OBD2 request (Mode 01 PID 00) to verify the device can communicate with the vehicle.
                    Check the logs tab for results.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="h-5 w-5" />
                  Bridge Logs
                </CardTitle>
                <CardDescription>
                  Real-time communication logs from J2534 bridge
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm h-96 overflow-y-auto">
                  {logs.length === 0 ? (
                    <div className="text-muted-foreground">No logs yet...</div>
                  ) : (
                    logs.map((log, idx) => (
                      <div key={idx}>{log}</div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Download Bridge */}
      <Card className="bg-blue-50 dark:bg-blue-950 border-blue-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Download J2534 Bridge
          </CardTitle>
          <CardDescription>
            Get the bridge software for Windows
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm">
            The J2534 bridge is a Python script that runs on Windows and connects your PassThru device to this web application via WebSocket.
          </p>
          
          <div className="space-y-2">
            <h4 className="font-semibold">Supported Devices:</h4>
            <ul className="list-disc ml-6 text-sm space-y-1">
              <li>Autel MaxiSys / MaxiFlash Pro</li>
              <li>Drew Technologies Mongoose</li>
              <li>Tactrix OpenPort 2.0</li>
              <li>Any J2534-compliant PassThru device</li>
            </ul>
          </div>

          <Alert>
            <AlertDescription>
              <strong>Location:</strong> The bridge files are in the <code className="bg-black px-1">j2534-bridge/</code> folder of this project.
              <br />
              <strong>Requirements:</strong> Windows 7+ with Python 3.8+ and device drivers installed.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}
