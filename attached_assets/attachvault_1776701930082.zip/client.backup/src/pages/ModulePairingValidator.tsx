import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BackButton } from "@/components/BackButton";
import { CheckCircle2, XCircle, AlertTriangle, Loader2, Shield, Download } from "lucide-react";

interface PairingData {
  module: string;
  vin?: string;
  secretKey?: string;
  immobilizerBytes?: string;
  status: "valid" | "mismatch" | "missing";
}

export default function ModulePairingValidator() {
  const [validating, setValidating] = useState(false);
  const [pairingData, setPairingData] = useState<PairingData[]>([]);
  const [report, setReport] = useState("");

  const [rfhubFile, setRFHubFile] = useState<File | null>(null);
  const [bcmFile, setBCMFile] = useState<File | null>(null);
  const [ecmFile, setECMFile] = useState<File | null>(null);

  const handleFileUpload = (file: File, moduleType: string) => {
    switch (moduleType) {
      case "RFHUB":
        setRFHubFile(file);
        break;
      case "BCM":
        setBCMFile(file);
        break;
      case "ECM":
        setECMFile(file);
        break;
    }
  };

  const validatePairing = async () => {
    if (!rfhubFile && !bcmFile && !ecmFile) {
      alert("Please upload at least one module file");
      return;
    }

    setValidating(true);
    
    const data: PairingData[] = [];

    // Parse RFHUB file
    if (rfhubFile) {
      try {
        const buffer = await rfhubFile.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        
        // Extract VIN (typically at offset 0x4000-0x4010 in RFHUB EEPROM)
        let vin = "";
        for (let i = 0x4000; i < 0x4011 && i < bytes.length; i++) {
          const char = bytes[i];
          if (char >= 0x30 && char <= 0x5A) {
            vin += String.fromCharCode(char);
          }
        }
        
        // Extract secret key (typically at 0x4020-0x4027)
        let secretKey = "";
        for (let i = 0x4020; i < 0x4028 && i < bytes.length; i++) {
          secretKey += bytes[i].toString(16).padStart(2, '0').toUpperCase();
        }
        
        data.push({
          module: "RFHUB",
          vin: vin.length === 17 ? vin : undefined,
          secretKey: secretKey.length === 16 ? secretKey : undefined,
          status: "valid"
        });
      } catch (error) {
        console.error('Failed to parse RFHUB file:', error);
      }
    }

    // Parse BCM file
    if (bcmFile) {
      try {
        const buffer = await bcmFile.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        
        // Extract VIN (typically at offset 0x8000-0x8010 in BCM)
        let vin = "";
        for (let i = 0x8000; i < 0x8011 && i < bytes.length; i++) {
          const char = bytes[i];
          if (char >= 0x30 && char <= 0x5A) {
            vin += String.fromCharCode(char);
          }
        }
        
        // Extract immobilizer bytes (typically at 0x8020-0x8027)
        let immobilizerBytes = "";
        for (let i = 0x8020; i < 0x8028 && i < bytes.length; i++) {
          immobilizerBytes += bytes[i].toString(16).padStart(2, '0').toUpperCase();
        }
        
        data.push({
          module: "BCM",
          vin: vin.length === 17 ? vin : undefined,
          immobilizerBytes: immobilizerBytes.length === 16 ? immobilizerBytes : undefined,
          status: "valid"
        });
      } catch (error) {
        console.error('Failed to parse BCM file:', error);
      }
    }

    // Parse ECM file
    if (ecmFile) {
      try {
        const buffer = await ecmFile.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        
        // Extract VIN (typically at offset 0xC000-0xC010 in ECM)
        let vin = "";
        for (let i = 0xC000; i < 0xC011 && i < bytes.length; i++) {
          const char = bytes[i];
          if (char >= 0x30 && char <= 0x5A) {
            vin += String.fromCharCode(char);
          }
        }
        
        // Extract immobilizer bytes (typically at 0xC020-0xC027)
        let immobilizerBytes = "";
        for (let i = 0xC020; i < 0xC028 && i < bytes.length; i++) {
          immobilizerBytes += bytes[i].toString(16).padStart(2, '0').toUpperCase();
        }
        
        data.push({
          module: "ECM",
          vin: vin.length === 17 ? vin : undefined,
          immobilizerBytes: immobilizerBytes.length === 16 ? immobilizerBytes : undefined,
          status: "valid"
        });
      } catch (error) {
        console.error('Failed to parse ECM file:', error);
      }
    }

    // Check for mismatches
    const vins = data.map(d => d.vin).filter(Boolean) as string[];
    const uniqueVINs = Array.from(new Set(vins));
    
    if (uniqueVINs.length > 1) {
      data.forEach(d => {
        if (d.vin && d.vin !== uniqueVINs[0]) {
          d.status = "mismatch";
        }
      });
    }

    // Check secret key matching
    const rfhubSecretKey = data.find(d => d.module === "RFHUB")?.secretKey;
    const bcmImmobilizer = data.find(d => d.module === "BCM")?.immobilizerBytes;
    const ecmImmobilizer = data.find(d => d.module === "ECM")?.immobilizerBytes;

    if (rfhubSecretKey && bcmImmobilizer && rfhubSecretKey !== bcmImmobilizer) {
      const rfhub = data.find(d => d.module === "RFHUB");
      const bcm = data.find(d => d.module === "BCM");
      if (rfhub) rfhub.status = "mismatch";
      if (bcm) bcm.status = "mismatch";
    }

    if (rfhubSecretKey && ecmImmobilizer && rfhubSecretKey !== ecmImmobilizer) {
      const rfhub = data.find(d => d.module === "RFHUB");
      const ecm = data.find(d => d.module === "ECM");
      if (rfhub) rfhub.status = "mismatch";
      if (ecm) ecm.status = "mismatch";
    }

    setPairingData(data);

    // Generate report
    let reportText = `Module Pairing Validation Report\n`;
    reportText += `Date: ${new Date().toLocaleString()}\n\n`;
    
    data.forEach(d => {
      reportText += `[${d.module}]\n`;
      reportText += `  VIN: ${d.vin || "Not found"}\n`;
      if (d.secretKey) reportText += `  Secret Key: ${d.secretKey}\n`;
      if (d.immobilizerBytes) reportText += `  Immobilizer: ${d.immobilizerBytes}\n`;
      reportText += `  Status: ${d.status.toUpperCase()}\n\n`;
    });

    const hasMismatches = data.some(d => d.status === "mismatch");
    if (hasMismatches) {
      reportText += `\n⚠️ PAIRING MISMATCHES DETECTED\n`;
      reportText += `Action Required: Update mismatched modules before flashing\n`;
    } else {
      reportText += `\n✓ ALL MODULES PROPERLY PAIRED\n`;
    }

    setReport(reportText);
    setValidating(false);
  };

  const downloadReport = () => {
    const blob = new Blob([report], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pairing_validation_${new Date().getTime()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusBadge = (status: PairingData["status"]) => {
    switch (status) {
      case "valid":
        return <Badge className="bg-green-600">Valid</Badge>;
      case "mismatch":
        return <Badge variant="destructive">Mismatch</Badge>;
      case "missing":
        return <Badge variant="secondary">Missing</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Module Pairing Validator</h1>
          <p className="text-gray-600 mt-2">
            Verify RFHUB Secret Key matches BCM/ECM immobilizer bytes to prevent pairing issues
          </p>
        </div>

        <Alert>
          <Shield className="h-4 w-4" />
          <AlertDescription>
            <strong>Pre-Flash Validation:</strong> Always verify module pairing before flashing to prevent
            immobilizer lockout. RFHUB Secret Key (0x120) must match BCM and ECM immobilizer bytes.
          </AlertDescription>
        </Alert>

        {/* File Upload */}
        <Card>
          <CardHeader>
            <CardTitle>Upload Module Files</CardTitle>
            <CardDescription>
              Upload EEPROM dumps from RFHUB, BCM, and ECM for pairing validation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* RFHUB Upload */}
              <div className="space-y-2">
                <Label htmlFor="rfhub">RFHUB File</Label>
                <Input
                  id="rfhub"
                  type="file"
                  accept=".bin,.eeprom,.flash,.eee"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], "RFHUB")}
                  disabled={validating}
                />
                {rfhubFile && (
                  <p className="text-sm text-green-600">✓ {rfhubFile.name}</p>
                )}
              </div>

              {/* BCM Upload */}
              <div className="space-y-2">
                <Label htmlFor="bcm">BCM File</Label>
                <Input
                  id="bcm"
                  type="file"
                  accept=".bin,.eeprom,.flash"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], "BCM")}
                  disabled={validating}
                />
                {bcmFile && (
                  <p className="text-sm text-green-600">✓ {bcmFile.name}</p>
                )}
              </div>

              {/* ECM Upload */}
              <div className="space-y-2">
                <Label htmlFor="ecm">ECM File</Label>
                <Input
                  id="ecm"
                  type="file"
                  accept=".bin,.eeprom,.flash"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], "ECM")}
                  disabled={validating}
                />
                {ecmFile && (
                  <p className="text-sm text-green-600">✓ {ecmFile.name}</p>
                )}
              </div>
            </div>

            <Button
              onClick={validatePairing}
              disabled={validating || (!rfhubFile && !bcmFile && !ecmFile)}
              className="w-full"
              size="lg"
            >
              {validating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Validate Pairing
            </Button>
          </CardContent>
        </Card>

        {/* Validation Results */}
        {pairingData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Pairing Validation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pairingData.map(data => (
                  <div
                    key={data.module}
                    className="p-4 border rounded-lg"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-lg">{data.module}</h3>
                      {getStatusBadge(data.status)}
                    </div>
                    <div className="space-y-1 text-sm">
                      {data.vin && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">VIN:</span>
                          <span className="font-mono">{data.vin}</span>
                        </div>
                      )}
                      {data.secretKey && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Secret Key (0x120):</span>
                          <span className="font-mono">{data.secretKey}</span>
                        </div>
                      )}
                      {data.immobilizerBytes && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Immobilizer Bytes:</span>
                          <span className="font-mono">{data.immobilizerBytes}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {pairingData.some(d => d.status === "mismatch") && (
                <Alert variant="destructive" className="mt-4">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Pairing Mismatch Detected!</strong>
                    <br />
                    RFHUB Secret Key does not match BCM/ECM immobilizer bytes. Update the mismatched
                    module before flashing to prevent immobilizer lockout.
                  </AlertDescription>
                </Alert>
              )}

              {pairingData.every(d => d.status === "valid") && (
                <Alert className="mt-4">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>
                    <strong>All Modules Properly Paired!</strong>
                    <br />
                    RFHUB Secret Key matches BCM and ECM immobilizer bytes. Safe to flash.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}

        {/* Report */}
        {report && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Validation Report
                <Button onClick={downloadReport} variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download Report
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                {report}
              </pre>
            </CardContent>
          </Card>
        )}

        {/* Reference Guide */}
        <Card>
          <CardHeader>
            <CardTitle>Pairing Reference Guide</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">RFHUB Offsets</h3>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• VIN: 0x100-0x110 (17 bytes, ASCII)</li>
                <li>• Secret Key: 0x120-0x130 (16 bytes, hex)</li>
                <li>• B-number: 0x140-0x150 (16 bytes, ASCII)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">BCM Offsets</h3>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• VIN: 0x100-0x110 or 0x200-0x210 (17 bytes, ASCII)</li>
                <li>• Immobilizer Bytes: Varies by model (search for RFHUB Secret Key match)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">ECM Offsets</h3>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• VIN: 0x160-0x170 (17 bytes, ASCII)</li>
                <li>• Immobilizer Bytes: Varies by model (search for RFHUB Secret Key match)</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
