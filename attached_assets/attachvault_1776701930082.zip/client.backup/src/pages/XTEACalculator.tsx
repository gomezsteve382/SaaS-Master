import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BackButton } from "@/components/BackButton";
import { Key, Copy, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

interface CalculatedKeys {
  method1: string;
  method2: string;
  method3: string;
}

export default function XTEACalculator() {
  const [seed, setSeed] = useState("");
  const [securityLevel, setSecurityLevel] = useState<"09" | "0A" | "default">("09");
  const [calculatedKeys, setCalculatedKeys] = useState<CalculatedKeys | null>(null);

  const handleCalculate = () => {
    if (seed.length !== 10) {
      toast.error("Seed must be exactly 10 hex characters (5 bytes)");
      return;
    }

    if (!/^[0-9A-Fa-f]{10}$/.test(seed)) {
      toast.error("Seed must contain only hex characters (0-9, A-F)");
      return;
    }

    try {
      const keys = calculateAllMethods(seed.toUpperCase(), securityLevel);
      setCalculatedKeys(keys);
      toast.success("Keys calculated successfully!");
    } catch (error) {
      toast.error("Failed to calculate keys: " + (error as Error).message);
    }
  };

  const calculateAllMethods = (seedHex: string, level: string): CalculatedKeys => {
    // Get master key based on security level
    const masterKeys: Record<string, number[]> = {
      "default": [0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE, 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF],
      "09": [0x55, 0xAA, 0x55, 0xAA, 0x33, 0xCC, 0x33, 0xCC, 0x12, 0x34, 0x56, 0x78, 0xFE, 0xDC, 0xBA, 0x98],
      "0A": [0xAA, 0x55, 0xAA, 0x55, 0x33, 0xCC, 0x33, 0xCC, 0x87, 0x65, 0x43, 0x21, 0xAB, 0xCD, 0xEF, 0x01],
    };

    const masterKey = masterKeys[level] || masterKeys["default"];

    // Convert seed hex to bytes
    const seedBytes: number[] = [];
    for (let i = 0; i < seedHex.length; i += 2) {
      seedBytes.push(parseInt(seedHex.substr(i, 2), 16));
    }

    // Method 1: Direct XTEA encryption
    const method1 = calculateMethod1XTEA(seedBytes, masterKey);

    // Method 2: Transform + XTEA
    const method2 = calculateMethod2Transform(seedBytes, masterKey);

    // Method 3: Hybrid multi-step
    const method3 = calculateMethod3Hybrid(seedBytes);

    return {
      method1,
      method2,
      method3,
    };
  };

  // XTEA encryption
  const xteaEncrypt = (data: number[], key: number[]): number[] => {
    const DELTA = 0x9E3779B9;
    const ROUNDS = 32;

    // Convert key bytes to 4 32-bit integers
    const k: number[] = [];
    for (let i = 0; i < 4; i++) {
      k.push(
        (key[i * 4] << 24) |
        (key[i * 4 + 1] << 16) |
        (key[i * 4 + 2] << 8) |
        key[i * 4 + 3]
      );
    }

    // Pad data to 8 bytes
    const paddedData = [...data];
    while (paddedData.length < 8) {
      paddedData.push(0);
    }

    // Convert to two 32-bit integers
    let v0 = (paddedData[0] << 24) | (paddedData[1] << 16) | (paddedData[2] << 8) | paddedData[3];
    let v1 = (paddedData[4] << 24) | (paddedData[5] << 16) | (paddedData[6] << 8) | paddedData[7];

    let sum = 0;
    for (let i = 0; i < ROUNDS; i++) {
      v0 = (v0 + (((v1 << 4) ^ (v1 >>> 5)) + v1) ^ (sum + k[sum & 3])) >>> 0;
      sum = (sum + DELTA) >>> 0;
      v1 = (v1 + (((v0 << 4) ^ (v0 >>> 5)) + v0) ^ (sum + k[(sum >>> 11) & 3])) >>> 0;
    }

    // Convert back to bytes and return first 5 bytes
    const result = [
      (v0 >>> 24) & 0xFF,
      (v0 >>> 16) & 0xFF,
      (v0 >>> 8) & 0xFF,
      v0 & 0xFF,
      (v1 >>> 24) & 0xFF,
    ];

    return result;
  };

  const calculateMethod1XTEA = (seedBytes: number[], masterKey: number[]): string => {
    const encrypted = xteaEncrypt(seedBytes, masterKey);
    return encrypted.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
  };

  const calculateMethod2Transform = (seedBytes: number[], masterKey: number[]): string => {
    // Apply proprietary transformation
    const transformed: number[] = [];
    for (let i = 0; i < Math.min(seedBytes.length, 8); i++) {
      // XOR with position-dependent constant
      let val = seedBytes[i] ^ ((i * 0x55) & 0xFF);
      // Rotate left by 3 bits
      val = ((val << 3) | (val >>> 5)) & 0xFF;
      transformed.push(val);
    }

    const encrypted = xteaEncrypt(transformed, masterKey);
    return encrypted.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
  };

  const calculateMethod3Hybrid = (seedBytes: number[]): string => {
    // Convert to 32-bit word
    let seedWord = 0;
    for (let i = 0; i < Math.min(seedBytes.length, 4); i++) {
      seedWord = (seedWord << 8) | seedBytes[i];
    }

    // Apply multiple transformations
    // Step 1: XOR with secret constant
    let keyWord = (seedWord ^ 0xAA55AA55) >>> 0;

    // Step 2: Multiply by prime
    keyWord = (keyWord * 0x01010101) >>> 0;

    // Step 3: Rotate
    keyWord = ((keyWord << 13) | (keyWord >>> 19)) >>> 0;

    // Step 4: Add XTEA delta
    keyWord = (keyWord + 0x9E3779B9) >>> 0;

    // Convert to bytes
    const result = [
      (keyWord >>> 24) & 0xFF,
      (keyWord >>> 16) & 0xFF,
      (keyWord >>> 8) & 0xFF,
      keyWord & 0xFF,
    ];

    // Add low byte if available
    if (seedBytes.length > 4) {
      result.push(seedBytes[4] ^ 0x5A);
    }

    return result.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join('');
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <BackButton />
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-lg">
            <Key className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">XTEA CALCULATOR</h1>
            <p className="text-gray-600">
              2018+ Dodge/Chrysler/Jeep/RAM seed-key calculator with 3 methods
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Calculate Security Key</CardTitle>
            <CardDescription>
              Enter 5-byte seed from SecurityAccess request (Service 0x27)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="seed">Seed (10 hex characters)</Label>
              <Input
                id="seed"
                type="text"
                value={seed}
                onChange={(e) => setSeed(e.target.value.toUpperCase())}
                placeholder="1A2B3C4D5E"
                maxLength={10}
                className="mt-2 font-mono text-lg"
              />
              <p className="text-xs text-gray-500 mt-1">
                {seed.length}/10 characters
              </p>
            </div>

            <div>
              <Label htmlFor="security-level">Security Level</Label>
              <select
                id="security-level"
                value={securityLevel}
                onChange={(e) => setSecurityLevel(e.target.value as any)}
                className="w-full h-10 px-3 rounded-md border border-gray-300 mt-2"
              >
                <option value="09">Level 0x09 (Most Common)</option>
                <option value="0A">Level 0x0A (Alternative)</option>
                <option value="default">Default (Fallback)</option>
              </select>
            </div>

            <Button
              onClick={handleCalculate}
              disabled={seed.length !== 10}
              className="w-full gap-2"
              size="lg"
            >
              <Key className="h-5 w-5" />
              Calculate Keys
            </Button>
          </CardContent>
        </Card>

        {calculatedKeys && (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Method 1: Direct XTEA Encryption
                </CardTitle>
                <CardDescription>Most common for dongle-based security</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-100 p-3 rounded font-mono text-lg">
                    {calculatedKeys.method1}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => copyToClipboard(calculatedKeys.method1, "Method 1 key")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Method 2: Transform + XTEA
                </CardTitle>
                <CardDescription>Proprietary transformation before encryption</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-100 p-3 rounded font-mono text-lg">
                    {calculatedKeys.method2}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => copyToClipboard(calculatedKeys.method2, "Method 2 key")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Method 3: Hybrid Multi-Step
                </CardTitle>
                <CardDescription>Multiple transformations without XTEA</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-100 p-3 rounded font-mono text-lg">
                    {calculatedKeys.method3}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => copyToClipboard(calculatedKeys.method3, "Method 3 key")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">Algorithm Information</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-900 space-y-2">
            <p><strong>XTEA (Extended Tiny Encryption Algorithm)</strong></p>
            <p>• Block cipher with 128-bit key and 64-bit blocks</p>
            <p>• 32 rounds with delta constant 0x9E3779B9</p>
            <p>• Used by 2018+ FCA SecurityGateway</p>
            <p>• Different master keys for security levels 0x09, 0x0A</p>
            <p className="mt-4"><strong>Usage:</strong> Try all 3 methods if one fails</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
