import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';
import { Search } from 'lucide-react';

export default function SRTLabToolkit() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  
  const statsQuery = trpc.cda6Toolkit.getStats.useQuery();

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    try {
      const client = trpc.useUtils().client;
      const results = await client.cda6Toolkit.searchModules.query({ query: searchQuery });
      setSearchResults(results);
      toast.success(`Found ${results.length} modules`);
    } catch (error: any) {
      toast.error(`Search failed: ${error.message}`);
    }
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold">SRT Lab Toolkit</h1>
        <p className="text-muted-foreground mt-2">
          Chrysler Diagnostic Application 6.15.168 - {statsQuery.data?.totalModules || 0} Modules
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Search Modules
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Search by abbreviation, name, or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch}>Search</Button>
          </div>

          {searchResults.length > 0 && (
            <div className="space-y-2">
              {searchResults.map((module: any, idx: number) => (
                <div key={idx} className="p-4 border rounded-lg">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-semibold">{module.abbreviation}</h3>
                      <p className="text-sm text-muted-foreground">{module.fullName}</p>
                    </div>
                    <Badge variant="outline">{module.canId}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
