import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BackButton } from "@/components/BackButton";
import { FlaskConical, Download, AlertCircle, CheckCircle2 } from 'lucide-react';
import { 
  calculateSBEC2Key, 
  calculateNGC3Key, 
  calculateShiftXORKey,
  calculateXTEAKey,
  calculateVINBasedPIN,
  calculateAtlantisKey,
  formatKeyHex,
  MODULE_CONSTANTS
} from '@shared/seed-key-algorithms';

interface TestResult {
  algorithm: string;
  constant: string;
  keyHex: string;
  keyDec: string;
  notes: string;
  confidence: 'high' | 'medium' | 'low';
}

export default function AlgorithmTester() {
  const [seedInput, setSeedInput] = useState('');
  const [vinInput, setVinInput] = useState('');
  const [csnInput, setCsnInput] = useState('');
  const [results, setResults] = useState<TestResult[]>([]);
  const [error, setError] = useState('');

  const parseSeed = (input: string): number | null => {
    const cleaned = input.trim().replace(/\s+/g, '');
    
    // Try hex format
    if (cleaned.startsWith('0x') || /^[0-9A-Fa-f]+$/.test(cleaned)) {
      const hex = cleaned.startsWith('0x') ? cleaned : '0x' + cleaned;
      const value = parseInt(hex, 16);
      if (!isNaN(value)) return value;
    }
    
    // Try decimal format
    const decimal = parseInt(cleaned, 10);
    if (!isNaN(decimal)) return decimal;
    
    return null;
  };

  const testAllAlgorithms = () => {
    setError('');
    setResults([]);

    const seed = parseSeed(seedInput);
    if (seed === null) {
      setError('Invalid seed format. Use hex (0x12345678) or decimal (305419896)');
      return;
    }

    const testResults: TestResult[] = [];

    // Test SBEC2/SBEC3
    try {
      const key = calculateSBEC2Key(seed);
      testResults.push({
        algorithm: 'SBEC2/SBEC3',
        constant: '0x9018',
        keyHex: '0x' + key.toString(16).toUpperCase().padStart(8, '0'),
        keyDec: key.toString(),
        notes: 'Legacy ECM/PCM/TCM (1996-2006)',
        confidence: seed < 0x10000000 ? 'medium' : 'low'
      });
    } catch (e) {
      console.error('SBEC2 test failed:', e);
    }

    // Test NGC3/NGC4 (16-bit seed)
    try {
      const seed16 = seed & 0xFFFF;
      const key = calculateNGC3Key(seed16);
      testResults.push({
        algorithm: 'NGC3/NGC4',
        constant: '0x8749',
        keyHex: '0x' + key.toString(16).toUpperCase().padStart(4, '0'),
        keyDec: key.toString(),
        notes: 'NGC generation modules (2004-2010)',
        confidence: seed <= 0xFFFF ? 'high' : 'low'
      });
    } catch (e) {
      console.error('NGC3 test failed:', e);
    }

    // Test Shift-XOR with different module constants
    const shiftXORModules = [
      { name: 'BCM', constant: MODULE_CONSTANTS.BCM.constant },
      { name: 'ECM', constant: MODULE_CONSTANTS.ECM.constant },
      { name: 'TCM', constant: MODULE_CONSTANTS.TCM.constant },
      { name: 'RFHUB', constant: MODULE_CONSTANTS.RFHUB.constant }
    ];

    shiftXORModules.forEach(({ name, constant }) => {
      try {
        const key = calculateShiftXORKey(seed, constant, 5);
        testResults.push({
          algorithm: `Shift-XOR (${name})`,
          constant: '0x' + constant.toString(16).toUpperCase(),
          keyHex: '0x' + key.toString(16).toUpperCase().padStart(8, '0'),
          keyDec: key.toString(),
          notes: `Modern FCA ${name} (2010-2017)`,
          confidence: seed > 0x10000000 ? 'high' : 'medium'
        });
      } catch (e) {
        console.error(`Shift-XOR ${name} test failed:`, e);
      }
    });

    // Test XTEA (3 methods)
    try {
      const seedBytes = new Uint8Array(4);
      seedBytes[0] = (seed >>> 24) & 0xFF;
      seedBytes[1] = (seed >>> 16) & 0xFF;
      seedBytes[2] = (seed >>> 8) & 0xFF;
      seedBytes[3] = seed & 0xFF;

      for (let method = 1; method <= 3; method++) {
        const keyBytes = calculateXTEAKey(seedBytes, 0x09, method as 1 | 2 | 3);
        testResults.push({
          algorithm: `XTEA Method ${method}`,
          constant: 'Dynamic',
          keyHex: formatKeyHex(keyBytes),
          keyDec: Array.from(keyBytes).map(b => b.toString()).join(', '),
          notes: `SecurityGateway 2018+ (Method ${method})`,
          confidence: seed > 0x10000000 ? 'high' : 'medium'
        });
      }
    } catch (e) {
      console.error('XTEA test failed:', e);
    }

    // Test Atlantis (if CSN provided)
    if (csnInput.trim()) {
      try {
        const seedBytes = new Uint8Array(4);
        seedBytes[0] = (seed >>> 24) & 0xFF;
        seedBytes[1] = (seed >>> 16) & 0xFF;
        seedBytes[2] = (seed >>> 8) & 0xFF;
        seedBytes[3] = seed & 0xFF;

        // Parse CSN (5 bytes)
        const csnHex = csnInput.trim().replace(/[^0-9A-Fa-f]/g, '');
        if (csnHex.length === 10) {
          const csnBytes = new Uint8Array(5);
          for (let i = 0; i < 5; i++) {
            csnBytes[i] = parseInt(csnHex.substr(i * 2, 2), 16);
          }

          const keyBytes = calculateAtlantisKey(seedBytes, csnBytes);
          testResults.push({
            algorithm: 'Atlantis (2018+)',
            constant: 'AES-128 ECB',
            keyHex: formatKeyHex(keyBytes),
            keyDec: Array.from(keyBytes).map(b => b.toString()).join(', '),
            notes: 'SecurityGateway 2018+ with CSN (DID 0xF18C)',
            confidence: 'high'
          });
        }
      } catch (e) {
        console.error('Atlantis test failed:', e);
      }
    }

    // Test VIN-based PIN (if VIN provided)
    if (vinInput.length === 17) {
      try {
        const pin = calculateVINBasedPIN(vinInput);
        testResults.push({
          algorithm: 'VIN-based PIN',
          constant: 'VIN-derived',
          keyHex: 'N/A',
          keyDec: pin,
          notes: 'SKIM/SKREEM PIN extraction',
          confidence: 'high'
        });
      } catch (e) {
        console.error('VIN-based PIN test failed:', e);
      }
    }

    setResults(testResults);
  };

  const exportToCSV = () => {
    const headers = ['Algorithm', 'Constant', 'Key (Hex)', 'Key (Decimal)', 'Notes', 'Confidence'];
    const rows = results.map(r => [
      r.algorithm,
      r.constant,
      r.keyHex,
      r.keyDec,
      r.notes,
      r.confidence
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `algorithm-test-seed-${seedInput}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      <div className="flex items-center gap-3">
        <FlaskConical className="h-8 w-8 text-red-500" />
        <div>
          <h1 className="text-3xl font-bold">Algorithm Testing Tool</h1>
          <p className="text-muted-foreground">
            Test all 9 seed-key algorithms simultaneously to identify unknown modules
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Test Seed Against All Algorithms</CardTitle>
          <CardDescription>
            Enter a seed value to calculate keys using all available algorithms
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Seed Value</label>
              <Input
                placeholder="0x48D01C4A or 1221664842"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Supports hex (0x...) or decimal format
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">VIN (Optional)</label>
              <Input
                placeholder="2C3CDXHG8GH143509"
                value={vinInput}
                onChange={(e) => setVinInput(e.target.value.toUpperCase())}
                maxLength={17}
              />
              <p className="text-xs text-muted-foreground">
                Required for VIN-based PIN calculation
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">CSN - Control Serial Number (Optional)</label>
            <Input
              placeholder="4400311330 or 44 00 31 13 30"
              value={csnInput}
              onChange={(e) => setCsnInput(e.target.value.toUpperCase())}
              maxLength={14}
            />
            <p className="text-xs text-muted-foreground">
              Required for Atlantis algorithm (2018+ vehicles). Read from DID 0xF18C. 5 bytes (10 hex characters).
            </p>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
              <AlertCircle className="h-4 w-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={testAllAlgorithms} className="flex-1">
              Test All Algorithms
            </Button>
            {results.length > 0 && (
              <Button onClick={exportToCSV} variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Test Results</CardTitle>
            <CardDescription>
              {results.length} algorithms tested against seed: {seedInput}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Algorithm</TableHead>
                  <TableHead>Constant</TableHead>
                  <TableHead>Key (Hex)</TableHead>
                  <TableHead>Key (Decimal)</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Confidence</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="font-medium">{result.algorithm}</TableCell>
                    <TableCell className="font-mono text-sm">{result.constant}</TableCell>
                    <TableCell className="font-mono text-sm">{result.keyHex}</TableCell>
                    <TableCell className="font-mono text-sm">{result.keyDec}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{result.notes}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={result.confidence === 'high' ? 'default' : result.confidence === 'medium' ? 'secondary' : 'outline'}
                        className="flex items-center gap-1 w-fit"
                      >
                        {result.confidence === 'high' && <CheckCircle2 className="h-3 w-3" />}
                        {result.confidence}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Usage Guide */}
      <Card>
        <CardHeader>
          <CardTitle>Usage Guide</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">When to Use This Tool</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
              <li>Identifying unknown or aftermarket ECU modules</li>
              <li>Testing seed-key pairs from diagnostic logs</li>
              <li>Verifying which algorithm a module uses</li>
              <li>Cross-referencing multiple algorithm results</li>
              <li>Debugging security access failures</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Confidence Levels</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Badge>High</Badge>
                <span className="text-muted-foreground">Seed format matches algorithm expectations</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Medium</Badge>
                <span className="text-muted-foreground">Seed format is compatible but not ideal</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">Low</Badge>
                <span className="text-muted-foreground">Seed format doesn't match typical usage</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
