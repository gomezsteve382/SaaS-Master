import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackButton } from "@/components/BackButton";
import { 
  Home, Shield, AlertTriangle, Cpu, Cable, Wifi, 
  Car, Lock, Unlock, CheckCircle2, XCircle, Info, 
  FileText, ExternalLink, Wrench, Zap
} from 'lucide-react';

interface BypassMethod {
  name: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  cost: string;
  tools: string[];
  description: string;
  steps: string[];
  pros: string[];
  cons: string[];
}

const BYPASS_METHODS: BypassMethod[] = [
  {
    name: 'OBD2 Splitter + Dual Tool',
    difficulty: 'Easy',
    cost: '$20-50',
    tools: ['OBD2 Y-splitter cable', 'Alpha OBD or similar', 'Passive CAN reader (Arduino)'],
    description: 'Use an OBD2 splitter to connect two devices - one authorized tool handles authentication while the other reads/sniffs traffic passively.',
    steps: [
      'Purchase an OBD2 Y-splitter cable (wires to both connectors)',
      'Connect Alpha OBD or authorized tool to one port',
      'Connect Arduino CAN Shield to the other port in passive mode',
      'Use authorized tool to perform security access',
      'Sniff seed/key pairs on the passive port',
      'Analyze captured data to reverse engineer algorithm',
    ],
    pros: [
      'No permanent modification',
      'Low cost entry point',
      'Works with any 2018+ vehicle',
      'Good for security research',
    ],
    cons: [
      'Requires two devices',
      'Cannot program modules directly',
      'Only captures, cannot bypass SGW',
    ],
  },
  {
    name: 'SGW Module Removal (Temporary)',
    difficulty: 'Medium',
    cost: '$0',
    tools: ['Trim tools', 'Socket set', 'OBD2 jumper harness'],
    description: 'Physically disconnect the SGW module to allow direct CAN bus access. The SGW is typically located behind the center console or instrument panel.',
    steps: [
      'Locate SGW module (typically behind center console)',
      'Disconnect negative battery terminal',
      'Remove necessary trim panels to access SGW',
      'Unplug SGW connector',
      'Install OBD2 jumper harness to bridge CAN buses',
      'Perform required programming',
      'Reconnect SGW and reassemble',
    ],
    pros: [
      'Full CAN bus access',
      'No permanent modification',
      'Works with any scan tool',
    ],
    cons: [
      'Requires some disassembly',
      'Vehicle not driveable with SGW removed',
      'Must reinstall for vehicle operation',
    ],
  },
  {
    name: 'SGW Bypass Adapter (Commercial)',
    difficulty: 'Easy',
    cost: '$150-400',
    tools: ['Commercial SGW bypass adapter (AutoHex, Autel, etc.)'],
    description: 'Purchase a commercial SGW bypass adapter that plugs inline with the OBD2 port and handles gateway authentication automatically.',
    steps: [
      'Purchase compatible SGW bypass adapter',
      'Connect adapter to vehicle OBD2 port',
      'Connect scan tool to adapter',
      'Adapter handles SGW authentication',
      'Program modules normally',
    ],
    pros: [
      'Plug and play',
      'No vehicle modification',
      'Works with most scan tools',
    ],
    cons: [
      'Higher cost',
      'May require subscriptions',
      'Limited to supported vehicles',
    ],
  },
  {
    name: 'Direct CAN Tap (Advanced)',
    difficulty: 'Hard',
    cost: '$50-100',
    tools: ['CAN transceiver module', 'Arduino/ESP32', 'Wiring supplies', 'Oscilloscope (optional)'],
    description: 'Tap directly into the vehicle CAN bus behind the SGW by accessing module connectors or splicing into CAN wiring.',
    steps: [
      'Identify CAN High and CAN Low wires at target module',
      'Locate accessible wiring harness',
      'Install CAN tap connector or splice',
      'Connect CAN transceiver (MCP2515, etc.)',
      'Configure for correct baud rate (500kbps typical)',
      'Communicate directly with target module',
    ],
    pros: [
      'Direct module access',
      'Bypasses SGW completely',
      'Works for any module',
    ],
    cons: [
      'Requires electrical knowledge',
      'Risk of damaging vehicle wiring',
      'More complex setup',
    ],
  },
];

const AFFECTED_VEHICLES: { year: string; make: string; models: string[] }[] = [
  { year: '2018+', make: 'Chrysler', models: ['300', 'Pacifica', 'Voyager'] },
  { year: '2018+', make: 'Dodge', models: ['Charger', 'Challenger', 'Durango', 'Journey'] },
  { year: '2018+', make: 'Jeep', models: ['Cherokee', 'Grand Cherokee', 'Wrangler', 'Gladiator', 'Compass', 'Renegade'] },
  { year: '2019+', make: 'Ram', models: ['1500', '2500', '3500', 'ProMaster'] },
  { year: '2020+', make: 'Fiat', models: ['500X', '500L'] },
  { year: '2021+', make: 'Alfa Romeo', models: ['Giulia', 'Stelvio'] },
];

export default function GatewayBypassPage() {
  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-6xl mx-auto">
        <BackButton />
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon" data-testid="button-home">
                <Home className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-red-500 font-mono" data-testid="text-page-title">
                SGW BYPASS GUIDE
              </h1>
              <p className="text-sm text-gray-400">Secure Gateway bypass methods for 2018+ FCA/Stellantis</p>
            </div>
          </div>
          
          <Badge variant="outline" className="border-yellow-500 text-yellow-500">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Advanced Users Only
          </Badge>
        </div>
        
        <Alert className="mb-6 border-yellow-500/50 bg-yellow-900/20">
          <AlertTriangle className="h-4 w-4 text-yellow-500" />
          <AlertTitle className="text-yellow-500">Security Gateway (SGW) Information</AlertTitle>
          <AlertDescription className="text-gray-300">
            Starting in 2018, FCA/Stellantis vehicles include a Secure Gateway Module that blocks 
            unauthorized diagnostic access via the OBD2 port. This guide covers methods to work around 
            this restriction for legitimate diagnostic and programming purposes.
          </AlertDescription>
        </Alert>
        
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-900">
            <TabsTrigger value="overview" data-testid="tab-overview">
              <Info className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="methods" data-testid="tab-methods">
              <Wrench className="w-4 h-4 mr-2" />
              Bypass Methods
            </TabsTrigger>
            <TabsTrigger value="vehicles" data-testid="tab-vehicles">
              <Car className="w-4 h-4 mr-2" />
              Affected Vehicles
            </TabsTrigger>
            <TabsTrigger value="technical" data-testid="tab-technical">
              <Cpu className="w-4 h-4 mr-2" />
              Technical Details
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <Card className="border-white/10">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-red-400" />
                  What is the Secure Gateway?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-gray-300">
                <p>
                  The Secure Gateway (SGW) is a network firewall module installed in FCA/Stellantis 
                  vehicles starting in 2018 model year. It sits between the OBD2 port and the vehicle's 
                  internal CAN bus networks, filtering and blocking unauthorized diagnostic commands.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border-red-500/30 bg-red-900/10">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2 text-red-400">
                        <Lock className="w-4 h-4" />
                        Blocked Operations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="text-sm space-y-1">
                        <li className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-red-400" />
                          Security Access (0x27) requests
                        </li>
                        <li className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-red-400" />
                          Write Data By ID (0x2E) commands
                        </li>
                        <li className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-red-400" />
                          Routine Control (0x31) requests
                        </li>
                        <li className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-red-400" />
                          ECU programming/flashing
                        </li>
                        <li className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-red-400" />
                          Key/immobilizer programming
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-green-500/30 bg-green-900/10">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2 text-green-400">
                        <Unlock className="w-4 h-4" />
                        Allowed Operations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="text-sm space-y-1">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-400" />
                          Read DTC (0x19) - basic codes
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-400" />
                          Clear DTC (0x14) - basic clearing
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-400" />
                          Read Data (0x22) - most DIDs
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-400" />
                          VIN reading
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-400" />
                          OBD2 live data/PIDs
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
                
                <Alert className="border-blue-500/50 bg-blue-900/20">
                  <Info className="h-4 w-4 text-blue-400" />
                  <AlertDescription className="text-gray-300">
                    <strong>Why was SGW added?</strong> The SGW was implemented to prevent unauthorized 
                    access to vehicle systems, particularly to combat vehicle theft and 
                    prevent unauthorized key programming. While this improves security, it also 
                    restricts legitimate diagnostic access for independent technicians.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="methods" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {BYPASS_METHODS.map((method, index) => (
                <Card key={index} className="border-white/10" data-testid={`card-method-${index}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{method.name}</CardTitle>
                      <div className="flex gap-2">
                        <Badge 
                          variant="outline" 
                          className={
                            method.difficulty === 'Easy' ? 'border-green-500 text-green-500' :
                            method.difficulty === 'Medium' ? 'border-yellow-500 text-yellow-500' :
                            'border-red-500 text-red-500'
                          }
                        >
                          {method.difficulty}
                        </Badge>
                        <Badge variant="outline" className="border-gray-500 text-gray-400">
                          {method.cost}
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>{method.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-semibold text-white mb-2">Required Tools:</h4>
                      <ul className="text-sm text-gray-400 space-y-1">
                        {method.tools.map((tool, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <Wrench className="w-3 h-3 text-blue-400" />
                            {tool}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-semibold text-white mb-2">Steps:</h4>
                      <ol className="text-sm text-gray-400 space-y-1 list-decimal list-inside">
                        {method.steps.map((step, i) => (
                          <li key={i}>{step}</li>
                        ))}
                      </ol>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-semibold text-green-400 mb-1">Pros:</h4>
                        <ul className="text-xs text-gray-400 space-y-1">
                          {method.pros.map((pro, i) => (
                            <li key={i} className="flex items-start gap-1">
                              <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                              {pro}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-red-400 mb-1">Cons:</h4>
                        <ul className="text-xs text-gray-400 space-y-1">
                          {method.cons.map((con, i) => (
                            <li key={i} className="flex items-start gap-1">
                              <XCircle className="w-3 h-3 text-red-400 mt-0.5 flex-shrink-0" />
                              {con}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="vehicles" className="space-y-4">
            <Card className="border-white/10">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Car className="w-5 h-5 text-blue-400" />
                  Vehicles with Secure Gateway
                </CardTitle>
                <CardDescription>
                  These vehicles are known to have SGW installed and require bypass for advanced diagnostics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {AFFECTED_VEHICLES.map((vehicle, index) => (
                    <Card key={index} className="border-white/5 bg-white/5" data-testid={`card-vehicle-${index}`}>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center justify-between">
                          {vehicle.make}
                          <Badge variant="outline" className="text-xs">
                            {vehicle.year}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-1">
                          {vehicle.models.map((model, i) => (
                            <Badge key={i} variant="secondary" className="text-xs">
                              {model}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <Alert className="mt-4 border-yellow-500/50 bg-yellow-900/20">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <AlertDescription className="text-gray-300">
                    <strong>Note:</strong> Some early 2018 models may not have SGW. Production date 
                    and VIN decoding can help determine if SGW is present. Use module scan to check 
                    for SGW module presence (typically address 0x753/0x75B).
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="technical" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="border-white/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-purple-400" />
                    SGW Module Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-gray-400">CAN TX Address:</div>
                    <div className="font-mono text-green-400">0x753</div>
                    
                    <div className="text-gray-400">CAN RX Address:</div>
                    <div className="font-mono text-green-400">0x75B</div>
                    
                    <div className="text-gray-400">Module Code:</div>
                    <div className="font-mono">SGW / ESG</div>
                    
                    <div className="text-gray-400">Location:</div>
                    <div>Behind center console or IP</div>
                    
                    <div className="text-gray-400">CAN Networks:</div>
                    <div>Bridges HS-CAN1, HS-CAN2, HS-CAN3</div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-white/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    Authentication Method
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-gray-300">
                  <p>
                    The SGW uses a cloud-based authentication system. Authorized tools (dealership diagnostic system, 
                    Alpha OBD, AutoHex II, etc.) must connect to FCA's servers to obtain 
                    time-limited access tokens for each diagnostic session.
                  </p>
                  <div className="bg-gray-900 p-3 rounded font-mono text-xs">
                    <div className="text-blue-400">Authentication Flow:</div>
                    <div className="text-gray-400 mt-2">
                      1. Tool sends VIN to FCA server<br/>
                      2. Server validates subscription<br/>
                      3. Server returns encrypted token<br/>
                      4. Tool presents token to SGW<br/>
                      5. SGW validates and grants access
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-white/10 lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-orange-400" />
                    Known DIDs and Security Levels
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[200px]">
                    <table className="w-full text-sm">
                      <thead className="text-gray-400 border-b border-white/10">
                        <tr>
                          <th className="text-left py-2">DID</th>
                          <th className="text-left py-2">Name</th>
                          <th className="text-left py-2">Access Level</th>
                          <th className="text-left py-2">Notes</th>
                        </tr>
                      </thead>
                      <tbody className="font-mono">
                        <tr className="border-b border-white/5">
                          <td className="py-2 text-green-400">0xF190</td>
                          <td>VIN</td>
                          <td className="text-yellow-400">Read: Open, Write: Security</td>
                          <td className="text-gray-400">17-byte VIN</td>
                        </tr>
                        <tr className="border-b border-white/5">
                          <td className="py-2 text-green-400">0xF18C</td>
                          <td>ECU Serial (CSN)</td>
                          <td className="text-green-400">Open</td>
                          <td className="text-gray-400">5-byte CSN for Atlantis algorithm</td>
                        </tr>
                        <tr className="border-b border-white/5">
                          <td className="py-2 text-green-400">0xF191</td>
                          <td>ECU Hardware Number</td>
                          <td className="text-green-400">Open</td>
                          <td className="text-gray-400">Part number</td>
                        </tr>
                        <tr className="border-b border-white/5">
                          <td className="py-2 text-green-400">0xF193</td>
                          <td>ECU Software Number</td>
                          <td className="text-green-400">Open</td>
                          <td className="text-gray-400">Calibration version</td>
                        </tr>
                        <tr className="border-b border-white/5">
                          <td className="py-2 text-green-400">0x27 01</td>
                          <td>Security Access L1</td>
                          <td className="text-red-400">SGW Blocked</td>
                          <td className="text-gray-400">Engineering level (0x4B92)</td>
                        </tr>
                        <tr className="border-b border-white/5">
                          <td className="py-2 text-green-400">0x27 11</td>
                          <td>Security Access L17</td>
                          <td className="text-red-400">SGW Blocked</td>
                          <td className="text-gray-400">Bootloader level (0x1209)</td>
                        </tr>
                      </tbody>
                    </table>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
