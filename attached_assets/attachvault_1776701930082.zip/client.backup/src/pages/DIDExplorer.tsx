import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { BackButton } from "@/components/BackButton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Database, Search, Edit, Download, Upload, AlertTriangle,
  CheckCircle2, XCircle, Clock, Trash2, Copy as CopyIcon
} from "lucide-react";
import { toast } from "sonner";
import didDatabase from "@/../../shared/did_database.json";

interface DIDEntry {
  did: string;
  name: string;
  value: string;
  timestamp: Date;
  status: "success" | "error";
  direction: "read" | "write";
}

export default function DIDExplorer() {
  const [did, setDid] = useState("");
  const [value, setValue] = useState("");
  const [history, setHistory] = useState<DIDEntry[]>([]);
  const [isReading, setIsReading] = useState(false);
  const [isWriting, setIsWriting] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<"hex" | "ascii">("hex");

  // Get DID info from database
  const getDidInfo = (didCode: string) => {
    const standardDid = didDatabase.standard_dids[didCode as keyof typeof didDatabase.standard_dids];
    if (standardDid) return standardDid;

    // Search in module-specific DIDs
    for (const module of Object.values(didDatabase.module_specific)) {
      if (module.additional_dids && module.additional_dids[didCode as keyof typeof module.additional_dids]) {
        return module.additional_dids[didCode as keyof typeof module.additional_dids];
      }
    }
    return null;
  };

  const handleReadDID = async () => {
    if (!did || did.length !== 4) {
      toast.error("DID must be 4 hex characters (e.g., F190)");
      return;
    }

    setIsReading(true);
    try {
      // Simulate DID read (replace with actual UDS command)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock response
      const mockValue = did === "F190" 
        ? "2C3CDXKT3FH796320" 
        : "AA BB CC DD EE";

      const didInfo = getDidInfo(did.toUpperCase());
      const entry: DIDEntry = {
        did: did.toUpperCase(),
        name: didInfo?.name || "Unknown DID",
        value: mockValue,
        timestamp: new Date(),
        status: "success",
        direction: "read"
      };

      setHistory([entry, ...history]);
      setValue(mockValue);
      toast.success(`Successfully read DID ${did.toUpperCase()}`);
    } catch (error) {
      const entry: DIDEntry = {
        did: did.toUpperCase(),
        name: "Error",
        value: (error as Error).message,
        timestamp: new Date(),
        status: "error",
        direction: "read"
      };
      setHistory([entry, ...history]);
      toast.error("Failed to read DID");
    } finally {
      setIsReading(false);
    }
  };

  const handleWriteDID = async () => {
    if (!did || did.length !== 4) {
      toast.error("DID must be 4 hex characters");
      return;
    }

    if (!value) {
      toast.error("Value cannot be empty");
      return;
    }

    const didInfo = getDidInfo(did.toUpperCase());
    if (didInfo && didInfo.access === "read") {
      toast.error("This DID is read-only");
      return;
    }

    setIsWriting(true);
    try {
      // Simulate DID write (replace with actual UDS command)
      await new Promise(resolve => setTimeout(resolve, 1500));

      const entry: DIDEntry = {
        did: did.toUpperCase(),
        name: didInfo?.name || "Unknown DID",
        value: value,
        timestamp: new Date(),
        status: "success",
        direction: "write"
      };

      setHistory([entry, ...history]);
      toast.success(`Successfully wrote DID ${did.toUpperCase()}`);
    } catch (error) {
      const entry: DIDEntry = {
        did: did.toUpperCase(),
        name: "Error",
        value: (error as Error).message,
        timestamp: new Date(),
        status: "error",
        direction: "write"
      };
      setHistory([entry, ...history]);
      toast.error("Failed to write DID");
    } finally {
      setIsWriting(false);
    }
  };

  const handleExportHistory = () => {
    const json = JSON.stringify(history, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `did_history_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("History exported");
  };

  const handleClearHistory = () => {
    setHistory([]);
    toast.success("History cleared");
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const didInfo = did.length === 4 ? getDidInfo(did.toUpperCase()) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />

        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="p-4 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl">
            <Database className="h-10 w-10" />
          </div>
          <div>
            <h1 className="text-4xl font-black tracking-tight">DID EXPLORER</h1>
            <p className="text-gray-400 text-lg">
              Manual read/write of UDS Data Identifiers (DIDs)
            </p>
          </div>
        </div>

        {/* Warning */}
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Advanced Tool - Use With Caution</AlertTitle>
          <AlertDescription>
            Writing incorrect data to critical DIDs can brick modules permanently. Always backup before writing.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - DID Operations */}
          <div className="space-y-6">
            {/* DID Input */}
            <Card>
              <CardHeader>
                <CardTitle>DID Operations</CardTitle>
                <CardDescription>Enter DID in hexadecimal (e.g., F190 for VIN)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="did-input">Data Identifier (DID)</Label>
                  <Input
                    id="did-input"
                    type="text"
                    value={did}
                    onChange={(e) => setDid(e.target.value.toUpperCase())}
                    placeholder="F190"
                    maxLength={4}
                    className="mt-2 font-mono text-lg"
                  />
                  {didInfo && (
                    <div className="mt-2 p-3 bg-blue-500/10 border border-blue-500/30 rounded">
                      <p className="font-semibold text-blue-400">{didInfo.name}</p>
                      <p className="text-sm text-gray-400">{didInfo.description}</p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant={didInfo.access === "read" ? "secondary" : "default"}>
                          {didInfo.access}
                        </Badge>
                        <Badge variant="outline">{didInfo.format}</Badge>
                        {(didInfo as any).critical && (
                          <Badge variant="destructive">CRITICAL</Badge>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="value-input">Value</Label>
                  <Textarea
                    id="value-input"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder="Enter value (hex or ASCII)"
                    className="mt-2 font-mono"
                    rows={3}
                  />
                  <div className="flex gap-2 mt-2">
                    <Button
                      size="sm"
                      variant={selectedFormat === "hex" ? "default" : "outline"}
                      onClick={() => setSelectedFormat("hex")}
                    >
                      HEX
                    </Button>
                    <Button
                      size="sm"
                      variant={selectedFormat === "ascii" ? "default" : "outline"}
                      onClick={() => setSelectedFormat("ascii")}
                    >
                      ASCII
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleReadDID}
                    disabled={isReading || !did}
                    className="flex-1 gap-2"
                  >
                    {isReading ? (
                      <>Reading...</>
                    ) : (
                      <>
                        <Search className="h-4 w-4" />
                        Read DID
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={handleWriteDID}
                    disabled={isWriting || !did || !value}
                    variant="destructive"
                    className="flex-1 gap-2"
                  >
                    {isWriting ? (
                      <>Writing...</>
                    ) : (
                      <>
                        <Edit className="h-4 w-4" />
                        Write DID
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Common DIDs Quick Access */}
            <Card>
              <CardHeader>
                <CardTitle>Common DIDs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(didDatabase.standard_dids)
                    .filter(([_, info]) => (info as any).critical)
                    .slice(0, 6)
                    .map(([didCode, info]) => (
                      <Button
                        key={didCode}
                        variant="outline"
                        size="sm"
                        onClick={() => setDid(didCode)}
                        className="justify-start"
                      >
                        <span className="font-mono">{didCode}</span>
                        <span className="ml-2 text-xs text-gray-400 truncate">
                          {info.name}
                        </span>
                      </Button>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - History */}
          <div className="space-y-6">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Operation History</CardTitle>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleExportHistory}
                      disabled={history.length === 0}
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleClearHistory}
                      disabled={history.length === 0}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  {history.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-gray-500">
                      <Database className="h-12 w-12 mb-2 opacity-50" />
                      <p>No operations yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {history.map((entry, idx) => (
                        <div
                          key={idx}
                          className={`p-3 rounded border ${
                            entry.status === "success"
                              ? "bg-green-500/10 border-green-500/30"
                              : "bg-red-500/10 border-red-500/30"
                          }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {entry.direction === "read" ? (
                                <Search className="h-4 w-4 text-blue-400" />
                              ) : (
                                <Edit className="h-4 w-4 text-orange-400" />
                              )}
                              <span className="font-mono font-semibold">{entry.did}</span>
                              <Badge variant="outline" className="text-xs">
                                {entry.name}
                              </Badge>
                            </div>
                            {entry.status === "success" ? (
                              <CheckCircle2 className="h-4 w-4 text-green-500" />
                            ) : (
                              <XCircle className="h-4 w-4 text-red-500" />
                            )}
                          </div>
                          <div className="flex items-start justify-between">
                            <p className="font-mono text-sm break-all flex-1">{entry.value}</p>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyToClipboard(entry.value)}
                              className="ml-2"
                            >
                              <CopyIcon className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                            <Clock className="h-3 w-3" />
                            {entry.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
