import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Upload, Download, CheckCircle2, AlertCircle, Loader2, Database, FileStack, Archive } from 'lucide-react';

export default function RFHUBVINPatcher() {
  const [eeeFile, setEeeFile] = useState<File | null>(null);
  const [newVIN, setNewVIN] = useState('');
  const [customPoly, setCustomPoly] = useState('');
  const [customInit, setCustomInit] = useState('');
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');
  
  // Batch processing state
  const [batchFiles, setBatchFiles] = useState<File[]>([]);
  const [batchVIN, setBatchVIN] = useState('');
  const [batchResults, setBatchResults] = useState<any[]>([]);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [batchProgress, setBatchProgress] = useState({ current: 0, total: 0 });

  const knownAlgorithms = trpc.rfhub.getKnownAlgorithms.useQuery();
  const patchVIN = trpc.rfhub.patchVIN.useMutation();
  const validateVINMutation = trpc.rfhub.validateVIN.useMutation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size !== 4096) {
        setError('Invalid EEE file size. Must be exactly 4096 bytes.');
        setEeeFile(null);
        return;
      }
      setEeeFile(file);
      setError('');
      setResult(null);
    }
  };

  const handlePatch = async () => {
    if (!eeeFile || !newVIN) {
      setError('Please select an EEE file and enter a new VIN');
      return;
    }

    // Validate VIN first
    const validation = await validateVINMutation.mutateAsync({ vin: newVIN });
    if (!validation.valid) {
      setError(validation.error || 'Invalid VIN');
      return;
    }

    try {
      const arrayBuffer = await eeeFile.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      let binary = '';
      for (let i = 0; i < uint8Array.length; i++) {
        binary += String.fromCharCode(uint8Array[i]);
      }
      const base64 = btoa(binary);

      const poly = customPoly ? parseInt(customPoly, 16) : undefined;
      const init = customInit ? parseInt(customInit, 16) : undefined;

      const patchResult = await patchVIN.mutateAsync({
        eeeDataBase64: base64,
        newVIN,
        poly,
        init,
      });

      if (patchResult.success) {
        setResult(patchResult);
        setError('');
      } else {
        setError(patchResult.error || 'Patching failed');
        setResult(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      setResult(null);
    }
  };

  const handleDownload = () => {
    if (!result?.patchedDataBase64) return;

    const binary = atob(result.patchedDataBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${newVIN}_patched.eee`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Batch processing handlers
  const handleBatchFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(f => f.size === 4096);
    
    if (validFiles.length !== files.length) {
      setError(`${files.length - validFiles.length} file(s) rejected: must be exactly 4096 bytes`);
    } else {
      setError('');
    }
    
    setBatchFiles(validFiles);
    setBatchResults([]);
  };

  const handleBatchPatch = async () => {
    if (batchFiles.length === 0 || !batchVIN) {
      setError('Please select files and enter a VIN');
      return;
    }

    // Validate VIN first
    const validation = await validateVINMutation.mutateAsync({ vin: batchVIN });
    if (!validation.valid) {
      setError(validation.error || 'Invalid VIN');
      return;
    }

    setBatchProcessing(true);
    setBatchProgress({ current: 0, total: batchFiles.length });
    const results: any[] = [];

    for (let i = 0; i < batchFiles.length; i++) {
      const file = batchFiles[i];
      setBatchProgress({ current: i + 1, total: batchFiles.length });

      try {
        const arrayBuffer = await file.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);
        let binary = '';
        for (let j = 0; j < uint8Array.length; j++) {
          binary += String.fromCharCode(uint8Array[j]);
        }
        const base64 = btoa(binary);

        const patchResult = await patchVIN.mutateAsync({
          eeeDataBase64: base64,
          newVIN: batchVIN,
        });

        results.push({
          filename: file.name,
          success: patchResult.success,
          result: patchResult,
          error: patchResult.error,
        });
      } catch (err) {
        results.push({
          filename: file.name,
          success: false,
          error: err instanceof Error ? err.message : 'Unknown error',
        });
      }
    }

    setBatchResults(results);
    setBatchProcessing(false);
    setError('');
  };

  const handleBatchDownload = async () => {
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();

    batchResults.forEach((result) => {
      if (result.success && result.result?.patchedDataBase64) {
        const binary = atob(result.result.patchedDataBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        zip.file(`${batchVIN}_${result.filename}`, bytes);
      }
    });

    const content = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RFHUB_Batch_${batchVIN}.zip`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">RFHUB VIN Patcher</h1>
        <p className="text-muted-foreground">
          Patch RFHUB EEE files with new VIN using 10 known CRC-16 algorithms
        </p>
      </div>

      <Tabs defaultValue="patcher" className="space-y-6">
        <TabsList>
          <TabsTrigger value="patcher">Single File</TabsTrigger>
          <TabsTrigger value="batch">Batch Processing</TabsTrigger>
          <TabsTrigger value="algorithms">Known Algorithms</TabsTrigger>
        </TabsList>

        <TabsContent value="patcher" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Upload EEE File</CardTitle>
              <CardDescription>
                Select your RFHUB EEE dump file (must be exactly 4096 bytes)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="eee-file">EEE File</Label>
                <div className="flex gap-2">
                  <Input
                    id="eee-file"
                    type="file"
                    accept=".eee,.bin"
                    onChange={handleFileChange}
                    className="flex-1"
                  />
                  {eeeFile && (
                    <Badge variant="outline" className="flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      {eeeFile.name}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-vin">New VIN (17 characters)</Label>
                <Input
                  id="new-vin"
                  value={newVIN}
                  onChange={(e) => setNewVIN(e.target.value.toUpperCase())}
                  placeholder="2C3CDXKT3FH796320"
                  maxLength={17}
                  className="font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="custom-poly">Custom Polynomial (optional)</Label>
                  <Input
                    id="custom-poly"
                    value={customPoly}
                    onChange={(e) => setCustomPoly(e.target.value)}
                    placeholder="0x589B"
                    className="font-mono"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="custom-init">Custom Init (optional)</Label>
                  <Input
                    id="custom-init"
                    value={customInit}
                    onChange={(e) => setCustomInit(e.target.value)}
                    placeholder="0xFFFF"
                    className="font-mono"
                  />
                </div>
              </div>

              <Button
                onClick={handlePatch}
                disabled={!eeeFile || !newVIN || patchVIN.isPending}
                className="w-full"
              >
                {patchVIN.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Patching...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Patch VIN
                  </>
                )}
              </Button>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {result && (
                <Alert className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                  <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <AlertDescription className="text-green-900 dark:text-green-100">
                    <div className="space-y-2">
                      <p className="font-semibold">VIN Patching Successful!</p>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="font-medium">Old VIN:</span> {result.oldVIN}
                        </div>
                        <div>
                          <span className="font-medium">New VIN:</span> {result.newVIN}
                        </div>
                        <div>
                          <span className="font-medium">Old Checksum:</span> {result.oldChecksum}
                        </div>
                        <div>
                          <span className="font-medium">New Checksum:</span> {result.newChecksum}
                        </div>
                        <div className="col-span-2">
                          <span className="font-medium">Algorithm:</span>{' '}
                          Poly={result.algorithm.poly}, Init={result.algorithm.init} (
                          {result.algorithm.source})
                        </div>
                      </div>
                      <Button onClick={handleDownload} className="w-full mt-2">
                        <Download className="mr-2 h-4 w-4" />
                        Download Patched EEE
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="batch" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileStack className="h-5 w-5" />
                Batch VIN Patching
              </CardTitle>
              <CardDescription>
                Process multiple RFHUB EEE files with the same VIN simultaneously
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="batch-files">Select Multiple EEE Files</Label>
                <Input
                  id="batch-files"
                  type="file"
                  accept=".eee,.bin"
                  multiple
                  onChange={handleBatchFileChange}
                  className="flex-1"
                />
                {batchFiles.length > 0 && (
                  <Badge variant="outline" className="flex items-center gap-1 w-fit">
                    <CheckCircle2 className="h-3 w-3" />
                    {batchFiles.length} file(s) selected
                  </Badge>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="batch-vin">New VIN (17 characters)</Label>
                <Input
                  id="batch-vin"
                  value={batchVIN}
                  onChange={(e) => setBatchVIN(e.target.value.toUpperCase())}
                  placeholder="2C3CDXKT3FH796320"
                  maxLength={17}
                  className="font-mono"
                />
              </div>

              <Button
                onClick={handleBatchPatch}
                disabled={batchFiles.length === 0 || !batchVIN || batchProcessing}
                className="w-full"
              >
                {batchProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing {batchProgress.current}/{batchProgress.total}...
                  </>
                ) : (
                  <>
                    <FileStack className="mr-2 h-4 w-4" />
                    Patch All Files
                  </>
                )}
              </Button>

              {batchProcessing && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Progress</span>
                    <span>{Math.round((batchProgress.current / batchProgress.total) * 100)}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${(batchProgress.current / batchProgress.total) * 100}%` }}
                    />
                  </div>
                </div>
              )}

              {batchResults.length > 0 && (
                <div className="space-y-4">
                  <Alert className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
                    <AlertDescription className="text-blue-900 dark:text-blue-100">
                      <div className="space-y-2">
                        <p className="font-semibold">Batch Processing Complete!</p>
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div>
                            <span className="font-medium">Total:</span> {batchResults.length}
                          </div>
                          <div className="text-green-600 dark:text-green-400">
                            <span className="font-medium">Success:</span> {batchResults.filter(r => r.success).length}
                          </div>
                          <div className="text-red-600 dark:text-red-400">
                            <span className="font-medium">Failed:</span> {batchResults.filter(r => !r.success).length}
                          </div>
                        </div>
                        <Button onClick={handleBatchDownload} className="w-full mt-2">
                          <Archive className="mr-2 h-4 w-4" />
                          Download All as ZIP
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {batchResults.map((result, idx) => (
                      <div
                        key={idx}
                        className={`p-3 border rounded-lg ${
                          result.success
                            ? 'bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800'
                            : 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-sm">{result.filename}</span>
                          {result.success ? (
                            <Badge className="bg-green-600">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Success
                            </Badge>
                          ) : (
                            <Badge variant="destructive">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              Failed
                            </Badge>
                          )}
                        </div>
                        {result.error && (
                          <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                            {result.error}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="algorithms">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Known CRC-16 Algorithms
              </CardTitle>
              <CardDescription>
                Database of 10 known VIN-specific CRC algorithms
              </CardDescription>
            </CardHeader>
            <CardContent>
              {knownAlgorithms.isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : (
                <div className="space-y-2">
                  {knownAlgorithms.data?.map((algo, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent"
                    >
                      <span className="font-mono text-sm">{algo.vin}</span>
                      <div className="flex gap-4 text-sm text-muted-foreground">
                        <span>
                          Poly: <span className="font-mono">0x{algo.poly.toString(16).toUpperCase().padStart(4, '0')}</span>
                        </span>
                        <span>
                          Init: <span className="font-mono">0x{algo.init.toString(16).toUpperCase().padStart(4, '0')}</span>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
