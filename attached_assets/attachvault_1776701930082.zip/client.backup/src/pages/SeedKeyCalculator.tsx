import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { BackButton } from "@/components/BackButton";
import { Copy, Calculator, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type Algorithm = {
  id: string;
  name: string;
  yearRange: string;
  modules: string[];
  constant: string;
  formula: string;
  calculate: (seed: number) => number;
};

const ALGORITHMS: Algorithm[] = [
  {
    id: "sbec2",
    name: "SBEC2/SBEC3",
    yearRange: "1996-2006",
    modules: ["ECM", "PCM", "TCM"],
    constant: "0x9018",
    formula: "(seed * 4) + 0x9018",
    calculate: (seed) => ((seed * 4) + 0x9018) & 0xFFFF,
  },
  {
    id: "ngc3",
    name: "NGC3/NGC4",
    yearRange: "2004-2010",
    modules: ["ECM", "PCM", "TCM"],
    constant: "0x8749, 0x4A, 0x259B",
    formula: "((seed ^ 0x8749) * 0x4A) + 0x259B",
    calculate: (seed) => (((seed ^ 0x8749) * 0x4A) + 0x259B) & 0xFFFF,
  },
  {
    id: "bcm_standard",
    name: "BCM Standard",
    yearRange: "2007-2015",
    modules: ["BCM"],
    constant: "0x4B92",
    formula: "ROL5(seed) ^ 0x4B92",
    calculate: (seed) => {
      const rol5 = ((seed << 5) | (seed >> 11)) & 0xFFFF;
      return rol5 ^ 0x4B92;
    },
  },
  {
    id: "bcm_fca",
    name: "BCM FCA",
    yearRange: "2010-2017",
    modules: ["BCM"],
    constant: "0x4B92",
    formula: "ROL5(seed) ^ 0x4B92",
    calculate: (seed) => {
      const rol5 = ((seed << 5) | (seed >> 11)) & 0xFFFF;
      return rol5 ^ 0x4B92;
    },
  },
  {
    id: "skim",
    name: "SKIM/WCM",
    yearRange: "2007-2017",
    modules: ["SKIM", "WCM", "SKREEM"],
    constant: "0x82F1",
    formula: "ROL5(seed) ^ 0x82F1",
    calculate: (seed) => {
      const rol5 = ((seed << 5) | (seed >> 11)) & 0xFFFF;
      return rol5 ^ 0x82F1;
    },
  },
  {
    id: "rfhub",
    name: "RFHUB RH850",
    yearRange: "2013+",
    modules: ["RFHUB"],
    constant: "Complex XTEA",
    formula: "XTEA encryption (32-bit)",
    calculate: (seed) => {
      // Simplified XTEA - real implementation is more complex
      let v0 = seed & 0xFFFF;
      let v1 = (seed >> 16) & 0xFFFF;
      const delta = 0x9E3779B9;
      let sum = 0;
      for (let i = 0; i < 32; i++) {
        v0 = (v0 + (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + 0xDEADBEEF)) & 0xFFFFFFFF;
        sum = (sum + delta) & 0xFFFFFFFF;
        v1 = (v1 + (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + 0xCAFEBABE)) & 0xFFFFFFFF;
      }
      return ((v0 << 16) | v1) & 0xFFFFFFFF;
    },
  },
  {
    id: "ecm_modern",
    name: "ECM/PCM Modern",
    yearRange: "2011+",
    modules: ["ECM", "PCM"],
    constant: "0x1209",
    formula: "ROL5(seed) ^ 0x1209",
    calculate: (seed) => {
      const rol5 = ((seed << 5) | (seed >> 11)) & 0xFFFF;
      return rol5 ^ 0x1209;
    },
  },
  {
    id: "tcm",
    name: "TCM Standard",
    yearRange: "2010+",
    modules: ["TCM"],
    constant: "0x4B92",
    formula: "(seed * 4) + 0x4B92",
    calculate: (seed) => ((seed * 4) + 0x4B92) & 0xFFFF,
  },
  {
    id: "abs",
    name: "ABS/ESP",
    yearRange: "2010+",
    modules: ["ABS", "ESP"],
    constant: "0x82F1",
    formula: "ROL5(seed) ^ 0x82F1",
    calculate: (seed) => {
      const rol5 = ((seed << 5) | (seed >> 11)) & 0xFFFF;
      return rol5 ^ 0x82F1;
    },
  },
];

export default function SeedKeyCalculator() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<string>("");
  const [seedInput, setSeedInput] = useState<string>("");
  const [calculatedKey, setCalculatedKey] = useState<number | null>(null);
  const [error, setError] = useState<string>("");
  const { toast } = useToast();

  const handleCalculate = () => {
    setError("");
    setCalculatedKey(null);

    if (!selectedAlgorithm) {
      setError("Please select an algorithm");
      return;
    }

    if (!seedInput) {
      setError("Please enter a seed value");
      return;
    }

    try {
      // Parse seed (supports hex with 0x prefix or decimal)
      const seed = seedInput.toLowerCase().startsWith("0x")
        ? parseInt(seedInput, 16)
        : parseInt(seedInput, 10);

      if (isNaN(seed)) {
        setError("Invalid seed value");
        return;
      }

      const algorithm = ALGORITHMS.find((a) => a.id === selectedAlgorithm);
      if (!algorithm) {
        setError("Algorithm not found");
        return;
      }

      const key = algorithm.calculate(seed);
      setCalculatedKey(key);

      toast({
        title: "Key Calculated",
        description: `Successfully calculated key using ${algorithm.name}`,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Calculation failed");
    }
  };

  const handleCopyKey = () => {
    if (calculatedKey !== null) {
      const hexKey = "0x" + calculatedKey.toString(16).toUpperCase().padStart(4, "0");
      navigator.clipboard.writeText(hexKey);
      toast({
        title: "Copied",
        description: "Key copied to clipboard",
      });
    }
  };

  const selectedAlgo = ALGORITHMS.find((a) => a.id === selectedAlgorithm);

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Seed-Key Calculator</h1>
        <p className="text-muted-foreground">
          Calculate security access keys using 9 different FCA/Stellantis algorithms
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Calculator
            </CardTitle>
            <CardDescription>Select algorithm and enter seed value</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Algorithm Selector */}
            <div className="space-y-2">
              <Label>Algorithm</Label>
              <Select value={selectedAlgorithm} onValueChange={setSelectedAlgorithm}>
                <SelectTrigger>
                  <SelectValue placeholder="Select algorithm..." />
                </SelectTrigger>
                <SelectContent>
                  {ALGORITHMS.map((algo) => (
                    <SelectItem key={algo.id} value={algo.id}>
                      {algo.name} ({algo.yearRange})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Seed Input */}
            <div className="space-y-2">
              <Label>Seed Value</Label>
              <Input
                placeholder="0x1234 or 4660"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleCalculate();
                }}
              />
              <p className="text-xs text-muted-foreground">
                Enter seed in hex (0x1234) or decimal (4660) format
              </p>
            </div>

            {/* Calculate Button */}
            <Button onClick={handleCalculate} className="w-full">
              <Calculator className="h-4 w-4 mr-2" />
              Calculate Key
            </Button>

            {/* Error Display */}
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Result Display */}
            {calculatedKey !== null && selectedAlgo && (
              <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                <CardHeader>
                  <CardTitle className="text-lg">Calculated Key</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Key Value */}
                  <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-900 rounded-lg border">
                    <div>
                      <p className="text-sm text-muted-foreground">Security Key</p>
                      <p className="text-2xl font-mono font-bold">
                        0x{calculatedKey.toString(16).toUpperCase().padStart(4, "0")}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Decimal: {calculatedKey}
                      </p>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleCopyKey}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>

                  {/* Formula Display */}
                  <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                    <p className="text-sm font-medium mb-2">Formula Used:</p>
                    <p className="font-mono text-sm">{selectedAlgo.formula}</p>
                    <p className="font-mono text-sm mt-2 text-muted-foreground">
                      {selectedAlgo.formula.replace("seed", seedInput)} = 0x
                      {calculatedKey.toString(16).toUpperCase().padStart(4, "0")}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Algorithm Info Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Info className="h-5 w-5" />
                Algorithm Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedAlgo ? (
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-1">Name</p>
                    <p className="text-sm text-muted-foreground">{selectedAlgo.name}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-1">Year Range</p>
                    <Badge variant="outline">{selectedAlgo.yearRange}</Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-2">Compatible Modules</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedAlgo.modules.map((module) => (
                        <Badge key={module} variant="secondary">
                          {module}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-1">Constant(s)</p>
                    <p className="font-mono text-sm text-muted-foreground">
                      {selectedAlgo.constant}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-1">Formula</p>
                    <p className="font-mono text-xs text-muted-foreground break-all">
                      {selectedAlgo.formula}
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Select an algorithm to view details
                </p>
              )}
            </CardContent>
          </Card>

          {/* Quick Reference */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Reference</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div>
                <p className="font-medium">UDS Security Access</p>
                <p className="text-muted-foreground text-xs">
                  Service 0x27 0x01 - Request Seed
                </p>
                <p className="text-muted-foreground text-xs">
                  Service 0x27 0x02 - Send Key
                </p>
              </div>
              <div className="pt-2 border-t">
                <p className="font-medium">Common Use Cases</p>
                <ul className="text-xs text-muted-foreground space-y-1 mt-1">
                  <li>• VIN Programming</li>
                  <li>• Module Configuration</li>
                  <li>• Flash Programming</li>
                  <li>• Diagnostic Procedures</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* All Algorithms Reference */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>All Available Algorithms</CardTitle>
          <CardDescription>Complete reference of 9 FCA/Stellantis seed-key algorithms</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Algorithm</th>
                  <th className="text-left p-2">Years</th>
                  <th className="text-left p-2">Modules</th>
                  <th className="text-left p-2">Formula</th>
                </tr>
              </thead>
              <tbody>
                {ALGORITHMS.map((algo) => (
                  <tr key={algo.id} className="border-b hover:bg-muted/50">
                    <td className="p-2 font-medium">{algo.name}</td>
                    <td className="p-2">
                      <Badge variant="outline" className="text-xs">
                        {algo.yearRange}
                      </Badge>
                    </td>
                    <td className="p-2">
                      <div className="flex flex-wrap gap-1">
                        {algo.modules.map((m) => (
                          <Badge key={m} variant="secondary" className="text-xs">
                            {m}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="p-2 font-mono text-xs">{algo.formula}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
