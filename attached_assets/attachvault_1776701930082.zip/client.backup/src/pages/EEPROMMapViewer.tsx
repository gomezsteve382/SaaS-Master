import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { BackButton } from "@/components/BackButton";
import { Download, Upload, Search, Copy } from 'lucide-react';

type ModuleType = 'BCM' | 'RFHUB' | 'ECM' | 'TCM' | 'ABS' | 'IPC' | 'ACM' | 'RADIO' | 'CGW';

interface MemoryRegion {
  name: string;
  offset: number;
  length: number;
  type: 'vin' | 'security' | 'feature' | 'checksum' | 'data';
  description: string;
}

const EEPROM_MAPS: Record<ModuleType, MemoryRegion[]> = {
  BCM: [
    { name: 'Original VIN', offset: 0x0400, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0440, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Feature Bytes', offset: 0x0460, length: 32, type: 'feature', description: 'Module configuration flags' },
    { name: 'Checksum', offset: 0x0480, length: 2, type: 'checksum', description: 'CRC-16 for data integrity' },
  ],
  RFHUB: [
    { name: 'Original VIN', offset: 0x0100, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0120, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Security Bytes', offset: 0x0130, length: 4, type: 'security', description: 'Immobilizer pairing data' },
    { name: 'PIN', offset: 0x0134, length: 4, type: 'security', description: 'SKIM PIN (4 digits)' },
    { name: 'Checksum', offset: 0x0140, length: 1, type: 'checksum', description: 'Complement checksum' },
  ],
  ECM: [
    { name: 'Original VIN', offset: 0x1000, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x1020, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Calibration Data', offset: 0x2000, length: 4096, type: 'data', description: 'Fuel/ignition maps' },
    { name: 'Checksum', offset: 0x1040, length: 4, type: 'checksum', description: 'CRC-32 for data integrity' },
  ],
  TCM: [
    { name: 'Original VIN', offset: 0x0800, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0820, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Shift Points', offset: 0x0900, length: 256, type: 'data', description: 'Transmission shift calibration' },
    { name: 'Checksum', offset: 0x0840, length: 4, type: 'checksum', description: 'CRC-32 for data integrity' },
  ],
  ABS: [
    { name: 'Original VIN', offset: 0x0200, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0220, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Checksum', offset: 0x0240, length: 2, type: 'checksum', description: 'CRC-16 for data integrity' },
  ],
  IPC: [
    { name: 'Original VIN', offset: 0x0300, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0320, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Odometer', offset: 0x0340, length: 4, type: 'data', description: 'Mileage storage' },
    { name: 'Checksum', offset: 0x0340, length: 2, type: 'checksum', description: 'CRC-16 for data integrity' },
  ],
  ACM: [
    { name: 'Original VIN', offset: 0x0500, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0520, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Checksum', offset: 0x0540, length: 2, type: 'checksum', description: 'CRC-16 for data integrity' },
  ],
  RADIO: [
    { name: 'Original VIN', offset: 0x0600, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0620, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Checksum', offset: 0x0640, length: 2, type: 'checksum', description: 'CRC-16 for data integrity' },
  ],
  CGW: [
    { name: 'Original VIN', offset: 0x0700, length: 17, type: 'vin', description: 'First VIN ever written (permanent)' },
    { name: 'Current VIN', offset: 0x0720, length: 17, type: 'vin', description: 'Active VIN for diagnostics' },
    { name: 'Checksum', offset: 0x0740, length: 4, type: 'checksum', description: 'CRC-32 for data integrity' },
  ],
};

export default function EEPROMMapViewer() {
  const [selectedModule, setSelectedModule] = useState<ModuleType>('BCM');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<MemoryRegion | null>(null);
  const [hexData, setHexData] = useState<string>('FF'.repeat(256)); // Simulated EEPROM data

  const regions = EEPROM_MAPS[selectedModule];
  const filteredRegions = regions.filter(r =>
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRegionColor = (type: MemoryRegion['type']) => {
    switch (type) {
      case 'vin': return 'bg-blue-500/20 border-blue-500';
      case 'security': return 'bg-red-500/20 border-red-500';
      case 'feature': return 'bg-green-500/20 border-green-500';
      case 'checksum': return 'bg-purple-500/20 border-purple-500';
      case 'data': return 'bg-yellow-500/20 border-yellow-500';
    }
  };

  const getRegionBadgeColor = (type: MemoryRegion['type']) => {
    switch (type) {
      case 'vin': return 'bg-blue-500';
      case 'security': return 'bg-red-500';
      case 'feature': return 'bg-green-500';
      case 'checksum': return 'bg-purple-500';
      case 'data': return 'bg-yellow-500';
    }
  };

  const exportMap = () => {
    const map = {
      module: selectedModule,
      regions: EEPROM_MAPS[selectedModule],
      timestamp: new Date().toISOString(),
    };

    const json = JSON.stringify(map, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedModule}_EEPROM_Map.json`;
    a.click();
  };

  const copyOffset = (offset: number) => {
    navigator.clipboard.writeText(`0x${offset.toString(16).toUpperCase().padStart(4, '0')}`);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
          EEPROM Memory Map Viewer
        </h1>
        <p className="text-muted-foreground mt-2">
          Interactive memory map showing exact byte offsets for VINs, security bytes, feature bytes, and checksums
        </p>
      </div>

      {/* Module Selector */}
      <Card className="p-6">
        <div className="flex items-center justify-between gap-4">
          <div className="flex-1">
            <Label htmlFor="module">Select Module</Label>
            <Select value={selectedModule} onValueChange={(v: ModuleType) => setSelectedModule(v)}>
              <SelectTrigger id="module">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BCM">BCM - Body Control Module</SelectItem>
                <SelectItem value="RFHUB">RFHUB - SmartBox (Immobilizer)</SelectItem>
                <SelectItem value="ECM">ECM - Engine Control Module</SelectItem>
                <SelectItem value="TCM">TCM - Transmission Control Module</SelectItem>
                <SelectItem value="ABS">ABS - Anti-lock Braking System</SelectItem>
                <SelectItem value="IPC">IPC - Instrument Panel Cluster</SelectItem>
                <SelectItem value="ACM">ACM - Airbag Control Module</SelectItem>
                <SelectItem value="RADIO">RADIO - Uconnect/Infotainment</SelectItem>
                <SelectItem value="CGW">CGW - Central Gateway</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button onClick={exportMap} variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Map
            </Button>
            <Button variant="outline">
              <Upload className="mr-2 h-4 w-4" />
              Import Dump
            </Button>
          </div>
        </div>
      </Card>

      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search memory regions..."
            className="pl-10"
          />
        </div>
      </Card>

      {/* Memory Map */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Regions List */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Memory Regions</h2>
          <div className="space-y-3">
            {filteredRegions.map((region, index) => (
              <div
                key={index}
                className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${getRegionColor(region.type)} ${
                  selectedRegion === region ? 'ring-2 ring-white' : ''
                }`}
                onClick={() => setSelectedRegion(region)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{region.name}</h3>
                      <Badge className={getRegionBadgeColor(region.type)}>
                        {region.type.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{region.description}</p>
                    <div className="flex items-center gap-4 text-xs font-mono">
                      <span className="flex items-center gap-1">
                        Offset: <strong>0x{region.offset.toString(16).toUpperCase().padStart(4, '0')}</strong>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0"
                          onClick={(e) => {
                            e.stopPropagation();
                            copyOffset(region.offset);
                          }}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </span>
                      <span>Length: <strong>{region.length} bytes</strong></span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Hex Editor */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Hex Editor</h2>
          {selectedRegion ? (
            <div className="space-y-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">{selectedRegion.name}</h3>
                  <Badge className={getRegionBadgeColor(selectedRegion.type)}>
                    {selectedRegion.type.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{selectedRegion.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div>Offset: <strong>0x{selectedRegion.offset.toString(16).toUpperCase().padStart(4, '0')}</strong></div>
                  <div>Length: <strong>{selectedRegion.length} bytes</strong></div>
                </div>
              </div>

              <Separator />

              <div>
                <Label>Hex Data (Read/Write)</Label>
                <textarea
                  value={hexData.slice(0, selectedRegion.length * 2)}
                  onChange={(e) => setHexData(e.target.value)}
                  className="w-full h-64 p-3 font-mono text-sm bg-black/50 text-green-400 rounded-lg border border-border"
                  placeholder="FF FF FF FF..."
                />
                <p className="text-xs text-muted-foreground mt-1">
                  {selectedRegion.length * 2} hex characters ({selectedRegion.length} bytes)
                </p>
              </div>

              <div className="flex gap-2">
                <Button className="flex-1">
                  Read from Module
                </Button>
                <Button variant="destructive" className="flex-1">
                  Write to Module
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-muted-foreground">
              Select a memory region to view/edit
            </div>
          )}
        </Card>
      </div>

      {/* Legend */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Region Types</h2>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-blue-500" />
            <span className="text-sm">VIN - Vehicle Identification Number</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-red-500" />
            <span className="text-sm">Security - Immobilizer/PIN data</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-green-500" />
            <span className="text-sm">Feature - Configuration flags</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-purple-500" />
            <span className="text-sm">Checksum - Data integrity</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-yellow-500" />
            <span className="text-sm">Data - Calibration/configuration</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
