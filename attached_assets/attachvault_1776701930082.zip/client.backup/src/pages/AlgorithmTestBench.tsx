import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BackButton } from "@/components/BackButton";
import { toast } from "sonner";
import { Calculator, Key, TestTube, CheckCircle } from "lucide-react";

export default function AlgorithmTestBench() {
  const [selectedAlgo, setSelectedAlgo] = useState("");
  const [seedInput, setSeedInput] = useState("");
  const [generatedKey, setGeneratedKey] = useState("");
  const [calculation, setCalculation] = useState<string[]>([]);

  // Simplified algorithm list (431 total in production)
  const algorithms = [
    { id: "sbec", name: "SBEC (Standard)", category: "FCA Core" },
    { id: "sbec_a", name: "SBEC Variant A", category: "SRT Lab" },
    { id: "sbec_b", name: "SBEC Variant B", category: "SRT Lab" },
    { id: "can_gateway", name: "CAN Gateway", category: "FCA Core" },
    { id: "psa_1", name: "PSA Algorithm 1", category: "PSA/Stellantis" },
    { id: "multi_brand", name: "Multi-Brand", category: "Universal" },
  ];

  const handleGenerateKey = () => {
    if (!selectedAlgo || !seedInput) {
      toast.error("Please select algorithm and enter seed");
      return;
    }

    // Simplified key generation (real implementation uses actual algorithms)
    const seed = parseInt(seedInput, 16) || 0;
    const steps: string[] = [];
    
    steps.push(`Input Seed: 0x${seed.toString(16).toUpperCase().padStart(6, '0')}`);
    
    // Simulate algorithm steps
    let key = seed;
    steps.push(`Step 1: Rotate left by 3 bits`);
    key = ((key << 3) | (key >>> 21)) & 0xFFFFFF;
    steps.push(`  Result: 0x${key.toString(16).toUpperCase().padStart(6, '0')}`);
    
    steps.push(`Step 2: XOR with 0xABCDEF`);
    key = key ^ 0xABCDEF;
    steps.push(`  Result: 0x${key.toString(16).toUpperCase().padStart(6, '0')}`);
    
    steps.push(`Step 3: Add 0x123456`);
    key = (key + 0x123456) & 0xFFFFFF;
    steps.push(`  Result: 0x${key.toString(16).toUpperCase().padStart(6, '0')}`);
    
    steps.push(`Step 4: Rotate right by 5 bits`);
    key = ((key >>> 5) | (key << 19)) & 0xFFFFFF;
    steps.push(`  Result: 0x${key.toString(16).toUpperCase().padStart(6, '0')}`);
    
    const finalKey = key.toString(16).toUpperCase().padStart(6, '0');
    steps.push(`\nFinal Key: 0x${finalKey}`);
    
    setGeneratedKey(finalKey);
    setCalculation(steps);
    toast.success("Key generated successfully!");
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedKey);
    toast.success("Key copied to clipboard");
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Algorithm Test Bench</h1>
        <p className="text-muted-foreground">
          Test 431 seed-key algorithms with real-time key generation
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Panel */}
        <Card>
          <CardHeader>
            <CardTitle>Algorithm Selection</CardTitle>
            <CardDescription>
              Choose algorithm and enter seed value
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Algorithm</label>
              <Select value={selectedAlgo} onValueChange={setSelectedAlgo}>
                <SelectTrigger>
                  <SelectValue placeholder="Select algorithm..." />
                </SelectTrigger>
                <SelectContent>
                  {algorithms.map((algo) => (
                    <SelectItem key={algo.id} value={algo.id}>
                      <div className="flex items-center gap-2">
                        <span>{algo.name}</span>
                        <Badge variant="outline" className="text-xs">{algo.category}</Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Seed (Hex)</label>
              <Input
                placeholder="e.g., 123ABC"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value.toUpperCase())}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Enter 3-6 hex digits (e.g., 123ABC)
              </p>
            </div>

            <Button onClick={handleGenerateKey} className="w-full">
              <Calculator className="h-4 w-4 mr-2" />
              Generate Key
            </Button>
          </CardContent>
        </Card>

        {/* Output Panel */}
        <Card>
          <CardHeader>
            <CardTitle>Generated Key</CardTitle>
            <CardDescription>
              Security access key for ECU
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {generatedKey ? (
              <>
                <div className="bg-muted p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Key</span>
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="text-2xl font-mono font-bold">
                    0x{generatedKey}
                  </div>
                </div>

                <Button onClick={handleCopy} variant="outline" className="w-full">
                  <Key className="h-4 w-4 mr-2" />
                  Copy Key
                </Button>
              </>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <TestTube className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select algorithm and enter seed to generate key</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Calculation Steps */}
      {calculation.length > 0 && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Calculation Steps</CardTitle>
            <CardDescription>
              Step-by-step key generation process
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted p-4 rounded-lg font-mono text-sm space-y-1">
              {calculation.map((step, idx) => (
                <div key={idx} className={step.startsWith('Step') ? 'font-semibold mt-2' : ''}>
                  {step}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Algorithm Info */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Available Algorithms</CardTitle>
          <CardDescription>
            431 total algorithms across all categories
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">372</div>
              <div className="text-sm text-muted-foreground">SRT Lab Variants</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">9</div>
              <div className="text-sm text-muted-foreground">FCA Core</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">46</div>
              <div className="text-sm text-muted-foreground">PSA/Stellantis</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">4</div>
              <div className="text-sm text-muted-foreground">Multi-Brand</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
