import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Key,
  Search,
  Download,
  Upload,
  Database,
  TrendingUp,
  Shield,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from 'lucide-react';

export default function SkreemKeyDatabase() {
  const [searchVIN, setSearchVIN] = useState('');
  const [searchPartNumber, setSearchPartNumber] = useState('');
  const [moduleTypeFilter, setModuleTypeFilter] = useState<string>('all');
  const [entropyMin, setEntropyMin] = useState('');

  // Queries
  const allKeys = trpc.skreem.getAllKeys.useQuery();
  const searchKeys = trpc.skreem.searchKeys.useQuery(
    {
      vin: searchVIN || undefined,
      partNumber: searchPartNumber || undefined,
      moduleType: moduleTypeFilter !== 'all' ? moduleTypeFilter : undefined,
      minEntropy: entropyMin ? parseInt(entropyMin) : undefined,
    },
    { enabled: !!(searchVIN || searchPartNumber || moduleTypeFilter !== 'all' || entropyMin) }
  );
  const stats = trpc.skreem.getStatistics.useQuery();

  // Mutations
  const addKey = trpc.skreem.addKey.useMutation({
    onSuccess: () => {
      allKeys.refetch();
      stats.refetch();
    },
  });
  const deleteKey = trpc.skreem.deleteKey.useMutation({
    onSuccess: () => {
      allKeys.refetch();
      stats.refetch();
    },
  });

  const displayedKeys: any[] = searchKeys.data || allKeys.data || [];

  const getEntropyColor = (score: number | null) => {
    if (!score) return 'text-gray-500';
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const exportToCSV = () => {
    if (!displayedKeys.length) return;

    const headers = ['ID', 'VIN', 'Part Number', 'Module Type', 'Key Data', 'Entropy', 'Extraction Method', 'Date'];
    const rows = displayedKeys.map((key: any) => [
      key.id,
      key.vin || '',
      key.modulePartNumber || '',
      key.moduleType,
      key.keyData,
      key.entropyScore || '',
      key.extractionMethod || '',
      new Date(key.extractedAt).toLocaleDateString(),
    ]);

    const csv = [headers, ...rows].map((row) => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `skreem_keys_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">SKREEM Key Database</h1>
        <p className="text-muted-foreground">
          Searchable repository of extracted RFHUB/BCM security keys with entropy analysis
        </p>
      </div>

      {/* Statistics Dashboard */}
      {stats.data && (
        <div className="grid grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Database className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold">{stats.data.totalKeys}</div>
                  <div className="text-sm text-muted-foreground">Total Keys</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <TrendingUp className="h-8 w-8 text-green-600" />
                <div>
                  <div className="text-2xl font-bold">{stats.data.avgEntropy.toFixed(1)}</div>
                  <div className="text-sm text-muted-foreground">Avg Entropy</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Shield className="h-8 w-8 text-purple-600" />
                <div>
                  <div className="text-2xl font-bold">{stats.data.uniqueVINs}</div>
                  <div className="text-sm text-muted-foreground">Unique VINs</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Key className="h-8 w-8 text-orange-600" />
                <div>
                  <div className="text-2xl font-bold">{stats.data.uniquePartNumbers}</div>
                  <div className="text-sm text-muted-foreground">Part Numbers</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="search" className="space-y-6">
        <TabsList>
          <TabsTrigger value="search">Search & Browse</TabsTrigger>
          <TabsTrigger value="add">Add New Key</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
        </TabsList>

        {/* Search & Browse Tab */}
        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Search Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="search-vin">VIN</Label>
                  <Input
                    id="search-vin"
                    value={searchVIN}
                    onChange={(e) => setSearchVIN(e.target.value.toUpperCase())}
                    placeholder="2C3CDXKT3FH796320"
                    className="font-mono"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="search-part">Part Number</Label>
                  <Input
                    id="search-part"
                    value={searchPartNumber}
                    onChange={(e) => setSearchPartNumber(e.target.value.toUpperCase())}
                    placeholder="68303831AA"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="module-type">Module Type</Label>
                  <Select value={moduleTypeFilter} onValueChange={setModuleTypeFilter}>
                    <SelectTrigger id="module-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="RFHUB">RFHUB</SelectItem>
                      <SelectItem value="BCM">BCM</SelectItem>
                      <SelectItem value="WCM">WCM</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="entropy-min">Min Entropy</Label>
                  <Input
                    id="entropy-min"
                    type="number"
                    value={entropyMin}
                    onChange={(e) => setEntropyMin(e.target.value)}
                    placeholder="0-100"
                    min="0"
                    max="100"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    setSearchVIN('');
                    setSearchPartNumber('');
                    setModuleTypeFilter('all');
                    setEntropyMin('');
                  }}
                  variant="outline"
                >
                  Clear Filters
                </Button>
                <Button onClick={exportToCSV} variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results Table */}
          <Card>
            <CardHeader>
              <CardTitle>
                {displayedKeys.length} Key{displayedKeys.length !== 1 ? 's' : ''} Found
              </CardTitle>
            </CardHeader>
            <CardContent>
              {allKeys.isLoading || searchKeys.isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : displayedKeys.length === 0 ? (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>No keys found matching your criteria.</AlertDescription>
                </Alert>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>VIN</TableHead>
                        <TableHead>Part Number</TableHead>
                        <TableHead>Module</TableHead>
                        <TableHead>Key Data</TableHead>
                        <TableHead>Entropy</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {displayedKeys.map((key: any) => (
                        <TableRow key={key.id}>
                          <TableCell className="font-mono text-sm">
                            {key.vin || <span className="text-muted-foreground">N/A</span>}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {key.modulePartNumber || <span className="text-muted-foreground">N/A</span>}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{key.moduleType}</Badge>
                          </TableCell>
                          <TableCell className="font-mono text-xs max-w-xs truncate">
                            {key.keyData}
                          </TableCell>
                          <TableCell>
                            <span className={`font-semibold ${getEntropyColor(key.entropyScore)}`}>
                              {key.entropyScore || 'N/A'}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm">
                            {key.extractionMethod || <span className="text-muted-foreground">N/A</span>}
                          </TableCell>
                          <TableCell className="text-sm">
                            {new Date(key.extractedAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => deleteKey.mutate({ id: key.id })}
                            >
                              Delete
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Add New Key Tab */}
        <TabsContent value="add" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Add New SKREEM Key
              </CardTitle>
              <CardDescription>
                Manually add an extracted key to the database
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Keys are automatically added when extracted via RFHUB SKREEM Extractor.
                  Use this form only for manual imports.
                </AlertDescription>
              </Alert>
              <p className="text-sm text-muted-foreground">
                This feature integrates with the RFHUB SKREEM Extractor tool for automatic key population.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analysis Tab */}
        <TabsContent value="analysis" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Entropy Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {stats.data && (
                  <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground mb-1">High Entropy (80+)</div>
                      <div className="text-2xl font-bold text-green-600">
                        {stats.data.entropyDistribution.high}
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground mb-1">Medium Entropy (60-79)</div>
                      <div className="text-2xl font-bold text-yellow-600">
                        {stats.data.entropyDistribution.medium}
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground mb-1">Low Entropy (&lt;60)</div>
                      <div className="text-2xl font-bold text-red-600">
                        {stats.data.entropyDistribution.low}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-2">Security Marker Distribution</h3>
                    <div className="space-y-2">
                      {Object.entries(stats.data.markerDistribution).map(([marker, count]: [string, any]) => (
                        <div key={marker} className="flex items-center justify-between">
                          <span className="font-mono text-sm">{marker}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
