import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { BackButton } from "@/components/BackButton";
import { Download, Filter, CheckCircle2, XCircle, AlertTriangle, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function VINProgrammingHistory() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [filterModule, setFilterModule] = useState("");
  const [filterVIN, setFilterVIN] = useState("");
  const [filterStatus, setFilterStatus] = useState<"success" | "failure" | "all">("all");
  const [selectedOperation, setSelectedOperation] = useState<any>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);

  const operationsQuery = trpc.vinHistory.getVINOperations.useQuery({
    page,
    pageSize: 50,
    filterModule,
    filterVIN,
    filterStatus,
  });

  const statsQuery = trpc.vinHistory.getStatistics.useQuery({});
  const exportMutation = trpc.vinHistory.exportHistory.useMutation();

  const handleExport = async () => {
    try {
      const result = await exportMutation.mutateAsync({
        filterModule,
        filterVIN,
        filterStatus,
      });

      // Create download
      const blob = new Blob([result.data], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export successful",
        description: `Exported ${operationsQuery.data?.total || 0} operations to CSV`,
      });
    } catch (error: any) {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleViewDetails = (operation: any) => {
    setSelectedOperation(operation);
    setShowDetailsDialog(true);
  };

  const getRiskBadge = (riskLevel: string | null) => {
    switch (riskLevel) {
      case "safe":
        return <Badge className="bg-green-600">Safe</Badge>;
      case "caution":
        return <Badge className="bg-yellow-600">Caution</Badge>;
      case "danger":
        return <Badge className="bg-red-600">Danger</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    return status === "success" ? (
      <Badge className="bg-green-600 flex items-center gap-1 w-fit">
        <CheckCircle2 className="h-3 w-3" />
        Success
      </Badge>
    ) : (
      <Badge variant="destructive" className="flex items-center gap-1 w-fit">
        <XCircle className="h-3 w-3" />
        Failed
      </Badge>
    );
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">VIN Programming History</h1>
        <p className="text-muted-foreground">
          Complete audit log of all VIN programming operations with compliance tracking
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Operations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsQuery.data?.statistics?.totalOperations || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {statsQuery.data?.statistics?.successRate || "0.0"}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Successful</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {statsQuery.data?.statistics?.successfulOperations || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Failed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {statsQuery.data?.statistics?.failedOperations || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Operations Table */}
        <div className="lg:col-span-2 space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filters</CardTitle>
              <CardDescription>Filter operations by module, VIN, or status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Module</Label>
                  <Input
                    placeholder="e.g., RFHUB"
                    value={filterModule}
                    onChange={(e) => setFilterModule(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>VIN</Label>
                  <Input
                    placeholder="e.g., 1C4RJFBG"
                    value={filterVIN}
                    onChange={(e) => setFilterVIN(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={filterStatus} onValueChange={(v: any) => setFilterStatus(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="success">Success Only</SelectItem>
                      <SelectItem value="failure">Failed Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExport}
                  disabled={exportMutation.isPending || !operationsQuery.data?.operations.length}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setFilterModule("");
                    setFilterVIN("");
                    setFilterStatus("all");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Operations Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Operations History</CardTitle>
                  <CardDescription>
                    Showing {operationsQuery.data?.operations.length || 0} of {operationsQuery.data?.total || 0} operations
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-[600px] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead className="w-[140px]">Timestamp</TableHead>
                        <TableHead className="w-[120px]">VIN</TableHead>
                        <TableHead className="w-[100px]">Module</TableHead>
                        <TableHead className="w-[100px]">Status</TableHead>
                        <TableHead className="w-[100px]">Risk</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {operationsQuery.isLoading ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                            Loading operations...
                          </TableCell>
                        </TableRow>
                      ) : !operationsQuery.data?.operations.length ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                            No operations found
                          </TableCell>
                        </TableRow>
                      ) : (
                        operationsQuery.data.operations.map((op: any) => (
                          <TableRow key={op.id}>
                            <TableCell className="font-mono text-xs">
                              {new Date(op.timestamp).toLocaleString()}
                            </TableCell>
                            <TableCell className="font-mono font-semibold">{op.vin || "N/A"}</TableCell>
                            <TableCell className="font-semibold">{op.module || "N/A"}</TableCell>
                            <TableCell>{getStatusBadge(op.status)}</TableCell>
                            <TableCell>{getRiskBadge(op.riskLevel)}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewDetails(op)}
                              >
                                Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Pagination */}
              {operationsQuery.data && operationsQuery.data.pageSize && operationsQuery.data.total > operationsQuery.data.pageSize && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Page {page} of {Math.ceil(operationsQuery.data.total / operationsQuery.data.pageSize)}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(page - 1)}
                      disabled={page === 1}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(page + 1)}
                      disabled={page >= Math.ceil(operationsQuery.data.total / operationsQuery.data.pageSize)}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar: Module Distribution & Risk Levels */}
        <div className="space-y-6">
          {/* Top Modules */}
          <Card>
            <CardHeader>
              <CardTitle>Top Modules</CardTitle>
              <CardDescription>Most frequently programmed modules</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {statsQuery.data?.statistics?.topModules?.map((item: any, index: number) => (
                <div key={item.module} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold">{item.module}</span>
                    <span className="text-muted-foreground">
                      {item.count} ({item.percentage}%)
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-cyan-600"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Risk Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Risk Distribution</CardTitle>
              <CardDescription>Operations by risk level</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {statsQuery.data?.statistics?.riskDistribution && (
                <>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-green-600">Safe</Badge>
                      <span className="text-sm text-muted-foreground">Low risk operations</span>
                    </div>
                    <span className="font-semibold">{statsQuery.data.statistics.riskDistribution.safe}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-yellow-600">Caution</Badge>
                      <span className="text-sm text-muted-foreground">Medium risk operations</span>
                    </div>
                    <span className="font-semibold">{statsQuery.data.statistics.riskDistribution.caution}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-red-600">Danger</Badge>
                      <span className="text-sm text-muted-foreground">High risk operations</span>
                    </div>
                    <span className="font-semibold">{statsQuery.data.statistics.riskDistribution.danger}</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Last 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <TrendingUp className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold">
                    {statsQuery.data?.statistics?.recentOperations || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Operations</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Operation Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Operation Details</DialogTitle>
            <DialogDescription>
              Complete information about this VIN programming operation
            </DialogDescription>
          </DialogHeader>
          {selectedOperation && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Timestamp</Label>
                  <p className="font-mono text-sm">{new Date(selectedOperation.timestamp).toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Session ID</Label>
                  <p className="font-mono text-sm">{selectedOperation.sessionId || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">VIN</Label>
                  <p className="font-mono font-semibold">{selectedOperation.vin || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Module</Label>
                  <p className="font-semibold">{selectedOperation.module || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <div className="mt-1">{getStatusBadge(selectedOperation.status)}</div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Risk Level</Label>
                  <div className="mt-1">{getRiskBadge(selectedOperation.riskLevel)}</div>
                </div>
              </div>

              {selectedOperation.details && Object.keys(selectedOperation.details).length > 0 && (
                <div>
                  <Label className="text-muted-foreground">Additional Details</Label>
                  <div className="mt-2 p-4 bg-muted rounded-lg">
                    <pre className="text-xs overflow-x-auto">
                      {JSON.stringify(selectedOperation.details, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
