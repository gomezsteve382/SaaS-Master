import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { 
  Play, 
  Square, 
  Download, 
  Search,
  Clock,
  CheckCircle2,
  XCircle,
  FileText,
  Share2,
  Eye,
  Filter
} from 'lucide-react';

interface UDSCommand {
  timestamp: Date;
  direction: 'tx' | 'rx';
  data: string;
  description: string;
  duration?: number;
  status: 'success' | 'error' | 'pending';
}

interface DiagnosticSession {
  id: string;
  name: string;
  vehicle: string;
  module: string;
  startTime: Date;
  endTime?: Date;
  commands: UDSCommand[];
  status: 'recording' | 'completed' | 'failed';
  notes?: string;
}

export default function DiagnosticSessionRecording() {
  const [isRecording, setIsRecording] = useState(false);
  const [currentSession, setCurrentSession] = useState<DiagnosticSession | null>(null);
  const [sessions, setSessions] = useState<DiagnosticSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<DiagnosticSession | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Mock UDS commands for demonstration
  const mockUDSCommands: UDSCommand[] = [
    {
      timestamp: new Date(),
      direction: 'tx',
      data: '10 03',
      description: 'Enter Extended Diagnostic Session',
      duration: 50,
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 50),
      direction: 'rx',
      data: '50 03',
      description: 'Positive Response - Session Changed',
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 100),
      direction: 'tx',
      data: '22 F1 8C',
      description: 'Read CSN (Challenge Serial Number)',
      duration: 100,
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 200),
      direction: 'rx',
      data: '62 F1 8C 44 00 31 13 30',
      description: 'CSN Response: 44 00 31 13 30',
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 300),
      direction: 'tx',
      data: '27 05',
      description: 'Request Seed - Level 5 (Atlantis)',
      duration: 150,
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 450),
      direction: 'rx',
      data: '67 05 9A 3C 7E 2F',
      description: 'Seed Response: 9A 3C 7E 2F',
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 600),
      direction: 'tx',
      data: '27 06 90 37 9C 69 3E',
      description: 'Send Key - Level 6 (Calculated)',
      duration: 100,
      status: 'success'
    },
    {
      timestamp: new Date(Date.now() + 700),
      direction: 'rx',
      data: '67 06',
      description: 'Security Access UNLOCKED!',
      status: 'success'
    }
  ];

  const startRecording = async () => {
    try {
      const { ConnectionManager } = await import('@/lib/obd2-protocol');
      const connMgr = new ConnectionManager();
      const state = connMgr.getState();
      const protocol = connMgr.getProtocol();
      
      if (state !== 'connected' || !protocol) {
        alert('Not connected to vehicle. Please connect hardware first.');
        return;
      }

      const newSession: DiagnosticSession = {
        id: `session-${Date.now()}`,
        name: `Session ${sessions.length + 1}`,
        vehicle: 'Connected Vehicle',
        module: 'Live Capture',
        startTime: new Date(),
        commands: [],
        status: 'recording'
      };

      setCurrentSession(newSession);
      setIsRecording(true);

      // Intercept real UDS traffic by wrapping protocol.sendUDS
      const originalSendUDS = protocol.sendUDS.bind(protocol);
      
      protocol.sendUDS = async (tx: number, rx: number, data: number[]) => {
        const startTime = Date.now();
        
        // Log TX
        const txCommand: UDSCommand = {
          timestamp: new Date(),
          direction: 'tx',
          data: data.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
          description: describeUDSCommand(data),
          status: 'pending'
        };
        
        setCurrentSession(prev => {
          if (!prev) return prev;
          return { ...prev, commands: [...prev.commands, txCommand] };
        });

        try {
          // Send real command
          const response = await originalSendUDS(tx, rx, data);
          const duration = Date.now() - startTime;
          
          // Log RX
          if (response) {
            const rxCommand: UDSCommand = {
              timestamp: new Date(),
              direction: 'rx',
              data: Array.from(response).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
              description: describeUDSResponse(Array.from(response)),
              duration,
              status: 'success'
            };
            
            setCurrentSession(prev => {
              if (!prev) return prev;
              const updatedCommands = [...prev.commands];
              updatedCommands[updatedCommands.length - 1].status = 'success';
              updatedCommands[updatedCommands.length - 1].duration = duration;
              return { ...prev, commands: [...updatedCommands, rxCommand] };
            });
          }
          
          return response;
        } catch (error) {
          // Log error
          setCurrentSession(prev => {
            if (!prev) return prev;
            const updatedCommands = [...prev.commands];
            updatedCommands[updatedCommands.length - 1].status = 'error';
            return { ...prev, commands: updatedCommands };
          });
          throw error;
        }
      };

    } catch (error) {
      alert('Failed to start recording: ' + (error as Error).message);
    }
  };

  const describeUDSCommand = (data: number[]): string => {
    const service = data[0];
    const descriptions: Record<number, string> = {
      0x10: 'Diagnostic Session Control',
      0x22: 'Read Data By Identifier',
      0x27: 'Security Access',
      0x2E: 'Write Data By Identifier',
      0x31: 'Routine Control',
      0x3E: 'Tester Present',
    };
    return descriptions[service] || `Service 0x${service.toString(16)}`;
  };

  const describeUDSResponse = (data: number[]): string => {
    if (data[0] === 0x7F) return `Negative Response: ${data[2].toString(16)}`;
    return `Positive Response`;
  };

  const saveSessionMutation = trpc.sessionReplay.saveSession.useMutation();

  const stopRecording = () => {
    if (currentSession) {
      const completedSession: DiagnosticSession = {
        ...currentSession,
        endTime: new Date(),
        status: 'completed'
      };

      // Save to database
      saveSessionMutation.mutate({
        id: completedSession.id,
        name: completedSession.name,
        vehicle: completedSession.vehicle,
        module: completedSession.module,
        startTime: completedSession.startTime,
        endTime: completedSession.endTime,
        status: completedSession.status,
        notes: completedSession.notes,
        commands: completedSession.commands,
      });

      setSessions(prev => [...prev, completedSession]);
      setCurrentSession(null);
      setIsRecording(false);
    }
  };

  const exportSession = (session: DiagnosticSession) => {
    const json = JSON.stringify(session, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${session.name.replace(/\s+/g, '_')}_${session.id}.json`;
    a.click();
  };

  const exportSessionCSV = (session: DiagnosticSession) => {
    const csv = [
      ['Timestamp', 'Direction', 'Data', 'Description', 'Duration (ms)', 'Status'],
      ...session.commands.map(cmd => [
        cmd.timestamp.toISOString(),
        cmd.direction.toUpperCase(),
        cmd.data,
        cmd.description,
        cmd.duration?.toString() || '',
        cmd.status
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${session.name.replace(/\s+/g, '_')}_${session.id}.csv`;
    a.click();
  };

  const filteredSessions = sessions.filter(session =>
    session.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    session.vehicle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    session.module.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getDirectionBadge = (direction: 'tx' | 'rx') => {
    return direction === 'tx' ? (
      <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
        TX →
      </Badge>
    ) : (
      <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
        ← RX
      </Badge>
    );
  };

  const getStatusIcon = (status: UDSCommand['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <BackButton />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
            Diagnostic Session Recording
          </h1>
          <p className="text-muted-foreground mt-2">
            Record, replay, and share diagnostic sessions for learning and troubleshooting
          </p>
        </div>
        {!isRecording ? (
          <Button onClick={startRecording} size="lg">
            <Play className="mr-2 h-5 w-5" />
            Start Recording
          </Button>
        ) : (
          <Button onClick={stopRecording} variant="destructive" size="lg">
            <Square className="mr-2 h-5 w-5" />
            Stop Recording
          </Button>
        )}
      </div>

      {/* Current Recording */}
      {isRecording && currentSession && (
        <Card className="p-6 border-2 border-red-500 animate-pulse">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-3 w-3 rounded-full bg-red-500 animate-pulse" />
                <h2 className="text-xl font-semibold">Recording in Progress</h2>
              </div>
              <Badge variant="destructive">LIVE</Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Vehicle</p>
                <p className="font-semibold">{currentSession.vehicle}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Module</p>
                <p className="font-semibold">{currentSession.module}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Commands Recorded</p>
                <p className="font-semibold">{currentSession.commands.length}</p>
              </div>
            </div>

            <Separator />

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {currentSession.commands.map((cmd, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg font-mono text-sm"
                >
                  {getDirectionBadge(cmd.direction)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{cmd.data}</span>
                      <span className="text-xs text-muted-foreground">
                        {cmd.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{cmd.description}</p>
                  </div>
                  {getStatusIcon(cmd.status)}
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* Search and Filter */}
      {sessions.length > 0 && (
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Label htmlFor="search">Search Sessions</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search by name, vehicle, or module..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Session List */}
      {filteredSessions.length > 0 ? (
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Recorded Sessions</h2>
          {filteredSessions.map((session) => (
            <Card key={session.id} className="p-6 hover:shadow-lg transition-shadow">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-semibold">{session.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {session.vehicle} • {session.module}
                    </p>
                  </div>
                  <Badge variant={session.status === 'completed' ? 'default' : 'destructive'}>
                    {session.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Start Time</p>
                    <p className="text-sm font-mono">{session.startTime.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="text-sm font-mono">
                      {session.endTime
                        ? `${((session.endTime.getTime() - session.startTime.getTime()) / 1000).toFixed(2)}s`
                        : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Commands</p>
                    <p className="text-sm font-mono">{session.commands.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Success Rate</p>
                    <p className="text-sm font-mono">
                      {((session.commands.filter(c => c.status === 'success').length / session.commands.length) * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>

                <Separator />

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedSession(selectedSession?.id === session.id ? null : session)}
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    {selectedSession?.id === session.id ? 'Hide' : 'View'} Commands
                  </Button>
                  <Button variant="outline" onClick={() => exportSession(session)}>
                    <Download className="mr-2 h-4 w-4" />
                    Export JSON
                  </Button>
                  <Button variant="outline" onClick={() => exportSessionCSV(session)}>
                    <FileText className="mr-2 h-4 w-4" />
                    Export CSV
                  </Button>
                  <Button variant="outline">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>

                {/* Command Details */}
                {selectedSession?.id === session.id && (
                  <div className="mt-4 space-y-2 border rounded-lg p-4 bg-muted/50">
                    <h4 className="font-semibold mb-2">UDS Commands</h4>
                    {session.commands.map((cmd, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-3 p-3 bg-background rounded-lg font-mono text-sm"
                      >
                        {getDirectionBadge(cmd.direction)}
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold">{cmd.data}</span>
                            <div className="flex items-center gap-2">
                              {cmd.duration && (
                                <span className="text-xs text-muted-foreground">
                                  {cmd.duration}ms
                                </span>
                              )}
                              <span className="text-xs text-muted-foreground">
                                {cmd.timestamp.toLocaleTimeString()}
                              </span>
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{cmd.description}</p>
                        </div>
                        {getStatusIcon(cmd.status)}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-12 text-center">
          <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No Sessions Recorded</h3>
          <p className="text-muted-foreground mb-4">
            Start recording a diagnostic session to build your knowledge base
          </p>
          <Button onClick={startRecording}>
            <Play className="mr-2 h-4 w-4" />
            Start First Recording
          </Button>
        </Card>
      )}

      {/* Info Alert */}
      <Alert>
        <FileText className="h-4 w-4" />
        <AlertDescription>
          <strong>Pro Tip:</strong> Record successful diagnostic procedures to build institutional knowledge. 
          Share sessions with team members to help them learn from your experience. Export to JSON/CSV for analysis or integration with other tools.
        </AlertDescription>
      </Alert>
    </div>
  );
}
