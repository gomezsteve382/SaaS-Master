import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackButton } from "@/components/BackButton";
import { Loader2, Code2, Plus, X } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Streamdown } from 'streamdown';

export default function ReverseEngineeringAssistant() {
  const [dataType, setDataType] = useState<'algorithm' | 'protocol' | 'memory_structure' | 'can_messages'>('algorithm');
  const [samples, setSamples] = useState<string[]>(['']);
  const [description, setDescription] = useState('');
  const [analysis, setAnalysis] = useState('');

  const analyzeMutation = trpc.ai.reverseEngineer.useMutation();

  const addSample = () => {
    setSamples([...samples, '']);
  };

  const removeSample = (index: number) => {
    setSamples(samples.filter((_, i) => i !== index));
  };

  const updateSample = (index: number, value: string) => {
    const newSamples = [...samples];
    newSamples[index] = value;
    setSamples(newSamples);
  };

  const handleAnalyze = async () => {
    const validSamples = samples.filter(s => s.trim() !== '');
    if (validSamples.length === 0) {
      alert('Please provide at least one sample');
      return;
    }

    try {
      const response = await analyzeMutation.mutateAsync({
        dataType,
        samples: validSamples,
        description: description || undefined
      });
      setAnalysis(typeof response.analysis === 'string' ? response.analysis : JSON.stringify(response.analysis));
    } catch (error) {
      console.error('Analysis failed:', error);
      alert('Analysis failed. Please try again.');
    }
  };

  return (
    <div className="container mx-auto py-8">
      <BackButton />
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Code2 className="w-10 h-10 text-primary" />
          AI Reverse Engineering Assistant
        </h1>
        <p className="text-muted-foreground">
          Analyze unknown algorithms, protocols, memory structures, and CAN messages with AI-powered pattern recognition.
        </p>
      </div>

      <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
        <AlertDescription>
          <strong>How it works:</strong> Provide samples of unknown data (seed-key pairs, CAN messages, memory dumps, protocol traces). 
          The AI analyzes patterns, identifies structures, and suggests hypotheses about functionality. 
          Useful for reverse engineering aftermarket modules or unknown dealer tools.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Data Samples</CardTitle>
            <CardDescription>Provide samples for analysis</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="data-type">Data Type *</Label>
              <Select value={dataType} onValueChange={(v) => setDataType(v as any)}>
                <SelectTrigger id="data-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="algorithm">Seed-Key Algorithm</SelectItem>
                  <SelectItem value="protocol">Communication Protocol</SelectItem>
                  <SelectItem value="memory_structure">Memory Structure</SelectItem>
                  <SelectItem value="can_messages">CAN Messages</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Aftermarket BCM, unknown seed-key algorithm, responds to 0x27..."
                rows={3}
              />
            </div>

            <div>
              <Label>Samples * (minimum 3 recommended)</Label>
              <div className="space-y-2 mt-2">
                {samples.map((sample, i) => (
                  <div key={i} className="flex gap-2">
                    <Textarea
                      value={sample}
                      onChange={(e) => updateSample(i, e.target.value)}
                      placeholder={
                        dataType === 'algorithm' ? 'Seed: 0x1234 → Key: 0x5678' :
                        dataType === 'protocol' ? 'TX: 7E0 03 22 F1 8C → RX: 7E8 05 62 F1 8C AA BB' :
                        dataType === 'memory_structure' ? '0x0100: 31 43 33 43 44 46 42 42 (VIN prefix)' :
                        '0x123: 8 bytes: 01 02 03 04 05 06 07 08'
                      }
                      rows={2}
                      className="flex-1 font-mono text-xs"
                    />
                    {samples.length > 1 && (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => removeSample(i)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={addSample}
                className="mt-2 w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Sample
              </Button>
            </div>

            <Button 
              onClick={handleAnalyze} 
              disabled={analyzeMutation.isPending || samples.every(s => !s.trim())}
              className="w-full"
            >
              {analyzeMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Code2 className="w-4 h-4 mr-2" />
                  Reverse Engineer
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>Analysis Results</CardTitle>
            <CardDescription>AI-powered pattern recognition</CardDescription>
          </CardHeader>
          <CardContent>
            {analysis ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{analysis}</Streamdown>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Code2 className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Provide samples to begin analysis</p>
                <p className="text-xs mt-2">
                  More samples = better analysis
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Analysis Capabilities */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>What the AI Can Identify</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div>
              <h3 className="font-semibold mb-2">🔐 Algorithms</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Mathematical operations</li>
                <li>• Constants and multipliers</li>
                <li>• XOR/shift patterns</li>
                <li>• Encryption methods</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">📡 Protocols</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Message structure</li>
                <li>• Command/response pairs</li>
                <li>• Checksums/CRCs</li>
                <li>• Timing patterns</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">💾 Memory</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Data regions</li>
                <li>• VIN locations</li>
                <li>• Security bytes</li>
                <li>• Padding patterns</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🚗 CAN Bus</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Message IDs</li>
                <li>• Data field meanings</li>
                <li>• Periodic messages</li>
                <li>• Event triggers</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Example Use Cases */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Example Use Cases</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="font-semibold mb-2">Aftermarket Modules</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Unknown BCM from salvage yard</li>
                <li>• Aftermarket ECM tuning box</li>
                <li>• Third-party alarm system</li>
                <li>• Custom CAN gateway</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Unknown Tools</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Foreign market diagnostic tool</li>
                <li>• Dealer-only programming device</li>
                <li>• Proprietary J2534 adapter</li>
                <li>• Custom flash programmer</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
