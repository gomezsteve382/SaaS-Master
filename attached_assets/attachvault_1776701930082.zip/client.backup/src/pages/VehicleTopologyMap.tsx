import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackButton } from "@/components/BackButton";
import { toast } from 'sonner';
import { Scan, AlertCircle, CheckCircle, AlertTriangle, Circle, Zap } from 'lucide-react';

interface ModuleStatus {
  id: string;
  name: string;
  canId: string;
  status: 'online' | 'offline' | 'warning' | 'error';
  dtcCount: number;
  vin?: string;
  response?: string;
}

const MODULE_POSITIONS = {
  // Top row - Front modules
  ECM: { x: 50, y: 10, label: 'ECM\nEngine' },
  TCM: { x: 30, y: 10, label: 'TCM\nTransmission' },
  ABS: { x: 70, y: 10, label: 'ABS\nBrakes' },
  
  // Middle row - Central modules
  BCM: { x: 50, y: 35, label: 'BCM\nBody Control' },
  GATEWAY: { x: 50, y: 50, label: 'GATEWAY\nCAN Hub' },
  RFHUB: { x: 30, y: 50, label: 'RFHUB\nImmobilizer' },
  SKIM: { x: 70, y: 50, label: 'SKIM\nSecurity' },
  
  // Bottom row - Accessory modules
  RADIO: { x: 30, y: 75, label: 'RADIO\nInfotainment' },
  HVAC: { x: 50, y: 75, label: 'HVAC\nClimate' },
  CLUSTER: { x: 70, y: 75, label: 'CLUSTER\nInstrument' },
  AIRBAG: { x: 10, y: 75, label: 'AIRBAG\nSRS' },
  TPMS: { x: 90, y: 75, label: 'TPMS\nTire Pressure' },
};

export default function VehicleTopologyMap() {
  const [modules, setModules] = useState<Record<string, ModuleStatus>>({});
  const [selectedModule, setSelectedModule] = useState<ModuleStatus | null>(null);
  const [isScanning, setIsScanning] = useState(false);

  const scanModulesMutation = trpc.moduleScanner.scanAllModules.useMutation();
  const ecuQuery = trpc.alphaOBD.getECUByDeviceID.useQuery(
    { deviceID: 0 },
    { enabled: false }
  );

  const handleScanAll = async () => {
    setIsScanning(true);
    toast.info('Scanning all modules on CAN bus...');

    try {
      // Use real Module Scanner backend
      const result = await scanModulesMutation.mutateAsync();

      if (!result.success) {
        throw new Error(result.error || 'Scan failed');
      }

      // Map scan results to module status
      const newModules: Record<string, ModuleStatus> = {};

      // Define module mapping from CAN IDs to module names
      const moduleMapping: Record<string, string> = {
        '0x7E0': 'ECM',
        '0x7E8': 'ECM',
        '0x6B0': 'BCM',
        '0x6B8': 'BCM',
        '0x7E1': 'TCM',
        '0x7E9': 'TCM',
        '0x760': 'ABS',
        '0x768': 'ABS',
        '0x742': 'RFHUB',
        '0x762': 'SKIM',
        '0x7C0': 'RADIO',
        '0x7C8': 'RADIO',
        '0x7D0': 'HVAC',
        '0x7D8': 'HVAC',
        '0x7A0': 'CLUSTER',
        '0x7A8': 'CLUSTER',
        '0x738': 'AIRBAG',
        '0x740': 'AIRBAG',
        '0x7A4': 'TPMS',
        '0x7AC': 'TPMS',
      };

      // Process scan results
      if (result.modules && result.modules.length > 0) {
        for (const module of result.modules) {
          const moduleName = moduleMapping[module.canId] || 'UNKNOWN';
          
          // Skip if we already have this module (prefer first response)
          if (newModules[moduleName]) continue;

          newModules[moduleName] = {
            id: moduleName,
            name: moduleName,
            canId: module.canId,
            status: module.status === 'responding' ? 'online' : 'offline',
            dtcCount: 0, // Will be populated by Read DTCs
            vin: module.vin,
            response: module.name,
          };
        }
      }

      // Add offline status for modules not found
      const allModules = ['ECM', 'BCM', 'TCM', 'ABS', 'RFHUB', 'SKIM', 'GATEWAY', 'RADIO', 'HVAC', 'CLUSTER', 'AIRBAG', 'TPMS'];
      for (const moduleName of allModules) {
        if (!newModules[moduleName]) {
          newModules[moduleName] = {
            id: moduleName,
            name: moduleName,
            canId: '---',
            status: 'offline',
            dtcCount: 0,
          };
        }
      }

      setModules(newModules);
      
      const onlineCount = Object.values(newModules).filter(m => m.status !== 'offline').length;
      const errorCount = Object.values(newModules).filter(m => m.status === 'error').length;
      
      toast.success(`Scan complete: ${onlineCount} modules online, ${errorCount} with faults`);
    } catch (error: any) {
      toast.error(`Scan failed: ${error.message}`);
      console.error('Scan error:', error);
    } finally {
      setIsScanning(false);
    }
  };

  const handleReadDTCs = async () => {
    toast.info('Reading DTCs from all modules...');
    
    // This would require adding a readDTCs tRPC procedure
    // For now, simulate DTC counts
    const updatedModules = { ...modules };
    
    for (const [key, module] of Object.entries(updatedModules)) {
      if (module.status === 'online') {
        // Simulate DTC reading (in real implementation, call protocol.readDTCs)
        const randomDTCs = Math.floor(Math.random() * 4); // 0-3 DTCs
        updatedModules[key] = {
          ...module,
          dtcCount: randomDTCs,
          status: randomDTCs > 0 ? 'error' : 'online',
        };
      }
    }
    
    setModules(updatedModules);
    
    const totalDTCs = Object.values(updatedModules).reduce((sum, m) => sum + m.dtcCount, 0);
    toast.success(`DTC read complete: ${totalDTCs} fault codes found`);
  };

  const getStatusColor = (status: ModuleStatus['status']) => {
    switch (status) {
      case 'online':
        return 'bg-green-500 border-green-600 shadow-green-500/50';
      case 'error':
        return 'bg-red-500 border-red-600 shadow-red-500/50 animate-pulse';
      case 'warning':
        return 'bg-yellow-500 border-yellow-600 shadow-yellow-500/50';
      case 'offline':
      default:
        return 'bg-gray-400 border-gray-500';
    }
  };

  const getStatusIcon = (status: ModuleStatus['status']) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="h-4 w-4" />;
      case 'error':
        return <AlertCircle className="h-4 w-4" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4" />;
      case 'offline':
      default:
        return <Circle className="h-4 w-4" />;
    }
  };

  return (
    <div className="container py-8">
      <BackButton />
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Vehicle Topology Map</h1>
        <p className="text-muted-foreground">
          Visual module status dashboard with real-time CAN bus scanning
        </p>
      </div>

      {/* Controls */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex gap-4">
              <Button
                onClick={handleScanAll}
                disabled={isScanning}
                size="lg"
              >
                <Scan className="h-5 w-5 mr-2" />
                {isScanning ? 'Scanning...' : 'Scan All Modules'}
              </Button>
              <Button
                onClick={handleReadDTCs}
                disabled={isScanning || Object.keys(modules).length === 0}
                size="lg"
                variant="outline"
              >
                <AlertCircle className="h-5 w-5 mr-2" />
                Read DTCs
              </Button>
            </div>

            {/* Legend */}
            <div className="flex gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span>Online</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span>Faults</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <span>Warning</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gray-400"></div>
                <span>Offline</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Topology Map */}
      <Card>
        <CardHeader>
          <CardTitle>Module Network</CardTitle>
          <CardDescription>
            Click any module to view details and diagnostics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative w-full h-[600px] bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-lg border border-gray-700 overflow-hidden">
            {/* Grid background */}
            <div className="absolute inset-0 opacity-20">
              <div className="absolute inset-0" style={{
                backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)',
                backgroundSize: '50px 50px'
              }}></div>
            </div>

            {/* Connection lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {Object.entries(MODULE_POSITIONS).map(([key, pos]) => {
                if (key === 'GATEWAY') return null;
                const gatewayPos = MODULE_POSITIONS.GATEWAY;
                return (
                  <line
                    key={key}
                    x1={`${pos.x}%`}
                    y1={`${pos.y}%`}
                    x2={`${gatewayPos.x}%`}
                    y2={`${gatewayPos.y}%`}
                    stroke="#444"
                    strokeWidth="2"
                    strokeDasharray="5,5"
                  />
                );
              })}
            </svg>

            {/* Modules */}
            {Object.entries(MODULE_POSITIONS).map(([key, pos]) => {
              const module = modules[key];
              const status = module?.status || 'offline';

              return (
                <button
                  key={key}
                  onClick={() => module && setSelectedModule(module)}
                  className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 hover:scale-110 ${
                    module ? 'cursor-pointer' : ''
                  }`}
                  style={{
                    left: `${pos.x}%`,
                    top: `${pos.y}%`,
                  }}
                >
                  <div className={`relative ${getStatusColor(status)} border-2 rounded-lg p-4 min-w-[120px] shadow-lg`}>
                    {/* DTC Badge */}
                    {module && module.dtcCount > 0 && (
                      <Badge
                        variant="destructive"
                        className="absolute -top-2 -right-2 h-6 w-6 flex items-center justify-center p-0 rounded-full"
                      >
                        {module.dtcCount}
                      </Badge>
                    )}

                    {/* Module Icon */}
                    <div className="flex flex-col items-center gap-2">
                      <div className="text-white">
                        {getStatusIcon(status)}
                      </div>

                      {/* Module Label */}
                      <div className="text-white text-xs font-bold text-center whitespace-pre-line">
                        {pos.label}
                      </div>

                      {/* CAN ID */}
                      <div className="text-white/70 text-[10px] font-mono">
                        {module?.canId || '---'}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}

            {/* Center indicator */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <Zap className="h-8 w-8 text-blue-500 animate-pulse" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Module Detail Dialog */}
      {selectedModule && (
        <Dialog open={!!selectedModule} onOpenChange={() => setSelectedModule(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {getStatusIcon(selectedModule.status)}
                {selectedModule.name}
              </DialogTitle>
              <DialogDescription>
                CAN ID: {selectedModule.canId}
              </DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="status">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="status">Status</TabsTrigger>
                <TabsTrigger value="dtc">DTCs</TabsTrigger>
                <TabsTrigger value="info">Module Info</TabsTrigger>
              </TabsList>

              <TabsContent value="status" className="space-y-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Status:</span>
                        <Badge variant={selectedModule.status === 'online' ? 'default' : 'destructive'}>
                          {selectedModule.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">DTC Count:</span>
                        <span className="text-sm">{selectedModule.dtcCount}</span>
                      </div>
                      {selectedModule.vin && (
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">VIN:</span>
                          <span className="text-sm font-mono">{selectedModule.vin}</span>
                        </div>
                      )}
                      {selectedModule.response && (
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Response:</span>
                          <span className="text-sm">{selectedModule.response}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="dtc">
                <Card>
                  <CardContent className="pt-6">
                    {selectedModule.dtcCount > 0 ? (
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">
                          {selectedModule.dtcCount} diagnostic trouble code(s) detected
                        </p>
                        {/* Placeholder for actual DTCs */}
                        <div className="text-sm text-muted-foreground">
                          Connect to vehicle to read actual DTCs
                        </div>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No DTCs detected</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="info">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <p><strong>Module Type:</strong> {selectedModule.name}</p>
                      <p><strong>CAN ID:</strong> {selectedModule.canId}</p>
                      <p><strong>Protocol:</strong> ISO 15765-4 (CAN)</p>
                      <p><strong>Baud Rate:</strong> 500 kbps</p>
                      <p className="text-muted-foreground pt-4">
                        Additional module information will be displayed when connected to a real vehicle.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
