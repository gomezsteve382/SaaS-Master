import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BackButton } from "@/components/BackButton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Shield, Download, Upload, CheckCircle2, XCircle, AlertTriangle,
  Loader2, Database, FileJson, Settings, Lock, Unlock
} from "lucide-react";
import { toast } from "sonner";

interface DIDData {
  did: string;
  name: string;
  value: string;
  status: "pending" | "reading" | "writing" | "success" | "error";
  errorMessage?: string;
}

interface SGWModule {
  id: string;
  name: string;
  canId: string;
  authorized: boolean;
}

export default function GatewayCloneTool() {
  const [sourceData, setSourceData] = useState<DIDData[]>([]);
  const [isReading, setIsReading] = useState(false);
  const [isWriting, setIsWriting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [sgwEnabled, setSgwEnabled] = useState(false);
  const [sgwModules, setSgwModules] = useState<SGWModule[]>([
    { id: "bcm", name: "Body Control Module", canId: "0x6B0", authorized: true },
    { id: "ecm", name: "Engine Control Module", canId: "0x7E0", authorized: true },
    { id: "tcm", name: "Transmission Control", canId: "0x7E1", authorized: true },
    { id: "abs", name: "ABS Module", canId: "0x760", authorized: true },
    { id: "skim", name: "Security Module", canId: "0x728", authorized: false },
  ]);

  const criticalDIDs = [
    { did: "F190", name: "VIN", critical: true },
    { did: "F187", name: "Vehicle Configuration", critical: true },
    { did: "F18C", name: "ECU Serial Number", critical: true },
    { did: "F199", name: "Programming Date", critical: false },
    { did: "F1B0", name: "SGW Authorization List", critical: true },
    { did: "F1B1", name: "SGW Mode", critical: true },
    { did: "F194", name: "Software Number", critical: false },
    { did: "F195", name: "Software Version", critical: false },
  ];

  const handleReadSource = async () => {
    setIsReading(true);
    setProgress(0);

    const dids: DIDData[] = criticalDIDs.map(d => ({
      did: d.did,
      name: d.name,
      value: "",
      status: "pending" as const
    }));
    setSourceData(dids);

    try {
      for (let i = 0; i < dids.length; i++) {
        dids[i].status = "reading";
        setSourceData([...dids]);

        // Simulate reading DID
        await new Promise(resolve => setTimeout(resolve, 800));

        // Mock data
        if (dids[i].did === "F190") {
          dids[i].value = "2C3CDXKT3FH796320";
        } else if (dids[i].did === "F1B1") {
          dids[i].value = sgwEnabled ? "01" : "00";
        } else {
          dids[i].value = "AA BB CC DD";
        }

        dids[i].status = "success";
        setProgress(((i + 1) / dids.length) * 100);
        setSourceData([...dids]);
      }

      toast.success("Successfully read all DIDs from source gateway");
    } catch (error) {
      toast.error("Failed to read from source gateway");
    } finally {
      setIsReading(false);
    }
  };

  const handleWriteTarget = async () => {
    if (sourceData.length === 0) {
      toast.error("No source data available. Read from source first.");
      return;
    }

    setIsWriting(true);
    setProgress(0);

    const dids = [...sourceData].map(d => ({ ...d, status: "pending" as DIDData["status"] }));
    setSourceData(dids);

    try {
      for (let i = 0; i < dids.length; i++) {
        dids[i].status = "writing";
        setSourceData([...dids]);

        // Simulate writing DID
        await new Promise(resolve => setTimeout(resolve, 1000));

        dids[i].status = "success";
        setProgress(((i + 1) / dids.length) * 100);
        setSourceData([...dids]);
      }

      toast.success("Successfully wrote all DIDs to target gateway");
    } catch (error) {
      toast.error("Failed to write to target gateway");
    } finally {
      setIsWriting(false);
    }
  };

  const handleExportBackup = () => {
    if (sourceData.length === 0) {
      toast.error("No data to export");
      return;
    }

    const backup = {
      timestamp: new Date().toISOString(),
      module: "Gateway (GPEC4)",
      dids: sourceData.map(d => ({
        did: d.did,
        name: d.name,
        value: d.value
      })),
      sgw: {
        enabled: sgwEnabled,
        modules: sgwModules
      }
    };

    const json = JSON.stringify(backup, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `gateway_backup_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success("Backup exported successfully");
  };

  const handleImportBackup = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const backup = JSON.parse(event.target?.result as string);
          setSourceData(backup.dids.map((d: any) => ({
            ...d,
            status: "success"
          })));
          if (backup.sgw) {
            setSgwEnabled(backup.sgw.enabled);
            setSgwModules(backup.sgw.modules);
          }
          toast.success("Backup imported successfully");
        } catch (error) {
          toast.error("Invalid backup file");
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const toggleSGW = async () => {
    setSgwEnabled(!sgwEnabled);
    toast.success(`Security Gateway ${!sgwEnabled ? "enabled" : "disabled"}`);
  };

  const toggleModuleAuth = (moduleId: string) => {
    setSgwModules(sgwModules.map(m =>
      m.id === moduleId ? { ...m, authorized: !m.authorized } : m
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <BackButton />

        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="p-4 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl">
            <Shield className="h-10 w-10" />
          </div>
          <div>
            <h1 className="text-4xl font-black tracking-tight">GATEWAY CLONING TOOL</h1>
            <p className="text-gray-400 text-lg">
              GPEC4 Gateway with Security Gateway (SGW) Management
            </p>
          </div>
        </div>

        {/* Warning */}
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Critical: SGW Lockout Risk</AlertTitle>
          <AlertDescription>
            Incorrect SGW configuration can permanently lock out dealer tools. Always backup before modifying SGW settings.
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="clone" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="clone">Clone Gateway</TabsTrigger>
            <TabsTrigger value="sgw">SGW Manager</TabsTrigger>
          </TabsList>

          {/* Clone Tab */}
          <TabsContent value="clone" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Control Panel */}
              <Card>
                <CardHeader>
                  <CardTitle>Operations</CardTitle>
                  <CardDescription>Read from source, write to target</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    onClick={handleReadSource}
                    disabled={isReading || isWriting}
                    className="w-full gap-2"
                  >
                    {isReading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Reading...
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4" />
                        Read Source Gateway
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={handleWriteTarget}
                    disabled={isWriting || isReading || sourceData.length === 0}
                    variant="destructive"
                    className="w-full gap-2"
                  >
                    {isWriting ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Writing...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4" />
                        Write Target Gateway
                      </>
                    )}
                  </Button>

                  <div className="border-t border-gray-700 pt-3 space-y-3">
                    <Button
                      onClick={handleExportBackup}
                      disabled={sourceData.length === 0}
                      variant="outline"
                      className="w-full gap-2"
                    >
                      <FileJson className="h-4 w-4" />
                      Export Backup
                    </Button>

                    <Button
                      onClick={handleImportBackup}
                      variant="outline"
                      className="w-full gap-2"
                    >
                      <Upload className="h-4 w-4" />
                      Import Backup
                    </Button>
                  </div>

                  {(isReading || isWriting) && (
                    <div className="space-y-2">
                      <Progress value={progress} />
                      <p className="text-xs text-center text-gray-400">
                        {Math.round(progress)}%
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* DID Status */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>DID Status</CardTitle>
                  <CardDescription>
                    {sourceData.length === 0
                      ? "No data loaded"
                      : `${sourceData.filter(d => d.status === "success").length}/${sourceData.length} DIDs complete`}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    {sourceData.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-gray-500">
                        <Database className="h-12 w-12 mb-2 opacity-50" />
                        <p>Click "Read Source Gateway" to begin</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {sourceData.map((did, idx) => (
                          <div
                            key={idx}
                            className={`p-3 rounded border ${
                              did.status === "success"
                                ? "bg-green-500/10 border-green-500/30"
                                : did.status === "error"
                                ? "bg-red-500/10 border-red-500/30"
                                : did.status === "reading" || did.status === "writing"
                                ? "bg-blue-500/10 border-blue-500/30"
                                : "bg-gray-500/10 border-gray-500/30"
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <span className="font-mono font-semibold">{did.did}</span>
                                <span className="text-sm text-gray-400">{did.name}</span>
                                {criticalDIDs.find(d => d.did === did.did)?.critical && (
                                  <Badge variant="destructive" className="text-xs">CRITICAL</Badge>
                                )}
                              </div>
                              {did.status === "success" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                              {did.status === "error" && <XCircle className="h-4 w-4 text-red-500" />}
                              {(did.status === "reading" || did.status === "writing") && (
                                <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
                              )}
                            </div>
                            {did.value && (
                              <p className="font-mono text-sm mt-2 text-gray-300">{did.value}</p>
                            )}
                            {did.errorMessage && (
                              <p className="text-sm text-red-400 mt-2">{did.errorMessage}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* SGW Manager Tab */}
          <TabsContent value="sgw" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* SGW Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Security Gateway Status
                    <Button
                      size="sm"
                      variant={sgwEnabled ? "destructive" : "default"}
                      onClick={toggleSGW}
                      className="gap-2"
                    >
                      {sgwEnabled ? (
                        <>
                          <Lock className="h-4 w-4" />
                          Enabled
                        </>
                      ) : (
                        <>
                          <Unlock className="h-4 w-4" />
                          Disabled
                        </>
                      )}
                    </Button>
                  </CardTitle>
                  <CardDescription>
                    SGW controls which modules can be reprogrammed
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Alert variant={sgwEnabled ? "destructive" : "default"}>
                    <Settings className="h-4 w-4" />
                    <AlertTitle>
                      {sgwEnabled ? "SGW Active" : "SGW Inactive"}
                    </AlertTitle>
                    <AlertDescription>
                      {sgwEnabled
                        ? "Only authorized modules can be reprogrammed. Dealer tools may be restricted."
                        : "All modules can be freely reprogrammed. This is the normal state for bench work."}
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>

              {/* Module Authorization List */}
              <Card>
                <CardHeader>
                  <CardTitle>Authorized Modules</CardTitle>
                  <CardDescription>
                    Toggle module authorization for SGW
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px]">
                    <div className="space-y-2">
                      {sgwModules.map((module) => (
                        <div
                          key={module.id}
                          className={`p-3 rounded border ${
                            module.authorized
                              ? "bg-green-500/10 border-green-500/30"
                              : "bg-red-500/10 border-red-500/30"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-semibold">{module.name}</p>
                              <p className="text-sm text-gray-400 font-mono">{module.canId}</p>
                            </div>
                            <Button
                              size="sm"
                              variant={module.authorized ? "default" : "outline"}
                              onClick={() => toggleModuleAuth(module.id)}
                            >
                              {module.authorized ? (
                                <>
                                  <CheckCircle2 className="h-4 w-4 mr-1" />
                                  Authorized
                                </>
                              ) : (
                                <>
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Blocked
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>

            {/* SGW Information */}
            <Card>
              <CardHeader>
                <CardTitle>Security Gateway Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-semibold mb-2">When to Enable SGW:</h3>
                    <ul className="text-sm text-gray-400 space-y-1">
                      <li>• Production vehicle configuration</li>
                      <li>• Dealer-level security required</li>
                      <li>• Prevent unauthorized reprogramming</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">When to Disable SGW:</h3>
                    <ul className="text-sm text-gray-400 space-y-1">
                      <li>• Bench testing and development</li>
                      <li>• Module cloning operations</li>
                      <li>• Troubleshooting communication issues</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
