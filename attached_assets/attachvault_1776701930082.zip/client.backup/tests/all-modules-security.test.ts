/**
 * ALL MODULES Security Algorithm Test Suite
 * 
 * Tests the complete VIN programming code path for every module type:
 * - BCM: ROL5+XOR (2-byte seed → 2-byte key)
 * - ECM/PCM: Shift-XOR (4-byte seed → 4-byte key)
 * - TCM: Shift-XOR (4-byte seed → 4-byte key)
 * - RFHUB: XTEA (4-byte seed → 4-byte key)
 * - ABS: ROL5+XOR (2-byte seed → 2-byte key)
 * - SGW: Atlantis AES-128 (4-byte seed + 5-byte CSN → 5-byte key)
 */

// @ts-nocheck - Using node test runner
import { describe, it } from 'node:test';
import assert from 'node:assert';
const expect = (val: any) => ({
  toBe: (expected: any) => assert.strictEqual(val, expected),
  toBeDefined: () => assert.ok(val !== undefined),
  toEqual: (expected: any) => assert.deepStrictEqual(val, expected),
  toContain: (str: string) => assert.ok(String(val).includes(str))
});
import { 
  calculateSecurityKey, 
  hexToBytes, 
  bytesToHex,
  UDS,
  parseUDSResponse,
  type KeyCalculationRequest 
} from '../../shared/security-resolver';
import { 
  MODULE_DATABASE, 
  getSecurityConfig, 
  getVINConfig,
  getVINProgrammableModules,
  requiresCSN,
  supportsVINWrite 
} from '../src/lib/module-database';

describe('Module Security Configurations', () => {
  
  it('BCM has correct security config', () => {
    const bcm = MODULE_DATABASE.find(m => m.code === 'BCM');
    expect(bcm).toBeDefined();
    expect(bcm!.security?.algorithm).toBe('rol5-xor');
    expect(bcm!.security?.seedLength).toBe(2);
    expect(bcm!.security?.keyLength).toBe(2);
    expect(bcm!.vinConfig?.writable).toBe(true);
  });

  it('ECM has correct security config', () => {
    const ecm = MODULE_DATABASE.find(m => m.code === 'ECM');
    expect(ecm).toBeDefined();
    expect(ecm!.security?.algorithm).toBe('shift-xor');
    expect(ecm!.security?.seedLength).toBe(4);
    expect(ecm!.security?.keyLength).toBe(4);
    expect(ecm!.security?.constant).toBe(0x8A3C71);
  });

  it('TCM has correct security config', () => {
    const tcm = MODULE_DATABASE.find(m => m.code === 'TCM');
    expect(tcm).toBeDefined();
    expect(tcm!.security?.algorithm).toBe('shift-xor');
    expect(tcm!.security?.constant).toBe(0x6E4B92);
  });

  it('RFHUB has correct security config', () => {
    const rfhub = MODULE_DATABASE.find(m => m.code === 'RFHUB');
    expect(rfhub).toBeDefined();
    expect(rfhub!.security?.algorithm).toBe('rol5-xor');
    expect(rfhub!.security?.seedLength).toBe(2);
    expect(rfhub!.vinConfig?.writable).toBe(true); // Technically writable but OTP - use with caution!
    expect(rfhub!.otpInfo?.riskLevel).toBe('danger');
  });

  it('ABS has correct security config', () => {
    const abs = MODULE_DATABASE.find(m => m.code === 'ABS');
    expect(abs).toBeDefined();
    expect(abs!.security?.algorithm).toBe('shift-xor');
    expect(abs!.security?.seedLength).toBe(4);
    expect(abs!.security?.constant).toBe(0x4B129F);
  });

  it('SGW has correct Atlantis security config', () => {
    const sgw = MODULE_DATABASE.find(m => m.code === 'SGW');
    expect(sgw).toBeDefined();
    expect(sgw!.security?.algorithm).toBe('atlantis');
    expect(sgw!.security?.requiresCSN).toBe(true);
    expect(sgw!.security?.seedLength).toBe(4); // 4-byte seed
    expect(sgw!.security?.keyLength).toBe(5);  // 5-byte key output
    expect(sgw!.vinConfig?.writable).toBe(false); // OTP!
  });

  it('PCM is alias for ECM with same security', () => {
    const pcm = MODULE_DATABASE.find(m => m.code === 'PCM');
    expect(pcm).toBeDefined();
    expect(pcm!.security?.algorithm).toBe('shift-xor');
    expect(pcm!.security?.constant).toBe(0x8A3C71);
  });
});

describe('ROL5+XOR Key Calculation (BCM, ABS)', () => {
  
  it('BCM: calculates correct key for Level 1', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'BCM',
      algorithm: 'rol5-xor',
      seed: hexToBytes('A5 3C'),
      securityLevel: 0x01
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key).toBeDefined();
    expect(result.key!.length).toBe(2);
    console.log(`BCM L1: Seed A5 3C → Key ${result.keyHex}`);
  });

  it('BCM: calculates correct key for Level 3', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'BCM',
      algorithm: 'rol5-xor',
      seed: hexToBytes('12 34'),
      securityLevel: 0x03
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key!.length).toBe(2);
    console.log(`BCM L3: Seed 12 34 → Key ${result.keyHex}`);
  });

  it('ABS: is configured for Shift-XOR', () => {
    const abs = MODULE_DATABASE.find(m => m.code === 'ABS');
    expect(abs!.security?.algorithm).toBe('shift-xor');
    expect(abs!.security?.constant).toBe(0x4B129F);
    expect(abs!.security?.seedLength).toBe(4);
    console.log(`ABS configured: Shift-XOR with constant 0x${abs!.security!.constant!.toString(16).toUpperCase()}`);
  });
});

describe('Shift-XOR Key Calculation (ECM, TCM, PCM)', () => {
  
  it('ECM: calculates correct key with constant 0x8A3C71', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'ECM',
      algorithm: 'shift-xor',
      seed: hexToBytes('12 34 56 78'),
      securityLevel: 0x01,
      constant: 0x8A3C71,
      iterations: 3
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key!.length).toBe(4);
    console.log(`ECM: Seed 12345678 → Key ${result.keyHex}`);
  });

  it('TCM: calculates correct key with constant 0x6E4B92', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'TCM',
      algorithm: 'shift-xor',
      seed: hexToBytes('AA BB CC DD'),
      securityLevel: 0x01,
      constant: 0x6E4B92,
      iterations: 5
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key!.length).toBe(4);
    console.log(`TCM: Seed AABBCCDD → Key ${result.keyHex}`);
  });

  it('Shift-XOR: requires constant', () => {
    const result = calculateSecurityKey({
      moduleCode: 'ECM',
      algorithm: 'shift-xor',
      seed: hexToBytes('12 34 56 78'),
      securityLevel: 0x01
      // Missing constant!
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain('constant');
  });
});

describe('RFHUB ROL5+XOR Key Calculation', () => {
  
  it('RFHUB: calculates ROL5 key for Level 1', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'RFHUB',
      algorithm: 'rol5-xor',
      seed: hexToBytes('DE AD'),
      securityLevel: 0x01
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key!.length).toBe(2);
    console.log(`RFHUB L1: Seed DEAD → Key ${result.keyHex}`);
  });

  it('RFHUB: calculates ROL5 key for Level 3', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'RFHUB',
      algorithm: 'rol5-xor',
      seed: hexToBytes('CA FE'),
      securityLevel: 0x03
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key!.length).toBe(2);
    console.log(`RFHUB L3: Seed CAFE → Key ${result.keyHex}`);
  });
});

describe('Atlantis AES Key Calculation (SGW)', () => {
  
  it('SGW: calculates Atlantis key with CSN', () => {
    const request: KeyCalculationRequest = {
      moduleCode: 'SGW',
      algorithm: 'atlantis',
      seed: hexToBytes('11 22 33 44'),         // 4-byte seed
      securityLevel: 0x01,
      csn: hexToBytes('AA BB CC DD EE')        // 5-byte CSN from DID F18C
    };
    const result = calculateSecurityKey(request);
    expect(result.success).toBe(true);
    expect(result.key!.length).toBe(5); // Atlantis outputs 5-byte key
    console.log(`SGW: Seed 11223344 + CSN AABBCCDDEE → Key ${result.keyHex}`);
  });

  it('SGW: fails without CSN', () => {
    const result = calculateSecurityKey({
      moduleCode: 'SGW',
      algorithm: 'atlantis',
      seed: hexToBytes('11 22 33 44'),
      securityLevel: 0x01
      // Missing CSN!
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain('CSN');
  });

  it('SGW: fails with wrong CSN length', () => {
    const result = calculateSecurityKey({
      moduleCode: 'SGW',
      algorithm: 'atlantis',
      seed: hexToBytes('11 22 33 44'),
      securityLevel: 0x01,
      csn: hexToBytes('AA BB CC DD')  // 4 bytes instead of 5
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain('5-byte CSN');
  });
});

describe('UDS Message Builders', () => {
  
  it('requestSeed builds correct message', () => {
    const msg = UDS.requestSeed(0x01);
    expect(bytesToHex(msg, '')).toBe('2701');
  });

  it('sendKey builds correct message with 2-byte key', () => {
    const key = hexToBytes('A5 3C');
    const msg = UDS.sendKey(0x01, key);
    expect(bytesToHex(msg, '')).toBe('2702A53C');
  });

  it('sendKey builds correct message with 4-byte key', () => {
    const key = hexToBytes('12 34 56 78');
    const msg = UDS.sendKey(0x03, key);
    expect(bytesToHex(msg, '')).toBe('270412345678');
  });

  it('readVIN builds correct message', () => {
    const msg = UDS.readVIN();
    expect(bytesToHex(msg, '')).toBe('22F190');
  });

  it('readCSN builds correct message', () => {
    const msg = UDS.readCSN();
    expect(bytesToHex(msg, '')).toBe('22F18C');
  });

  it('writeVIN builds correct message', () => {
    const vin = '2C3CDXHG4MH591631';
    const msg = UDS.writeVIN(vin);
    expect(msg[0]).toBe(0x2E);
    expect(msg[1]).toBe(0xF1);
    expect(msg[2]).toBe(0x90);
    expect(msg.length).toBe(20); // 3 header + 17 VIN
    const vinFromMsg = String.fromCharCode(...msg.slice(3));
    expect(vinFromMsg).toBe(vin);
  });

  it('programmingSession builds correct message', () => {
    const msg = UDS.programmingSession();
    expect(bytesToHex(msg, '')).toBe('1002');
  });

  it('testerPresent builds correct message', () => {
    const msg = UDS.testerPresent();
    expect(bytesToHex(msg, '')).toBe('3E00');
  });
});

describe('UDS Response Parser', () => {
  
  it('parses positive SecurityAccess response', () => {
    const response = hexToBytes('67 01 AB CD'); // Positive response with seed
    const result = parseUDSResponse(response);
    expect(result.positive).toBe(true);
    expect(result.service).toBe(0x27);
    expect(result.data!.length).toBe(3);
    expect(result.data![0]).toBe(0x01);
  });

  it('parses negative response with NRC', () => {
    const response = hexToBytes('7F 27 35'); // Security access denied - invalid key
    const result = parseUDSResponse(response);
    expect(result.positive).toBe(false);
    expect(result.nrc).toBe(0x35);
    expect(result.nrcDescription!.toLowerCase()).toContain('invalid');
  });

  it('parses exceededNumberOfAttempts NRC', () => {
    const response = hexToBytes('7F 27 36'); // Exceeded attempts
    const result = parseUDSResponse(response);
    expect(result.positive).toBe(false);
    expect(result.nrc).toBe(0x36);
    expect(result.nrcDescription!.toLowerCase()).toContain('exceeded');
  });

  it('parses requiredTimeDelayNotExpired NRC', () => {
    const response = hexToBytes('7F 27 37'); // Time delay
    const result = parseUDSResponse(response);
    expect(result.positive).toBe(false);
    expect(result.nrc).toBe(0x37);
    expect(result.nrcDescription!.toLowerCase()).toContain('delay');
  });
});

describe('Helper Functions', () => {
  
  it('getSecurityConfig returns correct config', () => {
    const bcmConfig = getSecurityConfig('BCM');
    expect(bcmConfig?.algorithm).toBe('rol5-xor');
    
    const sgwConfig = getSecurityConfig('SGW');
    expect(sgwConfig?.algorithm).toBe('atlantis');
    expect(sgwConfig?.requiresCSN).toBe(true);
  });

  it('getVINConfig returns correct config', () => {
    const bcmVin = getVINConfig('BCM');
    expect(bcmVin?.did).toBe(0xF190);
    expect(bcmVin?.writable).toBe(true);
    
    const sgwVin = getVINConfig('SGW');
    expect(sgwVin?.writable).toBe(false); // OTP
  });

  it('requiresCSN identifies Atlantis modules', () => {
    expect(requiresCSN('BCM')).toBe(false);
    expect(requiresCSN('SGW')).toBe(true);
  });

  it('supportsVINWrite identifies writable modules', () => {
    expect(supportsVINWrite('BCM')).toBe(true);
    expect(supportsVINWrite('ECM')).toBe(true);
    expect(supportsVINWrite('RFHUB')).toBe(true);  // Writable but OTP - dangerous!
    expect(supportsVINWrite('SGW')).toBe(false);   // OTP - not writable
  });

  it('getVINProgrammableModules returns writable modules', () => {
    const writable = getVINProgrammableModules();
    expect(writable.some(m => m.code === 'BCM')).toBe(true);
    expect(writable.some(m => m.code === 'ECM')).toBe(true);
    expect(writable.some(m => m.code === 'RFHUB')).toBe(true); // OTP but marked writable
    expect(writable.some(m => m.code === 'SGW')).toBe(false);  // Not writable
  });
});

describe('Complete VIN Programming Flow Simulation', () => {
  
  it('BCM: Full unlock → write VIN flow', () => {
    // 1. Start programming session
    const sessionMsg = UDS.programmingSession();
    expect(sessionMsg[0]).toBe(0x10);
    
    // 2. Request seed
    const seedReq = UDS.requestSeed(0x01);
    expect(seedReq[0]).toBe(0x27);
    
    // 3. Calculate key with known seed
    const seed = hexToBytes('A5 3C');
    const keyResult = calculateSecurityKey({
      moduleCode: 'BCM',
      algorithm: 'rol5-xor',
      seed,
      securityLevel: 0x01
    });
    expect(keyResult.success).toBe(true);
    
    // 4. Send key
    const keyMsg = UDS.sendKey(0x01, keyResult.key!);
    expect(keyMsg[0]).toBe(0x27);
    expect(keyMsg[1]).toBe(0x02);
    
    // 5. Write VIN
    const vinMsg = UDS.writeVIN('2C3CDXHG4MH591631');
    expect(vinMsg[0]).toBe(0x2E);
    
    console.log('✓ BCM VIN programming flow validated');
  });

  it('ECM: Full unlock → write VIN flow with Shift-XOR', () => {
    const ecm = MODULE_DATABASE.find(m => m.code === 'ECM')!;
    
    // 1. Request seed
    const seedReq = UDS.requestSeed(0x01);
    expect(seedReq[0]).toBe(0x27);
    
    // 2. Calculate key with known seed
    const seed = hexToBytes('12 34 56 78');
    const keyResult = calculateSecurityKey({
      moduleCode: 'ECM',
      algorithm: 'shift-xor',
      seed,
      securityLevel: 0x01,
      constant: ecm.security!.constant,
      iterations: 3
    });
    expect(keyResult.success).toBe(true);
    expect(keyResult.key!.length).toBe(4);
    
    // 3. Send key
    const keyMsg = UDS.sendKey(0x01, keyResult.key!);
    expect(keyMsg.length).toBe(6); // 27 02 + 4-byte key
    
    console.log('✓ ECM VIN programming flow validated');
    console.log(`  Seed: 12345678 → Key: ${keyResult.keyHex}`);
  });

  it('SGW: Full unlock flow with Atlantis (requires CSN)', () => {
    // 1. Read CSN first (required for Atlantis)
    const csnReq = UDS.readCSN();
    expect(bytesToHex(csnReq, '')).toBe('22F18C');
    
    // 2. Known seed and CSN
    const csn = hexToBytes('AA BB CC DD EE');
    const seed = hexToBytes('11 22 33 44');
    
    // 3. Calculate Atlantis key
    const keyResult = calculateSecurityKey({
      moduleCode: 'SGW',
      algorithm: 'atlantis',
      seed,
      securityLevel: 0x01,
      csn
    });
    expect(keyResult.success).toBe(true);
    expect(keyResult.key!.length).toBe(5);
    
    // 4. Send key
    const keyMsg = UDS.sendKey(0x01, keyResult.key!);
    expect(keyMsg.length).toBe(7); // 27 02 + 5-byte key
    
    console.log('✓ SGW Atlantis security flow validated');
    console.log(`  CSN: ${bytesToHex(csn)}`);
    console.log(`  Seed: ${bytesToHex(seed)}`);
    console.log(`  Key: ${keyResult.keyHex}`);
  });
});
