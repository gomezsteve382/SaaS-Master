import { describe, it, expect } from 'vitest';
import { 
  crc16Generic, 
  detectRFHUBAlgorithm,
  RFHUB_KNOWN_ALGORITHMS 
} from '../../shared/production-vin-patcher';

describe('RFHUB CRC Auto-Detection (Production Code)', () => {
  it('should detect Journey SmartBox algorithm (poly=0x95A5, init=0x0000)', () => {
    const reversedVIN = '284372HG5GBACC3C2';
    const vinBytes = new TextEncoder().encode(reversedVIN);
    const expectedCRC = 0x0202;
    const crcByte0 = expectedCRC & 0xFF;        // Low byte (LE)
    const crcByte1 = (expectedCRC >> 8) & 0xFF; // High byte (LE)

    const result = detectRFHUBAlgorithm(vinBytes, crcByte0, crcByte1);

    expect(result).not.toBeNull();
    expect(result?.polynomial).toBe(0x95A5);
    expect(result?.init).toBe(0x0000);
  });

  it('should calculate correct CRC for Journey SmartBox VIN', () => {
    const reversedVIN = '284372HG5GBACC3C2';
    const vinBytes = new TextEncoder().encode(reversedVIN);

    const crc = crc16Generic(vinBytes, 0x95A5, 0x0000);

    expect(crc).toBe(0x0202);
  });

  it('should detect Charger RFHUB algorithm (poly=0x589B, init=0xFFFF)', () => {
    const reversedVIN = '023697HF3TKXDC3C2';
    const vinBytes = new TextEncoder().encode(reversedVIN);
    
    const crc = crc16Generic(vinBytes, 0x589B, 0xFFFF);
    const crcByte0 = crc & 0xFF;
    const crcByte1 = (crc >> 8) & 0xFF;
    const result = detectRFHUBAlgorithm(vinBytes, crcByte0, crcByte1);

    expect(result).not.toBeNull();
    expect(result?.polynomial).toBe(0x589B);
    expect(result?.init).toBe(0xFFFF);
  });

  it('should return null for truly unknown algorithm', () => {
    const reversedVIN = 'UNKNOWNVINXXXXXX1';
    const vinBytes = new TextEncoder().encode(reversedVIN);
    const fakeCRC = 0x1234;
    const crcByte0 = fakeCRC & 0xFF;
    const crcByte1 = (fakeCRC >> 8) & 0xFF;

    const result = detectRFHUBAlgorithm(vinBytes, crcByte0, crcByte1);

    expect(result).toBeNull();
  });

  it('should have Journey SmartBox VIN in known algorithms database', () => {
    expect(RFHUB_KNOWN_ALGORITHMS['284372HG5GBACC3C2']).toBeDefined();
    expect(RFHUB_KNOWN_ALGORITHMS['284372HG5GBACC3C2'].polynomial).toBe(0x95A5);
    expect(RFHUB_KNOWN_ALGORITHMS['284372HG5GBACC3C2'].init).toBe(0x0000);
  });

  it('should verify all database CRC algorithms can be auto-detected', () => {
    for (const [reversedVIN, algo] of Object.entries(RFHUB_KNOWN_ALGORITHMS)) {
      const vinBytes = new TextEncoder().encode(reversedVIN);
      const crc = crc16Generic(vinBytes, algo.polynomial, algo.init);
      const crcByte0 = crc & 0xFF;
      const crcByte1 = (crc >> 8) & 0xFF;
      const detected = detectRFHUBAlgorithm(vinBytes, crcByte0, crcByte1);
      
      expect(detected, `Failed for VIN: ${reversedVIN}`).not.toBeNull();
      expect(detected?.polynomial).toBe(algo.polynomial);
      expect(detected?.init).toBe(algo.init);
    }
  });

  it('should detect big-endian CRC for 4KB RFHUB (poly=0x1021, init=0x0FDE)', () => {
    const reversedVIN = '844066HH4JGXDC3C2';
    const vinBytes = new TextEncoder().encode(reversedVIN);
    const expectedCRC = 0xE101;
    const crcByte0 = 0xE1; // As stored in file (first byte)
    const crcByte1 = 0x01; // As stored in file (second byte)

    const result = detectRFHUBAlgorithm(vinBytes, crcByte0, crcByte1);

    expect(result).not.toBeNull();
    expect(result?.polynomial).toBe(0x1021);
    expect(result?.init).toBe(0x0FDE);
    expect(result?.bigEndian).toBe(true);
  });
});
