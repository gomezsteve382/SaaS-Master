/**
 * Comprehensive Module Discovery Test
 * 
 * Verifies all modules from knowledge/modules.json:
 * 1. All modules load correctly
 * 2. TX/RX addresses are valid
 * 3. No duplicate module codes
 * 4. Conversion to ModuleDefinition works (using REAL converter)
 * 5. Address conflicts are detected
 * 6. MODULE_DATABASE sync validation (using REAL database)
 */

import * as fs from 'fs';
import * as path from 'path';
import { 
  MODULE_DATABASE,
  convertKnowledgeModule,
  convertKnowledgeModules,
  type KnowledgeModule,
  type ModuleDefinition
} from '../src/lib/module-database';

interface KnowledgeDB {
  metadata: {
    version: string;
    total_modules: number;
    verified_addresses: number;
  };
  modules: KnowledgeModule[];
}

interface TestResult {
  name: string;
  passed: boolean;
  details: string;
  errors?: string[];
}

function loadKnowledgeModules(): KnowledgeDB {
  const modulesPath = path.join(process.cwd(), 'knowledge', 'modules.json');
  const content = fs.readFileSync(modulesPath, 'utf-8');
  return JSON.parse(content);
}

function parseHexAddress(hex: string): number {
  return parseInt(hex.replace(/^0x/i, ''), 16);
}

function runTests(): TestResult[] {
  const results: TestResult[] = [];
  const db = loadKnowledgeModules();
  
  // =========================================================================
  // TEST 1: Module Count
  // =========================================================================
  const test1: TestResult = {
    name: 'Module Count Verification',
    passed: false,
    details: '',
    errors: []
  };
  
  const expectedCount = 30;
  const actualCount = db.modules.length;
  test1.passed = actualCount >= expectedCount;
  test1.details = `Expected >= ${expectedCount} modules, found ${actualCount}`;
  if (!test1.passed) {
    test1.errors!.push(`Missing ${expectedCount - actualCount} modules`);
  }
  results.push(test1);
  
  // =========================================================================
  // TEST 2: All Modules Have Valid TX/RX Addresses
  // =========================================================================
  const test2: TestResult = {
    name: 'TX/RX Address Validation',
    passed: true,
    details: '',
    errors: []
  };
  
  const invalidAddresses: string[] = [];
  for (const mod of db.modules) {
    const tx = parseHexAddress(mod.tx);
    const rx = parseHexAddress(mod.rx);
    
    if (isNaN(tx) || tx === 0 || tx > 0x7FF) {
      invalidAddresses.push(`${mod.code}: Invalid TX address ${mod.tx}`);
      test2.passed = false;
    }
    if (isNaN(rx) || rx === 0 || rx > 0x7FF) {
      invalidAddresses.push(`${mod.code}: Invalid RX address ${mod.rx}`);
      test2.passed = false;
    }
  }
  test2.details = test2.passed 
    ? `All ${db.modules.length} modules have valid 11-bit CAN addresses`
    : `${invalidAddresses.length} invalid addresses found`;
  test2.errors = invalidAddresses;
  results.push(test2);
  
  // =========================================================================
  // TEST 3: No Duplicate Module Codes
  // =========================================================================
  const test3: TestResult = {
    name: 'Unique Module Codes',
    passed: true,
    details: '',
    errors: []
  };
  
  const codeCounts = new Map<string, number>();
  for (const mod of db.modules) {
    const code = mod.code.toUpperCase();
    codeCounts.set(code, (codeCounts.get(code) || 0) + 1);
  }
  
  const duplicates: string[] = [];
  for (const [code, count] of codeCounts) {
    if (count > 1) {
      duplicates.push(`${code} appears ${count} times`);
      test3.passed = false;
    }
  }
  test3.details = test3.passed 
    ? `All ${db.modules.length} module codes are unique`
    : `${duplicates.length} duplicate codes found`;
  test3.errors = duplicates;
  results.push(test3);
  
  // =========================================================================
  // TEST 4: TX Address Uniqueness (allows known aliases)
  // =========================================================================
  const test4: TestResult = {
    name: 'TX Address Uniqueness',
    passed: true,
    details: '',
    errors: []
  };
  
  // Known aliases that share addresses (PCM = ECM, same physical module)
  const KNOWN_TX_ALIASES: Record<number, string[]> = {
    0x7E0: ['ECM', 'PCM'], // ECM and PCM are the same module
  };
  
  const txAddresses = new Map<number, string[]>();
  for (const mod of db.modules) {
    const tx = parseHexAddress(mod.tx);
    if (!txAddresses.has(tx)) {
      txAddresses.set(tx, []);
    }
    txAddresses.get(tx)!.push(mod.code);
  }
  
  const txConflicts: string[] = [];
  for (const [tx, codes] of txAddresses) {
    if (codes.length > 1) {
      // Check if this is a known alias
      const knownAlias = KNOWN_TX_ALIASES[tx];
      if (knownAlias && codes.every(c => knownAlias.includes(c))) {
        // This is an expected alias, not a conflict
        continue;
      }
      txConflicts.push(`TX 0x${tx.toString(16).toUpperCase()}: ${codes.join(', ')}`);
      test4.passed = false;
    }
  }
  test4.details = test4.passed 
    ? `All ${txAddresses.size} TX addresses are unique (ECM/PCM alias allowed)`
    : `${txConflicts.length} TX address conflicts found`;
  test4.errors = txConflicts;
  results.push(test4);
  
  // =========================================================================
  // TEST 5: RX Address Analysis (conflicts allowed but documented)
  // =========================================================================
  const test5: TestResult = {
    name: 'RX Address Analysis',
    passed: true,
    details: '',
    errors: []
  };
  
  const rxAddresses = new Map<number, string[]>();
  for (const mod of db.modules) {
    const rx = parseHexAddress(mod.rx);
    if (!rxAddresses.has(rx)) {
      rxAddresses.set(rx, []);
    }
    rxAddresses.get(rx)!.push(mod.code);
  }
  
  const rxShared: string[] = [];
  for (const [rx, codes] of rxAddresses) {
    if (codes.length > 1) {
      rxShared.push(`RX 0x${rx.toString(16).toUpperCase()}: ${codes.join(', ')}`);
    }
  }
  test5.details = rxShared.length === 0
    ? `All ${rxAddresses.size} RX addresses are unique`
    : `${rxShared.length} shared RX addresses (may be intentional)`;
  test5.errors = rxShared;
  results.push(test5);
  
  // =========================================================================
  // TEST 6: Verified Module Count
  // =========================================================================
  const test6: TestResult = {
    name: 'Verified Modules Count',
    passed: true,
    details: '',
    errors: []
  };
  
  const verified = db.modules.filter(m => m.verified);
  const unverified = db.modules.filter(m => !m.verified);
  test6.details = `${verified.length} verified, ${unverified.length} unverified`;
  test6.errors = unverified.map(m => `${m.code}: ${m.name} (${m.source})`);
  results.push(test6);
  
  // =========================================================================
  // TEST 7: Required Modules Present
  // =========================================================================
  const test7: TestResult = {
    name: 'Required Modules Present',
    passed: true,
    details: '',
    errors: []
  };
  
  const requiredModules = [
    'BCM', 'ECM', 'TCM', 'RFHUB', 'ABS', 'IPC', 'ORC', 'SGW',
    'CCM', 'DDM', 'PDM', 'EPS', 'ADM', 'SDM'
  ];
  
  const presentCodes = new Set(db.modules.map(m => m.code.toUpperCase()));
  const missingRequired: string[] = [];
  for (const req of requiredModules) {
    if (!presentCodes.has(req)) {
      missingRequired.push(req);
      test7.passed = false;
    }
  }
  test7.details = test7.passed 
    ? `All ${requiredModules.length} required modules present`
    : `Missing ${missingRequired.length} required modules`;
  test7.errors = missingRequired;
  results.push(test7);
  
  // =========================================================================
  // TEST 8: Module Data Completeness
  // =========================================================================
  const test8: TestResult = {
    name: 'Module Data Completeness',
    passed: true,
    details: '',
    errors: []
  };
  
  const incomplete: string[] = [];
  for (const mod of db.modules) {
    const issues: string[] = [];
    if (!mod.code || mod.code.length === 0) issues.push('missing code');
    if (!mod.name || mod.name.length === 0) issues.push('missing name');
    if (!mod.tx || mod.tx.length === 0) issues.push('missing TX');
    if (!mod.rx || mod.rx.length === 0) issues.push('missing RX');
    if (!mod.description || mod.description.length === 0) issues.push('missing description');
    
    if (issues.length > 0) {
      incomplete.push(`${mod.code}: ${issues.join(', ')}`);
      test8.passed = false;
    }
  }
  test8.details = test8.passed 
    ? `All ${db.modules.length} modules have complete data`
    : `${incomplete.length} modules have incomplete data`;
  test8.errors = incomplete;
  results.push(test8);
  
  // =========================================================================
  // TEST 9: Address Range Validation (CAN-C vs CAN-IHS)
  // =========================================================================
  const test9: TestResult = {
    name: 'CAN Bus Address Range Analysis',
    passed: true,
    details: '',
    errors: []
  };
  
  const canC: string[] = [];     // 0x700-0x7FF range (OBD-II standard)
  const canIHS: string[] = [];   // 0x600-0x6FF range (FCA internal)
  const other: string[] = [];
  
  for (const mod of db.modules) {
    const tx = parseHexAddress(mod.tx);
    if (tx >= 0x700 && tx <= 0x7FF) {
      canC.push(mod.code);
    } else if (tx >= 0x600 && tx <= 0x6FF) {
      canIHS.push(mod.code);
    } else {
      other.push(`${mod.code}: 0x${tx.toString(16).toUpperCase()}`);
    }
  }
  
  test9.details = `CAN-C (0x7xx): ${canC.length} modules, CAN-IHS (0x6xx): ${canIHS.length} modules`;
  if (other.length > 0) {
    test9.errors = [`Non-standard addresses: ${other.join(', ')}`];
  }
  results.push(test9);
  
  // =========================================================================
  // TEST 10: REAL Conversion to ModuleDefinition (using actual converter)
  // =========================================================================
  const test10: TestResult = {
    name: 'KnowledgeModule → ModuleDefinition Conversion (REAL)',
    passed: true,
    details: '',
    errors: []
  };
  
  // Use the REAL convertKnowledgeModules function from module-database.ts
  let convertedModules: ModuleDefinition[] = [];
  try {
    convertedModules = convertKnowledgeModules(db.modules);
  } catch (error) {
    test10.passed = false;
    test10.details = `Conversion failed: ${error}`;
    test10.errors = [`convertKnowledgeModules threw: ${error}`];
    results.push(test10);
    return results; // Can't continue if conversion fails
  }
  
  // Verify all conversions match the source data
  const conversionErrors: string[] = [];
  for (let i = 0; i < db.modules.length; i++) {
    const km = db.modules[i];
    const md = convertedModules[i];
    
    const expectedTx = parseHexAddress(km.tx);
    const expectedRx = parseHexAddress(km.rx);
    
    if (md.code.toUpperCase() !== km.code.toUpperCase()) {
      conversionErrors.push(`${km.code}: Code mismatch (got ${md.code})`);
      test10.passed = false;
    }
    if (md.tx !== expectedTx) {
      conversionErrors.push(`${km.code}: TX mismatch (expected 0x${expectedTx.toString(16)}, got 0x${md.tx.toString(16)})`);
      test10.passed = false;
    }
    if (md.rx !== expectedRx) {
      conversionErrors.push(`${km.code}: RX mismatch (expected 0x${expectedRx.toString(16)}, got 0x${md.rx.toString(16)})`);
      test10.passed = false;
    }
    if (!md.name || md.name.length === 0) {
      conversionErrors.push(`${km.code}: Missing name after conversion`);
      test10.passed = false;
    }
  }
  test10.details = test10.passed 
    ? `All ${convertedModules.length} modules convert correctly with matching TX/RX`
    : `${conversionErrors.length} conversion errors`;
  test10.errors = conversionErrors;
  results.push(test10);
  
  // =========================================================================
  // TEST 11: REAL MODULE_DATABASE Sync Check (using actual database)
  // =========================================================================
  const test11: TestResult = {
    name: 'MODULE_DATABASE Synchronization (REAL)',
    passed: true,
    details: '',
    errors: []
  };
  
  // Use the REAL MODULE_DATABASE from module-database.ts
  const dbCodes = new Set(MODULE_DATABASE.map(m => m.code.toUpperCase()));
  const knowledgeCodes = new Set(db.modules.map(m => m.code.toUpperCase()));
  
  const missingInKnowledge: string[] = [];
  const missingInDatabase: string[] = [];
  
  // Check all MODULE_DATABASE codes exist in knowledge
  for (const dbCode of dbCodes) {
    if (!knowledgeCodes.has(dbCode)) {
      missingInKnowledge.push(dbCode);
      test11.passed = false;
    }
  }
  
  // Check all knowledge codes exist in MODULE_DATABASE
  for (const kmCode of knowledgeCodes) {
    if (!dbCodes.has(kmCode)) {
      missingInDatabase.push(kmCode);
      // Not a failure - knowledge can have more than database
    }
  }
  
  test11.details = test11.passed 
    ? `All ${dbCodes.size} MODULE_DATABASE codes exist in knowledge base (${knowledgeCodes.size} total)`
    : `Sync issues found`;
  if (missingInKnowledge.length > 0) {
    test11.errors!.push(`In MODULE_DATABASE but missing in knowledge: ${missingInKnowledge.join(', ')}`);
  }
  if (missingInDatabase.length > 0) {
    test11.errors!.push(`In knowledge but not MODULE_DATABASE: ${missingInDatabase.join(', ')} (OK - knowledge is source of truth)`);
  }
  results.push(test11);
  
  // =========================================================================
  // TEST 12: TX/RX Address Match Between Knowledge and MODULE_DATABASE
  // =========================================================================
  const test12: TestResult = {
    name: 'Address Match: Knowledge ↔ MODULE_DATABASE',
    passed: true,
    details: '',
    errors: []
  };
  
  const addressMismatches: string[] = [];
  for (const km of db.modules) {
    const dbModule = MODULE_DATABASE.find(m => m.code.toUpperCase() === km.code.toUpperCase());
    if (dbModule) {
      const expectedTx = parseHexAddress(km.tx);
      const expectedRx = parseHexAddress(km.rx);
      
      if (dbModule.tx !== expectedTx) {
        addressMismatches.push(`${km.code}: TX mismatch (knowledge=0x${expectedTx.toString(16).toUpperCase()}, db=0x${dbModule.tx.toString(16).toUpperCase()})`);
        test12.passed = false;
      }
      if (dbModule.rx !== expectedRx) {
        addressMismatches.push(`${km.code}: RX mismatch (knowledge=0x${expectedRx.toString(16).toUpperCase()}, db=0x${dbModule.rx.toString(16).toUpperCase()})`);
        test12.passed = false;
      }
    }
  }
  
  const matchedCount = db.modules.filter(km => 
    MODULE_DATABASE.some(m => m.code.toUpperCase() === km.code.toUpperCase())
  ).length;
  
  test12.details = test12.passed 
    ? `All ${matchedCount} matched modules have consistent TX/RX addresses`
    : `${addressMismatches.length} address mismatches found`;
  test12.errors = addressMismatches;
  results.push(test12);
  
  // =========================================================================
  // TEST 13: Full Module List
  // =========================================================================
  const test13: TestResult = {
    name: 'Complete Module Inventory',
    passed: true,
    details: `All ${db.modules.length} modules:`,
    errors: db.modules.map(m => 
      `${m.code.padEnd(8)} TX:${m.tx.padEnd(6)} RX:${m.rx.padEnd(6)} ${m.verified ? '✓' : '○'} ${m.name}`
    )
  };
  results.push(test13);
  
  return results;
}

// Run tests and output results
console.log('═══════════════════════════════════════════════════════════════');
console.log('       ALL 30 MODULES DISCOVERY TEST');
console.log('═══════════════════════════════════════════════════════════════');
console.log('');

const results = runTests();
let passedCount = 0;
let failedCount = 0;

for (const result of results) {
  const status = result.passed ? '✅ PASS' : '❌ FAIL';
  console.log(`${status}: ${result.name}`);
  console.log(`       ${result.details}`);
  
  if (result.errors && result.errors.length > 0 && result.errors.length <= 30) {
    for (const error of result.errors) {
      console.log(`       - ${error}`);
    }
  }
  console.log('');
  
  if (result.passed) passedCount++;
  else failedCount++;
}

console.log('═══════════════════════════════════════════════════════════════');
console.log(`SUMMARY: ${passedCount} passed, ${failedCount} failed out of ${results.length} tests`);
console.log('═══════════════════════════════════════════════════════════════');

// Exit with error code if any tests failed
if (failedCount > 0) {
  process.exit(1);
}
