/*
 * DARKVIN LABS - CAN-to-Serial Bridge
 * For Arduino Uno R3 + Seeed Studio CAN-Bus Shield V2
 * 
 * This firmware makes your Arduino act like an ELM327 device
 * Compatible with DARKVIN LABS toolkit
 */

#include <SPI.h>
#include "mcp2515_can.h"

// CAN-Bus Shield V2 uses pin 9 for CS
#define CAN_CS_PIN 9
#define CAN_BITRATE CAN_500KBPS

mcp2515_can CAN(CAN_CS_PIN);

// Buffer for CAN messages
unsigned char canMsgBuf[8];
unsigned char canMsgLen = 0;
unsigned long canMsgId = 0;

// Command buffer
String cmdBuffer = "";

void setup() {
  Serial.begin(115200);
  
  // Initialize CAN bus at 500kbps
  while (CAN.begin(CAN_BITRATE) != CAN_OK) {
    Serial.println("ERROR: CAN init failed!");
    delay(1000);
  }
  
  Serial.println("DARKVIN LABS CAN Bridge v1.0");
  Serial.println("Arduino Uno R3 + Seeed CAN-Bus Shield V2");
  Serial.println("READY");
}

void loop() {
  // Check for incoming serial commands
  while (Serial.available()) {
    char c = Serial.read();
    
    if (c == '\n' || c == '\r') {
      if (cmdBuffer.length() > 0) {
        processCommand(cmdBuffer);
        cmdBuffer = "";
      }
    } else {
      cmdBuffer += c;
    }
  }
  
  // Check for incoming CAN messages
  if (CAN.checkReceive() == CAN_MSGAVAIL) {
    CAN.readMsgBuf(&canMsgLen, canMsgBuf);
    canMsgId = CAN.getCanId();
    
    // Print received message in hex format
    Serial.print("RX:");
    Serial.print(canMsgId, HEX);
    Serial.print(":");
    for (int i = 0; i < canMsgLen; i++) {
      if (canMsgBuf[i] < 0x10) Serial.print("0");
      Serial.print(canMsgBuf[i], HEX);
    }
    Serial.println();
  }
}

void processCommand(String cmd) {
  cmd.trim();
  cmd.toUpperCase();
  
  // ATZ - Reset
  if (cmd == "ATZ") {
    Serial.println("DARKVIN LABS CAN Bridge v1.0");
    Serial.println("OK");
    return;
  }
  
  // AT commands (ELM327 compatibility)
  if (cmd.startsWith("AT")) {
    Serial.println("OK");
    return;
  }
  
  // Send CAN message: TX:ID:DATA
  // Example: TX:7E0:0222F190
  if (cmd.startsWith("TX:")) {
    int firstColon = cmd.indexOf(':', 3);
    if (firstColon > 0) {
      String idStr = cmd.substring(3, firstColon);
      String dataStr = cmd.substring(firstColon + 1);
      
      unsigned long id = strtoul(idStr.c_str(), NULL, 16);
      
      // Parse hex data
      int dataLen = dataStr.length() / 2;
      unsigned char data[8];
      for (int i = 0; i < dataLen && i < 8; i++) {
        String byteStr = dataStr.substring(i * 2, i * 2 + 2);
        data[i] = strtoul(byteStr.c_str(), NULL, 16);
      }
      
      // Send CAN message
      byte result = CAN.sendMsgBuf(id, 0, dataLen, data);
      
      if (result == CAN_OK) {
        Serial.println("OK");
      } else {
        Serial.println("ERROR");
      }
    }
    return;
  }
  
  // Unknown command
  Serial.println("?");
}
