# Arduino Setup Guide for CAN Bus Monitor

## Hardware Requirements

- **Arduino Uno REV3** (ATmega328P)
- **Seeed Studio CAN-Bus Shield V2**
- **MicroSD card** (optional, for logging)
- **USB cable** (Arduino to PC)
- **OBD-II cable** or bench harness

## Software Requirements

### 1. Arduino IDE

Download and install Arduino IDE 1.8.19 or later:
- https://www.arduino.cc/en/software

### 2. Required Libraries

Install the following libraries via Arduino IDE Library Manager:

**Method 1: Using Library Manager (Recommended)**

1. Open Arduino IDE
2. Go to **Sketch → Include Library → Manage Libraries**
3. Search and install each library:

#### MCP2515 CAN Library
- **Name**: `mcp2515` by autowp
- **Version**: 1.0.1 or later
- **Search**: "mcp2515"

#### SD Card Library
- **Name**: `SD` (built-in with Arduino IDE)
- **Already included** - no installation needed

#### SPI Library
- **Name**: `SPI` (built-in with Arduino IDE)
- **Already included** - no installation needed

**Method 2: Manual Installation**

If Library Manager doesn't work:

1. Download MCP2515 library:
   ```
   https://github.com/autowp/arduino-mcp2515/archive/master.zip
   ```

2. In Arduino IDE:
   - Go to **Sketch → Include Library → Add .ZIP Library**
   - Select the downloaded ZIP file

## Hardware Setup

### Step 1: Assemble Shield

1. **Stack the CAN-Bus Shield on Arduino Uno**
   - Align all pins carefully
   - Press down firmly until seated
   - No wiring needed - shield connects via headers

### Step 2: Insert SD Card (Optional)

1. Format SD card as FAT32
2. Insert into SD card slot on shield
3. Required for data logging feature

### Step 3: Connect to PC

1. Connect Arduino to PC via USB cable
2. Wait for drivers to install (Windows)
3. Note the COM port number (e.g., COM3)

### Step 4: Connect to Vehicle

**Option A: OBD-II Port (Live Vehicle)**

```
OBD-II Pin    CAN Shield Pin
---------     --------------
6  (CAN-H)    →  CAN-H
14 (CAN-L)    →  CAN-L
16 (+12V)     →  VIN (optional power)
4,5 (GND)     →  GND
```

**Option B: Bench Harness**

```
Module        CAN Shield
------        ----------
CAN-H    →    CAN-H
CAN-L    →    CAN-L
GND      →    GND
+12V     →    VIN (if powering shield from vehicle)
```

**Important Notes:**
- CAN-H and CAN-L are twisted pair wires
- Termination resistor (120Ω) may be needed
- Shield can be powered via USB (no VIN connection needed)

## Software Setup

### Step 1: Open Sketch

1. Launch Arduino IDE
2. Open `CANBusMonitor.ino`
3. Verify all libraries are installed (no red errors)

### Step 2: Configure Board

1. Go to **Tools → Board**
2. Select **Arduino Uno**

### Step 3: Select Port

1. Go to **Tools → Port**
2. Select your Arduino's COM port (e.g., COM3)

### Step 4: Upload Sketch

1. Click **Upload** button (→)
2. Wait for "Done uploading" message
3. Should see LED blinking 3 times (ready indicator)

### Step 5: Open Serial Monitor

1. Go to **Tools → Serial Monitor**
2. Set baud rate to **115200**
3. Set line ending to **Newline**
4. You should see startup messages

## Testing

### Test 1: Verify Initialization

In Serial Monitor, you should see:
```
===========================================
  RFHUB BCM Toolkit - CAN Bus Monitor
  Version 1.0.0
===========================================
Initializing CAN bus... OK
CAN Speed: 500 kbps
Mode: Promiscuous (all messages)
Initializing SD card... OK
SD Card Size: XXXX MB

Ready! Send commands via serial.
Type 'help' for command list.
```

### Test 2: Check Status

Type `status` in Serial Monitor:
```
=== SYSTEM STATUS ===
CAN Bus: OK
SD Card: OK
Monitoring: ENABLED
Logging: DISABLED
Uptime: 10 seconds
Messages RX: 0
Messages TX: 0
Errors: 0
====================
```

### Test 3: Monitor CAN Traffic

1. Connect to vehicle or bench setup
2. Turn ignition ON (don't start engine)
3. You should see JSON messages in Serial Monitor:
```json
{"type":"can_message","id":"0x760","dlc":8,"data":"02 09 02 00 00 00 00 00","timestamp":12345}
```

### Test 4: Scan for VINs

Type `scanvin` in Serial Monitor:
```json
{"status":"scanning_vins"}
{"status":"scanning","module":"ECM"}
{"status":"vin_request_sent","module":"0x7E0"}
...
{"status":"scan_complete"}
```

## Command Reference

### Basic Commands

| Command | Description | Example |
|---------|-------------|---------|
| `help` | Show command list | `help` |
| `status` | Show system status | `status` |
| `start` | Start monitoring | `start` |
| `stop` | Stop monitoring | `stop` |
| `reset` | Reset statistics | `reset` |

### VIN Commands

| Command | Description | Example |
|---------|-------------|---------|
| `scanvin` | Scan all modules | `scanvin` |
| `getvin:XXX` | Request VIN from module | `getvin:7E0` |

### Diagnostic Commands

| Command | Description | Example |
|---------|-------------|---------|
| `readdtc:XXX` | Read DTCs from module | `readdtc:7E0` |
| `cleardtc:XXX` | Clear DTCs from module | `cleardtc:7E0` |

### Logging Commands

| Command | Description | Example |
|---------|-------------|---------|
| `logstart` | Start SD logging | `logstart` |
| `logstop` | Stop SD logging | `logstop` |

## Troubleshooting

### Problem: "CAN bus... FAILED"

**Causes:**
- Shield not properly seated
- Wrong SPI pins
- Faulty shield

**Solutions:**
1. Re-seat shield on Arduino
2. Check all pins aligned
3. Verify CS pin is 10 (default)
4. Try different Arduino

### Problem: "SD card... FAILED"

**Causes:**
- No SD card inserted
- Wrong format (not FAT32)
- Faulty SD card
- CS pin conflict

**Solutions:**
1. Insert SD card
2. Format as FAT32
3. Try different SD card
4. Verify SD CS pin is 4

### Problem: No CAN messages received

**Causes:**
- Not connected to vehicle
- Wrong CAN speed
- Bad wiring
- No termination resistor

**Solutions:**
1. Verify connections (CAN-H, CAN-L, GND)
2. Check CAN speed (500kbps for most Chrysler)
3. Add 120Ω termination resistor
4. Try different vehicle/module

### Problem: Garbled serial output

**Causes:**
- Wrong baud rate
- USB cable issue
- Driver problem

**Solutions:**
1. Set Serial Monitor to 115200 baud
2. Try different USB cable
3. Reinstall Arduino drivers
4. Try different USB port

## Pin Reference

### Seeed CAN-Bus Shield V2

| Pin | Function | Arduino Pin |
|-----|----------|-------------|
| D10 | MCP2515 CS | 10 |
| D4 | SD Card CS | 4 |
| D13 | SCK (SPI) | 13 |
| D12 | MISO (SPI) | 12 |
| D11 | MOSI (SPI) | 11 |
| D13 | LED | 13 |

### CAN Bus Connector

| Terminal | Signal | Color (typical) |
|----------|--------|-----------------|
| 1 | CAN-H | Orange/White |
| 2 | CAN-L | Orange |
| 3 | GND | Black |

## Advanced Configuration

### Change CAN Speed

Edit line 24 in `CANBusMonitor.ino`:
```cpp
#define CAN_SPEED CAN_500KBPS  // Options: CAN_250KBPS, CAN_500KBPS
```

### Change Crystal Frequency

Edit line 25 if using different crystal:
```cpp
#define CAN_CLOCK MCP_8MHZ  // Options: MCP_8MHZ, MCP_16MHZ
```

### Enable Debug Output

Add at top of sketch:
```cpp
#define DEBUG_MODE 1
```

## Next Steps

Once Arduino is working:
1. Test with bench setup first
2. Verify CAN traffic reception
3. Test VIN scanning
4. Connect to web application
5. Perform live vehicle testing

## Support

For issues:
1. Check this guide first
2. Verify hardware connections
3. Test with known-good vehicle
4. Check Serial Monitor output
5. Review error messages

## Safety Warnings

⚠️ **IMPORTANT:**
- Never disconnect while vehicle is running
- Don't short CAN-H or CAN-L
- Use proper 12V power supply for bench testing
- Disconnect battery before wiring
- CAN bus errors can cause vehicle issues

## Resources

- **Arduino IDE**: https://www.arduino.cc
- **MCP2515 Library**: https://github.com/autowp/arduino-mcp2515
- **Seeed Wiki**: https://wiki.seeedstudio.com/CAN-BUS_Shield_V2.0/
- **OBD-II Pinout**: https://en.wikipedia.org/wiki/OBD-II_PIDs

