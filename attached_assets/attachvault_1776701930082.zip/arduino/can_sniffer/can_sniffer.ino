/**
 * DARKVIN LABS - CAN Bus Sniffer for Dodge/Chrysler/FCA Vehicles
 * 
 * Hardware Requirements:
 * - Arduino Uno/Mega/Nano
 * - MCP2515 CAN Bus Module
 * - Connections:
 *   MCP2515 VCC  -> Arduino 5V
 *   MCP2515 GND  -> Arduino GND
 *   MCP2515 CS   -> Arduino D10
 *   MCP2515 SO   -> Arduino D12
 *   MCP2515 SI   -> Arduino D11
 *   MCP2515 SCK  -> Arduino D13
 *   MCP2515 INT  -> Arduino D2
 *   CAN-H        -> OBD-II Pin 6
 *   CAN-L        -> OBD-II Pin 14
 *   GND          -> OBD-II Pin 4 or 5
 * 
 * CAN Bus Speed: 500 kbps (standard for most Dodge vehicles)
 * 
 * Features:
 * - Passive CAN bus monitoring (sniffing)
 * - Active UDS diagnostic requests
 * - VIN extraction
 * - Module identification
 * - Real-time message streaming to PC
 */

#include <SPI.h>
#include <mcp2515.h>

// MCP2515 CAN Controller
MCP2515 mcp2515(10); // CS pin

// CAN message structure
struct can_frame canMsg;

// State variables
bool monitoring = false;
unsigned long messageCount = 0;
unsigned long lastHeartbeat = 0;

// UDS Service IDs
#define UDS_READ_DATA_BY_ID 0x22
#define UDS_SESSION_CONTROL 0x10

// Common Data Identifiers
#define DID_VIN 0xF190
#define DID_PART_NUMBER 0xF187
#define DID_SOFTWARE_VERSION 0xF18B

// ECU Addresses (Diagnostic Request)
#define ECU_ECM 0x7E0
#define ECU_TCM 0x7E1
#define ECU_ABS 0x7E2
#define ECU_BCM 0x7E3
#define ECU_RFHUB 0x7E4
#define ECU_CGW 0x7E5

void setup() {
  Serial.begin(500000); // High baud rate for fast data transfer
  
  // Initialize MCP2515
  mcp2515.reset();
  mcp2515.setBitrate(CAN_500KBPS, MCP_8MHZ); // Adjust crystal frequency if needed
  mcp2515.setNormalMode();
  
  Serial.println("DARKVIN LABS CAN Sniffer v1.0");
  Serial.println("READY");
}

void loop() {
  // Check for commands from PC
  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    command.trim();
    handleCommand(command);
  }
  
  // Read CAN messages if monitoring
  if (monitoring) {
    if (mcp2515.readMessage(&canMsg) == MCP2515::ERROR_OK) {
      printCANMessage(&canMsg);
      messageCount++;
    }
  }
  
  // Send heartbeat every second
  if (millis() - lastHeartbeat > 1000) {
    sendHeartbeat();
    lastHeartbeat = millis();
  }
}

void handleCommand(String command) {
  if (command == "START_CAN_MONITOR") {
    monitoring = true;
    messageCount = 0;
    Serial.println("STATUS:MONITORING_STARTED");
    
  } else if (command == "STOP_CAN_MONITOR") {
    monitoring = false;
    Serial.println("STATUS:MONITORING_STOPPED");
    
  } else if (command.startsWith("REQUEST_VIN:")) {
    // Format: REQUEST_VIN:7E3 (ECU address in hex)
    String ecuAddr = command.substring(12);
    requestVIN(strtol(ecuAddr.c_str(), NULL, 16));
    
  } else if (command.startsWith("REQUEST_PART:")) {
    // Format: REQUEST_PART:7E3
    String ecuAddr = command.substring(13);
    requestPartNumber(strtol(ecuAddr.c_str(), NULL, 16));
    
  } else if (command.startsWith("REQUEST_SW:")) {
    // Format: REQUEST_SW:7E3
    String ecuAddr = command.substring(11);
    requestSoftwareVersion(strtol(ecuAddr.c_str(), NULL, 16));
    
  } else if (command == "SCAN_MODULES") {
    scanModules();
    
  } else if (command == "GET_STATUS") {
    sendStatus();
    
  } else {
    Serial.println("ERROR:UNKNOWN_COMMAND");
  }
}

void printCANMessage(struct can_frame *frame) {
  // Format: ID:7E8,DLC:8,DATA:02,62,F1,90,31,47,31,4A
  Serial.print("ID:");
  Serial.print(frame->can_id, HEX);
  Serial.print(",DLC:");
  Serial.print(frame->can_dlc);
  Serial.print(",DATA:");
  
  for (int i = 0; i < frame->can_dlc; i++) {
    if (i > 0) Serial.print(",");
    if (frame->data[i] < 0x10) Serial.print("0");
    Serial.print(frame->data[i], HEX);
  }
  
  Serial.println();
}

void sendUDSRequest(uint16_t ecuAddr, uint8_t service, uint16_t did) {
  struct can_frame frame;
  frame.can_id = ecuAddr;
  frame.can_dlc = 8;
  
  // UDS format: [Length, Service, DID_High, DID_Low, 0x00, ...]
  frame.data[0] = 0x02; // Length (2 bytes: service + DID)
  frame.data[1] = service;
  frame.data[2] = (did >> 8) & 0xFF;
  frame.data[3] = did & 0xFF;
  frame.data[4] = 0x00;
  frame.data[5] = 0x00;
  frame.data[6] = 0x00;
  frame.data[7] = 0x00;
  
  mcp2515.sendMessage(&frame);
  
  Serial.print("REQUEST_SENT:ID=");
  Serial.print(ecuAddr, HEX);
  Serial.print(",SERVICE=");
  Serial.print(service, HEX);
  Serial.print(",DID=");
  Serial.println(did, HEX);
}

void requestVIN(uint16_t ecuAddr) {
  sendUDSRequest(ecuAddr, UDS_READ_DATA_BY_ID, DID_VIN);
}

void requestPartNumber(uint16_t ecuAddr) {
  sendUDSRequest(ecuAddr, UDS_READ_DATA_BY_ID, DID_PART_NUMBER);
}

void requestSoftwareVersion(uint16_t ecuAddr) {
  sendUDSRequest(ecuAddr, UDS_READ_DATA_BY_ID, DID_SOFTWARE_VERSION);
}

void scanModules() {
  Serial.println("SCAN:STARTED");
  
  // List of common ECU addresses
  uint16_t ecuAddresses[] = {
    ECU_ECM, ECU_TCM, ECU_ABS, ECU_BCM, ECU_RFHUB, ECU_CGW
  };
  
  for (int i = 0; i < 6; i++) {
    // Request VIN from each module
    requestVIN(ecuAddresses[i]);
    delay(100); // Wait for response
    
    // Request part number
    requestPartNumber(ecuAddresses[i]);
    delay(100);
  }
  
  Serial.println("SCAN:COMPLETED");
}

void sendHeartbeat() {
  Serial.print("HEARTBEAT:UPTIME=");
  Serial.print(millis() / 1000);
  Serial.print(",MESSAGES=");
  Serial.println(messageCount);
}

void sendStatus() {
  Serial.print("STATUS:MONITORING=");
  Serial.print(monitoring ? "ON" : "OFF");
  Serial.print(",MESSAGES=");
  Serial.print(messageCount);
  Serial.print(",UPTIME=");
  Serial.println(millis() / 1000);
}

