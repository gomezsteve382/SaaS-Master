/*
 * RFHUB BCM Toolkit - CAN Bus Monitor
 * 
 * Hardware: Arduino Uno + Seeed Studio CAN-Bus Shield V2
 * CAN Controller: MCP2515
 * CAN Transceiver: MCP2551
 * 
 * Features:
 * - Live CAN bus monitoring
 * - VIN scanning across all modules
 * - Diagnostic requests (UDS/OBD-II)
 * - DTC reading
 * - SD card logging
 * - USB serial communication with web app
 * 
 * Author: SRT LAB
 * Version: 1.0.0
 */

#include <SPI.h>
#include <mcp2515.h>
#include <SD.h>

// Pin Definitions
#define CAN_CS_PIN 10      // MCP2515 CS pin
#define SD_CS_PIN 4        // SD card CS pin
#define LED_PIN 13         // Status LED

// CAN Bus Settings
#define CAN_SPEED CAN_500KBPS  // Most Chrysler vehicles use 500kbps
#define CAN_CLOCK MCP_8MHZ     // Seeed Shield uses 8MHz crystal

// Buffer sizes
#define SERIAL_BUFFER_SIZE 256
#define CAN_BUFFER_SIZE 64

// MCP2515 CAN controller
MCP2515 mcp2515(CAN_CS_PIN);

// State variables
bool canInitialized = false;
bool sdInitialized = false;
bool loggingEnabled = false;
bool monitoringEnabled = true;
File logFile;

// Statistics
unsigned long messagesReceived = 0;
unsigned long messagesSent = 0;
unsigned long errors = 0;

// Command buffer
char commandBuffer[SERIAL_BUFFER_SIZE];
int commandIndex = 0;

// Timing
unsigned long lastHeartbeat = 0;
const unsigned long HEARTBEAT_INTERVAL = 1000; // 1 second

void setup() {
  // Initialize serial communication
  Serial.begin(115200);
  while (!Serial && millis() < 3000); // Wait up to 3 seconds for serial
  
  Serial.println(F("==========================================="));
  Serial.println(F("  RFHUB BCM Toolkit - CAN Bus Monitor"));
  Serial.println(F("  Version 1.0.0"));
  Serial.println(F("==========================================="));
  
  // Initialize LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  
  // Initialize CAN bus
  initializeCAN();
  
  // Initialize SD card
  initializeSD();
  
  Serial.println(F("\nReady! Send commands via serial."));
  Serial.println(F("Type 'help' for command list.\n"));
  
  blinkLED(3, 200); // Ready indicator
}

void loop() {
  // Process serial commands
  processSerialCommands();
  
  // Monitor CAN bus
  if (canInitialized && monitoringEnabled) {
    monitorCANBus();
  }
  
  // Send heartbeat
  sendHeartbeat();
  
  // Blink LED to show activity
  if (messagesReceived % 100 == 0 && messagesReceived > 0) {
    blinkLED(1, 50);
  }
}

void initializeCAN() {
  Serial.print(F("Initializing CAN bus... "));
  
  mcp2515.reset();
  mcp2515.setBitrate(CAN_SPEED, CAN_CLOCK);
  mcp2515.setNormalMode();
  
  // Set filters to receive all messages (promiscuous mode)
  mcp2515.setFilterMask(MCP2515::MASK0, false, 0x00000000);
  mcp2515.setFilterMask(MCP2515::MASK1, false, 0x00000000);
  
  canInitialized = true;
  Serial.println(F("OK"));
  Serial.println(F("CAN Speed: 500 kbps"));
  Serial.println(F("Mode: Promiscuous (all messages)"));
}

void initializeSD() {
  Serial.print(F("Initializing SD card... "));
  
  if (!SD.begin(SD_CS_PIN)) {
    Serial.println(F("FAILED"));
    Serial.println(F("SD card not found or initialization failed."));
    sdInitialized = false;
    return;
  }
  
  sdInitialized = true;
  Serial.println(F("OK"));
  Serial.println(F("SD card ready for logging."));
}

void processSerialCommands() {
  while (Serial.available() > 0) {
    char c = Serial.read();
    
    if (c == '\n' || c == '\r') {
      if (commandIndex > 0) {
        commandBuffer[commandIndex] = '\0';
        executeCommand(commandBuffer);
        commandIndex = 0;
      }
    } else if (commandIndex < SERIAL_BUFFER_SIZE - 1) {
      commandBuffer[commandIndex++] = c;
    }
  }
}

void executeCommand(const char* cmd) {
  // Convert to uppercase for case-insensitive matching
  String command = String(cmd);
  command.toUpperCase();
  command.trim();
  
  // Help command
  if (command == "HELP") {
    printHelp();
  }
  // Status command
  else if (command == "STATUS") {
    printStatus();
  }
  // Start monitoring
  else if (command == "START") {
    monitoringEnabled = true;
    Serial.println(F("{\"status\":\"monitoring_started\"}"));
  }
  // Stop monitoring
  else if (command == "STOP") {
    monitoringEnabled = false;
    Serial.println(F("{\"status\":\"monitoring_stopped\"}"));
  }
  // Scan for VINs
  else if (command.startsWith("SCANVIN")) {
    scanForVINs();
  }
  // Request VIN from specific module
  else if (command.startsWith("GETVIN")) {
    // Format: GETVIN:7E0 (ECM address)
    int colonPos = command.indexOf(':');
    if (colonPos > 0) {
      String addrStr = command.substring(colonPos + 1);
      uint32_t addr = strtoul(addrStr.c_str(), NULL, 16);
      requestVIN(addr);
    }
  }
  // Read DTCs
  else if (command.startsWith("READDTC")) {
    int colonPos = command.indexOf(':');
    if (colonPos > 0) {
      String addrStr = command.substring(colonPos + 1);
      uint32_t addr = strtoul(addrStr.c_str(), NULL, 16);
      readDTCs(addr);
    }
  }
  // Clear DTCs
  else if (command.startsWith("CLEARDTC")) {
    int colonPos = command.indexOf(':');
    if (colonPos > 0) {
      String addrStr = command.substring(colonPos + 1);
      uint32_t addr = strtoul(addrStr.c_str(), NULL, 16);
      clearDTCs(addr);
    }
  }
  // Start logging
  else if (command == "LOGSTART") {
    startLogging();
  }
  // Stop logging
  else if (command == "LOGSTOP") {
    stopLogging();
  }
  // Reset statistics
  else if (command == "RESET") {
    messagesReceived = 0;
    messagesSent = 0;
    errors = 0;
    Serial.println(F("{\"status\":\"statistics_reset\"}"));
  }
  // Unknown command
  else {
    Serial.print(F("{\"error\":\"unknown_command\",\"command\":\""));
    Serial.print(cmd);
    Serial.println(F("\"}"));
  }
}

void monitorCANBus() {
  struct can_frame frame;
  
  if (mcp2515.readMessage(&frame) == MCP2515::ERROR_OK) {
    messagesReceived++;
    
    // Send to serial in JSON format
    Serial.print(F("{\"type\":\"can_message\",\"id\":\"0x"));
    Serial.print(frame.can_id, HEX);
    Serial.print(F("\",\"dlc\":"));
    Serial.print(frame.can_dlc);
    Serial.print(F(",\"data\":\""));
    
    for (int i = 0; i < frame.can_dlc; i++) {
      if (frame.data[i] < 0x10) Serial.print(F("0"));
      Serial.print(frame.data[i], HEX);
      if (i < frame.can_dlc - 1) Serial.print(F(" "));
    }
    
    Serial.print(F("\",\"timestamp\":"));
    Serial.print(millis());
    Serial.println(F("}"));
    
    // Log to SD card if enabled
    if (loggingEnabled && sdInitialized && logFile) {
      logFile.print(millis());
      logFile.print(F(",0x"));
      logFile.print(frame.can_id, HEX);
      logFile.print(F(","));
      logFile.print(frame.can_dlc);
      logFile.print(F(","));
      
      for (int i = 0; i < frame.can_dlc; i++) {
        if (frame.data[i] < 0x10) logFile.print(F("0"));
        logFile.print(frame.data[i], HEX);
        if (i < frame.can_dlc - 1) logFile.print(F(" "));
      }
      
      logFile.println();
      
      // Flush every 10 messages
      if (messagesReceived % 10 == 0) {
        logFile.flush();
      }
    }
  }
}

void scanForVINs() {
  Serial.println(F("{\"status\":\"scanning_vins\"}"));
  
  // Common module addresses for Chrysler/Dodge
  uint32_t modules[] = {
    0x7E0, // ECM/PCM
    0x7E1, // TCM
    0x760, // BCM
    0x765, // RFHUB
    0x7E4, // HVAC
    0x7E5, // ABS/ESP
    0x7E6, // Airbag
    0x7E7, // Cluster
  };
  
  const char* moduleNames[] = {
    "ECM",
    "TCM",
    "BCM",
    "RFHUB",
    "HVAC",
    "ABS",
    "Airbag",
    "Cluster"
  };
  
  for (int i = 0; i < 8; i++) {
    Serial.print(F("{\"status\":\"scanning\",\"module\":\""));
    Serial.print(moduleNames[i]);
    Serial.println(F("\"}"));
    
    requestVIN(modules[i]);
    delay(500); // Wait for response
  }
  
  Serial.println(F("{\"status\":\"scan_complete\"}"));
}

void requestVIN(uint32_t moduleAddr) {
  struct can_frame frame;
  
  // OBD-II Mode 09 PID 02 (VIN request)
  frame.can_id = moduleAddr;
  frame.can_dlc = 8;
  frame.data[0] = 0x02; // Number of bytes
  frame.data[1] = 0x09; // Mode 09 (Vehicle Information)
  frame.data[2] = 0x02; // PID 02 (VIN)
  frame.data[3] = 0x00;
  frame.data[4] = 0x00;
  frame.data[5] = 0x00;
  frame.data[6] = 0x00;
  frame.data[7] = 0x00;
  
  if (mcp2515.sendMessage(&frame) == MCP2515::ERROR_OK) {
    messagesSent++;
    Serial.print(F("{\"status\":\"vin_request_sent\",\"module\":\"0x"));
    Serial.print(moduleAddr, HEX);
    Serial.println(F("\"}"));
  } else {
    errors++;
    Serial.print(F("{\"error\":\"send_failed\",\"module\":\"0x"));
    Serial.print(moduleAddr, HEX);
    Serial.println(F("\"}"));
  }
}

void readDTCs(uint32_t moduleAddr) {
  struct can_frame frame;
  
  // OBD-II Mode 03 (Read DTCs)
  frame.can_id = moduleAddr;
  frame.can_dlc = 8;
  frame.data[0] = 0x01; // Number of bytes
  frame.data[1] = 0x03; // Mode 03 (Read DTCs)
  frame.data[2] = 0x00;
  frame.data[3] = 0x00;
  frame.data[4] = 0x00;
  frame.data[5] = 0x00;
  frame.data[6] = 0x00;
  frame.data[7] = 0x00;
  
  if (mcp2515.sendMessage(&frame) == MCP2515::ERROR_OK) {
    messagesSent++;
    Serial.print(F("{\"status\":\"dtc_request_sent\",\"module\":\"0x"));
    Serial.print(moduleAddr, HEX);
    Serial.println(F("\"}"));
  } else {
    errors++;
  }
}

void clearDTCs(uint32_t moduleAddr) {
  struct can_frame frame;
  
  // OBD-II Mode 04 (Clear DTCs)
  frame.can_id = moduleAddr;
  frame.can_dlc = 8;
  frame.data[0] = 0x01; // Number of bytes
  frame.data[1] = 0x04; // Mode 04 (Clear DTCs)
  frame.data[2] = 0x00;
  frame.data[3] = 0x00;
  frame.data[4] = 0x00;
  frame.data[5] = 0x00;
  frame.data[6] = 0x00;
  frame.data[7] = 0x00;
  
  if (mcp2515.sendMessage(&frame) == MCP2515::ERROR_OK) {
    messagesSent++;
    Serial.print(F("{\"status\":\"dtc_clear_sent\",\"module\":\"0x"));
    Serial.print(moduleAddr, HEX);
    Serial.println(F("\"}"));
  } else {
    errors++;
  }
}

void startLogging() {
  if (!sdInitialized) {
    Serial.println(F("{\"error\":\"sd_not_initialized\"}"));
    return;
  }
  
  // Create log filename with timestamp
  char filename[32];
  sprintf(filename, "can_%lu.csv", millis());
  
  logFile = SD.open(filename, FILE_WRITE);
  
  if (logFile) {
    loggingEnabled = true;
    
    // Write CSV header
    logFile.println(F("Timestamp,ID,DLC,Data"));
    logFile.flush();
    
    Serial.print(F("{\"status\":\"logging_started\",\"file\":\""));
    Serial.print(filename);
    Serial.println(F("\"}"));
  } else {
    Serial.println(F("{\"error\":\"failed_to_create_log_file\"}"));
  }
}

void stopLogging() {
  if (loggingEnabled && logFile) {
    logFile.flush();
    logFile.close();
    loggingEnabled = false;
    Serial.println(F("{\"status\":\"logging_stopped\"}"));
  }
}

void sendHeartbeat() {
  unsigned long now = millis();
  
  if (now - lastHeartbeat >= HEARTBEAT_INTERVAL) {
    Serial.print(F("{\"type\":\"heartbeat\",\"uptime\":"));
    Serial.print(now);
    Serial.print(F(",\"rx\":"));
    Serial.print(messagesReceived);
    Serial.print(F(",\"tx\":"));
    Serial.print(messagesSent);
    Serial.print(F(",\"errors\":"));
    Serial.print(errors);
    Serial.println(F("}"));
    
    lastHeartbeat = now;
  }
}

void printHelp() {
  Serial.println(F("\n=== COMMAND REFERENCE ==="));
  Serial.println(F("HELP         - Show this help"));
  Serial.println(F("STATUS       - Show system status"));
  Serial.println(F("START        - Start CAN monitoring"));
  Serial.println(F("STOP         - Stop CAN monitoring"));
  Serial.println(F("SCANVIN      - Scan all modules for VINs"));
  Serial.println(F("GETVIN:7E0   - Request VIN from module (hex address)"));
  Serial.println(F("READDTC:7E0  - Read DTCs from module"));
  Serial.println(F("CLEARDTC:7E0 - Clear DTCs from module"));
  Serial.println(F("LOGSTART     - Start logging to SD card"));
  Serial.println(F("LOGSTOP      - Stop logging"));
  Serial.println(F("RESET        - Reset statistics"));
  Serial.println(F("========================\n"));
}

void printStatus() {
  Serial.println(F("\n=== SYSTEM STATUS ==="));
  Serial.print(F("CAN Bus: "));
  Serial.println(canInitialized ? F("OK") : F("FAILED"));
  Serial.print(F("SD Card: "));
  Serial.println(sdInitialized ? F("OK") : F("NOT FOUND"));
  Serial.print(F("Monitoring: "));
  Serial.println(monitoringEnabled ? F("ENABLED") : F("DISABLED"));
  Serial.print(F("Logging: "));
  Serial.println(loggingEnabled ? F("ENABLED") : F("DISABLED"));
  Serial.print(F("Uptime: "));
  Serial.print(millis() / 1000);
  Serial.println(F(" seconds"));
  Serial.print(F("Messages RX: "));
  Serial.println(messagesReceived);
  Serial.print(F("Messages TX: "));
  Serial.println(messagesSent);
  Serial.print(F("Errors: "));
  Serial.println(errors);
  Serial.println(F("====================\n"));
}

void blinkLED(int times, int delayMs) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_PIN, HIGH);
    delay(delayMs);
    digitalWrite(LED_PIN, LOW);
    delay(delayMs);
  }
}

