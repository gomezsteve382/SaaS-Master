# DARKVIN LABS - Arduino CAN Bus Sniffer Setup

## Hardware Requirements

### Components Needed
1. **Arduino Board** (Uno, Mega, or Nano)
2. **MCP2515 CAN Bus Module** with TJA1050 transceiver
3. **OBD-II to DB9 Cable** or direct wiring to OBD-II connector
4. **USB Cable** (Arduino to PC)

### Wiring Diagram

```
MCP2515 Module    →    Arduino
─────────────────────────────────
VCC               →    5V
GND               →    GND
CS                →    D10
SO (MISO)         →    D12
SI (MOSI)         →    D11
SCK               →    D13
INT               →    D2

MCP2515 CAN       →    Vehicle OBD-II
─────────────────────────────────
CAN-H             →    Pin 6
CAN-L             →    Pin 14
GND               →    Pin 4 or 5
```

## Software Setup

### 1. Install Arduino IDE
Download from: https://www.arduino.cc/en/software

### 2. Install MCP2515 Library
1. Open Arduino IDE
2. Go to **Sketch → Include Library → Manage Libraries**
3. Search for **"mcp2515"** by autowp
4. Click **Install**

### 3. Upload Firmware
1. Open `can_sniffer.ino` in Arduino IDE
2. Select your Arduino board: **Tools → Board**
3. Select COM port: **Tools → Port**
4. Click **Upload** button (→)
5. Wait for "Done uploading" message

### 4. Verify Installation
1. Open Serial Monitor: **Tools → Serial Monitor**
2. Set baud rate to **500000**
3. You should see:
   ```
   DARKVIN LABS CAN Sniffer v1.0
   READY
   ```

## Usage

### Web Interface
1. Go to **CAN Bus Monitor** in DARKVIN LABS toolkit
2. Click **"Connect to CAN Interface"**
3. Select your Arduino from the list
4. Click **"Start Monitoring"**

### Supported Commands

The Arduino firmware responds to these commands:

| Command | Description |
|---------|-------------|
| `START_CAN_MONITOR` | Begin passive CAN bus monitoring |
| `STOP_CAN_MONITOR` | Stop monitoring |
| `REQUEST_VIN:7E3` | Request VIN from ECU (e.g., BCM at 0x7E3) |
| `REQUEST_PART:7E3` | Request part number from ECU |
| `REQUEST_SW:7E3` | Request software version from ECU |
| `SCAN_MODULES` | Scan all common modules |
| `GET_STATUS` | Get current status |

### ECU Addresses (Dodge/Chrysler/FCA)

| Module | Request ID | Response ID |
|--------|-----------|-------------|
| ECM (Engine) | 0x7E0 | 0x7E8 |
| TCM (Transmission) | 0x7E1 | 0x7E9 |
| ABS | 0x7E2 | 0x7EA |
| BCM (Body) | 0x7E3 | 0x7EB |
| RFHUB (RF Hub) | 0x7E4 | 0x7EC |
| CGW (Gateway) | 0x7E5 | 0x7ED |

## Vehicle Connection

### Safety Precautions
⚠️ **IMPORTANT:**
- Never disconnect while vehicle is running
- Ensure proper grounding
- Use 12V power protection if needed
- Double-check wiring before connecting

### Connection Steps
1. **Turn OFF vehicle ignition**
2. Connect MCP2515 CAN-H to OBD-II pin 6
3. Connect MCP2515 CAN-L to OBD-II pin 14
4. Connect GND to OBD-II pin 4 or 5
5. Connect Arduino to PC via USB
6. **Turn ON vehicle ignition** (engine can stay off)
7. Wait 5 seconds for modules to initialize
8. Start monitoring in web interface

## Troubleshooting

### No CAN Messages
- Check CAN-H and CAN-L connections
- Verify vehicle ignition is ON
- Try different baud rate (some vehicles use 250 kbps)
- Check MCP2515 crystal frequency (8MHz or 16MHz)

### Connection Failed
- Ensure correct COM port selected
- Check USB cable connection
- Verify baud rate is 500000
- Try different USB port

### Garbled Data
- Check baud rate in Serial Monitor (must be 500000)
- Verify MCP2515 library is installed correctly
- Check SPI connections (MISO, MOSI, SCK)

### No Response from ECU
- Vehicle must be in ignition ON state
- Some modules require diagnostic session activation
- Try scanning multiple times (modules may be sleeping)

## Advanced Configuration

### Change CAN Bus Speed
Edit line 77 in `can_sniffer.ino`:
```cpp
mcp2515.setBitrate(CAN_500KBPS, MCP_8MHZ);
```

Options:
- `CAN_250KBPS` - Some older vehicles
- `CAN_500KBPS` - Most Dodge/Chrysler vehicles
- `CAN_1000KBPS` - High-speed CAN

### Change Crystal Frequency
If your MCP2515 has 16MHz crystal:
```cpp
mcp2515.setBitrate(CAN_500KBPS, MCP_16MHZ);
```

## Data Format

### CAN Message Format
```
ID:7E8,DLC:8,DATA:02,62,F1,90,31,47,31,4A
```
- **ID**: CAN identifier (hex)
- **DLC**: Data length (0-8 bytes)
- **DATA**: Payload bytes (hex, comma-separated)

### UDS Response Format
```
[Length, Service+0x40, DID_High, DID_Low, Data...]
```

Example VIN response:
```
ID:7EB,DLC:8,DATA:10,14,62,F1,90,32,43,33
```
- `10` = First frame (multi-frame response)
- `14` = Total length (20 bytes)
- `62` = Read Data response (0x22 + 0x40)
- `F190` = VIN DID
- `32,43,33...` = VIN characters (ASCII)

## Support

For issues or questions:
- Check wiring connections
- Verify vehicle compatibility
- Review Arduino Serial Monitor output
- Contact DARKVIN LABS support

## License

© 2025 DARKVIN LABS. For authorized use only.

