# 🔥 DARKVIN LABS - Arduino Setup Guide

**For Arduino Uno R3 + Seeed Studio CAN-Bus Shield V2**

---

## ✅ What You Have

Perfect hardware setup:
- **Arduino Uno R3** - ATmega328P microcontroller
- **Seeed Studio CAN-Bus Shield V2** - MCP2515 CAN controller + SN65HVD230 transceiver
- **OBD2 cable** - 16-pin connector

**This is professional-grade CAN hardware!**

---

## 📦 Step 1: Install Arduino IDE

### **Download:**
- https://www.arduino.cc/en/software
- Get version 2.x (latest)

### **Install on:**
- **Windows:** Run installer
- **Mac:** Drag to Applications
- **Linux:** `sudo apt-get install arduino`

---

## 📚 Step 2: Install Required Libraries

### **In Arduino IDE:**

1. **Open Library Manager:**
   - Tools → Manage Libraries...

2. **Install "Seeed CAN Bus Shield" library:**
   - Search: "mcp2515"
   - Install: **"Seeed CAN Bus Shield"** by Seeed Studio
   - Version: Latest (2.x)

### **Alternative (Manual Install):**

```bash
cd ~/Arduino/libraries/
git clone https://github.com/Seeed-Studio/Seeed_Arduino_CAN.git
```

---

## 🔌 Step 3: Hardware Setup

### **Connect Arduino:**

1. **Stack the CAN-Bus Shield on Arduino Uno**
   - Align pins carefully
   - Press down firmly

2. **Set jumpers on CAN-Bus Shield:**
   - **CS pin:** Set to D9 (default for Shield V2)
   - **Termination:** 120Ω ON if you're the only device

3. **Connect OBD2 cable:**
   - **CAN_H** → Pin 6 on OBD2 (Yellow/Green wire)
   - **CAN_L** → Pin 14 on OBD2 (Yellow/Brown wire)
   - **GND** → Pin 4 or 5 on OBD2 (Black wire)
   - **+12V** → Pin 16 on OBD2 (Red wire) - **OPTIONAL** (for shield power)

### **OBD2 Pinout:**
```
     1  2  3  4  5  6  7  8
    ┌─┬─┬─┬─┬─┬─┬─┬─┐
    │ │ │ │G│ │H│ │ │
    └─┴─┴─┴─┴─┴─┴─┴─┘
     9 10 11 12 13 14 15 16
    ┌─┬─┬─┬─┬─┬─┬─┬─┐
    │ │ │ │ │ │L│ │+│
    └─┴─┴─┴─┴─┴─┴─┴─┘

Pin 4/5: Ground
Pin 6: CAN_H (High)
Pin 14: CAN_L (Low)
Pin 16: +12V (Battery)
```

---

## 💾 Step 4: Upload Firmware

### **Open Firmware:**

1. In Arduino IDE:
   - File → Open...
   - Navigate to: `rfhub-bcm-toolkit/arduino/darkvin_can_bridge/darkvin_can_bridge.ino`

2. **Select Board:**
   - Tools → Board → Arduino AVR Boards → Arduino Uno

3. **Select Port:**
   - Tools → Port → /dev/ttyACM0 (Linux/Mac)
   - Tools → Port → COM3 (Windows)

4. **Upload:**
   - Click Upload button (→)
   - Wait for "Done uploading"

### **Verify Upload:**

1. Open Serial Monitor:
   - Tools → Serial Monitor
   - Set baud rate: **115200**

2. You should see:
   ```
   DARKVIN LABS CAN Bridge v1.0
   Arduino Uno R3 + Seeed CAN-Bus Shield V2
   READY
   ```

---

## 🚗 Step 5: Test With Vehicle

### **Connect to Vehicle:**

1. **Plug OBD2 cable into vehicle**
2. **Turn ignition to ON** (don't start engine)
3. **Arduino should power up** (if using +12V from OBD2)

### **Test CAN Communication:**

In Serial Monitor, type:
```
ATZ
```

Should respond:
```
DARKVIN LABS CAN Bridge v1.0
OK
```

### **Send Test CAN Message:**

```
TX:7E0:0222F190
```

This requests VIN from BCM. You should see response:
```
OK
RX:7E8:10144962F1903...
```

---

## 🔥 Step 6: Use With DARKVIN LABS Toolkit

### **On Your Computer:**

```bash
# Check Arduino is connected
ls /dev/ttyACM*
# Should show: /dev/ttyACM0

# Run toolkit
cd /home/ubuntu/rfhub-bcm-toolkit
python3 toolkit/universal_module_reader.py \
  --interface arduino \
  --channel /dev/ttyACM0 \
  --module BCM
```

### **Expected Output:**
```
[+] Connecting to Arduino on /dev/ttyACM0...
[+] DARKVIN LABS CAN Bridge v1.0
[+] Arduino Uno R3 + Seeed CAN-Bus Shield V2
[+] READY
[+] Reading module: BCM
[+] Sending: 10 02 (DiagnosticSessionControl)
[+] Response: 50 02
[+] Sending: 22 F1 90 (ReadDataByIdentifier - VIN)
[+] Response: 62 F1 90 32 42 33 43 4A 34 44 56 36 41 48 33 30 30 35 34 39
[+] VIN: 2B3CJ4DV6AH300549
```

---

## 🛠️ Troubleshooting

### **Problem: "CAN init failed!"**

**Solution:**
- Check shield is properly seated on Arduino
- Verify jumper on D9
- Check OBD2 cable connections
- Ensure vehicle ignition is ON

### **Problem: "No response from module"**

**Solution:**
- Verify CAN_H and CAN_L are correct
- Check vehicle uses 500kbps CAN (most do)
- Try 250kbps: Edit firmware line 14 to `CAN_250KBPS`
- Enable 120Ω termination resistor

### **Problem: "Arduino not detected"**

**Solution:**
- Install CH340 drivers (if using clone Arduino)
- Check USB cable (must be data cable, not charge-only)
- Try different USB port
- Linux: Add user to dialout group: `sudo usermod -a -G dialout $USER`

### **Problem: "Permission denied /dev/ttyACM0"**

**Solution (Linux):**
```bash
sudo chmod 666 /dev/ttyACM0
# Or permanently:
sudo usermod -a -G dialout $USER
# Then logout and login
```

---

## 📊 Advanced: SocketCAN Mode

Want to use Arduino as native Linux CAN interface?

### **Install slcand:**
```bash
sudo apt-get install can-utils
```

### **Create virtual CAN interface:**
```bash
# Attach Arduino to slcan
sudo slcand -o -c -s6 /dev/ttyACM0 can0

# Bring up interface
sudo ip link set can0 up

# Test
candump can0
```

### **Use with toolkit:**
```bash
python3 toolkit/universal_module_reader.py \
  --interface socketcan \
  --channel can0 \
  --module BCM
```

---

## 🎯 What You Can Do Now

✅ **Read VINs** from any module
✅ **Read SKIM keys** from immobilizer
✅ **Read DTCs** (diagnostic trouble codes)
✅ **Write VINs** to modules
✅ **Capture CAN traffic** with Wireshark
✅ **Module diagnostics** (all ECUs)

---

## 📝 Notes

**CAN Bitrates:**
- Most vehicles: **500kbps** (default)
- Some older: **250kbps**
- High-speed: **1Mbps** (rare)

**Module CAN IDs:**
- BCM: 0x7E0 (TX) / 0x7E8 (RX)
- ECM: 0x7E0 (TX) / 0x7E8 (RX)
- TCM: 0x7E1 (TX) / 0x7E9 (RX)
- ABS: 0x7E2 (TX) / 0x7EA (RX)

**Safety:**
- Never disconnect while vehicle is running
- Don't send random CAN messages
- Always test in mock mode first

---

**You're ready to program VINs with your Arduino!** 🔥

