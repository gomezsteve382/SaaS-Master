# 🔥 Arduino Integration with DARKVIN LABS Toolkit

**How to use your Arduino Uno R3 + Seeed CAN-Bus Shield V2 with the toolkit**

---

## 🎯 Overview

Your Arduino becomes a **professional CAN interface** that works with all DARKVIN LABS tools:

- ✅ Live VIN reading/writing via OBD2
- ✅ Module diagnostics (BCM, ECM, TCM, etc.)
- ✅ CAN traffic monitoring
- ✅ Security byte extraction
- ✅ Universal module reader

**Cost:** $0 (you already have the hardware!)
**Alternative:** Mongoose Pro J2534 ($350+)

---

## 🔌 Hardware Connection

### **Physical Setup:**

```
Arduino Uno R3
    ↓ (stacked)
Seeed CAN-Bus Shield V2
    ↓ (OBD2 cable)
Vehicle OBD2 Port
```

### **OBD2 Wiring:**

| OBD2 Pin | Signal | Wire Color | Shield Connection |
|----------|--------|------------|-------------------|
| 6 | CAN_H | Yellow/Green | CAN_H terminal |
| 14 | CAN_L | Yellow/Brown | CAN_L terminal |
| 4 or 5 | Ground | Black | GND terminal |
| 16 | +12V | Red | VCC (optional) |

**Note:** Pin 16 (+12V) is optional - Arduino can be powered via USB from laptop.

---

## 💻 Software Setup

### **1. Upload Firmware:**

See `ARDUINO_SETUP_GUIDE.md` for detailed instructions.

**Quick version:**
```bash
# Open in Arduino IDE
arduino/darkvin_can_bridge/darkvin_can_bridge.ino

# Select: Tools → Board → Arduino Uno
# Select: Tools → Port → /dev/ttyACM0
# Click: Upload
```

### **2. Verify Connection:**

```bash
# Check Arduino is connected
ls /dev/ttyACM*
# Should show: /dev/ttyACM0 (or COM3 on Windows)

# Test communication
screen /dev/ttyACM0 115200
# Type: ATZ
# Should respond: DARKVIN LABS CAN Bridge v1.0
```

---

## 🚀 Using With Toolkit

### **Method 1: Python Scripts (Direct)**

```bash
cd /home/ubuntu/rfhub-bcm-toolkit/toolkit

# Read VIN from BCM
python3 uds_vin_reader.py \
  --interface arduino \
  --channel /dev/ttyACM0 \
  --module BCM

# Write VIN to BCM
python3 uds_vin_writer.py \
  --interface arduino \
  --channel /dev/ttyACM0 \
  --module BCM \
  --vin 2B3CJ5DT2BH590794

# Universal module reader
python3 universal_module_reader.py \
  --interface arduino \
  --channel /dev/ttyACM0 \
  --module BCM
```

### **Method 2: Web Interface**

1. **Open OBD2 Diagnostics page** in DARKVIN LABS web interface
2. **Click "Detect Hardware"** button
3. **Select your Arduino** from detected devices
4. **Choose module** (BCM, ECM, RFHUB, etc.)
5. **Click "Read VIN"** or **"Write VIN"**

The web interface automatically handles all communication!

---

## 📊 Protocol Details

### **Command Format:**

Arduino uses simple text protocol over serial (115200 baud):

**Send CAN message:**
```
TX:7E0:0222F190
```
- `TX:` = Transmit command
- `7E0` = CAN ID (hex)
- `0222F190` = Data bytes (hex)

**Receive CAN message:**
```
RX:7E8:10144962F1903...
```
- `RX:` = Received message
- `7E8` = CAN ID (hex)
- `10144962F1903...` = Data bytes (hex)

### **AT Commands (ELM327 Compatibility):**

```
ATZ         - Reset device
AT@1        - Device description
ATSP6       - Set protocol (ISO 15765-4 CAN)
ATE0        - Echo off
ATL0        - Linefeeds off
ATH1        - Headers on
```

All AT commands respond with `OK`.

---

## 🔧 Troubleshooting

### **Problem: No CAN messages received**

**Check:**
1. Vehicle ignition is ON
2. OBD2 cable is fully inserted
3. CAN_H and CAN_L are correct (not swapped)
4. Shield jumper is on D9
5. Try enabling 120Ω termination resistor

**Test:**
```bash
# In Serial Monitor, send:
TX:7DF:0201000000000000
# This is a broadcast request for PIDs
# Should get responses from multiple modules
```

### **Problem: "Permission denied" on /dev/ttyACM0**

**Linux:**
```bash
sudo chmod 666 /dev/ttyACM0
# Or add user to dialout group:
sudo usermod -a -G dialout $USER
# Then logout and login
```

**Windows:**
- Check Device Manager
- Update CH340 drivers if needed

### **Problem: CAN init failed**

**Solutions:**
1. Check shield is properly seated
2. Verify MCP2515 library is installed
3. Try different CAN bitrate (250kbps vs 500kbps)
4. Check 5V power supply to shield

---

## 🎯 Supported Operations

### **✅ What Works:**

| Operation | Status | Notes |
|-----------|--------|-------|
| Read VIN | ✅ | All modules |
| Write VIN | ✅ | BCM, ECM, RFHUB |
| Read DTCs | ✅ | All modules |
| Clear DTCs | ✅ | All modules |
| Security unlock | ✅ | SBEC2/SBEC3 algorithm |
| Module diagnostics | ✅ | 30+ DIDs |
| CAN monitoring | ✅ | Real-time traffic |
| Wireshark capture | ✅ | Via socketcan mode |

### **⚠️ Limitations:**

- **Speed:** Slower than J2534 (but works fine for VIN programming)
- **Protocols:** CAN only (no K-Line, LIN, FlexRay)
- **Simultaneous:** One module at a time
- **Buffer:** 8-byte CAN frames only

---

## 🚗 Real Vehicle Testing

### **Before First Use:**

1. ✅ Test in mock mode first
2. ✅ Verify firmware uploaded correctly
3. ✅ Check all connections
4. ✅ Have backup of original module files

### **Safety Checklist:**

- [ ] Vehicle in PARK with parking brake
- [ ] Ignition ON, engine OFF
- [ ] Battery voltage > 12V
- [ ] No other devices connected to OBD2
- [ ] Laptop fully charged (don't rely on car power)

### **First Test (Safe):**

```bash
# Read VIN only (non-destructive)
python3 uds_vin_reader.py \
  --interface arduino \
  --channel /dev/ttyACM0 \
  --module BCM
```

If this works, you're ready for VIN programming!

---

## 📈 Performance

**Typical timings:**

| Operation | Time | Notes |
|-----------|------|-------|
| Read VIN | 2-5 sec | Single DID |
| Write VIN | 10-15 sec | Full UDS sequence |
| Module scan | 30-60 sec | All DIDs |
| CAN capture | Real-time | ~100 msg/sec |

**Comparison:**

| Device | Cost | Speed | Protocols |
|--------|------|-------|-----------|
| Arduino + Shield | ~$50 | Medium | CAN only |
| ELM327 USB | ~$20 | Slow | CAN, ISO9141 |
| Mongoose Pro | $350+ | Fast | All protocols |

---

## 🔥 Advanced: SocketCAN Mode

Convert Arduino to native Linux CAN interface:

```bash
# Install can-utils
sudo apt-get install can-utils

# Attach Arduino to slcan
sudo slcand -o -c -s6 /dev/ttyACM0 can0

# Bring up interface
sudo ip link set can0 up

# Monitor traffic
candump can0

# Send message
cansend can0 7E0#0222F190

# Use with toolkit
python3 uds_vin_reader.py \
  --interface socketcan \
  --channel can0 \
  --module BCM
```

**Benefits:**
- Native Linux CAN support
- Works with Wireshark
- Standard can-utils commands
- Better performance

---

## 📚 Next Steps

1. **Upload firmware** (see ARDUINO_SETUP_GUIDE.md)
2. **Test with vehicle** (read VIN first)
3. **Try VIN programming** (backup first!)
4. **Explore other modules** (ECM, TCM, ABS, etc.)

---

**You now have a professional CAN interface for $0!** 🔥

No need to buy expensive J2534 tools - your Arduino does everything you need for VIN programming and module diagnostics.

