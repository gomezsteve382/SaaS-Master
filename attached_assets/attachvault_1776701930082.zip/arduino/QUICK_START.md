# ⚡ Arduino Quick Start - 5 Minutes to VIN Programming

**Get your Arduino working with DARKVIN LABS in 5 minutes!**

---

## 🎯 What You Need

- ✅ Arduino Uno R3
- ✅ Seeed Studio CAN-Bus Shield V2
- ✅ OBD2 cable
- ✅ USB cable (Arduino to laptop)
- ✅ Vehicle with OBD2 port (1996+)

---

## ⚡ 5-Minute Setup

### **Step 1: Install Arduino IDE (2 min)**

Download from: https://www.arduino.cc/en/software

### **Step 2: Install Library (1 min)**

In Arduino IDE:
1. Tools → Manage Libraries
2. Search: "mcp2515"
3. Install: "Seeed CAN Bus Shield"

### **Step 3: Upload Firmware (1 min)**

1. Open: `arduino/darkvin_can_bridge/darkvin_can_bridge.ino`
2. Select: Tools → Board → Arduino Uno
3. Select: Tools → Port → /dev/ttyACM0 (or COM3)
4. Click: Upload (→ button)

### **Step 4: Connect Hardware (1 min)**

```
1. Stack shield on Arduino
2. Connect OBD2 cable:
   - CAN_H → Pin 6 (Yellow/Green)
   - CAN_L → Pin 14 (Yellow/Brown)
   - GND → Pin 4 (Black)
3. Plug into vehicle OBD2 port
4. Turn ignition ON
```

---

## 🚀 First Test

### **Open Serial Monitor:**

Tools → Serial Monitor (set to 115200 baud)

**You should see:**
```
DARKVIN LABS CAN Bridge v1.0
Arduino Uno R3 + Seeed CAN-Bus Shield V2
READY
```

### **Send Test Command:**

Type in Serial Monitor:
```
ATZ
```

**Should respond:**
```
DARKVIN LABS CAN Bridge v1.0
OK
```

**✅ If you see this, your Arduino is working!**

---

## 🔥 Read Your First VIN

### **In Serial Monitor, type:**

```
TX:7E0:0222F190
```

**You should see:**
```
OK
RX:7E8:10144962F1903...
RX:7E8:21...
RX:7E8:22...
```

**This is your vehicle's VIN!** The toolkit will decode it automatically.

---

## 💻 Use With Web Interface

1. **Open DARKVIN LABS** in browser
2. **Go to:** OBD2 Diagnostics
3. **Click:** "Detect Hardware"
4. **Select:** Your Arduino
5. **Click:** "Read VIN"

**Done!** The web interface handles everything automatically.

---

## 🛠️ Troubleshooting

### **Problem: "CAN init failed!"**

**Fix:**
- Check shield is fully seated on Arduino
- Verify jumper is on D9
- Try re-uploading firmware

### **Problem: No response from vehicle**

**Fix:**
- Turn ignition to ON position
- Check OBD2 cable connections
- Verify CAN_H and CAN_L are correct

### **Problem: Permission denied**

**Linux:**
```bash
sudo chmod 666 /dev/ttyACM0
```

**Windows:**
- Install CH340 drivers
- Check Device Manager

---

## 📚 Full Documentation

- **Complete setup:** `ARDUINO_SETUP_GUIDE.md`
- **Integration guide:** `ARDUINO_INTEGRATION.md`
- **Firmware source:** `darkvin_can_bridge/darkvin_can_bridge.ino`

---

## 🎯 What's Next?

Now you can:

✅ **Read VINs** from any module
✅ **Write VINs** to BCM/ECM/RFHUB
✅ **Extract SKIM keys** from immobilizer
✅ **Read DTCs** from all modules
✅ **Monitor CAN traffic** in real-time
✅ **Diagnose modules** with Universal Reader

**All with your $50 Arduino setup!**

No need for $350 Mongoose Pro or dealer tools.

---

**Ready to rewrite identities?** 🔥

