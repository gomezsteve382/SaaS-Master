/*
 * RED KEY Transponder Reader for Chrysler/Dodge/Jeep/RAM
 * 
 * Hardware: Arduino Uno/Mega + RDM6300 125kHz RFID Reader
 * Purpose: Read transponder ID from RED KEY FOBs for cloning/analysis
 * 
 * Wiring:
 * RDM6300 VCC  -> Arduino 5V
 * RDM6300 GND  -> Arduino GND
 * RDM6300 TX   -> Arduino Pin 2 (Software Serial RX)
 * 
 * Output: Transponder ID in hex format (8-10 bytes)
 * Compatible with: SRT Lab RFHUB PIN Extractor
 * 
 * Author: The SRT Lab
 * Version: 1.0
 */

#include <SoftwareSerial.h>

// RDM6300 connected to Pin 2 (RX), Pin 3 (TX - unused)
SoftwareSerial rfid(2, 3);

// Buffer for RFID data
byte rfidData[14];
int dataIndex = 0;

// Timing
unsigned long lastReadTime = 0;
const unsigned long READ_INTERVAL = 2000; // 2 seconds between reads

// LED indicator (optional - use built-in LED)
const int LED_PIN = 13;

void setup() {
  // Initialize serial communications
  Serial.begin(9600);
  rfid.begin(9600);
  
  // Setup LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  
  // Print header
  Serial.println("========================================");
  Serial.println("RED KEY Transponder Reader v1.0");
  Serial.println("The SRT Lab - Professional Diagnostic Tool");
  Serial.println("========================================");
  Serial.println();
  Serial.println("Place RED KEY FOB on antenna...");
  Serial.println("Listening for 125 kHz transponder signal...");
  Serial.println();
  
  // Blink LED to indicate ready
  blinkLED(3, 200);
}

void loop() {
  // Check if data available from RDM6300
  if (rfid.available()) {
    byte inByte = rfid.read();
    
    // RDM6300 protocol: Start byte 0x02, End byte 0x03
    if (inByte == 0x02) {
      // Start of transmission
      dataIndex = 0;
      rfidData[dataIndex++] = inByte;
    }
    else if (dataIndex > 0) {
      // Collecting data
      rfidData[dataIndex++] = inByte;
      
      // Check for end byte
      if (inByte == 0x03 && dataIndex >= 14) {
        // Complete transmission received
        processRFIDData();
        dataIndex = 0;
      }
      
      // Prevent buffer overflow
      if (dataIndex >= 14) {
        dataIndex = 0;
      }
    }
  }
}

void processRFIDData() {
  // Debounce - prevent multiple reads of same tag
  unsigned long currentTime = millis();
  if (currentTime - lastReadTime < READ_INTERVAL) {
    return; // Too soon, ignore
  }
  lastReadTime = currentTime;
  
  // Blink LED to indicate read
  digitalWrite(LED_PIN, HIGH);
  
  // RDM6300 data format (14 bytes total):
  // [0]    = 0x02 (STX - Start of Text)
  // [1-10] = 10 ASCII hex characters (5 bytes of data)
  // [11-12]= 2 ASCII hex characters (checksum)
  // [13]   = 0x03 (ETX - End of Text)
  
  // Extract transponder ID (bytes 1-10)
  byte transponderID[5];
  for (int i = 0; i < 5; i++) {
    transponderID[i] = hexCharToByte(rfidData[i*2 + 1], rfidData[i*2 + 2]);
  }
  
  // Extract checksum (bytes 11-12)
  byte receivedChecksum = hexCharToByte(rfidData[11], rfidData[12]);
  
  // Calculate expected checksum (XOR of all data bytes)
  byte calculatedChecksum = 0;
  for (int i = 0; i < 5; i++) {
    calculatedChecksum ^= transponderID[i];
  }
  
  // Verify checksum
  bool checksumValid = (receivedChecksum == calculatedChecksum);
  
  // Print results
  Serial.println("========================================");
  Serial.println("🔴 RED KEY DETECTED!");
  Serial.println("========================================");
  Serial.println();
  
  // Print transponder ID
  Serial.print("Transponder ID: ");
  for (int i = 0; i < 5; i++) {
    if (transponderID[i] < 0x10) Serial.print("0");
    Serial.print(transponderID[i], HEX);
    Serial.print(" ");
  }
  Serial.println();
  
  // Print full 10-byte extended format (for Chrysler FOBIK)
  Serial.print("Extended ID:    ");
  for (int i = 0; i < 5; i++) {
    if (transponderID[i] < 0x10) Serial.print("0");
    Serial.print(transponderID[i], HEX);
    Serial.print(" ");
  }
  // Chrysler FOBs often have additional bytes
  Serial.println("(+ 3 bytes secret key - requires deeper read)");
  
  // Print checksum status
  Serial.print("Checksum:       ");
  if (receivedChecksum < 0x10) Serial.print("0");
  Serial.print(receivedChecksum, HEX);
  Serial.print(" [");
  Serial.print(checksumValid ? "VALID ✓" : "INVALID ✗");
  Serial.println("]");
  
  // Print raw data
  Serial.print("Raw Data:       ");
  for (int i = 0; i < 14; i++) {
    if (rfidData[i] < 0x10) Serial.print("0");
    Serial.print(rfidData[i], HEX);
    Serial.print(" ");
  }
  Serial.println();
  
  // Print file export format
  Serial.println();
  Serial.println("--- COPY THIS FOR SRT LAB UPLOAD ---");
  for (int i = 0; i < 5; i++) {
    if (transponderID[i] < 0x10) Serial.print("0");
    Serial.print(transponderID[i], HEX);
    if (i < 4) Serial.print(" ");
  }
  Serial.println();
  Serial.println("--- END ---");
  Serial.println();
  
  // Instructions
  Serial.println("Next Steps:");
  Serial.println("1. Copy the hex data above");
  Serial.println("2. Save to RED_KEY_DUMP.txt");
  Serial.println("3. Upload to SRT Lab RFHUB PIN Extractor");
  Serial.println("4. Extract PIN and program new keys");
  Serial.println();
  Serial.println("Place next FOB on antenna...");
  Serial.println();
  
  // LED off
  digitalWrite(LED_PIN, LOW);
}

// Convert two ASCII hex characters to a byte
byte hexCharToByte(byte high, byte low) {
  return (asciiHexToNibble(high) << 4) | asciiHexToNibble(low);
}

// Convert ASCII hex character to nibble (0-15)
byte asciiHexToNibble(byte c) {
  if (c >= '0' && c <= '9') {
    return c - '0';
  }
  else if (c >= 'A' && c <= 'F') {
    return c - 'A' + 10;
  }
  else if (c >= 'a' && c <= 'f') {
    return c - 'a' + 10;
  }
  return 0;
}

// Blink LED indicator
void blinkLED(int times, int delayMs) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_PIN, HIGH);
    delay(delayMs);
    digitalWrite(LED_PIN, LOW);
    delay(delayMs);
  }
}
