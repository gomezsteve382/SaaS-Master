# RED KEY Transponder Reader - Hardware Setup Guide

## Overview

This guide shows you how to build a DIY transponder reader for Chrysler/Dodge/Jeep/RAM RED KEY FOBs using Arduino and an RDM6300 RFID module.

**Total Cost:** ~$20-30 (vs $300+ for commercial readers)

---

## Hardware Components

### Required Parts

| Component | Specs | Price | Source |
|-----------|-------|-------|--------|
| Arduino Uno/Mega | ATmega328P or ATmega2560 | $10-25 | Amazon, AliExpress |
| RDM6300 RFID Reader | 125 kHz, UART output | $5-8 | Amazon, eBay |
| Jumper Wires | Male-to-male | $2 | Any electronics store |
| USB Cable | Type A to Type B | $3 | Included with Arduino |
| Breadboard (optional) | Half-size | $3 | For prototyping |

**Total:** $23-41

### Optional Components

| Component | Purpose | Price |
|-----------|---------|-------|
| Buzzer | Audio feedback | $1 |
| LED | Visual indicator | $0.50 |
| 220Ω Resistor | LED current limiting | $0.10 |
| Project Box | Enclosure | $5 |

---

## RDM6300 RFID Reader Module

### Specifications

- **Frequency:** 125 kHz (Low Frequency)
- **Protocol:** EM4100 compatible
- **Read Distance:** 2-5 cm (0.8-2 inches)
- **Output:** UART/TTL (9600 baud)
- **Power:** 5V DC, 50mA
- **Dimensions:** 38.5mm × 19mm × 9mm

### Pinout

```
┌─────────────────┐
│   RDM6300       │
│                 │
│  [Antenna Coil] │
│                 │
│  VCC GND TX RX  │
└──┬───┬───┬───┬──┘
   │   │   │   │
   │   │   │   └── Not used (leave disconnected)
   │   │   └────── Data output (connect to Arduino RX)
   │   └────────── Ground (connect to Arduino GND)
   └────────────── Power (connect to Arduino 5V)
```

---

## Wiring Diagram

### Basic Setup (Arduino Uno)

```
RDM6300          Arduino Uno
───────          ───────────
VCC    ────────> 5V
GND    ────────> GND
TX     ────────> Pin 2 (Digital)
RX     ────────> (Not connected)

Optional:
LED (+) ───[220Ω]──> Pin 13
LED (-) ──────────> GND

Buzzer (+) ───────> Pin 8
Buzzer (-) ───────> GND
```

### Schematic

```
         +5V
          │
          ├────────────┐
          │            │
      ┌───┴───┐    ┌───┴───┐
      │ VCC   │    │ LED   │
      │RDM6300│    │  (+)  │
      │  TX   ├────┤Pin 13 │
      │ GND   │    │  (-)  │
      └───┬───┘    └───┬───┘
          │            │
          └────────────┴──── GND
          
Arduino Pin 2 ────> RDM6300 TX
```

---

## Assembly Instructions

### Step 1: Prepare Components

1. Unpack Arduino Uno
2. Unpack RDM6300 module
3. Gather 3 jumper wires (red, black, yellow)

### Step 2: Connect Power

1. Connect **RDM6300 VCC** (red wire) to **Arduino 5V**
2. Connect **RDM6300 GND** (black wire) to **Arduino GND**

### Step 3: Connect Data

1. Connect **RDM6300 TX** (yellow wire) to **Arduino Pin 2**
   - This is the data output from the RFID reader
   - Arduino will read transponder IDs through this pin

### Step 4: Optional - Add LED Indicator

1. Insert LED into breadboard
2. Connect LED anode (+, longer leg) to **220Ω resistor**
3. Connect resistor to **Arduino Pin 13**
4. Connect LED cathode (-, shorter leg) to **GND**

### Step 5: Optional - Add Buzzer

1. Connect buzzer positive (+) to **Arduino Pin 8**
2. Connect buzzer negative (-) to **GND**

### Step 6: Verify Connections

Double-check all connections:
- [ ] RDM6300 VCC → Arduino 5V
- [ ] RDM6300 GND → Arduino GND
- [ ] RDM6300 TX → Arduino Pin 2
- [ ] LED (optional) → Pin 13 + GND
- [ ] Buzzer (optional) → Pin 8 + GND

---

## Software Installation

### Step 1: Install Arduino IDE

1. Download from: https://www.arduino.cc/en/software
2. Install for your OS (Windows/Mac/Linux)
3. Open Arduino IDE

### Step 2: Upload Sketch

1. Open `RED_KEY_Reader.ino` in Arduino IDE
2. Select board: **Tools → Board → Arduino Uno**
3. Select port: **Tools → Port → COM3** (Windows) or **/dev/ttyUSB0** (Linux)
4. Click **Upload** button (→)
5. Wait for "Done uploading" message

### Step 3: Open Serial Monitor

1. Click **Tools → Serial Monitor**
2. Set baud rate to **9600**
3. You should see:
   ```
   ========================================
   RED KEY Transponder Reader v1.0
   The SRT Lab - Professional Diagnostic Tool
   ========================================
   
   Place RED KEY FOB on antenna...
   ```

---

## Testing

### Test 1: Power Check

1. Connect Arduino to USB
2. LED on Arduino should light up (power indicator)
3. RDM6300 LED should blink slowly (searching for tags)

### Test 2: Read Range Test

1. Place any 125 kHz RFID card on RDM6300 antenna
2. Hold 1-2 inches above the coil
3. Serial monitor should show data

### Test 3: RED KEY Test

1. Place Chrysler RED KEY FOB on antenna
2. Press FOB against the coil (within 1 inch)
3. Serial monitor should display:
   ```
   ========================================
   🔴 RED KEY DETECTED!
   ========================================
   
   Transponder ID: 12 34 56 78 9A
   Extended ID:    12 34 56 78 9A (+ 3 bytes secret key)
   Checksum:       5A [VALID ✓]
   ```

---

## Troubleshooting

### No Data Received

**Problem:** Serial monitor shows "Place RED KEY FOB on antenna..." but nothing happens

**Solutions:**
1. Check wiring - verify TX pin is connected to Pin 2
2. Check baud rate - must be 9600 in Serial Monitor
3. Move FOB closer - within 1 inch of antenna coil
4. Try different FOB orientation - rotate 90 degrees

### Invalid Checksum

**Problem:** Data received but checksum shows INVALID

**Solutions:**
1. Weak signal - move FOB closer
2. Interference - remove other RFID tags nearby
3. Damaged transponder - try different FOB

### Arduino Not Detected

**Problem:** COM port not showing in Arduino IDE

**Solutions:**
1. Install CH340 USB driver (for clone Arduinos)
2. Try different USB cable
3. Try different USB port
4. Check Device Manager (Windows) for COM port

### RDM6300 Not Working

**Problem:** Module LED not blinking

**Solutions:**
1. Check power - measure 5V on VCC pin with multimeter
2. Check module orientation - antenna coil should face up
3. Module may be defective - try replacement

---

## Advanced: Increase Read Range

### Option 1: External Antenna

Replace built-in coil with larger antenna:

```
Materials:
- 22 AWG magnet wire (50 feet)
- Cardboard tube (3-4 inch diameter)
- Hot glue

Steps:
1. Wind 10-15 turns of wire around tube
2. Connect ends to RDM6300 antenna pads
3. Tune with 100pF capacitor (optional)

Result: 4-6 inch read range
```

### Option 2: Amplifier Circuit

Add TL431 amplifier for 2x range:

```
RDM6300 Antenna → TL431 → Larger Coil

Components:
- TL431 voltage reference
- 2x 10kΩ resistors
- 100nF capacitor

Result: 8-10 inch read range
```

---

## Enclosure Design

### 3D Printable Case

STL files available at: `/arduino/enclosures/`

**Features:**
- Snap-fit design
- USB port cutout
- Antenna window
- LED light pipe
- Mounting holes

**Print Settings:**
- Material: PLA or PETG
- Layer height: 0.2mm
- Infill: 20%
- Supports: Yes (for overhangs)

### DIY Cardboard Enclosure

**Materials:**
- Small cardboard box (4" × 3" × 2")
- Hot glue gun
- Utility knife

**Steps:**
1. Cut USB port hole in side
2. Mount Arduino with double-sided tape
3. Mount RDM6300 on top (antenna facing up)
4. Label "RED KEY READER" on top
5. Add power LED hole in front

---

## Usage Workflow

### Daily Operation

1. **Power On**
   - Connect Arduino to USB power (computer or 5V adapter)
   - Wait for "Ready" message in Serial Monitor

2. **Read RED KEY**
   - Place FOB on antenna (within 1 inch)
   - Wait for beep and LED flash
   - Transponder ID appears in Serial Monitor

3. **Save Data**
   - Copy hex data from Serial Monitor
   - Paste into text file: `RED_KEY_DUMP.txt`
   - Save file

4. **Upload to SRT Lab**
   - Open SRT Lab RFHUB PIN Extractor
   - Click "Upload File"
   - Select `RED_KEY_DUMP.txt`
   - System extracts PIN automatically

5. **Program New Keys**
   - Use extracted PIN to unlock RFHUB
   - Program up to 7 additional black keys
   - No dealer visit required

---

## Safety Notes

⚠️ **Important:**
- RDM6300 is READ-ONLY - cannot write or clone transponders
- To clone keys, you need a separate programmer (Zedfull, Tango, etc.)
- This reader only extracts transponder ID for analysis
- Always verify PIN before programming keys to avoid lockout

---

## Upgrade Path

### Level 1: Basic Reader (This Guide)
- **Cost:** $20-30
- **Features:** Read transponder ID
- **Use:** PIN extraction, key inventory

### Level 2: Zedfull Programmer
- **Cost:** $300-400
- **Features:** Read + Write + Clone
- **Use:** Full key programming

### Level 3: Tango Programmer
- **Cost:** $1,500-2,000
- **Features:** Read + Write + Clone + Hitag2/AES
- **Use:** Professional locksmith operations

---

## Support

**Questions?**
- Forum: https://srtlab.community
- Email: support@srtlab.com
- Discord: https://discord.gg/srtlab

**Need Help?**
- Post your Serial Monitor output
- Include photos of wiring
- Specify Arduino model and RDM6300 version

---

## Legal Disclaimer

This tool is for **authorized use only**:
- ✅ Reading your own vehicle's keys
- ✅ Locksmith services with customer authorization
- ✅ Automotive repair and diagnostics
- ❌ Unauthorized key cloning
- ❌ Vehicle theft
- ❌ Bypassing security systems

**You are responsible for legal compliance in your jurisdiction.**

---

**The SRT Lab - Professional Diagnostic Tools**
*Version 1.0 - Updated 2024*
