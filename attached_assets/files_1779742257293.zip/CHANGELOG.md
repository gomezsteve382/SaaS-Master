# The SRT Lab — Complete Refactor Changelog

## What was done

### Phase 1: Stabilize
- Removed `client.backup/` (2.8MB duplicate)
- Fixed 2 duplicate routes
- Wrote real README (was a password cracking guide)
- Updated `.gitignore` for sensitive files
- Extracted 10 inline routers from `routers.ts` (575→133 lines)
- Removed Manus Vite plugin + Builder.io plugin
- Deleted `.replit`, `replit.nix`, `.manus/`

### Phase 2: Decouple from Manus
- Rewrote `llm.ts` — generic OpenAI-compatible client, works with any provider
- Rewrote `storage.ts` — local filesystem replacing Manus proxy
- Rewrote `notification.ts` — console + optional webhook
- Simplified `sdk.ts` — no auth, always admin (personal use)
- Simplified `oauth.ts` — no-op stub
- Simplified `env.ts` — just DB, LLM, storage, port
- Deleted dead code: `imageGeneration.ts`, `voiceTranscription.ts`, `dataApi.ts`, `map.ts`, `manusTypes.ts`
- Fixed `llmTest.ts` Manus fallback URL
- Updated server `index.ts` with storage routes + startup banner

### Phase 3: Consolidate Navigation
- Rewrote `Home.tsx` — all 124 tools in 10 collapsible categories with search
- Created `AppSidebar.tsx` — reusable sidebar nav component
- Normalized all route indentation and quote syntax in `App.tsx`
- Created `docs/CONSOLIDATION_TARGETS.md` for future page merging

### Phase 4: Deploy
- `Dockerfile` — multi-stage build, health check
- `docker-compose.yml` — app + MySQL, persistent volumes
- `.dockerignore` — lean image
- `.github/workflows/ci.yml` — typecheck → test → build → docker
- `.env.example` — documented config

## Quick start

```bash
cp .env.example .env
# Set DATABASE_URL, LLM_API_KEY if you want those features
pnpm install
pnpm dev
```

Or with Docker:
```bash
docker compose up -d
```

## Stats
| Metric | Before | After |
|--------|--------|-------|
| TS/TSX files | 659 | 429 |
| Manus references | dozens | 0 |
| Pages in nav | 59/124 | 124/124 |
| Duplicate routes | 2 | 0 |
| routers.ts | 575 lines | 133 lines |
| Platform lock-in | Manus | None |
