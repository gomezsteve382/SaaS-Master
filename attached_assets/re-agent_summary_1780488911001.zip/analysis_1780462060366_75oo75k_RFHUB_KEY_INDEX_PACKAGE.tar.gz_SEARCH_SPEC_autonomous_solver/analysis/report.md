# RFHUB_KEY_INDEX_PACKAGE.tar.gz — SEARCH_SPEC autonomous solver

**Created:** 6/3/2026, 4:47:40 AM
**Updated:** 6/3/2026, 4:47:40 AM
**Model:** qwen/qwen3-coder:free
**File:** RFHUB_KEY_INDEX_PACKAGE.tar.gz
**Tools Used:** 1

## Prompt

Autonomous SEARCH_SPEC key-index solver run

## Response

# Final Report — RFHUB Key Index Byte Search

## Overview
RE-Agent completed a deterministic autonomous SEARCH_SPEC pass against the supplied RFHUB package. The objective was to find `F(keyId, master) -> index` that reproduces all six known validation vectors.

## Conclusion
No perfect offline function was found in the tested AES/DES/3DES, HMAC, or common CRC16-truncation candidate families. Based on the SEARCH_SPEC priority tree, the next credible path is Hitag2/FCA proprietary logic or RFHUB assignment during RoutineControl 0x0401 key-learn.

## Evidence Artifacts
- `rfhub_key_index_search_report.md`
- `rfhub_key_index_search_results.json`
- `coverage_manifest.md`

## Next Steps
Use a bench RFHUB/UDS learn capture to observe the slot/index emitted for a held-out seventh key, then correlate that byte against Hitag2 authenticator bytes and any FCA seed-key response bytes.


---

# RFHUB Key Index Search Results

Validation pairs: 6
Master: `59022F5542BE7644EC2028C53AD4D654`
Candidates evaluated: 640
Perfect candidates: 0

## Validation Oracle

| keyId | revUID | expected index |
|---|---|---|
| `0077A29B` | `9BA27700` | `0x48` |
| `CC62209F` | `9F2062CC` | `0x0F` |
| `09A6629F` | `9F62A609` | `0x4C` |
| `91654F9E` | `9E4F6591` | `0x19` |
| `197E6C9E` | `9E6C7E19` | `0x5B` |
| `C47D6C9E` | `9E6C7DC4` | `0xB0` |

## Result
No tested offline candidate reproduced all six indexes. This rules out the implemented keyed AES/DES/3DES truncations, common HMAC truncations, and common CRC16 truncations for the provided oracle. The remaining high-priority branches are Hitag2 authenticator byte selection, proprietary FCA/Stellantis seed-key tables, or RFHUB-assigned index during RoutineControl 0x0401 key learn.

## Best Near Misses

| matches | candidate | outputs |
|---:|---|---|
| 1/6 | `3des_m_m0_8:des-ede3-ecb(revUID_le,pkcs7)[1]` | `0xF6, 0x0F, 0xAC, 0xD2, 0xE5, 0xBB` |
| 1/6 | `3des_m_m0_8:des-ede3-ecb(revUID_le,pkcs7)[4]` | `0x6A, 0x0F, 0xC6, 0x36, 0x63, 0xEF` |
| 1/6 | `3des_m_m0_8:des-ede3-ecb(revUID_le,zero)[5]` | `0xCF, 0xDD, 0xB3, 0x1E, 0x5B, 0x0F` |
| 1/6 | `AES-128-ECB(master,revUID_le,repeat)[2]` | `0x36, 0xB0, 0x76, 0xA9, 0x5B, 0x73` |
| 1/6 | `AES-128-ECB(master,revUID_le,right_ff)[0]` | `0x57, 0x7F, 0x1E, 0xC1, 0x93, 0xB0` |
| 1/6 | `AES-128-ECB(master,revUID_le,zero)[8]` | `0x48, 0x04, 0x92, 0x6A, 0x05, 0x64` |
| 1/6 | `CRC16-MODBUS(revUID_master).hi` | `0x8E, 0x5B, 0x4C, 0x60, 0x2A, 0x04` |
| 1/6 | `HMAC-md5(master,keyId_be)[3]` | `0x0A, 0x39, 0xF9, 0x19, 0xD9, 0x9E` |
| 1/6 | `HMAC-md5(master,revUID_keyId)[8]` | `0xEF, 0xCF, 0xCA, 0x19, 0xF5, 0x4E` |
| 1/6 | `HMAC-md5(master,revUID_le)[11]` | `0xFC, 0xBD, 0x4C, 0xF2, 0x16, 0x88` |
| 1/6 | `HMAC-md5(master,revUID_le)[6]` | `0x31, 0x0F, 0x2B, 0x39, 0x93, 0x83` |
| 1/6 | `HMAC-sha1(master,keyId_be)[1]` | `0x84, 0x8B, 0x94, 0x19, 0x04, 0x6C` |
| 1/6 | `HMAC-sha1(master,keyId_be)[6]` | `0x3A, 0xDE, 0x50, 0x19, 0x4D, 0x44` |
| 1/6 | `HMAC-sha256(master,keyId_be)[9]` | `0x39, 0xD0, 0x4C, 0xC0, 0x20, 0x85` |
| 1/6 | `HMAC-sha256(master,keyId_revUID)[13]` | `0xBC, 0xEB, 0xA3, 0xC3, 0xCA, 0xB0` |
| 1/6 | `HMAC-sha256(master,revUID_keyId)[5]` | `0xBA, 0x0F, 0x98, 0xDB, 0x16, 0xF4` |
| 1/6 | `HMAC-sha256(master,revUID_le)[24]` | `0x30, 0xE5, 0x4C, 0xA0, 0x26, 0xF5` |
| 1/6 | `HMAC-sha512(master,keyId_be)[11]` | `0x18, 0x0F, 0x1D, 0x92, 0x18, 0xB7` |
| 1/6 | `HMAC-sha512(master,keyId_be)[25]` | `0x82, 0xC6, 0x4C, 0x12, 0x50, 0x26` |
| 1/6 | `HMAC-sha512(master,keyId_be)[7]` | `0xD3, 0xAF, 0x4C, 0x33, 0xD4, 0xBF` |
| 1/6 | `HMAC-sha512(master,keyId_revUID)[27]` | `0x80, 0x85, 0xC2, 0x19, 0x4D, 0x7F` |
| 1/6 | `HMAC-sha512(master,keyId_revUID)[4]` | `0x10, 0x97, 0xCC, 0x76, 0x5B, 0xD1` |
| 1/6 | `HMAC-sha512(master,revUID_keyId)[24]` | `0x48, 0x33, 0x3A, 0xD8, 0x38, 0x39` |
| 1/6 | `HMAC-sha512(master,revUID_keyId)[29]` | `0xA0, 0x39, 0x9A, 0x45, 0x5B, 0x5D` |
| 1/6 | `HMAC-sha512(master,revUID_le)[26]` | `0xA6, 0x51, 0x53, 0x8E, 0x5B, 0x09` |

## Ruled-Out Discipline

This deterministic pass did not re-test the explicitly ruled-out CRC8, CRC16-except-current-priority common variants, linear byte transforms, xor/add/sub constants, or simple folds. It focused on the next SEARCH_SPEC candidate families that can be tested offline from the package.

