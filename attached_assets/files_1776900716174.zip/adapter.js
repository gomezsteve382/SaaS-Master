/**
 * Unified Adapter — wraps OBDLink/ELM327 (serial) and J2534 (WebSocket bridge)
 * so any page can work with either transport through the same interface.
 *
 * Usage:
 *   const adapter = await connectAdapter("obdlink"); // or "j2534"
 *   const response = await adapter.uds(txId, rxId, [0x22, 0xF1, 0x90]);
 *   await adapter.close();
 */

import { useState, useRef, useEffect, useCallback } from "react";

/* ═══════════════════════════════════════════════════════════════════════
   OBDLink / ELM327 Serial Adapter
   ═══════════════════════════════════════════════════════════════════════ */

export async function connectOBDLink(addLog) {
  if (!navigator.serial) {
    throw new Error("Web Serial API not available. Use Chrome/Edge on desktop.");
  }
  addLog?.("Requesting serial port for OBDLink/ELM327...", "info");
  const port = await navigator.serial.requestPort();
  await port.open({ baudRate: 115200 });
  const writer = port.writable.getWriter();
  const reader = port.readable.getReader();

  const enc = new TextEncoder();
  const dec = new TextDecoder();
  let rbuf = "";

  const send = async (cmd, timeout = 800) => {
    rbuf = "";
    await writer.write(enc.encode(cmd + "\r"));
    addLog?.(`TX > ${cmd}`, "tx");
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const { value, done } = await Promise.race([
        reader.read(),
        new Promise(r => setTimeout(() => r({ value: null }), 50)),
      ]);
      if (done) break;
      if (value) rbuf += dec.decode(value);
      if (rbuf.includes(">")) break;
    }
    const t = rbuf.replace(/\r/g, "\n").replace(/\n+/g, "\n").replace(/>/g, "").trim();
    if (t) addLog?.(`RX < ${t}`, "rx");
    return t;
  };

  // Standard init sequence
  await send("ATZ", 2000);
  await new Promise(r => setTimeout(r, 500));
  await send("ATE0");
  const ati = await send("ATI");
  const stdi = await send("STDI");
  const isSTN = !stdi.includes("?") && !stdi.includes("ERROR") && stdi.length > 2;
  const rv = await send("ATRV");
  addLog?.(`Adapter: ${isSTN ? "STN/OBDLink" : "ELM327"} | ${ati} | ${rv}`, "info");

  await send("ATL0"); await send("ATS1"); await send("ATH1");
  await send("ATSP6"); await send("ATAT2"); await send("ATST96");
  if (isSTN) { await send("ATCAF1"); await send("ATFCSM1"); }
  else { await send("ATCAF1"); await send("ATFCSM1"); }

  let curTx = 0, curRx = 0;

  const uds = async (tx, rx, data) => {
    if (tx !== curTx) {
      await send("ATSH" + tx.toString(16).toUpperCase().padStart(3, "0"));
      if (isSTN) await send("ATFCSH" + tx.toString(16).toUpperCase().padStart(3, "0"));
      curTx = tx;
    }
    if (rx !== curRx) {
      await send("ATCRA" + rx.toString(16).toUpperCase().padStart(3, "0"));
      curRx = rx;
    }
    const h = Array.from(data).map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ");
    const r = await send(h, 5000);
    if (!r || /NO DATA|UNABLE TO CONNECT|CAN ERROR|BUS ERROR|BUS INIT|STOPPED/.test(r))
      return { ok: false, raw: r || "" };
    if (r.includes("?") || r.includes("ERROR")) return { ok: false, raw: r };

    const lines = r.split(/[\r\n]+/).map(l => l.trim()).filter(l => l.length > 0);
    if (!lines.length) return { ok: false, raw: r };
    let all = [];
    for (const line of lines) {
      if (line.includes("SEARCHING") || line === "OK") continue;
      const toks = line.split(/\s+/).filter(t => /^[0-9A-Fa-f]{2,3}$/.test(t));
      if (!toks.length) continue;
      const bytes = toks.map(t => parseInt(t, 16));
      all.push(...bytes);
    }
    return { ok: true, raw: r, bytes: all };
  };

  return {
    type: "obdlink",
    label: isSTN ? "STN/OBDLink" : "ELM327",
    firmware: ati,
    voltage: rv,
    isSTN,
    send,
    uds,
    close: async () => {
      try { reader.releaseLock(); } catch {}
      try { writer.releaseLock(); } catch {}
      try { await port.close(); } catch {}
    },
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   J2534 WebSocket Adapter (via j2534_bridge.py)
   ═══════════════════════════════════════════════════════════════════════ */

export async function connectJ2534(addLog, opts = {}) {
  const { wsUrl = "ws://localhost:8765", dllPath } = opts;
  addLog?.(`Connecting to J2534 bridge at ${wsUrl}...`, "info");

  const ws = await new Promise((resolve, reject) => {
    const socket = new WebSocket(wsUrl);
    socket.onopen = () => resolve(socket);
    socket.onerror = () => reject(new Error(`Cannot connect to ${wsUrl} — is j2534_bridge.py running?`));
    setTimeout(() => reject(new Error("Bridge connection timeout")), 3000);
  });
  addLog?.("Bridge connected", "info");

  let msgId = 0;
  const pending = new Map();

  ws.onmessage = (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.id !== undefined && pending.has(msg.id)) {
        const { resolve, reject } = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) reject(new Error(msg.error));
        else resolve(msg);
      }
    } catch (e) {}
  };

  const cmd = (command, args = {}) => {
    const id = msgId++;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, command, ...args }));
      setTimeout(() => {
        if (pending.has(id)) {
          pending.delete(id);
          reject(new Error(`J2534 command timeout: ${command}`));
        }
      }, 10000);
    });
  };

  // List + open device
  const deviceList = await cmd("ListDevices");
  addLog?.(`Found ${deviceList.devices?.length || 0} J2534 device(s)`, "info");

  const openArgs = dllPath ? { dllPath } : {};
  const openResp = await cmd("Open", openArgs);
  if (!openResp.success) {
    throw new Error(`PassThruOpen failed: ${openResp.error || "unknown error"}`);
  }
  addLog?.(`Opened: ${openResp.device || "J2534 device"}`, "info");

  // Connect to ISO15765 (CAN UDS) @ 500kbps
  const connResp = await cmd("Connect", { protocol: "ISO15765", baudrate: 500000 });
  if (!connResp.success) {
    await cmd("Close").catch(() => {});
    throw new Error(`PassThruConnect failed: ${connResp.error || "unknown"}`);
  }

  const uds = async (tx, rx, data) => {
    try {
      const bytes = Array.from(data);
      const resp = await cmd("UDS", { tx, rx, data: bytes, timeout: 5000 });
      if (!resp.success) return { ok: false, raw: resp.error || "" };
      addLog?.(`RX < ${resp.bytes.map(b => b.toString(16).toUpperCase().padStart(2, "0")).join(" ")}`, "rx");
      return { ok: true, raw: "", bytes: resp.bytes };
    } catch (e) {
      return { ok: false, raw: e.message };
    }
  };

  return {
    type: "j2534",
    label: openResp.device || "J2534 PassThru",
    firmware: openResp.firmware || "",
    voltage: openResp.voltage || "",
    isSTN: false,
    send: async () => { throw new Error("J2534 does not support ELM AT commands"); },
    uds,
    close: async () => {
      try { await cmd("Disconnect").catch(() => {}); } catch {}
      try { await cmd("Close").catch(() => {}); } catch {}
      try { ws.close(); } catch {}
    },
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   Unified Entry Point
   ═══════════════════════════════════════════════════════════════════════ */

export async function connectAdapter(type, addLog, opts = {}) {
  if (type === "j2534") return connectJ2534(addLog, opts);
  return connectOBDLink(addLog);
}

/* ═══════════════════════════════════════════════════════════════════════
   ConnectButton — replaces single "Connect" buttons everywhere.
   Renders a dropdown with OBDLink and J2534 options.
   ═══════════════════════════════════════════════════════════════════════ */

export function ConnectButton({ onConnect, onDisconnect, adapter, addLog, C }) {
  const [busy, setBusy] = useState(false);
  const [showPicker, setShowPicker] = useState(false);

  const handleConnect = async (type) => {
    setBusy(true);
    setShowPicker(false);
    try {
      const a = await connectAdapter(type, addLog);
      onConnect?.(a);
    } catch (e) {
      addLog?.(`Connect failed: ${e.message}`, "error");
    } finally {
      setBusy(false);
    }
  };

  const handleDisconnect = async () => {
    setBusy(true);
    try {
      await adapter?.close?.();
      onDisconnect?.();
    } catch (e) {
      addLog?.(`Disconnect error: ${e.message}`, "error");
    } finally {
      setBusy(false);
    }
  };

  if (adapter) {
    return (
      <button
        onClick={handleDisconnect}
        disabled={busy}
        style={{
          padding: "10px 18px", borderRadius: 8, border: "none",
          background: C?.gn || "#00C853", color: "#fff",
          fontSize: 13, fontWeight: 800, cursor: "pointer",
          display: "inline-flex", alignItems: "center", gap: 8,
        }}
      >
        ✓ {adapter.label} Connected — Click to disconnect
      </button>
    );
  }

  return (
    <div style={{ position: "relative", display: "inline-block" }}>
      <button
        onClick={() => setShowPicker(!showPicker)}
        disabled={busy}
        style={{
          padding: "10px 18px", borderRadius: 8, border: "none",
          background: C?.a3 || "#2979FF", color: "#fff",
          fontSize: 13, fontWeight: 800, cursor: "pointer",
          display: "inline-flex", alignItems: "center", gap: 8,
        }}
      >
        {busy ? "Connecting..." : "🔌 Connect Adapter ▾"}
      </button>

      {showPicker && !busy && (
        <div style={{
          position: "absolute", top: "100%", left: 0, marginTop: 6,
          background: "#fff", border: "1px solid #E8E4DE", borderRadius: 10,
          boxShadow: "0 8px 24px rgba(0,0,0,0.12)", zIndex: 100, minWidth: 280,
          overflow: "hidden",
        }}>
          <button
            onClick={() => handleConnect("obdlink")}
            style={{
              display: "block", width: "100%", padding: "12px 16px",
              border: "none", background: "none", textAlign: "left",
              cursor: "pointer", borderBottom: "1px solid #E8E4DE",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#F4F1EC"}
            onMouseLeave={e => e.currentTarget.style.background = "none"}
          >
            <div style={{ fontWeight: 800, fontSize: 13, color: "#1A1A1A" }}>
              📡 OBDLink / ELM327
            </div>
            <div style={{ fontSize: 10, color: "#5A5A5A", marginTop: 2 }}>
              USB/Bluetooth serial adapter — Web Serial API
            </div>
          </button>

          <button
            onClick={() => handleConnect("j2534")}
            style={{
              display: "block", width: "100%", padding: "12px 16px",
              border: "none", background: "none", textAlign: "left",
              cursor: "pointer",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#F4F1EC"}
            onMouseLeave={e => e.currentTarget.style.background = "none"}
          >
            <div style={{ fontWeight: 800, fontSize: 13, color: "#1A1A1A" }}>
              ⚡ J2534 PassThru
            </div>
            <div style={{ fontSize: 10, color: "#5A5A5A", marginTop: 2 }}>
              Autel / Drew Tech / Cardaq / MDI — via j2534_bridge.py
            </div>
          </button>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   useAdapter hook — manages adapter lifecycle in a React component
   ═══════════════════════════════════════════════════════════════════════ */

export function useAdapter(addLog) {
  const [adapter, setAdapter] = useState(null);
  const adapterRef = useRef(null);

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (adapterRef.current) {
        adapterRef.current.close().catch(() => {});
      }
    };
  }, []);

  const connect = useCallback(async (type) => {
    try {
      const a = await connectAdapter(type, addLog);
      adapterRef.current = a;
      setAdapter(a);
      return a;
    } catch (e) {
      addLog?.(`Connect failed: ${e.message}`, "error");
      throw e;
    }
  }, [addLog]);

  const disconnect = useCallback(async () => {
    if (adapterRef.current) {
      try { await adapterRef.current.close(); } catch {}
      adapterRef.current = null;
      setAdapter(null);
    }
  }, []);

  return { adapter, connect, disconnect };
}
