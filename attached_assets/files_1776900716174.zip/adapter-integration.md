// ═══════════════════════════════════════════════════════════════════════
// ADAPTER INTEGRATION — HOW TO ADD J2534 OPTION EVERYWHERE
// ═══════════════════════════════════════════════════════════════════════
//
// File to add: artifacts/srt-lab/src/lib/adapter.js (use the adapter.js I provided)
//
// Then replace the "Connect OBDLink" buttons in these files:
//   - OBDTab.jsx         (line 239)
//   - BenchTab.jsx       (line 222)
//   - SecurityTab.jsx    (search for ELM327 or OBDLink)
//   - ImmoVINTab.jsx     (if it has a connect button)
//   - App.jsx            (line 483, in the BenchTab section)
//
// ═══════════════════════════════════════════════════════════════════════


// ──────────────────────────────────────────────────────────────────────
// STEP 1: Add import at top of each tab file
// ──────────────────────────────────────────────────────────────────────

import { ConnectButton, useAdapter } from "../lib/adapter.js";


// ──────────────────────────────────────────────────────────────────────
// STEP 2: In OBDTab.jsx — replace the connect logic
// ──────────────────────────────────────────────────────────────────────
//
// OLD (around lines 15-50):
//   const [conn,setConn]=useState(false);
//   const eng=useRef(null);
//   const connect=async()=>{
//     try{
//       const port=await navigator.serial.requestPort();
//       ...
//       setConn(true);
//     }catch(e){addLog(e.message,'error');}
//   };
//
// NEW:
//   const { adapter, connect, disconnect } = useAdapter(addLog);
//   const eng = useRef(null);
//
//   // After connect, wire up eng.current for compatibility with existing code
//   useEffect(() => {
//     if (adapter) {
//       eng.current = {
//         send: adapter.send,
//         isSTN: adapter.isSTN,
//         uds: adapter.uds,
//       };
//     } else {
//       eng.current = null;
//     }
//   }, [adapter]);
//
//   const conn = !!adapter;
//
// Then in the render (line 239):
//   OLD:  <Btn onClick={connect} disabled={conn} color={conn?C.gn:C.a3} full>
//           {conn?'✓ Connected':'🔌 Connect ELM327 / OBDLink'}
//         </Btn>
//
//   NEW:  <ConnectButton
//           adapter={adapter}
//           onConnect={a => { /* adapter already set by useAdapter */ }}
//           onDisconnect={disconnect}
//           addLog={addLog}
//           C={C}
//         />


// ──────────────────────────────────────────────────────────────────────
// STEP 3: In BenchTab.jsx (line 222) — same pattern
// ──────────────────────────────────────────────────────────────────────
//
// OLD:  <Btn onClick={benchConnect} disabled={benchConn} color={benchConn?C.gn:C.a3}>
//         {benchConn?'✓ Bench Connected':'🔌 Connect OBDLink (Bench)'}
//       </Btn>
//
// NEW:  <ConnectButton
//         adapter={benchAdapter}
//         onConnect={a => setBenchAdapter(a)}
//         onDisconnect={() => setBenchAdapter(null)}
//         addLog={addLog}
//         C={C}
//       />
//
// Update state:
//   OLD: const [benchConn, setBenchConn] = useState(false);
//   NEW: const [benchAdapter, setBenchAdapter] = useState(null);
//        const benchConn = !!benchAdapter;


// ──────────────────────────────────────────────────────────────────────
// STEP 4: In App.jsx (line 483, the Bench section duplicate) — same pattern
// ──────────────────────────────────────────────────────────────────────
//
// (Same replacement as BenchTab.jsx)


// ──────────────────────────────────────────────────────────────────────
// STEP 5: In SecurityTab.jsx — if it has a connect button
// ──────────────────────────────────────────────────────────────────────
//
// Search for "Connect" button and apply the same ConnectButton replacement.


// ──────────────────────────────────────────────────────────────────────
// STEP 6: Update j2534_bridge.py to support the new Open command
// ──────────────────────────────────────────────────────────────────────
//
// The bridge needs to support these commands from adapter.js:
//
//   ListDevices → returns { devices: [{name, dll}, ...] }
//   Open (optional dllPath) → returns { success, device, firmware, voltage, error }
//   Connect (protocol, baudrate) → returns { success, error }
//   UDS (tx, rx, data, timeout) → returns { success, bytes, error }
//   Disconnect → returns { success }
//   Close → returns { success }
//
// If your bridge uses different command names, update the adapter.js file
// to match — the command names are in connectJ2534() function.


// ══════════════════════════════════════════════════════════════════════
// MINIMAL CHANGE VERSION — just a picker drop-in
// ══════════════════════════════════════════════════════════════════════
//
// If you don't want to refactor everything, just use the ConnectButton
// as a visual element that exposes both options, and keep your existing
// connect handlers. Wire the onConnect callback to set up whichever
// adapter was chosen:
//
//   const [adapter, setAdapter] = useState(null);
//
//   <ConnectButton
//     adapter={adapter}
//     onConnect={a => {
//       setAdapter(a);
//       // existing state setters:
//       setConn(true);
//       eng.current = { send: a.send, isSTN: a.isSTN, uds: a.uds };
//     }}
//     onDisconnect={() => {
//       setAdapter(null);
//       setConn(false);
//       eng.current = null;
//     }}
//     addLog={addLog}
//     C={C}
//   />
//
// This way all existing code that reads `conn` and calls `eng.current.uds(...)`
// keeps working unchanged — you just added J2534 as a second connection option.

// ══════════════════════════════════════════════════════════════════════
// INSIDE THE DROPDOWN THE USER SEES:
// ══════════════════════════════════════════════════════════════════════
//
// 🔌 Connect Adapter ▾
//   ┌────────────────────────────────────────────┐
//   │ 📡 OBDLink / ELM327                        │
//   │    USB/Bluetooth serial adapter           │
//   ├────────────────────────────────────────────┤
//   │ ⚡ J2534 PassThru                          │
//   │    Autel / Drew Tech / Cardaq / MDI        │
//   └────────────────────────────────────────────┘
//
