# CLAUDE.md — SRT Lab Jailbreak Edition

## Project Overview
FCA/Stellantis ECU module workbench. React single-page app (Vite + React).
Patches VINs, manages immobilizer keys, communicates over OBD-II via Web Serial.

## Commands
- `npm run dev` — Start dev server
- `npm run build` — Production build
- `npm run preview` — Preview production build

## Tech Stack
- React 18+ (functional components, hooks only)
- Vite bundler
- No UI library — custom components with inline styles
- Fonts: Nunito (body), Righteous (display), JetBrains Mono (hex/data)
- Color palette: Pixar-vibrant light base (#F4F1EC), SRT Red (#D32F2F) + black (#1A1A1A) accents

## Architecture
Single file: `src/App.jsx` (or split into `src/tabs/` if needed)
No server — all processing is client-side in the browser.
Binary files loaded via FileReader API, processed as Uint8Array.

---

## VERIFIED CHECKSUM ALGORITHMS (DO NOT MODIFY)

### BCM D-FLASH (64KB / 128KB) — CRC-16 CCITT-FALSE
- Poly: 0x1021, Init: 0xFFFF, no reflection, no XOR-out
- Stored big-endian at VIN+17 (2 bytes)
- VIN offsets stride 0x20: typically 0x5320, 0x5340, 0x5360, 0x5380
- Also has partial VINs (8-byte tail fragments with CRC-16)
- **VERIFIED: 31/31 real dumps pass**

```javascript
function crc16(d, i = 0xFFFF) {
  let c = i;
  for (let x = 0; x < d.length; x++) {
    c ^= d[x] << 8;
    for (let j = 0; j < 8; j++)
      c = c & 0x8000 ? (c << 1) ^ 0x1021 : c << 1;
    c &= 0xFFFF;
  }
  return c;
}
```

### 95640 EEPROM (8KB / 16KB) — CRC-8 Forward
- Poly: 0x26, Init: 0x00
- Stored at VIN-1 (1 byte BEFORE the VIN)
- VIN offsets: 0x0275, 0x0288
- Secret key at 0x0040 (16 bytes)
- Fob data at 0x0200 (64 bytes)
- **VERIFIED: 3/3 Trackhawk dumps pass**
- Note: Wrangler JL and some other variants use a different algorithm — CRC will show as invalid on load but patching still works

```javascript
function crc8a(d, i = 0) {
  let c = i;
  for (let x = 0; x < d.length; x++) {
    c ^= d[x];
    for (let j = 0; j < 8; j++)
      c = c & 0x80 ? (c << 1) ^ 0x26 : c << 1;
    c &= 0xFF;
  }
  return c;
}
```

### RFHUB EEE (4KB Journey SmartBox) — CONTEXT-DEPENDENT (DO NOT RECALCULATE)
- VINs stored MIRRORED (byte-reversed) at 4 slots: 0x0EA5, 0x0EB9, 0x0ECD, 0x0EE1
- Byte at VIN+17 is NOT a simple VIN checksum
- It depends on the preamble byte at VIN-1 (varies per vehicle: 0x00, 0xFE, 0xFF, 0x20)
- Same VIN in different dumps produces DIFFERENT checksum values
- **VERIFIED: 0/20 dumps match ANY CRC-8 algorithm — proven not VIN-only**
- When patching: write mirrored VIN, PRESERVE existing checksum byte
- Module firmware recalculates on boot
- Secret key at 0x0040 (16 bytes)

### GPEC2A (4KB Continental PCM) — NO CRC
- VIN at 0x0000, 0x01F0, 0x0224 (3 copies, plain ASCII, no checksum)
- SKIM byte at 0x0011 (0x80 = enabled, 0x00 = disabled)
- Secret key at 0x0203 (8 bytes), mirror at 0x0361
- Transponder keys at 0x0888 (4 × 4 bytes)
- ZZZZ tamper at 0x0C8C (8 bytes, 0x5A = intact)
- Runtime counters at 0x0E61, 0x0E69, 0x0E6D, 0x0E75

---

## FILE TYPE DETECTION
```
Size 65536 or 131072 → BCM D-FLASH
Size 8192 or 16384   → 95640 EEPROM
Size 4096:
  - VIN at byte 0 (ASCII 0x30-0x5A) → GPEC2A
  - Otherwise → RFHUB EEE
Size > 131072 → Firmware (GPEC flash, etc.)
```

---

## SEED-KEY ALGORITHMS (14 total)
All use shift-XOR-32 except NGC, JTEC, CDA6, and TIPM.

| ID | Name | Constant/Method |
|---|---|---|
| gpec1 | GPEC1 | sxor(seed, 670269) |
| gpec2 | GPEC2 | sxor(seed, 0xE72E3799) |
| gpec2f | GPEC2 Flash | sxor(seed, 0x966AEEB1) |
| gpec2e | GPEC2 EPROM | sxor(seed, 0x3F711F5A) |
| gpec3 | GPEC3 | sxor(seed, 0x129D657F) |
| gpec2a | GPEC2A | sxor(seed, 0xCE853A6F) |
| gpec15 | GPEC2 2015 | sxor(seed, 0x47EC21F8) |
| ngc | NGC | DAIMLERCHRYSLER lookup table |
| jtec | JTEC | Fixed 0x0000 |
| cda6 | CDA6 L1 | XOR/rotate algorithm |
| t80 | TIPM 0x80 | t8001 lookup table |
| t36 | TIPM 0x36 | t3605 lookup table |
| t81 | TIPM 0x81 | t8101 lookup table |
| t3c | TIPM 0x3C | t3c lookup table |

---

## LIVE OBD — UDS Protocol

### Module CAN IDs
| Module | TX | RX | Seed-Key Constant |
|---|---|---|---|
| ECM | 0x7E0 | 0x7E8 | 0x8A3C71 |
| TCM | 0x7E1 | 0x7E9 | 0x6E4B92 |
| BCM | 0x742 | 0x762 | 0x4B129F |
| RFHUB | 0x75F | 0x767 | 0xD5F1 |
| ABS | 0x760 | 0x768 | 0x4B129F |
| IPC | 0x745 | 0x765 | 0x4B129F |
| RADIO | 0x772 | 0x77A | — |
| DAMP | 0x7E4 | 0x7EC | — |
| EPS | 0x75F | 0x769 | 0x4B129F |
| TIPM | 0x74C | 0x76C | — |

### UDS Sequence (VIN Write)
1. `10 03` — Extended diagnostic session
2. `27 01` — Request seed (response: `67 01 XX XX XX XX`)
3. Compute key via CDA6 shift-XOR
4. `27 02 KK KK KK KK` — Send key (response: `67 02`)
5. `2E F1 90 [17 VIN bytes]` — Write VIN (response: `6E F1 90`)
6. Also write to DIDs: 0x7B90 (current), 0x7B88 (original)
7. `11 01` — Hard reset

### Key VIN DIDs
- 0xF190 — Standard VIN (UDS)
- 0x7B90 — Current VIN (FCA-specific)
- 0x7B88 — Original VIN (FCA-specific)
- 0x6E2025 — Bus Transmitted VIN
- 0x6E2027 — WCM Configured VIN
- 0x6E9EB0 — SKIM State (0x80=enabled, 0x00=disabled)
- 0x6EF190 — EPS VIN
- 0x2023 — BCM Proxi Configuration

### ELM327/OBDLink Init Sequence
```
ATZ → ATI → ATE0 → ATL0 → ATS1 → ATH1 → ATCAF1 → ATCFC1 → ATAL → ATSP6
```
Then for each module: `ATSH[TX]` + `ATCRA[RX]` before sending UDS bytes.

---

## BCM SECURITY BYTE MAP
- 0x2000 — Security backup block (32 bytes), Trackhawk variant
- 0x40C0 — Primary security block (32 bytes), SRT variant
- 0x40C8 — Immobilizer key (18 bytes) within primary block
- 0x40F0 — Immobilizer key backup (18 bytes)
- SKIM keys: 6 slots × 18 bytes at each base offset

---

## GPEC FIRMWARE UNLOCK
From .NET IL disassembly of GPEC Unlocker tool:
- Search for 4-byte pattern in firmware
- Set byte at offset 0x2FFFC to 0x96
- If 0x2FFFC already equals 0x96, file is already unlocked

---

## VIRGINIZER BEHAVIOR
| Module | Action |
|---|---|
| BCM | Zero all VIN slots + CRC, FF-fill 0x2000 and 0x40C0 SKIM blocks |
| 95640 | Zero VINs at 0x275/0x288, zero CRC bytes, FF-fill secret key at 0x0040 |
| RFHUB EEE | Zero 4 mirrored VIN slots, zero CRC bytes, FF-fill secret key at 0x0040, FF-fill fob data at 0x0200 |
| GPEC2A | Zero VINs at 0x0000/0x01F0/0x0224 |

---

## TABS IN THE APP
1. **DUMPS** — Load .bin files, auto-detect type, VIN patch with correct CRC, hex viewer, virginizer
2. **LIVE OBD** — Web Serial connect, scan modules, read/write VIN over UDS, RFHUB virginize, proxi read
3. **SEED→KEY** — 14 algorithm calculator
4. **GPEC** — Firmware unlock (0x2FFFC = 0x96)
5. **SKIM / SECURITY** — Own file loader, module analyzer, key extraction, cross-module match, key sync
6. **GPEC2A TOOLS** — SKIM byte toggle, secret key extract, transponder keys, ZZZZ tamper, hex diff

## Design Rules
- Light background (#F4F1EC), white cards, SRT Red (#D32F2F) + black accents
- Pixar-vibrant colors, NOT dark hacker terminal
- Nunito font body, Righteous display, JetBrains Mono for data
- No references to "VILLAIN" anywhere in UI
- User-friendly, clean, professional look
