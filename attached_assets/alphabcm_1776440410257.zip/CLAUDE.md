# CLAUDE.md — SRT Lab Jailbreak Edition OBD Debug Session

## THE PROBLEM
Single-file React app (src/App.jsx) connects to OBDLink EX via Web Serial.
Only ECM (0x7E0/0x7E8) responds. All body modules (BCM, IPC, RFHUB, ABS, etc.) return NO DATA.
The Autel MaxiSys and Alpha OBD talk to ALL modules on the same bench with the same adapter.

## HARDWARE
- OBDLink EX r2.1 (STN2120 chip, reports "ELM327 v1.4b" to ATI, "OBDLink EX r2.1" to STDI)
- Connected via USB to laptop, Chrome Web Serial API
- Bench setup: ECM, BCM, IPC, RFHUB, Active Dampening, Cluster — all sharing OBD connector
- Gateway is BYPASSED
- Ignition is in RUN
- 14.6V power supply
- CAN monitor (ATMA) shows 37-47 active broadcast IDs on pins 6/14

## WHAT WORKS
- ECM at 0x7E0/0x7E8 responds to TesterPresent and Read VIN
- VIN: 1C4RJFDJXEC365477
- ATMA shows body module broadcast frames on CAN-C (pins 6/14)
- Autel talks to all modules on same bench
- Alpha OBD (same OBDLink EX, USB) talks to all modules

## WHAT DOESN'T WORK
- ANY body module diagnostic request returns NO DATA
- Tried addresses from 6 different source files (see below)
- Tried CAN-IHS via STP61+ATSP7 (125kbps on pins 3/11) — NO DATA
- Tried CAN-IHS at 500kbps — NO DATA
- Tried functional broadcast 7DF — only ECM responds
- Tried brute force 0x600-0x7FF — only ECM responds

## CRITICAL THEORY (UNTESTED)
The OBDLink EX in default mode may only process standard OBD-II CAN IDs (0x7E0-0x7EF).
AlphaOBDProtocol.ts sends ATPP2CSV81 + ATPP2CON to enable "MFG extended mode" which
opens the full 0x600-0x7FF CAN ID range. Without this, body modules at 0x750, 0x740, etc.
are ignored by the adapter's CAN controller.

Previous attempt to add PP commands caused CAN ERROR on ALL modules (including ECM).
The error was likely a timing issue — insufficient delay after ATZ reset.
AlphaOBDProtocol.ts uses: ATZ(1500ms) → delay(500ms) → ATE0.
We should use: ATZ(3000ms) → delay(1000ms) → ATE0 to be safe.

After CAN ERROR, user ran ATPP2COFF + ATPP2DOFF + ATD + ATZ to restore defaults.
ECM worked again after that, confirming the PP values were the issue.

## KNOWN CAN ADDRESSES (from all project files)
### alphaobd-can-addresses-CORRECT.ts (CDA6 database, 317 modules)
- ECM: TX 0x7E0 / RX 0x7E8 (RX = TX + 0x08)
- TCM: TX 0x7E1 / RX 0x7E9
- BCM: TX 0x750 / RX 0x758
- RFHUB: TX 0x75F / RX 0x767
- ABS: TX 0x760 / RX 0x768
- IPC: TX 0x740 / RX 0x748
- ORC: TX 0x758 / RX 0x760
- ADCM: TX 0x7A8 / RX 0x7B0
- EPS: TX 0x75F / RX 0x767

### CLAUDE.md (original project spec)
- BCM: TX 0x742 / RX 0x762
- IPC: TX 0x745 / RX 0x765
- DAMP: TX 0x7E4 / RX 0x7EC
- RADIO: TX 0x772 / RX 0x77A

### ACTIVE_DAMPENING_MODULES.md
- ADM: TX 0x744 / RX 0x764
- SDM: TX 0x745 / RX 0x765

## AlphaOBDProtocol.ts INIT SEQUENCE (the one that works)
```
ATZ (2000ms timeout)
delay(500ms)
ATE0
ATI
STDI → detect STN
AT@1
ATRV
--- if STN ---
ATPP2CSV81  ← MFG extended mode value
ATPP2CON    ← enable PP 2C
ATPP2DSV01  ← CAN protocol options
ATPP2DON    ← enable PP 2D
ATZ (1500ms)
delay(500ms)
ATE0
--- end STN ---
ATL0
ATS1
ATH1
ATSP6
ATAT2
ATST96
--- if STN ---
ATCAF1
STCSWM1    (may return ? — OK to ignore)
ATFCSH7E0
ATFCSD300000
ATFCSM1
```

## AlphaOBDProtocol.ts sendUDS()
```
ATSH[TX hex]
ATFCSH[TX hex]  (if STN)
ATCRA[RX hex]
[hex data with spaces]
```

## obd2-protocol.ts KEY DETAILS
- Uses ATCAF0 (manual ISO-TP) not ATCAF1
- Clears ATCRA (no argument) before EACH module switch
- Body modules respond better to 22 F1 90 (Read VIN) than 3E 00 (TesterPresent)
- Sends wakeup broadcast via 7DF before scanning body modules
- CAN-IHS switching: STP61 + ATSP7 (not STPX H:030B)
- Switch back: ATSP6 + STP60
- Default bypassMode=true scans ALL modules on CAN-C (no bus switching)

## BUGS ALREADY FIXED
1. TextDecoderStream + pipeTo reader → replaced with direct port.readable.getReader()
2. ATAR command → replaced with ATCRA
3. Missing STN init → added STDI detection, ATAT2, ATST96, ATFCSH, ATFCSD, ATFCSM

## RECOVERY: If adapter gets stuck in CAN ERROR
Send via any serial terminal:
```
ATPP2COFF
ATPP2DOFF
ATPPSOFF
ATD
ATZ
```

## COMMANDS
- npm run dev — start Vite dev server
- The app is a single file: src/App.jsx

## APPROACH FOR FIXING
1. Add PP commands back with LONGER delays (3s ATZ, 1s settle)
2. If PP causes CAN ERROR again, try J2534 approach (j2534_bridge.py)
3. The J2534 DLL bypasses ELM327 entirely — talks raw CAN to the hardware
4. If nothing works, use Arduino CAN bridge (hardware/firmware/darkvin_can_bridge.ino)
