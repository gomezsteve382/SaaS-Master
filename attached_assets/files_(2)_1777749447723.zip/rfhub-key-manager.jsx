import { useState, useCallback, useRef } from "react";

// ════════════════════════════════════════════════════════════════════════════
// VERIFIED CONSTANTS — derived from binary analysis of FCA/Stellantis BCM + RFHUB bins
// ════════════════════════════════════════════════════════════════════════════

// ─── RFHUB EEE (4KB .bin) ───────────────────────────────────────────────────
// Key slot table: tightly-packed 6-byte entries @ 0x0C60
// Blank entry:   5A 5A 95 00 FF FF
// Entry format:  [family][A0][A1][A2][cnt_lo][cnt_hi]
// Autel ID:      [A0 A1 A2 family]  e.g. "4470B664"
// Each key written TWICE consecutively (dual-write redundancy)
// Master transponder @ 0x0226 (16 bytes)
// Verified: EH219538 (5 keys), KH633754 (4 keys), Key3 image confirmed

const RFHUB_KEY_BASE  = 0x0C60;
const RFHUB_SLOT_SIZE = 6;
const RFHUB_SLOT_MAX  = 28;
const RFHUB_BLANK     = [0x5A, 0x5A, 0x95, 0x00, 0xFF, 0xFF];
const RFHUB_MASTER    = 0x0226;
const RFHUB_MASTER_LEN= 16;
const FOB_FAMILIES    = new Set([0x60, 0x62, 0x64, 0x68, 0x6A, 0x6C, 0x6E, 0x6F]);

// ─── BCM D-Flash (64KB .bin) ────────────────────────────────────────────────
// Record block size: 0x20 (32 bytes)
// Block header:     FF FF 00 00 00 00 00 00  (first 8 bytes of each block)
// Record data:      bytes 8–29 of the block
// Free block:       bytes 8–29 all = FF
// Key record:       22 bytes = [slot_id][7B HW UID][04 04 00 14][9B vehicle secret][flag]
// Written 3× per key: copy1={slot:0x01,flag:0x7F}, copy2={slot:0x02,flag:0x7F}, copy3={slot:0x02,flag:0x8F}
// Free space scan:  0x8100 → 0x9000, 0x20-aligned
// Vehicle secret:   9 bytes at record_offset+12, SAME for ALL keys on one car
// Verified:         KH633754, ZO Scat392 BCM D-Flash dumps

const BCM_BLOCK_SIZE   = 0x20;
const BCM_SCAN_START   = 0x8100;
const BCM_SCAN_END     = 0x9000;
const BCM_RECORD_OFF   = 8;      // record data starts 8 bytes into each block
const BCM_FIXED_HDR    = [0x04, 0x04, 0x00, 0x14];
const BCM_KEY_COPIES   = [
  { slot: 0x01, flag: 0x7F },
  { slot: 0x02, flag: 0x7F },
  { slot: 0x02, flag: 0x8F },
];

// ════════════════════════════════════════════════════════════════════════════
// COLORS
// ════════════════════════════════════════════════════════════════════════════
const C = {
  bg:'#09090C', panel:'#101014', card:'#17171D', border:'#242430',
  borderBright:'#363644', green:'#00D26A', greenDim:'#00D26A1A',
  blue:'#4A9EFF', blueDim:'#4A9EFF15', red:'#FF4A4A', redDim:'#FF4A4A1A',
  orange:'#FF8C00', yellow:'#FFD700', text:'#E6E4DE', sub:'#767684',
  muted:'#323240', fresh:'#FFB800', teal:'#00C8C8',
};

// ════════════════════════════════════════════════════════════════════════════
// UTILS
// ════════════════════════════════════════════════════════════════════════════
const hx  = bytes  => Array.from(bytes).map(b => b.toString(16).padStart(2,'0').toUpperCase()).join(' ');
const hxc = bytes  => Array.from(bytes).map(b => b.toString(16).padStart(2,'0').toUpperCase()).join('');
const parseHex = s => { const c=s.replace(/\s/g,'').toUpperCase(); if(c.length%2)return null; try{return Uint8Array.from(c.match(/.{2}/g),h=>parseInt(h,16))}catch{return null} };

// ════════════════════════════════════════════════════════════════════════════
// RFHUB LOGIC
// ════════════════════════════════════════════════════════════════════════════
function rfhubIsBlank(d, off) { return RFHUB_BLANK.every((b,i)=>d[off+i]===b); }
function rfhubIsFob(d, off)   { return FOB_FAMILIES.has(d[off]); }
function rfhubSlotAutel(d, off){ const [f,A0,A1,A2]=[d[off],d[off+1],d[off+2],d[off+3]]; return[A0,A1,A2,f].map(b=>b.toString(16).padStart(2,'0').toUpperCase()).join(''); }
function rfhubSlotCnt(d, off)  { return d[off+4]|(d[off+5]<<8); }

function autelToRfhubSlot(autelHex, counter=0) {
  const s = autelHex.replace(/\s/g,'').toUpperCase();
  if (s.length !== 8) return null;
  try {
    const [A0,A1,A2,fam] = s.match(/.{2}/g).map(h=>parseInt(h,16));
    return new Uint8Array([fam,A0,A1,A2,counter&0xFF,(counter>>8)&0xFF]);
  } catch { return null; }
}

function parseRFHUB(buffer) {
  const d = new Uint8Array(buffer);
  const master = (() => { const m=d.slice(RFHUB_MASTER,RFHUB_MASTER+RFHUB_MASTER_LEN); return m.every(b=>b===0xFF)?null:m; })();
  const keys=[]; const seen=new Set();
  for (let i=0;i<RFHUB_SLOT_MAX;i++) {
    const off=RFHUB_KEY_BASE+i*RFHUB_SLOT_SIZE;
    if (off+6>d.length) break;
    const hex=hx(d.slice(off,off+6));
    if      (rfhubIsBlank(d,off)) keys.push({idx:i,off,blank:true});
    else if (rfhubIsFob(d,off))   { const dup=seen.has(hex); seen.add(hex); keys.push({idx:i,off,blank:false,dup,entry:d.slice(off,off+6),hex,autelId:rfhubSlotAutel(d,off),counter:rfhubSlotCnt(d,off)}); }
    else                          keys.push({idx:i,off,blank:null,hex});
  }
  return { data:new Uint8Array(d), master, keys, size:d.length };
}

function rfhubAddKey(parsed, autelHex, counter=0) {
  const entry=autelToRfhubSlot(autelHex,counter);
  if (!entry) return {error:'Invalid Autel ID'};
  const blanks=parsed.keys.filter(k=>k.blank);
  if (blanks.length<2) return {error:`Need ≥2 blank slots, found ${blanks.length}`};
  const out=new Uint8Array(parsed.data);
  out.set(entry,blanks[0].off); out.set(entry,blanks[1].off);
  return {data:out,off1:blanks[0].off,off2:blanks[1].off,entry};
}

function rfhubDeleteKey(parsed, targetHex) {
  const out=new Uint8Array(parsed.data); const blank=new Uint8Array(RFHUB_BLANK);
  for (const k of parsed.keys) if (!k.blank&&k.hex===targetHex) out.set(blank,k.off);
  return out;
}

function rfhubTransfer(srcParsed, dstParsed, keys) {
  let cur=dstParsed; let n=0;
  for (const k of keys) {
    const r=rfhubAddKey(cur,k.autelId,k.counter);
    if (!r.error) { cur=parseRFHUB(r.data.buffer); n++; }
  }
  return {parsed:cur,count:n};
}

// ════════════════════════════════════════════════════════════════════════════
// BCM LOGIC
// ════════════════════════════════════════════════════════════════════════════
function bcmIsKeyRecord(d, blockOff) {
  const ro=blockOff+BCM_RECORD_OFF;
  return d[ro] in [0x01,0x02] && BCM_FIXED_HDR.every((b,i)=>d[ro+8+i]===b);
}
// More robust check
function bcmIsKeyBlock(d, blockOff) {
  const ro=blockOff+BCM_RECORD_OFF;
  if (ro+22>d.length) return false;
  return (d[ro]===0x01||d[ro]===0x02) && d[ro+8]===0x04&&d[ro+9]===0x04&&d[ro+10]===0x00&&d[ro+11]===0x14;
}
function bcmIsFreeBlock(d, blockOff) {
  if (blockOff+BCM_BLOCK_SIZE>d.length) return false;
  return [...d.slice(blockOff+BCM_RECORD_OFF, blockOff+BCM_RECORD_OFF+22)].every(b=>b===0xFF);
}

function parseBCM(buffer) {
  const d=new Uint8Array(buffer);
  const keys=[]; const seen=new Set(); const freeBlocks=[];
  let secret=null;

  for (let off=BCM_SCAN_START; off<BCM_SCAN_END-BCM_BLOCK_SIZE; off+=BCM_BLOCK_SIZE) {
    if (off+BCM_BLOCK_SIZE>d.length) break;
    if (bcmIsKeyBlock(d,off)) {
      const ro=off+BCM_RECORD_OFF;
      const slot=d[ro], uid=d.slice(ro+1,ro+8), sec=d.slice(ro+12,ro+21), flag=d[ro+21];
      const uid7=hxc(uid);
      if (!seen.has(uid7)) { seen.add(uid7); keys.push({blockOff:off,recOff:ro,slot,uid,uid7,secret:sec,flag,hex:hx(uid)}); }
      if (!secret&&slot===0x01) secret=new Uint8Array(sec);
    } else if (bcmIsFreeBlock(d,off)) {
      freeBlocks.push(off);
    }
  }
  return {data:new Uint8Array(d),keys,secret,freeBlocks,size:d.length};
}

function bcmAddKey(parsed, hwUid7) {
  // hwUid7: Uint8Array of 7 bytes (MCR512 page 0 HW UID)
  if (!hwUid7||hwUid7.length!==7) return {error:'HW UID must be 7 bytes'};
  if (!parsed.secret) return {error:'No existing key records found — cannot extract vehicle secret'};
  if (parsed.freeBlocks.length<3) return {error:`Need 3 free blocks, found ${parsed.freeBlocks.length}`};

  const out=new Uint8Array(parsed.data);
  const blocks=parsed.freeBlocks.slice(0,3);
  const written=[];

  for (let i=0;i<3;i++) {
    const blk=blocks[i];
    const {slot,flag}=BCM_KEY_COPIES[i];
    // Block header
    out[blk+0]=0xFF; out[blk+1]=0xFF;
    out[blk+2]=0x00; out[blk+3]=0x00; out[blk+4]=0x00; out[blk+5]=0x00; out[blk+6]=0x00; out[blk+7]=0x00;
    // Record at +8
    const ro=blk+BCM_RECORD_OFF;
    out[ro]=slot;
    out.set(hwUid7, ro+1);
    out.set(BCM_FIXED_HDR, ro+8);
    out.set(parsed.secret, ro+12);
    out[ro+21]=flag;
    // Footer
    out[blk+30]=0xFF; out[blk+31]=0xFF;
    written.push({blockOff:blk,recOff:ro,slot,flag});
  }

  return {data:out,written};
}

function bcmDeleteKey(parsed, uid7hex) {
  const out=new Uint8Array(parsed.data);
  // Find all blocks with this UID (all 3 copies) and blank them
  for (let off=BCM_SCAN_START; off<BCM_SCAN_END; off+=BCM_BLOCK_SIZE) {
    if (!bcmIsKeyBlock(out,off)) continue;
    const ro=off+BCM_RECORD_OFF;
    const thisUid=hxc(out.slice(ro+1,ro+8));
    if (thisUid===uid7hex) {
      // Blank the record area (bytes 8-29)
      out.fill(0xFF,off+BCM_RECORD_OFF,off+BCM_RECORD_OFF+22);
    }
  }
  return out;
}

// ════════════════════════════════════════════════════════════════════════════
// TRANSPONDER DUMP PARSER
// ════════════════════════════════════════════════════════════════════════════
// Autel IM608 full transponder dump = raw chip page data
// For FCA FOBIK MCR512: likely 32 bytes (8 blocks × 4 bytes)
// The 7-byte HW UID position in the dump is not yet confirmed from a real dump
// So: parse the dump, show the user all bytes, let them select which 7 are the HW UID
// Also auto-extract the 4-byte Autel ID (look for 0x44 prefix pattern)

function parseTransponderDump(hexStr) {
  const bytes=parseHex(hexStr);
  if (!bytes) return null;

  // Try to find Autel ID: look for type byte (0x44) followed by 3 non-trivial bytes
  let autelGuess=null;
  for (let i=0;i<bytes.length-3;i++) {
    if (bytes[i]===0x44 && bytes[i+1]!==0x00&&bytes[i+1]!==0xFF && bytes[i+2]!==0x00&&bytes[i+2]!==0xFF) {
      // Autel ID = [bytes[i+3], bytes[i+2], bytes[i+1], 0x64] (reversed + family code)
      autelGuess=[bytes[i+3],bytes[i+2],bytes[i+1],0x64].map(b=>b.toString(16).padStart(2,'0').toUpperCase()).join('');
      break;
    }
  }

  // HW UID candidates: look for 7 consecutive non-trivial bytes not already identified as Autel data
  // Common positions based on ATA5577/MCR512 structure:
  // Bytes 0-6 (first 7 bytes) - most common for page 0 UID
  // Bytes 4-10
  // Show all candidates, user picks
  const candidates=[];
  for (let start=0;start<=bytes.length-7;start++) {
    const slice=Array.from(bytes.slice(start,start+7));
    const nonTrivial=slice.filter(b=>b!==0x00&&b!==0xFF).length;
    if (nonTrivial>=4) {
      candidates.push({start,bytes:new Uint8Array(slice),hex:hx(new Uint8Array(slice)),label:`Bytes ${start}-${start+6}`});
    }
  }

  return {bytes,autelGuess,candidates,size:bytes.length};
}

// ════════════════════════════════════════════════════════════════════════════
// FILE HELPERS
// ════════════════════════════════════════════════════════════════════════════
function dlBin(data,name) {
  const url=URL.createObjectURL(new Blob([data],{type:'application/octet-stream'}));
  Object.assign(document.createElement('a'),{href:url,download:name}).click();
  URL.revokeObjectURL(url);
}
function reprse(data) { return parseRFHUB(data.buffer); }
function reprseBCM(data) { return parseBCM(data.buffer); }

// ════════════════════════════════════════════════════════════════════════════
// SMALL UI COMPONENTS
// ════════════════════════════════════════════════════════════════════════════
function Drop({label, file, onLoad, accept='.bin'}) {
  const inp=useRef(); const [drag,setDrag]=useState(false);
  const handle=useCallback(async f=>{
    if(!f)return;
    onLoad({name:f.name,size:f.size,buf:await f.arrayBuffer()});
  },[onLoad]);
  return (
    <div onClick={()=>!file&&inp.current?.click()}
      onDragOver={e=>{e.preventDefault();setDrag(true);}}
      onDragLeave={()=>setDrag(false)}
      onDrop={e=>{e.preventDefault();setDrag(false);handle(e.dataTransfer.files[0]);}}
      style={{border:`2px dashed ${drag?C.green:file?C.borderBright:C.border}`,borderRadius:6,
        padding:file?'7px 10px':'16px 10px',cursor:file?'default':'pointer',
        background:drag?C.greenDim:C.card,transition:'all .15s',marginBottom:8,
        display:'flex',alignItems:'center',justifyContent:'center',minHeight:file?0:52}}>
      <input ref={inp} type="file" accept={accept} style={{display:'none'}} onChange={e=>handle(e.target.files[0])}/>
      {file?(
        <div style={{width:'100%'}}>
          <div style={{fontSize:9,color:C.green,fontFamily:'monospace',fontWeight:700}}>{file.name}</div>
          <div style={{fontSize:8,color:C.sub}}>{file.size.toLocaleString()} bytes</div>
        </div>
      ):(
        <div style={{textAlign:'center'}}>
          <div style={{fontSize:12,marginBottom:2}}>{label}</div>
          <div style={{fontSize:8,color:C.sub}}>Click or Drag & Drop</div>
        </div>
      )}
    </div>
  );
}

function Btn({label,fn,color,text='#fff',off=false,small=false}) {
  return (
    <button onClick={fn} disabled={off} style={{
      padding:small?'4px 8px':'6px 11px',fontSize:small?8:9,fontWeight:800,fontFamily:'monospace',
      background:color,color:text,border:'none',borderRadius:4,
      cursor:off?'not-allowed':'pointer',opacity:off?0.4:1,letterSpacing:.5,whiteSpace:'nowrap',
    }}>{label}</button>
  );
}

function Msg({text,ok}) {
  if(!text)return null;
  return <div style={{fontSize:8,padding:'5px 8px',borderRadius:3,marginTop:6,
    color:ok?C.green:C.red,background:ok?C.greenDim:C.redDim}}>{text}</div>;
}

function SectionHeader({title,sub}) {
  return (
    <div style={{marginBottom:8}}>
      <span style={{fontSize:10,fontWeight:800,color:C.fresh}}>{title}</span>
      {sub&&<span style={{fontSize:8,color:C.sub,marginLeft:8}}>{sub}</span>}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// RFHUB KEY TABLE
// ════════════════════════════════════════════════════════════════════════════
function RfhubKeyTable({parsed,selected,onToggle,onDel}) {
  if(!parsed)return null;
  const enrolled=parsed.keys.filter(k=>!k.blank&&!k.dup);
  const blanks=parsed.keys.filter(k=>k.blank);
  return (
    <div>
      {enrolled.length===0?(
        <div style={{fontSize:9,color:C.sub,padding:'8px 0',textAlign:'center'}}>No keys enrolled</div>
      ):(
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:8,fontFamily:'monospace'}}>
          <thead><tr style={{background:C.card}}>
            {['','AUTEL ID','SLOT ENTRY','OFF','CNT',''].map((h,i)=>(
              <th key={i} style={{padding:'3px 5px',color:C.sub,textAlign:'left',
                borderBottom:`1px solid ${C.border}`,fontWeight:700}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {enrolled.map((k,i)=>{
              const sel=selected.has(k.hex);
              return (
                <tr key={i} style={{background:sel?C.greenDim:i%2===0?C.panel:C.card}}>
                  <td style={{padding:'3px 5px',borderBottom:`1px solid ${C.border}`}}>
                    <input type="checkbox" checked={sel} onChange={()=>onToggle(k.hex)} style={{accentColor:C.green}}/>
                  </td>
                  <td style={{padding:'3px 5px',color:C.blue,fontWeight:700,borderBottom:`1px solid ${C.border}`}}>{k.autelId}</td>
                  <td style={{padding:'3px 5px',color:C.yellow,letterSpacing:.3,borderBottom:`1px solid ${C.border}`}}>{k.hex}</td>
                  <td style={{padding:'3px 5px',color:C.sub,borderBottom:`1px solid ${C.border}`}}>0x{k.off.toString(16).toUpperCase()}</td>
                  <td style={{padding:'3px 5px',color:C.sub,borderBottom:`1px solid ${C.border}`}}>0x{k.counter.toString(16).padStart(4,'0').toUpperCase()}</td>
                  <td style={{padding:'3px 5px',borderBottom:`1px solid ${C.border}`}}>
                    <Btn small label="Del" fn={()=>onDel(k.hex)} color={C.red}/>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
      <div style={{fontSize:7,color:C.sub,marginTop:3}}>{enrolled.length} key(s) · {Math.floor(blanks.length/2)} free pairs</div>
      {parsed.master&&(
        <div style={{background:'#0B1B0B',border:`1px solid ${C.green}28`,borderRadius:4,padding:'4px 8px',marginTop:5}}>
          <div style={{fontSize:7,color:C.green,fontWeight:800}}>Master Transponder @ 0x0226</div>
          <div style={{fontSize:8,fontFamily:'monospace',color:C.text,letterSpacing:.3}}>{hx(parsed.master)}</div>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// BCM KEY TABLE
// ════════════════════════════════════════════════════════════════════════════
function BcmKeyTable({parsed,onDel}) {
  if(!parsed)return null;
  return (
    <div>
      {parsed.keys.length===0?(
        <div style={{fontSize:9,color:C.sub,padding:'8px 0',textAlign:'center'}}>No keys found</div>
      ):(
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:8,fontFamily:'monospace'}}>
          <thead><tr style={{background:C.card}}>
            {['HW UID (7B)','SECRET (9B)','BLOCK',''].map((h,i)=>(
              <th key={i} style={{padding:'3px 5px',color:C.sub,textAlign:'left',
                borderBottom:`1px solid ${C.border}`,fontWeight:700}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {parsed.keys.map((k,i)=>(
              <tr key={i} style={{background:i%2===0?C.panel:C.card}}>
                <td style={{padding:'3px 5px',color:C.teal,letterSpacing:.3,borderBottom:`1px solid ${C.border}`}}>{k.hex}</td>
                <td style={{padding:'3px 5px',color:C.yellow,letterSpacing:.3,borderBottom:`1px solid ${C.border}`}}>{hx(k.secret)}</td>
                <td style={{padding:'3px 5px',color:C.sub,borderBottom:`1px solid ${C.border}`}}>0x{k.blockOff.toString(16).toUpperCase()}</td>
                <td style={{padding:'3px 5px',borderBottom:`1px solid ${C.border}`}}>
                  <Btn small label="Del" fn={()=>onDel(k.uid7)} color={C.red}/>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {parsed.secret&&(
        <div style={{background:'#1A120B',border:`1px solid ${C.orange}28`,borderRadius:4,padding:'4px 8px',marginTop:5}}>
          <div style={{fontSize:7,color:C.orange,fontWeight:800}}>Vehicle Secret (9B) — same for all keys on this car</div>
          <div style={{fontSize:8,fontFamily:'monospace',color:C.text,letterSpacing:.3}}>{hx(parsed.secret)}</div>
        </div>
      )}
      <div style={{fontSize:7,color:C.sub,marginTop:3}}>
        {parsed.keys.length} key(s) · {parsed.freeBlocks.length} free block(s)
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// TRANSPONDER DUMP PANEL
// ════════════════════════════════════════════════════════════════════════════
function DumpPanel({onConfirm}) {
  const [raw,setRaw]=useState('');
  const [parsed,setParsed]=useState(null);
  const [uidStart,setUidStart]=useState(0);

  const handleParse=()=>{
    const p=parseTransponderDump(raw);
    if(p){setParsed(p);setUidStart(0);}
  };

  const selectedUid = parsed ? parsed.bytes.slice(uidStart,uidStart+7) : null;
  const canConfirm  = parsed && selectedUid && selectedUid.length===7;

  return (
    <div>
      <div style={{fontSize:8,color:C.sub,marginBottom:8}}>
        Paste the full raw hex dump from Autel IM608 "Read Transponder Data" 
        (or equivalent tool). Expected: 32–64 bytes. Then select which 7 bytes 
        are the HW UID (chip page 0 serial) — these go into the BCM. 
        The 4-byte Autel display ID is auto-detected for the RFHUB.
      </div>

      <textarea
        value={raw} onChange={e=>setRaw(e.target.value)}
        placeholder="44 B6 70 44 2E 01 FF FF 00 00 00 00 ..."
        style={{width:'100%',height:80,padding:'6px 8px',borderRadius:4,
          border:`1px solid ${C.border}`,background:C.card,color:C.yellow,
          fontFamily:'monospace',fontSize:9,letterSpacing:.5,outline:'none',
          boxSizing:'border-box',resize:'vertical'}}
      />
      <div style={{marginTop:6,marginBottom:8}}>
        <Btn label="Parse Dump" fn={handleParse} color={C.blue}/>
      </div>

      {parsed&&(
        <div>
          <div style={{fontSize:8,color:C.sub,marginBottom:4}}>
            Dump: <span style={{color:C.text}}>{parsed.size} bytes</span>
            {parsed.autelGuess&&<>  ·  Autel ID guess: <span style={{color:C.blue,fontWeight:700}}>{parsed.autelGuess}</span></>}
          </div>

          {/* Byte map - clickable to select UID start */}
          <div style={{marginBottom:8}}>
            <div style={{fontSize:7,color:C.sub,marginBottom:3}}>
              Click start byte for 7-byte HW UID (highlighted in cyan):
            </div>
            <div style={{fontFamily:'monospace',fontSize:9,lineHeight:1.8,letterSpacing:.5}}>
              {Array.from(parsed.bytes).map((b,i)=>{
                const inRange=i>=uidStart&&i<uidStart+7;
                return (
                  <span key={i}
                    onClick={()=>i<=parsed.bytes.length-7&&setUidStart(i)}
                    style={{
                      display:'inline-block',padding:'1px 2px',cursor:'pointer',
                      background:inRange?C.teal+'44':'transparent',
                      color:inRange?C.teal:C.sub,borderRadius:2,marginRight:1,
                    }}
                    title={`Byte ${i}`}
                  >{b.toString(16).padStart(2,'0').toUpperCase()}</span>
                );
              })}
            </div>
          </div>

          {selectedUid&&(
            <div style={{fontSize:8,color:C.sub,fontFamily:'monospace',marginBottom:8}}>
              Selected HW UID: <span style={{color:C.teal,fontWeight:700}}>{hx(selectedUid)}</span>
              <span style={{color:C.sub}}> (bytes {uidStart}–{uidStart+6})</span>
            </div>
          )}

          <Btn label="Use These 7 Bytes as HW UID" fn={()=>canConfirm&&onConfirm(selectedUid,parsed.autelGuess)}
            color={C.green} text="#000" off={!canConfirm}/>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN APP
// ════════════════════════════════════════════════════════════════════════════
export default function App() {
  // RFHUB files
  const [rfhubAFile, setRfhubAFile]=useState(null);
  const [rfhubA,     setRfhubA]=useState(null);
  const [rfhubBFile, setRfhubBFile]=useState(null);
  const [rfhubB,     setRfhubB]=useState(null);
  const [selA,       setSelA]=useState(new Set());
  const [selB,       setSelB]=useState(new Set());

  // BCM file
  const [bcmFile, setBcmFile]=useState(null);
  const [bcm,     setBcm]=useState(null);

  // Add key state
  const [autelInput, setAutelInput]=useState('');
  const [rfhubTarget,setRfhubTarget]=useState('A');
  const [rfhubMsg,   setRfhubMsg]=useState({text:'',ok:true});

  // Pending HW UID from dump
  const [pendingUid,   setPendingUid]=useState(null);   // Uint8Array 7 bytes
  const [pendingAutel, setPendingAutel]=useState('');   // auto-detected Autel ID
  const [bcmMsg,       setBcmMsg]=useState({text:'',ok:true});

  // Log
  const [log,setLog]=useState([]);
  const logIt=t=>setLog(p=>[`[${new Date().toLocaleTimeString()}] ${t}`,...p.slice(0,29)]);

  // Active tab
  const [tab,setTab]=useState('rfhub'); // 'rfhub' | 'bcm' | 'dump'

  // ─── Loaders ─────────────────────────────────────────────────────────────
  const loadRfhub=(which,{name,size,buf})=>{
    const p=parseRFHUB(buf);
    const n=p.keys.filter(k=>!k.blank&&!k.dup).length;
    if(which==='A'){setRfhubAFile({name,size});setRfhubA(p);setSelA(new Set());}
    else            {setRfhubBFile({name,size});setRfhubB(p);setSelB(new Set());}
    logIt(`RFHUB ${which}: ${name} — ${n} key(s)`);
  };

  const loadBcm=({name,size,buf})=>{
    const p=parseBCM(buf);
    setBcmFile({name,size}); setBcm(p);
    logIt(`BCM: ${name} — ${p.keys.length} key(s), ${p.freeBlocks.length} free block(s), secret=${p.secret?hx(p.secret):'none'}`);
  };

  // ─── RFHUB add key ────────────────────────────────────────────────────────
  const rfhubAdd=()=>{
    setRfhubMsg({text:'',ok:true});
    const clean=autelInput.replace(/\s/g,'').toUpperCase();
    if(clean.length!==8){setRfhubMsg({text:'Autel ID = 8 hex chars',ok:false});return;}
    const p=rfhubTarget==='A'?rfhubA:rfhubB;
    const set=rfhubTarget==='A'?setRfhubA:setRfhubB;
    if(!p){setRfhubMsg({text:`Load RFHUB ${rfhubTarget} first`,ok:false});return;}
    const r=rfhubAddKey(p,clean);
    if(r.error){setRfhubMsg({text:r.error,ok:false});return;}
    set(reprse(r.data));
    setRfhubMsg({text:`Added ${clean} @ 0x${r.off1.toString(16).toUpperCase()} + 0x${r.off2.toString(16).toUpperCase()} (×2)`,ok:true});
    setAutelInput('');
    logIt(`RFHUB ${rfhubTarget}: added key ${clean}`);
  };

  // ─── RFHUB delete ─────────────────────────────────────────────────────────
  const rfhubDel=(which,hex)=>{
    const p=which==='A'?rfhubA:rfhubB; const set=which==='A'?setRfhubA:setRfhubB;
    if(!p)return;
    set(reprse(rfhubDeleteKey(p,hex)));
    logIt(`RFHUB ${which}: deleted ${hex}`);
  };

  // ─── RFHUB transfer ───────────────────────────────────────────────────────
  const rfhubXfer=(mode)=>{
    if(!rfhubA||!rfhubB){logIt('Load both RFHUB files first');return;}
    const src=rfhubA.keys.filter(k=>!k.blank&&!k.dup);
    const keys=mode==='sel'?src.filter(k=>selA.has(k.hex)):src;
    const {parsed:newB,count}=rfhubTransfer(rfhubA,rfhubB,keys);
    setRfhubB(newB);
    logIt(`RFHUB: transferred ${count} key(s) A→B`);
  };

  // ─── BCM add from pending UID ─────────────────────────────────────────────
  const bcmAdd=()=>{
    setBcmMsg({text:'',ok:true});
    if(!bcm){setBcmMsg({text:'Load BCM first',ok:false});return;}
    if(!pendingUid){setBcmMsg({text:'Parse a transponder dump first',ok:false});return;}
    const r=bcmAddKey(bcm,pendingUid);
    if(r.error){setBcmMsg({text:r.error,ok:false});return;}
    setBcm(reprseBCM(r.data));
    setBcmMsg({text:`Key added — 3 records written @ ${r.written.map(w=>'0x'+w.blockOff.toString(16).toUpperCase()).join(', ')}`,ok:true});
    logIt(`BCM: added key ${hx(pendingUid)}`);

    // Also add to RFHUB if Autel ID was detected
    if(pendingAutel) {
      const p=rfhubTarget==='A'?rfhubA:rfhubB; const set=rfhubTarget==='A'?setRfhubA:setRfhubB;
      if(p){
        const r2=rfhubAddKey(p,pendingAutel);
        if(!r2.error){set(reprse(r2.data));logIt(`RFHUB ${rfhubTarget}: auto-added ${pendingAutel} from dump`);}
      }
    }
    setPendingUid(null);setPendingAutel('');
  };

  // ─── BCM delete ───────────────────────────────────────────────────────────
  const bcmDel=(uid7hex)=>{
    if(!bcm)return;
    setBcm(reprseBCM(bcmDeleteKey(bcm,uid7hex)));
    logIt(`BCM: deleted key ${uid7hex}`);
  };

  // ─── Download ─────────────────────────────────────────────────────────────
  const dl=(which)=>{
    if(which==='rfhubA'&&rfhubAFile&&rfhubA) dlBin(rfhubA.data,rfhubAFile.name.replace('.bin','_edited.bin'));
    if(which==='rfhubB'&&rfhubBFile&&rfhubB) dlBin(rfhubB.data,rfhubBFile.name.replace('.bin','_edited.bin'));
    if(which==='bcm'&&bcmFile&&bcm)          dlBin(bcm.data,bcmFile.name.replace('.bin','_edited.bin'));
    logIt(`Downloaded ${which}`);
  };

  const preview4=autelInput.length===8?autelToRfhubSlot(autelInput):null;

  const tabStyle=(t)=>({
    padding:'6px 14px',fontSize:9,fontWeight:800,fontFamily:'monospace',cursor:'pointer',
    background:tab===t?C.fresh:'transparent',color:tab===t?'#000':C.sub,
    border:'none',borderRadius:4,letterSpacing:.5,
  });

  return (
    <div style={{minHeight:'100vh',background:C.bg,color:C.text,fontFamily:"'Courier New',monospace",paddingBottom:40}}>

      {/* Header */}
      <div style={{background:'#080809',borderBottom:`1px solid ${C.border}`,padding:'10px 20px'}}>
        <div style={{maxWidth:1100,margin:'0 auto',display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
          <div>
            <div style={{fontSize:17,fontWeight:900,color:C.fresh,letterSpacing:2}}>FRESHAUTO</div>
            <div style={{fontSize:11,fontWeight:700,color:C.text}}>FCA Key Programmer — RFHUB + BCM</div>
            <div style={{fontSize:8,color:C.sub}}>RFHUB EEE · BCM D-Flash · Transponder Dump · Full Bench Workflow</div>
          </div>
          <div style={{fontSize:7,color:C.sub,textAlign:'right',lineHeight:1.8}}>
            <div>RFHUB slots <span style={{color:C.yellow}}>0x0C60</span> · 6B stride · ×2</div>
            <div>BCM records <span style={{color:C.yellow}}>0x81A0+</span> · 0x20 blocks · ×3</div>
            <div>Master <span style={{color:C.yellow}}>0x0226</span> · Secret 9B per car</div>
          </div>
        </div>
      </div>

      <div style={{maxWidth:1100,margin:'0 auto',padding:'14px 20px'}}>

        {/* Tab bar */}
        <div style={{display:'flex',gap:4,marginBottom:14,background:C.panel,
          border:`1px solid ${C.border}`,borderRadius:6,padding:4,width:'fit-content'}}>
          <button style={tabStyle('rfhub')} onClick={()=>setTab('rfhub')}>📡 RFHUB EEE</button>
          <button style={tabStyle('bcm')}   onClick={()=>setTab('bcm')}>💾 BCM D-Flash</button>
          <button style={tabStyle('dump')}  onClick={()=>setTab('dump')}>
            🔑 Transponder Dump{pendingUid?` ✓`:''}
          </button>
        </div>

        {/* ══ RFHUB TAB ══ */}
        {tab==='rfhub'&&(
          <div>
            {/* Dual panels */}
            <div style={{display:'flex',gap:12,marginBottom:12,flexWrap:'wrap'}}>
              {[['A',C.green,rfhubA,rfhubAFile,selA,setSelA],
                ['B',C.blue, rfhubB,rfhubBFile,selB,setSelB]].map(([w,acc,p,f,s,setS])=>(
                <div key={w} style={{flex:1,minWidth:280,background:C.panel,border:`1px solid ${acc}28`,borderRadius:8,padding:12}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                    <div style={{fontSize:10,fontWeight:800,color:acc}}>RFHUB File {w}</div>
                    <Btn label={`↓ ${w}`} fn={()=>dl(`rfhub${w}`)} color={acc} text={w==='A'?'#000':'#fff'} off={!f}/>
                  </div>
                  <Drop label={`[ RFHUB ${w} ]`} file={f} onLoad={d=>loadRfhub(w,d)}/>
                  <RfhubKeyTable parsed={p} selected={s}
                    onToggle={hex=>{const n=new Set(s);n.has(hex)?n.delete(hex):n.add(hex);setS(n);}}
                    onDel={hex=>rfhubDel(w,hex)}/>
                </div>
              ))}
            </div>

            {/* Add Key from Autel */}
            <div style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:8,padding:'12px 14px',marginBottom:12}}>
              <SectionHeader title="Add Key — Autel 8-Char ID" sub="from RFHUB slot encoding"/>
              <div style={{fontSize:8,color:C.sub,marginBottom:10}}>
                Read blank fob with Autel MaxiIM/XP400. Paste 8-char UID. 
                Encoding: <span style={{color:C.yellow}}>[family A0 A1 A2 00 00]</span> written ×2 to consecutive blank slots.
              </div>
              <div style={{display:'flex',gap:8,alignItems:'flex-end',flexWrap:'wrap',marginBottom:8}}>
                <div style={{flex:2,minWidth:160}}>
                  <div style={{fontSize:8,color:C.sub,marginBottom:3}}>Autel ID (8 hex chars)</div>
                  <input value={autelInput}
                    onChange={e=>setAutelInput(e.target.value.replace(/[^0-9a-fA-F]/g,'').toUpperCase().slice(0,8))}
                    onKeyDown={e=>e.key==='Enter'&&rfhubAdd()}
                    placeholder="4470B664"
                    style={{width:'100%',padding:'7px 10px',borderRadius:4,
                      border:`1px solid ${autelInput.length===8?C.green:C.border}`,
                      background:C.card,color:C.yellow,fontFamily:'monospace',
                      fontSize:14,letterSpacing:4,outline:'none',boxSizing:'border-box'}}/>
                </div>
                <div style={{flex:1,minWidth:90}}>
                  <div style={{fontSize:8,color:C.sub,marginBottom:3}}>Target</div>
                  <select value={rfhubTarget} onChange={e=>setRfhubTarget(e.target.value)}
                    style={{width:'100%',padding:'7px 8px',background:C.card,color:C.text,
                      border:`1px solid ${C.border}`,borderRadius:4,fontSize:9,fontFamily:'monospace'}}>
                    <option value="A">File A</option><option value="B">File B</option>
                  </select>
                </div>
                <Btn label="Add to RFHUB" fn={rfhubAdd} color={C.green} text="#000"/>
              </div>
              {preview4&&<div style={{fontSize:8,color:C.sub,fontFamily:'monospace',marginBottom:4}}>
                Slot: <span style={{color:C.yellow}}>{hx(preview4)}</span>
              </div>}
              <Msg {...rfhubMsg}/>
            </div>

            {/* Transfer */}
            <div style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:8,padding:'12px 14px',marginBottom:12}}>
              <SectionHeader title="Transfer Keys" sub="copy enrolled records between files"/>
              <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                <Btn label="Selected A → B" fn={()=>rfhubXfer('sel')} color={C.orange}/>
                <Btn label="All A → B"      fn={()=>rfhubXfer('all')} color={C.blue}/>
              </div>
            </div>
          </div>
        )}

        {/* ══ BCM TAB ══ */}
        {tab==='bcm'&&(
          <div>
            <div style={{background:C.panel,border:`1px solid ${C.orange}28`,borderRadius:8,padding:12,marginBottom:12}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                <div style={{fontSize:10,fontWeight:800,color:C.orange}}>BCM D-Flash (64KB)</div>
                <Btn label="↓ BCM" fn={()=>dl('bcm')} color={C.orange} off={!bcmFile}/>
              </div>
              <Drop label="[ BCM D-Flash .bin ]" file={bcmFile} onLoad={loadBcm}/>
              <BcmKeyTable parsed={bcm} onDel={bcmDel}/>
            </div>

            {/* Add key from dump */}
            <div style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:8,padding:'12px 14px',marginBottom:12}}>
              <SectionHeader title="Add Key from Transponder Dump" sub="requires 7-byte HW UID from chip page 0"/>

              {pendingUid?(
                <div>
                  <div style={{fontSize:8,color:C.sub,marginBottom:8}}>
                    Pending HW UID:{' '}
                    <span style={{color:C.teal,fontFamily:'monospace',fontWeight:700}}>{hx(pendingUid)}</span>
                    {pendingAutel&&<> · Autel ID: <span style={{color:C.blue,fontFamily:'monospace',fontWeight:700}}>{pendingAutel}</span></>}
                  </div>
                  <div style={{fontSize:8,color:C.sub,marginBottom:10}}>
                    BCM record: <span style={{color:C.orange,fontFamily:'monospace'}}>
                      [01][{hx(pendingUid)}][04 04 00 14][vehicle secret (9B)][7F]
                    </span> × 3 copies in next 3 free 0x20 blocks.
                    {pendingAutel&&` Also adds Autel ID ${pendingAutel} to RFHUB ${rfhubTarget}.`}
                  </div>
                  <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
                    <div style={{fontSize:8,color:C.sub}}>Also add to RFHUB:</div>
                    <select value={rfhubTarget} onChange={e=>setRfhubTarget(e.target.value)}
                      style={{padding:'4px 6px',background:C.card,color:C.text,
                        border:`1px solid ${C.border}`,borderRadius:4,fontSize:8,fontFamily:'monospace'}}>
                      <option value="A">File A</option><option value="B">File B</option>
                      <option value="none">Don't add to RFHUB</option>
                    </select>
                    <Btn label="Write to BCM" fn={bcmAdd} color={C.green} text="#000" off={!bcm}/>
                    <Btn label="Clear" fn={()=>{setPendingUid(null);setPendingAutel('');}} color={C.muted}/>
                  </div>
                  <Msg {...bcmMsg}/>
                </div>
              ):(
                <div>
                  <div style={{fontSize:9,color:C.sub}}>
                    No transponder dump loaded. Go to the{' '}
                    <span style={{color:C.fresh,cursor:'pointer'}} onClick={()=>setTab('dump')}>
                      🔑 Transponder Dump
                    </span>{' '}tab to parse a dump and select the 7-byte HW UID.
                  </div>
                </div>
              )}
            </div>

            <div style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:8,padding:'10px 14px'}}>
              <div style={{fontSize:8,color:C.sub,lineHeight:1.7}}>
                <div><span style={{color:C.orange}}>BCM record format:</span> [slot=01/02][7B HW UID][04 04 00 14][9B vehicle secret][7F/8F]</div>
                <div><span style={{color:C.orange}}>Written 3×:</span> slot=01/flag=7F · slot=02/flag=7F · slot=02/flag=8F</div>
                <div><span style={{color:C.orange}}>Block layout:</span> [FF FF 00 00 00 00 00 00][22B record][FF FF] = 32 bytes per block</div>
                <div><span style={{color:C.orange}}>Free blocks:</span> scanned 0x8100→0x9000, 0x20-aligned, bytes 8–29 all FF</div>
              </div>
            </div>
          </div>
        )}

        {/* ══ DUMP TAB ══ */}
        {tab==='dump'&&(
          <div style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:8,padding:'12px 14px',marginBottom:12}}>
            <SectionHeader title="Transponder Dump Parser" sub="MCR512 / FOBIK chip — Autel IM608 full read"/>
            <DumpPanel onConfirm={(uid7,autelId)=>{
              setPendingUid(uid7);
              setPendingAutel(autelId||'');
              setBcmMsg({text:'',ok:true});
              logIt(`Dump parsed: HW UID=${hx(uid7)}${autelId?` Autel=${autelId}`:''}`);
              setTab('bcm');
            }}/>
          </div>
        )}

        {/* Log */}
        {log.length>0&&(
          <div style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:8,padding:'10px 14px',marginTop:8}}>
            <div style={{fontSize:8,fontWeight:800,color:C.sub,marginBottom:4}}>LOG</div>
            {log.map((e,i)=>(
              <div key={i} style={{fontSize:8,color:i===0?C.green:C.sub,fontFamily:'monospace',padding:'1px 0'}}>{e}</div>
            ))}
          </div>
        )}

        <div style={{marginTop:16,fontSize:7,color:C.muted,textAlign:'center'}}>
          RFHUB slots 0x0C60 · 6B · ×2 · master 0x0226 · BCM blocks 0x81A0+ · 0x20 · ×3 · secret 9B ·
          verified KH633754 + ZO Scat392 D-Flash
        </div>
      </div>
    </div>
  );
}
