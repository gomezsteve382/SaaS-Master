{pkgs}: {
  deps = [
    pkgs.sqlite
  ];
}
